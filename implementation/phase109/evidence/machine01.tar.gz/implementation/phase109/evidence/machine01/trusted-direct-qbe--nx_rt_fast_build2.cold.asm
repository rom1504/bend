
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004015b3 <nx_rt_fast_build2.cold>:
  4015b3:	mov    %r13,%rdx
  4015b6:	mov    $0x1,%ecx
  4015bb:	mov    %r15,%rdi
  4015be:	mov    %r14,%rsi
  4015c1:	mov    %r8,0x8(%rsp)
  4015c6:	callq  401397 <rfc_wrap>
  4015cb:	mov    0x8(%rsp),%r8
  4015d0:	mov    %rax,%r13
  4015d3:	jmpq   40285d <nx_rt_fast_build2+0x4d>
  4015d8:	mov    %r12,%rdx
  4015db:	mov    $0x1,%ecx
  4015e0:	mov    %r15,%rdi
  4015e3:	mov    %r14,%rsi
  4015e6:	callq  401397 <rfc_wrap>
  4015eb:	mov    %rax,%r12
  4015ee:	jmpq   402875 <nx_rt_fast_build2+0x65>
  4015f3:	mov    $0x1,%edx
  4015f8:	mov    %r15,%rdi
  4015fb:	mov    %r14,%rsi
  4015fe:	callq  401178 <heap_alloc_miss>
  401603:	mov    %rax,%rbp
  401606:	lea    (%r15,%rax,8),%r8
  40160a:	jmpq   40284d <nx_rt_fast_build2+0x3d>

Disassembly of section .fini:
