
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403c50 <nx_rt_pair_rebuild2_c3_k0>:
  403c50:	push   %r15
  403c52:	push   %r14
  403c54:	push   %r13
  403c56:	push   %r12
  403c58:	mov    %rdx,%r12
  403c5b:	push   %rbp
  403c5c:	push   %rbx
  403c5d:	movabs $0xffffffffff,%rbx
  403c67:	and    %rsi,%rbx
  403c6a:	lea    0x0(,%rbx,8),%rdx
  403c72:	sub    $0x18,%rsp
  403c76:	mov    (%rdi),%rbp
  403c79:	mov    0x8(%rdi),%r15
  403c7d:	lea    0x0(%rbp,%rdx,1),%rax
  403c82:	test   %rsi,%rsi
  403c85:	js     403d40 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  403c8b:	mov    (%rax),%r14
  403c8e:	mov    0x8(%rbp,%rdx,1),%r13
  403c93:	cmp    $0x310817f,%rbx
  403c9a:	jbe    403d10 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  403c9c:	lea    0x0(%rbp,%rbx,8),%r8
  403ca1:	mov    %r14,%rax
  403ca4:	shr    $0x38,%rax
  403ca8:	and    $0x7f,%eax
  403cab:	cmp    $0x2,%rax
  403caf:	je     403cf0 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  403cb1:	mov    %r12,%rax
  403cb4:	mov    %r14,(%r8)
  403cb7:	lea    0x8(%rbp,%rbx,8),%r14
  403cbc:	shr    $0x38,%rax
  403cc0:	and    $0x7f,%eax
  403cc3:	cmp    $0x2,%rax
  403cc7:	je     403d00 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  403cc9:	movabs $0x200030000000000,%rax
  403cd3:	mov    %r12,(%r14)
  403cd6:	mov    %r13,%rdx
  403cd9:	add    $0x18,%rsp
  403cdd:	or     %rbx,%rax
  403ce0:	pop    %rbx
  403ce1:	pop    %rbp
  403ce2:	pop    %r12
  403ce4:	pop    %r13
  403ce6:	pop    %r14
  403ce8:	pop    %r15
  403cea:	retq   
  403ceb:	nopl   0x0(%rax,%rax,1)
  403cf0:	test   %r14,%r14
  403cf3:	js     403cb1 <nx_rt_pair_rebuild2_c3_k0+0x61>
  403cf5:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  403cfa:	nopw   0x0(%rax,%rax,1)
  403d00:	test   %r12,%r12
  403d03:	js     403cc9 <nx_rt_pair_rebuild2_c3_k0+0x79>
  403d05:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  403d0a:	nopw   0x0(%rax,%rax,1)
  403d10:	mov    0x8(%r15),%rbx
  403d14:	test   %rbx,%rbx
  403d17:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  403d1d:	lea    0x0(%rbp,%rbx,8),%r8
  403d22:	mov    (%r8),%rax
  403d25:	subq   $0x2,0x108(%r15)
  403d2d:	mov    %rax,0x8(%r15)
  403d31:	jmpq   403ca1 <nx_rt_pair_rebuild2_c3_k0+0x51>
  403d36:	nopw   %cs:0x0(%rax,%rax,1)
  403d40:	mov    0x4(%rax),%edx
  403d43:	mov    (%rax),%ecx
  403d45:	shl    $0x20,%rdx
  403d49:	or     %rcx,%rdx
  403d4c:	mov    %rdx,%rcx
  403d4f:	and    $0xffffff,%edx
  403d55:	shr    $0x18,%rcx
  403d59:	lea    0x8(,%rcx,8),%rdi
  403d61:	lea    0x0(%rbp,%rdi,1),%r8
  403d66:	lea    -0x8(%rbp,%rdi,1),%rdi
  403d6b:	cmp    $0x1,%rdx
  403d6f:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  403d75:	mov    (%rax),%edx
  403d77:	mov    (%r15),%rdx
  403d7a:	mov    (%rdi),%r14
  403d7d:	mov    (%r8),%r13
  403d80:	mov    %rdx,(%rax)
  403d83:	mov    0x100(%r15),%rax
  403d8a:	mov    0x3d448(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403d90:	mov    %rbx,(%r15)
  403d93:	add    $0x1,%rax
  403d97:	mov    %rax,0x100(%r15)
  403d9e:	cmp    %rdx,%rax
  403da1:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  403da7:	mov    %rcx,%rbx
  403daa:	jmpq   403c93 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
