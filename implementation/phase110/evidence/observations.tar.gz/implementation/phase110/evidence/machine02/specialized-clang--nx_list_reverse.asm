
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	push   %r14
  401df2:	push   %rbx
  401df3:	push   %rax
  401df4:	mov    %rdx,%r14
  401df7:	mov    %rdi,%rbx
  401dfa:	nopw   0x0(%rax,%rax,1)
  401e00:	mov    %rsi,%rax
  401e03:	shr    $0x28,%rax
  401e07:	cmp    $0x1,%ax
  401e0b:	jne    401e2a <nx_list_reverse+0x3a>
  401e0d:	mov    %rbx,%rdi
  401e10:	mov    %r14,%rdx
  401e13:	callq  403570 <nx_rt_rebuild2_c1_k0>
  401e18:	mov    %rax,%r14
  401e1b:	mov    %rbx,%rdi
  401e1e:	xor    %esi,%esi
  401e20:	callq  402ea0 <nx_rt_fast_field>
  401e25:	mov    %rax,%rsi
  401e28:	jmp    401e00 <nx_list_reverse+0x10>
  401e2a:	movzwl %ax,%eax
  401e2d:	test   %eax,%eax
  401e2f:	jne    401e3c <nx_list_reverse+0x4c>
  401e31:	mov    %r14,%rax
  401e34:	add    $0x8,%rsp
  401e38:	pop    %rbx
  401e39:	pop    %r14
  401e3b:	retq   
  401e3c:	mov    %rbx,%rdi
  401e3f:	mov    $0x1,%esi
  401e44:	add    $0x8,%rsp
  401e48:	pop    %rbx
  401e49:	pop    %r14
  401e4b:	jmpq   4026a0 <nx_rt_fail>

Disassembly of section .fini:
