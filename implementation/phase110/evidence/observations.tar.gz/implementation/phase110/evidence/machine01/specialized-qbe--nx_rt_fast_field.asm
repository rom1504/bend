
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d10 <nx_rt_fast_field>:
  402d10:	mov    %esi,%ecx
  402d12:	mov    $0xfffffffe,%eax
  402d17:	rol    %cl,%eax
  402d19:	add    $0x2,%rcx
  402d1d:	and    %eax,0x20(%rdi)
  402d20:	mov    (%rdi,%rcx,8),%rax
  402d24:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402d2c:	retq   

Disassembly of section .fini:
