
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e40 <nx_string_reverse>:
  401e40:	push   %rbx
  401e41:	mov    %rdx,%rax
  401e44:	mov    %rdi,%rbx
  401e47:	nopw   0x0(%rax,%rax,1)
  401e50:	mov    %rsi,%rcx
  401e53:	shr    $0x28,%rcx
  401e57:	cmp    $0x3,%cx
  401e5b:	jne    401e6d <nx_string_reverse+0x2d>
  401e5d:	mov    %rbx,%rdi
  401e60:	mov    %rax,%rdx
  401e63:	callq  403c50 <nx_rt_pair_rebuild2_c3_k0>
  401e68:	mov    %rdx,%rsi
  401e6b:	jmp    401e50 <nx_string_reverse+0x10>
  401e6d:	movzwl %cx,%ecx
  401e70:	cmp    $0x2,%ecx
  401e73:	jne    401e77 <nx_string_reverse+0x37>
  401e75:	pop    %rbx
  401e76:	retq   
  401e77:	mov    %rbx,%rdi
  401e7a:	mov    $0x1,%esi
  401e7f:	pop    %rbx
  401e80:	jmpq   402670 <nx_rt_fail>

Disassembly of section .fini:
