
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004029a0 <nx_rt_fast_field>:
  4029a0:	mov    %esi,%ecx
  4029a2:	mov    $0xfffffffe,%eax
  4029a7:	rol    %cl,%eax
  4029a9:	add    $0x2,%rcx
  4029ad:	and    %eax,0x20(%rdi)
  4029b0:	mov    (%rdi,%rcx,8),%rax
  4029b4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  4029bc:	retq   

Disassembly of section .fini:
