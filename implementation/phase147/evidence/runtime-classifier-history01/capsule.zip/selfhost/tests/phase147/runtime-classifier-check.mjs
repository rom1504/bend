// Exact production closure versus independently enumerated closed-name oracle.
import fs from 'node:fs';
import path from 'node:path';
import assert from 'node:assert/strict';
import {pathToFileURL} from 'node:url';
import * as S from '../../../experiments/phase147/tools/support.mjs';
const a=S.options();for(const k of ['preparation','out'])assert(a[k]);
const out=S.output(a.out),p=S.read(a.preparation),rfile=path.join(path.dirname(a.preparation),'api/report.json'),r=S.read(rfile);
const inputs=[S.pin(import.meta.filename),S.pin(path.join(S.root,'experiments/phase147/tools/support.mjs')),S.pin(a.preparation),S.pin(rfile),p.apiSource,p.candidate,p.cases,r.api,r.source];
const report={kind:'phase147-runtime-classifier-controls',complete:false,passed:false,inputs,rows:[],scope:'Pure finite Boolean equivalence and independent closed-set expectations; no native ownership proof or whole-request speed claim.'};
const save=()=>S.save(out+'/report.json',report);save();
try{
 assert.equal(p.kind,'phase147-runtime-classifier-preparation');assert(p.complete);assert.equal(r.kind,'bend-checked-hosted-api');assert(r.complete&&r.checked);assert(S.same(p.apiSource,r.source));
 assert.deepEqual(r.exports,['p118z_runtime','p147z_runtime','p111v_signature']);inputs.forEach(S.verify);
 const api=(await import(pathToFileURL(r.api.file))).default,fixture=S.read(p.cases.file);assert(fixture.complete&&fixture.kind==='phase147-runtime-classifier-cases');
 for(const x of fixture.cases){const old=api.p118z_runtime(x.symbol),fresh=api.p147z_runtime(x.symbol);assert.equal(old,x.expected,'original '+JSON.stringify(x.symbol));assert.equal(fresh,x.expected,'candidate '+JSON.stringify(x.symbol));report.rows.push({symbol:x.symbol,expected:x.expected,old,fresh,passed:true});}
 inputs.forEach(S.verify);report.complete=report.passed=true;
}catch(error){report.error=String(error.stack??error);process.exitCode=1;}
finally{save();console.log(JSON.stringify({complete:report.complete,passed:report.passed,cases:report.rows.length,error:report.error}));}
