
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403b60 <nx_rt_rebuild2_c3_k0>:
  403b60:	push   %r15
  403b62:	push   %r14
  403b64:	push   %r13
  403b66:	push   %r12
  403b68:	mov    %rdx,%r12
  403b6b:	push   %rbp
  403b6c:	mov    %rdi,%rbp
  403b6f:	push   %rbx
  403b70:	movabs $0xffffffffff,%rbx
  403b7a:	and    %rsi,%rbx
  403b7d:	lea    0x0(,%rbx,8),%rdx
  403b85:	sub    $0x18,%rsp
  403b89:	mov    (%rdi),%r13
  403b8c:	mov    0x8(%rdi),%r15
  403b90:	lea    0x0(%r13,%rdx,1),%rax
  403b95:	test   %rsi,%rsi
  403b98:	js     403c60 <nx_rt_rebuild2_c3_k0+0x100>
  403b9e:	mov    (%rax),%r14
  403ba1:	mov    0x8(%r13,%rdx,1),%r9
  403ba6:	cmp    $0x310817f,%rbx
  403bad:	jbe    403c38 <nx_rt_rebuild2_c3_k0+0xd8>
  403bb3:	lea    0x0(%r13,%rbx,8),%r8
  403bb8:	mov    %r14,%rax
  403bbb:	mov    %r9,0x10(%rbp)
  403bbf:	shr    $0x38,%rax
  403bc3:	movq   $0xffffffffffffffff,0x18(%rbp)
  403bcb:	and    $0x7f,%eax
  403bce:	movl   $0x1,0x20(%rbp)
  403bd5:	cmp    $0x2,%rax
  403bd9:	je     403c18 <nx_rt_rebuild2_c3_k0+0xb8>
  403bdb:	mov    %r12,%rax
  403bde:	mov    %r14,(%r8)
  403be1:	lea    0x8(%r13,%rbx,8),%rbp
  403be6:	shr    $0x38,%rax
  403bea:	and    $0x7f,%eax
  403bed:	cmp    $0x2,%rax
  403bf1:	je     403c28 <nx_rt_rebuild2_c3_k0+0xc8>
  403bf3:	movabs $0x200030000000000,%rax
  403bfd:	mov    %r12,0x0(%rbp)
  403c01:	add    $0x18,%rsp
  403c05:	or     %rbx,%rax
  403c08:	pop    %rbx
  403c09:	pop    %rbp
  403c0a:	pop    %r12
  403c0c:	pop    %r13
  403c0e:	pop    %r14
  403c10:	pop    %r15
  403c12:	retq   
  403c13:	nopl   0x0(%rax,%rax,1)
  403c18:	test   %r14,%r14
  403c1b:	js     403bdb <nx_rt_rebuild2_c3_k0+0x7b>
  403c1d:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  403c22:	nopw   0x0(%rax,%rax,1)
  403c28:	test   %r12,%r12
  403c2b:	js     403bf3 <nx_rt_rebuild2_c3_k0+0x93>
  403c2d:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  403c32:	nopw   0x0(%rax,%rax,1)
  403c38:	mov    0x8(%r15),%rbx
  403c3c:	test   %rbx,%rbx
  403c3f:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  403c45:	lea    0x0(%r13,%rbx,8),%r8
  403c4a:	mov    (%r8),%rax
  403c4d:	subq   $0x2,0x108(%r15)
  403c55:	mov    %rax,0x8(%r15)
  403c59:	jmpq   403bb8 <nx_rt_rebuild2_c3_k0+0x58>
  403c5e:	xchg   %ax,%ax
  403c60:	mov    0x4(%rax),%edx
  403c63:	mov    (%rax),%ecx
  403c65:	shl    $0x20,%rdx
  403c69:	or     %rcx,%rdx
  403c6c:	mov    %rdx,%rcx
  403c6f:	and    $0xffffff,%edx
  403c75:	shr    $0x18,%rcx
  403c79:	lea    0x8(,%rcx,8),%rdi
  403c81:	lea    0x0(%r13,%rdi,1),%r8
  403c86:	lea    -0x8(%r13,%rdi,1),%rdi
  403c8b:	cmp    $0x1,%rdx
  403c8f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  403c95:	mov    (%rax),%edx
  403c97:	mov    (%r15),%rdx
  403c9a:	mov    (%rdi),%r14
  403c9d:	mov    (%r8),%r9
  403ca0:	mov    %rdx,(%rax)
  403ca3:	mov    0x100(%r15),%rax
  403caa:	mov    0x3d528(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403cb0:	mov    %rbx,(%r15)
  403cb3:	add    $0x1,%rax
  403cb7:	mov    %rax,0x100(%r15)
  403cbe:	cmp    %rdx,%rax
  403cc1:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  403cc7:	mov    %rcx,%rbx
  403cca:	jmpq   403ba6 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
