
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/coverage-map-churn-128/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000406120 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>:
  406120:	endbr64 
  406124:	push   %rbp
  406125:	mov    %rsp,%rbp
  406128:	sub    $0x808,%rsp
  40612f:	push   %rbx
  406130:	push   %r12
  406132:	push   %r13
  406134:	data16 nopw %cs:0x0(%rax,%rax,1)
  40613f:	nop
  406140:	mov    %rsi,%rax
  406143:	shr    $0x28,%rax
  406147:	and    $0xffff,%rax
  40614d:	cmp    $0x18,%rax
  406151:	je     4062b8 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x198>
  406157:	cmp    $0x19,%rax
  40615b:	sete   %r8b
  40615f:	movzbl %r8b,%r8d
  406163:	jne    4062a7 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x187>
  406169:	cs cs mov %rsi,%rax
  40616e:	shr    $0x38,%rax
  406172:	and    $0x7f,%rax
  406176:	cmp    $0x2,%rax
  40617a:	sete   %al
  40617d:	movzbl %al,%eax
  406180:	test   %eax,%r8d
  406183:	jne    4061b0 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x90>
  406185:	mov    $0x2,%r8d
  40618b:	mov    %rcx,%r13
  40618e:	mov    $0x19,%ecx
  406193:	mov    %rdx,%r12
  406196:	lea    -0x800(%rbp),%rdx
  40619d:	mov    %rdi,%rbx
  4061a0:	callq  4368c0 <p118_rt_borrow_fields>
  4061a5:	mov    %r13,%rcx
  4061a8:	mov    %r12,%rdx
  4061ab:	mov    %rbx,%rdi
  4061ae:	jmp    406206 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0xe6>
  4061b0:	mov    %rsi,%r9
  4061b3:	mov    (%rdi),%rsi
  4061b6:	movabs $0xffffffffff,%rax
  4061c0:	and    %r9,%rax
  4061c3:	mov    %r9,%r8
  4061c6:	shr    $0x3f,%r8
  4061ca:	cmp    $0x0,%r8
  4061ce:	je     4061eb <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0xcb>
  4061d0:	mov    %rax,%r8
  4061d3:	shl    $0x3,%r8
  4061d7:	mov    (%r8,%rsi,1),%eax
  4061db:	mov    0x4(%r8,%rsi,1),%r8d
  4061e0:	shl    $0x20,%r8
  4061e4:	or     %r8,%rax
  4061e7:	shr    $0x18,%rax
  4061eb:	shl    $0x3,%rax
  4061ef:	mov    (%rax,%rsi,1),%r8
  4061f3:	mov    %r8,-0x800(%rbp)
  4061fa:	mov    0x8(%rax,%rsi,1),%rax
  4061ff:	mov    %rax,-0x7f8(%rbp)
  406206:	mov    -0x800(%rbp),%rbx
  40620d:	mov    -0x7f8(%rbp),%rsi
  406214:	cmp    $0x0,%rdx
  406218:	je     406225 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x105>
  40621a:	cs cs sub $0x1,%rdx
  406220:	jmpq   406140 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x20>
  406225:	cmp    $0x0,%rcx
  406229:	je     40628f <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x16f>
  40622b:	cs cs cs mov %rcx,%rax
  406231:	sub    $0x1,%rax
  406235:	movq   $0x1f,-0x800(%rbp)
  406240:	mov    %rax,-0x7f8(%rbp)
  406247:	mov    $0x2,%ecx
  40624c:	lea    -0x800(%rbp),%rdx
  406253:	mov    $0x3f,%esi
  406258:	callq  432050 <p111_rt_op>
  40625d:	mov    %rax,%rcx
  406260:	cmp    $0x20,%rcx
  406264:	jb     40626d <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x14d>
  406266:	mov    $0x0,%eax
  40626b:	jmp    40627a <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x15a>
  40626d:	mov    %ebx,%eax
  40626f:	shr    %cl,%rax
  406272:	mov    $0xffffffff,%ecx
  406277:	and    %rcx,%rax
  40627a:	mov    %eax,%eax
  40627c:	and    $0x1,%eax
  40627f:	mov    %eax,%eax
  406281:	cmp    $0x0,%rax
  406285:	setne  %al
  406288:	movzbl %al,%eax
  40628b:	mov    %eax,%eax
  40628d:	jmp    4062ce <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1ae>
  40628f:	mov    $0x0,%ecx
  406294:	lea    -0x800(%rbp),%rdx
  40629b:	mov    $0x2,%esi
  4062a0:	callq  433230 <p111_rt_special_ctor>
  4062a5:	jmp    4062ce <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1ae>
  4062a7:	mov    $0x4,%esi
  4062ac:	callq  432030 <p111_rt_fail>
  4062b1:	mov    $0x0,%eax
  4062b6:	jmp    4062ce <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1ae>
  4062b8:	mov    $0x0,%ecx
  4062bd:	lea    -0x800(%rbp),%rdx
  4062c4:	mov    $0x1,%esi
  4062c9:	callq  433230 <p111_rt_special_ctor>
  4062ce:	pop    %r13
  4062d0:	pop    %r12
  4062d2:	pop    %rbx
  4062d3:	leaveq 
  4062d4:	retq   

Disassembly of section .fini:
