#!/usr/bin/env python3
"""Repackage portable checked current + pinned TS outputs; execute no target/compiler."""
import argparse
import gzip
import hashlib
import io
import json
from pathlib import Path
import shutil
import sys
import tarfile

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / 'programs'))
from run import load_bundle, verify
from support import identity, save


def record(data, path):
    return dict(path=path, bytes=len(data), sha256=hashlib.sha256(data).hexdigest())


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--current', type=Path, required=True)
    p.add_argument('--reference', type=Path, required=True)
    p.add_argument('--catalog', type=Path, required=True)
    p.add_argument('--out', type=Path, required=True)
    p.add_argument('--expected-api', required=True, help='Explicit starting checked API SHA256')
    a = p.parse_args()
    out = a.out.resolve(); out.mkdir(parents=True, exist_ok=False)
    catalog = json.loads(a.catalog.read_text()); sha = identity(a.catalog)['sha256']
    inputs = [identity(x) for x in [__file__, a.current, a.reference, a.catalog]]
    current = load_bundle(a.current, catalog, sha, catalog['cases'], ['candidate'], inputs, out / 'work/current')
    ref = load_bundle(a.reference, catalog, sha, catalog['cases'], ['baseline', 'typescript'], inputs, out / 'work/reference')
    c = current['roles']['candidate']['compiler']
    assert len(a.expected_api) == 64 and all(x in '0123456789abcdef' for x in a.expected_api)
    assert c['api']['sha256'] == a.expected_api
    assert c['kind'] == 'checked-development-attempt'
    origin = json.loads(a.current.read_text())
    assert origin['complete'] and origin.get('archive') and origin.get('provenance')
    verify(a.current.parent / origin['provenance']['path'], origin['provenance'])
    assert json.loads((a.current.parent / origin['provenance']['path']).read_text())['complete']
    files = {'consumed/freeze-baseline.py': Path(__file__).read_bytes()}
    # Preserve complete current acquisition, including original manifest/receipts.
    for file in sorted(a.current.parent.rglob('*')):
        assert not file.is_symlink()
        if file.is_file():
            files['acquisition/current/' + str(file.relative_to(a.current.parent))] = file.read_bytes()
            inputs.append(identity(file))
    for name in ['manifest.json', 'provenance.json', 'programs.tar.gz']:
        file = a.reference.parent / name
        files['acquisition/reference/' + name] = file.read_bytes(); inputs.append(identity(file))
    roles = {'baseline': current['roles']['candidate'], 'typescript': ref['roles']['typescript']}
    roles['baseline']['label'] = 'Phase40 starting Phase39 checked05 (retained portable acquisition)'
    cases = []
    for case in catalog['cases']:
        row = dict(id=case['id'], sourceSha256=case['source']['sha256'], point=case['point'], modules={})
        for role, bundle, oldrole in [('baseline', current, 'candidate'), ('typescript', ref, 'typescript')]:
            item = bundle['points'][case['id']][oldrole]
            data = Path(item['resolved']).read_bytes()
            name = role + '/modules/' + item['sha256'] + '.mjs'
            files[name] = data; row['modules'][role] = record(data, name)
        cases.append(row)
    provenance = dict(kind='phase40-retained-checked-reference', complete=True,
        scope='Repackages exact retained starting checked current and pinned TS outputs. No new compilation or execution. Current candidate role is relabeled baseline; original receipts and reference archive are retained.',
        inputs=inputs, cases=len(cases), baselineApi=c['api']['sha256'], parentTool=identity(HERE.parent/'phase39/freeze-baseline.py'))
    data = (json.dumps(provenance, indent=2)+'\n').encode(); files['provenance.json'] = data
    archive = out / 'programs.tar.gz'
    with archive.open('xb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as gz:
        with tarfile.open(fileobj=gz, mode='w|') as tar:
            for name, body in sorted(files.items()):
                info = tarfile.TarInfo(name); info.size=len(body); info.mode=0o644; info.mtime=0
                tar.addfile(info, io.BytesIO(body))
    with tarfile.open(archive, 'r:gz') as tar:
        members=tar.getmembers(); assert len(members)==len(files)
        for m in members: assert m.isfile() and tar.extractfile(m).read()==files[m.name]
    for item in inputs: verify(item['path'], item)
    save(out/'manifest.json', dict(kind='bend-program-bundle', schemaVersion=1, complete=True,
        upstreamCommit=catalog['upstreamCommit'], catalogSha256=sha, roles=roles, cases=cases,
        archive=record(archive.read_bytes(),'programs.tar.gz'), provenance=record(data,'provenance.json'),
        preservation=dict(members=len(files), reopenedVerified=True)))
    save(out/'provenance.json', provenance)
    shutil.rmtree(out/'work')
    print(json.dumps(dict(complete=True, cases=len(cases), bytes=archive.stat().st_size)))


if __name__ == '__main__':
    main()
