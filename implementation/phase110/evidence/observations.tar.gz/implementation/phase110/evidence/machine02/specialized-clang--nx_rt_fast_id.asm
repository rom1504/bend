
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402bf0 <nx_rt_fast_id>:
  402bf0:	shr    $0x28,%rsi
  402bf4:	movzwl %si,%eax
  402bf7:	retq   

Disassembly of section .fini:
