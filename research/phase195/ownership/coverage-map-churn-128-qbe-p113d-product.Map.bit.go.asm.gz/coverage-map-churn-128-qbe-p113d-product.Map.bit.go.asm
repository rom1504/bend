
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/coverage-map-churn-128/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000406380 <p113d_FID_36_112_114_111_100_117_99_116_46_77_97_112_46_98_105_116_46_103_111_>:
  406380:	endbr64 
  406384:	push   %rbp
  406385:	mov    %rsp,%rbp
  406388:	push   %rbx
  406389:	push   %r12
  40638b:	mov    %rdx,%r12
  40638e:	mov    %rcx,%rdx
  406391:	mov    %r8,%rcx
  406394:	mov    %rsi,%rbx
  406397:	mov    %r12,%rsi
  40639a:	callq  406120 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>
  40639f:	mov    %r12,%rdx
  4063a2:	mov    %rbx,%rsi
  4063a5:	mov    %rdx,(%rsi)
  4063a8:	mov    %rax,0x8(%rsi)
  4063ac:	mov    $0x0,%eax
  4063b1:	pop    %r12
  4063b3:	pop    %rbx
  4063b4:	leaveq 
  4063b5:	retq   

Disassembly of section .fini:
