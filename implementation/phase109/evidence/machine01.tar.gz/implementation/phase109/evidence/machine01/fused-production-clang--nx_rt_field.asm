
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401fe0 <nx_rt_field>:
  401fe0:	push   %rax
  401fe1:	lea    0x51a0(%rip),%rdx        # 407188 <nx_context>
  401fe8:	cmp    %rdx,%rdi
  401feb:	jne    402037 <nx_rt_field+0x57>
  401fed:	testb  $0x1,0x518c(%rip)        # 407180 <nx_active>
  401ff4:	je     402037 <nx_rt_field+0x57>
  401ff6:	cmp    $0x1,%esi
  401ff9:	ja     40202b <nx_rt_field+0x4b>
  401ffb:	mov    0x51a7(%rip),%eax        # 4071a8 <nx_context+0x20>
  402001:	mov    $0x1,%edi
  402006:	mov    %esi,%ecx
  402008:	shl    %cl,%edi
  40200a:	bt     %esi,%eax
  40200d:	jae    40202b <nx_rt_field+0x4b>
  40200f:	not    %edi
  402011:	and    %edi,%eax
  402013:	mov    %eax,0x518f(%rip)        # 4071a8 <nx_context+0x20>
  402019:	mov    %esi,%ecx
  40201b:	mov    0x10(%rdx,%rcx,8),%rax
  402020:	movq   $0xffffffffffffffff,0x10(%rdx,%rcx,8)
  402029:	pop    %rcx
  40202a:	retq   
  40202b:	lea    0x20b1(%rip),%rdi        # 4040e3 <_IO_stdin_used+0xe3>
  402032:	callq  401130 <err_fail>
  402037:	lea    0x22d6(%rip),%rdi        # 404314 <_IO_stdin_used+0x314>
  40203e:	callq  401130 <err_fail>

Disassembly of section .fini:
