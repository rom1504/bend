
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/tree-bitonic/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000041293d <p111_FID_36_100_105_114_101_99_116_46_119_97_114_112_>:
  41293d:	push   %rbp
  41293e:	mov    %rsp,%rbp
  412941:	sub    $0x950,%rsp
  412948:	mov    %r12,-0x10(%rbp)
  41294c:	mov    %rdi,%rax
  41294f:	mov    %rax,%r12
  412952:	mov    0x28(%r12),%rdi
  412957:	mov    0x30(%r12),%rsi
  41295c:	mov    0x38(%r12),%rdx
  412961:	mov    %r12,%r10
  412964:	mov    %r10,0x38(%rsp)
  412969:	mov    %rdi,%r10
  41296c:	mov    %r10,0x40(%rsp)
  412971:	mov    %rsi,%r10
  412974:	mov    %r10,0x48(%rsp)
  412979:	mov    %rdx,%r10
  41297c:	mov    %r10,0x50(%rsp)
  412981:	movabs $0x0,%r10
  41298b:	mov    %r10,0x58(%rsp)
  412990:	movabs $0x0,%r10
  41299a:	mov    %r10,0x60(%rsp)
  41299f:	movabs $0x0,%r10
  4129a9:	mov    %r10,0x68(%rsp)
  4129ae:	mov    0x38(%rsp),%rdi
  4129b3:	mov    0x40(%rsp),%rsi
  4129b8:	mov    0x48(%rsp),%rdx
  4129bd:	mov    0x50(%rsp),%rcx
  4129c2:	mov    0x58(%rsp),%r8
  4129c7:	mov    0x60(%rsp),%r9
  4129cc:	mov    0x68(%rsp),%r10
  4129d1:	mov    %r10,(%rsp)
  4129d5:	xor    %eax,%eax
  4129d7:	callq  411e47 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_>
  4129dc:	mov    %rax,%rdi
  4129df:	lea    -0x880(%rbp),%r10
  4129e6:	mov    %rdi,%r11
  4129e9:	mov    %r11,(%r10)
  4129ec:	mov    %r12,%rdi
  4129ef:	lea    -0x880(%rbp),%rsi
  4129f6:	movabs $0x1,%rdx
  412a00:	mov    %edx,%edx
  412a02:	xor    %eax,%eax
  412a04:	callq  41c5c0 <p111_rt_return>
  412a09:	mov    %rax,%rdi
  412a0c:	mov    %rdi,%rax
  412a0f:	mov    -0x10(%rbp),%r12
  412a13:	mov    %rbp,%rsp
  412a16:	pop    %rbp
  412a17:	retq   

Disassembly of section .fini:
