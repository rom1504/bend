
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402e70 <nx_rt_fast_field>:
  402e70:	mov    %esi,%ecx
  402e72:	mov    $0xfffffffe,%eax
  402e77:	rol    %cl,%eax
  402e79:	add    $0x2,%rcx
  402e7d:	and    %eax,0x20(%rdi)
  402e80:	mov    (%rdi,%rcx,8),%rax
  402e84:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402e8c:	retq   

Disassembly of section .fini:
