    99b0:	test   %rsi,%rsi
    99b3:	je     9a24 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x74>
    99b5:	test   $0x1,%sil
    99b9:	jne    99c6 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x16>
    99bb:	mov    %rsi,%rax
    99be:	cmp    $0x1,%rsi
    99c2:	jne    99f0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x40>
    99c4:	jmp    9a24 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x74>
    99c6:	lea    -0x1(%rsi),%rax
    99ca:	lea    0x1(%rdx),%edi
    99cd:	xor    %ecx,%edx
    99cf:	lea    (%rcx,%rcx,2),%r8
    99d3:	inc    %r8
    99d6:	and    $0x7,%ecx
    99d9:	cmp    $0x3,%ecx
    99dc:	mov    %rdx,%rcx
    99df:	cmovb  %r8,%rcx
    99e3:	mov    %edi,%edx
    99e5:	cmp    $0x1,%rsi
    99e9:	je     9a24 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x74>
    99eb:	nopl   0x0(%rax,%rax,1)
    99f0:	mov    %edx,%esi
    99f2:	xor    %ecx,%esi
    99f4:	lea    (%rcx,%rcx,2),%rdi
    99f8:	inc    %rdi
    99fb:	and    $0x7,%ecx
    99fe:	cmp    $0x3,%ecx
    9a01:	cmovb  %rdi,%rsi
    9a05:	lea    0x1(%rdx),%ecx
    9a08:	xor    %esi,%ecx
    9a0a:	lea    (%rsi,%rsi,2),%rdi
    9a0e:	inc    %rdi
    9a11:	and    $0x7,%esi
    9a14:	cmp    $0x3,%esi
    9a17:	cmovb  %rdi,%rcx
    9a1b:	add    $0x2,%edx
    9a1e:	add    $0xfffffffffffffffe,%rax
    9a22:	jne    99f0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x40>
    9a24:	mov    %ecx,%esi
    9a26:	mov    -0x8(%r14),%eax
    9a2a:	add    $0xfffffffffffffff8,%r14
    9a2e:	lea    0x93bb(%rip),%rcx        # 12df0 <wl_tab>
    9a35:	mov    (%rcx,%rax,8),%rax
    9a39:	mov    $0x1,%edi
    9a3e:	jmpq   *%rax
