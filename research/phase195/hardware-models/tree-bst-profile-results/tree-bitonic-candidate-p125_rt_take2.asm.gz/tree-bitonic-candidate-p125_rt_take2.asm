0000000000421d30 <p125_rt_take2>:
  421d30:	push   r12
  421d32:	mov    rax,rdx
  421d35:	mov    rdx,rsi
  421d38:	push   rbx
  421d39:	shr    rdx,0x28
  421d3d:	movzx  edx,dx
  421d40:	sub    rsp,0x8
  421d44:	mov    rcx,QWORD PTR [rip+0x108f85]        # 52acd0 <p111_program_active>
  421d4b:	cmp    QWORD PTR [rcx+0x18],rdx
  421d4f:	ja     421d60 <p125_rt_take2+0x30>
  421d51:	lea    rdi,[rip+0x160b]        # 423363 <_IO_stdin_used+0x363>
  421d58:	call   418060 <err_fail>
  421d5d:	nop    DWORD PTR [rax]
  421d60:	mov    rbx,rdi
  421d63:	mov    rdi,QWORD PTR [rcx+0x80]
  421d6a:	cmp    BYTE PTR [rdi+rdx*1],0x2
  421d6e:	jne    421d51 <p125_rt_take2+0x21>
  421d70:	mov    rdx,rsi
  421d73:	shr    rdx,0x38
  421d77:	and    edx,0x7f
  421d7a:	cmp    rdx,0x2
  421d7e:	jne    421eab <p125_rt_take2+0x17b>
  421d84:	movabs rdx,0xffffffffff
  421d8e:	mov    rdi,QWORD PTR [rbx]
  421d91:	and    rdx,rsi
  421d94:	lea    r9,[rdx*8+0x0]
  421d9c:	lea    r8,[rdi+r9*1]
  421da0:	test   rsi,rsi
  421da3:	js     421e28 <p125_rt_take2+0xf8>
  421da9:	mov    rsi,QWORD PTR [r8]
  421dac:	mov    QWORD PTR [rax],rsi
  421daf:	mov    rsi,QWORD PTR [rdi+r9*1+0x8]
  421db4:	mov    QWORD PTR [rax+0x8],rsi
  421db8:	mov    rax,QWORD PTR [rcx+0x40]
  421dbc:	add    rax,0x7f
  421dc0:	and    rax,0xffffffffffffff80
  421dc4:	add    rax,0x3108200
  421dca:	cmp    rax,rdx
  421dcd:	jbe    421de0 <p125_rt_take2+0xb0>
  421dcf:	add    rsp,0x8
  421dd3:	mov    eax,0x2
  421dd8:	pop    rbx
  421dd9:	pop    r12
  421ddb:	ret    
  421ddc:	nop    DWORD PTR [rax+0x0]
  421de0:	mov    rsi,QWORD PTR [rbx+0x8]
  421de4:	mov    rdi,QWORD PTR [rbx]
  421de7:	mov    rax,QWORD PTR [rsi+0x8]
  421deb:	mov    QWORD PTR [rdi+rdx*8],rax
  421def:	mov    rax,QWORD PTR [rsi+0x108]
  421df6:	mov    QWORD PTR [rsi+0x8],rdx
  421dfa:	mov    edx,DWORD PTR [rip+0x108f84]        # 52ad84 <KEEP_WORDS>
  421e00:	add    rax,0x2
  421e04:	mov    QWORD PTR [rsi+0x108],rax
  421e0b:	cmp    rax,rdx
  421e0e:	jae    405067 <p125_rt_take2.cold+0x2f>
  421e14:	add    rsp,0x8
  421e18:	mov    eax,0x2
  421e1d:	pop    rbx
  421e1e:	pop    r12
  421e20:	ret    
  421e21:	nop    DWORD PTR [rax+0x0]
  421e28:	mov    r9,QWORD PTR [rbx+0x8]
  421e2c:	mov    ecx,DWORD PTR [r8+0x4]
  421e30:	mov    r10d,DWORD PTR [r8]
  421e33:	shl    rcx,0x20
  421e37:	or     rcx,r10
  421e3a:	mov    r12,rcx
  421e3d:	and    ecx,0xffffff
  421e43:	shr    r12,0x18
  421e47:	lea    r10,[r12*8+0x0]
  421e4f:	lea    r11,[rdi+r10*1]
  421e53:	lea    r10,[r10+rdi*1+0x8]
  421e58:	cmp    rcx,0x1
  421e5c:	jne    405038 <p125_rt_take2.cold>
  421e62:	mov    ecx,DWORD PTR [r8]
  421e65:	mov    rcx,QWORD PTR [r11]
  421e68:	mov    QWORD PTR [rax],rcx
  421e6b:	mov    rcx,QWORD PTR [r10]
  421e6e:	mov    QWORD PTR [rax+0x8],rcx
  421e72:	mov    rax,QWORD PTR [r9]
  421e75:	mov    QWORD PTR [r8],rax
  421e78:	mov    rax,QWORD PTR [r9+0x100]
  421e7f:	mov    QWORD PTR [r9],rdx
  421e82:	mov    edx,DWORD PTR [rip+0x108efc]        # 52ad84 <KEEP_WORDS>
  421e88:	add    rax,0x1
  421e8c:	mov    QWORD PTR [r9+0x100],rax
  421e93:	cmp    rax,rdx
  421e96:	jae    405076 <p125_rt_take2.cold+0x3e>
  421e9c:	mov    rcx,QWORD PTR [rip+0x108e2d]        # 52acd0 <p111_program_active>
  421ea3:	mov    rdx,r12
  421ea6:	jmp    421db8 <p125_rt_take2+0x88>
  421eab:	lea    rdi,[rip+0x206e]        # 423f20 <_IO_stdin_used+0xf20>
  421eb2:	call   418060 <err_fail>
  421eb7:	nop    WORD PTR [rax+rax*1+0x0]

