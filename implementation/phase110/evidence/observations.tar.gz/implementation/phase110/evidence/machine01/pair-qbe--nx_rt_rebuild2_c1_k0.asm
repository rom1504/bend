
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403360 <nx_rt_rebuild2_c1_k0>:
  403360:	push   %r13
  403362:	mov    %rsi,%r10
  403365:	mov    %rdx,%r8
  403368:	movabs $0xffffffffff,%r9
  403372:	push   %r12
  403374:	and    %r10,%r9
  403377:	push   %rbp
  403378:	lea    0x0(,%r9,8),%rax
  403380:	push   %rbx
  403381:	mov    %rdi,%rbx
  403384:	sub    $0x28,%rsp
  403388:	mov    (%rdi),%rdi
  40338b:	mov    0x8(%rbx),%rsi
  40338f:	lea    (%rdi,%rax,1),%rdx
  403393:	test   %r10,%r10
  403396:	js     403400 <nx_rt_rebuild2_c1_k0+0xa0>
  403398:	mov    (%rdx),%r12
  40339b:	mov    0x8(%rdi,%rax,1),%rbp
  4033a0:	cmp    $0x310817f,%r9
  4033a7:	jbe    4033d8 <nx_rt_rebuild2_c1_k0+0x78>
  4033a9:	mov    %rbp,0x10(%rbx)
  4033ad:	mov    %r12,%rcx
  4033b0:	mov    $0x1,%edx
  4033b5:	movq   $0xffffffffffffffff,0x18(%rbx)
  4033bd:	movl   $0x1,0x20(%rbx)
  4033c4:	add    $0x28,%rsp
  4033c8:	pop    %rbx
  4033c9:	pop    %rbp
  4033ca:	pop    %r12
  4033cc:	pop    %r13
  4033ce:	jmpq   401fb0 <nx_construct2>
  4033d3:	nopl   0x0(%rax,%rax,1)
  4033d8:	mov    0x8(%rsi),%r9
  4033dc:	test   %r9,%r9
  4033df:	je     4016c4 <nx_rt_rebuild2_c1_k0.cold>
  4033e5:	mov    (%rdi,%r9,8),%rax
  4033e9:	subq   $0x2,0x108(%rsi)
  4033f1:	mov    %rax,0x8(%rsi)
  4033f5:	jmp    4033a9 <nx_rt_rebuild2_c1_k0+0x49>
  4033f7:	nopw   0x0(%rax,%rax,1)
  403400:	mov    0x4(%rdx),%eax
  403403:	mov    (%rdx),%ecx
  403405:	shl    $0x20,%rax
  403409:	or     %rcx,%rax
  40340c:	mov    %rax,%r13
  40340f:	and    $0xffffff,%eax
  403414:	shr    $0x18,%r13
  403418:	lea    0x0(,%r13,8),%r11
  403420:	lea    (%rdi,%r11,1),%rbp
  403424:	lea    0x8(%rdi,%r11,1),%r11
  403429:	cmp    $0x1,%rax
  40342d:	jne    40170a <nx_rt_rebuild2_c1_k0.cold+0x46>
  403433:	mov    (%rdx),%eax
  403435:	mov    (%rsi),%rax
  403438:	mov    0x0(%rbp),%r12
  40343c:	mov    (%r11),%rbp
  40343f:	mov    %rax,(%rdx)
  403442:	mov    0x100(%rsi),%rax
  403449:	mov    0x3dd89(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40344f:	mov    %r9,(%rsi)
  403452:	add    $0x1,%rax
  403456:	mov    %rax,0x100(%rsi)
  40345d:	cmp    %rdx,%rax
  403460:	jae    4016f4 <nx_rt_rebuild2_c1_k0.cold+0x30>
  403466:	mov    %r13,%r9
  403469:	jmpq   4033a0 <nx_rt_rebuild2_c1_k0+0x40>

Disassembly of section .fini:
