
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d50 <nx_rt_fast_take2>:
  402d50:	movabs $0xffffffffff,%rax
  402d5a:	push   %r12
  402d5c:	and    %rsi,%rax
  402d5f:	push   %rbp
  402d60:	push   %rbx
  402d61:	mov    %rdi,%rbx
  402d64:	mov    (%rdi),%rdi
  402d67:	lea    0x0(,%rax,8),%rcx
  402d6f:	mov    0x8(%rbx),%rbp
  402d73:	lea    (%rdi,%rcx,1),%rdx
  402d77:	test   %rsi,%rsi
  402d7a:	js     402de8 <nx_rt_fast_take2+0x98>
  402d7c:	mov    (%rdx),%rdx
  402d7f:	mov    %rdx,0x10(%rbx)
  402d83:	mov    0x8(%rdi,%rcx,1),%rdx
  402d88:	mov    %rdx,0x18(%rbx)
  402d8c:	cmp    $0x310817f,%rax
  402d92:	ja     402da8 <nx_rt_fast_take2+0x58>
  402d94:	movl   $0x3,0x20(%rbx)
  402d9b:	xor    %eax,%eax
  402d9d:	pop    %rbx
  402d9e:	pop    %rbp
  402d9f:	pop    %r12
  402da1:	retq   
  402da2:	nopw   0x0(%rax,%rax,1)
  402da8:	mov    0x8(%rbp),%rdx
  402dac:	mov    %rdx,(%rdi,%rax,8)
  402db0:	mov    0x3e422(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402db6:	mov    %rax,0x8(%rbp)
  402dba:	mov    0x108(%rbp),%rax
  402dc1:	add    $0x2,%rax
  402dc5:	mov    %rax,0x108(%rbp)
  402dcc:	cmp    %rdx,%rax
  402dcf:	jae    4015fe <nx_rt_fast_take2.cold>
  402dd5:	movl   $0x3,0x20(%rbx)
  402ddc:	xor    %eax,%eax
  402dde:	pop    %rbx
  402ddf:	pop    %rbp
  402de0:	pop    %r12
  402de2:	retq   
  402de3:	nopl   0x0(%rax,%rax,1)
  402de8:	mov    0x4(%rdx),%ecx
  402deb:	mov    (%rdx),%r8d
  402dee:	shl    $0x20,%rcx
  402df2:	or     %r8,%rcx
  402df5:	mov    %rcx,%r12
  402df8:	and    $0xffffff,%ecx
  402dfe:	shr    $0x18,%r12
  402e02:	lea    0x0(,%r12,8),%r8
  402e0a:	lea    (%rdi,%r8,1),%r9
  402e0e:	lea    0x8(%rdi,%r8,1),%r8
  402e13:	cmp    $0x1,%rcx
  402e17:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  402e1d:	mov    (%rdx),%ecx
  402e1f:	mov    (%r9),%rcx
  402e22:	mov    %rcx,0x10(%rbx)
  402e26:	mov    (%r8),%rcx
  402e29:	mov    %rcx,0x18(%rbx)
  402e2d:	mov    0x0(%rbp),%rcx
  402e31:	mov    %rcx,(%rdx)
  402e34:	mov    0x3e39e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e3a:	mov    %rax,0x0(%rbp)
  402e3e:	mov    0x100(%rbp),%rax
  402e45:	add    $0x1,%rax
  402e49:	mov    %rax,0x100(%rbp)
  402e50:	cmp    %rdx,%rax
  402e53:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  402e59:	mov    %r12,%rax
  402e5c:	jmpq   402d8c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
