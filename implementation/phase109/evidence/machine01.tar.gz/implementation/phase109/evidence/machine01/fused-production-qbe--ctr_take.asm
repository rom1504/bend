
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402390 <ctr_take>:
  402390:	endbr64 
  402394:	push   %rbp
  402395:	mov    %rsp,%rbp
  402398:	sub    $0x18,%rsp
  40239c:	push   %rbx
  40239d:	push   %r12
  40239f:	push   %r13
  4023a1:	push   %r14
  4023a3:	push   %r15
  4023a5:	mov    %r8,%r15
  4023a8:	mov    %ecx,%r14d
  4023ab:	mov    %rdx,%r12
  4023ae:	mov    %rdi,-0x10(%rbp)
  4023b2:	mov    %rsi,-0x8(%rbp)
  4023b6:	mov    -0x10(%rbp),%rbx
  4023ba:	mov    %r12,%rdi
  4023bd:	callq  401b10 <term_rfc>
  4023c2:	movzbl %al,%eax
  4023c5:	cmp    $0x0,%eax
  4023c8:	jne    402423 <ctr_take+0x93>
  4023ca:	mov    %r12,%r13
  4023cd:	mov    $0x0,%r12d
  4023d3:	data16 nopw %cs:0x0(%rax,%rax,1)
  4023de:	xchg   %ax,%ax
  4023e0:	cmp    %r14d,%r12d
  4023e3:	jae    402413 <ctr_take+0x83>
  4023e5:	mov    %r13,%rdi
  4023e8:	callq  401b50 <term_loc>
  4023ed:	mov    %r15,%r8
  4023f0:	mov    %r14d,%ecx
  4023f3:	mov    %r13,%rdx
  4023f6:	mov    %r12d,%esi
  4023f9:	add    %rsi,%rax
  4023fc:	mov    (%rbx,%rax,8),%rax
  402400:	mov    %rax,(%r8,%rsi,8)
  402404:	add    $0x1,%r12d
  402408:	mov    %r8,%r15
  40240b:	mov    %ecx,%r14d
  40240e:	mov    %rdx,%r13
  402411:	jmp    4023e0 <ctr_take+0x50>
  402413:	mov    %r13,%r12
  402416:	mov    %r12,%rdi
  402419:	callq  401b50 <term_loc>
  40241e:	jmpq   4024d2 <ctr_take+0x142>
  402423:	mov    %r12,%rdi
  402426:	callq  401b50 <term_loc>
  40242b:	mov    %r12,%rdx
  40242e:	mov    %rax,%r13
  402431:	mov    %rdx,%r12
  402434:	mov    %r13,%rdx
  402437:	mov    -0x10(%rbp),%rdi
  40243b:	mov    -0x8(%rbp),%rsi
  40243f:	callq  401cc0 <rfc_view>
  402444:	mov    %r14d,%r8d
  402447:	mov    %r13,%rcx
  40244a:	mov    %r12,%rdx
  40244d:	mov    %rax,%r12
  402450:	mov    %rcx,%r13
  402453:	mov    %r12,%rcx
  402456:	shr    $0x18,%rcx
  40245a:	mov    %rcx,%rsi
  40245d:	mov    %r8d,%ecx
  402460:	mov    %r15,%r8
  402463:	mov    $0x0,%eax
  402468:	nopl   0x0(%rax,%rax,1)
  402470:	cmp    %ecx,%eax
  402472:	jae    40248a <ctr_take+0xfa>
  402474:	mov    %eax,%r9d
  402477:	mov    %rsi,%rdi
  40247a:	add    %r9,%rdi
  40247d:	mov    (%rbx,%rdi,8),%rdi
  402481:	mov    %rdi,(%r8,%r9,8)
  402485:	add    $0x1,%eax
  402488:	jmp    402470 <ctr_take+0xe0>
  40248a:	mov    %r13,%rbx
  40248d:	mov    %ecx,%r8d
  402490:	mov    %rsi,%rcx
  402493:	mov    %r12,%rax
  402496:	and    $0xffffff,%rax
  40249c:	cmp    $0x1,%rax
  4024a0:	je     4024b6 <ctr_take+0x126>
  4024a2:	mov    -0x10(%rbp),%rdi
  4024a6:	mov    -0x8(%rbp),%rsi
  4024aa:	callq  4022c0 <span_fade>
  4024af:	mov    $0x0,%eax
  4024b4:	jmp    4024d2 <ctr_take+0x142>
  4024b6:	mov    %rbx,%rcx
  4024b9:	mov    $0x0,%edx
  4024be:	mov    -0x10(%rbp),%rdi
  4024c2:	mov    -0x8(%rbp),%rsi
  4024c6:	callq  401a20 <heap_free>
  4024cb:	mov    %r12,%rax
  4024ce:	shr    $0x18,%rax
  4024d2:	pop    %r15
  4024d4:	pop    %r14
  4024d6:	pop    %r13
  4024d8:	pop    %r12
  4024da:	pop    %rbx
  4024db:	leaveq 
  4024dc:	retq   

Disassembly of section .fini:
