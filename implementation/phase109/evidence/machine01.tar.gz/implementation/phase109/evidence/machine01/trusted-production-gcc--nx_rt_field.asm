
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004027b0 <nx_rt_field>:
  4027b0:	sub    $0x8,%rsp
  4027b4:	cmpb   $0x0,0x59c5(%rip)        # 408180 <nx_active>
  4027bb:	je     4027c9 <nx_rt_field+0x19>
  4027bd:	lea    0x59dc(%rip),%rdx        # 4081a0 <nx_context>
  4027c4:	cmp    %rdx,%rdi
  4027c7:	je     4027d8 <nx_rt_field+0x28>
  4027c9:	lea    0x2863(%rip),%rdi        # 405033 <_IO_stdin_used+0x33>
  4027d0:	callq  401ac0 <err_fail>
  4027d5:	nopl   (%rax)
  4027d8:	mov    %esi,%ecx
  4027da:	cmp    $0x1,%ecx
  4027dd:	jbe    4027f0 <nx_rt_field+0x40>
  4027df:	lea    0x2b62(%rip),%rdi        # 405348 <_IO_stdin_used+0x348>
  4027e6:	callq  401ac0 <err_fail>
  4027eb:	nopl   0x0(%rax,%rax,1)
  4027f0:	mov    $0x1,%eax
  4027f5:	mov    0x59c5(%rip),%esi        # 4081c0 <nx_context+0x20>
  4027fb:	shl    %cl,%eax
  4027fd:	test   %eax,%esi
  4027ff:	je     4027df <nx_rt_field+0x2f>
  402801:	not    %eax
  402803:	add    $0x2,%rcx
  402807:	and    %esi,%eax
  402809:	mov    %eax,0x59b1(%rip)        # 4081c0 <nx_context+0x20>
  40280f:	mov    (%rdx,%rcx,8),%rax
  402813:	movq   $0xffffffffffffffff,(%rdx,%rcx,8)
  40281b:	add    $0x8,%rsp
  40281f:	retq   

Disassembly of section .fini:
