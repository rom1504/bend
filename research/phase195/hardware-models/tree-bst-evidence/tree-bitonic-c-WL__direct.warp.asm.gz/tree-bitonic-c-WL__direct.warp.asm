000000000000ce60 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_>:
    ce60:	push   rbp
    ce61:	sub    rsp,0x10
    ce65:	mov    rbx,rdx
    ce68:	mov    rbp,rsi
    ce6b:	movabs rax,0xffffffff80
    ce75:	mov    r8d,ecx
    ce78:	lea    r9,[rax+0x7f]
    ce7c:	mov    QWORD PTR [rsp],r14
    ce80:	mov    rcx,rbp
    ce83:	shr    rcx,0x28
    ce87:	movzx  ecx,cx
    ce8a:	cmp    ecx,0xa5
    ce90:	jne    d174 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x314>
    ce96:	mov    rdx,rbp
    ce99:	and    rdx,r9
    ce9c:	test   rbp,rbp
    ce9f:	js     cec0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x60>
    cea1:	mov    rbp,QWORD PTR [r12+rdx*8]
    cea5:	mov    r11,QWORD PTR [r12+rdx*8+0x8]
    ceaa:	mov    rcx,rdx
    cead:	cmp    rcx,0x3108180
    ceb4:	jae    cf32 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd2>
    ceb6:	jmp    cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    cebb:	nop    DWORD PTR [rax+rax*1+0x0]
    cec0:	mov    ecx,DWORD PTR [r12+rdx*8+0x4]
    cec5:	mov    esi,DWORD PTR [r12+rdx*8]
    cec9:	mov    edi,esi
    cecb:	and    edi,0xffffff
    ced1:	cmp    edi,0x1
    ced4:	jne    d0ad <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x24d>
    ceda:	mov    edi,DWORD PTR [r12+rdx*8]
    cede:	shl    rcx,0x20
    cee2:	or     rcx,rsi
    cee5:	shr    rcx,0x18
    cee9:	mov    rbp,QWORD PTR [r12+rcx*8]
    ceed:	mov    r11,QWORD PTR [r12+rcx*8+0x8]
    cef2:	mov    rsi,QWORD PTR [r13+0x0]
    cef6:	mov    QWORD PTR [r12+rdx*8],rsi
    cefa:	mov    QWORD PTR [r13+0x0],rdx
    cefe:	mov    rdx,QWORD PTR [r13+0x100]
    cf05:	inc    rdx
    cf08:	mov    QWORD PTR [r13+0x100],rdx
    cf0f:	cmp    BYTE PTR [rip+0x10c97a],0x1        # 119890 <KEEP_WORDS>
    cf16:	jne    d12d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2cd>
    cf1c:	cmp    rdx,0x8000
    cf23:	jae    d12d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2cd>
    cf29:	cmp    rcx,0x3108180
    cf30:	jb     cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    cf32:	mov    rdx,QWORD PTR [r13+0x8]
    cf36:	mov    QWORD PTR [r12+rcx*8],rdx
    cf3a:	mov    QWORD PTR [r13+0x8],rcx
    cf3e:	mov    rcx,QWORD PTR [r13+0x108]
    cf45:	add    rcx,0x2
    cf49:	mov    QWORD PTR [r13+0x108],rcx
    cf50:	cmp    BYTE PTR [rip+0x10c939],0x1        # 119890 <KEEP_WORDS>
    cf57:	jne    d07d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x21d>
    cf5d:	cmp    rcx,0x8000
    cf64:	jae    d07d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x21d>
    cf6a:	mov    rcx,rbx
    cf6d:	shr    rcx,0x28
    cf71:	movzx  ecx,cx
    cf74:	cmp    ecx,0xa5
    cf7a:	jne    d1cb <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x36b>
    cf80:	mov    rdx,rbx
    cf83:	and    rdx,r9
    cf86:	test   rbx,rbx
    cf89:	js     cfb0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x150>
    cf8b:	mov    rbx,QWORD PTR [r12+rdx*8]
    cf8f:	mov    r10,QWORD PTR [r12+rdx*8+0x8]
    cf94:	mov    rcx,rdx
    cf97:	cmp    rcx,0x3108180
    cf9e:	jae    d028 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1c8>
    cfa4:	jmp    d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    cfa9:	nop    DWORD PTR [rax+0x0]
    cfb0:	mov    rax,r11
    cfb3:	mov    ecx,DWORD PTR [r12+rdx*8+0x4]
    cfb8:	mov    esi,DWORD PTR [r12+rdx*8]
    cfbc:	mov    edi,esi
    cfbe:	and    edi,0xffffff
    cfc4:	cmp    edi,0x1
    cfc7:	jne    d0ed <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x28d>
    cfcd:	mov    edi,DWORD PTR [r12+rdx*8]
    cfd1:	shl    rcx,0x20
    cfd5:	or     rcx,rsi
    cfd8:	shr    rcx,0x18
    cfdc:	mov    rbx,QWORD PTR [r12+rcx*8]
    cfe0:	mov    r10,QWORD PTR [r12+rcx*8+0x8]
    cfe5:	mov    rsi,QWORD PTR [r13+0x0]
    cfe9:	mov    QWORD PTR [r12+rdx*8],rsi
    cfed:	mov    QWORD PTR [r13+0x0],rdx
    cff1:	mov    rdx,QWORD PTR [r13+0x100]
    cff8:	inc    rdx
    cffb:	mov    QWORD PTR [r13+0x100],rdx
    d002:	cmp    BYTE PTR [rip+0x10c887],0x1        # 119890 <KEEP_WORDS>
    d009:	jne    d152 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2f2>
    d00f:	cmp    rdx,0x8000
    d016:	jae    d152 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2f2>
    d01c:	mov    r11,rax
    d01f:	cmp    rcx,0x3108180
    d026:	jb     d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    d028:	mov    rax,QWORD PTR [r13+0x8]
    d02c:	mov    QWORD PTR [r12+rcx*8],rax
    d030:	mov    QWORD PTR [r13+0x8],rcx
    d034:	mov    rcx,QWORD PTR [r13+0x108]
    d03b:	add    rcx,0x2
    d03f:	mov    QWORD PTR [r13+0x108],rcx
    d046:	cmp    BYTE PTR [rip+0x10c843],0x1        # 119890 <KEEP_WORDS>
    d04d:	jne    d098 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x238>
    d04f:	cmp    rcx,0x8000
    d056:	jae    d098 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x238>
    d058:	test   r15d,r15d
    d05b:	je     d218 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x3b8>
    d061:	mov    QWORD PTR [r14],r11
    d064:	mov    QWORD PTR [r14+0x8],r8
    d068:	mov    QWORD PTR [r14+0x10],r10
    d06c:	mov    QWORD PTR [r14+0x18],0x74
    d074:	add    r14,0x20
    d078:	jmp    ce80 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x20>
    d07d:	mov    rdi,r12
    d080:	mov    rsi,r13
    d083:	mov    edx,0x1
    d088:	mov    rax,r11
    d08b:	call   15881 <heap_hand>
    d090:	mov    r11,rax
    d093:	jmp    cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    d098:	mov    rdi,r12
    d09b:	mov    rsi,r13
    d09e:	mov    edx,0x1
    d0a3:	mov    rax,r11
    d0a6:	call   15881 <heap_hand>
    d0ab:	jmp    d125 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2c5>
    d0ad:	shl    rcx,0x20
    d0b1:	or     rcx,rsi
    d0b4:	shr    rcx,0x18
    d0b8:	mov    rax,QWORD PTR [r12+rcx*8]
    d0bc:	mov    QWORD PTR [rsp+0x8],rax
    d0c1:	mov    r10,QWORD PTR [r12+rcx*8+0x8]
    d0c6:	mov    rdi,r12
    d0c9:	mov    rsi,r13
    d0cc:	mov    rdx,rbp
    d0cf:	mov    rax,r8
    d0d2:	mov    r8d,0x2
    d0d8:	call   15912 <span_fade>
    d0dd:	mov    r11,r10
    d0e0:	mov    r8,rax
    d0e3:	mov    rbp,QWORD PTR [rsp+0x8]
    d0e8:	jmp    cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    d0ed:	shl    rcx,0x20
    d0f1:	or     rcx,rsi
    d0f4:	shr    rcx,0x18
    d0f8:	mov    rdx,QWORD PTR [r12+rcx*8]
    d0fc:	mov    QWORD PTR [rsp+0x8],rdx
    d101:	mov    r10,QWORD PTR [r12+rcx*8+0x8]
    d106:	mov    rdi,r12
    d109:	mov    rsi,r13
    d10c:	mov    rdx,rbx
    d10f:	mov    rbx,r8
    d112:	mov    r8d,0x2
    d118:	call   15912 <span_fade>
    d11d:	mov    r8,rbx
    d120:	mov    rbx,QWORD PTR [rsp+0x8]
    d125:	mov    r11,rax
    d128:	jmp    d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    d12d:	mov    rdi,r12
    d130:	mov    rsi,r13
    d133:	xor    edx,edx
    d135:	mov    rax,r11
    d138:	call   15881 <heap_hand>
    d13d:	mov    r11,rax
    d140:	cmp    rcx,0x3108180
    d147:	jae    cf32 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd2>
    d14d:	jmp    cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    d152:	mov    rdi,r12
    d155:	mov    rsi,r13
    d158:	xor    edx,edx
    d15a:	call   15881 <heap_hand>
    d15f:	mov    r11,rax
    d162:	cmp    rcx,0x3108180
    d169:	jae    d028 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1c8>
    d16f:	jmp    d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    d174:	cmp    ecx,0xa4
    d17a:	jne    d941 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xae1>
    d180:	movabs rax,0x7f00000000000000
    d18a:	mov    rcx,rbp
    d18d:	and    rcx,rax
    d190:	movabs r10,0x100000000000000
    d19a:	cmp    rcx,r10
    d19d:	je     d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d1a3:	mov    rdx,rbp
    d1a6:	and    rdx,r9
    d1a9:	test   rbp,rbp
    d1ac:	js     d310 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b0>
    d1b2:	mov    ebp,DWORD PTR [r12+rdx*8]
    d1b6:	mov    rcx,rdx
    d1b9:	cmp    rcx,0x3108180
    d1c0:	jae    d37d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x51d>
    d1c6:	jmp    d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d1cb:	cmp    ecx,0xa4
    d1d1:	jne    d9f9 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xb99>
    d1d7:	movabs rax,0x7f00000000000000
    d1e1:	and    rax,rbx
    d1e4:	movabs rcx,0x100000000000000
    d1ee:	cmp    rax,rcx
    d1f1:	je     d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d1f7:	and    r9,rbx
    d1fa:	test   rbx,rbx
    d1fd:	js     d549 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6e9>
    d203:	mov    rcx,r9
    d206:	cmp    rcx,0x3108180
    d20d:	jae    d5b1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x751>
    d213:	jmp    d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d218:	mov    rax,QWORD PTR [rsp]
    d21c:	mov    r14,QWORD PTR [rax-0x18]
    d220:	mov    r9,QWORD PTR [rax-0x10]
    d224:	mov    rcx,QWORD PTR [r13+0x10]
    d228:	mov    r15,r8
    d22b:	test   rcx,rcx
    d22e:	je     d744 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8e4>
    d234:	mov    rax,QWORD PTR [r12+rcx*8]
    d238:	mov    QWORD PTR [r13+0x10],rax
    d23c:	add    QWORD PTR [r13+0x110],0xfffffffffffffffc
    d244:	lea    r8,[r12+rcx*8]
    d248:	pcmpeqd xmm0,xmm0
    d24c:	movdqu XMMWORD PTR [r12+rcx*8],xmm0
    d252:	mov    QWORD PTR [r12+rcx*8+0x10],r14
    d257:	shl    r9,0x20
    d25b:	or     r9,0x2
    d25f:	mov    QWORD PTR [r12+rcx*8+0x18],r9
    d264:	movabs rax,0x500730000000000
    d26e:	or     rax,rcx
    d271:	mov    rcx,QWORD PTR [r13+0x18]
    d275:	test   rcx,rcx
    d278:	je     d762 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x902>
    d27e:	mov    rdx,QWORD PTR [r12+rcx*8]
    d282:	mov    QWORD PTR [r13+0x18],rdx
    d286:	add    QWORD PTR [r13+0x118],0xfffffffffffffff8
    d28e:	mov    QWORD PTR [r12+rcx*8+0x18],rax
    d293:	mov    QWORD PTR [r12+rcx*8+0x20],0x0
    d29c:	mov    QWORD PTR [r12+rcx*8],rbp
    d2a0:	mov    QWORD PTR [r12+rcx*8+0x8],r15
    d2a5:	mov    QWORD PTR [r12+rcx*8+0x10],rbx
    d2aa:	movabs rdx,0x500760000000000
    d2b4:	or     rdx,rcx
    d2b7:	mov    QWORD PTR [r8],rdx
    d2ba:	mov    rcx,QWORD PTR [r13+0x18]
    d2be:	test   rcx,rcx
    d2c1:	je     d786 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x926>
    d2c7:	mov    rdx,QWORD PTR [r12+rcx*8]
    d2cb:	mov    QWORD PTR [r13+0x18],rdx
    d2cf:	add    QWORD PTR [r13+0x118],0xfffffffffffffff8
    d2d7:	mov    QWORD PTR [r12+rcx*8+0x18],rax
    d2dc:	movabs rdx,0x100000000
    d2e6:	mov    QWORD PTR [r12+rcx*8+0x20],rdx
    d2eb:	mov    QWORD PTR [r12+rcx*8],r11
    d2ef:	mov    QWORD PTR [r12+rcx*8+0x8],r15
    d2f4:	mov    QWORD PTR [r12+rcx*8+0x10],r10
    d2f9:	movabs rdx,0x500770000000000
    d303:	or     rdx,rcx
    d306:	mov    QWORD PTR [r8+0x8],rdx
    d30a:	add    rsp,0x10
    d30e:	pop    rbp
    d30f:	ret    
    d310:	mov    ecx,DWORD PTR [r12+rdx*8+0x4]
    d315:	mov    esi,DWORD PTR [r12+rdx*8]
    d319:	mov    edi,esi
    d31b:	and    edi,0xffffff
    d321:	cmp    edi,0x1
    d324:	jne    d7e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x986>
    d32a:	mov    edi,DWORD PTR [r12+rdx*8]
    d32e:	shl    rcx,0x20
    d332:	or     rcx,rsi
    d335:	shr    rcx,0x18
    d339:	mov    ebp,DWORD PTR [r12+rcx*8]
    d33d:	mov    rsi,QWORD PTR [r13+0x0]
    d341:	mov    QWORD PTR [r12+rdx*8],rsi
    d345:	mov    QWORD PTR [r13+0x0],rdx
    d349:	mov    rdx,QWORD PTR [r13+0x100]
    d350:	inc    rdx
    d353:	mov    QWORD PTR [r13+0x100],rdx
    d35a:	cmp    BYTE PTR [rip+0x10c52f],0x1        # 119890 <KEEP_WORDS>
    d361:	jne    d876 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa16>
    d367:	cmp    rdx,0x8000
    d36e:	jae    d876 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa16>
    d374:	cmp    rcx,0x3108180
    d37b:	jb     d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d37d:	mov    rdx,QWORD PTR [r13+0x0]
    d381:	mov    QWORD PTR [r12+rcx*8],rdx
    d385:	mov    QWORD PTR [r13+0x0],rcx
    d389:	mov    rcx,QWORD PTR [r13+0x100]
    d390:	inc    rcx
    d393:	mov    QWORD PTR [r13+0x100],rcx
    d39a:	cmp    BYTE PTR [rip+0x10c4ef],0x1        # 119890 <KEEP_WORDS>
    d3a1:	jne    d7aa <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x94a>
    d3a7:	cmp    rcx,0x8000
    d3ae:	jae    d7aa <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x94a>
    d3b4:	mov    rcx,rbx
    d3b7:	shr    rcx,0x28
    d3bb:	movzx  ecx,cx
    d3be:	cmp    ecx,0xa5
    d3c4:	je     d403 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x5a3>
    d3c6:	cmp    ecx,0xa4
    d3cc:	jne    db84 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd24>
    d3d2:	and    rax,rbx
    d3d5:	cmp    rax,r10
    d3d8:	je     d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d3de:	and    r9,rbx
    d3e1:	test   rbx,rbx
    d3e4:	js     d691 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x831>
    d3ea:	mov    ebx,DWORD PTR [r12+r9*8]
    d3ee:	mov    rcx,r9
    d3f1:	cmp    rcx,0x3108180
    d3f8:	jae    d6fd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x89d>
    d3fe:	jmp    d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d403:	and    r9,rbx
    d406:	test   rbx,rbx
    d409:	js     d425 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x5c5>
    d40b:	mov    rdx,QWORD PTR [r12+r9*8]
    d40f:	mov    rbp,QWORD PTR [r12+r9*8+0x8]
    d414:	mov    rcx,r9
    d417:	cmp    rcx,0x3108180
    d41e:	jae    d496 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x636>
    d420:	jmp    d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d425:	mov    ecx,DWORD PTR [r12+r9*8+0x4]
    d42a:	mov    eax,DWORD PTR [r12+r9*8]
    d42e:	mov    edx,eax
    d430:	and    edx,0xffffff
    d436:	cmp    edx,0x1
    d439:	jne    d81c <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9bc>
    d43f:	mov    edx,DWORD PTR [r12+r9*8]
    d443:	shl    rcx,0x20
    d447:	or     rcx,rax
    d44a:	shr    rcx,0x18
    d44e:	mov    rdx,QWORD PTR [r12+rcx*8]
    d452:	mov    rbp,QWORD PTR [r12+rcx*8+0x8]
    d457:	mov    rax,QWORD PTR [r13+0x0]
    d45b:	mov    QWORD PTR [r12+r9*8],rax
    d45f:	mov    QWORD PTR [r13+0x0],r9
    d463:	mov    rax,QWORD PTR [r13+0x100]
    d46a:	inc    rax
    d46d:	mov    QWORD PTR [r13+0x100],rax
    d474:	cmp    BYTE PTR [rip+0x10c415],0x1        # 119890 <KEEP_WORDS>
    d47b:	jne    d895 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa35>
    d481:	cmp    rax,0x8000
    d487:	jae    d895 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa35>
    d48d:	cmp    rcx,0x3108180
    d494:	jb     d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d496:	mov    rax,QWORD PTR [r13+0x8]
    d49a:	mov    QWORD PTR [r12+rcx*8],rax
    d49e:	mov    QWORD PTR [r13+0x8],rcx
    d4a2:	mov    rax,QWORD PTR [r13+0x108]
    d4a9:	add    rax,0x2
    d4ad:	mov    QWORD PTR [r13+0x108],rax
    d4b4:	cmp    BYTE PTR [rip+0x10c3d5],0x1        # 119890 <KEEP_WORDS>
    d4bb:	jne    d7bc <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x95c>
    d4c1:	cmp    rax,0x8000
    d4c7:	jae    d7bc <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x95c>
    d4cd:	movabs rbx,0x7e00000000000000
    d4d7:	test   rdx,rbx
    d4da:	sete   al
    d4dd:	cmp    rdx,0xffffffffffffffff
    d4e1:	sete   cl
    d4e4:	or     cl,al
    d4e6:	mov    rax,rdx
    d4e9:	movabs rsi,0xffffffff80
    d4f3:	and    rax,rsi
    d4f6:	cmp    rax,0x3108180
    d4fc:	setb   al
    d4ff:	or     al,cl
    d501:	jne    d50e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6ae>
    d503:	mov    rdi,r12
    d506:	mov    rsi,r13
    d509:	call   7810 <term_drop>
    d50e:	test   rbp,rbx
    d511:	sete   al
    d514:	cmp    rbp,0xffffffffffffffff
    d518:	sete   cl
    d51b:	or     cl,al
    d51d:	movabs rax,0xffffffff80
    d527:	and    rax,rbp
    d52a:	cmp    rax,0x3108180
    d530:	setb   al
    d533:	or     al,cl
    d535:	jne    d668 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x808>
    d53b:	mov    rdi,r12
    d53e:	mov    rsi,r13
    d541:	mov    rdx,rbp
    d544:	jmp    d663 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x803>
    d549:	mov    ecx,DWORD PTR [r12+r9*8+0x4]
    d54e:	mov    eax,DWORD PTR [r12+r9*8]
    d552:	mov    edx,eax
    d554:	and    edx,0xffffff
    d55a:	cmp    edx,0x1
    d55d:	jne    d84c <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9ec>
    d563:	mov    edx,DWORD PTR [r12+r9*8]
    d567:	shl    rcx,0x20
    d56b:	or     rcx,rax
    d56e:	shr    rcx,0x18
    d572:	mov    rax,QWORD PTR [r13+0x0]
    d576:	mov    QWORD PTR [r12+r9*8],rax
    d57a:	mov    QWORD PTR [r13+0x0],r9
    d57e:	mov    rax,QWORD PTR [r13+0x100]
    d585:	inc    rax
    d588:	mov    QWORD PTR [r13+0x100],rax
    d58f:	cmp    BYTE PTR [rip+0x10c2fa],0x1        # 119890 <KEEP_WORDS>
    d596:	jne    d8ba <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa5a>
    d59c:	cmp    rax,0x8000
    d5a2:	jae    d8ba <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa5a>
    d5a8:	cmp    rcx,0x3108180
    d5af:	jb     d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d5b1:	mov    rax,QWORD PTR [r13+0x0]
    d5b5:	mov    QWORD PTR [r12+rcx*8],rax
    d5b9:	mov    QWORD PTR [r13+0x0],rcx
    d5bd:	mov    rax,QWORD PTR [r13+0x100]
    d5c4:	inc    rax
    d5c7:	mov    QWORD PTR [r13+0x100],rax
    d5ce:	cmp    BYTE PTR [rip+0x10c2bb],0x1        # 119890 <KEEP_WORDS>
    d5d5:	jne    d7d1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x971>
    d5db:	cmp    rax,0x8000
    d5e1:	jae    d7d1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x971>
    d5e7:	movabs rbx,0x7e00000000000000
    d5f1:	test   rbp,rbx
    d5f4:	sete   al
    d5f7:	cmp    rbp,0xffffffffffffffff
    d5fb:	sete   cl
    d5fe:	or     cl,al
    d600:	mov    rax,rbp
    d603:	movabs rdx,0xffffffff80
    d60d:	and    rax,rdx
    d610:	cmp    rax,0x3108180
    d616:	setb   al
    d619:	or     al,cl
    d61b:	jne    d631 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x7d1>
    d61d:	mov    rdi,r12
    d620:	mov    rsi,r13
    d623:	mov    rdx,rbp
    d626:	mov    rbp,r11
    d629:	call   7810 <term_drop>
    d62e:	mov    r11,rbp
    d631:	test   r11,rbx
    d634:	sete   al
    d637:	cmp    r11,0xffffffffffffffff
    d63b:	sete   cl
    d63e:	or     cl,al
    d640:	movabs rax,0xffffffff80
    d64a:	and    rax,r11
    d64d:	cmp    rax,0x3108180
    d653:	setb   al
    d656:	or     al,cl
    d658:	jne    d668 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x808>
    d65a:	mov    rdi,r12
    d65d:	mov    rsi,r13
    d660:	mov    rdx,r11
    d663:	call   7810 <term_drop>
    d668:	mov    eax,DWORD PTR [r14-0x8]
    d66c:	add    r14,0xfffffffffffffff8
    d670:	lea    rcx,[rip+0xa799]        # 17e10 <wl_tab>
    d677:	mov    rax,QWORD PTR [rcx+rax*8]
    d67b:	movabs rsi,0x100a40000000000
    d685:	mov    edi,0x1
    d68a:	add    rsp,0x10
    d68e:	pop    rbp
    d68f:	jmp    rax
    d691:	mov    ecx,DWORD PTR [r12+r9*8+0x4]
    d696:	mov    eax,DWORD PTR [r12+r9*8]
    d69a:	mov    edx,eax
    d69c:	and    edx,0xffffff
    d6a2:	cmp    edx,0x1
    d6a5:	jne    d8f1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa91>
    d6ab:	mov    edx,DWORD PTR [r12+r9*8]
    d6af:	shl    rcx,0x20
    d6b3:	or     rcx,rax
    d6b6:	shr    rcx,0x18
    d6ba:	mov    ebx,DWORD PTR [r12+rcx*8]
    d6be:	mov    rax,QWORD PTR [r13+0x0]
    d6c2:	mov    QWORD PTR [r12+r9*8],rax
    d6c6:	mov    QWORD PTR [r13+0x0],r9
    d6ca:	mov    rax,QWORD PTR [r13+0x100]
    d6d1:	inc    rax
    d6d4:	mov    QWORD PTR [r13+0x100],rax
    d6db:	cmp    BYTE PTR [rip+0x10c1ae],0x1        # 119890 <KEEP_WORDS>
    d6e2:	jne    d922 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xac2>
    d6e8:	cmp    rax,0x8000
    d6ee:	jae    d922 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xac2>
    d6f4:	cmp    rcx,0x3108180
    d6fb:	jb     d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d6fd:	mov    rax,QWORD PTR [r13+0x0]
    d701:	mov    QWORD PTR [r12+rcx*8],rax
    d705:	mov    QWORD PTR [r13+0x0],rcx
    d709:	mov    rax,QWORD PTR [r13+0x100]
    d710:	inc    rax
    d713:	mov    QWORD PTR [r13+0x100],rax
    d71a:	cmp    BYTE PTR [rip+0x10c16f],0x1        # 119890 <KEEP_WORDS>
    d721:	jne    d8df <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa7f>
    d727:	cmp    rax,0x8000
    d72d:	jae    d8df <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa7f>
    d733:	mov    esi,ebp
    d735:	mov    edx,ebx
    d737:	mov    rcx,r8
    d73a:	add    rsp,0x10
    d73e:	pop    rbp
    d73f:	jmp    de10 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_108_101_97_102_>
    d744:	mov    rdi,r12
    d747:	mov    rsi,r13
    d74a:	mov    edx,0x2
    d74f:	mov    rcx,r11
    d752:	call   159a8 <heap_alloc_miss>
    d757:	mov    r11,rcx
    d75a:	mov    rcx,rax
    d75d:	jmp    d244 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x3e4>
    d762:	mov    rdi,r12
    d765:	mov    rsi,r13
    d768:	mov    edx,0x3
    d76d:	mov    r9,rax
    d770:	mov    rcx,r11
    d773:	call   159a8 <heap_alloc_miss>
    d778:	mov    r11,rcx
    d77b:	mov    rcx,rax
    d77e:	mov    rax,r9
    d781:	jmp    d28e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x42e>
    d786:	mov    rdi,r12
    d789:	mov    rsi,r13
    d78c:	mov    edx,0x3
    d791:	mov    r9,rax
    d794:	mov    rcx,r11
    d797:	call   159a8 <heap_alloc_miss>
    d79c:	mov    r11,rcx
    d79f:	mov    rcx,rax
    d7a2:	mov    rax,r9
    d7a5:	jmp    d2d7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x477>
    d7aa:	mov    rdi,r12
    d7ad:	mov    rsi,r13
    d7b0:	xor    edx,edx
    d7b2:	call   15881 <heap_hand>
    d7b7:	jmp    d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d7bc:	mov    rdi,r12
    d7bf:	mov    rsi,r13
    d7c2:	mov    rax,rdx
    d7c5:	mov    edx,0x1
    d7ca:	call   15881 <heap_hand>
    d7cf:	jmp    d844 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9e4>
    d7d1:	mov    rdi,r12
    d7d4:	mov    rsi,r13
    d7d7:	xor    edx,edx
    d7d9:	mov    rax,r11
    d7dc:	call   15881 <heap_hand>
    d7e1:	jmp    d86e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa0e>
    d7e6:	shl    rcx,0x20
    d7ea:	or     rcx,rsi
    d7ed:	shr    rcx,0x18
    d7f1:	mov    edx,DWORD PTR [r12+rcx*8]
    d7f5:	mov    QWORD PTR [rsp],rdx
    d7f9:	mov    rdi,r12
    d7fc:	mov    rsi,r13
    d7ff:	mov    rdx,rbp
    d802:	mov    rbp,r8
    d805:	mov    r8d,0x1
    d80b:	call   15912 <span_fade>
    d810:	mov    r8,rbp
    d813:	mov    rbp,QWORD PTR [rsp]
    d817:	jmp    d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d81c:	shl    rcx,0x20
    d820:	or     rcx,rax
    d823:	shr    rcx,0x18
    d827:	mov    rax,QWORD PTR [r12+rcx*8]
    d82b:	mov    rbp,QWORD PTR [r12+rcx*8+0x8]
    d830:	mov    rdi,r12
    d833:	mov    rsi,r13
    d836:	mov    rdx,rbx
    d839:	mov    r8d,0x2
    d83f:	call   15912 <span_fade>
    d844:	mov    rdx,rax
    d847:	jmp    d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d84c:	shl    rcx,0x20
    d850:	or     rcx,rax
    d853:	shr    rcx,0x18
    d857:	mov    rdi,r12
    d85a:	mov    rsi,r13
    d85d:	mov    rdx,rbx
    d860:	mov    r8d,0x1
    d866:	mov    rax,r11
    d869:	call   15912 <span_fade>
    d86e:	mov    r11,rax
    d871:	jmp    d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d876:	mov    rdi,r12
    d879:	mov    rsi,r13
    d87c:	xor    edx,edx
    d87e:	call   15881 <heap_hand>
    d883:	cmp    rcx,0x3108180
    d88a:	jae    d37d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x51d>
    d890:	jmp    d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d895:	mov    rdi,r12
    d898:	mov    rsi,r13
    d89b:	mov    rax,rdx
    d89e:	xor    edx,edx
    d8a0:	call   15881 <heap_hand>
    d8a5:	mov    rdx,rax
    d8a8:	cmp    rcx,0x3108180
    d8af:	jae    d496 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x636>
    d8b5:	jmp    d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d8ba:	mov    rdi,r12
    d8bd:	mov    rsi,r13
    d8c0:	xor    edx,edx
    d8c2:	mov    rax,r11
    d8c5:	call   15881 <heap_hand>
    d8ca:	mov    r11,rax
    d8cd:	cmp    rcx,0x3108180
    d8d4:	jae    d5b1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x751>
    d8da:	jmp    d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d8df:	mov    rdi,r12
    d8e2:	mov    rsi,r13
    d8e5:	xor    edx,edx
    d8e7:	call   15881 <heap_hand>
    d8ec:	jmp    d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d8f1:	shl    rcx,0x20
    d8f5:	or     rcx,rax
    d8f8:	shr    rcx,0x18
    d8fc:	mov    eax,DWORD PTR [r12+rcx*8]
    d900:	mov    rdi,r12
    d903:	mov    rsi,r13
    d906:	mov    rdx,rbx
    d909:	mov    r9,r8
    d90c:	mov    r8d,0x1
    d912:	call   15912 <span_fade>
    d917:	mov    r8,r9
    d91a:	mov    rbx,rax
    d91d:	jmp    d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d922:	mov    rdi,r12
    d925:	mov    rsi,r13
    d928:	xor    edx,edx
    d92a:	call   15881 <heap_hand>
    d92f:	cmp    rcx,0x3108180
    d936:	jae    d6fd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x89d>
    d93c:	jmp    d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d941:	mov    QWORD PTR [rsp],r8
    d945:	test   r15d,r15d
    d948:	jne    db22 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xcc2>
    d94e:	mov    rcx,QWORD PTR [r14-0x18]
    d952:	lea    r15,[r14-0x10]
    d956:	mov    r8d,DWORD PTR [r14-0x10]
    d95a:	mov    rdi,r12
    d95d:	mov    rsi,r13
    d960:	mov    edx,0x7a
    d965:	mov    r9d,0x1
    d96b:	call   7ca0 <task_node>
    d970:	mov    rcx,QWORD PTR [rsp]
    d974:	mov    QWORD PTR [r12+rax*8],rcx
    d978:	movabs rcx,0x5007a0000000000
    d982:	or     rcx,rax
    d985:	mov    QWORD PTR [r14-0x18],rcx
    d989:	mov    QWORD PTR [r14-0x10],0x1
    d991:	mov    rdi,r12
    d994:	mov    rsi,r13
    d997:	mov    edx,0x7b
    d99c:	mov    r8d,0x1
    d9a2:	mov    r9d,0x1
    d9a8:	call   7ca0 <task_node>
    d9ad:	mov    QWORD PTR [r12+rax*8],rbx
    d9b1:	movabs rcx,0x5007b0000000000
    d9bb:	or     rcx,rax
    d9be:	mov    QWORD PTR [r14-0x18],rcx
    d9c2:	mov    QWORD PTR [r14-0x10],0x1
    d9ca:	mov    rdi,r12
    d9cd:	mov    rsi,r13
    d9d0:	mov    edx,0x7c
    d9d5:	mov    r8d,0x1
    d9db:	mov    r9d,0x1
    d9e1:	call   7ca0 <task_node>
    d9e6:	mov    QWORD PTR [r12+rax*8],rbp
    d9ea:	movabs rcx,0x5007c0000000000
    d9f4:	jmp    db04 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xca4>
    d9f9:	mov    QWORD PTR [rsp+0x8],r11
    d9fe:	mov    QWORD PTR [rsp],r8
    da02:	movabs rax,0x7e00000000000000
    da0c:	test   rbp,rax
    da0f:	sete   al
    da12:	cmp    rbp,0xffffffffffffffff
    da16:	sete   cl
    da19:	or     cl,al
    da1b:	mov    rax,rbp
    da1e:	movabs rdx,0xffffffff80
    da28:	and    rax,rdx
    da2b:	cmp    rax,0x3108180
    da31:	setb   al
    da34:	or     al,cl
    da36:	jne    da46 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xbe6>
    da38:	mov    rdi,r12
    da3b:	mov    rsi,r13
    da3e:	mov    rdx,rbp
    da41:	call   7810 <term_drop>
    da46:	mov    rdx,QWORD PTR [rsp+0x8]
    da4b:	movabs rax,0x7e00000000000000
    da55:	test   rdx,rax
    da58:	sete   al
    da5b:	cmp    rdx,0xffffffffffffffff
    da5f:	sete   cl
    da62:	or     cl,al
    da64:	movabs rax,0xffffffff80
    da6e:	and    rax,rdx
    da71:	cmp    rax,0x3108180
    da77:	setb   al
    da7a:	or     al,cl
    da7c:	jne    da8e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xc2e>
    da7e:	mov    rdi,r12
    da81:	mov    rsi,r13
    da84:	mov    rdx,QWORD PTR [rsp+0x8]
    da89:	call   7810 <term_drop>
    da8e:	test   r15d,r15d
    da91:	jne    db59 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xcf9>
    da97:	mov    rcx,QWORD PTR [r14-0x18]
    da9b:	lea    r15,[r14-0x10]
    da9f:	mov    r8d,DWORD PTR [r14-0x10]
    daa3:	mov    rdi,r12
    daa6:	mov    rsi,r13
    daa9:	mov    edx,0x78
    daae:	mov    r9d,0x1
    dab4:	call   7ca0 <task_node>
    dab9:	mov    rcx,QWORD PTR [rsp]
    dabd:	mov    QWORD PTR [r12+rax*8],rcx
    dac1:	movabs rcx,0x500780000000000
    dacb:	or     rcx,rax
    dace:	mov    QWORD PTR [r14-0x18],rcx
    dad2:	mov    QWORD PTR [r14-0x10],0x1
    dada:	mov    rdi,r12
    dadd:	mov    rsi,r13
    dae0:	mov    edx,0x79
    dae5:	mov    r8d,0x1
    daeb:	mov    r9d,0x1
    daf1:	call   7ca0 <task_node>
    daf6:	mov    QWORD PTR [r12+rax*8],rbx
    dafa:	movabs rcx,0x500790000000000
    db04:	or     rcx,rax
    db07:	mov    QWORD PTR [r14-0x18],rcx
    db0b:	mov    eax,0x1
    db10:	mov    r14,r15
    db13:	mov    QWORD PTR [r14],rax
    db16:	lea    rdi,[rip+0xffffffffffff5093]        # 2bb0 <FID_RESW_T+0x350>
    db1d:	call   15820 <err_fail>
    db22:	mov    rax,QWORD PTR [rsp]
    db26:	mov    QWORD PTR [r14],rax
    db29:	mov    QWORD PTR [r14+0x8],0x7a
    db31:	mov    QWORD PTR [r14+0x10],rbx
    db35:	mov    QWORD PTR [r14+0x18],0x7b
    db3d:	mov    QWORD PTR [r14+0x20],rbp
    db41:	add    r14,0x28
    db45:	mov    eax,0x7c
    db4a:	mov    QWORD PTR [r14],rax
    db4d:	lea    rdi,[rip+0xffffffffffff505c]        # 2bb0 <FID_RESW_T+0x350>
    db54:	call   15820 <err_fail>
    db59:	mov    rax,QWORD PTR [rsp]
    db5d:	mov    QWORD PTR [r14],rax
    db60:	mov    QWORD PTR [r14+0x8],0x78
    db68:	mov    QWORD PTR [r14+0x10],rbx
    db6c:	add    r14,0x18
    db70:	mov    eax,0x79
    db75:	mov    QWORD PTR [r14],rax
    db78:	lea    rdi,[rip+0xffffffffffff5031]        # 2bb0 <FID_RESW_T+0x350>
    db7f:	call   15820 <err_fail>
    db84:	mov    rbp,r8
    db87:	test   r15d,r15d
    db8a:	jne    dbfa <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd9a>
    db8c:	mov    rcx,QWORD PTR [r14-0x18]
    db90:	lea    r15,[r14-0x10]
    db94:	mov    r8d,DWORD PTR [r14-0x10]
    db98:	mov    rdi,r12
    db9b:	mov    rsi,r13
    db9e:	mov    edx,0x71
    dba3:	mov    r9d,0x1
    dba9:	call   7ca0 <task_node>
    dbae:	mov    QWORD PTR [r12+rax*8],rbp
    dbb2:	movabs rcx,0x500710000000000
    dbbc:	or     rcx,rax
    dbbf:	mov    QWORD PTR [r14-0x18],rcx
    dbc3:	mov    QWORD PTR [r14-0x10],0x1
    dbcb:	mov    rdi,r12
    dbce:	mov    rsi,r13
    dbd1:	mov    edx,0x72
    dbd6:	mov    r8d,0x1
    dbdc:	mov    r9d,0x1
    dbe2:	call   7ca0 <task_node>
    dbe7:	mov    QWORD PTR [r12+rax*8],rbx
    dbeb:	movabs rcx,0x500720000000000
    dbf5:	jmp    db04 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xca4>
    dbfa:	mov    QWORD PTR [r14],rbp
    dbfd:	mov    QWORD PTR [r14+0x8],0x71
    dc05:	mov    QWORD PTR [r14+0x10],rbx
    dc09:	add    r14,0x18
    dc0d:	mov    eax,0x72
    dc12:	mov    QWORD PTR [r14],rax
    dc15:	lea    rdi,[rip+0xffffffffffff4f94]        # 2bb0 <FID_RESW_T+0x350>
    dc1c:	call   15820 <err_fail>
    dc21:	data16 data16 data16 data16 data16 nop WORD PTR cs:[rax+rax*1+0x0]

