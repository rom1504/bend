
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402210 <nx_rt_fast_field>:
  402210:	mov    %esi,%ecx
  402212:	mov    $0xfffffffe,%eax
  402217:	rol    %cl,%eax
  402219:	and    %eax,0x20(%rdi)
  40221c:	mov    %esi,%ecx
  40221e:	mov    0x10(%rdi,%rcx,8),%rax
  402223:	movq   $0xffffffffffffffff,0x10(%rdi,%rcx,8)
  40222c:	retq   

Disassembly of section .fini:
