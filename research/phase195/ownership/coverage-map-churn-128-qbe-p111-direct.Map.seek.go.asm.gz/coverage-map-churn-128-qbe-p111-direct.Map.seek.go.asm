
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/coverage-map-churn-128/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000420590 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_>:
  420590:	endbr64 
  420594:	cs push %rbp
  420596:	mov    %rsp,%rbp
  420599:	sub    $0x38e8,%rsp
  4205a0:	push   %rbx
  4205a1:	push   %r12
  4205a3:	push   %r13
  4205a5:	push   %r14
  4205a7:	push   %r15
  4205a9:	mov    0x28(%rdi),%rsi
  4205ad:	mov    0x30(%rdi),%r12
  4205b1:	mov    %rsi,%rax
  4205b4:	shr    $0x28,%rax
  4205b8:	and    $0xffff,%rax
  4205be:	cmp    $0x2d,%rax
  4205c2:	sete   %al
  4205c5:	movzbl %al,%eax
  4205c8:	mov    %r12,%rcx
  4205cb:	shr    $0x28,%rcx
  4205cf:	mov    %rcx,%rbx
  4205d2:	and    $0xffff,%rbx
  4205d9:	mov    %rbx,-0xb8(%rbp)
  4205e0:	cmp    $0x0,%eax
  4205e3:	jne    4207ba <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x22a>
  4205e9:	cmp    $0x8,%rbx
  4205ed:	je     42062a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9a>
  4205ef:	mov    %rdi,%rbx
  4205f2:	callq  4318a0 <p111_rt_sink>
  4205f7:	mov    %r12,%rsi
  4205fa:	mov    %rbx,%rdi
  4205fd:	mov    %rsi,-0x38e0(%rbp)
  420604:	mov    0x10(%rdi),%rax
  420608:	mov    %rsi,(%rax)
  42060b:	movq   $0x179,0x8(%rax)
  420613:	add    $0x10,%rax
  420617:	mov    %rax,0x10(%rdi)
  42061b:	mov    $0x4,%esi
  420620:	callq  432030 <p111_rt_fail>
  420625:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  42062a:	xchg   %r12,%rsi
  42062d:	lea    -0x38e0(%rbp),%rdx
  420634:	mov    %rsi,%r15
  420637:	mov    %rdi,%rbx
  42063a:	callq  437640 <p125_rt_take2>
  42063f:	mov    %r12,%rsi
  420642:	mov    %rbx,%rdi
  420645:	mov    -0x38e0(%rbp),%rbx
  42064c:	mov    %rsi,%r13
  42064f:	mov    -0x38d8(%rbp),%rsi
  420656:	mov    %rdi,%r12
  420659:	callq  4318a0 <p111_rt_sink>
  42065e:	mov    %r13,%rsi
  420661:	mov    %r12,%rdi
  420664:	mov    %rbx,-0x38e0(%rbp)
  42066b:	movabs $0x1000b0000000000,%rax
  420675:	mov    %rax,-0x38d8(%rbp)
  42067c:	mov    0x8(%rdi),%r9
  420680:	mov    0x8(%r9),%rax
  420684:	cmp    $0x0,%rax
  420688:	jne    4206ac <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x11c>
  42068a:	lea    -0x38e0(%rbp),%rdx
  420691:	mov    %rsi,%r12
  420694:	mov    $0x8,%esi
  420699:	mov    %rdi,%rbx
  42069c:	callq  437550 <p125_rt_ctor2>
  4206a1:	mov    %r12,%rsi
  4206a4:	mov    %rbx,%rdi
  4206a7:	mov    %rax,%rcx
  4206aa:	jmp    4206f0 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x160>
  4206ac:	mov    (%rdi),%rdx
  4206af:	mov    %rax,%r8
  4206b2:	shl    $0x3,%r8
  4206b6:	mov    (%rdx,%r8,1),%r10
  4206ba:	mov    0x108(%r9),%rcx
  4206c1:	mov    %r10,0x8(%r9)
  4206c5:	sub    $0x2,%rcx
  4206c9:	mov    %rcx,0x108(%r9)
  4206d0:	mov    %rbx,(%rdx,%r8,1)
  4206d4:	movabs $0x1000b0000000000,%rcx
  4206de:	mov    %rcx,0x8(%rdx,%r8,1)
  4206e3:	movabs $0x200080000000000,%rcx
  4206ed:	or     %rax,%rcx
  4206f0:	mov    %rsi,-0x38e0(%rbp)
  4206f7:	mov    %rcx,-0x38d8(%rbp)
  4206fe:	mov    0x8(%rdi),%r9
  420702:	mov    0x8(%r9),%rax
  420706:	cmp    $0x0,%rax
  42070a:	jne    420725 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x195>
  42070c:	lea    -0x38e0(%rbp),%rdx
  420713:	mov    $0x8,%esi
  420718:	mov    %rdi,%rbx
  42071b:	callq  437550 <p125_rt_ctor2>
  420720:	mov    %rbx,%rdi
  420723:	jmp    420762 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d2>
  420725:	mov    (%rdi),%rdx
  420728:	mov    %rsi,%rbx
  42072b:	mov    %rax,%rsi
  42072e:	shl    $0x3,%rsi
  420732:	mov    (%rdx,%rsi,1),%r10
  420736:	mov    0x108(%r9),%r8
  42073d:	mov    %r10,0x8(%r9)
  420741:	sub    $0x2,%r8
  420745:	mov    %r8,0x108(%r9)
  42074c:	mov    %rbx,(%rdx,%rsi,1)
  420750:	mov    %rcx,0x8(%rdx,%rsi,1)
  420755:	movabs $0x200080000000000,%rcx
  42075f:	or     %rcx,%rax
  420762:	mov    %rax,-0x38e0(%rbp)
  420769:	mov    0x1f4c8(%rip),%rcx        # 43fc38 <p111_program+0x58>
  420770:	test   $0x4,%rcx
  420777:	jne    42078f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ff>
  420779:	mov    $0x1,%edx
  42077e:	lea    -0x38e0(%rbp),%rsi
  420785:	callq  431ec0 <p111_rt_return>
  42078a:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  42078f:	mov    %rax,0x28(%rdi)
  420793:	movl   $0x1,0x1c(%rdi)
  42079a:	mov    0x10(%rdi),%rax
  42079e:	mov    %rax,%rcx
  4207a1:	add    $0xfffffffffffffff8,%rcx
  4207a5:	mov    %rcx,0x10(%rdi)
  4207a9:	mov    -0x8(%rax),%rax
  4207ad:	mov    %eax,0x20(%rdi)
  4207b0:	mov    $0x0,%eax
  4207b5:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4207ba:	cs cs cs cs mov %r12,%r15
  4207c1:	cs cs cs mov %rbx,%r12
  4207c7:	lea    -0x38e0(%rbp),%rdx
  4207ce:	mov    %rdi,%rbx
  4207d1:	callq  4378a0 <p125_rt_take3>
  4207d6:	mov    %rbx,%rdi
  4207d9:	mov    -0x38e0(%rbp),%rbx
  4207e0:	mov    -0x38d8(%rbp),%rsi
  4207e7:	mov    -0x38d0(%rbp),%r14
  4207ee:	mov    %r14,-0x8(%rbp)
  4207f2:	mov    %rsi,%rax
  4207f5:	shr    $0x28,%rax
  4207f9:	and    $0xffff,%rax
  4207ff:	cmp    $0x2b,%rax
  420803:	sete   %dl
  420806:	movzbl %dl,%edx
  420809:	mov    %rax,%rcx
  42080c:	mov    %r14,%rax
  42080f:	shr    $0x28,%rax
  420813:	and    $0xffff,%rax
  420819:	mov    %rax,-0x88(%rbp)
  420820:	cmp    $0x0,%edx
  420823:	jne    423351 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2dc1>
  420829:	mov    %rcx,%rax
  42082c:	cmp    $0x2c,%rax
  420830:	je     421c74 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16e4>
  420836:	cmp    $0x2d,%rax
  42083a:	je     4208b9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x329>
  42083c:	mov    %rsi,%r12
  42083f:	mov    %rbx,%rsi
  420842:	mov    %rdi,%rbx
  420845:	callq  4318a0 <p111_rt_sink>
  42084a:	mov    %r12,%rsi
  42084d:	mov    %rbx,%rdi
  420850:	mov    %r15,-0x38e0(%rbp)
  420857:	mov    0x10(%rdi),%rax
  42085b:	mov    %r15,(%rax)
  42085e:	movq   $0x176,0x8(%rax)
  420866:	add    $0x10,%rax
  42086a:	mov    %rax,0x10(%rdi)
  42086e:	mov    %r14,-0x38e0(%rbp)
  420875:	mov    0x10(%rdi),%rax
  420879:	mov    %r14,(%rax)
  42087c:	movq   $0x177,0x8(%rax)
  420884:	add    $0x10,%rax
  420888:	mov    %rax,0x10(%rdi)
  42088c:	mov    %rsi,-0x38e0(%rbp)
  420893:	mov    0x10(%rdi),%rax
  420897:	mov    %rsi,(%rax)
  42089a:	movq   $0x178,0x8(%rax)
  4208a2:	add    $0x10,%rax
  4208a6:	mov    %rax,0x10(%rdi)
  4208aa:	mov    $0x4,%esi
  4208af:	callq  432030 <p111_rt_fail>
  4208b4:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4208b9:	cs cs cs lea %cs:-0x38e0(%rbp),%rdx
  4208c4:	cs cs cs cs mov %rdi,%r13
  4208cb:	callq  4378a0 <p125_rt_take3>
  4208d0:	cs mov %r14,%rsi
  4208d4:	mov    %r13,%rdi
  4208d7:	mov    -0x88(%rbp),%rax
  4208de:	mov    %rsi,%r14
  4208e1:	mov    -0x38e0(%rbp),%rsi
  4208e8:	mov    %rsi,-0x58(%rbp)
  4208ec:	mov    %r12,%rcx
  4208ef:	mov    -0x38d8(%rbp),%r12
  4208f6:	mov    %rbx,%r13
  4208f9:	mov    -0x38d0(%rbp),%rbx
  420900:	cmp    $0x2b,%rax
  420904:	je     421714 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1184>
  42090a:	cmp    $0x2c,%rax
  42090e:	je     420fd4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xa44>
  420914:	cmp    $0x2d,%rax
  420918:	je     4209b7 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x427>
  42091e:	mov    %rsi,%r14
  420921:	mov    %r13,%rsi
  420924:	mov    %rdi,%r13
  420927:	callq  4318a0 <p111_rt_sink>
  42092c:	mov    %r14,%rsi
  42092f:	mov    %r13,%rdi
  420932:	mov    -0x8(%rbp),%r14
  420936:	mov    %rdi,%r13
  420939:	callq  4318a0 <p111_rt_sink>
  42093e:	mov    %r14,%rsi
  420941:	mov    %r13,%rdi
  420944:	mov    %rsi,%r13
  420947:	mov    %r12,%rsi
  42094a:	mov    %rdi,%r12
  42094d:	callq  4318a0 <p111_rt_sink>
  420952:	mov    %r13,%rsi
  420955:	mov    %r12,%rdi
  420958:	mov    %rsi,%r12
  42095b:	mov    %rbx,%rsi
  42095e:	mov    %rdi,%rbx
  420961:	callq  4318a0 <p111_rt_sink>
  420966:	mov    %r12,%rsi
  420969:	mov    %rbx,%rdi
  42096c:	mov    %r15,-0x38e0(%rbp)
  420973:	mov    0x10(%rdi),%rax
  420977:	mov    %r15,(%rax)
  42097a:	movq   $0x174,0x8(%rax)
  420982:	add    $0x10,%rax
  420986:	mov    %rax,0x10(%rdi)
  42098a:	mov    %rsi,-0x38e0(%rbp)
  420991:	mov    0x10(%rdi),%rax
  420995:	mov    %rsi,(%rax)
  420998:	movq   $0x175,0x8(%rax)
  4209a0:	add    $0x10,%rax
  4209a4:	mov    %rax,0x10(%rdi)
  4209a8:	mov    $0x4,%esi
  4209ad:	callq  432030 <p111_rt_fail>
  4209b2:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4209b7:	cs cs mov %r14,%rsi
  4209bc:	lea    -0x38e0(%rbp),%rdx
  4209c3:	mov    %rdi,%r14
  4209c6:	callq  4378a0 <p125_rt_take3>
  4209cb:	mov    %r15,%rsi
  4209ce:	mov    %r14,%rdi
  4209d1:	mov    %rsi,%r15
  4209d4:	mov    -0x58(%rbp),%rsi
  4209d8:	mov    -0xb8(%rbp),%r14
  4209df:	mov    -0x38e0(%rbp),%r9
  4209e6:	mov    %r9,-0x20(%rbp)
  4209ea:	mov    -0x38d8(%rbp),%r8
  4209f1:	mov    %r8,-0x10(%rbp)
  4209f5:	mov    -0x38d0(%rbp),%rax
  4209fc:	mov    %rax,-0x18(%rbp)
  420a00:	cmp    $0x8,%r14
  420a04:	je     420acf <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x53f>
  420a0a:	mov    %rsi,%r14
  420a0d:	mov    %r13,%rsi
  420a10:	mov    %rdi,%r13
  420a13:	callq  4318a0 <p111_rt_sink>
  420a18:	mov    %r14,%rsi
  420a1b:	mov    %r13,%rdi
  420a1e:	mov    -0x10(%rbp),%r13
  420a22:	mov    %rdi,%r14
  420a25:	callq  4318a0 <p111_rt_sink>
  420a2a:	mov    %r15,%rsi
  420a2d:	mov    %r14,%rdi
  420a30:	mov    -0x18(%rbp),%r15
  420a34:	mov    %rsi,%r14
  420a37:	mov    %r12,%rsi
  420a3a:	mov    %rdi,%r12
  420a3d:	callq  4318a0 <p111_rt_sink>
  420a42:	mov    %r14,%rsi
  420a45:	mov    %r12,%rdi
  420a48:	mov    -0x20(%rbp),%r14
  420a4c:	mov    %rsi,%r12
  420a4f:	mov    %rbx,%rsi
  420a52:	mov    %rdi,%rbx
  420a55:	callq  4318a0 <p111_rt_sink>
  420a5a:	mov    %r14,%r9
  420a5d:	mov    %r12,%rsi
  420a60:	mov    %rbx,%rdi
  420a63:	mov    %rsi,%r12
  420a66:	mov    %r9,%rsi
  420a69:	mov    %rdi,%rbx
  420a6c:	callq  4318a0 <p111_rt_sink>
  420a71:	mov    %r13,%r8
  420a74:	mov    %r12,%rsi
  420a77:	mov    %rbx,%rdi
  420a7a:	mov    %rsi,%r12
  420a7d:	mov    %r8,%rsi
  420a80:	mov    %rdi,%rbx
  420a83:	callq  4318a0 <p111_rt_sink>
  420a88:	mov    %r12,%rsi
  420a8b:	mov    %rbx,%rdi
  420a8e:	mov    %rsi,%r12
  420a91:	mov    %r15,%rsi
  420a94:	mov    %rdi,%rbx
  420a97:	callq  4318a0 <p111_rt_sink>
  420a9c:	mov    %r12,%rsi
  420a9f:	mov    %rbx,%rdi
  420aa2:	mov    %rsi,-0x38e0(%rbp)
  420aa9:	mov    0x10(%rdi),%rax
  420aad:	mov    %rsi,(%rax)
  420ab0:	movq   $0x173,0x8(%rax)
  420ab8:	add    $0x10,%rax
  420abc:	mov    %rax,0x10(%rdi)
  420ac0:	mov    $0x4,%esi
  420ac5:	callq  432030 <p111_rt_fail>
  420aca:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  420acf:	cs cs cs cs xchg %rsi,%r15
  420ad6:	lea    %cs:-0x38e0(%rbp),%rdx
  420ade:	mov    %rdi,%r14
  420ae1:	callq  437640 <p125_rt_take2>
  420ae6:	mov    %r15,%rsi
  420ae9:	mov    %r14,%rdi
  420aec:	mov    -0x18(%rbp),%r15
  420af0:	mov    -0x10(%rbp),%r8
  420af4:	mov    -0x20(%rbp),%r9
  420af8:	mov    -0x38e0(%rbp),%rax
  420aff:	mov    %rax,-0x40(%rbp)
  420b03:	mov    -0x38d8(%rbp),%r14
  420b0a:	mov    %r14,-0x28(%rbp)
  420b0e:	cmp    $0x1,%r14
  420b12:	sete   %cl
  420b15:	movzbl %cl,%ecx
  420b18:	mov    %r14,%rdx
  420b1b:	shr    $0x28,%rdx
  420b1f:	and    $0x7fffff,%rdx
  420b26:	cmp    $0x10002,%rdx
  420b2d:	sete   %dl
  420b30:	movzbl %dl,%edx
  420b33:	mov    %r8,%r14
  420b36:	mov    %ecx,%r8d
  420b39:	or     %edx,%r8d
  420b3c:	xor    $0x1,%r8d
  420b40:	jne    420e05 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x875>
  420b46:	or     %edx,%ecx
  420b48:	jne    420c19 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x689>
  420b4e:	mov    %rsi,%r15
  420b51:	mov    %r13,%rsi
  420b54:	mov    %rdi,%r13
  420b57:	callq  4318a0 <p111_rt_sink>
  420b5c:	mov    %r15,%rsi
  420b5f:	mov    %r13,%rdi
  420b62:	mov    -0x18(%rbp),%r15
  420b66:	mov    %rsi,%r8
  420b69:	mov    %rdi,%r13
  420b6c:	callq  4318a0 <p111_rt_sink>
  420b71:	mov    %r13,%rdi
  420b74:	mov    -0x20(%rbp),%r13
  420b78:	mov    %r12,%rsi
  420b7b:	mov    %rdi,%r12
  420b7e:	callq  4318a0 <p111_rt_sink>
  420b83:	mov    %r12,%rdi
  420b86:	mov    %rbx,%r12
  420b89:	mov    -0x28(%rbp),%rbx
  420b8d:	mov    %r12,%rsi
  420b90:	mov    %rdi,%r12
  420b93:	callq  4318a0 <p111_rt_sink>
  420b98:	mov    %r13,%r9
  420b9b:	mov    %r12,%rdi
  420b9e:	mov    -0x40(%rbp),%rsi
  420ba2:	mov    %rsi,%r13
  420ba5:	mov    %r9,%rsi
  420ba8:	mov    %rdi,%r12
  420bab:	callq  4318a0 <p111_rt_sink>
  420bb0:	mov    %r14,%r8
  420bb3:	mov    %r13,%rsi
  420bb6:	mov    %r12,%rdi
  420bb9:	mov    %rsi,%r13
  420bbc:	mov    %r8,%rsi
  420bbf:	mov    %rdi,%r12
  420bc2:	callq  4318a0 <p111_rt_sink>
  420bc7:	mov    %r13,%rsi
  420bca:	mov    %r12,%rdi
  420bcd:	mov    %rsi,%r13
  420bd0:	mov    %r15,%rsi
  420bd3:	mov    %rdi,%r12
  420bd6:	callq  4318a0 <p111_rt_sink>
  420bdb:	mov    %r13,%rsi
  420bde:	mov    %r12,%rdi
  420be1:	mov    %rdi,%r12
  420be4:	callq  4318a0 <p111_rt_sink>
  420be9:	mov    %r12,%rdi
  420bec:	mov    %rbx,-0x38e0(%rbp)
  420bf3:	mov    0x10(%rdi),%rax
  420bf7:	mov    %rbx,(%rax)
  420bfa:	movq   $0x172,0x8(%rax)
  420c02:	add    $0x10,%rax
  420c06:	mov    %rax,0x10(%rdi)
  420c0a:	mov    $0x4,%esi
  420c0f:	callq  432030 <p111_rt_fail>
  420c14:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  420c19:	mov    %rsi,%r8
  420c1c:	mov    %rax,%rsi
  420c1f:	xchg   %r14,%r13
  420c22:	xchg   %r12,%r14
  420c25:	xchg   %rbx,%r12
  420c28:	mov    %r8,-0x38e0(%rbp)
  420c2f:	mov    %r14,-0x38d8(%rbp)
  420c36:	mov    %r12,-0x38d0(%rbp)
  420c3d:	mov    0x8(%rdi),%r11
  420c41:	mov    0x10(%r11),%rax
  420c45:	cmp    $0x0,%rax
  420c49:	jne    420c6e <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6de>
  420c4b:	mov    %r9,%r14
  420c4e:	lea    -0x38e0(%rbp),%rdx
  420c55:	mov    $0x2d,%esi
  420c5a:	mov    %rdi,%r12
  420c5d:	callq  4377d0 <p125_rt_ctor3>
  420c62:	mov    %r14,%r9
  420c65:	mov    %r12,%rdi
  420c68:	mov    -0x40(%rbp),%rsi
  420c6c:	jmp    420cbd <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x72d>
  420c6e:	mov    (%rdi),%rcx
  420c71:	mov    %rax,%rdx
  420c74:	shl    $0x3,%rdx
  420c78:	mov    (%rcx,%rdx,1),%r10
  420c7c:	mov    %r10,-0x30(%rbp)
  420c80:	mov    0x110(%r11),%r10
  420c87:	mov    %r10,-0x38(%rbp)
  420c8b:	mov    -0x30(%rbp),%r10
  420c8f:	mov    %r10,0x10(%r11)
  420c93:	mov    -0x38(%rbp),%r10
  420c97:	sub    $0x4,%r10
  420c9b:	mov    %r10,0x110(%r11)
  420ca2:	mov    %r8,(%rcx,%rdx,1)
  420ca6:	mov    %r14,0x8(%rcx,%rdx,1)
  420cab:	mov    %r12,0x10(%rcx,%rdx,1)
  420cb0:	movabs $0x2002d0000000000,%rcx
  420cba:	or     %rcx,%rax
  420cbd:	mov    %rbx,-0x38e0(%rbp)
  420cc4:	mov    %rax,-0x38d8(%rbp)
  420ccb:	mov    0x10(%rdi),%rax
  420ccf:	mov    %rbx,(%rax)
  420cd2:	mov    -0x38d8(%rbp),%rcx
  420cd9:	mov    %rcx,0x8(%rax)
  420cdd:	movq   $0x170,0x10(%rax)
  420ce5:	add    $0x18,%rax
  420ce9:	mov    %rax,0x10(%rdi)
  420ced:	mov    %rsi,%r12
  420cf0:	mov    %r9,%rsi
  420cf3:	mov    %rdi,%rbx
  420cf6:	callq  431810 <p111_rt_keep>
  420cfb:	mov    %r13,%r8
  420cfe:	mov    %r12,%rsi
  420d01:	mov    %rbx,%rdi
  420d04:	mov    %rax,%rdx
  420d07:	mov    %rdx,-0x38e0(%rbp)
  420d0e:	mov    %r8,-0x38d8(%rbp)
  420d15:	mov    %r15,-0x38d0(%rbp)
  420d1c:	mov    0x8(%rdi),%r10
  420d20:	mov    0x10(%r10),%rax
  420d24:	cmp    $0x0,%rax
  420d28:	jne    420d52 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x7c2>
  420d2a:	mov    %rdx,%r13
  420d2d:	lea    -0x38e0(%rbp),%rdx
  420d34:	mov    %rsi,%r12
  420d37:	mov    $0x2d,%esi
  420d3c:	mov    %rdi,%rbx
  420d3f:	callq  4377d0 <p125_rt_ctor3>
  420d44:	mov    %r13,%rdx
  420d47:	mov    %r12,%rsi
  420d4a:	mov    %rbx,%rdi
  420d4d:	mov    %rax,%rbx
  420d50:	jmp    420d9d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x80d>
  420d52:	cs cs cs mov %cs:(%rdi),%rcx
  420d59:	cs cs mov %r8,%rbx
  420d5e:	mov    %rax,%r8
  420d61:	shl    $0x3,%r8
  420d65:	mov    (%rcx,%r8,1),%r11
  420d69:	mov    0x110(%r10),%r9
  420d70:	mov    %r11,0x10(%r10)
  420d74:	sub    $0x4,%r9
  420d78:	mov    %r9,0x110(%r10)
  420d7f:	mov    %rdx,(%rcx,%r8,1)
  420d83:	mov    %rbx,0x8(%rcx,%r8,1)
  420d88:	mov    %r15,0x10(%rcx,%r8,1)
  420d8d:	movabs $0x2002d0000000000,%rcx
  420d97:	mov    %rax,%rbx
  420d9a:	or     %rcx,%rbx
  420d9d:	mov    %rsi,%r14
  420da0:	mov    %rdi,%r12
  420da3:	callq  4053c0 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  420da8:	mov    %r12,%rdi
  420dab:	mov    %rbx,-0x8e0(%rbp)
  420db2:	mov    %rax,-0x8d8(%rbp)
  420db9:	mov    0x1ee78(%rip),%rcx        # 43fc38 <p111_program+0x58>
  420dc0:	test   $0x4,%rcx
  420dc7:	jne    420de5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x855>
  420dc9:	cs mov $0x2,%ecx
  420dcf:	lea    -0x8e0(%rbp),%rdx
  420dd6:	mov    $0x151,%esi
  420ddb:	callq  431e60 <p111_rt_jump>
  420de0:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  420de5:	mov    %rbx,0x28(%rdi)
  420de9:	mov    %rax,0x30(%rdi)
  420ded:	movl   $0x0,0x1c(%rdi)
  420df4:	movl   $0x151,0x20(%rdi)
  420dfb:	mov    $0x0,%eax
  420e00:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  420e05:	mov    %r14,%r8
  420e08:	mov    %rax,%r14
  420e0b:	mov    %r9,-0x38e0(%rbp)
  420e12:	mov    %r8,-0x38d8(%rbp)
  420e19:	mov    %r15,-0x38d0(%rbp)
  420e20:	mov    0x8(%rdi),%r11
  420e24:	mov    0x10(%r11),%rax
  420e28:	cmp    $0x0,%rax
  420e2c:	jne    420e51 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8c1>
  420e2e:	lea    -0x38e0(%rbp),%rdx
  420e35:	mov    %rsi,%r15
  420e38:	mov    $0x2d,%esi
  420e3d:	mov    %rdi,%r14
  420e40:	callq  4377d0 <p125_rt_ctor3>
  420e45:	mov    %r15,%rsi
  420e48:	mov    %r14,%rdi
  420e4b:	mov    -0x40(%rbp),%r14
  420e4f:	jmp    420ea2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x912>
  420e51:	cs mov %cs:(%rdi),%rcx
  420e56:	mov    %rax,%rdx
  420e59:	shl    $0x3,%rdx
  420e5d:	mov    (%rcx,%rdx,1),%r10
  420e61:	mov    %r10,-0x48(%rbp)
  420e65:	mov    0x110(%r11),%r10
  420e6c:	mov    %r10,-0x50(%rbp)
  420e70:	mov    -0x48(%rbp),%r10
  420e74:	mov    %r10,0x10(%r11)
  420e78:	mov    -0x50(%rbp),%r10
  420e7c:	sub    $0x4,%r10
  420e80:	mov    %r10,0x110(%r11)
  420e87:	mov    %r9,(%rcx,%rdx,1)
  420e8b:	mov    %r8,0x8(%rcx,%rdx,1)
  420e90:	mov    %r15,0x10(%rcx,%rdx,1)
  420e95:	movabs $0x2002d0000000000,%rcx
  420e9f:	or     %rcx,%rax
  420ea2:	mov    %r13,-0x38e0(%rbp)
  420ea9:	mov    %rax,-0x38d8(%rbp)
  420eb0:	mov    0x10(%rdi),%rax
  420eb4:	mov    %r13,(%rax)
  420eb7:	mov    -0x38d8(%rbp),%rcx
  420ebe:	mov    %rcx,0x8(%rax)
  420ec2:	movq   $0x16e,0x10(%rax)
  420eca:	add    $0x18,%rax
  420ece:	mov    %rax,0x10(%rdi)
  420ed2:	mov    %rdi,%r13
  420ed5:	callq  431810 <p111_rt_keep>
  420eda:	mov    %r14,%rsi
  420edd:	mov    %r13,%rdi
  420ee0:	mov    %rax,%rdx
  420ee3:	mov    %rdx,-0x38e0(%rbp)
  420eea:	mov    %r12,-0x38d8(%rbp)
  420ef1:	mov    %rbx,-0x38d0(%rbp)
  420ef8:	mov    0x8(%rdi),%r10
  420efc:	mov    0x10(%r10),%rax
  420f00:	cmp    $0x0,%rax
  420f04:	jne    420f2e <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x99e>
  420f06:	mov    %rdx,%r13
  420f09:	lea    -0x38e0(%rbp),%rdx
  420f10:	mov    %rsi,%r12
  420f13:	mov    $0x2d,%esi
  420f18:	mov    %rdi,%rbx
  420f1b:	callq  4377d0 <p125_rt_ctor3>
  420f20:	mov    %r13,%rdx
  420f23:	mov    %r12,%rsi
  420f26:	mov    %rbx,%rdi
  420f29:	mov    %rax,%rbx
  420f2c:	jmp    420f70 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9e0>
  420f2e:	mov    (%rdi),%rcx
  420f31:	mov    %rax,%r8
  420f34:	shl    $0x3,%r8
  420f38:	mov    (%rcx,%r8,1),%r11
  420f3c:	mov    0x110(%r10),%r9
  420f43:	mov    %r11,0x10(%r10)
  420f47:	sub    $0x4,%r9
  420f4b:	mov    %r9,0x110(%r10)
  420f52:	mov    %rdx,(%rcx,%r8,1)
  420f56:	mov    %r12,0x8(%rcx,%r8,1)
  420f5b:	mov    %rbx,0x10(%rcx,%r8,1)
  420f60:	movabs $0x2002d0000000000,%rcx
  420f6a:	mov    %rax,%rbx
  420f6d:	or     %rcx,%rbx
  420f70:	mov    %rdi,%r12
  420f73:	callq  4053c0 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  420f78:	mov    %r12,%rdi
  420f7b:	mov    %rbx,-0x10e0(%rbp)
  420f82:	mov    %rax,-0x10d8(%rbp)
  420f89:	mov    0x1eca8(%rip),%rcx        # 43fc38 <p111_program+0x58>
  420f90:	test   $0x4,%rcx
  420f97:	jne    420fb4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xa24>
  420f99:	mov    $0x2,%ecx
  420f9e:	lea    -0x10e0(%rbp),%rdx
  420fa5:	mov    $0x151,%esi
  420faa:	callq  431e60 <p111_rt_jump>
  420faf:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  420fb4:	mov    %rbx,0x28(%rdi)
  420fb8:	mov    %rax,0x30(%rdi)
  420fbc:	movl   $0x0,0x1c(%rdi)
  420fc3:	movl   $0x151,0x20(%rdi)
  420fca:	mov    $0x0,%eax
  420fcf:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  420fd4:	mov    %r14,%rsi
  420fd7:	lea    -0x38e0(%rbp),%rdx
  420fde:	mov    %rsi,%r14
  420fe1:	mov    %rdi,%r14
  420fe4:	callq  437640 <p125_rt_take2>
  420fe9:	mov    %r15,%rsi
  420fec:	mov    %r14,%rdi
  420fef:	mov    %rsi,%r14
  420ff2:	mov    -0x58(%rbp),%rsi
  420ff6:	mov    -0xb8(%rbp),%r15
  420ffd:	mov    -0x38e0(%rbp),%r8
  421004:	mov    %r8,-0x68(%rbp)
  421008:	mov    -0x38d8(%rbp),%rax
  42100f:	mov    %rax,-0x60(%rbp)
  421013:	cmp    $0x8,%r15
  421017:	je     4210c7 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xb37>
  42101d:	mov    %rsi,%r15
  421020:	mov    %r13,%rsi
  421023:	mov    %rdi,%r13
  421026:	callq  4318a0 <p111_rt_sink>
  42102b:	mov    %r15,%rsi
  42102e:	mov    %r13,%rdi
  421031:	mov    -0x60(%rbp),%r15
  421035:	mov    %rdi,%r13
  421038:	callq  4318a0 <p111_rt_sink>
  42103d:	mov    %r14,%rsi
  421040:	mov    %r13,%rdi
  421043:	mov    -0x68(%rbp),%r13
  421047:	mov    %rsi,%r14
  42104a:	mov    %r12,%rsi
  42104d:	mov    %rdi,%r12
  421050:	callq  4318a0 <p111_rt_sink>
  421055:	mov    %r14,%rsi
  421058:	mov    %r12,%rdi
  42105b:	mov    %rsi,%r12
  42105e:	mov    %rbx,%rsi
  421061:	mov    %rdi,%rbx
  421064:	callq  4318a0 <p111_rt_sink>
  421069:	mov    %r13,%r8
  42106c:	mov    %r12,%rsi
  42106f:	mov    %rbx,%rdi
  421072:	mov    %rsi,%r12
  421075:	mov    %r8,%rsi
  421078:	mov    %rdi,%rbx
  42107b:	callq  4318a0 <p111_rt_sink>
  421080:	mov    %r12,%rsi
  421083:	mov    %rbx,%rdi
  421086:	mov    %rsi,%r12
  421089:	mov    %r15,%rsi
  42108c:	mov    %rdi,%rbx
  42108f:	callq  4318a0 <p111_rt_sink>
  421094:	mov    %r12,%rsi
  421097:	mov    %rbx,%rdi
  42109a:	mov    %rsi,-0x38e0(%rbp)
  4210a1:	mov    0x10(%rdi),%rax
  4210a5:	mov    %rsi,(%rax)
  4210a8:	movq   $0x16d,0x8(%rax)
  4210b0:	add    $0x10,%rax
  4210b4:	mov    %rax,0x10(%rdi)
  4210b8:	mov    $0x4,%esi
  4210bd:	callq  432030 <p111_rt_fail>
  4210c2:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4210c7:	mov    %rsi,%r15
  4210ca:	xchg   %r12,%r13
  4210cd:	mov    %r14,%rsi
  4210d0:	lea    -0x38e0(%rbp),%rdx
  4210d7:	mov    %rsi,%r14
  4210da:	mov    %rdi,%r14
  4210dd:	callq  437640 <p125_rt_take2>
  4210e2:	mov    %r15,%rsi
  4210e5:	mov    %r14,%rdi
  4210e8:	mov    -0x60(%rbp),%r15
  4210ec:	mov    -0x68(%rbp),%r8
  4210f0:	mov    -0x38e0(%rbp),%rax
  4210f7:	mov    %rax,-0x78(%rbp)
  4210fb:	mov    -0x38d8(%rbp),%r14
  421102:	mov    %r14,-0x70(%rbp)
  421106:	cmp    $0x1,%r14
  42110a:	sete   %cl
  42110d:	movzbl %cl,%ecx
  421110:	mov    %r14,%rdx
  421113:	shr    $0x28,%rdx
  421117:	and    $0x7fffff,%rdx
  42111e:	cmp    $0x10002,%rdx
  421125:	sete   %dl
  421128:	movzbl %dl,%edx
  42112b:	mov    %r8,%r14
  42112e:	mov    %ecx,%r8d
  421131:	or     %edx,%r8d
  421134:	xor    $0x1,%r8d
  421138:	jne    421558 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xfc8>
  42113e:	or     %edx,%ecx
  421140:	jne    4211f9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xc69>
  421146:	mov    %rsi,%r14
  421149:	mov    %r12,%rsi
  42114c:	mov    %rdi,%r12
  42114f:	callq  4318a0 <p111_rt_sink>
  421154:	mov    %r14,%rsi
  421157:	mov    %r12,%rdi
  42115a:	mov    -0x68(%rbp),%r14
  42115e:	mov    %rdi,%r12
  421161:	callq  4318a0 <p111_rt_sink>
  421166:	mov    %r12,%rdi
  421169:	mov    %rbx,%r12
  42116c:	mov    -0x70(%rbp),%rbx
  421170:	mov    %r13,%rsi
  421173:	mov    %rdi,%r13
  421176:	callq  4318a0 <p111_rt_sink>
  42117b:	mov    %r13,%rdi
  42117e:	mov    -0x78(%rbp),%rsi
  421182:	mov    %rsi,%r13
  421185:	mov    %r12,%rsi
  421188:	mov    %rdi,%r12
  42118b:	callq  4318a0 <p111_rt_sink>
  421190:	mov    %r14,%r8
  421193:	mov    %r13,%rsi
  421196:	mov    %r12,%rdi
  421199:	mov    %rsi,%r13
  42119c:	mov    %r8,%rsi
  42119f:	mov    %rdi,%r12
  4211a2:	callq  4318a0 <p111_rt_sink>
  4211a7:	mov    %r13,%rsi
  4211aa:	mov    %r12,%rdi
  4211ad:	mov    %rsi,%r13
  4211b0:	mov    %r15,%rsi
  4211b3:	mov    %rdi,%r12
  4211b6:	callq  4318a0 <p111_rt_sink>
  4211bb:	mov    %r13,%rsi
  4211be:	mov    %r12,%rdi
  4211c1:	mov    %rdi,%r12
  4211c4:	callq  4318a0 <p111_rt_sink>
  4211c9:	mov    %r12,%rdi
  4211cc:	mov    %rbx,-0x38e0(%rbp)
  4211d3:	mov    0x10(%rdi),%rax
  4211d7:	mov    %rbx,(%rax)
  4211da:	movq   $0x16c,0x8(%rax)
  4211e2:	add    $0x10,%rax
  4211e6:	mov    %rax,0x10(%rdi)
  4211ea:	mov    $0x4,%esi
  4211ef:	callq  432030 <p111_rt_fail>
  4211f4:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4211f9:	mov    %r14,%r8
  4211fc:	mov    %rsi,%r14
  4211ff:	mov    %rax,%rsi
  421202:	xchg   %rbx,%r12
  421205:	mov    %r14,-0x38e0(%rbp)
  42120c:	mov    %r13,-0x38d8(%rbp)
  421213:	mov    %r12,-0x38d0(%rbp)
  42121a:	mov    0x8(%rdi),%r10
  42121e:	mov    0x10(%r10),%rax
  421222:	cmp    $0x0,%rax
  421226:	jne    421256 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xcc6>
  421228:	mov    %r8,%r14
  42122b:	lea    -0x38e0(%rbp),%rdx
  421232:	mov    %rsi,%r13
  421235:	mov    $0x2d,%esi
  42123a:	mov    %rdi,%r12
  42123d:	callq  4377d0 <p125_rt_ctor3>
  421242:	mov    %r14,%r8
  421245:	mov    %r13,%rsi
  421248:	mov    %r12,%rdi
  42124b:	mov    %rax,%r12
  42124e:	mov    %rbx,%r13
  421251:	mov    %r12,%rbx
  421254:	jmp    42129b <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xd0b>
  421256:	mov    (%rdi),%rcx
  421259:	mov    %rax,%rdx
  42125c:	shl    $0x3,%rdx
  421260:	mov    (%rcx,%rdx,1),%r11
  421264:	mov    0x110(%r10),%r9
  42126b:	mov    %r11,0x10(%r10)
  42126f:	sub    $0x4,%r9
  421273:	mov    %r9,0x110(%r10)
  42127a:	mov    %r14,(%rcx,%rdx,1)
  42127e:	mov    %r13,0x8(%rcx,%rdx,1)
  421283:	mov    %r12,0x10(%rcx,%rdx,1)
  421288:	movabs $0x2002d0000000000,%rcx
  421292:	mov    %rbx,%r13
  421295:	mov    %rax,%rbx
  421298:	or     %rcx,%rbx
  42129b:	mov    %rsi,%r14
  42129e:	mov    %r8,%rsi
  4212a1:	mov    %rdi,%r12
  4212a4:	callq  431810 <p111_rt_keep>
  4212a9:	mov    %r14,%rsi
  4212ac:	mov    %r12,%rdi
  4212af:	mov    %rax,%r12
  4212b2:	mov    %r12,-0x38e0(%rbp)
  4212b9:	mov    %r15,-0x38d8(%rbp)
  4212c0:	mov    0x8(%rdi),%r9
  4212c4:	mov    0x8(%r9),%rax
  4212c8:	cmp    $0x0,%rax
  4212cc:	jne    4212f0 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xd60>
  4212ce:	lea    -0x38e0(%rbp),%rdx
  4212d5:	mov    %rsi,%r15
  4212d8:	mov    $0x2c,%esi
  4212dd:	mov    %rdi,%r14
  4212e0:	callq  437550 <p125_rt_ctor2>
  4212e5:	mov    %r15,%rsi
  4212e8:	mov    %r14,%rdi
  4212eb:	mov    %rax,%rcx
  4212ee:	jmp    42132a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xd9a>
  4212f0:	mov    (%rdi),%rcx
  4212f3:	mov    %rax,%rdx
  4212f6:	shl    $0x3,%rdx
  4212fa:	mov    (%rcx,%rdx,1),%r10
  4212fe:	mov    0x108(%r9),%r8
  421305:	mov    %r10,0x8(%r9)
  421309:	sub    $0x2,%r8
  42130d:	mov    %r8,0x108(%r9)
  421314:	mov    %r12,(%rcx,%rdx,1)
  421318:	mov    %r15,0x8(%rcx,%rdx,1)
  42131d:	movabs $0x2002c0000000000,%rcx
  421327:	or     %rax,%rcx
  42132a:	mov    %r13,-0x38e0(%rbp)
  421331:	mov    %rbx,-0x38d8(%rbp)
  421338:	mov    %rcx,-0x38d0(%rbp)
  42133f:	mov    0x8(%rdi),%r10
  421343:	mov    0x10(%r10),%rax
  421347:	cmp    $0x0,%rax
  42134b:	jne    42136f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xddf>
  42134d:	lea    -0x38e0(%rbp),%rdx
  421354:	mov    %rsi,%r13
  421357:	mov    $0x2d,%esi
  42135c:	mov    %rdi,%rbx
  42135f:	callq  4377d0 <p125_rt_ctor3>
  421364:	mov    %r13,%rsi
  421367:	mov    %rbx,%rdi
  42136a:	mov    %rax,%rbx
  42136d:	jmp    4213b2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xe22>
  42136f:	mov    %cs:(%rdi),%rdx
  421373:	mov    %rax,%r8
  421376:	shl    $0x3,%r8
  42137a:	mov    (%rdx,%r8,1),%r11
  42137e:	mov    0x110(%r10),%r9
  421385:	mov    %r11,0x10(%r10)
  421389:	sub    $0x4,%r9
  42138d:	mov    %r9,0x110(%r10)
  421394:	mov    %r13,(%rdx,%r8,1)
  421398:	mov    %rbx,0x8(%rdx,%r8,1)
  42139d:	mov    %rcx,0x10(%rdx,%r8,1)
  4213a2:	movabs $0x2002d0000000000,%rcx
  4213ac:	mov    %rax,%rbx
  4213af:	or     %rcx,%rbx
  4213b2:	mov    %r12,-0x38e0(%rbp)
  4213b9:	mov    0x8(%rdi),%r9
  4213bd:	mov    (%r9),%rax
  4213c0:	cmp    $0x0,%rax
  4213c4:	jne    4213e8 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xe58>
  4213c6:	lea    -0x38e0(%rbp),%rdx
  4213cd:	mov    %rsi,%r13
  4213d0:	mov    $0xc,%esi
  4213d5:	mov    %rdi,%r12
  4213d8:	callq  437320 <p125_rt_ctor1>
  4213dd:	mov    %r13,%rsi
  4213e0:	mov    %r12,%rdi
  4213e3:	mov    %rax,%rcx
  4213e6:	jmp    42141c <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xe8c>
  4213e8:	mov    (%rdi),%rcx
  4213eb:	mov    %rax,%rdx
  4213ee:	shl    $0x3,%rdx
  4213f2:	mov    (%rcx,%rdx,1),%r10
  4213f6:	mov    0x100(%r9),%r8
  4213fd:	mov    %r10,(%r9)
  421400:	sub    $0x1,%r8
  421404:	mov    %r8,0x100(%r9)
  42140b:	mov    %r12,(%rcx,%rdx,1)
  42140f:	movabs $0x2000c0000000000,%rcx
  421419:	or     %rax,%rcx
  42141c:	mov    %rsi,-0x38e0(%rbp)
  421423:	mov    %rcx,-0x38d8(%rbp)
  42142a:	mov    0x8(%rdi),%r9
  42142e:	mov    0x8(%r9),%rax
  421432:	cmp    $0x0,%rax
  421436:	jne    421454 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xec4>
  421438:	lea    -0x38e0(%rbp),%rdx
  42143f:	mov    $0x8,%esi
  421444:	mov    %rdi,%r12
  421447:	callq  437550 <p125_rt_ctor2>
  42144c:	mov    %r12,%rdi
  42144f:	mov    %rax,%rcx
  421452:	jmp    421491 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf01>
  421454:	mov    (%rdi),%rdx
  421457:	mov    %rsi,%r14
  42145a:	mov    %rax,%rsi
  42145d:	shl    $0x3,%rsi
  421461:	mov    (%rdx,%rsi,1),%r10
  421465:	mov    0x108(%r9),%r8
  42146c:	mov    %r10,0x8(%r9)
  421470:	sub    $0x2,%r8
  421474:	mov    %r8,0x108(%r9)
  42147b:	mov    %r14,(%rdx,%rsi,1)
  42147f:	mov    %rcx,0x8(%rdx,%rsi,1)
  421484:	movabs $0x200080000000000,%rcx
  42148e:	or     %rax,%rcx
  421491:	mov    %rbx,-0x38e0(%rbp)
  421498:	mov    %rcx,-0x38d8(%rbp)
  42149f:	mov    0x8(%rdi),%r9
  4214a3:	mov    0x8(%r9),%rax
  4214a7:	cmp    $0x0,%rax
  4214ab:	jne    4214c6 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf36>
  4214ad:	lea    -0x38e0(%rbp),%rdx
  4214b4:	mov    $0x8,%esi
  4214b9:	mov    %rdi,%rbx
  4214bc:	callq  437550 <p125_rt_ctor2>
  4214c1:	mov    %rbx,%rdi
  4214c4:	jmp    421500 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf70>
  4214c6:	mov    (%rdi),%rdx
  4214c9:	mov    %rax,%rsi
  4214cc:	shl    $0x3,%rsi
  4214d0:	mov    (%rdx,%rsi,1),%r10
  4214d4:	mov    0x108(%r9),%r8
  4214db:	mov    %r10,0x8(%r9)
  4214df:	sub    $0x2,%r8
  4214e3:	mov    %r8,0x108(%r9)
  4214ea:	mov    %rbx,(%rdx,%rsi,1)
  4214ee:	mov    %rcx,0x8(%rdx,%rsi,1)
  4214f3:	movabs $0x200080000000000,%rcx
  4214fd:	or     %rcx,%rax
  421500:	mov    %rax,-0x38e0(%rbp)
  421507:	mov    0x1e72a(%rip),%rcx        # 43fc38 <p111_program+0x58>
  42150e:	test   $0x4,%rcx
  421515:	jne    42152d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf9d>
  421517:	mov    $0x1,%edx
  42151c:	lea    -0x38e0(%rbp),%rsi
  421523:	callq  431ec0 <p111_rt_return>
  421528:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  42152d:	mov    %rax,0x28(%rdi)
  421531:	movl   $0x1,0x1c(%rdi)
  421538:	mov    0x10(%rdi),%rax
  42153c:	mov    %rax,%rcx
  42153f:	add    $0xfffffffffffffff8,%rcx
  421543:	mov    %rcx,0x10(%rdi)
  421547:	mov    -0x8(%rax),%rax
  42154b:	mov    %eax,0x20(%rdi)
  42154e:	mov    $0x0,%eax
  421553:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421558:	mov    %r14,%r8
  42155b:	mov    %rax,%r14
  42155e:	xchg   %r13,%r12
  421561:	mov    %r8,-0x38e0(%rbp)
  421568:	mov    %r15,-0x38d8(%rbp)
  42156f:	mov    0x8(%rdi),%r10
  421573:	mov    0x8(%r10),%rax
  421577:	cmp    $0x0,%rax
  42157b:	jne    4215a2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1012>
  42157d:	cs lea %cs:-0x38e0(%rbp),%rdx
  421586:	mov    %rsi,%r15
  421589:	mov    $0x2c,%esi
  42158e:	mov    %rdi,%r14
  421591:	callq  437550 <p125_rt_ctor2>
  421596:	mov    %r15,%rsi
  421599:	mov    %r14,%rdi
  42159c:	mov    -0x78(%rbp),%r14
  4215a0:	jmp    4215e2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1052>
  4215a2:	cs cs cs mov %cs:(%rdi),%rcx
  4215a9:	cs cs mov %rax,%rdx
  4215ae:	shl    $0x3,%rdx
  4215b2:	mov    (%rcx,%rdx,1),%r11
  4215b6:	mov    0x108(%r10),%r9
  4215bd:	mov    %r11,0x8(%r10)
  4215c1:	sub    $0x2,%r9
  4215c5:	mov    %r9,0x108(%r10)
  4215cc:	mov    %r8,(%rcx,%rdx,1)
  4215d0:	mov    %r15,0x8(%rcx,%rdx,1)
  4215d5:	movabs $0x2002c0000000000,%rcx
  4215df:	or     %rcx,%rax
  4215e2:	mov    %r13,-0x38e0(%rbp)
  4215e9:	mov    %rax,-0x38d8(%rbp)
  4215f0:	mov    0x10(%rdi),%rax
  4215f4:	mov    %r13,(%rax)
  4215f7:	mov    -0x38d8(%rbp),%rcx
  4215fe:	mov    %rcx,0x8(%rax)
  421602:	movq   $0x16a,0x10(%rax)
  42160a:	add    $0x18,%rax
  42160e:	mov    %rax,0x10(%rdi)
  421612:	mov    %rdi,%r13
  421615:	callq  431810 <p111_rt_keep>
  42161a:	mov    %r14,%rsi
  42161d:	mov    %r13,%rdi
  421620:	mov    %rax,%rdx
  421623:	mov    %rdx,-0x38e0(%rbp)
  42162a:	mov    %r12,-0x38d8(%rbp)
  421631:	mov    %rbx,-0x38d0(%rbp)
  421638:	mov    0x8(%rdi),%r10
  42163c:	mov    0x10(%r10),%rax
  421640:	cmp    $0x0,%rax
  421644:	jne    42166e <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10de>
  421646:	mov    %rdx,%r13
  421649:	lea    -0x38e0(%rbp),%rdx
  421650:	mov    %rsi,%r12
  421653:	mov    $0x2d,%esi
  421658:	mov    %rdi,%rbx
  42165b:	callq  4377d0 <p125_rt_ctor3>
  421660:	mov    %r13,%rdx
  421663:	mov    %r12,%rsi
  421666:	mov    %rbx,%rdi
  421669:	mov    %rax,%rbx
  42166c:	jmp    4216b0 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1120>
  42166e:	mov    (%rdi),%rcx
  421671:	mov    %rax,%r8
  421674:	shl    $0x3,%r8
  421678:	mov    (%rcx,%r8,1),%r11
  42167c:	mov    0x110(%r10),%r9
  421683:	mov    %r11,0x10(%r10)
  421687:	sub    $0x4,%r9
  42168b:	mov    %r9,0x110(%r10)
  421692:	mov    %rdx,(%rcx,%r8,1)
  421696:	mov    %r12,0x8(%rcx,%r8,1)
  42169b:	mov    %rbx,0x10(%rcx,%r8,1)
  4216a0:	movabs $0x2002d0000000000,%rcx
  4216aa:	mov    %rax,%rbx
  4216ad:	or     %rcx,%rbx
  4216b0:	mov    %rdi,%r12
  4216b3:	callq  4053c0 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  4216b8:	mov    %r12,%rdi
  4216bb:	mov    %rbx,-0x18e0(%rbp)
  4216c2:	mov    %rax,-0x18d8(%rbp)
  4216c9:	mov    0x1e568(%rip),%rcx        # 43fc38 <p111_program+0x58>
  4216d0:	test   $0x4,%rcx
  4216d7:	jne    4216f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1164>
  4216d9:	mov    $0x2,%ecx
  4216de:	lea    -0x18e0(%rbp),%rdx
  4216e5:	mov    $0x151,%esi
  4216ea:	callq  431e60 <p111_rt_jump>
  4216ef:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4216f4:	mov    %rbx,0x28(%rdi)
  4216f8:	mov    %rax,0x30(%rdi)
  4216fc:	movl   $0x0,0x1c(%rdi)
  421703:	movl   $0x151,0x20(%rdi)
  42170a:	mov    $0x0,%eax
  42170f:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421714:	cs cs cs cs mov %r15,%r14
  42171b:	cs cs mov %rcx,%r15
  421720:	cmp    $0x8,%r15
  421724:	je     4217a5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1215>
  421726:	cs cs cs cs mov %rsi,%r15
  42172d:	cs mov %r13,%rsi
  421731:	mov    %rdi,%r13
  421734:	callq  4318a0 <p111_rt_sink>
  421739:	mov    %r15,%rsi
  42173c:	mov    %r13,%rdi
  42173f:	mov    %rsi,%r15
  421742:	mov    %rdi,%r13
  421745:	callq  4318a0 <p111_rt_sink>
  42174a:	mov    %r14,%rsi
  42174d:	mov    %r13,%rdi
  421750:	mov    %rsi,%r13
  421753:	mov    %r12,%rsi
  421756:	mov    %rdi,%r12
  421759:	callq  4318a0 <p111_rt_sink>
  42175e:	mov    %r13,%rsi
  421761:	mov    %r12,%rdi
  421764:	mov    %rsi,%r12
  421767:	mov    %rbx,%rsi
  42176a:	mov    %rdi,%rbx
  42176d:	callq  4318a0 <p111_rt_sink>
  421772:	mov    %r12,%rsi
  421775:	mov    %rbx,%rdi
  421778:	mov    %rsi,-0x38e0(%rbp)
  42177f:	mov    0x10(%rdi),%rax
  421783:	mov    %rsi,(%rax)
  421786:	movq   $0x169,0x8(%rax)
  42178e:	add    $0x10,%rax
  421792:	mov    %rax,0x10(%rdi)
  421796:	mov    $0x4,%esi
  42179b:	callq  432030 <p111_rt_fail>
  4217a0:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4217a5:	mov    %rsi,%r15
  4217a8:	mov    %r14,%rsi
  4217ab:	mov    %r13,%r14
  4217ae:	mov    %r12,%r13
  4217b1:	lea    -0x38e0(%rbp),%rdx
  4217b8:	mov    %rsi,%r12
  4217bb:	mov    %rdi,%r12
  4217be:	callq  437640 <p125_rt_take2>
  4217c3:	mov    %r15,%rsi
  4217c6:	mov    %r12,%rdi
  4217c9:	mov    -0x38e0(%rbp),%r15
  4217d0:	mov    %r15,-0x80(%rbp)
  4217d4:	mov    %rbx,%r12
  4217d7:	mov    -0x38d8(%rbp),%rbx
  4217de:	cmp    $0x1,%rbx
  4217e2:	sete   %al
  4217e5:	movzbl %al,%eax
  4217e8:	mov    %rbx,%rcx
  4217eb:	shr    $0x28,%rcx
  4217ef:	and    $0x7fffff,%rcx
  4217f6:	cmp    $0x10002,%rcx
  4217fd:	sete   %cl
  421800:	movzbl %cl,%ecx
  421803:	mov    %eax,%edx
  421805:	or     %ecx,%edx
  421807:	xor    $0x1,%edx
  42180a:	jne    421b2a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x159a>
  421810:	or     %ecx,%eax
  421812:	jne    4218a5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1315>
  421818:	cs cs cs cs mov %rsi,%r15
  42181f:	mov    %r14,%rsi
  421822:	mov    %rdi,%r14
  421825:	callq  4318a0 <p111_rt_sink>
  42182a:	mov    %r15,%rsi
  42182d:	mov    %r14,%rdi
  421830:	mov    -0x80(%rbp),%r15
  421834:	mov    %rsi,%r14
  421837:	mov    %rdi,%r14
  42183a:	callq  4318a0 <p111_rt_sink>
  42183f:	mov    %r15,%rsi
  421842:	mov    %r14,%rdi
  421845:	mov    %rsi,%r14
  421848:	mov    %r13,%rsi
  42184b:	mov    %rdi,%r13
  42184e:	callq  4318a0 <p111_rt_sink>
  421853:	mov    %r14,%rsi
  421856:	mov    %r13,%rdi
  421859:	mov    %rsi,%r13
  42185c:	mov    %r12,%rsi
  42185f:	mov    %rdi,%r12
  421862:	callq  4318a0 <p111_rt_sink>
  421867:	mov    %r13,%rsi
  42186a:	mov    %r12,%rdi
  42186d:	mov    %rdi,%r12
  421870:	callq  4318a0 <p111_rt_sink>
  421875:	mov    %r12,%rdi
  421878:	mov    %rbx,-0x38e0(%rbp)
  42187f:	mov    0x10(%rdi),%rax
  421883:	mov    %rbx,(%rax)
  421886:	movq   $0x168,0x8(%rax)
  42188e:	add    $0x10,%rax
  421892:	mov    %rax,0x10(%rdi)
  421896:	mov    $0x4,%esi
  42189b:	callq  432030 <p111_rt_fail>
  4218a0:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4218a5:	mov    %r12,%rbx
  4218a8:	mov    %r13,%r12
  4218ab:	mov    %r14,%r13
  4218ae:	mov    %rsi,%r14
  4218b1:	mov    %r15,%rsi
  4218b4:	mov    %r14,-0x38e0(%rbp)
  4218bb:	mov    %r12,-0x38d8(%rbp)
  4218c2:	mov    %rbx,-0x38d0(%rbp)
  4218c9:	mov    0x8(%rdi),%r9
  4218cd:	mov    0x10(%r9),%rax
  4218d1:	cmp    $0x0,%rax
  4218d5:	jne    4218f9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1369>
  4218d7:	lea    -0x38e0(%rbp),%rdx
  4218de:	mov    %rsi,%r12
  4218e1:	mov    $0x2d,%esi
  4218e6:	mov    %rdi,%rbx
  4218e9:	callq  4377d0 <p125_rt_ctor3>
  4218ee:	mov    %r12,%rsi
  4218f1:	mov    %rbx,%rdi
  4218f4:	mov    %rax,%rcx
  4218f7:	jmp    421939 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x13a9>
  4218f9:	mov    %cs:(%rdi),%rcx
  4218fd:	mov    %rax,%rdx
  421900:	shl    $0x3,%rdx
  421904:	mov    (%rcx,%rdx,1),%r10
  421908:	mov    0x110(%r9),%r8
  42190f:	mov    %r10,0x10(%r9)
  421913:	sub    $0x4,%r8
  421917:	mov    %r8,0x110(%r9)
  42191e:	mov    %r14,(%rcx,%rdx,1)
  421922:	mov    %r12,0x8(%rcx,%rdx,1)
  421927:	mov    %rbx,0x10(%rcx,%rdx,1)
  42192c:	movabs $0x2002d0000000000,%rcx
  421936:	or     %rax,%rcx
  421939:	mov    %r13,-0x38e0(%rbp)
  421940:	mov    %rcx,-0x38d8(%rbp)
  421947:	movabs $0x1002b0000000000,%rax
  421951:	mov    %rax,-0x38d0(%rbp)
  421958:	mov    0x8(%rdi),%r10
  42195c:	mov    0x10(%r10),%rax
  421960:	cmp    $0x0,%rax
  421964:	jne    421988 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x13f8>
  421966:	lea    -0x38e0(%rbp),%rdx
  42196d:	mov    %rsi,%r12
  421970:	mov    $0x2d,%esi
  421975:	mov    %rdi,%rbx
  421978:	callq  4377d0 <p125_rt_ctor3>
  42197d:	mov    %r12,%rsi
  421980:	mov    %rbx,%rdi
  421983:	mov    %rax,%rbx
  421986:	jmp    4219d4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1444>
  421988:	mov    (%rdi),%rdx
  42198b:	mov    %rax,%r8
  42198e:	shl    $0x3,%r8
  421992:	mov    (%rdx,%r8,1),%r11
  421996:	mov    0x110(%r10),%r9
  42199d:	mov    %r11,0x10(%r10)
  4219a1:	sub    $0x4,%r9
  4219a5:	mov    %r9,0x110(%r10)
  4219ac:	mov    %r13,(%rdx,%r8,1)
  4219b0:	mov    %rcx,0x8(%rdx,%r8,1)
  4219b5:	movabs $0x1002b0000000000,%rcx
  4219bf:	mov    %rcx,0x10(%rdx,%r8,1)
  4219c4:	movabs $0x2002d0000000000,%rcx
  4219ce:	mov    %rax,%rbx
  4219d1:	or     %rcx,%rbx
  4219d4:	mov    %rsi,-0x38e0(%rbp)
  4219db:	movabs $0x1000b0000000000,%rax
  4219e5:	mov    %rax,-0x38d8(%rbp)
  4219ec:	mov    0x8(%rdi),%r8
  4219f0:	mov    0x8(%r8),%rax
  4219f4:	cmp    $0x0,%rax
  4219f8:	jne    421a16 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1486>
  4219fa:	lea    -0x38e0(%rbp),%rdx
  421a01:	mov    $0x8,%esi
  421a06:	mov    %rdi,%r12
  421a09:	callq  437550 <p125_rt_ctor2>
  421a0e:	mov    %r12,%rdi
  421a11:	mov    %rax,%rcx
  421a14:	jmp    421a5d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x14cd>
  421a16:	mov    (%rdi),%rdx
  421a19:	mov    %rsi,%r14
  421a1c:	mov    %rax,%rsi
  421a1f:	shl    $0x3,%rsi
  421a23:	mov    (%rdx,%rsi,1),%r9
  421a27:	mov    0x108(%r8),%rcx
  421a2e:	mov    %r9,0x8(%r8)
  421a32:	sub    $0x2,%rcx
  421a36:	mov    %rcx,0x108(%r8)
  421a3d:	mov    %r14,(%rdx,%rsi,1)
  421a41:	movabs $0x1000b0000000000,%rcx
  421a4b:	mov    %rcx,0x8(%rdx,%rsi,1)
  421a50:	movabs $0x200080000000000,%rcx
  421a5a:	or     %rax,%rcx
  421a5d:	mov    %rbx,-0x38e0(%rbp)
  421a64:	mov    %rcx,-0x38d8(%rbp)
  421a6b:	mov    0x8(%rdi),%r9
  421a6f:	mov    0x8(%r9),%rax
  421a73:	cmp    $0x0,%rax
  421a77:	jne    421a92 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1502>
  421a79:	lea    -0x38e0(%rbp),%rdx
  421a80:	mov    $0x8,%esi
  421a85:	mov    %rdi,%rbx
  421a88:	callq  437550 <p125_rt_ctor2>
  421a8d:	mov    %rbx,%rdi
  421a90:	jmp    421ad2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1542>
  421a92:	cs cs cs mov %cs:(%rdi),%rdx
  421a99:	cs cs mov %rax,%rsi
  421a9e:	shl    $0x3,%rsi
  421aa2:	mov    (%rdx,%rsi,1),%r10
  421aa6:	mov    0x108(%r9),%r8
  421aad:	mov    %r10,0x8(%r9)
  421ab1:	sub    $0x2,%r8
  421ab5:	mov    %r8,0x108(%r9)
  421abc:	mov    %rbx,(%rdx,%rsi,1)
  421ac0:	mov    %rcx,0x8(%rdx,%rsi,1)
  421ac5:	movabs $0x200080000000000,%rcx
  421acf:	or     %rcx,%rax
  421ad2:	mov    %rax,-0x38e0(%rbp)
  421ad9:	mov    0x1e158(%rip),%rcx        # 43fc38 <p111_program+0x58>
  421ae0:	test   $0x4,%rcx
  421ae7:	jne    421aff <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x156f>
  421ae9:	mov    $0x1,%edx
  421aee:	lea    -0x38e0(%rbp),%rsi
  421af5:	callq  431ec0 <p111_rt_return>
  421afa:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421aff:	mov    %rax,0x28(%rdi)
  421b03:	movl   $0x1,0x1c(%rdi)
  421b0a:	mov    0x10(%rdi),%rax
  421b0e:	mov    %rax,%rcx
  421b11:	add    $0xfffffffffffffff8,%rcx
  421b15:	mov    %rcx,0x10(%rdi)
  421b19:	mov    -0x8(%rax),%rax
  421b1d:	mov    %eax,0x20(%rdi)
  421b20:	mov    $0x0,%eax
  421b25:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421b2a:	cs cs mov %r12,%rbx
  421b2f:	mov    %r13,%r12
  421b32:	mov    %r14,%r13
  421b35:	mov    %r15,%r14
  421b38:	mov    %r13,-0x38e0(%rbp)
  421b3f:	movabs $0x1002b0000000000,%rax
  421b49:	mov    %rax,-0x38d8(%rbp)
  421b50:	mov    0x10(%rdi),%rax
  421b54:	mov    %r13,(%rax)
  421b57:	mov    -0x38d8(%rbp),%rcx
  421b5e:	mov    %rcx,0x8(%rax)
  421b62:	movq   $0x166,0x10(%rax)
  421b6a:	add    $0x18,%rax
  421b6e:	mov    %rax,0x10(%rdi)
  421b72:	mov    %rdi,%r13
  421b75:	callq  431810 <p111_rt_keep>
  421b7a:	mov    %r14,%rsi
  421b7d:	mov    %r13,%rdi
  421b80:	mov    %rax,%rdx
  421b83:	mov    %rdx,-0x38e0(%rbp)
  421b8a:	mov    %r12,-0x38d8(%rbp)
  421b91:	mov    %rbx,-0x38d0(%rbp)
  421b98:	mov    0x8(%rdi),%r10
  421b9c:	mov    0x10(%r10),%rax
  421ba0:	cmp    $0x0,%rax
  421ba4:	jne    421bce <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x163e>
  421ba6:	mov    %rdx,%r13
  421ba9:	lea    -0x38e0(%rbp),%rdx
  421bb0:	mov    %rsi,%r12
  421bb3:	mov    $0x2d,%esi
  421bb8:	mov    %rdi,%rbx
  421bbb:	callq  4377d0 <p125_rt_ctor3>
  421bc0:	mov    %r13,%rdx
  421bc3:	mov    %r12,%rsi
  421bc6:	mov    %rbx,%rdi
  421bc9:	mov    %rax,%rbx
  421bcc:	jmp    421c10 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1680>
  421bce:	mov    (%rdi),%rcx
  421bd1:	mov    %rax,%r8
  421bd4:	shl    $0x3,%r8
  421bd8:	mov    (%rcx,%r8,1),%r11
  421bdc:	mov    0x110(%r10),%r9
  421be3:	mov    %r11,0x10(%r10)
  421be7:	sub    $0x4,%r9
  421beb:	mov    %r9,0x110(%r10)
  421bf2:	mov    %rdx,(%rcx,%r8,1)
  421bf6:	mov    %r12,0x8(%rcx,%r8,1)
  421bfb:	mov    %rbx,0x10(%rcx,%r8,1)
  421c00:	movabs $0x2002d0000000000,%rcx
  421c0a:	mov    %rax,%rbx
  421c0d:	or     %rcx,%rbx
  421c10:	mov    %rdi,%r12
  421c13:	callq  4053c0 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  421c18:	mov    %r12,%rdi
  421c1b:	mov    %rbx,-0x20e0(%rbp)
  421c22:	mov    %rax,-0x20d8(%rbp)
  421c29:	mov    0x1e008(%rip),%rcx        # 43fc38 <p111_program+0x58>
  421c30:	test   $0x4,%rcx
  421c37:	jne    421c54 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16c4>
  421c39:	mov    $0x2,%ecx
  421c3e:	lea    -0x20e0(%rbp),%rdx
  421c45:	mov    $0x151,%esi
  421c4a:	callq  431e60 <p111_rt_jump>
  421c4f:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421c54:	mov    %rbx,0x28(%rdi)
  421c58:	mov    %rax,0x30(%rdi)
  421c5c:	movl   $0x0,0x1c(%rdi)
  421c63:	movl   $0x151,0x20(%rdi)
  421c6a:	mov    $0x0,%eax
  421c6f:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421c74:	xchg   %r12,%r15
  421c77:	lea    -0x38e0(%rbp),%rdx
  421c7e:	mov    %rdi,%r13
  421c81:	callq  437640 <p125_rt_take2>
  421c86:	mov    %r14,%rsi
  421c89:	mov    %r13,%rdi
  421c8c:	mov    -0x88(%rbp),%rax
  421c93:	mov    %rsi,%r13
  421c96:	mov    -0x38e0(%rbp),%rsi
  421c9d:	mov    -0x38d8(%rbp),%r14
  421ca4:	cmp    $0x2b,%rax
  421ca8:	je     422cfa <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x276a>
  421cae:	cmp    $0x2c,%rax
  421cb2:	je     4224aa <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1f1a>
  421cb8:	nopl   0x0(%rax,%rax,1)
  421cc0:	cmp    $0x2d,%rax
  421cc4:	je     421d4e <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x17be>
  421cca:	mov    %rsi,%r15
  421ccd:	mov    %rbx,%rsi
  421cd0:	mov    %rdi,%rbx
  421cd3:	callq  4318a0 <p111_rt_sink>
  421cd8:	mov    %r15,%rsi
  421cdb:	mov    %rbx,%rdi
  421cde:	mov    %rsi,%r15
  421ce1:	mov    %rdi,%rbx
  421ce4:	callq  4318a0 <p111_rt_sink>
  421ce9:	mov    %r13,%rsi
  421cec:	mov    %rbx,%rdi
  421cef:	mov    %rsi,%r13
  421cf2:	mov    %r14,%rsi
  421cf5:	mov    %rdi,%rbx
  421cf8:	callq  4318a0 <p111_rt_sink>
  421cfd:	mov    %r13,%rsi
  421d00:	mov    %rbx,%rdi
  421d03:	mov    %r12,-0x38e0(%rbp)
  421d0a:	mov    0x10(%rdi),%rax
  421d0e:	mov    %r12,(%rax)
  421d11:	movq   $0x164,0x8(%rax)
  421d19:	add    $0x10,%rax
  421d1d:	mov    %rax,0x10(%rdi)
  421d21:	mov    %rsi,-0x38e0(%rbp)
  421d28:	mov    0x10(%rdi),%rax
  421d2c:	mov    %rsi,(%rax)
  421d2f:	movq   $0x165,0x8(%rax)
  421d37:	add    $0x10,%rax
  421d3b:	mov    %rax,0x10(%rdi)
  421d3f:	mov    $0x4,%esi
  421d44:	callq  432030 <p111_rt_fail>
  421d49:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421d4e:	mov    %rsi,%r15
  421d51:	mov    %r13,%rsi
  421d54:	lea    -0x38e0(%rbp),%rdx
  421d5b:	mov    %rdi,%r13
  421d5e:	callq  4378a0 <p125_rt_take3>
  421d63:	mov    %r15,%rsi
  421d66:	mov    %r13,%rdi
  421d69:	mov    -0xb8(%rbp),%r15
  421d70:	mov    -0x38e0(%rbp),%r8
  421d77:	mov    %r8,-0xa0(%rbp)
  421d7e:	mov    -0x38d8(%rbp),%r13
  421d85:	mov    -0x38d0(%rbp),%rax
  421d8c:	mov    %rax,-0x90(%rbp)
  421d93:	cmp    $0x8,%r15
  421d97:	je     421e4d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x18bd>
  421d9d:	mov    %rsi,%r15
  421da0:	mov    %rbx,%rsi
  421da3:	mov    %rdi,%rbx
  421da6:	callq  4318a0 <p111_rt_sink>
  421dab:	mov    %r15,%rsi
  421dae:	mov    %rbx,%rdi
  421db1:	mov    -0x90(%rbp),%r15
  421db8:	mov    %rdi,%rbx
  421dbb:	callq  4318a0 <p111_rt_sink>
  421dc0:	mov    %r13,%rsi
  421dc3:	mov    %rbx,%rdi
  421dc6:	mov    %r14,%rbx
  421dc9:	mov    -0xa0(%rbp),%r14
  421dd0:	mov    %rsi,%r13
  421dd3:	mov    %rbx,%rsi
  421dd6:	mov    %rdi,%rbx
  421dd9:	callq  4318a0 <p111_rt_sink>
  421dde:	mov    %r14,%r8
  421de1:	mov    %r13,%rsi
  421de4:	mov    %rbx,%rdi
  421de7:	mov    %rsi,%r13
  421dea:	mov    %r8,%rsi
  421ded:	mov    %rdi,%rbx
  421df0:	callq  4318a0 <p111_rt_sink>
  421df5:	mov    %r13,%rsi
  421df8:	mov    %rbx,%rdi
  421dfb:	mov    %rsi,%r13
  421dfe:	mov    %rdi,%rbx
  421e01:	callq  4318a0 <p111_rt_sink>
  421e06:	mov    %r12,%rsi
  421e09:	mov    %rbx,%rdi
  421e0c:	mov    %rsi,%r12
  421e0f:	mov    %r15,%rsi
  421e12:	mov    %rdi,%rbx
  421e15:	callq  4318a0 <p111_rt_sink>
  421e1a:	mov    %r12,%rsi
  421e1d:	mov    %rbx,%rdi
  421e20:	mov    %rsi,-0x38e0(%rbp)
  421e27:	mov    0x10(%rdi),%rax
  421e2b:	mov    %rsi,(%rax)
  421e2e:	movq   $0x163,0x8(%rax)
  421e36:	add    $0x10,%rax
  421e3a:	mov    %rax,0x10(%rdi)
  421e3e:	mov    $0x4,%esi
  421e43:	callq  432030 <p111_rt_fail>
  421e48:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421e4d:	cs cs mov %rsi,%r15
  421e52:	mov    %r12,%rsi
  421e55:	lea    -0x38e0(%rbp),%rdx
  421e5c:	mov    %rsi,%r12
  421e5f:	mov    %rdi,%r12
  421e62:	callq  437640 <p125_rt_take2>
  421e67:	mov    %r15,%rsi
  421e6a:	mov    %r12,%rdi
  421e6d:	mov    -0x90(%rbp),%r15
  421e74:	mov    -0xa0(%rbp),%r8
  421e7b:	mov    -0x38e0(%rbp),%r12
  421e82:	mov    %r12,-0xb0(%rbp)
  421e89:	mov    -0x38d8(%rbp),%rcx
  421e90:	mov    %rcx,-0x98(%rbp)
  421e97:	cmp    $0x1,%rcx
  421e9b:	sete   %al
  421e9e:	movzbl %al,%eax
  421ea1:	shr    $0x28,%rcx
  421ea5:	and    $0x7fffff,%rcx
  421eac:	cmp    $0x10002,%rcx
  421eb3:	sete   %cl
  421eb6:	movzbl %cl,%ecx
  421eb9:	mov    %eax,%edx
  421ebb:	or     %ecx,%edx
  421ebd:	xor    $0x1,%edx
  421ec0:	jne    422145 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1bb5>
  421ec6:	or     %ecx,%eax
  421ec8:	jne    421f87 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x19f7>
  421ece:	mov    %rsi,%r12
  421ed1:	mov    %rbx,%rsi
  421ed4:	mov    %rdi,%rbx
  421ed7:	callq  4318a0 <p111_rt_sink>
  421edc:	mov    %r12,%rsi
  421edf:	mov    %rbx,%rdi
  421ee2:	mov    %r14,%r12
  421ee5:	mov    -0xa0(%rbp),%r14
  421eec:	mov    %rdi,%rbx
  421eef:	callq  4318a0 <p111_rt_sink>
  421ef4:	mov    %r13,%rsi
  421ef7:	mov    %rbx,%rdi
  421efa:	mov    -0x98(%rbp),%rbx
  421f01:	mov    %rsi,%r13
  421f04:	mov    %r12,%rsi
  421f07:	mov    %rdi,%r12
  421f0a:	callq  4318a0 <p111_rt_sink>
  421f0f:	mov    %r14,%r8
  421f12:	mov    %r13,%rsi
  421f15:	mov    %r12,%rdi
  421f18:	mov    -0xb0(%rbp),%r12
  421f1f:	mov    %rsi,%r14
  421f22:	mov    %r8,%rsi
  421f25:	mov    %rdi,%r13
  421f28:	callq  4318a0 <p111_rt_sink>
  421f2d:	mov    %r14,%rsi
  421f30:	mov    %r13,%rdi
  421f33:	mov    %rdi,%r13
  421f36:	callq  4318a0 <p111_rt_sink>
  421f3b:	mov    %r13,%rdi
  421f3e:	mov    %r15,%rsi
  421f41:	mov    %rdi,%r13
  421f44:	callq  4318a0 <p111_rt_sink>
  421f49:	mov    %r13,%rdi
  421f4c:	mov    %r12,%rsi
  421f4f:	mov    %rdi,%r12
  421f52:	callq  4318a0 <p111_rt_sink>
  421f57:	mov    %r12,%rdi
  421f5a:	mov    %rbx,-0x38e0(%rbp)
  421f61:	mov    0x10(%rdi),%rax
  421f65:	mov    %rbx,(%rax)
  421f68:	movq   $0x162,0x8(%rax)
  421f70:	add    $0x10,%rax
  421f74:	mov    %rax,0x10(%rdi)
  421f78:	mov    $0x4,%esi
  421f7d:	callq  432030 <p111_rt_fail>
  421f82:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  421f87:	xchg   %r13,%rsi
  421f8a:	mov    %r13,-0x38e0(%rbp)
  421f91:	mov    %r14,-0x38d8(%rbp)
  421f98:	mov    0x8(%rdi),%r10
  421f9c:	mov    0x8(%r10),%rax
  421fa0:	cmp    $0x0,%rax
  421fa4:	jne    421fd2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a42>
  421fa6:	mov    %r8,%r14
  421fa9:	lea    -0x38e0(%rbp),%rdx
  421fb0:	mov    %rsi,%r13
  421fb3:	mov    $0x2c,%esi
  421fb8:	mov    %rdi,%r12
  421fbb:	callq  437550 <p125_rt_ctor2>
  421fc0:	mov    %r14,%r8
  421fc3:	mov    %r13,%rsi
  421fc6:	mov    %r12,%rdi
  421fc9:	mov    -0xb0(%rbp),%r12
  421fd0:	jmp    42200c <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a7c>
  421fd2:	mov    (%rdi),%rcx
  421fd5:	mov    %rax,%rdx
  421fd8:	shl    $0x3,%rdx
  421fdc:	mov    (%rcx,%rdx,1),%r11
  421fe0:	mov    0x108(%r10),%r9
  421fe7:	mov    %r11,0x8(%r10)
  421feb:	sub    $0x2,%r9
  421fef:	mov    %r9,0x108(%r10)
  421ff6:	mov    %r13,(%rcx,%rdx,1)
  421ffa:	mov    %r14,0x8(%rcx,%rdx,1)
  421fff:	movabs $0x2002c0000000000,%rcx
  422009:	or     %rcx,%rax
  42200c:	mov    %rbx,-0x38e0(%rbp)
  422013:	mov    %rax,-0x38d8(%rbp)
  42201a:	mov    0x10(%rdi),%rax
  42201e:	mov    %rbx,(%rax)
  422021:	mov    -0x38d8(%rbp),%rcx
  422028:	mov    %rcx,0x8(%rax)
  42202c:	movq   $0x160,0x10(%rax)
  422034:	add    $0x18,%rax
  422038:	mov    %rax,0x10(%rdi)
  42203c:	mov    %rsi,%r13
  42203f:	mov    %r8,%rsi
  422042:	mov    %rdi,%rbx
  422045:	callq  431810 <p111_rt_keep>
  42204a:	mov    %r13,%rsi
  42204d:	mov    %rbx,%rdi
  422050:	mov    %rax,%rdx
  422053:	mov    %rdx,-0x38e0(%rbp)
  42205a:	mov    %rsi,-0x38d8(%rbp)
  422061:	mov    %r15,-0x38d0(%rbp)
  422068:	mov    0x8(%rdi),%r9
  42206c:	mov    0x10(%r9),%rax
  422070:	cmp    $0x0,%rax
  422074:	jne    422098 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b08>
  422076:	mov    %rdx,%r13
  422079:	lea    -0x38e0(%rbp),%rdx
  422080:	mov    $0x2d,%esi
  422085:	mov    %rdi,%rbx
  422088:	callq  4377d0 <p125_rt_ctor3>
  42208d:	mov    %r13,%rdx
  422090:	mov    %rbx,%rdi
  422093:	mov    %rax,%rbx
  422096:	jmp    4220dd <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b4d>
  422098:	mov    (%rdi),%rcx
  42209b:	mov    %rsi,%r13
  42209e:	mov    %rax,%rsi
  4220a1:	shl    $0x3,%rsi
  4220a5:	mov    (%rcx,%rsi,1),%r10
  4220a9:	mov    0x110(%r9),%r8
  4220b0:	mov    %r10,0x10(%r9)
  4220b4:	sub    $0x4,%r8
  4220b8:	mov    %r8,0x110(%r9)
  4220bf:	mov    %rdx,(%rcx,%rsi,1)
  4220c3:	mov    %r13,0x8(%rcx,%rsi,1)
  4220c8:	mov    %r15,0x10(%rcx,%rsi,1)
  4220cd:	movabs $0x2002d0000000000,%rcx
  4220d7:	mov    %rax,%rbx
  4220da:	or     %rcx,%rbx
  4220dd:	mov    %r12,%rsi
  4220e0:	mov    %rdi,%r12
  4220e3:	callq  4053c0 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  4220e8:	mov    %r12,%rdi
  4220eb:	mov    %rbx,-0x28e0(%rbp)
  4220f2:	mov    %rax,-0x28d8(%rbp)
  4220f9:	mov    0x1db38(%rip),%rcx        # 43fc38 <p111_program+0x58>
  422100:	test   $0x4,%rcx
  422107:	jne    422125 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b95>
  422109:	cs mov $0x2,%ecx
  42210f:	lea    -0x28e0(%rbp),%rdx
  422116:	mov    $0x151,%esi
  42211b:	callq  431e60 <p111_rt_jump>
  422120:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  422125:	mov    %rbx,0x28(%rdi)
  422129:	mov    %rax,0x30(%rdi)
  42212d:	movl   $0x0,0x1c(%rdi)
  422134:	movl   $0x151,0x20(%rdi)
  42213b:	mov    $0x0,%eax
  422140:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  422145:	mov    %rdi,%r12
  422148:	callq  431810 <p111_rt_keep>
  42214d:	mov    %r13,%rsi
  422150:	mov    %r12,%rdi
  422153:	mov    %rax,%r13
  422156:	mov    -0xb0(%rbp),%r12
  42215d:	mov    -0xa0(%rbp),%r8
  422164:	mov    %r13,-0xa8(%rbp)
  42216b:	mov    %r13,-0x38e0(%rbp)
  422172:	mov    %r14,-0x38d8(%rbp)
  422179:	mov    0x8(%rdi),%r10
  42217d:	mov    0x8(%r10),%rax
  422181:	cmp    $0x0,%rax
  422185:	jne    4221c2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1c32>
  422187:	cs cs mov %r8,%r14
  42218c:	lea    -0x38e0(%rbp),%rdx
  422193:	mov    %rsi,%r13
  422196:	mov    $0x2c,%esi
  42219b:	mov    %rdi,%r12
  42219e:	callq  437550 <p125_rt_ctor2>
  4221a3:	mov    %r14,%r8
  4221a6:	mov    %r13,%rsi
  4221a9:	mov    %r12,%rdi
  4221ac:	mov    %rax,%r14
  4221af:	mov    -0xa8(%rbp),%r13
  4221b6:	mov    -0xb0(%rbp),%r12
  4221bd:	xchg   %rbx,%r14
  4221c0:	jmp    422203 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1c73>
  4221c2:	mov    %cs:(%rdi),%rcx
  4221c6:	mov    %rax,%rdx
  4221c9:	shl    $0x3,%rdx
  4221cd:	mov    (%rcx,%rdx,1),%r11
  4221d1:	mov    0x108(%r10),%r9
  4221d8:	mov    %r11,0x8(%r10)
  4221dc:	sub    $0x2,%r9
  4221e0:	mov    %r9,0x108(%r10)
  4221e7:	mov    %r13,(%rcx,%rdx,1)
  4221eb:	mov    %r14,0x8(%rcx,%rdx,1)
  4221f0:	movabs $0x2002c0000000000,%rcx
  4221fa:	mov    %rbx,%r14
  4221fd:	mov    %rax,%rbx
  422200:	or     %rcx,%rbx
  422203:	mov    %r8,-0x38e0(%rbp)
  42220a:	mov    %rsi,-0x38d8(%rbp)
  422211:	mov    %r15,-0x38d0(%rbp)
  422218:	mov    0x8(%rdi),%r10
  42221c:	mov    0x10(%r10),%rax
  422220:	cmp    $0x0,%rax
  422224:	jne    422242 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1cb2>
  422226:	lea    -0x38e0(%rbp),%rdx
  42222d:	mov    $0x2d,%esi
  422232:	mov    %rdi,%r15
  422235:	callq  4377d0 <p125_rt_ctor3>
  42223a:	mov    %r15,%rdi
  42223d:	mov    %rax,%rcx
  422240:	jmp    422283 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1cf3>
  422242:	cs mov %cs:(%rdi),%rcx
  422247:	mov    %rax,%rdx
  42224a:	shl    $0x3,%rdx
  42224e:	mov    (%rcx,%rdx,1),%r11
  422252:	mov    0x110(%r10),%r9
  422259:	mov    %r11,0x10(%r10)
  42225d:	sub    $0x4,%r9
  422261:	mov    %r9,0x110(%r10)
  422268:	mov    %r8,(%rcx,%rdx,1)
  42226c:	mov    %rsi,0x8(%rcx,%rdx,1)
  422271:	mov    %r15,0x10(%rcx,%rdx,1)
  422276:	movabs $0x2002d0000000000,%rcx
  422280:	or     %rax,%rcx
  422283:	mov    %r14,-0x38e0(%rbp)
  42228a:	mov    %rbx,-0x38d8(%rbp)
  422291:	mov    %rcx,-0x38d0(%rbp)
  422298:	mov    0x8(%rdi),%r9
  42229c:	mov    0x10(%r9),%rax
  4222a0:	cmp    $0x0,%rax
  4222a4:	jne    4222c2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d32>
  4222a6:	lea    -0x38e0(%rbp),%rdx
  4222ad:	mov    $0x2d,%esi
  4222b2:	mov    %rdi,%rbx
  4222b5:	callq  4377d0 <p125_rt_ctor3>
  4222ba:	mov    %rbx,%rdi
  4222bd:	mov    %rax,%rbx
  4222c0:	jmp    422304 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d74>
  4222c2:	mov    (%rdi),%rdx
  4222c5:	mov    %rax,%rsi
  4222c8:	shl    $0x3,%rsi
  4222cc:	mov    (%rdx,%rsi,1),%r10
  4222d0:	mov    0x110(%r9),%r8
  4222d7:	mov    %r10,0x10(%r9)
  4222db:	sub    $0x4,%r8
  4222df:	mov    %r8,0x110(%r9)
  4222e6:	mov    %r14,(%rdx,%rsi,1)
  4222ea:	mov    %rbx,0x8(%rdx,%rsi,1)
  4222ef:	mov    %rcx,0x10(%rdx,%rsi,1)
  4222f4:	movabs $0x2002d0000000000,%rcx
  4222fe:	mov    %rax,%rbx
  422301:	or     %rcx,%rbx
  422304:	mov    %r13,-0x38e0(%rbp)
  42230b:	mov    0x8(%rdi),%r8
  42230f:	mov    (%r8),%rax
  422312:	cmp    $0x0,%rax
  422316:	jne    422334 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1da4>
  422318:	lea    -0x38e0(%rbp),%rdx
  42231f:	mov    $0xc,%esi
  422324:	mov    %rdi,%r13
  422327:	callq  437320 <p125_rt_ctor1>
  42232c:	mov    %r13,%rdi
  42232f:	mov    %rax,%rcx
  422332:	jmp    42236a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1dda>
  422334:	cs mov %cs:(%rdi),%rcx
  422339:	mov    %rax,%rdx
  42233c:	shl    $0x3,%rdx
  422340:	mov    (%rcx,%rdx,1),%r9
  422344:	mov    0x100(%r8),%rsi
  42234b:	mov    %r9,(%r8)
  42234e:	sub    $0x1,%rsi
  422352:	mov    %rsi,0x100(%r8)
  422359:	mov    %r13,(%rcx,%rdx,1)
  42235d:	movabs $0x2000c0000000000,%rcx
  422367:	or     %rax,%rcx
  42236a:	mov    %r12,-0x38e0(%rbp)
  422371:	mov    %rcx,-0x38d8(%rbp)
  422378:	mov    0x8(%rdi),%r9
  42237c:	mov    0x8(%r9),%rax
  422380:	cmp    $0x0,%rax
  422384:	jne    4223a2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e12>
  422386:	lea    -0x38e0(%rbp),%rdx
  42238d:	mov    $0x8,%esi
  422392:	mov    %rdi,%r12
  422395:	callq  437550 <p125_rt_ctor2>
  42239a:	mov    %r12,%rdi
  42239d:	mov    %rax,%rcx
  4223a0:	jmp    4223dc <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e4c>
  4223a2:	mov    (%rdi),%rdx
  4223a5:	mov    %rax,%rsi
  4223a8:	shl    $0x3,%rsi
  4223ac:	mov    (%rdx,%rsi,1),%r10
  4223b0:	mov    0x108(%r9),%r8
  4223b7:	mov    %r10,0x8(%r9)
  4223bb:	sub    $0x2,%r8
  4223bf:	mov    %r8,0x108(%r9)
  4223c6:	mov    %r12,(%rdx,%rsi,1)
  4223ca:	mov    %rcx,0x8(%rdx,%rsi,1)
  4223cf:	movabs $0x200080000000000,%rcx
  4223d9:	or     %rax,%rcx
  4223dc:	mov    %rbx,-0x38e0(%rbp)
  4223e3:	mov    %rcx,-0x38d8(%rbp)
  4223ea:	mov    0x8(%rdi),%r9
  4223ee:	mov    0x8(%r9),%rax
  4223f2:	cmp    $0x0,%rax
  4223f6:	jne    422411 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e81>
  4223f8:	lea    -0x38e0(%rbp),%rdx
  4223ff:	mov    $0x8,%esi
  422404:	mov    %rdi,%rbx
  422407:	callq  437550 <p125_rt_ctor2>
  42240c:	mov    %rbx,%rdi
  42240f:	jmp    422452 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ec2>
  422411:	cs cs cs mov %cs:(%rdi),%rdx
  422418:	cs cs cs mov %rax,%rsi
  42241e:	shl    $0x3,%rsi
  422422:	mov    (%rdx,%rsi,1),%r10
  422426:	mov    0x108(%r9),%r8
  42242d:	mov    %r10,0x8(%r9)
  422431:	sub    $0x2,%r8
  422435:	mov    %r8,0x108(%r9)
  42243c:	mov    %rbx,(%rdx,%rsi,1)
  422440:	mov    %rcx,0x8(%rdx,%rsi,1)
  422445:	movabs $0x200080000000000,%rcx
  42244f:	or     %rcx,%rax
  422452:	mov    %rax,-0x38e0(%rbp)
  422459:	mov    0x1d7d8(%rip),%rcx        # 43fc38 <p111_program+0x58>
  422460:	test   $0x4,%rcx
  422467:	jne    42247f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1eef>
  422469:	mov    $0x1,%edx
  42246e:	lea    -0x38e0(%rbp),%rsi
  422475:	callq  431ec0 <p111_rt_return>
  42247a:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  42247f:	mov    %rax,0x28(%rdi)
  422483:	movl   $0x1,0x1c(%rdi)
  42248a:	mov    0x10(%rdi),%rax
  42248e:	mov    %rax,%rcx
  422491:	add    $0xfffffffffffffff8,%rcx
  422495:	mov    %rcx,0x10(%rdi)
  422499:	mov    -0x8(%rax),%rax
  42249d:	mov    %eax,0x20(%rdi)
  4224a0:	mov    $0x0,%eax
  4224a5:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4224aa:	mov    %rsi,%r15
  4224ad:	mov    %r13,%rsi
  4224b0:	lea    -0x38e0(%rbp),%rdx
  4224b7:	mov    %rdi,%r13
  4224ba:	callq  437640 <p125_rt_take2>
  4224bf:	mov    %r15,%rsi
  4224c2:	mov    %r13,%rdi
  4224c5:	mov    -0xb8(%rbp),%r13
  4224cc:	mov    -0x38e0(%rbp),%r15
  4224d3:	mov    %r15,-0xc0(%rbp)
  4224da:	mov    -0x38d8(%rbp),%r15
  4224e1:	cmp    $0x8,%r13
  4224e5:	je     42257a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1fea>
  4224eb:	mov    %rsi,%r13
  4224ee:	mov    %rbx,%rsi
  4224f1:	mov    %rdi,%rbx
  4224f4:	callq  4318a0 <p111_rt_sink>
  4224f9:	mov    %r13,%rsi
  4224fc:	mov    %rbx,%rdi
  4224ff:	mov    -0xc0(%rbp),%r13
  422506:	mov    %rdi,%rbx
  422509:	callq  4318a0 <p111_rt_sink>
  42250e:	mov    %r13,%rsi
  422511:	mov    %rbx,%rdi
  422514:	mov    %rsi,%r13
  422517:	mov    %r14,%rsi
  42251a:	mov    %rdi,%rbx
  42251d:	callq  4318a0 <p111_rt_sink>
  422522:	mov    %r13,%rsi
  422525:	mov    %rbx,%rdi
  422528:	mov    %rsi,%r14
  42252b:	mov    %rdi,%rbx
  42252e:	callq  4318a0 <p111_rt_sink>
  422533:	mov    %r12,%rsi
  422536:	mov    %rbx,%rdi
  422539:	mov    %rsi,%r12
  42253c:	mov    %r15,%rsi
  42253f:	mov    %rdi,%rbx
  422542:	callq  4318a0 <p111_rt_sink>
  422547:	mov    %r12,%rsi
  42254a:	mov    %rbx,%rdi
  42254d:	mov    %rsi,-0x38e0(%rbp)
  422554:	mov    0x10(%rdi),%rax
  422558:	mov    %rsi,(%rax)
  42255b:	movq   $0x15f,0x8(%rax)
  422563:	add    $0x10,%rax
  422567:	mov    %rax,0x10(%rdi)
  42256b:	mov    $0x4,%esi
  422570:	callq  432030 <p111_rt_fail>
  422575:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  42257a:	mov    %rsi,%r13
  42257d:	mov    %r12,%rsi
  422580:	lea    -0x38e0(%rbp),%rdx
  422587:	mov    %rsi,%r12
  42258a:	mov    %rdi,%r12
  42258d:	callq  437640 <p125_rt_take2>
  422592:	mov    %r13,%rsi
  422595:	mov    %r12,%rdi
  422598:	mov    %r14,%r13
  42259b:	mov    -0xc0(%rbp),%r14
  4225a2:	mov    -0x38e0(%rbp),%r12
  4225a9:	mov    %r12,-0xd0(%rbp)
  4225b0:	mov    -0x38d8(%rbp),%rcx
  4225b7:	mov    %rcx,-0xc8(%rbp)
  4225be:	cmp    $0x1,%rcx
  4225c2:	sete   %al
  4225c5:	movzbl %al,%eax
  4225c8:	shr    $0x28,%rcx
  4225cc:	and    $0x7fffff,%rcx
  4225d3:	cmp    $0x10002,%rcx
  4225da:	sete   %cl
  4225dd:	movzbl %cl,%ecx
  4225e0:	mov    %eax,%edx
  4225e2:	or     %ecx,%edx
  4225e4:	xor    $0x1,%edx
  4225e7:	jne    4229ba <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x242a>
  4225ed:	or     %ecx,%eax
  4225ef:	jne    42268d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x20fd>
  4225f5:	mov    %rsi,%r12
  4225f8:	mov    %rbx,%rsi
  4225fb:	mov    %rdi,%rbx
  4225fe:	callq  4318a0 <p111_rt_sink>
  422603:	mov    %r12,%rsi
  422606:	mov    %rbx,%rdi
  422609:	mov    -0xd0(%rbp),%r12
  422610:	mov    %rdi,%rbx
  422613:	callq  4318a0 <p111_rt_sink>
  422618:	mov    %r14,%rsi
  42261b:	mov    %rbx,%rdi
  42261e:	mov    -0xc8(%rbp),%rbx
  422625:	mov    %rsi,%r14
  422628:	mov    %r13,%rsi
  42262b:	mov    %rdi,%r13
  42262e:	callq  4318a0 <p111_rt_sink>
  422633:	mov    %r14,%rsi
  422636:	mov    %r13,%rdi
  422639:	mov    %rdi,%r13
  42263c:	callq  4318a0 <p111_rt_sink>
  422641:	mov    %r13,%rdi
  422644:	mov    %r15,%rsi
  422647:	mov    %rdi,%r13
  42264a:	callq  4318a0 <p111_rt_sink>
  42264f:	mov    %r13,%rdi
  422652:	mov    %r12,%rsi
  422655:	mov    %rdi,%r12
  422658:	callq  4318a0 <p111_rt_sink>
  42265d:	mov    %r12,%rdi
  422660:	mov    %rbx,-0x38e0(%rbp)
  422667:	mov    0x10(%rdi),%rax
  42266b:	mov    %rbx,(%rax)
  42266e:	movq   $0x15e,0x8(%rax)
  422676:	add    $0x10,%rax
  42267a:	mov    %rax,0x10(%rdi)
  42267e:	mov    $0x4,%esi
  422683:	callq  432030 <p111_rt_fail>
  422688:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  42268d:	xchg   %r14,%rsi
  422690:	xchg   %r13,%r14
  422693:	mov    %r13,-0x38e0(%rbp)
  42269a:	mov    %r14,-0x38d8(%rbp)
  4226a1:	mov    0x8(%rdi),%r9
  4226a5:	mov    0x8(%r9),%rax
  4226a9:	cmp    $0x0,%rax
  4226ad:	jne    4226d7 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2147>
  4226af:	lea    -0x38e0(%rbp),%rdx
  4226b6:	mov    %rsi,%r14
  4226b9:	mov    $0x2c,%esi
  4226be:	mov    %rdi,%r13
  4226c1:	callq  437550 <p125_rt_ctor2>
  4226c6:	mov    %r14,%rsi
  4226c9:	mov    %r13,%rdi
  4226cc:	mov    %rax,%r13
  4226cf:	mov    %rbx,%r14
  4226d2:	mov    %r13,%rbx
  4226d5:	jmp    422719 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2189>
  4226d7:	cs mov %cs:(%rdi),%rcx
  4226dc:	mov    %rax,%rdx
  4226df:	shl    $0x3,%rdx
  4226e3:	mov    (%rcx,%rdx,1),%r10
  4226e7:	mov    0x108(%r9),%r8
  4226ee:	mov    %r10,0x8(%r9)
  4226f2:	sub    $0x2,%r8
  4226f6:	mov    %r8,0x108(%r9)
  4226fd:	mov    %r13,(%rcx,%rdx,1)
  422701:	mov    %r14,0x8(%rcx,%rdx,1)
  422706:	movabs $0x2002c0000000000,%rcx
  422710:	mov    %rbx,%r14
  422713:	mov    %rax,%rbx
  422716:	or     %rcx,%rbx
  422719:	mov    %rsi,%r13
  42271c:	mov    %rdi,%r13
  42271f:	callq  431810 <p111_rt_keep>
  422724:	mov    %r13,%rdi
  422727:	mov    %rax,%r13
  42272a:	mov    %r13,-0x38e0(%rbp)
  422731:	mov    %r15,-0x38d8(%rbp)
  422738:	mov    0x8(%rdi),%r8
  42273c:	mov    0x8(%r8),%rax
  422740:	cmp    $0x0,%rax
  422744:	jne    422762 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x21d2>
  422746:	lea    -0x38e0(%rbp),%rdx
  42274d:	mov    $0x2c,%esi
  422752:	mov    %rdi,%r15
  422755:	callq  437550 <p125_rt_ctor2>
  42275a:	mov    %r15,%rdi
  42275d:	mov    %rax,%rcx
  422760:	jmp    42279c <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x220c>
  422762:	mov    (%rdi),%rcx
  422765:	mov    %rax,%rdx
  422768:	shl    $0x3,%rdx
  42276c:	mov    (%rcx,%rdx,1),%r9
  422770:	mov    0x108(%r8),%rsi
  422777:	mov    %r9,0x8(%r8)
  42277b:	sub    $0x2,%rsi
  42277f:	mov    %rsi,0x108(%r8)
  422786:	mov    %r13,(%rcx,%rdx,1)
  42278a:	mov    %r15,0x8(%rcx,%rdx,1)
  42278f:	movabs $0x2002c0000000000,%rcx
  422799:	or     %rax,%rcx
  42279c:	mov    %r14,-0x38e0(%rbp)
  4227a3:	mov    %rbx,-0x38d8(%rbp)
  4227aa:	mov    %rcx,-0x38d0(%rbp)
  4227b1:	mov    0x8(%rdi),%r9
  4227b5:	mov    0x10(%r9),%rax
  4227b9:	cmp    $0x0,%rax
  4227bd:	jne    4227db <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x224b>
  4227bf:	lea    -0x38e0(%rbp),%rdx
  4227c6:	mov    $0x2d,%esi
  4227cb:	mov    %rdi,%rbx
  4227ce:	callq  4377d0 <p125_rt_ctor3>
  4227d3:	mov    %rbx,%rdi
  4227d6:	mov    %rax,%rbx
  4227d9:	jmp    42281d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x228d>
  4227db:	mov    (%rdi),%rdx
  4227de:	mov    %rax,%rsi
  4227e1:	shl    $0x3,%rsi
  4227e5:	mov    (%rdx,%rsi,1),%r10
  4227e9:	mov    0x110(%r9),%r8
  4227f0:	mov    %r10,0x10(%r9)
  4227f4:	sub    $0x4,%r8
  4227f8:	mov    %r8,0x110(%r9)
  4227ff:	mov    %r14,(%rdx,%rsi,1)
  422803:	mov    %rbx,0x8(%rdx,%rsi,1)
  422808:	mov    %rcx,0x10(%rdx,%rsi,1)
  42280d:	movabs $0x2002d0000000000,%rcx
  422817:	mov    %rax,%rbx
  42281a:	or     %rcx,%rbx
  42281d:	mov    %r13,-0x38e0(%rbp)
  422824:	mov    0x8(%rdi),%r8
  422828:	mov    (%r8),%rax
  42282b:	cmp    $0x0,%rax
  42282f:	jne    42284d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x22bd>
  422831:	lea    -0x38e0(%rbp),%rdx
  422838:	mov    $0xc,%esi
  42283d:	mov    %rdi,%r13
  422840:	callq  437320 <p125_rt_ctor1>
  422845:	mov    %r13,%rdi
  422848:	mov    %rax,%rcx
  42284b:	jmp    422881 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x22f1>
  42284d:	mov    (%rdi),%rcx
  422850:	mov    %rax,%rdx
  422853:	shl    $0x3,%rdx
  422857:	mov    (%rcx,%rdx,1),%r9
  42285b:	mov    0x100(%r8),%rsi
  422862:	mov    %r9,(%r8)
  422865:	sub    $0x1,%rsi
  422869:	mov    %rsi,0x100(%r8)
  422870:	mov    %r13,(%rcx,%rdx,1)
  422874:	movabs $0x2000c0000000000,%rcx
  42287e:	or     %rax,%rcx
  422881:	mov    %r12,-0x38e0(%rbp)
  422888:	mov    %rcx,-0x38d8(%rbp)
  42288f:	mov    0x8(%rdi),%r9
  422893:	mov    0x8(%r9),%rax
  422897:	cmp    $0x0,%rax
  42289b:	jne    4228b9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2329>
  42289d:	lea    -0x38e0(%rbp),%rdx
  4228a4:	mov    $0x8,%esi
  4228a9:	mov    %rdi,%r12
  4228ac:	callq  437550 <p125_rt_ctor2>
  4228b1:	mov    %r12,%rdi
  4228b4:	mov    %rax,%rcx
  4228b7:	jmp    4228f3 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2363>
  4228b9:	mov    (%rdi),%rdx
  4228bc:	mov    %rax,%rsi
  4228bf:	shl    $0x3,%rsi
  4228c3:	mov    (%rdx,%rsi,1),%r10
  4228c7:	mov    0x108(%r9),%r8
  4228ce:	mov    %r10,0x8(%r9)
  4228d2:	sub    $0x2,%r8
  4228d6:	mov    %r8,0x108(%r9)
  4228dd:	mov    %r12,(%rdx,%rsi,1)
  4228e1:	mov    %rcx,0x8(%rdx,%rsi,1)
  4228e6:	movabs $0x200080000000000,%rcx
  4228f0:	or     %rax,%rcx
  4228f3:	mov    %rbx,-0x38e0(%rbp)
  4228fa:	mov    %rcx,-0x38d8(%rbp)
  422901:	mov    0x8(%rdi),%r9
  422905:	mov    0x8(%r9),%rax
  422909:	cmp    $0x0,%rax
  42290d:	jne    422928 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2398>
  42290f:	lea    -0x38e0(%rbp),%rdx
  422916:	mov    $0x8,%esi
  42291b:	mov    %rdi,%rbx
  42291e:	callq  437550 <p125_rt_ctor2>
  422923:	mov    %rbx,%rdi
  422926:	jmp    422962 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x23d2>
  422928:	mov    (%rdi),%rdx
  42292b:	mov    %rax,%rsi
  42292e:	shl    $0x3,%rsi
  422932:	mov    (%rdx,%rsi,1),%r10
  422936:	mov    0x108(%r9),%r8
  42293d:	mov    %r10,0x8(%r9)
  422941:	sub    $0x2,%r8
  422945:	mov    %r8,0x108(%r9)
  42294c:	mov    %rbx,(%rdx,%rsi,1)
  422950:	mov    %rcx,0x8(%rdx,%rsi,1)
  422955:	movabs $0x200080000000000,%rcx
  42295f:	or     %rcx,%rax
  422962:	mov    %rax,-0x38e0(%rbp)
  422969:	mov    0x1d2c8(%rip),%rcx        # 43fc38 <p111_program+0x58>
  422970:	test   $0x4,%rcx
  422977:	jne    42298f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x23ff>
  422979:	mov    $0x1,%edx
  42297e:	lea    -0x38e0(%rbp),%rsi
  422985:	callq  431ec0 <p111_rt_return>
  42298a:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  42298f:	mov    %rax,0x28(%rdi)
  422993:	movl   $0x1,0x1c(%rdi)
  42299a:	mov    0x10(%rdi),%rax
  42299e:	mov    %rax,%rcx
  4229a1:	add    $0xfffffffffffffff8,%rcx
  4229a5:	mov    %rcx,0x10(%rdi)
  4229a9:	mov    -0x8(%rax),%rax
  4229ad:	mov    %eax,0x20(%rdi)
  4229b0:	mov    $0x0,%eax
  4229b5:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4229ba:	xchg   %r14,%r13
  4229bd:	mov    %rdi,%r12
  4229c0:	callq  431810 <p111_rt_keep>
  4229c5:	mov    %r13,%rsi
  4229c8:	mov    %r12,%rdi
  4229cb:	mov    %rax,%r13
  4229ce:	mov    -0xd0(%rbp),%r12
  4229d5:	mov    %r13,-0xd8(%rbp)
  4229dc:	mov    %r13,-0x38e0(%rbp)
  4229e3:	mov    %r14,-0x38d8(%rbp)
  4229ea:	mov    0x8(%rdi),%r9
  4229ee:	mov    0x8(%r9),%rax
  4229f2:	cmp    $0x0,%rax
  4229f6:	jne    422a24 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2494>
  4229f8:	lea    -0x38e0(%rbp),%rdx
  4229ff:	mov    %rsi,%r14
  422a02:	mov    $0x2c,%esi
  422a07:	mov    %rdi,%r13
  422a0a:	callq  437550 <p125_rt_ctor2>
  422a0f:	mov    %r14,%rsi
  422a12:	mov    %r13,%rdi
  422a15:	mov    %rax,%r14
  422a18:	mov    -0xd8(%rbp),%r13
  422a1f:	xchg   %rbx,%r14
  422a22:	jmp    422a6a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x24da>
  422a24:	cs cs cs mov %cs:(%rdi),%rcx
  422a2b:	cs cs mov %rax,%rdx
  422a30:	shl    $0x3,%rdx
  422a34:	mov    (%rcx,%rdx,1),%r10
  422a38:	mov    0x108(%r9),%r8
  422a3f:	mov    %r10,0x8(%r9)
  422a43:	sub    $0x2,%r8
  422a47:	mov    %r8,0x108(%r9)
  422a4e:	mov    %r13,(%rcx,%rdx,1)
  422a52:	mov    %r14,0x8(%rcx,%rdx,1)
  422a57:	movabs $0x2002c0000000000,%rcx
  422a61:	mov    %rbx,%r14
  422a64:	mov    %rax,%rbx
  422a67:	or     %rcx,%rbx
  422a6a:	mov    %rsi,-0x38e0(%rbp)
  422a71:	mov    %r15,-0x38d8(%rbp)
  422a78:	mov    0x8(%rdi),%r9
  422a7c:	mov    0x8(%r9),%rax
  422a80:	cmp    $0x0,%rax
  422a84:	jne    422aa2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2512>
  422a86:	lea    -0x38e0(%rbp),%rdx
  422a8d:	mov    $0x2c,%esi
  422a92:	mov    %rdi,%r15
  422a95:	callq  437550 <p125_rt_ctor2>
  422a9a:	mov    %r15,%rdi
  422a9d:	mov    %rax,%rcx
  422aa0:	jmp    422adc <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x254c>
  422aa2:	mov    (%rdi),%rcx
  422aa5:	mov    %rax,%rdx
  422aa8:	shl    $0x3,%rdx
  422aac:	mov    (%rcx,%rdx,1),%r10
  422ab0:	mov    0x108(%r9),%r8
  422ab7:	mov    %r10,0x8(%r9)
  422abb:	sub    $0x2,%r8
  422abf:	mov    %r8,0x108(%r9)
  422ac6:	mov    %rsi,(%rcx,%rdx,1)
  422aca:	mov    %r15,0x8(%rcx,%rdx,1)
  422acf:	movabs $0x2002c0000000000,%rcx
  422ad9:	or     %rax,%rcx
  422adc:	mov    %r14,-0x38e0(%rbp)
  422ae3:	mov    %rbx,-0x38d8(%rbp)
  422aea:	mov    %rcx,-0x38d0(%rbp)
  422af1:	mov    0x8(%rdi),%r9
  422af5:	mov    0x10(%r9),%rax
  422af9:	cmp    $0x0,%rax
  422afd:	jne    422b1b <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x258b>
  422aff:	lea    -0x38e0(%rbp),%rdx
  422b06:	mov    $0x2d,%esi
  422b0b:	mov    %rdi,%rbx
  422b0e:	callq  4377d0 <p125_rt_ctor3>
  422b13:	mov    %rbx,%rdi
  422b16:	mov    %rax,%rbx
  422b19:	jmp    422b5d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x25cd>
  422b1b:	mov    (%rdi),%rdx
  422b1e:	mov    %rax,%rsi
  422b21:	shl    $0x3,%rsi
  422b25:	mov    (%rdx,%rsi,1),%r10
  422b29:	mov    0x110(%r9),%r8
  422b30:	mov    %r10,0x10(%r9)
  422b34:	sub    $0x4,%r8
  422b38:	mov    %r8,0x110(%r9)
  422b3f:	mov    %r14,(%rdx,%rsi,1)
  422b43:	mov    %rbx,0x8(%rdx,%rsi,1)
  422b48:	mov    %rcx,0x10(%rdx,%rsi,1)
  422b4d:	movabs $0x2002d0000000000,%rcx
  422b57:	mov    %rax,%rbx
  422b5a:	or     %rcx,%rbx
  422b5d:	mov    %r13,-0x38e0(%rbp)
  422b64:	mov    0x8(%rdi),%r8
  422b68:	mov    (%r8),%rax
  422b6b:	cmp    $0x0,%rax
  422b6f:	jne    422b8d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x25fd>
  422b71:	lea    -0x38e0(%rbp),%rdx
  422b78:	mov    $0xc,%esi
  422b7d:	mov    %rdi,%r13
  422b80:	callq  437320 <p125_rt_ctor1>
  422b85:	mov    %r13,%rdi
  422b88:	mov    %rax,%rcx
  422b8b:	jmp    422bc1 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2631>
  422b8d:	mov    (%rdi),%rcx
  422b90:	mov    %rax,%rdx
  422b93:	shl    $0x3,%rdx
  422b97:	mov    (%rcx,%rdx,1),%r9
  422b9b:	mov    0x100(%r8),%rsi
  422ba2:	mov    %r9,(%r8)
  422ba5:	sub    $0x1,%rsi
  422ba9:	mov    %rsi,0x100(%r8)
  422bb0:	mov    %r13,(%rcx,%rdx,1)
  422bb4:	movabs $0x2000c0000000000,%rcx
  422bbe:	or     %rax,%rcx
  422bc1:	mov    %r12,-0x38e0(%rbp)
  422bc8:	mov    %rcx,-0x38d8(%rbp)
  422bcf:	mov    0x8(%rdi),%r9
  422bd3:	mov    0x8(%r9),%rax
  422bd7:	cmp    $0x0,%rax
  422bdb:	jne    422bf9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2669>
  422bdd:	lea    -0x38e0(%rbp),%rdx
  422be4:	mov    $0x8,%esi
  422be9:	mov    %rdi,%r12
  422bec:	callq  437550 <p125_rt_ctor2>
  422bf1:	mov    %r12,%rdi
  422bf4:	mov    %rax,%rcx
  422bf7:	jmp    422c33 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26a3>
  422bf9:	mov    (%rdi),%rdx
  422bfc:	mov    %rax,%rsi
  422bff:	shl    $0x3,%rsi
  422c03:	mov    (%rdx,%rsi,1),%r10
  422c07:	mov    0x108(%r9),%r8
  422c0e:	mov    %r10,0x8(%r9)
  422c12:	sub    $0x2,%r8
  422c16:	mov    %r8,0x108(%r9)
  422c1d:	mov    %r12,(%rdx,%rsi,1)
  422c21:	mov    %rcx,0x8(%rdx,%rsi,1)
  422c26:	movabs $0x200080000000000,%rcx
  422c30:	or     %rax,%rcx
  422c33:	mov    %rbx,-0x38e0(%rbp)
  422c3a:	mov    %rcx,-0x38d8(%rbp)
  422c41:	mov    0x8(%rdi),%r9
  422c45:	mov    0x8(%r9),%rax
  422c49:	cmp    $0x0,%rax
  422c4d:	jne    422c68 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26d8>
  422c4f:	lea    -0x38e0(%rbp),%rdx
  422c56:	mov    $0x8,%esi
  422c5b:	mov    %rdi,%rbx
  422c5e:	callq  437550 <p125_rt_ctor2>
  422c63:	mov    %rbx,%rdi
  422c66:	jmp    422ca2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2712>
  422c68:	mov    (%rdi),%rdx
  422c6b:	mov    %rax,%rsi
  422c6e:	shl    $0x3,%rsi
  422c72:	mov    (%rdx,%rsi,1),%r10
  422c76:	mov    0x108(%r9),%r8
  422c7d:	mov    %r10,0x8(%r9)
  422c81:	sub    $0x2,%r8
  422c85:	mov    %r8,0x108(%r9)
  422c8c:	mov    %rbx,(%rdx,%rsi,1)
  422c90:	mov    %rcx,0x8(%rdx,%rsi,1)
  422c95:	movabs $0x200080000000000,%rcx
  422c9f:	or     %rcx,%rax
  422ca2:	mov    %rax,-0x38e0(%rbp)
  422ca9:	mov    0x1cf88(%rip),%rcx        # 43fc38 <p111_program+0x58>
  422cb0:	test   $0x4,%rcx
  422cb7:	jne    422ccf <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x273f>
  422cb9:	mov    $0x1,%edx
  422cbe:	lea    -0x38e0(%rbp),%rsi
  422cc5:	callq  431ec0 <p111_rt_return>
  422cca:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  422ccf:	mov    %rax,0x28(%rdi)
  422cd3:	movl   $0x1,0x1c(%rdi)
  422cda:	mov    0x10(%rdi),%rax
  422cde:	mov    %rax,%rcx
  422ce1:	add    $0xfffffffffffffff8,%rcx
  422ce5:	mov    %rcx,0x10(%rdi)
  422ce9:	mov    -0x8(%rax),%rax
  422ced:	mov    %eax,0x20(%rdi)
  422cf0:	mov    $0x0,%eax
  422cf5:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  422cfa:	cs cs cs mov %r15,%r13
  422d00:	cmp    $0x8,%r13
  422d04:	je     422d6c <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x27dc>
  422d06:	mov    %rsi,%r13
  422d09:	mov    %rbx,%rsi
  422d0c:	mov    %rdi,%rbx
  422d0f:	callq  4318a0 <p111_rt_sink>
  422d14:	mov    %r13,%rsi
  422d17:	mov    %rbx,%rdi
  422d1a:	mov    %rsi,%r13
  422d1d:	mov    %rdi,%rbx
  422d20:	callq  4318a0 <p111_rt_sink>
  422d25:	mov    %r12,%rsi
  422d28:	mov    %rbx,%rdi
  422d2b:	mov    %rsi,%r12
  422d2e:	mov    %r14,%rsi
  422d31:	mov    %rdi,%rbx
  422d34:	callq  4318a0 <p111_rt_sink>
  422d39:	mov    %r12,%rsi
  422d3c:	mov    %rbx,%rdi
  422d3f:	mov    %rsi,-0x38e0(%rbp)
  422d46:	mov    0x10(%rdi),%rax
  422d4a:	mov    %rsi,(%rax)
  422d4d:	movq   $0x15d,0x8(%rax)
  422d55:	add    $0x10,%rax
  422d59:	mov    %rax,0x10(%rdi)
  422d5d:	mov    $0x4,%esi
  422d62:	callq  432030 <p111_rt_fail>
  422d67:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  422d6c:	mov    %rsi,%r13
  422d6f:	mov    %r12,%rsi
  422d72:	lea    -0x38e0(%rbp),%rdx
  422d79:	mov    %rdi,%r12
  422d7c:	callq  437640 <p125_rt_take2>
  422d81:	mov    %r13,%rsi
  422d84:	mov    %r12,%rdi
  422d87:	mov    -0x38e0(%rbp),%r12
  422d8e:	mov    %rbx,%r13
  422d91:	mov    -0x38d8(%rbp),%rbx
  422d98:	cmp    $0x1,%rbx
  422d9c:	sete   %al
  422d9f:	movzbl %al,%eax
  422da2:	mov    %rbx,%rcx
  422da5:	shr    $0x28,%rcx
  422da9:	and    $0x7fffff,%rcx
  422db0:	cmp    $0x10002,%rcx
  422db7:	sete   %cl
  422dba:	movzbl %cl,%ecx
  422dbd:	mov    %eax,%edx
  422dbf:	or     %ecx,%edx
  422dc1:	xor    $0x1,%edx
  422dc4:	jne    423091 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b01>
  422dca:	or     %ecx,%eax
  422dcc:	jne    422e36 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28a6>
  422dce:	mov    %rsi,%r15
  422dd1:	mov    %r13,%rsi
  422dd4:	mov    %rdi,%r13
  422dd7:	callq  4318a0 <p111_rt_sink>
  422ddc:	mov    %r15,%rsi
  422ddf:	mov    %r13,%rdi
  422de2:	mov    %rdi,%r13
  422de5:	callq  4318a0 <p111_rt_sink>
  422dea:	mov    %r13,%rdi
  422ded:	mov    %r14,%rsi
  422df0:	mov    %rdi,%r13
  422df3:	callq  4318a0 <p111_rt_sink>
  422df8:	mov    %r13,%rdi
  422dfb:	mov    %r12,%rsi
  422dfe:	mov    %rdi,%r12
  422e01:	callq  4318a0 <p111_rt_sink>
  422e06:	mov    %r12,%rdi
  422e09:	mov    %rbx,-0x38e0(%rbp)
  422e10:	mov    0x10(%rdi),%rax
  422e14:	mov    %rbx,(%rax)
  422e17:	movq   $0x15c,0x8(%rax)
  422e1f:	add    $0x10,%rax
  422e23:	mov    %rax,0x10(%rdi)
  422e27:	mov    $0x4,%esi
  422e2c:	callq  432030 <p111_rt_fail>
  422e31:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  422e36:	mov    %r13,%rbx
  422e39:	mov    %rsi,-0x38e0(%rbp)
  422e40:	mov    %r14,-0x38d8(%rbp)
  422e47:	mov    0x8(%rdi),%r9
  422e4b:	mov    0x8(%r9),%rax
  422e4f:	cmp    $0x0,%rax
  422e53:	jne    422e71 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28e1>
  422e55:	lea    -0x38e0(%rbp),%rdx
  422e5c:	mov    $0x2c,%esi
  422e61:	mov    %rdi,%r13
  422e64:	callq  437550 <p125_rt_ctor2>
  422e69:	mov    %r13,%rdi
  422e6c:	mov    %rax,%rcx
  422e6f:	jmp    422eab <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x291b>
  422e71:	mov    (%rdi),%rcx
  422e74:	mov    %rax,%rdx
  422e77:	shl    $0x3,%rdx
  422e7b:	mov    (%rcx,%rdx,1),%r10
  422e7f:	mov    0x108(%r9),%r8
  422e86:	mov    %r10,0x8(%r9)
  422e8a:	sub    $0x2,%r8
  422e8e:	mov    %r8,0x108(%r9)
  422e95:	mov    %rsi,(%rcx,%rdx,1)
  422e99:	mov    %r14,0x8(%rcx,%rdx,1)
  422e9e:	movabs $0x2002c0000000000,%rcx
  422ea8:	or     %rax,%rcx
  422eab:	mov    %rbx,-0x38e0(%rbp)
  422eb2:	mov    %rcx,-0x38d8(%rbp)
  422eb9:	movabs $0x1002b0000000000,%rax
  422ec3:	mov    %rax,-0x38d0(%rbp)
  422eca:	mov    0x8(%rdi),%r9
  422ece:	mov    0x10(%r9),%rax
  422ed2:	cmp    $0x0,%rax
  422ed6:	jne    422ef4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2964>
  422ed8:	lea    -0x38e0(%rbp),%rdx
  422edf:	mov    $0x2d,%esi
  422ee4:	mov    %rdi,%rbx
  422ee7:	callq  4377d0 <p125_rt_ctor3>
  422eec:	mov    %rbx,%rdi
  422eef:	mov    %rax,%rbx
  422ef2:	jmp    422f40 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x29b0>
  422ef4:	mov    (%rdi),%rdx
  422ef7:	mov    %rax,%rsi
  422efa:	shl    $0x3,%rsi
  422efe:	mov    (%rdx,%rsi,1),%r10
  422f02:	mov    0x110(%r9),%r8
  422f09:	mov    %r10,0x10(%r9)
  422f0d:	sub    $0x4,%r8
  422f11:	mov    %r8,0x110(%r9)
  422f18:	mov    %rbx,(%rdx,%rsi,1)
  422f1c:	mov    %rcx,0x8(%rdx,%rsi,1)
  422f21:	movabs $0x1002b0000000000,%rcx
  422f2b:	mov    %rcx,0x10(%rdx,%rsi,1)
  422f30:	movabs $0x2002d0000000000,%rcx
  422f3a:	mov    %rax,%rbx
  422f3d:	or     %rcx,%rbx
  422f40:	mov    %r12,-0x38e0(%rbp)
  422f47:	movabs $0x1000b0000000000,%rax
  422f51:	mov    %rax,-0x38d8(%rbp)
  422f58:	mov    0x8(%rdi),%r8
  422f5c:	mov    0x8(%r8),%rax
  422f60:	cmp    $0x0,%rax
  422f64:	jne    422f82 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x29f2>
  422f66:	lea    -0x38e0(%rbp),%rdx
  422f6d:	mov    $0x8,%esi
  422f72:	mov    %rdi,%r12
  422f75:	callq  437550 <p125_rt_ctor2>
  422f7a:	mov    %r12,%rdi
  422f7d:	mov    %rax,%rcx
  422f80:	jmp    422fca <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a3a>
  422f82:	cs cs cs mov %cs:(%rdi),%rdx
  422f89:	mov    %rax,%rsi
  422f8c:	shl    $0x3,%rsi
  422f90:	mov    (%rdx,%rsi,1),%r9
  422f94:	mov    0x108(%r8),%rcx
  422f9b:	mov    %r9,0x8(%r8)
  422f9f:	sub    $0x2,%rcx
  422fa3:	mov    %rcx,0x108(%r8)
  422faa:	mov    %r12,(%rdx,%rsi,1)
  422fae:	movabs $0x1000b0000000000,%rcx
  422fb8:	mov    %rcx,0x8(%rdx,%rsi,1)
  422fbd:	movabs $0x200080000000000,%rcx
  422fc7:	or     %rax,%rcx
  422fca:	mov    %rbx,-0x38e0(%rbp)
  422fd1:	mov    %rcx,-0x38d8(%rbp)
  422fd8:	mov    0x8(%rdi),%r9
  422fdc:	mov    0x8(%r9),%rax
  422fe0:	cmp    $0x0,%rax
  422fe4:	jne    422fff <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a6f>
  422fe6:	lea    -0x38e0(%rbp),%rdx
  422fed:	mov    $0x8,%esi
  422ff2:	mov    %rdi,%rbx
  422ff5:	callq  437550 <p125_rt_ctor2>
  422ffa:	mov    %rbx,%rdi
  422ffd:	jmp    423039 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2aa9>
  422fff:	mov    (%rdi),%rdx
  423002:	mov    %rax,%rsi
  423005:	shl    $0x3,%rsi
  423009:	mov    (%rdx,%rsi,1),%r10
  42300d:	mov    0x108(%r9),%r8
  423014:	mov    %r10,0x8(%r9)
  423018:	sub    $0x2,%r8
  42301c:	mov    %r8,0x108(%r9)
  423023:	mov    %rbx,(%rdx,%rsi,1)
  423027:	mov    %rcx,0x8(%rdx,%rsi,1)
  42302c:	movabs $0x200080000000000,%rcx
  423036:	or     %rcx,%rax
  423039:	mov    %rax,-0x38e0(%rbp)
  423040:	mov    0x1cbf1(%rip),%rcx        # 43fc38 <p111_program+0x58>
  423047:	test   $0x4,%rcx
  42304e:	jne    423066 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2ad6>
  423050:	mov    $0x1,%edx
  423055:	lea    -0x38e0(%rbp),%rsi
  42305c:	callq  431ec0 <p111_rt_return>
  423061:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423066:	mov    %rax,0x28(%rdi)
  42306a:	movl   $0x1,0x1c(%rdi)
  423071:	mov    0x10(%rdi),%rax
  423075:	mov    %rax,%rcx
  423078:	add    $0xfffffffffffffff8,%rcx
  42307c:	mov    %rcx,0x10(%rdi)
  423080:	mov    -0x8(%rax),%rax
  423084:	mov    %eax,0x20(%rdi)
  423087:	mov    $0x0,%eax
  42308c:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423091:	mov    %r13,%rbx
  423094:	mov    %rdi,%r13
  423097:	callq  431810 <p111_rt_keep>
  42309c:	mov    %r13,%rdi
  42309f:	mov    %rax,%r13
  4230a2:	mov    %r13,-0x38e0(%rbp)
  4230a9:	mov    %r14,-0x38d8(%rbp)
  4230b0:	mov    0x8(%rdi),%r8
  4230b4:	mov    0x8(%r8),%rax
  4230b8:	cmp    $0x0,%rax
  4230bc:	jne    4230da <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b4a>
  4230be:	lea    -0x38e0(%rbp),%rdx
  4230c5:	mov    $0x2c,%esi
  4230ca:	mov    %rdi,%r14
  4230cd:	callq  437550 <p125_rt_ctor2>
  4230d2:	mov    %r14,%rdi
  4230d5:	mov    %rax,%rcx
  4230d8:	jmp    423119 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b89>
  4230da:	cs cs cs mov %cs:(%rdi),%rcx
  4230e1:	cs mov %rax,%rdx
  4230e5:	shl    $0x3,%rdx
  4230e9:	mov    (%rcx,%rdx,1),%r9
  4230ed:	mov    0x108(%r8),%rsi
  4230f4:	mov    %r9,0x8(%r8)
  4230f8:	sub    $0x2,%rsi
  4230fc:	mov    %rsi,0x108(%r8)
  423103:	mov    %r13,(%rcx,%rdx,1)
  423107:	mov    %r14,0x8(%rcx,%rdx,1)
  42310c:	movabs $0x2002c0000000000,%rcx
  423116:	or     %rax,%rcx
  423119:	mov    %rbx,-0x38e0(%rbp)
  423120:	mov    %rcx,-0x38d8(%rbp)
  423127:	movabs $0x1002b0000000000,%rax
  423131:	mov    %rax,-0x38d0(%rbp)
  423138:	mov    0x8(%rdi),%r9
  42313c:	mov    0x10(%r9),%rax
  423140:	cmp    $0x0,%rax
  423144:	jne    423162 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2bd2>
  423146:	lea    -0x38e0(%rbp),%rdx
  42314d:	mov    $0x2d,%esi
  423152:	mov    %rdi,%rbx
  423155:	callq  4377d0 <p125_rt_ctor3>
  42315a:	mov    %rbx,%rdi
  42315d:	mov    %rax,%rbx
  423160:	jmp    4231b2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c22>
  423162:	cs cs cs mov %cs:(%rdi),%rdx
  423169:	mov    %rax,%rsi
  42316c:	shl    $0x3,%rsi
  423170:	mov    (%rdx,%rsi,1),%r10
  423174:	mov    0x110(%r9),%r8
  42317b:	mov    %r10,0x10(%r9)
  42317f:	sub    $0x4,%r8
  423183:	mov    %r8,0x110(%r9)
  42318a:	mov    %rbx,(%rdx,%rsi,1)
  42318e:	mov    %rcx,0x8(%rdx,%rsi,1)
  423193:	movabs $0x1002b0000000000,%rcx
  42319d:	mov    %rcx,0x10(%rdx,%rsi,1)
  4231a2:	movabs $0x2002d0000000000,%rcx
  4231ac:	mov    %rax,%rbx
  4231af:	or     %rcx,%rbx
  4231b2:	mov    %r13,-0x38e0(%rbp)
  4231b9:	mov    0x8(%rdi),%r8
  4231bd:	mov    (%r8),%rax
  4231c0:	cmp    $0x0,%rax
  4231c4:	jne    4231e2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c52>
  4231c6:	lea    -0x38e0(%rbp),%rdx
  4231cd:	mov    $0xc,%esi
  4231d2:	mov    %rdi,%r13
  4231d5:	callq  437320 <p125_rt_ctor1>
  4231da:	mov    %r13,%rdi
  4231dd:	mov    %rax,%rcx
  4231e0:	jmp    423216 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c86>
  4231e2:	mov    (%rdi),%rcx
  4231e5:	mov    %rax,%rdx
  4231e8:	shl    $0x3,%rdx
  4231ec:	mov    (%rcx,%rdx,1),%r9
  4231f0:	mov    0x100(%r8),%rsi
  4231f7:	mov    %r9,(%r8)
  4231fa:	sub    $0x1,%rsi
  4231fe:	mov    %rsi,0x100(%r8)
  423205:	mov    %r13,(%rcx,%rdx,1)
  423209:	movabs $0x2000c0000000000,%rcx
  423213:	or     %rax,%rcx
  423216:	mov    %r12,-0x38e0(%rbp)
  42321d:	mov    %rcx,-0x38d8(%rbp)
  423224:	mov    0x8(%rdi),%r9
  423228:	mov    0x8(%r9),%rax
  42322c:	cmp    $0x0,%rax
  423230:	jne    42324e <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2cbe>
  423232:	lea    -0x38e0(%rbp),%rdx
  423239:	mov    $0x8,%esi
  42323e:	mov    %rdi,%r12
  423241:	callq  437550 <p125_rt_ctor2>
  423246:	mov    %r12,%rdi
  423249:	mov    %rax,%rcx
  42324c:	jmp    42328a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2cfa>
  42324e:	cs mov %cs:(%rdi),%rdx
  423253:	mov    %rax,%rsi
  423256:	shl    $0x3,%rsi
  42325a:	mov    (%rdx,%rsi,1),%r10
  42325e:	mov    0x108(%r9),%r8
  423265:	mov    %r10,0x8(%r9)
  423269:	sub    $0x2,%r8
  42326d:	mov    %r8,0x108(%r9)
  423274:	mov    %r12,(%rdx,%rsi,1)
  423278:	mov    %rcx,0x8(%rdx,%rsi,1)
  42327d:	movabs $0x200080000000000,%rcx
  423287:	or     %rax,%rcx
  42328a:	mov    %rbx,-0x38e0(%rbp)
  423291:	mov    %rcx,-0x38d8(%rbp)
  423298:	mov    0x8(%rdi),%r9
  42329c:	mov    0x8(%r9),%rax
  4232a0:	cmp    $0x0,%rax
  4232a4:	jne    4232bf <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2d2f>
  4232a6:	lea    -0x38e0(%rbp),%rdx
  4232ad:	mov    $0x8,%esi
  4232b2:	mov    %rdi,%rbx
  4232b5:	callq  437550 <p125_rt_ctor2>
  4232ba:	mov    %rbx,%rdi
  4232bd:	jmp    4232f9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2d69>
  4232bf:	mov    (%rdi),%rdx
  4232c2:	mov    %rax,%rsi
  4232c5:	shl    $0x3,%rsi
  4232c9:	mov    (%rdx,%rsi,1),%r10
  4232cd:	mov    0x108(%r9),%r8
  4232d4:	mov    %r10,0x8(%r9)
  4232d8:	sub    $0x2,%r8
  4232dc:	mov    %r8,0x108(%r9)
  4232e3:	mov    %rbx,(%rdx,%rsi,1)
  4232e7:	mov    %rcx,0x8(%rdx,%rsi,1)
  4232ec:	movabs $0x200080000000000,%rcx
  4232f6:	or     %rcx,%rax
  4232f9:	mov    %rax,-0x38e0(%rbp)
  423300:	mov    0x1c931(%rip),%rcx        # 43fc38 <p111_program+0x58>
  423307:	test   $0x4,%rcx
  42330e:	jne    423326 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2d96>
  423310:	mov    $0x1,%edx
  423315:	lea    -0x38e0(%rbp),%rsi
  42331c:	callq  431ec0 <p111_rt_return>
  423321:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423326:	mov    %rax,0x28(%rdi)
  42332a:	movl   $0x1,0x1c(%rdi)
  423331:	mov    0x10(%rdi),%rax
  423335:	mov    %rax,%rcx
  423338:	add    $0xfffffffffffffff8,%rcx
  42333c:	mov    %rcx,0x10(%rdi)
  423340:	mov    -0x8(%rax),%rax
  423344:	mov    %eax,0x20(%rdi)
  423347:	mov    $0x0,%eax
  42334c:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423351:	mov    %r14,%rsi
  423354:	mov    %r15,%r14
  423357:	nopw   0x0(%rax,%rax,1)
  423360:	cmp    $0x2b,%rax
  423364:	je     423f8a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x39fa>
  42336a:	cmp    $0x2c,%rax
  42336e:	je     423911 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3381>
  423374:	cmp    $0x2d,%rax
  423378:	je     4233d9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2e49>
  42337a:	mov    %rsi,%r12
  42337d:	mov    %rbx,%rsi
  423380:	mov    %rdi,%rbx
  423383:	callq  4318a0 <p111_rt_sink>
  423388:	mov    %r12,%rsi
  42338b:	mov    %rbx,%rdi
  42338e:	mov    %r14,-0x38e0(%rbp)
  423395:	mov    0x10(%rdi),%rax
  423399:	mov    %r14,(%rax)
  42339c:	movq   $0x15a,0x8(%rax)
  4233a4:	add    $0x10,%rax
  4233a8:	mov    %rax,0x10(%rdi)
  4233ac:	mov    %rsi,-0x38e0(%rbp)
  4233b3:	mov    0x10(%rdi),%rax
  4233b7:	mov    %rsi,(%rax)
  4233ba:	movq   $0x15b,0x8(%rax)
  4233c2:	add    $0x10,%rax
  4233c6:	mov    %rax,0x10(%rdi)
  4233ca:	mov    $0x4,%esi
  4233cf:	callq  432030 <p111_rt_fail>
  4233d4:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4233d9:	lea    -0x38e0(%rbp),%rdx
  4233e0:	mov    %rdi,%r13
  4233e3:	callq  4378a0 <p125_rt_take3>
  4233e8:	mov    %r14,%rsi
  4233eb:	mov    %r13,%rdi
  4233ee:	mov    -0x38e0(%rbp),%r15
  4233f5:	mov    -0x38d8(%rbp),%r14
  4233fc:	mov    -0x38d0(%rbp),%r13
  423403:	cmp    $0x8,%r12
  423407:	je     423486 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2ef6>
  423409:	mov    %rsi,%r12
  42340c:	mov    %rbx,%rsi
  42340f:	mov    %rdi,%rbx
  423412:	callq  4318a0 <p111_rt_sink>
  423417:	mov    %r12,%rsi
  42341a:	mov    %rbx,%rdi
  42341d:	mov    %rsi,%r12
  423420:	mov    %r15,%rsi
  423423:	mov    %rdi,%rbx
  423426:	callq  4318a0 <p111_rt_sink>
  42342b:	mov    %r12,%rsi
  42342e:	mov    %rbx,%rdi
  423431:	mov    %rsi,%r12
  423434:	mov    %r14,%rsi
  423437:	mov    %rdi,%rbx
  42343a:	callq  4318a0 <p111_rt_sink>
  42343f:	mov    %r12,%rsi
  423442:	mov    %rbx,%rdi
  423445:	mov    %rsi,%r12
  423448:	mov    %r13,%rsi
  42344b:	mov    %rdi,%rbx
  42344e:	callq  4318a0 <p111_rt_sink>
  423453:	mov    %r12,%rsi
  423456:	mov    %rbx,%rdi
  423459:	mov    %rsi,-0x38e0(%rbp)
  423460:	mov    0x10(%rdi),%rax
  423464:	mov    %rsi,(%rax)
  423467:	movq   $0x159,0x8(%rax)
  42346f:	add    $0x10,%rax
  423473:	mov    %rax,0x10(%rdi)
  423477:	mov    $0x4,%esi
  42347c:	callq  432030 <p111_rt_fail>
  423481:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423486:	cs cs cs lea %cs:-0x38e0(%rbp),%rdx
  423491:	mov    %rdi,%r12
  423494:	callq  437640 <p125_rt_take2>
  423499:	mov    %r12,%rdi
  42349c:	mov    -0x38e0(%rbp),%rax
  4234a3:	mov    %rax,-0xe0(%rbp)
  4234aa:	mov    %rbx,%r12
  4234ad:	mov    -0x38d8(%rbp),%rbx
  4234b4:	cmp    $0x1,%rbx
  4234b8:	sete   %cl
  4234bb:	movzbl %cl,%ecx
  4234be:	mov    %rbx,%rdx
  4234c1:	shr    $0x28,%rdx
  4234c5:	and    $0x7fffff,%rdx
  4234cc:	cmp    $0x10002,%rdx
  4234d3:	sete   %dl
  4234d6:	movzbl %dl,%edx
  4234d9:	mov    %ecx,%esi
  4234db:	or     %edx,%esi
  4234dd:	xor    $0x1,%esi
  4234e0:	jne    4236a5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3115>
  4234e6:	or     %edx,%ecx
  4234e8:	jne    423565 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2fd5>
  4234ea:	cs mov %r12,%rsi
  4234ee:	mov    %rdi,%r12
  4234f1:	callq  4318a0 <p111_rt_sink>
  4234f6:	mov    %r12,%rdi
  4234f9:	mov    -0xe0(%rbp),%r12
  423500:	mov    %r15,%rsi
  423503:	mov    %rdi,%r15
  423506:	callq  4318a0 <p111_rt_sink>
  42350b:	mov    %r15,%rdi
  42350e:	mov    %r14,%rsi
  423511:	mov    %rdi,%r14
  423514:	callq  4318a0 <p111_rt_sink>
  423519:	mov    %r14,%rdi
  42351c:	mov    %r13,%rsi
  42351f:	mov    %rdi,%r13
  423522:	callq  4318a0 <p111_rt_sink>
  423527:	mov    %r13,%rdi
  42352a:	mov    %r12,%rsi
  42352d:	mov    %rdi,%r12
  423530:	callq  4318a0 <p111_rt_sink>
  423535:	mov    %r12,%rdi
  423538:	mov    %rbx,-0x38e0(%rbp)
  42353f:	mov    0x10(%rdi),%rax
  423543:	mov    %rbx,(%rax)
  423546:	movq   $0x158,0x8(%rax)
  42354e:	add    $0x10,%rax
  423552:	mov    %rax,0x10(%rdi)
  423556:	mov    $0x4,%esi
  42355b:	callq  432030 <p111_rt_fail>
  423560:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423565:	mov    %r12,%rbx
  423568:	mov    %rax,%r12
  42356b:	mov    %rbx,-0x38e0(%rbp)
  423572:	movabs $0x1002b0000000000,%rax
  42357c:	mov    %rax,-0x38d8(%rbp)
  423583:	mov    0x10(%rdi),%rax
  423587:	mov    %rbx,(%rax)
  42358a:	mov    -0x38d8(%rbp),%rcx
  423591:	mov    %rcx,0x8(%rax)
  423595:	movq   $0x156,0x10(%rax)
  42359d:	add    $0x18,%rax
  4235a1:	mov    %rax,0x10(%rdi)
  4235a5:	mov    %r15,%rsi
  4235a8:	mov    %rdi,%rbx
  4235ab:	callq  431810 <p111_rt_keep>
  4235b0:	mov    %rbx,%rdi
  4235b3:	mov    %rax,%rdx
  4235b6:	mov    %rdx,-0x38e0(%rbp)
  4235bd:	mov    %r14,-0x38d8(%rbp)
  4235c4:	mov    %r13,-0x38d0(%rbp)
  4235cb:	mov    0x8(%rdi),%r9
  4235cf:	mov    0x10(%r9),%rax
  4235d3:	cmp    $0x0,%rax
  4235d7:	jne    4235fb <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x306b>
  4235d9:	mov    %rdx,%r13
  4235dc:	lea    -0x38e0(%rbp),%rdx
  4235e3:	mov    $0x2d,%esi
  4235e8:	mov    %rdi,%rbx
  4235eb:	callq  4377d0 <p125_rt_ctor3>
  4235f0:	mov    %r13,%rdx
  4235f3:	mov    %rbx,%rdi
  4235f6:	mov    %rax,%rbx
  4235f9:	jmp    42363d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x30ad>
  4235fb:	mov    (%rdi),%rcx
  4235fe:	mov    %rax,%rsi
  423601:	shl    $0x3,%rsi
  423605:	mov    (%rcx,%rsi,1),%r10
  423609:	mov    0x110(%r9),%r8
  423610:	mov    %r10,0x10(%r9)
  423614:	sub    $0x4,%r8
  423618:	mov    %r8,0x110(%r9)
  42361f:	mov    %rdx,(%rcx,%rsi,1)
  423623:	mov    %r14,0x8(%rcx,%rsi,1)
  423628:	mov    %r13,0x10(%rcx,%rsi,1)
  42362d:	movabs $0x2002d0000000000,%rcx
  423637:	mov    %rax,%rbx
  42363a:	or     %rcx,%rbx
  42363d:	mov    %r12,%rsi
  423640:	mov    %rdi,%r12
  423643:	callq  4053c0 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  423648:	mov    %r12,%rdi
  42364b:	mov    %rbx,-0x30e0(%rbp)
  423652:	mov    %rax,-0x30d8(%rbp)
  423659:	mov    0x1c5d8(%rip),%rcx        # 43fc38 <p111_program+0x58>
  423660:	test   $0x4,%rcx
  423667:	jne    423685 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x30f5>
  423669:	cs mov $0x2,%ecx
  42366f:	lea    -0x30e0(%rbp),%rdx
  423676:	mov    $0x151,%esi
  42367b:	callq  431e60 <p111_rt_jump>
  423680:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423685:	mov    %rbx,0x28(%rdi)
  423689:	mov    %rax,0x30(%rdi)
  42368d:	movl   $0x0,0x1c(%rdi)
  423694:	movl   $0x151,0x20(%rdi)
  42369b:	mov    $0x0,%eax
  4236a0:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4236a5:	mov    %r12,%rbx
  4236a8:	mov    %rax,%r12
  4236ab:	mov    %r15,-0x38e0(%rbp)
  4236b2:	mov    %r14,-0x38d8(%rbp)
  4236b9:	mov    %r13,-0x38d0(%rbp)
  4236c0:	mov    0x8(%rdi),%r8
  4236c4:	mov    0x10(%r8),%rax
  4236c8:	cmp    $0x0,%rax
  4236cc:	jne    4236ea <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x315a>
  4236ce:	lea    -0x38e0(%rbp),%rdx
  4236d5:	mov    $0x2d,%esi
  4236da:	mov    %rdi,%r13
  4236dd:	callq  4377d0 <p125_rt_ctor3>
  4236e2:	mov    %r13,%rdi
  4236e5:	mov    %rax,%rcx
  4236e8:	jmp    423729 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3199>
  4236ea:	mov    (%rdi),%rcx
  4236ed:	mov    %rax,%rdx
  4236f0:	shl    $0x3,%rdx
  4236f4:	mov    (%rcx,%rdx,1),%r9
  4236f8:	mov    0x110(%r8),%rsi
  4236ff:	mov    %r9,0x10(%r8)
  423703:	sub    $0x4,%rsi
  423707:	mov    %rsi,0x110(%r8)
  42370e:	mov    %r15,(%rcx,%rdx,1)
  423712:	mov    %r14,0x8(%rcx,%rdx,1)
  423717:	mov    %r13,0x10(%rcx,%rdx,1)
  42371c:	movabs $0x2002d0000000000,%rcx
  423726:	or     %rax,%rcx
  423729:	mov    %rbx,-0x38e0(%rbp)
  423730:	movabs $0x1002b0000000000,%rax
  42373a:	mov    %rax,-0x38d8(%rbp)
  423741:	mov    %rcx,-0x38d0(%rbp)
  423748:	mov    0x8(%rdi),%r9
  42374c:	mov    0x10(%r9),%rax
  423750:	cmp    $0x0,%rax
  423754:	jne    423772 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x31e2>
  423756:	lea    -0x38e0(%rbp),%rdx
  42375d:	mov    $0x2d,%esi
  423762:	mov    %rdi,%rbx
  423765:	callq  4377d0 <p125_rt_ctor3>
  42376a:	mov    %rbx,%rdi
  42376d:	mov    %rax,%rbx
  423770:	jmp    4237c0 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3230>
  423772:	cs mov %cs:(%rdi),%rdx
  423777:	mov    %rax,%rsi
  42377a:	shl    $0x3,%rsi
  42377e:	mov    (%rdx,%rsi,1),%r10
  423782:	mov    0x110(%r9),%r8
  423789:	mov    %r10,0x10(%r9)
  42378d:	sub    $0x4,%r8
  423791:	mov    %r8,0x110(%r9)
  423798:	mov    %rbx,(%rdx,%rsi,1)
  42379c:	movabs $0x1002b0000000000,%r8
  4237a6:	mov    %r8,0x8(%rdx,%rsi,1)
  4237ab:	mov    %rcx,0x10(%rdx,%rsi,1)
  4237b0:	movabs $0x2002d0000000000,%rcx
  4237ba:	mov    %rax,%rbx
  4237bd:	or     %rcx,%rbx
  4237c0:	mov    %r12,-0x38e0(%rbp)
  4237c7:	movabs $0x1000b0000000000,%rax
  4237d1:	mov    %rax,-0x38d8(%rbp)
  4237d8:	mov    0x8(%rdi),%r8
  4237dc:	mov    0x8(%r8),%rax
  4237e0:	cmp    $0x0,%rax
  4237e4:	jne    423802 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3272>
  4237e6:	lea    -0x38e0(%rbp),%rdx
  4237ed:	mov    $0x8,%esi
  4237f2:	mov    %rdi,%r12
  4237f5:	callq  437550 <p125_rt_ctor2>
  4237fa:	mov    %r12,%rdi
  4237fd:	mov    %rax,%rcx
  423800:	jmp    42384a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x32ba>
  423802:	cs cs cs mov %cs:(%rdi),%rdx
  423809:	mov    %rax,%rsi
  42380c:	shl    $0x3,%rsi
  423810:	mov    (%rdx,%rsi,1),%r9
  423814:	mov    0x108(%r8),%rcx
  42381b:	mov    %r9,0x8(%r8)
  42381f:	sub    $0x2,%rcx
  423823:	mov    %rcx,0x108(%r8)
  42382a:	mov    %r12,(%rdx,%rsi,1)
  42382e:	movabs $0x1000b0000000000,%rcx
  423838:	mov    %rcx,0x8(%rdx,%rsi,1)
  42383d:	movabs $0x200080000000000,%rcx
  423847:	or     %rax,%rcx
  42384a:	mov    %rbx,-0x38e0(%rbp)
  423851:	mov    %rcx,-0x38d8(%rbp)
  423858:	mov    0x8(%rdi),%r9
  42385c:	mov    0x8(%r9),%rax
  423860:	cmp    $0x0,%rax
  423864:	jne    42387f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x32ef>
  423866:	lea    -0x38e0(%rbp),%rdx
  42386d:	mov    $0x8,%esi
  423872:	mov    %rdi,%rbx
  423875:	callq  437550 <p125_rt_ctor2>
  42387a:	mov    %rbx,%rdi
  42387d:	jmp    4238b9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3329>
  42387f:	mov    (%rdi),%rdx
  423882:	mov    %rax,%rsi
  423885:	shl    $0x3,%rsi
  423889:	mov    (%rdx,%rsi,1),%r10
  42388d:	mov    0x108(%r9),%r8
  423894:	mov    %r10,0x8(%r9)
  423898:	sub    $0x2,%r8
  42389c:	mov    %r8,0x108(%r9)
  4238a3:	mov    %rbx,(%rdx,%rsi,1)
  4238a7:	mov    %rcx,0x8(%rdx,%rsi,1)
  4238ac:	movabs $0x200080000000000,%rcx
  4238b6:	or     %rcx,%rax
  4238b9:	mov    %rax,-0x38e0(%rbp)
  4238c0:	mov    0x1c371(%rip),%rcx        # 43fc38 <p111_program+0x58>
  4238c7:	test   $0x4,%rcx
  4238ce:	jne    4238e6 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3356>
  4238d0:	mov    $0x1,%edx
  4238d5:	lea    -0x38e0(%rbp),%rsi
  4238dc:	callq  431ec0 <p111_rt_return>
  4238e1:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4238e6:	mov    %rax,0x28(%rdi)
  4238ea:	movl   $0x1,0x1c(%rdi)
  4238f1:	mov    0x10(%rdi),%rax
  4238f5:	mov    %rax,%rcx
  4238f8:	add    $0xfffffffffffffff8,%rcx
  4238fc:	mov    %rcx,0x10(%rdi)
  423900:	mov    -0x8(%rax),%rax
  423904:	mov    %eax,0x20(%rdi)
  423907:	mov    $0x0,%eax
  42390c:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423911:	lea    -0x38e0(%rbp),%rdx
  423918:	mov    %rdi,%r13
  42391b:	callq  437640 <p125_rt_take2>
  423920:	mov    %r14,%rsi
  423923:	mov    %r13,%rdi
  423926:	mov    -0x38e0(%rbp),%r14
  42392d:	mov    %r14,%r13
  423930:	mov    -0x38d8(%rbp),%r14
  423937:	cmp    $0x8,%r12
  42393b:	je     4239a6 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3416>
  42393d:	mov    %rsi,%r12
  423940:	mov    %rbx,%rsi
  423943:	mov    %rdi,%rbx
  423946:	callq  4318a0 <p111_rt_sink>
  42394b:	mov    %r12,%rsi
  42394e:	mov    %rbx,%rdi
  423951:	mov    %rsi,%r12
  423954:	mov    %r13,%rsi
  423957:	mov    %rdi,%rbx
  42395a:	callq  4318a0 <p111_rt_sink>
  42395f:	mov    %r12,%rsi
  423962:	mov    %rbx,%rdi
  423965:	mov    %rsi,%r12
  423968:	mov    %r14,%rsi
  42396b:	mov    %rdi,%rbx
  42396e:	callq  4318a0 <p111_rt_sink>
  423973:	mov    %r12,%rsi
  423976:	mov    %rbx,%rdi
  423979:	mov    %rsi,-0x38e0(%rbp)
  423980:	mov    0x10(%rdi),%rax
  423984:	mov    %rsi,(%rax)
  423987:	movq   $0x155,0x8(%rax)
  42398f:	add    $0x10,%rax
  423993:	mov    %rax,0x10(%rdi)
  423997:	mov    $0x4,%esi
  42399c:	callq  432030 <p111_rt_fail>
  4239a1:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  4239a6:	lea    -0x38e0(%rbp),%rdx
  4239ad:	mov    %rdi,%r12
  4239b0:	callq  437640 <p125_rt_take2>
  4239b5:	mov    %r12,%rdi
  4239b8:	mov    -0x38e0(%rbp),%r12
  4239bf:	mov    %rbx,%r15
  4239c2:	mov    -0x38d8(%rbp),%rbx
  4239c9:	cmp    $0x1,%rbx
  4239cd:	sete   %al
  4239d0:	movzbl %al,%eax
  4239d3:	mov    %rbx,%rcx
  4239d6:	shr    $0x28,%rcx
  4239da:	and    $0x7fffff,%rcx
  4239e1:	cmp    $0x10002,%rcx
  4239e8:	sete   %cl
  4239eb:	movzbl %cl,%ecx
  4239ee:	mov    %eax,%edx
  4239f0:	or     %ecx,%edx
  4239f2:	xor    $0x1,%edx
  4239f5:	jne    423d2a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x379a>
  4239fb:	or     %ecx,%eax
  4239fd:	jne    423a65 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x34d5>
  4239ff:	cs mov %r15,%rsi
  423a03:	mov    %rdi,%r15
  423a06:	callq  4318a0 <p111_rt_sink>
  423a0b:	mov    %r15,%rdi
  423a0e:	mov    %r13,%rsi
  423a11:	mov    %rdi,%r13
  423a14:	callq  4318a0 <p111_rt_sink>
  423a19:	mov    %r13,%rdi
  423a1c:	mov    %r14,%rsi
  423a1f:	mov    %rdi,%r13
  423a22:	callq  4318a0 <p111_rt_sink>
  423a27:	mov    %r13,%rdi
  423a2a:	mov    %r12,%rsi
  423a2d:	mov    %rdi,%r12
  423a30:	callq  4318a0 <p111_rt_sink>
  423a35:	mov    %r12,%rdi
  423a38:	mov    %rbx,-0x38e0(%rbp)
  423a3f:	mov    0x10(%rdi),%rax
  423a43:	mov    %rbx,(%rax)
  423a46:	movq   $0x154,0x8(%rax)
  423a4e:	add    $0x10,%rax
  423a52:	mov    %rax,0x10(%rdi)
  423a56:	mov    $0x4,%esi
  423a5b:	callq  432030 <p111_rt_fail>
  423a60:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423a65:	mov    %r15,%rbx
  423a68:	mov    %r13,%rsi
  423a6b:	mov    %rdi,%r13
  423a6e:	callq  431810 <p111_rt_keep>
  423a73:	mov    %r13,%rdi
  423a76:	mov    %rax,%r13
  423a79:	mov    %r13,-0x38e0(%rbp)
  423a80:	mov    %r14,-0x38d8(%rbp)
  423a87:	mov    0x8(%rdi),%r8
  423a8b:	mov    0x8(%r8),%rax
  423a8f:	cmp    $0x0,%rax
  423a93:	jne    423ab1 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3521>
  423a95:	lea    -0x38e0(%rbp),%rdx
  423a9c:	mov    $0x2c,%esi
  423aa1:	mov    %rdi,%r14
  423aa4:	callq  437550 <p125_rt_ctor2>
  423aa9:	mov    %r14,%rdi
  423aac:	mov    %rax,%rcx
  423aaf:	jmp    423aeb <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x355b>
  423ab1:	mov    (%rdi),%rcx
  423ab4:	mov    %rax,%rdx
  423ab7:	shl    $0x3,%rdx
  423abb:	mov    (%rcx,%rdx,1),%r9
  423abf:	mov    0x108(%r8),%rsi
  423ac6:	mov    %r9,0x8(%r8)
  423aca:	sub    $0x2,%rsi
  423ace:	mov    %rsi,0x108(%r8)
  423ad5:	mov    %r13,(%rcx,%rdx,1)
  423ad9:	mov    %r14,0x8(%rcx,%rdx,1)
  423ade:	movabs $0x2002c0000000000,%rcx
  423ae8:	or     %rax,%rcx
  423aeb:	mov    %rbx,-0x38e0(%rbp)
  423af2:	movabs $0x1002b0000000000,%rax
  423afc:	mov    %rax,-0x38d8(%rbp)
  423b03:	mov    %rcx,-0x38d0(%rbp)
  423b0a:	mov    0x8(%rdi),%r9
  423b0e:	mov    0x10(%r9),%rax
  423b12:	cmp    $0x0,%rax
  423b16:	jne    423b34 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x35a4>
  423b18:	lea    -0x38e0(%rbp),%rdx
  423b1f:	mov    $0x2d,%esi
  423b24:	mov    %rdi,%rbx
  423b27:	callq  4377d0 <p125_rt_ctor3>
  423b2c:	mov    %rbx,%rdi
  423b2f:	mov    %rax,%rbx
  423b32:	jmp    423b80 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x35f0>
  423b34:	mov    (%rdi),%rdx
  423b37:	mov    %rax,%rsi
  423b3a:	shl    $0x3,%rsi
  423b3e:	mov    (%rdx,%rsi,1),%r10
  423b42:	mov    0x110(%r9),%r8
  423b49:	mov    %r10,0x10(%r9)
  423b4d:	sub    $0x4,%r8
  423b51:	mov    %r8,0x110(%r9)
  423b58:	mov    %rbx,(%rdx,%rsi,1)
  423b5c:	movabs $0x1002b0000000000,%r8
  423b66:	mov    %r8,0x8(%rdx,%rsi,1)
  423b6b:	mov    %rcx,0x10(%rdx,%rsi,1)
  423b70:	movabs $0x2002d0000000000,%rcx
  423b7a:	mov    %rax,%rbx
  423b7d:	or     %rcx,%rbx
  423b80:	mov    %r13,-0x38e0(%rbp)
  423b87:	mov    0x8(%rdi),%r8
  423b8b:	mov    (%r8),%rax
  423b8e:	cmp    $0x0,%rax
  423b92:	jne    423bb0 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3620>
  423b94:	lea    -0x38e0(%rbp),%rdx
  423b9b:	mov    $0xc,%esi
  423ba0:	mov    %rdi,%r13
  423ba3:	callq  437320 <p125_rt_ctor1>
  423ba8:	mov    %r13,%rdi
  423bab:	mov    %rax,%rcx
  423bae:	jmp    423bea <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x365a>
  423bb0:	cs cs cs mov %cs:(%rdi),%rcx
  423bb7:	cs cs mov %rax,%rdx
  423bbc:	shl    $0x3,%rdx
  423bc0:	mov    (%rcx,%rdx,1),%r9
  423bc4:	mov    0x100(%r8),%rsi
  423bcb:	mov    %r9,(%r8)
  423bce:	sub    $0x1,%rsi
  423bd2:	mov    %rsi,0x100(%r8)
  423bd9:	mov    %r13,(%rcx,%rdx,1)
  423bdd:	movabs $0x2000c0000000000,%rcx
  423be7:	or     %rax,%rcx
  423bea:	mov    %r12,-0x38e0(%rbp)
  423bf1:	mov    %rcx,-0x38d8(%rbp)
  423bf8:	mov    0x8(%rdi),%r9
  423bfc:	mov    0x8(%r9),%rax
  423c00:	cmp    $0x0,%rax
  423c04:	jne    423c22 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3692>
  423c06:	lea    -0x38e0(%rbp),%rdx
  423c0d:	mov    $0x8,%esi
  423c12:	mov    %rdi,%r12
  423c15:	callq  437550 <p125_rt_ctor2>
  423c1a:	mov    %r12,%rdi
  423c1d:	mov    %rax,%rcx
  423c20:	jmp    423c5c <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x36cc>
  423c22:	mov    (%rdi),%rdx
  423c25:	mov    %rax,%rsi
  423c28:	shl    $0x3,%rsi
  423c2c:	mov    (%rdx,%rsi,1),%r10
  423c30:	mov    0x108(%r9),%r8
  423c37:	mov    %r10,0x8(%r9)
  423c3b:	sub    $0x2,%r8
  423c3f:	mov    %r8,0x108(%r9)
  423c46:	mov    %r12,(%rdx,%rsi,1)
  423c4a:	mov    %rcx,0x8(%rdx,%rsi,1)
  423c4f:	movabs $0x200080000000000,%rcx
  423c59:	or     %rax,%rcx
  423c5c:	mov    %rbx,-0x38e0(%rbp)
  423c63:	mov    %rcx,-0x38d8(%rbp)
  423c6a:	mov    0x8(%rdi),%r9
  423c6e:	mov    0x8(%r9),%rax
  423c72:	cmp    $0x0,%rax
  423c76:	jne    423c91 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3701>
  423c78:	lea    -0x38e0(%rbp),%rdx
  423c7f:	mov    $0x8,%esi
  423c84:	mov    %rdi,%rbx
  423c87:	callq  437550 <p125_rt_ctor2>
  423c8c:	mov    %rbx,%rdi
  423c8f:	jmp    423cd2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3742>
  423c91:	cs cs cs mov %cs:(%rdi),%rdx
  423c98:	cs cs cs mov %rax,%rsi
  423c9e:	shl    $0x3,%rsi
  423ca2:	mov    (%rdx,%rsi,1),%r10
  423ca6:	mov    0x108(%r9),%r8
  423cad:	mov    %r10,0x8(%r9)
  423cb1:	sub    $0x2,%r8
  423cb5:	mov    %r8,0x108(%r9)
  423cbc:	mov    %rbx,(%rdx,%rsi,1)
  423cc0:	mov    %rcx,0x8(%rdx,%rsi,1)
  423cc5:	movabs $0x200080000000000,%rcx
  423ccf:	or     %rcx,%rax
  423cd2:	mov    %rax,-0x38e0(%rbp)
  423cd9:	mov    0x1bf58(%rip),%rcx        # 43fc38 <p111_program+0x58>
  423ce0:	test   $0x4,%rcx
  423ce7:	jne    423cff <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x376f>
  423ce9:	mov    $0x1,%edx
  423cee:	lea    -0x38e0(%rbp),%rsi
  423cf5:	callq  431ec0 <p111_rt_return>
  423cfa:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423cff:	mov    %rax,0x28(%rdi)
  423d03:	movl   $0x1,0x1c(%rdi)
  423d0a:	mov    0x10(%rdi),%rax
  423d0e:	mov    %rax,%rcx
  423d11:	add    $0xfffffffffffffff8,%rcx
  423d15:	mov    %rcx,0x10(%rdi)
  423d19:	mov    -0x8(%rax),%rax
  423d1d:	mov    %eax,0x20(%rdi)
  423d20:	mov    $0x0,%eax
  423d25:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423d2a:	xchg   %r14,%r13
  423d2d:	mov    %r15,%rbx
  423d30:	mov    %r14,-0x38e0(%rbp)
  423d37:	mov    %r13,-0x38d8(%rbp)
  423d3e:	mov    0x8(%rdi),%r8
  423d42:	mov    0x8(%r8),%rax
  423d46:	cmp    $0x0,%rax
  423d4a:	jne    423d68 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x37d8>
  423d4c:	lea    -0x38e0(%rbp),%rdx
  423d53:	mov    $0x2c,%esi
  423d58:	mov    %rdi,%r13
  423d5b:	callq  437550 <p125_rt_ctor2>
  423d60:	mov    %r13,%rdi
  423d63:	mov    %rax,%rcx
  423d66:	jmp    423da2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3812>
  423d68:	mov    (%rdi),%rcx
  423d6b:	mov    %rax,%rdx
  423d6e:	shl    $0x3,%rdx
  423d72:	mov    (%rcx,%rdx,1),%r9
  423d76:	mov    0x108(%r8),%rsi
  423d7d:	mov    %r9,0x8(%r8)
  423d81:	sub    $0x2,%rsi
  423d85:	mov    %rsi,0x108(%r8)
  423d8c:	mov    %r14,(%rcx,%rdx,1)
  423d90:	mov    %r13,0x8(%rcx,%rdx,1)
  423d95:	movabs $0x2002c0000000000,%rcx
  423d9f:	or     %rax,%rcx
  423da2:	mov    %rbx,-0x38e0(%rbp)
  423da9:	movabs $0x1002b0000000000,%rax
  423db3:	mov    %rax,-0x38d8(%rbp)
  423dba:	mov    %rcx,-0x38d0(%rbp)
  423dc1:	mov    0x8(%rdi),%r9
  423dc5:	mov    0x10(%r9),%rax
  423dc9:	cmp    $0x0,%rax
  423dcd:	jne    423deb <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x385b>
  423dcf:	lea    -0x38e0(%rbp),%rdx
  423dd6:	mov    $0x2d,%esi
  423ddb:	mov    %rdi,%rbx
  423dde:	callq  4377d0 <p125_rt_ctor3>
  423de3:	mov    %rbx,%rdi
  423de6:	mov    %rax,%rbx
  423de9:	jmp    423e37 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x38a7>
  423deb:	mov    (%rdi),%rdx
  423dee:	mov    %rax,%rsi
  423df1:	shl    $0x3,%rsi
  423df5:	mov    (%rdx,%rsi,1),%r10
  423df9:	mov    0x110(%r9),%r8
  423e00:	mov    %r10,0x10(%r9)
  423e04:	sub    $0x4,%r8
  423e08:	mov    %r8,0x110(%r9)
  423e0f:	mov    %rbx,(%rdx,%rsi,1)
  423e13:	movabs $0x1002b0000000000,%r8
  423e1d:	mov    %r8,0x8(%rdx,%rsi,1)
  423e22:	mov    %rcx,0x10(%rdx,%rsi,1)
  423e27:	movabs $0x2002d0000000000,%rcx
  423e31:	mov    %rax,%rbx
  423e34:	or     %rcx,%rbx
  423e37:	mov    %r12,-0x38e0(%rbp)
  423e3e:	movabs $0x1000b0000000000,%rax
  423e48:	mov    %rax,-0x38d8(%rbp)
  423e4f:	mov    0x8(%rdi),%r8
  423e53:	mov    0x8(%r8),%rax
  423e57:	cmp    $0x0,%rax
  423e5b:	jne    423e79 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x38e9>
  423e5d:	lea    -0x38e0(%rbp),%rdx
  423e64:	mov    $0x8,%esi
  423e69:	mov    %rdi,%r12
  423e6c:	callq  437550 <p125_rt_ctor2>
  423e71:	mov    %r12,%rdi
  423e74:	mov    %rax,%rcx
  423e77:	jmp    423ebd <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x392d>
  423e79:	mov    (%rdi),%rdx
  423e7c:	mov    %rax,%rsi
  423e7f:	shl    $0x3,%rsi
  423e83:	mov    (%rdx,%rsi,1),%r9
  423e87:	mov    0x108(%r8),%rcx
  423e8e:	mov    %r9,0x8(%r8)
  423e92:	sub    $0x2,%rcx
  423e96:	mov    %rcx,0x108(%r8)
  423e9d:	mov    %r12,(%rdx,%rsi,1)
  423ea1:	movabs $0x1000b0000000000,%rcx
  423eab:	mov    %rcx,0x8(%rdx,%rsi,1)
  423eb0:	movabs $0x200080000000000,%rcx
  423eba:	or     %rax,%rcx
  423ebd:	mov    %rbx,-0x38e0(%rbp)
  423ec4:	mov    %rcx,-0x38d8(%rbp)
  423ecb:	mov    0x8(%rdi),%r9
  423ecf:	mov    0x8(%r9),%rax
  423ed3:	cmp    $0x0,%rax
  423ed7:	jne    423ef2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3962>
  423ed9:	lea    -0x38e0(%rbp),%rdx
  423ee0:	mov    $0x8,%esi
  423ee5:	mov    %rdi,%rbx
  423ee8:	callq  437550 <p125_rt_ctor2>
  423eed:	mov    %rbx,%rdi
  423ef0:	jmp    423f32 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x39a2>
  423ef2:	cs cs cs mov %cs:(%rdi),%rdx
  423ef9:	cs cs mov %rax,%rsi
  423efe:	shl    $0x3,%rsi
  423f02:	mov    (%rdx,%rsi,1),%r10
  423f06:	mov    0x108(%r9),%r8
  423f0d:	mov    %r10,0x8(%r9)
  423f11:	sub    $0x2,%r8
  423f15:	mov    %r8,0x108(%r9)
  423f1c:	mov    %rbx,(%rdx,%rsi,1)
  423f20:	mov    %rcx,0x8(%rdx,%rsi,1)
  423f25:	movabs $0x200080000000000,%rcx
  423f2f:	or     %rcx,%rax
  423f32:	mov    %rax,-0x38e0(%rbp)
  423f39:	mov    0x1bcf8(%rip),%rcx        # 43fc38 <p111_program+0x58>
  423f40:	test   $0x4,%rcx
  423f47:	jne    423f5f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x39cf>
  423f49:	mov    $0x1,%edx
  423f4e:	lea    -0x38e0(%rbp),%rsi
  423f55:	callq  431ec0 <p111_rt_return>
  423f5a:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423f5f:	mov    %rax,0x28(%rdi)
  423f63:	movl   $0x1,0x1c(%rdi)
  423f6a:	mov    0x10(%rdi),%rax
  423f6e:	mov    %rax,%rcx
  423f71:	add    $0xfffffffffffffff8,%rcx
  423f75:	mov    %rcx,0x10(%rdi)
  423f79:	mov    -0x8(%rax),%rax
  423f7d:	mov    %eax,0x20(%rdi)
  423f80:	mov    $0x0,%eax
  423f85:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423f8a:	mov    %r14,%rsi
  423f8d:	cmp    $0x8,%r12
  423f91:	je     423fd4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3a44>
  423f93:	mov    %rsi,%r12
  423f96:	mov    %rbx,%rsi
  423f99:	mov    %rdi,%rbx
  423f9c:	callq  4318a0 <p111_rt_sink>
  423fa1:	mov    %r12,%rsi
  423fa4:	mov    %rbx,%rdi
  423fa7:	mov    %rsi,-0x38e0(%rbp)
  423fae:	mov    0x10(%rdi),%rax
  423fb2:	mov    %rsi,(%rax)
  423fb5:	movq   $0x153,0x8(%rax)
  423fbd:	add    $0x10,%rax
  423fc1:	mov    %rax,0x10(%rdi)
  423fc5:	mov    $0x4,%esi
  423fca:	callq  432030 <p111_rt_fail>
  423fcf:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  423fd4:	lea    -0x38e0(%rbp),%rdx
  423fdb:	mov    %rdi,%r12
  423fde:	callq  437640 <p125_rt_take2>
  423fe3:	mov    %r12,%rdi
  423fe6:	mov    -0x38e0(%rbp),%r12
  423fed:	mov    %rbx,%r13
  423ff0:	mov    -0x38d8(%rbp),%rbx
  423ff7:	cmp    $0x1,%rbx
  423ffb:	sete   %al
  423ffe:	movzbl %al,%eax
  424001:	mov    %rbx,%rcx
  424004:	shr    $0x28,%rcx
  424008:	and    $0x7fffff,%rcx
  42400f:	cmp    $0x10002,%rcx
  424016:	sete   %cl
  424019:	movzbl %cl,%ecx
  42401c:	mov    %eax,%edx
  42401e:	or     %ecx,%edx
  424020:	xor    $0x1,%edx
  424023:	jne    424271 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ce1>
  424029:	or     %ecx,%eax
  42402b:	jne    424076 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ae6>
  42402d:	mov    %r13,%rsi
  424030:	mov    %rdi,%r13
  424033:	callq  4318a0 <p111_rt_sink>
  424038:	mov    %r13,%rdi
  42403b:	mov    %r12,%rsi
  42403e:	mov    %rdi,%r12
  424041:	callq  4318a0 <p111_rt_sink>
  424046:	mov    %r12,%rdi
  424049:	mov    %rbx,-0x38e0(%rbp)
  424050:	mov    0x10(%rdi),%rax
  424054:	mov    %rbx,(%rax)
  424057:	movq   $0x152,0x8(%rax)
  42405f:	add    $0x10,%rax
  424063:	mov    %rax,0x10(%rdi)
  424067:	mov    $0x4,%esi
  42406c:	callq  432030 <p111_rt_fail>
  424071:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  424076:	mov    %r13,%rbx
  424079:	mov    %rbx,-0x38e0(%rbp)
  424080:	movabs $0x1002b0000000000,%rax
  42408a:	mov    %rax,-0x38d8(%rbp)
  424091:	movabs $0x1002b0000000000,%rax
  42409b:	mov    %rax,-0x38d0(%rbp)
  4240a2:	mov    0x8(%rdi),%r8
  4240a6:	mov    0x10(%r8),%rax
  4240aa:	cmp    $0x0,%rax
  4240ae:	jne    4240cc <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3b3c>
  4240b0:	lea    -0x38e0(%rbp),%rdx
  4240b7:	mov    $0x2d,%esi
  4240bc:	mov    %rdi,%rbx
  4240bf:	callq  4377d0 <p125_rt_ctor3>
  4240c4:	mov    %rbx,%rdi
  4240c7:	mov    %rax,%rbx
  4240ca:	jmp    424122 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3b92>
  4240cc:	mov    (%rdi),%rdx
  4240cf:	mov    %rax,%rsi
  4240d2:	shl    $0x3,%rsi
  4240d6:	mov    (%rdx,%rsi,1),%r9
  4240da:	mov    0x110(%r8),%rcx
  4240e1:	mov    %r9,0x10(%r8)
  4240e5:	sub    $0x4,%rcx
  4240e9:	mov    %rcx,0x110(%r8)
  4240f0:	mov    %rbx,(%rdx,%rsi,1)
  4240f4:	movabs $0x1002b0000000000,%rcx
  4240fe:	mov    %rcx,0x8(%rdx,%rsi,1)
  424103:	movabs $0x1002b0000000000,%rcx
  42410d:	mov    %rcx,0x10(%rdx,%rsi,1)
  424112:	movabs $0x2002d0000000000,%rcx
  42411c:	mov    %rax,%rbx
  42411f:	or     %rcx,%rbx
  424122:	mov    %r12,-0x38e0(%rbp)
  424129:	movabs $0x1000b0000000000,%rax
  424133:	mov    %rax,-0x38d8(%rbp)
  42413a:	mov    0x8(%rdi),%r8
  42413e:	mov    0x8(%r8),%rax
  424142:	cmp    $0x0,%rax
  424146:	jne    424164 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3bd4>
  424148:	lea    -0x38e0(%rbp),%rdx
  42414f:	mov    $0x8,%esi
  424154:	mov    %rdi,%r12
  424157:	callq  437550 <p125_rt_ctor2>
  42415c:	mov    %r12,%rdi
  42415f:	mov    %rax,%rcx
  424162:	jmp    4241aa <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3c1a>
  424164:	cs mov %cs:(%rdi),%rdx
  424169:	mov    %rax,%rsi
  42416c:	shl    $0x3,%rsi
  424170:	mov    (%rdx,%rsi,1),%r9
  424174:	mov    0x108(%r8),%rcx
  42417b:	mov    %r9,0x8(%r8)
  42417f:	sub    $0x2,%rcx
  424183:	mov    %rcx,0x108(%r8)
  42418a:	mov    %r12,(%rdx,%rsi,1)
  42418e:	movabs $0x1000b0000000000,%rcx
  424198:	mov    %rcx,0x8(%rdx,%rsi,1)
  42419d:	movabs $0x200080000000000,%rcx
  4241a7:	or     %rax,%rcx
  4241aa:	mov    %rbx,-0x38e0(%rbp)
  4241b1:	mov    %rcx,-0x38d8(%rbp)
  4241b8:	mov    0x8(%rdi),%r9
  4241bc:	mov    0x8(%r9),%rax
  4241c0:	cmp    $0x0,%rax
  4241c4:	jne    4241df <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3c4f>
  4241c6:	lea    -0x38e0(%rbp),%rdx
  4241cd:	mov    $0x8,%esi
  4241d2:	mov    %rdi,%rbx
  4241d5:	callq  437550 <p125_rt_ctor2>
  4241da:	mov    %rbx,%rdi
  4241dd:	jmp    424219 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3c89>
  4241df:	mov    (%rdi),%rdx
  4241e2:	mov    %rax,%rsi
  4241e5:	shl    $0x3,%rsi
  4241e9:	mov    (%rdx,%rsi,1),%r10
  4241ed:	mov    0x108(%r9),%r8
  4241f4:	mov    %r10,0x8(%r9)
  4241f8:	sub    $0x2,%r8
  4241fc:	mov    %r8,0x108(%r9)
  424203:	mov    %rbx,(%rdx,%rsi,1)
  424207:	mov    %rcx,0x8(%rdx,%rsi,1)
  42420c:	movabs $0x200080000000000,%rcx
  424216:	or     %rcx,%rax
  424219:	mov    %rax,-0x38e0(%rbp)
  424220:	mov    0x1ba11(%rip),%rcx        # 43fc38 <p111_program+0x58>
  424227:	test   $0x4,%rcx
  42422e:	jne    424246 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3cb6>
  424230:	mov    $0x1,%edx
  424235:	lea    -0x38e0(%rbp),%rsi
  42423c:	callq  431ec0 <p111_rt_return>
  424241:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  424246:	mov    %rax,0x28(%rdi)
  42424a:	movl   $0x1,0x1c(%rdi)
  424251:	mov    0x10(%rdi),%rax
  424255:	mov    %rax,%rcx
  424258:	add    $0xfffffffffffffff8,%rcx
  42425c:	mov    %rcx,0x10(%rdi)
  424260:	mov    -0x8(%rax),%rax
  424264:	mov    %eax,0x20(%rdi)
  424267:	mov    $0x0,%eax
  42426c:	jmpq   424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  424271:	mov    %r13,%rbx
  424274:	mov    %rbx,-0x38e0(%rbp)
  42427b:	movabs $0x1002b0000000000,%rax
  424285:	mov    %rax,-0x38d8(%rbp)
  42428c:	movabs $0x1002b0000000000,%rax
  424296:	mov    %rax,-0x38d0(%rbp)
  42429d:	mov    0x8(%rdi),%r8
  4242a1:	mov    0x10(%r8),%rax
  4242a5:	cmp    $0x0,%rax
  4242a9:	jne    4242c7 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3d37>
  4242ab:	lea    -0x38e0(%rbp),%rdx
  4242b2:	mov    $0x2d,%esi
  4242b7:	mov    %rdi,%rbx
  4242ba:	callq  4377d0 <p125_rt_ctor3>
  4242bf:	mov    %rbx,%rdi
  4242c2:	mov    %rax,%rbx
  4242c5:	jmp    424320 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3d90>
  4242c7:	cs cs mov %cs:(%rdi),%rdx
  4242cd:	mov    %rax,%rsi
  4242d0:	shl    $0x3,%rsi
  4242d4:	mov    (%rdx,%rsi,1),%r9
  4242d8:	mov    0x110(%r8),%rcx
  4242df:	mov    %r9,0x10(%r8)
  4242e3:	sub    $0x4,%rcx
  4242e7:	mov    %rcx,0x110(%r8)
  4242ee:	mov    %rbx,(%rdx,%rsi,1)
  4242f2:	movabs $0x1002b0000000000,%rcx
  4242fc:	mov    %rcx,0x8(%rdx,%rsi,1)
  424301:	movabs $0x1002b0000000000,%rcx
  42430b:	mov    %rcx,0x10(%rdx,%rsi,1)
  424310:	movabs $0x2002d0000000000,%rcx
  42431a:	mov    %rax,%rbx
  42431d:	or     %rcx,%rbx
  424320:	mov    %r12,-0x38e0(%rbp)
  424327:	movabs $0x1000b0000000000,%rax
  424331:	mov    %rax,-0x38d8(%rbp)
  424338:	mov    0x8(%rdi),%r8
  42433c:	mov    0x8(%r8),%rax
  424340:	cmp    $0x0,%rax
  424344:	jne    424362 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3dd2>
  424346:	lea    -0x38e0(%rbp),%rdx
  42434d:	mov    $0x8,%esi
  424352:	mov    %rdi,%r12
  424355:	callq  437550 <p125_rt_ctor2>
  42435a:	mov    %r12,%rdi
  42435d:	mov    %rax,%rcx
  424360:	jmp    4243aa <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3e1a>
  424362:	cs cs cs mov %cs:(%rdi),%rdx
  424369:	mov    %rax,%rsi
  42436c:	shl    $0x3,%rsi
  424370:	mov    (%rdx,%rsi,1),%r9
  424374:	mov    0x108(%r8),%rcx
  42437b:	mov    %r9,0x8(%r8)
  42437f:	sub    $0x2,%rcx
  424383:	mov    %rcx,0x108(%r8)
  42438a:	mov    %r12,(%rdx,%rsi,1)
  42438e:	movabs $0x1000b0000000000,%rcx
  424398:	mov    %rcx,0x8(%rdx,%rsi,1)
  42439d:	movabs $0x200080000000000,%rcx
  4243a7:	or     %rax,%rcx
  4243aa:	mov    %rbx,-0x38e0(%rbp)
  4243b1:	mov    %rcx,-0x38d8(%rbp)
  4243b8:	mov    0x8(%rdi),%r9
  4243bc:	mov    0x8(%r9),%rax
  4243c0:	cmp    $0x0,%rax
  4243c4:	jne    4243df <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3e4f>
  4243c6:	lea    -0x38e0(%rbp),%rdx
  4243cd:	mov    $0x8,%esi
  4243d2:	mov    %rdi,%rbx
  4243d5:	callq  437550 <p125_rt_ctor2>
  4243da:	mov    %rbx,%rdi
  4243dd:	jmp    424419 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3e89>
  4243df:	mov    (%rdi),%rdx
  4243e2:	mov    %rax,%rsi
  4243e5:	shl    $0x3,%rsi
  4243e9:	mov    (%rdx,%rsi,1),%r10
  4243ed:	mov    0x108(%r9),%r8
  4243f4:	mov    %r10,0x8(%r9)
  4243f8:	sub    $0x2,%r8
  4243fc:	mov    %r8,0x108(%r9)
  424403:	mov    %rbx,(%rdx,%rsi,1)
  424407:	mov    %rcx,0x8(%rdx,%rsi,1)
  42440c:	movabs $0x200080000000000,%rcx
  424416:	or     %rcx,%rax
  424419:	mov    %rax,-0x38e0(%rbp)
  424420:	mov    0x1b811(%rip),%rcx        # 43fc38 <p111_program+0x58>
  424427:	test   $0x4,%rcx
  42442e:	jne    424443 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3eb3>
  424430:	mov    $0x1,%edx
  424435:	lea    -0x38e0(%rbp),%rsi
  42443c:	callq  431ec0 <p111_rt_return>
  424441:	jmp    424469 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
  424443:	mov    %rax,0x28(%rdi)
  424447:	movl   $0x1,0x1c(%rdi)
  42444e:	mov    0x10(%rdi),%rax
  424452:	mov    %rax,%rcx
  424455:	add    $0xfffffffffffffff8,%rcx
  424459:	mov    %rcx,0x10(%rdi)
  42445d:	mov    -0x8(%rax),%rax
  424461:	mov    %eax,0x20(%rdi)
  424464:	mov    $0x0,%eax
  424469:	pop    %r15
  42446b:	pop    %r14
  42446d:	pop    %r13
  42446f:	pop    %r12
  424471:	pop    %rbx
  424472:	leaveq 
  424473:	retq   

Disassembly of section .fini:
