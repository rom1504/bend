
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e60 <nx_string_reverse>:
  401e60:	endbr64 
  401e64:	push   %rbp
  401e65:	mov    %rsp,%rbp
  401e68:	sub    $0x18,%rsp
  401e6c:	push   %rbx
  401e6d:	mov    %rdx,%rax
  401e70:	mov    %rax,%rdx
  401e73:	data16 nopw %cs:0x0(%rax,%rax,1)
  401e7e:	xchg   %ax,%ax
  401e80:	mov    %rsi,%rax
  401e83:	shr    $0x28,%rax
  401e87:	and    $0xffff,%rax
  401e8d:	cmp    $0x2,%rax
  401e91:	je     401ec8 <nx_string_reverse+0x68>
  401e93:	cmp    $0x3,%rax
  401e97:	jne    401ebc <nx_string_reverse+0x5c>
  401e99:	mov    %rdi,%rbx
  401e9c:	callq  403c90 <nx_rt_pair_rebuild2_c3_k0>
  401ea1:	mov    %rbx,%rdi
  401ea4:	mov    %rax,%rcx
  401ea7:	mov    %rdx,%rax
  401eaa:	mov    %rcx,-0x10(%rbp)
  401eae:	mov    %rax,-0x8(%rbp)
  401eb2:	mov    -0x10(%rbp),%rdx
  401eb6:	mov    -0x8(%rbp),%rsi
  401eba:	jmp    401e80 <nx_string_reverse+0x20>
  401ebc:	mov    $0x1,%esi
  401ec1:	callq  4026b0 <nx_rt_fail>
  401ec6:	jmp    401ecb <nx_string_reverse+0x6b>
  401ec8:	mov    %rdx,%rax
  401ecb:	pop    %rbx
  401ecc:	leaveq 
  401ecd:	retq   

Disassembly of section .fini:
