#!/usr/bin/env python3
"""Prepare a bounded exact-runtime-name classifier experiment; execute no targets."""
import argparse,collections,hashlib,json,re,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'experiments/phase147/tools'))
from prepare import assembly,extract,guard,pin,require,write_json,fresh_output
ACCEPTED=['p111_rt_'+s for s in ['keep','sink','ctor','take','closure','tag','frame','jump','return','apply','stack_pop','stack_get','reg_get','fail','op','special_ctor','special_test','special_take']]+['p113_rt_array_pair','p118_rt_extend','p118_rt_finish','p118_rt_borrow_fields','p126_rt_nat_divmod','p118_rt_borrow_scalar_safe','p125_rt_concat_typed']

def pattern(s,tail='SNil{}'):
    for c in reversed(s):tail='SCon{Chr{'+str(ord(c))+'},'+tail+'}'
    return tail

def candidate():
    main=['# Exact closed-name Boolean recognizer. No prefix-only acceptance or hashing.','def p147z_runtime(symbol: String) -> Bool:','  match symbol:']
    helpers=[]
    for prefix,group in [('p111_rt_',[x[8:]for x in ACCEPTED if x.startswith('p111_rt_')]),('p118_rt_',[x[8:]for x in ACCEPTED if x.startswith('p118_rt_')])]:
        name='p147z_runtime_'+prefix[1:4]
        main.append('    case '+pattern(prefix,'rest')+': '+name+'(rest)')
        helpers+=['','def '+name+'(symbol: String) -> Bool:','  match symbol:']
        helpers+=['    case '+pattern(s)+': True{}'for s in group]
        helpers+=['    case _: False{}']
    main+=['    case '+pattern(s)+': True{}'for s in ACCEPTED if not(s.startswith('p111_rt_')or s.startswith('p118_rt_'))]
    return '\n'.join(main+['    case _: False{}']+helpers)+'\n'

def fixtures():
    values=set(ACCEPTED)|{'','p','p111','p111_rt_','p118_rt_','p112_rt_keep','p111_rt','p111_rt_unknown','p111_rt_keеp','p111_rt_keep\x00','p111_rt_Ｋeep','p111_rt_💡','p111_rt_keep.tail','p125_rt_take2','p125_rt_ctor2'}
    for s in ACCEPTED:
        values.update(s[:i]for i in range(len(s)))
        values.update([s+'x','x'+s,s.upper(),s.replace('_','.',1)])
        values.update(s[:i]+'X'+s[i+1:]for i in range(len(s)))
    return [{'symbol':s,'expected':s in ACCEPTED}for s in sorted(values)]

def capture_counts(p):
    d=json.loads(p.read_text());require(d['complete']and d['originalAccepted'],'Unaccepted capture')
    counter=collections.Counter();todo=[d['raw'],d['direct']]
    while todo:
        x=todo.pop()
        if isinstance(x,dict):
            if x.get('$')=='N111Call':counter[x['symbol']]+=1
            todo.extend(x.values())
        elif isinstance(x,list):todo.extend(x)
    return counter

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--out',required=True,type=Path);a=ap.parse_args();out=fresh_output(a.out,ROOT)
    canonical=assembly.maintained_assemble(ROOT/'selfhost/src/compiler.json',ROOT/'selfhost','qbe');_,blocks=assembly.blocks(canonical);by={r['name']:r for r in blocks if r['kind']=='def'}
    signature=by['p111v_signature']['data'].decode();runtime=by['p118z_runtime']['data'].decode()
    from_signature=re.findall(r'String.eq\(symbol,"([^"]+)"\)',signature)
    from_runtime=re.findall(r'String.eq\(symbol,"([^"]+)"\)',runtime)
    require(from_signature+from_runtime==ACCEPTED,'Actual production symbol set changed')
    module=ROOT/'selfhost/tests/phase147/runtime-classifier.bend';require(module.read_text()==candidate(),'Frozen candidate differs from generator')
    rows=fixtures();write_json(out/'cases.json',{'kind':'phase147-runtime-classifier-cases','complete':True,'accepted':ACCEPTED,'cases':rows,'scope':'Manual reviewed closed-set oracle; allproperprefixes, everypositionmutation, suffix/case/prefixcollisions andUnicode near-misses. No hashused.'})
    body,inventory=extract([('canonical',canonical),('classifier',module.read_bytes())],['p118z_runtime','p147z_runtime','p111v_signature'],200000)
    (out/'api.bend').write_bytes(body);write_json(out/'exports.json',{'kind':'bend-hosted-api-exports','version':1,'exports':['p118z_runtime','p147z_runtime','p111v_signature'],'protocol':'hosted-api-v1','targets':['qbe'],'preparationModes':['live'],'scope':'Bounded comparison API only; no compilerimage promotion.'})
    capture=ROOT/'selfhost/build/phase147/verifier-capture01';counts=collections.Counter();captures=[]
    for name in ['compiler-verifier-slice','lexer','coverage-map-churn-128']:
        p=capture/(name+'.json');c=capture_counts(p);counts.update(c);captures.append({'source':pin(p),'counts':dict(c),'scope':'Actual N111Call values in selected complete captured functions, not allfullcompilerIR or dynamiccalls.'})
    qbe=ROOT/'selfhost/build/phase147/cold-baseline01/program.ssa';machine=collections.Counter()
    with qbe.open()as f:
        for line in f:
            m=re.search(r'\bcall \$(p[0-9]+_rt_[A-Za-z0-9_]+)\(',line)
            if m:machine[m[1]]+=1
    write_json(out/'symbol-census.json',{'complete':True,'captures':captures,'selectedFunctionSymbols':dict(counts),'fullQbe':pin(qbe),'machineCallSites':dict(machine),'warning':'Machine callsites canhave loweredspecializations absentfromsourceeligibility classes. Staticcounts only; notdynamicfrequencies.'})
    # Frequency-compressed actual selected-function symbols: loop counts are data,
    # while runtime salt prevents specialization to compile-time-known names.
    weighted=sorted(counts.items());data='['+','.join('P147ZCase{'+json.dumps(s)+','+str(n)+'}'for s,n in weighted)+']'
    fixture='''type P147ZCase is Data:
  P147ZCase{+symbol: String, +count: U32}

def p147z_cases() -> List<&2,P147ZCase>:
  '''+data+'\n'
    harness=['''
@unsafe
def p147z_salt(rows: List<&2,P147ZCase>, +salt: String) -> List<&2,P147ZCase>:
  match rows:
    case Nil{}: []
    case Con{P147ZCase{name,count},rest}: Con{P147ZCase{salt ++ name,count},p147z_salt(rest,salt)}
''']
    for mode,fn in [('old','p118z_runtime'),('new','p147z_runtime')]:harness.append(f'''
@unsafe
def p147z_{mode}_one(+symbol: String, left: U32, count: U32) -> U32:
  match left:
    case 0: count
    case _: p147z_{mode}_one(symbol,U32.sub(left,1),U32.add(count,Bool.to_u32({fn}(symbol))))

@unsafe
def p147z_{mode}_rows(rows: List<&2,P147ZCase>, count: U32) -> U32:
  match rows:
    case Nil{{}}: count
    case Con{{P147ZCase{{symbol,n}},rest}}: p147z_{mode}_rows(rest,p147z_{mode}_one(symbol,n,count))

@unsafe
def p147z_{mode}_loop(+rows: List<&2,P147ZCase>, left: U32, count: U32) -> U32:
  match left:
    case 0: count
    case _: p147z_{mode}_loop(rows,U32.sub(left,1),U32.add(count,p147z_{mode}_rows(rows,0)))
''')
    harness.append('''
@unsafe
def p147z_run(+mode: String, parsed: Maybe<&2,U32>, salt: String) -> IO(Unit):
  match parsed:
    case Some{+count}:
      +rows = p147z_salt(p147z_cases(),salt)
      nt_choose(IO(Unit),U32.is_le(count,100000) && (String.eq(mode,"old") || String.eq(mode,"new")),
        u => IO.print(U32.show(nt_choose(U32,String.eq(mode,"new"),v => p147z_new_loop(rows,count,0),v => p147z_old_loop(rows,count,0)))),
        u => IO.die(Unit,2,"expected old/new and count<=100000"))
    case None{}: IO.die(Unit,2,"invalid count")

@unsafe
def p147z_args(args: List<&1,String>) -> IO(Unit):
  match args:
    case Con{program,Con{mode,Con{count,Con{salt,Nil{}}}}}: p147z_run(mode,U32.read(count),salt)
    case _: IO.die(Unit,2,"usage: classifier old/new REPEATS SALT")

@unsafe
def main() -> IO(Unit):
  do IO<Unit>:
    args : List<&1,String> <- IO.args()
    p147z_args(args)
''')
    fixture=fixture.encode();harness='\n'.join(harness).encode();native,closed=extract([('api',body),('fixture',fixture),('harness',harness)],['main'],200000)
    (out/'native.bend').write_bytes(native);(out/'fixture.bend').write_bytes(fixture);(out/'harness.bend').write_bytes(harness)
    jobs=[guard('runtime-classifier-api',out/'api',[ROOT/'selfhost/.assets/bin/bun',ROOT/'selfhost/tools/build/hosted.mjs','acquire','--source',out/'api.bend','--exports',out/'exports.json','--upstream',ROOT/'selfhost/.bootstrap/upstream-phase66','--engine',ROOT/'selfhost/.assets/bin/bun','--out',out/'api'],90,2048,128),guard('runtime-classifier-native',out/'native',['python3','-B',ROOT/'selfhost/tools/build/native.py','--assets',ROOT/'selfhost/manifests/assets-native.json','--host','native','--target','qbe','--stage','N2','--image-key','qbe-n2','--mode','cache','--source',out/'native.bend','--out',out/'native','--seconds','90'],120,2048,128)]
    write_json(out/'jobs.json',jobs)
    write_json(out/'manifest.json',{'kind':'phase147-runtime-classifier-preparation','complete':True,'targetsRun':False,'sourceIdentity':{'bytes':len(canonical),'sha256':hashlib.sha256(canonical).hexdigest()},'candidate':pin(module),'inputs':[pin(__file__),pin(ROOT/'experiments/phase147/tools/prepare.py'),pin(ROOT/'selfhost/src/compiler.json')],'originalDeclarations':{n:by[n]['data'].decode()for n in ['p118z_runtime','p111v_signature']},'apiSource':pin(out/'api.bend'),'nativeSource':pin(out/'native.bend'),'cases':pin(out/'cases.json'),'symbolCensus':pin(out/'symbol-census.json'),'apiDeclarations':inventory,'nativeDeclarations':closed,'expectedPerIteration':sum(n for s,n in weighted if s in ACCEPTED),'allWeightedCallsPerIteration':sum(counts.values()),'argv':['--threads','1','--gpu','off','--','classifier','old|new','REPEATS','SALT'],'saltControls':{'':'expectedPerIteration * REPEATS followedbynewline','!':'0 followedbynewline'},'scope':'Original/candidate onebinary; runtimeinput salt/repetition. Actualselectedfunction symbolfrequency compressed. No fullcompiler speedclaim or canonicalchange.'})
    print(json.dumps({'complete':True,'cases':len(rows),'weightedCalls':sum(counts.values()),'jobs':str(out/'jobs.json')}))
if __name__=='__main__':main()
