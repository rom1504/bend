
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403320 <nx_rt_rebuild2_c1_k0>:
  403320:	push   %r13
  403322:	mov    %rsi,%r10
  403325:	mov    %rdx,%r8
  403328:	movabs $0xffffffffff,%r9
  403332:	push   %r12
  403334:	and    %r10,%r9
  403337:	push   %rbp
  403338:	lea    0x0(,%r9,8),%rax
  403340:	push   %rbx
  403341:	mov    %rdi,%rbx
  403344:	sub    $0x28,%rsp
  403348:	mov    (%rdi),%rdi
  40334b:	mov    0x8(%rbx),%rsi
  40334f:	lea    (%rdi,%rax,1),%rdx
  403353:	test   %r10,%r10
  403356:	js     4033c0 <nx_rt_rebuild2_c1_k0+0xa0>
  403358:	mov    (%rdx),%r12
  40335b:	mov    0x8(%rdi,%rax,1),%rbp
  403360:	cmp    $0x310817f,%r9
  403367:	jbe    403398 <nx_rt_rebuild2_c1_k0+0x78>
  403369:	mov    %rbp,0x10(%rbx)
  40336d:	mov    %r12,%rcx
  403370:	mov    $0x1,%edx
  403375:	movq   $0xffffffffffffffff,0x18(%rbx)
  40337d:	movl   $0x1,0x20(%rbx)
  403384:	add    $0x28,%rsp
  403388:	pop    %rbx
  403389:	pop    %rbp
  40338a:	pop    %r12
  40338c:	pop    %r13
  40338e:	jmpq   401f70 <nx_construct2>
  403393:	nopl   0x0(%rax,%rax,1)
  403398:	mov    0x8(%rsi),%r9
  40339c:	test   %r9,%r9
  40339f:	je     4016c4 <nx_rt_rebuild2_c1_k0.cold>
  4033a5:	mov    (%rdi,%r9,8),%rax
  4033a9:	subq   $0x2,0x108(%rsi)
  4033b1:	mov    %rax,0x8(%rsi)
  4033b5:	jmp    403369 <nx_rt_rebuild2_c1_k0+0x49>
  4033b7:	nopw   0x0(%rax,%rax,1)
  4033c0:	mov    0x4(%rdx),%eax
  4033c3:	mov    (%rdx),%ecx
  4033c5:	shl    $0x20,%rax
  4033c9:	or     %rcx,%rax
  4033cc:	mov    %rax,%r13
  4033cf:	and    $0xffffff,%eax
  4033d4:	shr    $0x18,%r13
  4033d8:	lea    0x0(,%r13,8),%r11
  4033e0:	lea    (%rdi,%r11,1),%rbp
  4033e4:	lea    0x8(%rdi,%r11,1),%r11
  4033e9:	cmp    $0x1,%rax
  4033ed:	jne    40170a <nx_rt_rebuild2_c1_k0.cold+0x46>
  4033f3:	mov    (%rdx),%eax
  4033f5:	mov    (%rsi),%rax
  4033f8:	mov    0x0(%rbp),%r12
  4033fc:	mov    (%r11),%rbp
  4033ff:	mov    %rax,(%rdx)
  403402:	mov    0x100(%rsi),%rax
  403409:	mov    0x3ddc9(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40340f:	mov    %r9,(%rsi)
  403412:	add    $0x1,%rax
  403416:	mov    %rax,0x100(%rsi)
  40341d:	cmp    %rdx,%rax
  403420:	jae    4016f4 <nx_rt_rebuild2_c1_k0.cold+0x30>
  403426:	mov    %r13,%r9
  403429:	jmpq   403360 <nx_rt_rebuild2_c1_k0+0x40>

Disassembly of section .fini:
