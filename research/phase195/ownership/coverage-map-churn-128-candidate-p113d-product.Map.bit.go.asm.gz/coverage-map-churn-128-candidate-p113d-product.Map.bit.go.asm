
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/coverage-map-churn-128/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000407351 <p113d_FID_36_112_114_111_100_117_99_116_46_77_97_112_46_98_105_116_46_103_111_>:
  407351:	push   %rbp
  407352:	mov    %rsp,%rbp
  407355:	sub    $0x930,%rsp
  40735c:	mov    %r12,-0x10(%rbp)
  407360:	mov    %rbx,-0x8(%rbp)
  407364:	mov    %rdi,%rax
  407367:	mov    %rax,%r12
  40736a:	mov    %rsi,%rax
  40736d:	mov    %rax,-0x30(%rbp)
  407371:	mov    %rdx,%rax
  407374:	mov    %rax,%rbx
  407377:	mov    %rcx,%rax
  40737a:	mov    %rax,%rdi
  40737d:	mov    %r8,%rax
  407380:	mov    %rax,%rsi
  407383:	mov    %r12,%r10
  407386:	mov    %r10,0x20(%rsp)
  40738b:	mov    %rbx,%r10
  40738e:	mov    %r10,0x28(%rsp)
  407393:	mov    %rdi,%r10
  407396:	mov    %r10,0x30(%rsp)
  40739b:	mov    %rsi,%r10
  40739e:	mov    %r10,0x38(%rsp)
  4073a3:	mov    0x20(%rsp),%rdi
  4073a8:	mov    0x28(%rsp),%rsi
  4073ad:	mov    0x30(%rsp),%rdx
  4073b2:	mov    0x38(%rsp),%rcx
  4073b7:	xor    %eax,%eax
  4073b9:	callq  406ef3 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>
  4073be:	mov    %rax,%rdi
  4073c1:	mov    %rbx,%r10
  4073c4:	mov    -0x30(%rbp),%r11
  4073c8:	mov    %r10,(%r11)
  4073cb:	mov    %rdi,%r10
  4073ce:	mov    -0x30(%rbp),%r11
  4073d2:	mov    %r10,0x8(%r11)
  4073d6:	xor    %eax,%eax
  4073d8:	mov    -0x10(%rbp),%r12
  4073dc:	mov    -0x8(%rbp),%rbx
  4073e0:	mov    %rbp,%rsp
  4073e3:	pop    %rbp
  4073e4:	retq   

Disassembly of section .fini:
