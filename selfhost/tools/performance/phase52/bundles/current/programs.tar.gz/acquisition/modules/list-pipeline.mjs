// Direct JavaScript backend runtime. Generated output embeds this fragment.
// Ported from bend2/comp.ts NATIVE.JS, RUNTIME and RUNTIME_MAIN, and
// bend2/bend.ts f32_round at fixed upstream commit
// 018751270e800bc222a93dad7f257083ee53a5f7. The reference files stay unchanged.
// No TypeScript compiler/runtime dependency is used by ordinary compilation.
// Number is the internal Nat representation; nat_host handles typed host input.
// Node foreign IO requires the host emitter to provide an ESM require binding.
// Bun/system calls remain lazy, exactly as in the pinned upstream runtime.

function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}
// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, String(io_sys().strerror(code))) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    for (;;) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io);
        continue;
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

// Direct core names. A named tail call carries all already-evaluated arguments;
// run_tail above retains the upstream unary native-closure protocol unchanged.
const jd_run = run_loop;
const jd_clo = run_clo;
function jd_tail(f, args) {
  return {$: "$JMP", f, x: args};
}


// Direct JavaScript prototype: native functions and live arguments.
function $jd$Nat_46_add($a0,$a1){return nat_chk($a0 + $a1);}
function $jd$Nat_46_sub($a0,$a1){return ($a0 < $a1 ? 0 : $a0 - $a1);}
function $jd$U32_46_add($a0,$a1){return (($a0 + $a1) >>> 0);}
function $jd$U32_46_and($a0,$a1){return (($a0 & $a1) >>> 0);}
function $jd$U32_46_xor($a0,$a1){return (($a0 ^ $a1) >>> 0);}
function $jd$U32_46_cmp($a0,$a1){return cmp_new($a0, $a1);}
function $jd$U32_46_is_95_eq($a0,$a1){return ($a0 === $a1);}
function $jd$U32_46_is_95_ne($a0,$a1){return ($a0 !== $a1);}
function $jd$U32_46_from_95_nat($a0){return ($a0 >>> 0);}
function $jd$Char_46_cmp($a0,$a1){for(;;){{const $match1=$a0;{const $match3=$a1;return ({$:"Tuple",["fst"]:({$:"Tuple",["fst"]:(
/*JD_USE:1458*/$match1),["snd"]:(
/*JD_USE:1459*/$match3)}),["snd"]:(
/*JD_REF:$jd$U32_46_cmp*/$jd$U32_46_cmp((
/*JD_USE:1458*/$match1.codePointAt(0)),(
/*JD_USE:1459*/$match3.codePointAt(0))))});}}}}
function $jd$String_46_cmp_46_rec($a0,$a1,$a2){for(;;){const $x1491=$a0;const $x1492=$a1;{const $match3=$a2;{const $match4=$match3["fst"];const $x1493=$match4["fst"];const $x1494=$match4["snd"];const $x1495=$match3["snd"];return ({$:"Tuple",["fst"]:({$:"Tuple",["fst"]:((
/*JD_USE:1491*/$x1491)+(
/*JD_USE:1493*/$x1493)),["snd"]:((
/*JD_USE:1492*/$x1492)+(
/*JD_USE:1494*/$x1494))}),["snd"]:(
/*JD_USE:1495*/$x1495)});}}}}
function $jd$String_46_cmp_46_fin($a0,$a1,$a2){for(;;){const $x1501=$a0;const $x1502=$a1;{const $match3=$a2;{const $match4=$match3["fst"];const $x1503=$match4["fst"];const $x1504=$match4["snd"];{const $match7=$match3["snd"];if($match7.$==="LT"){return ({$:"Tuple",["fst"]:({$:"Tuple",["fst"]:((
/*JD_USE:1503*/$x1503)+(
/*JD_USE:1501*/$x1501)),["snd"]:((
/*JD_USE:1504*/$x1504)+(
/*JD_USE:1502*/$x1502))}),["snd"]:({$:"LT"})});}else{{const $match8=$match7;if($match8.$==="EQ"){return (
/*JD_REF:$jd$String_46_cmp_46_rec*/$jd$String_46_cmp_46_rec((
/*JD_USE:1503*/$x1503),(
/*JD_USE:1504*/$x1504),(
/*JD_REF:$jd$String_46_cmp*/$jd$String_46_cmp((
/*JD_USE:1501*/$x1501),(
/*JD_USE:1502*/$x1502)))));}else{{const $match9=$match8;return ({$:"Tuple",["fst"]:({$:"Tuple",["fst"]:((
/*JD_USE:1503*/$x1503)+(
/*JD_USE:1501*/$x1501)),["snd"]:((
/*JD_USE:1504*/$x1504)+(
/*JD_USE:1502*/$x1502))}),["snd"]:({$:"GT"})});}}}}}}}}}
function $jd$String_46_cmp($a0,$a1){for(;;){{const $match1=$a0;if($match1===""){{const $match2=$a1;if($match2===""){return ({$:"Tuple",["fst"]:({$:"Tuple",["fst"]:"",["snd"]:""}),["snd"]:({$:"EQ"})});}else{{const $match3=$match2;const $x1507=($match3.codePointAt(0)>0xFFFF?$match3.slice(0,2):$match3[0]);const $x1508=($match3.codePointAt(0)>0xFFFF?$match3.slice(2):$match3.slice(1));return ({$:"Tuple",["fst"]:({$:"Tuple",["fst"]:"",["snd"]:((
/*JD_USE:1507*/$x1507)+(
/*JD_USE:1508*/$x1508))}),["snd"]:({$:"LT"})});}}}}else{{const $match2=$match1;const $x1509=($match2.codePointAt(0)>0xFFFF?$match2.slice(0,2):$match2[0]);const $x1510=($match2.codePointAt(0)>0xFFFF?$match2.slice(2):$match2.slice(1));{const $match5=$a1;if($match5===""){return ({$:"Tuple",["fst"]:({$:"Tuple",["fst"]:((
/*JD_USE:1509*/$x1509)+(
/*JD_USE:1510*/$x1510)),["snd"]:""}),["snd"]:({$:"GT"})});}else{{const $match6=$match5;const $x1511=($match6.codePointAt(0)>0xFFFF?$match6.slice(0,2):$match6[0]);const $x1512=($match6.codePointAt(0)>0xFFFF?$match6.slice(2):$match6.slice(1));return (
/*JD_REF:$jd$String_46_cmp_46_fin*/$jd$String_46_cmp_46_fin((
/*JD_USE:1510*/$x1510),(
/*JD_USE:1512*/$x1512),(
/*JD_REF:$jd$Char_46_cmp*/$jd$Char_46_cmp((
/*JD_USE:1509*/$x1509),(
/*JD_USE:1511*/$x1511)))));}}}}}}}}
function $jd$Map_46_bit_46_u($a0,$a1){for(;;){const $x2192=$a0;const $x2193=$a1;return (
/*JD_REF:$jd$U32_46_is_95_ne*/$jd$U32_46_is_95_ne((
/*JD_REF:$jd$U32_46_and*/$jd$U32_46_and((((
/*JD_USE:2193*/$x2193) >= 32 ? 0 : ((
/*JD_USE:2192*/$x2192) >>> (
/*JD_USE:2193*/$x2193)) >>> 0)),1)),0));}}
function $jd$Map_46_bit_46_chr($a0,$a1){for(;;){{const $match1=$a0;{const $match3=$a1;if($match3===0){return ({$:"Tuple",["fst"]:(
/*JD_USE:2196*/$match1),["snd"]:true});}else{const $x2197=($match3-1);return ({$:"Tuple",["fst"]:(
/*JD_USE:2196*/$match1),["snd"]:(
/*JD_REF:$jd$Map_46_bit_46_u*/$jd$Map_46_bit_46_u((
/*JD_USE:2196*/$match1.codePointAt(0)),((31 < (
/*JD_USE:2197*/$x2197) ? 0 : 31 - (
/*JD_USE:2197*/$x2197)))))});}}}}}
function $jd$Map_46_bit_46_go_46_chr($a0,$a1){for(;;){const $x2200=$a0;{const $match2=$a1;const $x2201=$match2["fst"];const $x2202=$match2["snd"];return ({$:"Tuple",["fst"]:((
/*JD_USE:2201*/$x2201)+(
/*JD_USE:2200*/$x2200)),["snd"]:(
/*JD_USE:2202*/$x2202)});}}}
function $jd$Map_46_bit_46_go_46_rec($a0,$a1){for(;;){const $x2205=$a0;{const $match2=$a1;const $x2206=$match2["fst"];const $x2207=$match2["snd"];return ({$:"Tuple",["fst"]:((
/*JD_USE:2205*/$x2205)+(
/*JD_USE:2206*/$x2206)),["snd"]:(
/*JD_USE:2207*/$x2207)});}}}
function $jd$Map_46_bit_46_go($a0,$a1,$a2){for(;;){{const $match1=$a0;if($match1===""){return ({$:"Tuple",["fst"]:"",["snd"]:false});}else{{const $match2=$match1;const $x2213=($match2.codePointAt(0)>0xFFFF?$match2.slice(0,2):$match2[0]);const $x2214=($match2.codePointAt(0)>0xFFFF?$match2.slice(2):$match2.slice(1));{const $match5=$a1;if($match5===0){const $x2215=$a2;return (
/*JD_REF:$jd$Map_46_bit_46_go_46_chr*/$jd$Map_46_bit_46_go_46_chr((
/*JD_USE:2214*/$x2214),(
/*JD_REF:$jd$Map_46_bit_46_chr*/$jd$Map_46_bit_46_chr((
/*JD_USE:2213*/$x2213),(
/*JD_USE:2215*/$x2215)))));}else{const $x2216=($match5-1);const $x2217=$a2;return (
/*JD_REF:$jd$Map_46_bit_46_go_46_rec*/$jd$Map_46_bit_46_go_46_rec((
/*JD_USE:2213*/$x2213),(
/*JD_REF:$jd$Map_46_bit_46_go*/$jd$Map_46_bit_46_go((
/*JD_USE:2214*/$x2214),(
/*JD_USE:2216*/$x2216),(
/*JD_USE:2217*/$x2217)))));}}}}}}}
function $jd$Map_46_bit_46_at($a0,$a1){for(;;){const $x2220=$a0;{const $match2=$a1;const $x2221=$match2["fst"];const $x2222=$match2["snd"];return (
/*JD_REF:$jd$Map_46_bit_46_go*/$jd$Map_46_bit_46_go((
/*JD_USE:2220*/$x2220),(
/*JD_USE:2221*/$x2221),(
/*JD_USE:2222*/$x2222)));}}}
function $jd$Map_46_bit($a0,$a1){for(;;){const $x2225=$a0;const $x2226=$a1;return (
/*JD_REF:$jd$Map_46_bit_46_at*/$jd$Map_46_bit_46_at((
/*JD_USE:2225*/$x2225),(nat_divmod((
/*JD_USE:2226*/$x2226), 33))));}}
function $jd$Map_46_msb_46_u_46_if($a0,$a1,$a2){for(;;){const $x2232=$a0;const $x2233=$a1;{const $match3=$a2;if($match3){return 0;}else{{const $match4=$match3;return (
/*JD_REF:$jd$Nat_46_add*/$jd$Nat_46_add(1,(
/*JD_REF:$jd$Map_46_msb_46_u*/$jd$Map_46_msb_46_u((
/*JD_USE:2232*/$x2232),((((
/*JD_USE:2233*/$x2233) >>> 1) >>> 0))))));}}}}}
function $jd$Map_46_msb_46_u($a0,$a1){for(;;){{const $match1=$a0;if($match1===0){return 0;}else{const $x2237=($match1-1);const $x2238=$a1;return (
/*JD_REF:$jd$Map_46_msb_46_u_46_if*/$jd$Map_46_msb_46_u_46_if((
/*JD_USE:2237*/$x2237),(
/*JD_USE:2238*/$x2238),(((
/*JD_USE:2238*/$x2238) === 0))));}}}}
function $jd$Map_46_diff_46_chr($a0){for(;;){const $x2240=$a0;return (
/*JD_REF:$jd$Nat_46_sub*/$jd$Nat_46_sub(33,(
/*JD_REF:$jd$Map_46_msb_46_u*/$jd$Map_46_msb_46_u(32,(
/*JD_USE:2240*/$x2240)))));}}
function $jd$Map_46_diff_46_step($a0,$a1){for(;;){{const $match1=$a0;{const $match3=$a1;return ({$:"Tuple",["fst"]:(
/*JD_REF:$jd$Map_46_diff_46_chr*/$jd$Map_46_diff_46_chr((
/*JD_REF:$jd$U32_46_xor*/$jd$U32_46_xor((
/*JD_USE:2243*/$match1.codePointAt(0)),(
/*JD_USE:2244*/$match3.codePointAt(0)))))),["snd"]:(
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_USE:2243*/$match1.codePointAt(0)),(
/*JD_USE:2244*/$match3.codePointAt(0))))});}}}}
function $jd$Map_46_diff_46_fin($a0,$a1,$a2){for(;;){const $x2250=$a0;const $x2251=$a1;{const $match3=$a2;const $x2252=$match3["fst"];{const $match5=$match3["snd"];if($match5){return (
/*JD_REF:$jd$Nat_46_add*/$jd$Nat_46_add(33,(
/*JD_REF:$jd$Map_46_diff*/$jd$Map_46_diff((
/*JD_USE:2250*/$x2250),(
/*JD_USE:2251*/$x2251)))));}else{{const $match6=$match5;return (
/*JD_USE:2252*/$x2252);}}}}}}
function $jd$Map_46_diff($a0,$a1){for(;;){{const $match1=$a0;if($match1===""){return 0;}else{{const $match2=$match1;const $x2256=($match2.codePointAt(0)>0xFFFF?$match2.slice(0,2):$match2[0]);const $x2257=($match2.codePointAt(0)>0xFFFF?$match2.slice(2):$match2.slice(1));{const $match5=$a1;if($match5===""){return 0;}else{{const $match6=$match5;const $x2258=($match6.codePointAt(0)>0xFFFF?$match6.slice(0,2):$match6[0]);const $x2259=($match6.codePointAt(0)>0xFFFF?$match6.slice(2):$match6.slice(1));return (
/*JD_REF:$jd$Map_46_diff_46_fin*/$jd$Map_46_diff_46_fin((
/*JD_USE:2257*/$x2257),(
/*JD_USE:2259*/$x2259),(
/*JD_REF:$jd$Map_46_diff_46_step*/$jd$Map_46_diff_46_step((
/*JD_USE:2256*/$x2256),(
/*JD_USE:2258*/$x2258)))));}}}}}}}}
function $jd$Map_46_put_46_go($a0,$a1,$a2){for(;;){const $x2269=null;const $x2270=null;{const $match3=$a0;if($match3.$==="MNode"){const $x2271=$match3["pos"];{const $match5=$match3["lo"];if($match5.$==="MTip"){{const $match6=$match3["hi"];if($match6.$==="MTip"){const $x2272=$a1;{const $match8=$a2;const $x2273=$match8["fst"];{const $match10=$match8["snd"];if(!$match10){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2273*/$x2273),["val"]:(
/*JD_USE:2272*/$x2272)}),["hi"]:({$:"MTip"})});}else{{const $match11=$match10;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MTip"}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2273*/$x2273),["val"]:(
/*JD_USE:2272*/$x2272)})});}}}}}else{{const $match7=$match6;if($match7.$==="MLeaf"){const $x2276=$match7["key"];const $x2277=$match7["val"];const $x2278=$a1;{const $match11=$a2;const $x2279=$match11["fst"];{const $match13=$match11["snd"];if(!$match13){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2279*/$x2279),["val"]:(
/*JD_USE:2278*/$x2278)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2276*/$x2276),["val"]:(
/*JD_USE:2277*/$x2277)})});}else{{const $match14=$match13;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MTip"}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2276*/$x2276),["val"]:(
/*JD_USE:2278*/$x2278)})});}}}}}else{{const $match8=$match7;const $x2282=$match8["pos"];const $x2283=$match8["lo"];const $x2284=$match8["hi"];const $x2285=$a1;{const $match13=$a2;const $x2286=$match13["fst"];{const $match15=$match13["snd"];if(!$match15){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2286*/$x2286),["val"]:(
/*JD_USE:2285*/$x2285)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2282*/$x2282),["lo"]:(
/*JD_USE:2283*/$x2283),["hi"]:(
/*JD_USE:2284*/$x2284)})});}else{{const $match16=$match15;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MTip"}),["hi"]:(
/*JD_REF:$jd$Map_46_put_46_go*/$jd$Map_46_put_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2282*/$x2282),["lo"]:(
/*JD_USE:2283*/$x2283),["hi"]:(
/*JD_USE:2284*/$x2284)}),(
/*JD_USE:2285*/$x2285),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2286*/$x2286),(
/*JD_USE:2282*/$x2282)))))});}}}}}}}}}}else{{const $match6=$match5;if($match6.$==="MLeaf"){const $x2294=$match6["key"];const $x2295=$match6["val"];{const $match9=$match3["hi"];if($match9.$==="MTip"){const $x2296=$a1;{const $match11=$a2;const $x2297=$match11["fst"];{const $match13=$match11["snd"];if(!$match13){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2294*/$x2294),["val"]:(
/*JD_USE:2296*/$x2296)}),["hi"]:({$:"MTip"})});}else{{const $match14=$match13;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2294*/$x2294),["val"]:(
/*JD_USE:2295*/$x2295)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2297*/$x2297),["val"]:(
/*JD_USE:2296*/$x2296)})});}}}}}else{{const $match10=$match9;if($match10.$==="MLeaf"){const $x2300=$match10["key"];const $x2301=$match10["val"];const $x2302=$a1;{const $match14=$a2;{const $match16=$match14["snd"];if(!$match16){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2294*/$x2294),["val"]:(
/*JD_USE:2302*/$x2302)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2300*/$x2300),["val"]:(
/*JD_USE:2301*/$x2301)})});}else{{const $match17=$match16;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2294*/$x2294),["val"]:(
/*JD_USE:2295*/$x2295)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2300*/$x2300),["val"]:(
/*JD_USE:2302*/$x2302)})});}}}}}else{{const $match11=$match10;const $x2306=$match11["pos"];const $x2307=$match11["lo"];const $x2308=$match11["hi"];const $x2309=$a1;{const $match16=$a2;const $x2310=$match16["fst"];{const $match18=$match16["snd"];if(!$match18){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2294*/$x2294),["val"]:(
/*JD_USE:2309*/$x2309)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2306*/$x2306),["lo"]:(
/*JD_USE:2307*/$x2307),["hi"]:(
/*JD_USE:2308*/$x2308)})});}else{{const $match19=$match18;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2294*/$x2294),["val"]:(
/*JD_USE:2295*/$x2295)}),["hi"]:(
/*JD_REF:$jd$Map_46_put_46_go*/$jd$Map_46_put_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2306*/$x2306),["lo"]:(
/*JD_USE:2307*/$x2307),["hi"]:(
/*JD_USE:2308*/$x2308)}),(
/*JD_USE:2309*/$x2309),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2310*/$x2310),(
/*JD_USE:2306*/$x2306)))))});}}}}}}}}}}else{{const $match7=$match6;const $x2318=$match7["pos"];const $x2319=$match7["lo"];const $x2320=$match7["hi"];{const $match11=$match3["hi"];if($match11.$==="MTip"){const $x2321=$a1;{const $match13=$a2;const $x2322=$match13["fst"];{const $match15=$match13["snd"];if(!$match15){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:(
/*JD_REF:$jd$Map_46_put_46_go*/$jd$Map_46_put_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2318*/$x2318),["lo"]:(
/*JD_USE:2319*/$x2319),["hi"]:(
/*JD_USE:2320*/$x2320)}),(
/*JD_USE:2321*/$x2321),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2322*/$x2322),(
/*JD_USE:2318*/$x2318))))),["hi"]:({$:"MTip"})});}else{{const $match16=$match15;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2318*/$x2318),["lo"]:(
/*JD_USE:2319*/$x2319),["hi"]:(
/*JD_USE:2320*/$x2320)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2322*/$x2322),["val"]:(
/*JD_USE:2321*/$x2321)})});}}}}}else{{const $match12=$match11;if($match12.$==="MLeaf"){const $x2325=$match12["key"];const $x2326=$match12["val"];const $x2327=$a1;{const $match16=$a2;const $x2328=$match16["fst"];{const $match18=$match16["snd"];if(!$match18){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:(
/*JD_REF:$jd$Map_46_put_46_go*/$jd$Map_46_put_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2318*/$x2318),["lo"]:(
/*JD_USE:2319*/$x2319),["hi"]:(
/*JD_USE:2320*/$x2320)}),(
/*JD_USE:2327*/$x2327),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2328*/$x2328),(
/*JD_USE:2318*/$x2318))))),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2325*/$x2325),["val"]:(
/*JD_USE:2326*/$x2326)})});}else{{const $match19=$match18;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2318*/$x2318),["lo"]:(
/*JD_USE:2319*/$x2319),["hi"]:(
/*JD_USE:2320*/$x2320)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2325*/$x2325),["val"]:(
/*JD_USE:2327*/$x2327)})});}}}}}else{{const $match13=$match12;const $x2331=$match13["pos"];const $x2332=$match13["lo"];const $x2333=$match13["hi"];const $x2334=$a1;{const $match18=$a2;const $x2335=$match18["fst"];{const $match20=$match18["snd"];if(!$match20){return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:(
/*JD_REF:$jd$Map_46_put_46_go*/$jd$Map_46_put_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2318*/$x2318),["lo"]:(
/*JD_USE:2319*/$x2319),["hi"]:(
/*JD_USE:2320*/$x2320)}),(
/*JD_USE:2334*/$x2334),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2335*/$x2335),(
/*JD_USE:2318*/$x2318))))),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2331*/$x2331),["lo"]:(
/*JD_USE:2332*/$x2332),["hi"]:(
/*JD_USE:2333*/$x2333)})});}else{{const $match21=$match20;return ({$:"MNode",["pos"]:(
/*JD_USE:2271*/$x2271),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2318*/$x2318),["lo"]:(
/*JD_USE:2319*/$x2319),["hi"]:(
/*JD_USE:2320*/$x2320)}),["hi"]:(
/*JD_REF:$jd$Map_46_put_46_go*/$jd$Map_46_put_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2331*/$x2331),["lo"]:(
/*JD_USE:2332*/$x2332),["hi"]:(
/*JD_USE:2333*/$x2333)}),(
/*JD_USE:2334*/$x2334),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2335*/$x2335),(
/*JD_USE:2331*/$x2331)))))});}}}}}}}}}}}}}}}else{const $x2364=$match3;return (
/*JD_USE:2364*/$x2364);}}}}
function $jd$Map_46_put($a0,$a1,$a2){for(;;){const $x2372=null;const $x2373=null;{const $match3=$a0;if($match3.$==="MTip"){const $x2374=$a1;const $x2375=$a2;return ({$:"MLeaf",["key"]:(
/*JD_USE:2374*/$x2374),["val"]:(
/*JD_USE:2375*/$x2375)});}else{{const $match4=$match3;if($match4.$==="MLeaf"){const $x2376=$match4["key"];const $x2379=$a2;return ({$:"MLeaf",["key"]:(
/*JD_USE:2376*/$x2376),["val"]:(
/*JD_USE:2379*/$x2379)});}else{{const $match5=$match4;const $x2380=$match5["pos"];const $x2381=$match5["lo"];const $x2382=$match5["hi"];const $x2383=$a1;const $x2384=$a2;return (
/*JD_REF:$jd$Map_46_put_46_go*/$jd$Map_46_put_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2380*/$x2380),["lo"]:(
/*JD_USE:2381*/$x2381),["hi"]:(
/*JD_USE:2382*/$x2382)}),(
/*JD_USE:2384*/$x2384),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2383*/$x2383),(
/*JD_USE:2380*/$x2380)))));}}}}}}}
function $jd$Map_46_ins_46_splice_46_bit($a0,$a1,$a2,$a3){for(;;){const $x2391=null;const $x2392=null;const $x2393=$a0;const $x2394=$a1;const $x2395=$a2;{const $match6=$a3;const $x2396=$match6["fst"];{const $match8=$match6["snd"];if(!$match8){return ({$:"MNode",["pos"]:(
/*JD_USE:2395*/$x2395),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2396*/$x2396),["val"]:(
/*JD_USE:2393*/$x2393)}),["hi"]:(
/*JD_USE:2394*/$x2394)});}else{{const $match9=$match8;return ({$:"MNode",["pos"]:(
/*JD_USE:2395*/$x2395),["lo"]:(
/*JD_USE:2394*/$x2394),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2396*/$x2396),["val"]:(
/*JD_USE:2393*/$x2393)})});}}}}}}
function $jd$Map_46_ins_46_splice($a0,$a1,$a2,$a3){for(;;){const $x2403=null;const $x2404=null;const $x2405=$a0;const $x2406=$a1;const $x2407=$a2;const $x2408=$a3;return (
/*JD_REF:$jd$Map_46_ins_46_splice_46_bit*/$jd$Map_46_ins_46_splice_46_bit((
/*JD_USE:2407*/$x2407),(
/*JD_USE:2408*/$x2408),(
/*JD_USE:2405*/$x2405),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2406*/$x2406),(
/*JD_USE:2405*/$x2405)))));}}
function $jd$Map_46_ins_46_go($a0,$a1,$a2,$a3,$a4){for(;;){const $x2416=null;const $x2417=null;{const $match3=$a0;if($match3.$==="MNode"){const $x2418=$match3["pos"];{const $match5=$match3["lo"];if($match5.$==="MTip"){{const $match6=$match3["hi"];if($match6.$==="MTip"){const $x2419=$a1;const $x2420=$a2;{const $match9=$a3;const $x2421=$match9["fst"];{const $match11=$match9["snd"];if(!$match11){{const $match12=$a4;if(!$match12){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2420*/$x2420),(
/*JD_USE:2421*/$x2421),(
/*JD_USE:2419*/$x2419),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:({$:"MTip"})})));}else{{const $match13=$match12;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2421*/$x2421),["val"]:(
/*JD_USE:2419*/$x2419)}),["hi"]:({$:"MTip"})});}}}}else{{const $match12=$match11;{const $match13=$a4;if(!$match13){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2420*/$x2420),(
/*JD_USE:2421*/$x2421),(
/*JD_USE:2419*/$x2419),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:({$:"MTip"})})));}else{{const $match14=$match13;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2421*/$x2421),["val"]:(
/*JD_USE:2419*/$x2419)})});}}}}}}}}else{{const $match7=$match6;if($match7.$==="MLeaf"){const $x2428=$match7["key"];const $x2429=$match7["val"];const $x2430=$a1;const $x2431=$a2;{const $match12=$a3;const $x2432=$match12["fst"];{const $match14=$match12["snd"];if(!$match14){{const $match15=$a4;if(!$match15){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2431*/$x2431),(
/*JD_USE:2432*/$x2432),(
/*JD_USE:2430*/$x2430),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2428*/$x2428),["val"]:(
/*JD_USE:2429*/$x2429)})})));}else{{const $match16=$match15;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2432*/$x2432),["val"]:(
/*JD_USE:2430*/$x2430)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2428*/$x2428),["val"]:(
/*JD_USE:2429*/$x2429)})});}}}}else{{const $match15=$match14;{const $match16=$a4;if(!$match16){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2431*/$x2431),(
/*JD_USE:2432*/$x2432),(
/*JD_USE:2430*/$x2430),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2428*/$x2428),["val"]:(
/*JD_USE:2429*/$x2429)})})));}else{{const $match17=$match16;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:(
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2431*/$x2431),(
/*JD_USE:2432*/$x2432),(
/*JD_USE:2430*/$x2430),({$:"MLeaf",["key"]:(
/*JD_USE:2428*/$x2428),["val"]:(
/*JD_USE:2429*/$x2429)})))});}}}}}}}}else{{const $match8=$match7;const $x2439=$match8["pos"];const $x2440=$match8["lo"];const $x2441=$match8["hi"];const $x2442=$a1;const $x2443=$a2;{const $match14=$a3;const $x2444=$match14["fst"];{const $match16=$match14["snd"];if(!$match16){{const $match17=$a4;if(!$match17){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2443*/$x2443),(
/*JD_USE:2444*/$x2444),(
/*JD_USE:2442*/$x2442),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2439*/$x2439),["lo"]:(
/*JD_USE:2440*/$x2440),["hi"]:(
/*JD_USE:2441*/$x2441)})})));}else{{const $match18=$match17;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2444*/$x2444),["val"]:(
/*JD_USE:2442*/$x2442)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2439*/$x2439),["lo"]:(
/*JD_USE:2440*/$x2440),["hi"]:(
/*JD_USE:2441*/$x2441)})});}}}}else{{const $match17=$match16;{const $match18=$a4;if(!$match18){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2443*/$x2443),(
/*JD_USE:2444*/$x2444),(
/*JD_USE:2442*/$x2442),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2439*/$x2439),["lo"]:(
/*JD_USE:2440*/$x2440),["hi"]:(
/*JD_USE:2441*/$x2441)})})));}else{{const $match19=$match18;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MTip"}),["hi"]:(
/*JD_REF:$jd$Map_46_ins_46_go*/$jd$Map_46_ins_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2439*/$x2439),["lo"]:(
/*JD_USE:2440*/$x2440),["hi"]:(
/*JD_USE:2441*/$x2441)}),(
/*JD_USE:2442*/$x2442),(
/*JD_USE:2443*/$x2443),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2444*/$x2444),(
/*JD_USE:2439*/$x2439))),(((
/*JD_USE:2439*/$x2439) < (
/*JD_USE:2443*/$x2443)))))});}}}}}}}}}}}}}else{{const $match6=$match5;if($match6.$==="MLeaf"){const $x2460=$match6["key"];const $x2461=$match6["val"];{const $match9=$match3["hi"];if($match9.$==="MTip"){const $x2462=$a1;const $x2463=$a2;{const $match12=$a3;const $x2464=$match12["fst"];{const $match14=$match12["snd"];if(!$match14){{const $match15=$a4;if(!$match15){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2463*/$x2463),(
/*JD_USE:2464*/$x2464),(
/*JD_USE:2462*/$x2462),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:({$:"MTip"})})));}else{{const $match16=$match15;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:(
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2463*/$x2463),(
/*JD_USE:2464*/$x2464),(
/*JD_USE:2462*/$x2462),({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}))),["hi"]:({$:"MTip"})});}}}}else{{const $match15=$match14;{const $match16=$a4;if(!$match16){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2463*/$x2463),(
/*JD_USE:2464*/$x2464),(
/*JD_USE:2462*/$x2462),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:({$:"MTip"})})));}else{{const $match17=$match16;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2464*/$x2464),["val"]:(
/*JD_USE:2462*/$x2462)})});}}}}}}}}else{{const $match10=$match9;if($match10.$==="MLeaf"){const $x2471=$match10["key"];const $x2472=$match10["val"];const $x2473=$a1;const $x2474=$a2;{const $match15=$a3;const $x2475=$match15["fst"];{const $match17=$match15["snd"];if(!$match17){{const $match18=$a4;if(!$match18){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2474*/$x2474),(
/*JD_USE:2475*/$x2475),(
/*JD_USE:2473*/$x2473),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2471*/$x2471),["val"]:(
/*JD_USE:2472*/$x2472)})})));}else{{const $match19=$match18;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:(
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2474*/$x2474),(
/*JD_USE:2475*/$x2475),(
/*JD_USE:2473*/$x2473),({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}))),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2471*/$x2471),["val"]:(
/*JD_USE:2472*/$x2472)})});}}}}else{{const $match18=$match17;{const $match19=$a4;if(!$match19){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2474*/$x2474),(
/*JD_USE:2475*/$x2475),(
/*JD_USE:2473*/$x2473),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2471*/$x2471),["val"]:(
/*JD_USE:2472*/$x2472)})})));}else{{const $match20=$match19;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:(
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2474*/$x2474),(
/*JD_USE:2475*/$x2475),(
/*JD_USE:2473*/$x2473),({$:"MLeaf",["key"]:(
/*JD_USE:2471*/$x2471),["val"]:(
/*JD_USE:2472*/$x2472)})))});}}}}}}}}else{{const $match11=$match10;const $x2482=$match11["pos"];const $x2483=$match11["lo"];const $x2484=$match11["hi"];const $x2485=$a1;const $x2486=$a2;{const $match17=$a3;const $x2487=$match17["fst"];{const $match19=$match17["snd"];if(!$match19){{const $match20=$a4;if(!$match20){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2486*/$x2486),(
/*JD_USE:2487*/$x2487),(
/*JD_USE:2485*/$x2485),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2482*/$x2482),["lo"]:(
/*JD_USE:2483*/$x2483),["hi"]:(
/*JD_USE:2484*/$x2484)})})));}else{{const $match21=$match20;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:(
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2486*/$x2486),(
/*JD_USE:2487*/$x2487),(
/*JD_USE:2485*/$x2485),({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}))),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2482*/$x2482),["lo"]:(
/*JD_USE:2483*/$x2483),["hi"]:(
/*JD_USE:2484*/$x2484)})});}}}}else{{const $match20=$match19;{const $match21=$a4;if(!$match21){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2486*/$x2486),(
/*JD_USE:2487*/$x2487),(
/*JD_USE:2485*/$x2485),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2482*/$x2482),["lo"]:(
/*JD_USE:2483*/$x2483),["hi"]:(
/*JD_USE:2484*/$x2484)})})));}else{{const $match22=$match21;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2460*/$x2460),["val"]:(
/*JD_USE:2461*/$x2461)}),["hi"]:(
/*JD_REF:$jd$Map_46_ins_46_go*/$jd$Map_46_ins_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2482*/$x2482),["lo"]:(
/*JD_USE:2483*/$x2483),["hi"]:(
/*JD_USE:2484*/$x2484)}),(
/*JD_USE:2485*/$x2485),(
/*JD_USE:2486*/$x2486),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2487*/$x2487),(
/*JD_USE:2482*/$x2482))),(((
/*JD_USE:2482*/$x2482) < (
/*JD_USE:2486*/$x2486)))))});}}}}}}}}}}}}}else{{const $match7=$match6;const $x2503=$match7["pos"];const $x2504=$match7["lo"];const $x2505=$match7["hi"];{const $match11=$match3["hi"];if($match11.$==="MTip"){const $x2506=$a1;const $x2507=$a2;{const $match14=$a3;const $x2508=$match14["fst"];{const $match16=$match14["snd"];if(!$match16){{const $match17=$a4;if(!$match17){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2507*/$x2507),(
/*JD_USE:2508*/$x2508),(
/*JD_USE:2506*/$x2506),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:({$:"MTip"})})));}else{{const $match18=$match17;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:(
/*JD_REF:$jd$Map_46_ins_46_go*/$jd$Map_46_ins_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),(
/*JD_USE:2506*/$x2506),(
/*JD_USE:2507*/$x2507),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2508*/$x2508),(
/*JD_USE:2503*/$x2503))),(((
/*JD_USE:2503*/$x2503) < (
/*JD_USE:2507*/$x2507))))),["hi"]:({$:"MTip"})});}}}}else{{const $match17=$match16;{const $match18=$a4;if(!$match18){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2507*/$x2507),(
/*JD_USE:2508*/$x2508),(
/*JD_USE:2506*/$x2506),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:({$:"MTip"})})));}else{{const $match19=$match18;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2508*/$x2508),["val"]:(
/*JD_USE:2506*/$x2506)})});}}}}}}}}else{{const $match12=$match11;if($match12.$==="MLeaf"){const $x2515=$match12["key"];const $x2516=$match12["val"];const $x2517=$a1;const $x2518=$a2;{const $match17=$a3;const $x2519=$match17["fst"];{const $match19=$match17["snd"];if(!$match19){{const $match20=$a4;if(!$match20){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2518*/$x2518),(
/*JD_USE:2519*/$x2519),(
/*JD_USE:2517*/$x2517),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2515*/$x2515),["val"]:(
/*JD_USE:2516*/$x2516)})})));}else{{const $match21=$match20;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:(
/*JD_REF:$jd$Map_46_ins_46_go*/$jd$Map_46_ins_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),(
/*JD_USE:2517*/$x2517),(
/*JD_USE:2518*/$x2518),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2519*/$x2519),(
/*JD_USE:2503*/$x2503))),(((
/*JD_USE:2503*/$x2503) < (
/*JD_USE:2518*/$x2518))))),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2515*/$x2515),["val"]:(
/*JD_USE:2516*/$x2516)})});}}}}else{{const $match20=$match19;{const $match21=$a4;if(!$match21){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2518*/$x2518),(
/*JD_USE:2519*/$x2519),(
/*JD_USE:2517*/$x2517),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2515*/$x2515),["val"]:(
/*JD_USE:2516*/$x2516)})})));}else{{const $match22=$match21;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:(
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2518*/$x2518),(
/*JD_USE:2519*/$x2519),(
/*JD_USE:2517*/$x2517),({$:"MLeaf",["key"]:(
/*JD_USE:2515*/$x2515),["val"]:(
/*JD_USE:2516*/$x2516)})))});}}}}}}}}else{{const $match13=$match12;const $x2526=$match13["pos"];const $x2527=$match13["lo"];const $x2528=$match13["hi"];const $x2529=$a1;const $x2530=$a2;{const $match19=$a3;const $x2531=$match19["fst"];{const $match21=$match19["snd"];if(!$match21){{const $match22=$a4;if(!$match22){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2530*/$x2530),(
/*JD_USE:2531*/$x2531),(
/*JD_USE:2529*/$x2529),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2526*/$x2526),["lo"]:(
/*JD_USE:2527*/$x2527),["hi"]:(
/*JD_USE:2528*/$x2528)})})));}else{{const $match23=$match22;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:(
/*JD_REF:$jd$Map_46_ins_46_go*/$jd$Map_46_ins_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),(
/*JD_USE:2529*/$x2529),(
/*JD_USE:2530*/$x2530),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2531*/$x2531),(
/*JD_USE:2503*/$x2503))),(((
/*JD_USE:2503*/$x2503) < (
/*JD_USE:2530*/$x2530))))),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2526*/$x2526),["lo"]:(
/*JD_USE:2527*/$x2527),["hi"]:(
/*JD_USE:2528*/$x2528)})});}}}}else{{const $match22=$match21;{const $match23=$a4;if(!$match23){return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2530*/$x2530),(
/*JD_USE:2531*/$x2531),(
/*JD_USE:2529*/$x2529),({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2526*/$x2526),["lo"]:(
/*JD_USE:2527*/$x2527),["hi"]:(
/*JD_USE:2528*/$x2528)})})));}else{{const $match24=$match23;return ({$:"MNode",["pos"]:(
/*JD_USE:2418*/$x2418),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2503*/$x2503),["lo"]:(
/*JD_USE:2504*/$x2504),["hi"]:(
/*JD_USE:2505*/$x2505)}),["hi"]:(
/*JD_REF:$jd$Map_46_ins_46_go*/$jd$Map_46_ins_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2526*/$x2526),["lo"]:(
/*JD_USE:2527*/$x2527),["hi"]:(
/*JD_USE:2528*/$x2528)}),(
/*JD_USE:2529*/$x2529),(
/*JD_USE:2530*/$x2530),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2531*/$x2531),(
/*JD_USE:2526*/$x2526))),(((
/*JD_USE:2526*/$x2526) < (
/*JD_USE:2530*/$x2530)))))});}}}}}}}}}}}}}}}}}}else{const $x2585=$match3;return (
/*JD_USE:2585*/$x2585);}}}}
function $jd$Map_46_ins($a0,$a1,$a2,$a3){for(;;){const $x2596=null;const $x2597=null;{const $match3=$a0;if($match3.$==="MTip"){const $x2598=$a1;const $x2599=$a2;return ({$:"MLeaf",["key"]:(
/*JD_USE:2598*/$x2598),["val"]:(
/*JD_USE:2599*/$x2599)});}else{{const $match4=$match3;if($match4.$==="MLeaf"){const $x2601=$match4["key"];const $x2602=$match4["val"];const $x2603=$a1;const $x2604=$a2;const $x2605=$a3;return (
/*JD_REF:$jd$Map_46_ins_46_splice*/$jd$Map_46_ins_46_splice((
/*JD_USE:2605*/$x2605),(
/*JD_USE:2603*/$x2603),(
/*JD_USE:2604*/$x2604),({$:"MLeaf",["key"]:(
/*JD_USE:2601*/$x2601),["val"]:(
/*JD_USE:2602*/$x2602)})));}else{{const $match5=$match4;const $x2606=$match5["pos"];const $x2607=$match5["lo"];const $x2608=$match5["hi"];const $x2609=$a1;const $x2610=$a2;const $x2611=$a3;return (
/*JD_REF:$jd$Map_46_ins_46_go*/$jd$Map_46_ins_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2606*/$x2606),["lo"]:(
/*JD_USE:2607*/$x2607),["hi"]:(
/*JD_USE:2608*/$x2608)}),(
/*JD_USE:2610*/$x2610),(
/*JD_USE:2611*/$x2611),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2609*/$x2609),(
/*JD_USE:2606*/$x2606))),(((
/*JD_USE:2606*/$x2606) < (
/*JD_USE:2611*/$x2611)))));}}}}}}}
function $jd$Map_46_lo($a0,$a1,$a2){for(;;){const $x2618=null;const $x2619=null;const $x2620=null;const $x2621=$a0;const $x2622=$a1;{const $match6=$a2;const $x2623=$match6["fst"];const $x2624=$match6["snd"];return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2621*/$x2621),["lo"]:(
/*JD_USE:2623*/$x2623),["hi"]:(
/*JD_USE:2622*/$x2622)}),["snd"]:(
/*JD_USE:2624*/$x2624)});}}}
function $jd$Map_46_hi($a0,$a1,$a2){for(;;){const $x2631=null;const $x2632=null;const $x2633=null;const $x2634=$a0;const $x2635=$a1;{const $match6=$a2;const $x2636=$match6["fst"];const $x2637=$match6["snd"];return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2634*/$x2634),["lo"]:(
/*JD_USE:2635*/$x2635),["hi"]:(
/*JD_USE:2636*/$x2636)}),["snd"]:(
/*JD_USE:2637*/$x2637)});}}}
function $jd$Map_46_seek_46_go($a0,$a1){for(;;){const $x2642=null;const $x2643=null;{const $match3=$a0;if($match3.$==="MNode"){const $x2644=$match3["pos"];{const $match5=$match3["lo"];if($match5.$==="MTip"){{const $match6=$match3["hi"];if($match6.$==="MTip"){{const $match7=$a1;const $x2645=$match7["fst"];{const $match9=$match7["snd"];if(!$match9){return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MTip"}),["hi"]:({$:"MTip"})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2645*/$x2645),["snd"]:({$:"None"})})});}else{{const $match10=$match9;return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MTip"}),["hi"]:({$:"MTip"})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2645*/$x2645),["snd"]:({$:"None"})})});}}}}}else{{const $match7=$match6;if($match7.$==="MLeaf"){const $x2647=$match7["key"];const $x2648=$match7["val"];{const $match10=$a1;const $x2649=$match10["fst"];{const $match12=$match10["snd"];if(!$match12){return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MTip"}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2647*/$x2647),["val"]:(
/*JD_USE:2648*/$x2648)})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2649*/$x2649),["snd"]:({$:"None"})})});}else{{const $match13=$match12;return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MTip"}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2647*/$x2647),["val"]:(
/*JD_USE:2648*/$x2648)})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2649*/$x2649),["snd"]:({$:"Some",["value"]:(
/*JD_USE:2647*/$x2647)})})});}}}}}else{{const $match8=$match7;const $x2651=$match8["pos"];const $x2652=$match8["lo"];const $x2653=$match8["hi"];{const $match12=$a1;const $x2654=$match12["fst"];{const $match14=$match12["snd"];if(!$match14){return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MTip"}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2651*/$x2651),["lo"]:(
/*JD_USE:2652*/$x2652),["hi"]:(
/*JD_USE:2653*/$x2653)})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2654*/$x2654),["snd"]:({$:"None"})})});}else{{const $match15=$match14;return (
/*JD_REF:$jd$Map_46_hi*/$jd$Map_46_hi((
/*JD_USE:2644*/$x2644),({$:"MTip"}),(
/*JD_REF:$jd$Map_46_seek_46_go*/$jd$Map_46_seek_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2651*/$x2651),["lo"]:(
/*JD_USE:2652*/$x2652),["hi"]:(
/*JD_USE:2653*/$x2653)}),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2654*/$x2654),(
/*JD_USE:2651*/$x2651)))))));}}}}}}}}}}else{{const $match6=$match5;if($match6.$==="MLeaf"){const $x2659=$match6["key"];const $x2660=$match6["val"];{const $match9=$match3["hi"];if($match9.$==="MTip"){{const $match10=$a1;const $x2661=$match10["fst"];{const $match12=$match10["snd"];if(!$match12){return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2659*/$x2659),["val"]:(
/*JD_USE:2660*/$x2660)}),["hi"]:({$:"MTip"})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2661*/$x2661),["snd"]:({$:"Some",["value"]:(
/*JD_USE:2659*/$x2659)})})});}else{{const $match13=$match12;return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2659*/$x2659),["val"]:(
/*JD_USE:2660*/$x2660)}),["hi"]:({$:"MTip"})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2661*/$x2661),["snd"]:({$:"None"})})});}}}}}else{{const $match10=$match9;if($match10.$==="MLeaf"){const $x2663=$match10["key"];const $x2664=$match10["val"];{const $match13=$a1;const $x2665=$match13["fst"];{const $match15=$match13["snd"];if(!$match15){return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2659*/$x2659),["val"]:(
/*JD_USE:2660*/$x2660)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2663*/$x2663),["val"]:(
/*JD_USE:2664*/$x2664)})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2665*/$x2665),["snd"]:({$:"Some",["value"]:(
/*JD_USE:2659*/$x2659)})})});}else{{const $match16=$match15;return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2659*/$x2659),["val"]:(
/*JD_USE:2660*/$x2660)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2663*/$x2663),["val"]:(
/*JD_USE:2664*/$x2664)})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2665*/$x2665),["snd"]:({$:"Some",["value"]:(
/*JD_USE:2663*/$x2663)})})});}}}}}else{{const $match11=$match10;const $x2667=$match11["pos"];const $x2668=$match11["lo"];const $x2669=$match11["hi"];{const $match15=$a1;const $x2670=$match15["fst"];{const $match17=$match15["snd"];if(!$match17){return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MLeaf",["key"]:(
/*JD_USE:2659*/$x2659),["val"]:(
/*JD_USE:2660*/$x2660)}),["hi"]:({$:"MNode",["pos"]:(
/*JD_USE:2667*/$x2667),["lo"]:(
/*JD_USE:2668*/$x2668),["hi"]:(
/*JD_USE:2669*/$x2669)})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2670*/$x2670),["snd"]:({$:"Some",["value"]:(
/*JD_USE:2659*/$x2659)})})});}else{{const $match18=$match17;return (
/*JD_REF:$jd$Map_46_hi*/$jd$Map_46_hi((
/*JD_USE:2644*/$x2644),({$:"MLeaf",["key"]:(
/*JD_USE:2659*/$x2659),["val"]:(
/*JD_USE:2660*/$x2660)}),(
/*JD_REF:$jd$Map_46_seek_46_go*/$jd$Map_46_seek_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2667*/$x2667),["lo"]:(
/*JD_USE:2668*/$x2668),["hi"]:(
/*JD_USE:2669*/$x2669)}),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2670*/$x2670),(
/*JD_USE:2667*/$x2667)))))));}}}}}}}}}}else{{const $match7=$match6;const $x2675=$match7["pos"];const $x2676=$match7["lo"];const $x2677=$match7["hi"];{const $match11=$match3["hi"];if($match11.$==="MTip"){{const $match12=$a1;const $x2678=$match12["fst"];{const $match14=$match12["snd"];if(!$match14){return (
/*JD_REF:$jd$Map_46_lo*/$jd$Map_46_lo((
/*JD_USE:2644*/$x2644),({$:"MTip"}),(
/*JD_REF:$jd$Map_46_seek_46_go*/$jd$Map_46_seek_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2675*/$x2675),["lo"]:(
/*JD_USE:2676*/$x2676),["hi"]:(
/*JD_USE:2677*/$x2677)}),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2678*/$x2678),(
/*JD_USE:2675*/$x2675)))))));}else{{const $match15=$match14;return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2675*/$x2675),["lo"]:(
/*JD_USE:2676*/$x2676),["hi"]:(
/*JD_USE:2677*/$x2677)}),["hi"]:({$:"MTip"})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2678*/$x2678),["snd"]:({$:"None"})})});}}}}}else{{const $match12=$match11;if($match12.$==="MLeaf"){const $x2680=$match12["key"];const $x2681=$match12["val"];{const $match15=$a1;const $x2682=$match15["fst"];{const $match17=$match15["snd"];if(!$match17){return (
/*JD_REF:$jd$Map_46_lo*/$jd$Map_46_lo((
/*JD_USE:2644*/$x2644),({$:"MLeaf",["key"]:(
/*JD_USE:2680*/$x2680),["val"]:(
/*JD_USE:2681*/$x2681)}),(
/*JD_REF:$jd$Map_46_seek_46_go*/$jd$Map_46_seek_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2675*/$x2675),["lo"]:(
/*JD_USE:2676*/$x2676),["hi"]:(
/*JD_USE:2677*/$x2677)}),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2682*/$x2682),(
/*JD_USE:2675*/$x2675)))))));}else{{const $match18=$match17;return ({$:"Tuple",["fst"]:({$:"MNode",["pos"]:(
/*JD_USE:2644*/$x2644),["lo"]:({$:"MNode",["pos"]:(
/*JD_USE:2675*/$x2675),["lo"]:(
/*JD_USE:2676*/$x2676),["hi"]:(
/*JD_USE:2677*/$x2677)}),["hi"]:({$:"MLeaf",["key"]:(
/*JD_USE:2680*/$x2680),["val"]:(
/*JD_USE:2681*/$x2681)})}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2682*/$x2682),["snd"]:({$:"Some",["value"]:(
/*JD_USE:2680*/$x2680)})})});}}}}}else{{const $match13=$match12;const $x2684=$match13["pos"];const $x2685=$match13["lo"];const $x2686=$match13["hi"];{const $match17=$a1;const $x2687=$match17["fst"];{const $match19=$match17["snd"];if(!$match19){return (
/*JD_REF:$jd$Map_46_lo*/$jd$Map_46_lo((
/*JD_USE:2644*/$x2644),({$:"MNode",["pos"]:(
/*JD_USE:2684*/$x2684),["lo"]:(
/*JD_USE:2685*/$x2685),["hi"]:(
/*JD_USE:2686*/$x2686)}),(
/*JD_REF:$jd$Map_46_seek_46_go*/$jd$Map_46_seek_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2675*/$x2675),["lo"]:(
/*JD_USE:2676*/$x2676),["hi"]:(
/*JD_USE:2677*/$x2677)}),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2687*/$x2687),(
/*JD_USE:2675*/$x2675)))))));}else{{const $match20=$match19;return (
/*JD_REF:$jd$Map_46_hi*/$jd$Map_46_hi((
/*JD_USE:2644*/$x2644),({$:"MNode",["pos"]:(
/*JD_USE:2675*/$x2675),["lo"]:(
/*JD_USE:2676*/$x2676),["hi"]:(
/*JD_USE:2677*/$x2677)}),(
/*JD_REF:$jd$Map_46_seek_46_go*/$jd$Map_46_seek_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2684*/$x2684),["lo"]:(
/*JD_USE:2685*/$x2685),["hi"]:(
/*JD_USE:2686*/$x2686)}),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2687*/$x2687),(
/*JD_USE:2684*/$x2684)))))));}}}}}}}}}}}}}}}else{const $x2707=$match3;{const $match5=$a1;const $x2708=$match5["fst"];return ({$:"Tuple",["fst"]:(
/*JD_USE:2707*/$x2707),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2708*/$x2708),["snd"]:({$:"None"})})});}}}}}
function $jd$Map_46_seek($a0,$a1){for(;;){const $x2714=null;const $x2715=null;{const $match3=$a0;if($match3.$==="MTip"){const $x2716=$a1;return ({$:"Tuple",["fst"]:({$:"MTip"}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2716*/$x2716),["snd"]:({$:"None"})})});}else{{const $match4=$match3;if($match4.$==="MLeaf"){const $x2717=$match4["key"];const $x2718=$match4["val"];const $x2719=$a1;return ({$:"Tuple",["fst"]:({$:"MLeaf",["key"]:(
/*JD_USE:2717*/$x2717),["val"]:(
/*JD_USE:2718*/$x2718)}),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:2719*/$x2719),["snd"]:({$:"Some",["value"]:(
/*JD_USE:2717*/$x2717)})})});}else{{const $match5=$match4;const $x2720=$match5["pos"];const $x2721=$match5["lo"];const $x2722=$match5["hi"];const $x2723=$a1;return (
/*JD_REF:$jd$Map_46_seek_46_go*/$jd$Map_46_seek_46_go(({$:"MNode",["pos"]:(
/*JD_USE:2720*/$x2720),["lo"]:(
/*JD_USE:2721*/$x2721),["hi"]:(
/*JD_USE:2722*/$x2722)}),(
/*JD_REF:$jd$Map_46_bit*/$jd$Map_46_bit((
/*JD_USE:2723*/$x2723),(
/*JD_USE:2720*/$x2720)))));}}}}}}}
function $jd$Map_46_set_46_fin_46_go($a0,$a1,$a2,$a3){for(;;){const $x2730=null;const $x2731=null;const $x2732=$a0;const $x2733=$a1;const $x2734=$a2;{const $match6=$a3;{const $match7=$match6["fst"];const $x2735=$match7["fst"];const $x2736=$match7["snd"];{const $match10=$match6["snd"];if($match10.$==="EQ"){return (
/*JD_REF:$jd$Map_46_put*/$jd$Map_46_put((
/*JD_USE:2732*/$x2732),(
/*JD_USE:2733*/$x2733),(
/*JD_USE:2734*/$x2734)));}else{return (
/*JD_REF:$jd$Map_46_ins*/$jd$Map_46_ins((
/*JD_USE:2732*/$x2732),(
/*JD_USE:2733*/$x2733),(
/*JD_USE:2734*/$x2734),(
/*JD_REF:$jd$Map_46_diff*/$jd$Map_46_diff((
/*JD_USE:2735*/$x2735),(
/*JD_USE:2736*/$x2736)))));}}}}}}
function $jd$Map_46_set_46_fin($a0,$a1,$a2,$a3,$a4){for(;;){const $x2745=null;const $x2746=null;const $x2747=$a0;const $x2748=$a1;const $x2749=$a2;const $x2750=$a3;const $x2751=$a4;return (
/*JD_REF:$jd$Map_46_set_46_fin_46_go*/$jd$Map_46_set_46_fin_46_go((
/*JD_USE:2747*/$x2747),(
/*JD_USE:2748*/$x2748),(
/*JD_USE:2749*/$x2749),(
/*JD_REF:$jd$String_46_cmp*/$jd$String_46_cmp((
/*JD_USE:2750*/$x2750),(
/*JD_USE:2751*/$x2751)))));}}
function $jd$Map_46_set_46_go($a0,$a1){for(;;){const $x2756=null;const $x2757=null;const $x2758=$a0;{const $match4=$a1;const $x2759=$match4["fst"];{const $match6=$match4["snd"];const $x2760=$match6["fst"];{const $match8=$match6["snd"];if($match8.$==="None"){return ({$:"MLeaf",["key"]:(
/*JD_USE:2760*/$x2760),["val"]:(
/*JD_USE:2758*/$x2758)});}else{{const $match9=$match8;const $x2761=$match9["value"];{const $let0=(
/*JD_USE:2760*/$x2760);{const $x2762=$let0;return (
/*JD_REF:$jd$Map_46_set_46_fin*/$jd$Map_46_set_46_fin((
/*JD_USE:2759*/$x2759),(
/*JD_USE:2762*/$x2762),(
/*JD_USE:2758*/$x2758),(
/*JD_USE:2762*/$x2762),(
/*JD_USE:2761*/$x2761)));}}}}}}}}}
function $jd$Map_46_set($a0,$a1,$a2){for(;;){const $x2768=null;const $x2769=null;const $x2770=$a0;const $x2771=$a1;const $x2772=$a2;return (
/*JD_REF:$jd$Map_46_set_46_go*/$jd$Map_46_set_46_go((
/*JD_USE:2772*/$x2772),(
/*JD_REF:$jd$Map_46_seek*/$jd$Map_46_seek((
/*JD_USE:2770*/$x2770),(
/*JD_USE:2771*/$x2771)))));}}
function $jd$Map_46_from_95_list_46_go($a0,$a1){for(;;){const $x3203=null;const $x3204=null;{const $match3=$a0;if($match3.$==="Nil"){const $x3205=$a1;return (
/*JD_USE:3205*/$x3205);}else{{const $match4=$match3;{const $match5=$match4["head"];const $x3206=$match5["fst"];const $x3207=$match5["snd"];const $x3208=$match4["tail"];const $x3209=$a1;{
/*JD_REF:$jd$Map_46_from_95_list_46_go*/const $next0=(
/*JD_USE:3208*/$x3208);const $next1=(
/*JD_REF:$jd$Map_46_set*/$jd$Map_46_set((
/*JD_USE:3209*/$x3209),(
/*JD_USE:3206*/$x3206),(
/*JD_USE:3207*/$x3207)));$a0=$next0;$a1=$next1;continue;}}}}}}}
function $jd$Map_46_from_95_list($a0){for(;;){const $x3214=null;const $x3215=null;const $x3216=$a0;return (
/*JD_REF:$jd$Map_46_from_95_list_46_go*/$jd$Map_46_from_95_list_46_go((
/*JD_USE:3216*/$x3216),({$:"MTip"})));}}
function $jd$b2u($a0){for(;;){{const $match1=$a0;if(!$match1){return 0;}else{{const $match2=$match1;return 1;}}}}}
function $jd$dbl($a0){for(;;){{const $match1=$a0;if($match1.$==="Nil"){return ({$:"Nil"});}else{{const $match2=$match1;const $x3417=$match2["head"];const $x3418=$match2["tail"];return ({$:"Con",["head"]:((Math.imul((
/*JD_USE:3417*/$x3417), 2) >>> 0)),["tail"]:(
/*JD_REF:$jd$dbl*/$jd$dbl((
/*JD_USE:3418*/$x3418)))});}}}}}
function $jd$keep_95_gt1_46_at($a0,$a1,$a2){for(;;){const $x3426=$a0;const $x3427=$a1;{const $match3=$a2;if($match3){return ({$:"Con",["head"]:(
/*JD_USE:3426*/$x3426),["tail"]:(
/*JD_USE:3427*/$x3427)});}else{{const $match4=$match3;return (
/*JD_USE:3427*/$x3427);}}}}}
function $jd$keep_95_gt1($a0){for(;;){{const $match1=$a0;if($match1.$==="Nil"){return ({$:"Nil"});}else{{const $match2=$match1;const $x3429=$match2["head"];const $x3430=$match2["tail"];{const $let0=(
/*JD_USE:3429*/$x3429);{const $x3431=$let0;return (
/*JD_REF:$jd$keep_95_gt1_46_at*/$jd$keep_95_gt1_46_at((
/*JD_USE:3431*/$x3431),(
/*JD_REF:$jd$keep_95_gt1*/$jd$keep_95_gt1((
/*JD_USE:3430*/$x3430))),(((
/*JD_USE:3431*/$x3431) > 1))));}}}}}}}
function $jd$suma($a0,$a1){for(;;){{const $match1=$a0;if($match1.$==="Nil"){const $x3436=$a1;return (
/*JD_USE:3436*/$x3436);}else{{const $match2=$match1;const $x3437=$match2["head"];const $x3438=$match2["tail"];const $x3439=$a1;{
/*JD_REF:$jd$suma*/const $next0=(
/*JD_USE:3438*/$x3438);const $next1=((((
/*JD_USE:3439*/$x3439) + (
/*JD_USE:3437*/$x3437)) >>> 0));$a0=$next0;$a1=$next1;continue;}}}}}}
function $jd$anyeq2_46_at($a0,$a1){for(;;){const $x3445=$a0;{const $match2=$a1;if($match2){return true;}else{{const $match3=$match2;return (
/*JD_USE:3445*/$x3445);}}}}}
function $jd$anyeq2($a0){for(;;){{const $match1=$a0;if($match1.$==="Nil"){return false;}else{{const $match2=$match1;const $x3447=$match2["head"];const $x3448=$match2["tail"];return (
/*JD_REF:$jd$anyeq2_46_at*/$jd$anyeq2_46_at((
/*JD_REF:$jd$anyeq2*/$jd$anyeq2((
/*JD_USE:3448*/$x3448))),(((
/*JD_USE:3447*/$x3447) === 2))));}}}}}
function $jd$allpos_46_at($a0,$a1){for(;;){const $x3454=$a0;{const $match2=$a1;if($match2){return (
/*JD_USE:3454*/$x3454);}else{{const $match3=$match2;return false;}}}}}
function $jd$allpos($a0){for(;;){{const $match1=$a0;if($match1.$==="Nil"){return true;}else{{const $match2=$match1;const $x3456=$match2["head"];const $x3457=$match2["tail"];return (
/*JD_REF:$jd$allpos_46_at*/$jd$allpos_46_at((
/*JD_REF:$jd$allpos*/$jd$allpos((
/*JD_USE:3457*/$x3457))),(((
/*JD_USE:3456*/$x3456) > 0))));}}}}}
function $jd$mmul10($a0){for(;;){{const $match1=$a0;if($match1.$==="MTip"){return ({$:"MTip"});}else{{const $match2=$match1;if($match2.$==="MLeaf"){const $x3460=$match2["key"];const $x3461=$match2["val"];return ({$:"MLeaf",["key"]:(
/*JD_USE:3460*/$x3460),["val"]:((Math.imul((
/*JD_USE:3461*/$x3461), 10) >>> 0))});}else{{const $match3=$match2;const $x3462=$match3["pos"];const $x3463=$match3["lo"];const $x3464=$match3["hi"];return ({$:"MNode",["pos"]:(
/*JD_USE:3462*/$x3462),["lo"]:(
/*JD_REF:$jd$mmul10*/$jd$mmul10((
/*JD_USE:3463*/$x3463))),["hi"]:(
/*JD_REF:$jd$mmul10*/$jd$mmul10((
/*JD_USE:3464*/$x3464)))});}}}}}}}
function $jd$mfold($a0,$a1){for(;;){{const $match1=$a0;if($match1.$==="MTip"){const $x3469=$a1;return (
/*JD_USE:3469*/$x3469);}else{{const $match2=$match1;if($match2.$==="MLeaf"){const $x3470=$match2["key"];const $x3471=$match2["val"];const $x3472=$a1;return (
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add((
/*JD_USE:3472*/$x3472),(
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add((
/*JD_USE:3471*/$x3471),(
/*JD_REF:$jd$U32_46_from_95_nat*/$jd$U32_46_from_95_nat(([...(
/*JD_USE:3470*/$x3470)].length)))))));}else{{const $match3=$match2;const $x3474=$match3["lo"];const $x3475=$match3["hi"];const $x3476=$a1;{
/*JD_REF:$jd$mfold*/const $next0=(
/*JD_USE:3475*/$x3475);const $next1=(
/*JD_REF:$jd$mfold*/$jd$mfold((
/*JD_USE:3474*/$x3474),(
/*JD_USE:3476*/$x3476)));$a0=$next0;$a1=$next1;continue;}}}}}}}}
function $jd$main_46_out(){for(;;){{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_REF:$jd$suma*/$jd$suma((
/*JD_REF:$jd$dbl*/$jd$dbl(({$:"Con",["head"]:1,["tail"]:({$:"Con",["head"]:2,["tail"]:({$:"Con",["head"]:3,["tail"]:({$:"Nil"})})})}))),0)),12))));{const $x3477=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_REF:$jd$suma*/$jd$suma((
/*JD_REF:$jd$keep_95_gt1*/$jd$keep_95_gt1(({$:"Con",["head"]:1,["tail"]:({$:"Con",["head"]:2,["tail"]:({$:"Con",["head"]:3,["tail"]:({$:"Nil"})})})}))),0)),5))));{const $x3478=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_REF:$jd$suma*/$jd$suma(({$:"Con",["head"]:1,["tail"]:({$:"Con",["head"]:2,["tail"]:({$:"Con",["head"]:3,["tail"]:({$:"Nil"})})})}),100)),106))));{const $x3479=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((
/*JD_REF:$jd$anyeq2*/$jd$anyeq2(({$:"Con",["head"]:1,["tail"]:({$:"Con",["head"]:2,["tail"]:({$:"Con",["head"]:3,["tail"]:({$:"Nil"})})})})))));{const $x3480=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((
/*JD_REF:$jd$allpos*/$jd$allpos(({$:"Con",["head"]:1,["tail"]:({$:"Con",["head"]:2,["tail"]:({$:"Con",["head"]:3,["tail"]:({$:"Nil"})})})})))));{const $x3481=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_REF:$jd$mfold*/$jd$mfold((
/*JD_REF:$jd$mmul10*/$jd$mmul10((
/*JD_REF:$jd$Map_46_from_95_list*/$jd$Map_46_from_95_list(({$:"Con",["head"]:({$:"Tuple",["fst"]:"a",["snd"]:1}),["tail"]:({$:"Con",["head"]:({$:"Tuple",["fst"]:"b",["snd"]:2}),["tail"]:({$:"Nil"})})}))))),0)),32))));{const $x3482=$let0;return (
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add((
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add((
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add(((Math.imul((
/*JD_USE:3477*/$x3477), 1000000) >>> 0)),((Math.imul((
/*JD_USE:3478*/$x3478), 100000) >>> 0)))),(
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add(((Math.imul((
/*JD_USE:3479*/$x3479), 10000) >>> 0)),((Math.imul((
/*JD_USE:3480*/$x3480), 1000) >>> 0)))))),(
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add((
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add(((Math.imul((
/*JD_USE:3481*/$x3481), 100) >>> 0)),((Math.imul((
/*JD_USE:3482*/$x3482), 10) >>> 0)))),1))));}}}}}}}}}}}}}}
function $jd$p37_46_list($a0,$a1){for(;;){{const $match1=$a0;if($match1===0){return ({$:"Nil"});}else{const $x3486=($match1-1);const $x3487=$a1;return ({$:"Con",["head"]:((16 === 0 ? (
/*JD_USE:3487*/$x3487) : (
/*JD_USE:3487*/$x3487) % 16)),["tail"]:(
/*JD_REF:$jd$p37_46_list*/$jd$p37_46_list((
/*JD_USE:3486*/$x3486),(
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add(((Math.imul((
/*JD_USE:3487*/$x3487), 1664525) >>> 0)),1013904223))))});}}}}
function $jd$bench($a0,$a1){for(;;){const $x3490=$a0;const $x3491=$a1;return (
/*JD_REF:$jd$suma*/$jd$suma((
/*JD_REF:$jd$dbl*/$jd$dbl((
/*JD_REF:$jd$keep_95_gt1*/$jd$keep_95_gt1((
/*JD_REF:$jd$p37_46_list*/$jd$p37_46_list(((
/*JD_USE:3490*/$x3490)),(
/*JD_USE:3491*/$x3491))))))),0));}}

export const backend={kind:"direct-js",representation:"upstream-native",prototype:true,foreign:"upstream-cps"};
export default {
"b2u":run_lib((a0,)=>{const r=(run_loop($jd$b2u((a0),)));(a0);return r;},1),
"dbl":run_lib((a0,)=>{const r=(run_loop($jd$dbl((a0),)));(a0);return r;},1),
"keep_gt1.at":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$keep_95_gt1_46_at((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"keep_gt1":run_lib((a0,)=>{const r=(run_loop($jd$keep_95_gt1((a0),)));(a0);return r;},1),
"suma":run_lib((a0,a1,)=>{const r=(run_loop($jd$suma((a0),(a1),)));(a0);(a1);return r;},2),
"anyeq2.at":run_lib((a0,a1,)=>{const r=(run_loop($jd$anyeq2_46_at((a0),(a1),)));(a0);(a1);return r;},2),
"anyeq2":run_lib((a0,)=>{const r=(run_loop($jd$anyeq2((a0),)));(a0);return r;},1),
"allpos.at":run_lib((a0,a1,)=>{const r=(run_loop($jd$allpos_46_at((a0),(a1),)));(a0);(a1);return r;},2),
"allpos":run_lib((a0,)=>{const r=(run_loop($jd$allpos((a0),)));(a0);return r;},1),
"mmul10":run_lib((a0,)=>{const r=(function $dm0(v){const top=[v];for(let at=top,key=0;;){switch(v.$){case "MTip":at[key]=v;return top[0];case "MLeaf":at[key]=v;return top[0];case "MNode":at=at[key]={...v,["pos"]:BigInt(v["pos"]),["lo"]:$dm0(v["lo"])};key="hi";v=v[key];continue;default:throw "bend: Map has no tag "+v?.$+" (its tags: MTip, MLeaf, MNode); a tag names its constructor as the loading file sees it, which a later version will make the same everywhere (#1105)";}}})(run_loop($jd$mmul10((function $dm0(v){const top=[v];for(let at=top,key=0;;){switch(v.$){case "MTip":at[key]=v;return top[0];case "MLeaf":at[key]=v;return top[0];case "MNode":at=at[key]={...v,["pos"]:nat_host(v["pos"]),["lo"]:$dm0(v["lo"])};key="hi";v=v[key];continue;default:throw "bend: Map has no tag "+v?.$+" (its tags: MTip, MLeaf, MNode); a tag names its constructor as the loading file sees it, which a later version will make the same everywhere (#1105)";}}})(a0),)));(function $dm0(v){const top=[v];for(let at=top,key=0;;){switch(v.$){case "MTip":at[key]=v;return top[0];case "MLeaf":at[key]=v;return top[0];case "MNode":at=at[key]={...v,["pos"]:BigInt(v["pos"]),["lo"]:$dm0(v["lo"])};key="hi";v=v[key];continue;default:throw "bend: Map has no tag "+v?.$+" (its tags: MTip, MLeaf, MNode); a tag names its constructor as the loading file sees it, which a later version will make the same everywhere (#1105)";}}})(a0);return r;},1),
"mfold":run_lib((a0,a1,)=>{const r=(run_loop($jd$mfold((function $dm0(v){const top=[v];for(let at=top,key=0;;){switch(v.$){case "MTip":at[key]=v;return top[0];case "MLeaf":at[key]=v;return top[0];case "MNode":at=at[key]={...v,["pos"]:nat_host(v["pos"]),["lo"]:$dm0(v["lo"])};key="hi";v=v[key];continue;default:throw "bend: Map has no tag "+v?.$+" (its tags: MTip, MLeaf, MNode); a tag names its constructor as the loading file sees it, which a later version will make the same everywhere (#1105)";}}})(a0),(a1),)));(function $dm0(v){const top=[v];for(let at=top,key=0;;){switch(v.$){case "MTip":at[key]=v;return top[0];case "MLeaf":at[key]=v;return top[0];case "MNode":at=at[key]={...v,["pos"]:BigInt(v["pos"]),["lo"]:$dm0(v["lo"])};key="hi";v=v[key];continue;default:throw "bend: Map has no tag "+v?.$+" (its tags: MTip, MLeaf, MNode); a tag names its constructor as the loading file sees it, which a later version will make the same everywhere (#1105)";}}})(a0);(a1);return r;},2),
"main.out":run_lib(()=>{const r=(run_loop($jd$main_46_out()));return r;},0),
"p37.list":run_lib((a0,a1,)=>{const r=(run_loop($jd$p37_46_list(nat_host(a0),(a1),)));BigInt(a0);(a1);return r;},2),
"bench":run_lib((a0,a1,)=>{const r=(run_loop($jd$bench((a0),(a1),)));(a0);(a1);return r;},2),
};
