  4051a0:	xor    %ebp,%ebp
  4051a2:	mov    %rdx,%r9
  4051a5:	pop    %rsi
  4051a6:	mov    %rsp,%rdx
  4051a9:	and    $0xfffffffffffffff0,%rsp
  4051ad:	push   %rax
  4051ae:	push   %rsp
  4051af:	mov    $0x426a80,%r8
  4051b6:	mov    $0x426a20,%rcx
  4051bd:	mov    $0x41c10a,%rdi
  4051c4:	callq  *0x27e16(%rip)        # 42cfe0 <__libc_start_main@GLIBC_2.2.5>
  4051ca:	hlt    
  4051cb:	nopl   0x0(%rax,%rax,1)
