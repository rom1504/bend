
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c80 <nx_string_reverse>:
  401c80:	endbr64 
  401c84:	push   %rbp
  401c85:	mov    %rsp,%rbp
  401c88:	push   %rbx
  401c89:	push   %r12
  401c8b:	mov    %rdx,%rax
  401c8e:	mov    %rax,%rdx
  401c91:	data16 nopw %cs:0x0(%rax,%rax,1)
  401c9c:	nopl   0x0(%rax)
  401ca0:	mov    %rsi,%rax
  401ca3:	shr    $0x28,%rax
  401ca7:	and    $0xffff,%rax
  401cad:	cmp    $0x2,%rax
  401cb1:	je     401cf8 <nx_string_reverse+0x78>
  401cb3:	cmp    $0x3,%rax
  401cb7:	jne    401cec <nx_string_reverse+0x6c>
  401cb9:	mov    %rdx,%r8
  401cbc:	mov    $0x0,%ecx
  401cc1:	mov    $0x3,%edx
  401cc6:	mov    %rdi,%rbx
  401cc9:	callq  402d30 <nx_rt_rebuild2>
  401cce:	mov    %rbx,%rdi
  401cd1:	mov    %rax,%r12
  401cd4:	mov    $0x0,%esi
  401cd9:	mov    %rdi,%rbx
  401cdc:	callq  402d10 <nx_rt_fast_field>
  401ce1:	mov    %r12,%rdx
  401ce4:	mov    %rbx,%rdi
  401ce7:	mov    %rax,%rsi
  401cea:	jmp    401ca0 <nx_string_reverse+0x20>
  401cec:	mov    $0x1,%esi
  401cf1:	callq  402560 <nx_rt_fail>
  401cf6:	jmp    401cfb <nx_string_reverse+0x7b>
  401cf8:	mov    %rdx,%rax
  401cfb:	pop    %r12
  401cfd:	pop    %rbx
  401cfe:	leaveq 
  401cff:	retq   

Disassembly of section .fini:
