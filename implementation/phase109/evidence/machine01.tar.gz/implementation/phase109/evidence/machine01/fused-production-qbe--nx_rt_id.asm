
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402b60 <nx_rt_id>:
  402b60:	endbr64 
  402b64:	push   %rbp
  402b65:	mov    %rsp,%rbp
  402b68:	sub    $0x18,%rsp
  402b6c:	push   %rbx
  402b6d:	mov    %rsi,%rbx
  402b70:	callq  402900 <nx_env>
  402b75:	mov    %rax,%rcx
  402b78:	mov    %rdx,%rax
  402b7b:	mov    %rbx,%rdx
  402b7e:	mov    %rcx,-0x10(%rbp)
  402b82:	mov    %rax,-0x8(%rbp)
  402b86:	mov    -0x10(%rbp),%rdi
  402b8a:	mov    -0x8(%rbp),%rsi
  402b8e:	callq  402950 <nx_id>
  402b93:	pop    %rbx
  402b94:	leaveq 
  402b95:	retq   

Disassembly of section .fini:
