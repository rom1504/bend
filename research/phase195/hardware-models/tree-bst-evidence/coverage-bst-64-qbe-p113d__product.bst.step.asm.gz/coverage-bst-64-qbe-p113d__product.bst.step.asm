0000000000407290 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_>:
  407290:	endbr64 
  407294:	push   rbp
  407295:	mov    rbp,rsp
  407298:	sub    rsp,0x820
  40729f:	push   rbx
  4072a0:	push   r12
  4072a2:	push   r13
  4072a4:	push   r14
  4072a6:	mov    r14,r8
  4072a9:	mov    rax,rcx
  4072ac:	mov    r12,rdi
  4072af:	mov    rcx,rax
  4072b2:	shr    rcx,0x28
  4072b6:	and    rcx,0xffff
  4072bd:	cmp    rcx,0xa4
  4072c4:	sete   dil
  4072c8:	movzx  edi,dil
  4072cc:	cmp    edi,0x0
  4072cf:	jne    407551 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x2c1>
  4072d5:	cmp    rcx,0xa5
  4072dc:	je     407307 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x77>
  4072de:	mov    rbx,rsi
  4072e1:	mov    esi,0x4
  4072e6:	mov    rdi,r12
  4072e9:	call   412a70 <p111_rt_fail>
  4072ee:	mov    QWORD PTR [rbx],0x0
  4072f5:	mov    QWORD PTR [rbx+0x8],0x0
  4072fd:	mov    eax,0x0
  407302:	jmp    40756a <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x2da>
  407307:	mov    rbx,rsi
  40730a:	mov    rsi,rax
  40730d:	mov    r13,rdx
  407310:	lea    rdx,[rbp-0x818]
  407317:	mov    rdi,r12
  40731a:	call   4182e0 <p125_rt_take3>
  40731f:	mov    rdx,r13
  407322:	mov    rsi,rbx
  407325:	mov    rbx,QWORD PTR [rbp-0x818]
  40732c:	mov    rdi,QWORD PTR [rbp-0x810]
  407333:	mov    r13,r12
  407336:	mov    r12,QWORD PTR [rbp-0x808]
  40733d:	mov    ecx,edx
  40733f:	mov    eax,edi
  407341:	cmp    rcx,rax
  407344:	setb   al
  407347:	movzx  eax,al
  40734a:	cmp    eax,0x0
  40734d:	jne    40744f <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x1bf>
  407353:	mov    QWORD PTR [rbp-0x18],rdi
  407357:	mov    QWORD PTR [rbp-0x10],rbx
  40735b:	mov    QWORD PTR [rbp-0x8],0x0
  407363:	mov    r10,QWORD PTR [r13+0x8]
  407367:	mov    rax,QWORD PTR [r10+0x10]
  40736b:	cmp    rax,0x0
  40736f:	jne    407390 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x100>
  407371:	lea    rdx,[rbp-0x18]
  407375:	mov    rbx,rsi
  407378:	mov    esi,0xa6
  40737d:	mov    rdi,r13
  407380:	call   418210 <p125_rt_ctor3>
  407385:	mov    r8,r14
  407388:	mov    rsi,rbx
  40738b:	mov    rdi,rax
  40738e:	jmp    4073da <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x14a>
  407390:	mov    r8,r14
  407393:	mov    rcx,QWORD PTR [r13+0x0]
  407397:	mov    rdx,rax
  40739a:	shl    rdx,0x3
  40739e:	mov    r11,QWORD PTR [rcx+rdx*1]
  4073a2:	mov    r9,QWORD PTR [r10+0x110]
  4073a9:	mov    QWORD PTR [r10+0x10],r11
  4073ad:	sub    r9,0x4
  4073b1:	mov    QWORD PTR [r10+0x110],r9
  4073b8:	mov    QWORD PTR [rcx+rdx*1],rdi
  4073bc:	mov    QWORD PTR [rcx+rdx*1+0x8],rbx
  4073c1:	mov    QWORD PTR [rcx+rdx*1+0x10],0x0
  4073ca:	movabs rcx,0x200a60000000000
  4073d4:	mov    rdi,rax
  4073d7:	or     rdi,rcx
  4073da:	mov    QWORD PTR [rbp-0x18],rdi
  4073de:	mov    QWORD PTR [rbp-0x10],r8
  4073e2:	mov    r9,QWORD PTR [r13+0x8]
  4073e6:	mov    rax,QWORD PTR [r9+0x8]
  4073ea:	cmp    rax,0x0
  4073ee:	jne    407409 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x179>
  4073f0:	lea    rdx,[rbp-0x18]
  4073f4:	mov    rbx,rsi
  4073f7:	mov    esi,0x12
  4073fc:	mov    rdi,r13
  4073ff:	call   417f90 <p125_rt_ctor2>
  407404:	mov    rsi,rbx
  407407:	jmp    407447 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x1b7>
  407409:	mov    rcx,QWORD PTR [r13+0x0]
  40740d:	mov    rdx,rax
  407410:	shl    rdx,0x3
  407414:	mov    r10,QWORD PTR [rcx+rdx*1]
  407418:	mov    r14,r8
  40741b:	mov    r8,QWORD PTR [r9+0x108]
  407422:	mov    QWORD PTR [r9+0x8],r10
  407426:	sub    r8,0x2
  40742a:	mov    QWORD PTR [r9+0x108],r8
  407431:	mov    QWORD PTR [rcx+rdx*1],rdi
  407435:	mov    QWORD PTR [rcx+rdx*1+0x8],r14
  40743a:	movabs rcx,0x200120000000000
  407444:	or     rax,rcx
  407447:	mov    rbx,r12
  40744a:	jmp    407543 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x2b3>
  40744f:	mov    QWORD PTR [rbp-0x18],rdi
  407453:	mov    QWORD PTR [rbp-0x10],r12
  407457:	mov    QWORD PTR [rbp-0x8],0x1
  40745f:	mov    r10,QWORD PTR [r13+0x8]
  407463:	mov    rax,QWORD PTR [r10+0x10]
  407467:	cmp    rax,0x0
  40746b:	jne    40748c <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x1fc>
  40746d:	lea    rdx,[rbp-0x18]
  407471:	mov    r12,rsi
  407474:	mov    esi,0xa6
  407479:	mov    rdi,r13
  40747c:	call   418210 <p125_rt_ctor3>
  407481:	mov    r8,r14
  407484:	mov    rsi,r12
  407487:	mov    rdi,rax
  40748a:	jmp    4074d6 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x246>
  40748c:	mov    r8,r14
  40748f:	mov    rcx,QWORD PTR [r13+0x0]
  407493:	mov    rdx,rax
  407496:	shl    rdx,0x3
  40749a:	mov    r11,QWORD PTR [rcx+rdx*1]
  40749e:	mov    r9,QWORD PTR [r10+0x110]
  4074a5:	mov    QWORD PTR [r10+0x10],r11
  4074a9:	sub    r9,0x4
  4074ad:	mov    QWORD PTR [r10+0x110],r9
  4074b4:	mov    QWORD PTR [rcx+rdx*1],rdi
  4074b8:	mov    QWORD PTR [rcx+rdx*1+0x8],r12
  4074bd:	mov    QWORD PTR [rcx+rdx*1+0x10],0x1
  4074c6:	movabs rcx,0x200a60000000000
  4074d0:	mov    rdi,rax
  4074d3:	or     rdi,rcx
  4074d6:	mov    QWORD PTR [rbp-0x18],rdi
  4074da:	mov    QWORD PTR [rbp-0x10],r8
  4074de:	mov    r10,QWORD PTR [r13+0x8]
  4074e2:	mov    rax,QWORD PTR [r10+0x8]
  4074e6:	cmp    rax,0x0
  4074ea:	jne    407505 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x275>
  4074ec:	lea    rdx,[rbp-0x18]
  4074f0:	mov    r12,rsi
  4074f3:	mov    esi,0x12
  4074f8:	mov    rdi,r13
  4074fb:	call   417f90 <p125_rt_ctor2>
  407500:	mov    rsi,r12
  407503:	jmp    407543 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x2b3>
  407505:	mov    r12,r13
  407508:	mov    rcx,QWORD PTR [r12]
  40750c:	mov    rdx,rax
  40750f:	shl    rdx,0x3
  407513:	mov    r11,QWORD PTR [rcx+rdx*1]
  407517:	mov    r9,QWORD PTR [r10+0x108]
  40751e:	mov    QWORD PTR [r10+0x8],r11
  407522:	sub    r9,0x2
  407526:	mov    QWORD PTR [r10+0x108],r9
  40752d:	mov    QWORD PTR [rcx+rdx*1],rdi
  407531:	mov    QWORD PTR [rcx+rdx*1+0x8],r8
  407536:	movabs rcx,0x200120000000000
  407540:	or     rax,rcx
  407543:	mov    QWORD PTR [rsi],rbx
  407546:	mov    QWORD PTR [rsi+0x8],rax
  40754a:	mov    eax,0x0
  40754f:	jmp    40756a <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x2da>
  407551:	mov    r8,r14
  407554:	movabs rax,0x100a40000000000
  40755e:	mov    QWORD PTR [rsi],rax
  407561:	mov    QWORD PTR [rsi+0x8],r8
  407565:	mov    eax,0x0
  40756a:	pop    r14
  40756c:	pop    r13
  40756e:	pop    r12
  407570:	pop    rbx
  407571:	leave  
  407572:	ret    
  407573:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  40757e:	xchg   ax,ax

