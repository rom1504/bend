
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403310 <nx_rt_rebuild2>:
  403310:	push   %r15
  403312:	push   %r14
  403314:	push   %r13
  403316:	mov    %ecx,%r13d
  403319:	push   %r12
  40331b:	mov    %rdi,%r12
  40331e:	push   %rbp
  40331f:	movabs $0xffffffffff,%rbp
  403329:	push   %rbx
  40332a:	and    %rsi,%rbp
  40332d:	mov    %edx,%ebx
  40332f:	lea    0x0(,%rbp,8),%rdx
  403337:	sub    $0x28,%rsp
  40333b:	mov    (%rdi),%r14
  40333e:	mov    0x8(%rdi),%r15
  403342:	lea    (%r14,%rdx,1),%rax
  403346:	test   %rsi,%rsi
  403349:	js     403430 <nx_rt_rebuild2+0x120>
  40334f:	mov    (%rax),%rax
  403352:	mov    %rax,0x10(%rsp)
  403357:	mov    0x8(%r14,%rdx,1),%rax
  40335c:	mov    %rax,0x18(%rsp)
  403361:	cmp    $0x310817f,%rbp
  403368:	jbe    403408 <nx_rt_rebuild2+0xf8>
  40336e:	lea    (%r14,%rbp,8),%r9
  403372:	mov    $0x1,%eax
  403377:	mov    0x10(%rsp,%r13,8),%rdx
  40337c:	movq   $0xffffffffffffffff,0x18(%r12)
  403385:	movl   $0x1,0x20(%r12)
  40338e:	sub    %r13d,%eax
  403391:	mov    0x10(%rsp,%rax,8),%rax
  403396:	mov    %rax,0x10(%r12)
  40339b:	mov    %rdx,%rax
  40339e:	shr    $0x38,%rax
  4033a2:	and    $0x7f,%eax
  4033a5:	cmp    $0x2,%rax
  4033a9:	je     4033e8 <nx_rt_rebuild2+0xd8>
  4033ab:	mov    %r8,%rax
  4033ae:	mov    %rdx,(%r9)
  4033b1:	lea    0x8(%r14,%rbp,8),%r12
  4033b6:	shr    $0x38,%rax
  4033ba:	and    $0x7f,%eax
  4033bd:	cmp    $0x2,%rax
  4033c1:	je     4033f8 <nx_rt_rebuild2+0xe8>
  4033c3:	mov    %rbx,%rax
  4033c6:	mov    %r8,(%r12)
  4033ca:	add    $0x28,%rsp
  4033ce:	shl    $0x28,%rax
  4033d2:	pop    %rbx
  4033d3:	or     %rbp,%rax
  4033d6:	pop    %rbp
  4033d7:	pop    %r12
  4033d9:	bts    $0x39,%rax
  4033de:	pop    %r13
  4033e0:	pop    %r14
  4033e2:	pop    %r15
  4033e4:	retq   
  4033e5:	nopl   (%rax)
  4033e8:	test   %rdx,%rdx
  4033eb:	js     4033ab <nx_rt_rebuild2+0x9b>
  4033ed:	jmpq   401640 <nx_rt_rebuild2.cold>
  4033f2:	nopw   0x0(%rax,%rax,1)
  4033f8:	test   %r8,%r8
  4033fb:	js     4033c3 <nx_rt_rebuild2+0xb3>
  4033fd:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  403402:	nopw   0x0(%rax,%rax,1)
  403408:	mov    0x8(%r15),%rbp
  40340c:	test   %rbp,%rbp
  40340f:	je     401685 <nx_rt_rebuild2.cold+0x45>
  403415:	lea    (%r14,%rbp,8),%r9
  403419:	mov    (%r9),%rax
  40341c:	subq   $0x2,0x108(%r15)
  403424:	mov    %rax,0x8(%r15)
  403428:	jmpq   403372 <nx_rt_rebuild2+0x62>
  40342d:	nopl   (%rax)
  403430:	mov    0x4(%rax),%edx
  403433:	mov    (%rax),%ecx
  403435:	shl    $0x20,%rdx
  403439:	or     %rcx,%rdx
  40343c:	mov    %rdx,%rcx
  40343f:	and    $0xffffff,%edx
  403445:	shr    $0x18,%rcx
  403449:	lea    0x0(,%rcx,8),%rdi
  403451:	lea    (%r14,%rdi,1),%r9
  403455:	lea    0x8(%r14,%rdi,1),%rdi
  40345a:	cmp    $0x1,%rdx
  40345e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403464:	mov    (%rax),%edx
  403466:	mov    (%r9),%rdx
  403469:	mov    %rdx,0x10(%rsp)
  40346e:	mov    (%rdi),%rdx
  403471:	mov    %rdx,0x18(%rsp)
  403476:	mov    (%r15),%rdx
  403479:	mov    %rdx,(%rax)
  40347c:	mov    0x100(%r15),%rax
  403483:	mov    0x3ed4f(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403489:	mov    %rbp,(%r15)
  40348c:	add    $0x1,%rax
  403490:	mov    %rax,0x100(%r15)
  403497:	cmp    %rdx,%rax
  40349a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  4034a0:	mov    %rcx,%rbp
  4034a3:	jmpq   403361 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
