000000000040ec70 <p111_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>:
  40ec70:	push   rbp
  40ec71:	mov    rbp,rsp
  40ec74:	sub    rsp,0x930
  40ec7b:	mov    QWORD PTR [rbp-0x10],r12
  40ec7f:	mov    rax,rdi
  40ec82:	mov    r12,rax
  40ec85:	mov    rdi,QWORD PTR [r12+0x28]
  40ec8a:	mov    rsi,QWORD PTR [r12+0x30]
  40ec8f:	mov    r10,r12
  40ec92:	mov    QWORD PTR [rsp+0x30],r10
  40ec97:	mov    r10,rdi
  40ec9a:	mov    QWORD PTR [rsp+0x38],r10
  40ec9f:	mov    r10,rsi
  40eca2:	mov    QWORD PTR [rsp+0x40],r10
  40eca7:	movabs r10,0x0
  40ecb1:	mov    QWORD PTR [rsp+0x48],r10
  40ecb6:	movabs r10,0x0
  40ecc0:	mov    QWORD PTR [rsp+0x50],r10
  40ecc5:	movabs r10,0x0
  40eccf:	mov    QWORD PTR [rsp+0x58],r10
  40ecd4:	mov    rdi,QWORD PTR [rsp+0x30]
  40ecd9:	mov    rsi,QWORD PTR [rsp+0x38]
  40ecde:	mov    rdx,QWORD PTR [rsp+0x40]
  40ece3:	mov    rcx,QWORD PTR [rsp+0x48]
  40ece8:	mov    r8,QWORD PTR [rsp+0x50]
  40eced:	mov    r9,QWORD PTR [rsp+0x58]
  40ecf2:	xor    eax,eax
  40ecf4:	call   40e968 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>
  40ecf9:	mov    rdi,rax
  40ecfc:	lea    r10,[rbp-0x880]
  40ed03:	mov    r11,rdi
  40ed06:	mov    QWORD PTR [r10],r11
  40ed09:	mov    rdi,r12
  40ed0c:	lea    rsi,[rbp-0x880]
  40ed13:	movabs rdx,0x1
  40ed1d:	mov    edx,edx
  40ed1f:	xor    eax,eax
  40ed21:	call   418440 <p111_rt_return>
  40ed26:	mov    rdi,rax
  40ed29:	mov    rax,rdi
  40ed2c:	mov    r12,QWORD PTR [rbp-0x10]
  40ed30:	mov    rsp,rbp
  40ed33:	pop    rbp
  40ed34:	ret    

