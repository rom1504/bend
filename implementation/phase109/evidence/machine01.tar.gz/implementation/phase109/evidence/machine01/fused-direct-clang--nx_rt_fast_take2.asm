
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402840 <nx_rt_fast_take2>:
  402840:	movabs $0xffffffffff,%rax
  40284a:	push   %r12
  40284c:	and    %rsi,%rax
  40284f:	push   %rbp
  402850:	push   %rbx
  402851:	mov    %rdi,%rbx
  402854:	mov    (%rdi),%rdi
  402857:	lea    0x0(,%rax,8),%rcx
  40285f:	mov    0x8(%rbx),%rbp
  402863:	lea    (%rdi,%rcx,1),%rdx
  402867:	test   %rsi,%rsi
  40286a:	js     4028d8 <nx_rt_fast_take2+0x98>
  40286c:	mov    (%rdx),%rdx
  40286f:	mov    %rdx,0x10(%rbx)
  402873:	mov    0x8(%rdi,%rcx,1),%rdx
  402878:	mov    %rdx,0x18(%rbx)
  40287c:	cmp    $0x310817f,%rax
  402882:	ja     402898 <nx_rt_fast_take2+0x58>
  402884:	movl   $0x3,0x20(%rbx)
  40288b:	xor    %eax,%eax
  40288d:	pop    %rbx
  40288e:	pop    %rbp
  40288f:	pop    %r12
  402891:	retq   
  402892:	nopw   0x0(%rax,%rax,1)
  402898:	mov    0x8(%rbp),%rdx
  40289c:	mov    %rdx,(%rdi,%rax,8)
  4028a0:	mov    0x4932(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4028a6:	mov    %rax,0x8(%rbp)
  4028aa:	mov    0x108(%rbp),%rax
  4028b1:	add    $0x2,%rax
  4028b5:	mov    %rax,0x108(%rbp)
  4028bc:	cmp    %rdx,%rax
  4028bf:	jae    40160f <nx_rt_fast_take2.cold>
  4028c5:	movl   $0x3,0x20(%rbx)
  4028cc:	xor    %eax,%eax
  4028ce:	pop    %rbx
  4028cf:	pop    %rbp
  4028d0:	pop    %r12
  4028d2:	retq   
  4028d3:	nopl   0x0(%rax,%rax,1)
  4028d8:	mov    0x4(%rdx),%ecx
  4028db:	mov    (%rdx),%r8d
  4028de:	shl    $0x20,%rcx
  4028e2:	or     %r8,%rcx
  4028e5:	mov    %rcx,%r12
  4028e8:	and    $0xffffff,%ecx
  4028ee:	shr    $0x18,%r12
  4028f2:	lea    0x0(,%r12,8),%r8
  4028fa:	lea    (%rdi,%r8,1),%r9
  4028fe:	lea    0x8(%rdi,%r8,1),%r8
  402903:	cmp    $0x1,%rcx
  402907:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  40290d:	mov    (%rdx),%ecx
  40290f:	mov    (%r9),%rcx
  402912:	mov    %rcx,0x10(%rbx)
  402916:	mov    (%r8),%rcx
  402919:	mov    %rcx,0x18(%rbx)
  40291d:	mov    0x0(%rbp),%rcx
  402921:	mov    %rcx,(%rdx)
  402924:	mov    0x48ae(%rip),%edx        # 4071d8 <KEEP_WORDS>
  40292a:	mov    %rax,0x0(%rbp)
  40292e:	mov    0x100(%rbp),%rax
  402935:	add    $0x1,%rax
  402939:	mov    %rax,0x100(%rbp)
  402940:	cmp    %rdx,%rax
  402943:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402949:	mov    %r12,%rax
  40294c:	jmpq   40287c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
