# Supervised native compiler → QBE stdin

`build.py` builds an ordinary Bend source without writing a complete textual QBE
file. It runs an existing checked native compiler, relays its stdout into pinned
QBE 1.3, retains assembly, and uses the unchanged Phase123 aligned assembler and
linker commands. It changes no Bend compiler, runtime, verification rule or
installed selection.

The relay has one 65,536-byte buffer. It hashes the original bytes and finishes
sending each buffer before reading another, so downstream backpressure bounds
transport memory. QBE processes stdin using `-`; the compiler still performs its
normal admission and final verification. Source and runtime identities, carrier
receipt, executable tools, commands, stderr, child statuses and product hashes
are recorded. A whole-pipeline deadline kills/reaps child process groups on
failure. Run it inside the existing resource guard: this transport bound is not
a memory bound on the compiler, QBE, assembly or executable.

Example, from the repository root, with a fresh output directory:

```sh
python3 selfhost/tools/performance/phase134/pipe/build.py \
  --image selfhost/build/phase111/p134-no-copy-n1/program \
  --source selfhost/build/phase88/broad-fixtures03/lexer.bend \
  --carrier-receipt selfhost/build/phase130/base-carrier01/receipt.json \
  --runtime selfhost/build/phase128/runtime-borrow01/runtime.o \
  --out selfhost/build/phase134/my-pipe-build --seconds 60
```

An ordinary new source does not need a preexisting QBE file. Its report says
`comparedToReference: false`; successful compiler verification is not a claim of
byte equality with another compiler. Add `--expected-qbe PATH` for a strict
independent digest comparison, `--expected-stdout PATH` for exact ordinary output,
and `--retain-ir` only when qualification explicitly requires a textual IR copy.
Assembly remains materialized because the established aligned build consumes it.

## Evidence and limits

The three strict builds passed using the retained no-copy N1. Each stream matched
the qualified Phase131 reference exactly; assembly and the complete object were
byte-identical to a fresh unchanged Phase123 build. All loaded ELF sections and
ELF/program headers were identical except the GNU build-ID payload; native
outputs matched exactly. No textual IR artifact was created.

| Request | Stream bytes | Largest relay read |
|---|---:|---:|
| lexer | 577,297 | 41,481 |
| coverage-closures-256 | 99,537 | 9,137 |
| coverage-map-churn-128 | 1,028,294 | 65,536 |

The whole guarded validation took 9.10 seconds with 79.9 MB sampled process-tree
RSS. These are diagnostic validation costs, not a clean speed comparison against
file-based emission. A fresh ordinary newline fixture also passed without an IR
reference. Supplying another program's digest rejected an otherwise successful
compiler/QBE stream before assembly. Timeout, killed-producer and broken-consumer
fault injection were not performed; supervision of those paths is source-reviewed.
A full compiler build through this transport remains unmeasured.

The first harness demanded byte-identical complete ELF files and failed. The
assembler output and objects were already identical: GNU ld retains the absolute
object path in nonloaded `.strtab`, which also changes the build-ID digest. The
revised harness preserves the exact object requirement, independently compares
all allocated sections except that digest payload, compares ELF/program headers,
and executes both binaries. It does not mask machine instructions, data,
relocations, addresses or section sizes. This negative result is retained.

Receipts:

- `selfhost/build/phase134/pipe-test02/report.json`: three strict cases, ordinary
  nonreference case, actual wrong-digest refusal.
- `selfhost/build/phase134/pipe-test-guard02/process.json`: resource envelope.
- `selfhost/build/phase134/pipe-test01/report.json`: original overstrict ELF failure.
- `pipe-evidence.tar.xz` and `evidence.json`: small immutable receipts and consumed
  method snapshots; regenerable assembly, objects, executables and IR are excluded.

Reproduce the strict campaign using `test-v02.py --out FRESH_PHASE134_DIRECTORY`
inside the normal guard. Its Phase111 reference output names are deliberately
fresh-only; use new names for another run. `test.py` is the preserved failed
harness, not the current entry point.
