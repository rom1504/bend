0000000000407080 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_>:
  407080:	endbr64 
  407084:	push   rbp
  407085:	mov    rbp,rsp
  407088:	sub    rsp,0x848
  40708f:	push   rbx
  407090:	push   r12
  407092:	push   r13
  407094:	mov    rbx,rsi
  407097:	mov    rsi,rdx
  40709a:	mov    r12,rdi
  40709d:	mov    rax,rsi
  4070a0:	shr    rax,0x28
  4070a4:	and    rax,0xffff
  4070aa:	cmp    rax,0x8
  4070ae:	je     4070c7 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x47>
  4070b0:	mov    esi,0x4
  4070b5:	mov    rdi,r12
  4070b8:	call   412a70 <p111_rt_fail>
  4070bd:	mov    eax,0x0
  4070c2:	jmp    407281 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x201>
  4070c7:	lea    rdx,[rbp-0x840]
  4070ce:	mov    rdi,r12
  4070d1:	call   418080 <p125_rt_take2>
  4070d6:	mov    rsi,rbx
  4070d9:	mov    r13,rsi
  4070dc:	mov    rsi,QWORD PTR [rbp-0x840]
  4070e3:	mov    rbx,QWORD PTR [rbp-0x838]
  4070ea:	mov    rax,rsi
  4070ed:	shr    rax,0x28
  4070f1:	and    rax,0xffff
  4070f7:	cmp    rax,0xa4
  4070fd:	sete   cl
  407100:	movzx  ecx,cl
  407103:	cmp    ecx,0x0
  407106:	jne    4071ff <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x17f>
  40710c:	cmp    rax,0xa5
  407112:	je     40712b <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0xab>
  407114:	mov    esi,0x4
  407119:	mov    rdi,r12
  40711c:	call   412a70 <p111_rt_fail>
  407121:	mov    eax,0x0
  407126:	jmp    407281 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x201>
  40712b:	cs cs lea rdx,cs:[rbp-0x840]
  407135:	mov    rdi,r12
  407138:	call   4182e0 <p125_rt_take3>
  40713d:	mov    rsi,r13
  407140:	mov    rdx,QWORD PTR [rbp-0x840]
  407147:	mov    rcx,QWORD PTR [rbp-0x838]
  40714e:	mov    r8,QWORD PTR [rbp-0x830]
  407155:	mov    esi,esi
  407157:	mov    eax,ecx
  407159:	cmp    rsi,rax
  40715c:	setb   al
  40715f:	movzx  eax,al
  407162:	mov    eax,eax
  407164:	sub    rsp,0x10
  407168:	mov    rsi,rsp
  40716b:	mov    QWORD PTR [rsi],rax
  40716e:	mov    r9,rbx
  407171:	lea    rsi,[rbp-0x40]
  407175:	mov    rdi,r12
  407178:	call   406dc0 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_112_105_99_107_>
  40717d:	sub    rsp,0xfffffffffffffff0
  407181:	mov    rdi,QWORD PTR [rbp-0x40]
  407185:	mov    rcx,QWORD PTR [rbp-0x38]
  407189:	mov    QWORD PTR [rbp-0x840],rdi
  407190:	mov    QWORD PTR [rbp-0x838],rcx
  407197:	mov    r9,QWORD PTR [r12+0x8]
  40719c:	mov    rax,QWORD PTR [r9+0x8]
  4071a0:	cmp    rax,0x0
  4071a4:	jne    4071bf <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x13f>
  4071a6:	lea    rdx,[rbp-0x840]
  4071ad:	mov    esi,0x8
  4071b2:	mov    rdi,r12
  4071b5:	call   417f90 <p125_rt_ctor2>
  4071ba:	jmp    407281 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x201>
  4071bf:	mov    rdx,QWORD PTR [r12]
  4071c3:	mov    rsi,rax
  4071c6:	shl    rsi,0x3
  4071ca:	mov    r10,QWORD PTR [rdx+rsi*1]
  4071ce:	mov    r8,QWORD PTR [r9+0x108]
  4071d5:	mov    QWORD PTR [r9+0x8],r10
  4071d9:	sub    r8,0x2
  4071dd:	mov    QWORD PTR [r9+0x108],r8
  4071e4:	mov    QWORD PTR [rdx+rsi*1],rdi
  4071e8:	mov    QWORD PTR [rdx+rsi*1+0x8],rcx
  4071ed:	movabs rcx,0x200080000000000
  4071f7:	or     rax,rcx
  4071fa:	jmp    407281 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x201>
  4071ff:	movabs rax,0x100a40000000000
  407209:	mov    QWORD PTR [rbp-0x840],rax
  407210:	mov    QWORD PTR [rbp-0x838],rbx
  407217:	mov    rdi,QWORD PTR [r12+0x8]
  40721c:	mov    rax,QWORD PTR [rdi+0x8]
  407220:	cmp    rax,0x0
  407224:	jne    40723c <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x1bc>
  407226:	lea    rdx,[rbp-0x840]
  40722d:	mov    esi,0x8
  407232:	mov    rdi,r12
  407235:	call   417f90 <p125_rt_ctor2>
  40723a:	jmp    407281 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x201>
  40723c:	mov    rcx,QWORD PTR [r12]
  407240:	mov    rdx,rax
  407243:	shl    rdx,0x3
  407247:	mov    r8,QWORD PTR [rcx+rdx*1]
  40724b:	mov    rsi,QWORD PTR [rdi+0x108]
  407252:	mov    QWORD PTR [rdi+0x8],r8
  407256:	sub    rsi,0x2
  40725a:	mov    QWORD PTR [rdi+0x108],rsi
  407261:	movabs rsi,0x100a40000000000
  40726b:	mov    QWORD PTR [rcx+rdx*1],rsi
  40726f:	mov    QWORD PTR [rcx+rdx*1+0x8],rbx
  407274:	movabs rcx,0x200080000000000
  40727e:	or     rax,rcx
  407281:	pop    r13
  407283:	pop    r12
  407285:	pop    rbx
  407286:	leave  
  407287:	ret    
  407288:	nop    DWORD PTR [rax+rax*1+0x0]

