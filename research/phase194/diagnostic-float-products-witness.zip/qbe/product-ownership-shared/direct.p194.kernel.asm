  406fd0:	endbr64 
  406fd4:	push   %rbp
  406fd5:	mov    %rsp,%rbp
  406fd8:	sub    $0x8,%rsp
  406fdc:	push   %rbx
  406fdd:	push   %r12
  406fdf:	push   %r13
  406fe1:	mov    %rcx,%rax
  406fe4:	mov    %rax,%rcx
  406fe7:	nopw   0x0(%rax,%rax,1)
  406ff0:	cmp    $0x0,%rsi
  406ff4:	je     40701e <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x4e>
  406ff6:	sub    $0x1,%rsi
  406ffa:	mov    %edx,%eax
  406ffc:	add    $0x1,%eax
  406fff:	mov    %eax,%r13d
  407002:	mov    %rsi,%r12
  407005:	mov    %rcx,%rsi
  407008:	mov    %rdi,%rbx
  40700b:	callq  406fb0 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_>
  407010:	mov    %r13,%rdx
  407013:	mov    %r12,%rsi
  407016:	mov    %rbx,%rdi
  407019:	mov    %rax,%rcx
  40701c:	jmp    406ff0 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x20>
  40701e:	mov    %rcx,%rax
  407021:	pop    %r13
  407023:	pop    %r12
  407025:	pop    %rbx
  407026:	leaveq 
  407027:	retq   
  407028:	nopl   0x0(%rax,%rax,1)
