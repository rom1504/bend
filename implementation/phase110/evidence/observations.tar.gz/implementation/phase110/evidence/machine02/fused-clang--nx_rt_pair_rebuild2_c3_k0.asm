
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403c90 <nx_rt_pair_rebuild2_c3_k0>:
  403c90:	push   %r15
  403c92:	push   %r14
  403c94:	push   %r13
  403c96:	push   %r12
  403c98:	mov    %rdx,%r12
  403c9b:	push   %rbp
  403c9c:	push   %rbx
  403c9d:	movabs $0xffffffffff,%rbx
  403ca7:	and    %rsi,%rbx
  403caa:	lea    0x0(,%rbx,8),%rdx
  403cb2:	sub    $0x18,%rsp
  403cb6:	mov    (%rdi),%rbp
  403cb9:	mov    0x8(%rdi),%r15
  403cbd:	lea    0x0(%rbp,%rdx,1),%rax
  403cc2:	test   %rsi,%rsi
  403cc5:	js     403d80 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  403ccb:	mov    (%rax),%r14
  403cce:	mov    0x8(%rbp,%rdx,1),%r13
  403cd3:	cmp    $0x310817f,%rbx
  403cda:	jbe    403d50 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  403cdc:	lea    0x0(%rbp,%rbx,8),%r8
  403ce1:	mov    %r14,%rax
  403ce4:	shr    $0x38,%rax
  403ce8:	and    $0x7f,%eax
  403ceb:	cmp    $0x2,%rax
  403cef:	je     403d30 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  403cf1:	mov    %r12,%rax
  403cf4:	mov    %r14,(%r8)
  403cf7:	lea    0x8(%rbp,%rbx,8),%r14
  403cfc:	shr    $0x38,%rax
  403d00:	and    $0x7f,%eax
  403d03:	cmp    $0x2,%rax
  403d07:	je     403d40 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  403d09:	movabs $0x200030000000000,%rax
  403d13:	mov    %r12,(%r14)
  403d16:	mov    %r13,%rdx
  403d19:	add    $0x18,%rsp
  403d1d:	or     %rbx,%rax
  403d20:	pop    %rbx
  403d21:	pop    %rbp
  403d22:	pop    %r12
  403d24:	pop    %r13
  403d26:	pop    %r14
  403d28:	pop    %r15
  403d2a:	retq   
  403d2b:	nopl   0x0(%rax,%rax,1)
  403d30:	test   %r14,%r14
  403d33:	js     403cf1 <nx_rt_pair_rebuild2_c3_k0+0x61>
  403d35:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  403d3a:	nopw   0x0(%rax,%rax,1)
  403d40:	test   %r12,%r12
  403d43:	js     403d09 <nx_rt_pair_rebuild2_c3_k0+0x79>
  403d45:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  403d4a:	nopw   0x0(%rax,%rax,1)
  403d50:	mov    0x8(%r15),%rbx
  403d54:	test   %rbx,%rbx
  403d57:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  403d5d:	lea    0x0(%rbp,%rbx,8),%r8
  403d62:	mov    (%r8),%rax
  403d65:	subq   $0x2,0x108(%r15)
  403d6d:	mov    %rax,0x8(%r15)
  403d71:	jmpq   403ce1 <nx_rt_pair_rebuild2_c3_k0+0x51>
  403d76:	nopw   %cs:0x0(%rax,%rax,1)
  403d80:	mov    0x4(%rax),%edx
  403d83:	mov    (%rax),%ecx
  403d85:	shl    $0x20,%rdx
  403d89:	or     %rcx,%rdx
  403d8c:	mov    %rdx,%rcx
  403d8f:	and    $0xffffff,%edx
  403d95:	shr    $0x18,%rcx
  403d99:	lea    0x8(,%rcx,8),%rdi
  403da1:	lea    0x0(%rbp,%rdi,1),%r8
  403da6:	lea    -0x8(%rbp,%rdi,1),%rdi
  403dab:	cmp    $0x1,%rdx
  403daf:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  403db5:	mov    (%rax),%edx
  403db7:	mov    (%r15),%rdx
  403dba:	mov    (%rdi),%r14
  403dbd:	mov    (%r8),%r13
  403dc0:	mov    %rdx,(%rax)
  403dc3:	mov    0x100(%r15),%rax
  403dca:	mov    0x3d408(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403dd0:	mov    %rbx,(%r15)
  403dd3:	add    $0x1,%rax
  403dd7:	mov    %rax,0x100(%r15)
  403dde:	cmp    %rdx,%rax
  403de1:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  403de7:	mov    %rcx,%rbx
  403dea:	jmpq   403cd3 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
