
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401410 <nx_construct2.cold>:
  401410:	mov    $0x1,%ecx
  401415:	mov    %r9,0x18(%rsp)
  40141a:	mov    %r8,0x10(%rsp)
  40141f:	mov    %rdi,0x8(%rsp)
  401424:	mov    %rsi,(%rsp)
  401428:	callq  401397 <rfc_wrap>
  40142d:	mov    (%rsp),%rsi
  401431:	mov    0x8(%rsp),%rdi
  401436:	mov    0x10(%rsp),%r8
  40143b:	mov    0x18(%rsp),%r9
  401440:	mov    %rax,%rdx
  401443:	jmpq   401fd9 <nx_construct2+0x29>
  401448:	mov    %r8,%rdx
  40144b:	mov    $0x1,%ecx
  401450:	mov    %r9,(%rsp)
  401454:	callq  401397 <rfc_wrap>
  401459:	mov    (%rsp),%r9
  40145d:	mov    %rax,%r8
  401460:	jmpq   401ff2 <nx_construct2+0x42>

Disassembly of section .fini:
