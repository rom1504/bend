
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004027d0 <nx_rt_fast_build2>:
  4027d0:	push   %r15
  4027d2:	push   %r14
  4027d4:	push   %r13
  4027d6:	mov    %rdx,%r13
  4027d9:	push   %r12
  4027db:	mov    %rcx,%r12
  4027de:	push   %rbp
  4027df:	push   %rbx
  4027e0:	mov    %esi,%ebx
  4027e2:	sub    $0x18,%rsp
  4027e6:	mov    0x8(%rdi),%r14
  4027ea:	mov    (%rdi),%r15
  4027ed:	mov    0x8(%r14),%rbp
  4027f1:	test   %rbp,%rbp
  4027f4:	je     4015f3 <nx_rt_fast_build2.cold+0x40>
  4027fa:	lea    (%r15,%rbp,8),%r8
  4027fe:	mov    (%r8),%rax
  402801:	subq   $0x2,0x108(%r14)
  402809:	mov    %rax,0x8(%r14)
  40280d:	mov    %r13,%rax
  402810:	shr    $0x38,%rax
  402814:	and    $0x7f,%eax
  402817:	cmp    $0x2,%rax
  40281b:	je     402860 <nx_rt_fast_build2+0x90>
  40281d:	mov    %r12,%rax
  402820:	mov    %r13,(%r8)
  402823:	lea    0x8(%r15,%rbp,8),%r13
  402828:	shr    $0x38,%rax
  40282c:	and    $0x7f,%eax
  40282f:	cmp    $0x2,%rax
  402833:	je     402870 <nx_rt_fast_build2+0xa0>
  402835:	mov    %rbx,%rax
  402838:	mov    %r12,0x0(%r13)
  40283c:	add    $0x18,%rsp
  402840:	shl    $0x28,%rax
  402844:	pop    %rbx
  402845:	or     %rbp,%rax
  402848:	pop    %rbp
  402849:	pop    %r12
  40284b:	bts    $0x39,%rax
  402850:	pop    %r13
  402852:	pop    %r14
  402854:	pop    %r15
  402856:	retq   
  402857:	nopw   0x0(%rax,%rax,1)
  402860:	test   %r13,%r13
  402863:	js     40281d <nx_rt_fast_build2+0x4d>
  402865:	jmpq   4015b3 <nx_rt_fast_build2.cold>
  40286a:	nopw   0x0(%rax,%rax,1)
  402870:	test   %r12,%r12
  402873:	js     402835 <nx_rt_fast_build2+0x65>
  402875:	jmpq   4015d8 <nx_rt_fast_build2.cold+0x25>

Disassembly of section .fini:
