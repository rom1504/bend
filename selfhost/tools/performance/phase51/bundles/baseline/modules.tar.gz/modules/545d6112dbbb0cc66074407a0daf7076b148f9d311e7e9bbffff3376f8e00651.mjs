function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $Sel$fit$(_v_0) {
  const _f_0 = _v_0["fit"];
  return _f_0;
}

function $Sel$seed$(_v_0) {
  const _s_0 = _v_0["seed"];
  return _s_0;
}

function $b2u$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $prng$(_x_0) {
  const _x_1 = (13 >= 32 ? 0 : (_x_0 << 13) >>> 0);
  const _b_0 = ((_x_0 ^ _x_1) >>> 0);
  const _x_2 = (17 >= 32 ? 0 : (_b_0 >>> 17) >>> 0);
  const _d_0 = ((_b_0 ^ _x_2) >>> 0);
  const _x_3 = (5 >= 32 ? 0 : (_d_0 << 5) >>> 0);
  return ((_d_0 ^ _x_3) >>> 0);
}

function $sel$go$(_x_0, _y_0, _z_0) {
  if (_z_0) {
    return _x_0;
  } else {
    return _y_0;
  }
}

function $sel$(_t_0, _x_0, _y_0) {
  return $sel$go$(_x_0, _y_0, (_t_0 === 0));
}

function $adiff$(_a_0, _b_0) {
  return $sel$(($b2u$((_a_0 < _b_0))), ((_a_0 - _b_0) >>> 0), ((_b_0 - _a_0) >>> 0));
}

function $node$(_o_0, _a_0, _b_0) {
  if (_o_0 === 0) {
    return {$: "Add", "a": _a_0, "b": _b_0};
  } else if (_o_0 === 1) {
    return {$: "Sub", "a": _a_0, "b": _b_0};
  } else if (_o_0 === 2) {
    return {$: "Mul", "a": _a_0, "b": _b_0};
  } else {
    return {$: "Xor", "a": _a_0, "b": _b_0};
  }
}

function $gen$leaf$(_h_0, _z_0) {
  if (_z_0) {
    return {$: "Var"};
  } else {
    return {$: "Lit", "v": ((_h_0 & 255) >>> 0)};
  }
}

function $gen$(_d_0, _h_0) {
  if (_d_0 === 0) {
    const _x_0 = (8 >= 32 ? 0 : (_h_0 >>> 8) >>> 0);
    const _x_1 = ((_x_0 & 1) >>> 0);
    return $gen$leaf$(_h_0, (_x_1 === 0));
  } else {
    const _p_0 = (_d_0 - 1);
    const _a_0 = ($gen$(_p_0, ($prng$(((_h_0 ^ 2654435761) >>> 0)))));
    const _b_0 = ($gen$(_p_0, ($prng$(((_h_0 + 340573321) >>> 0)))));
    const _x_2 = (4 === 0 ? _h_0 : _h_0 % 4);
    return $node$(_x_2, _a_0, _b_0);
  }
}

function $eval$(_e_0, _x_0) {
  if (_e_0.$ === "Var") {
    return _x_0;
  } else if (_e_0.$ === "Lit") {
    const _v_0 = _e_0["v"];
    return _v_0;
  } else if (_e_0.$ === "Add") {
    const _a_0 = _e_0["a"];
    const _b_0 = _e_0["b"];
    const _x_1 = ($eval$(_a_0, _x_0));
    const _x_2 = ($eval$(_b_0, _x_0));
    return ((_x_1 + _x_2) >>> 0);
  } else if (_e_0.$ === "Sub") {
    const _a_1 = _e_0["a"];
    const _b_1 = _e_0["b"];
    const _x_3 = ($eval$(_a_1, _x_0));
    const _x_4 = ($eval$(_b_1, _x_0));
    return ((_x_3 - _x_4) >>> 0);
  } else if (_e_0.$ === "Mul") {
    const _a_2 = _e_0["a"];
    const _b_2 = _e_0["b"];
    const _x_5 = ($eval$(_a_2, _x_0));
    const _x_6 = ($eval$(_b_2, _x_0));
    return (Math.imul(_x_5, _x_6) >>> 0);
  } else {
    const _a_3 = _e_0["a"];
    const _b_3 = _e_0["b"];
    const _x_7 = ($eval$(_a_3, _x_0));
    const _x_8 = ($eval$(_b_3, _x_0));
    return ((_x_7 ^ _x_8) >>> 0);
  }
}

function $esize$(_e_0) {
  if (_e_0.$ === "Var") {
    return 1;
  } else if (_e_0.$ === "Lit") {
    return 1;
  } else if (_e_0.$ === "Add") {
    const _a_0 = _e_0["a"];
    const _b_0 = _e_0["b"];
    const _x_0 = ($esize$(_a_0));
    const _x_1 = ($esize$(_b_0));
    const _x_2 = ((_x_0 + _x_1) >>> 0);
    return ((1 + _x_2) >>> 0);
  } else if (_e_0.$ === "Sub") {
    const _a_1 = _e_0["a"];
    const _b_1 = _e_0["b"];
    const _x_3 = ($esize$(_a_1));
    const _x_4 = ($esize$(_b_1));
    const _x_5 = ((_x_3 + _x_4) >>> 0);
    return ((1 + _x_5) >>> 0);
  } else if (_e_0.$ === "Mul") {
    const _a_2 = _e_0["a"];
    const _b_2 = _e_0["b"];
    const _x_6 = ($esize$(_a_2));
    const _x_7 = ($esize$(_b_2));
    const _x_8 = ((_x_6 + _x_7) >>> 0);
    return ((1 + _x_8) >>> 0);
  } else {
    const _a_3 = _e_0["a"];
    const _b_3 = _e_0["b"];
    const _x_9 = ($esize$(_a_3));
    const _x_10 = ($esize$(_b_3));
    const _x_11 = ((_x_9 + _x_10) >>> 0);
    return ((1 + _x_11) >>> 0);
  }
}

function $floop$($0, $1, $2) {
  for (;;) {
    {
      const _j_0 = $0;
      const _e_0 = $1;
      const _acc_0 = $2;
      if (_j_0 === 0) {
        const _x_0 = ($esize$(_e_0));
        const _x_1 = (Math.imul(_x_0, 8) >>> 0);
        return ((_acc_0 + _x_1) >>> 0);
      } else {
        const _p_0 = (_j_0 - 1);
        const _xx_0 = (_p_0 >>> 0);
        const _v_0 = ($eval$(_e_0, _xx_0));
        const _x_2 = (Math.imul(3, _xx_0) >>> 0);
        const _x_3 = (Math.imul(_xx_0, _xx_0) >>> 0);
        const _x_4 = ((_x_2 + 7) >>> 0);
        const _t_0 = ((_x_3 + _x_4) >>> 0);
        const _x_5 = ($adiff$(_v_0, _t_0));
        $0 = _p_0;
        $1 = _e_0;
        $2 = ((_acc_0 + _x_5) >>> 0);
        continue;
      }
    }
  }
}

function $cand$(_s_0, _pts_0) {
  const _t_0 = ($gen$(5, ($prng$(_s_0))));
  const _f_0 = ($floop$(_pts_0, _t_0, 0));
  const _x_0 = (Math.imul(_s_0, 2654435761) >>> 0);
  return {$: "Sel", "fit": _f_0, "seed": _s_0, "sum": ((_f_0 ^ _x_0) >>> 0)};
}

function $pick$(_a_0, _b_0) {
  const _f1_0 = _a_0["fit"];
  const _s1_0 = _a_0["seed"];
  const _c1_0 = _a_0["sum"];
  const _f2_0 = _b_0["fit"];
  const _s2_0 = _b_0["seed"];
  const _c2_0 = _b_0["sum"];
  const _w_0 = ($b2u$((_f1_0 < _f2_0)));
  return {$: "Sel", "fit": ($sel$(_w_0, _f2_0, _f1_0)), "seed": ($sel$(_w_0, _s2_0, _s1_0)), "sum": ((_c1_0 + _c2_0) >>> 0)};
}

function $batch$(_d_0, _s_0, _pts_0) {
  if (_d_0 === 0) {
    return $cand$(($prng$(_s_0)), _pts_0);
  } else {
    const _p_0 = (_d_0 - 1);
    const _x_0 = (Math.imul(_s_0, 1664525) >>> 0);
    const _a_0 = ($batch$(_p_0, ((_x_0 + 1) >>> 0), _pts_0));
    const _x_1 = (Math.imul(_s_0, 214013) >>> 0);
    const _b_0 = ($batch$(_p_0, ((_x_1 + 3) >>> 0), _pts_0));
    return $pick$(_a_0, _b_0);
  }
}

function $climb$($0, $1, $2, $3) {
  for (;;) {
    {
      const _r_0 = $0;
      const _bs_0 = $1;
      const _bf_0 = $2;
      const _pts_0 = $3;
      if (_r_0 === 0) {
        const _x_0 = (Math.imul(_bs_0, 2654435761) >>> 0);
        return ((_bf_0 ^ _x_0) >>> 0);
      } else {
        const _p_0 = (_r_0 - 1);
        const _x_1 = (_p_0 >>> 0);
        const _x_2 = ((_x_1 + 1) >>> 0);
        const _x_3 = (Math.imul(_x_2, 40503) >>> 0);
        const _cn_0 = ($cand$(($prng$(((_bs_0 ^ _x_3) >>> 0))), _pts_0));
        const _ff_0 = ($Sel$fit$(_cn_0));
        const _w_0 = ($b2u$((_ff_0 < _bf_0)));
        $0 = _p_0;
        $1 = ($sel$(_w_0, _bs_0, ($Sel$seed$(_cn_0))));
        $2 = ($sel$(_w_0, _bf_0, _ff_0));
        $3 = _pts_0;
        continue;
      }
    }
  }
}

function $run$fin$(_r_0, _p_0, _t_0) {
  const _f_0 = _t_0["fit"];
  const _s_0 = _t_0["seed"];
  const _c_0 = _t_0["sum"];
  const _x_0 = ($climb$(_r_0, _s_0, _f_0, _p_0));
  return ((_x_0 + _c_0) >>> 0);
}

function $run$(_d_0, _s0_0, _r_0, _p_0) {
  return $run$fin$(_r_0, _p_0, ($batch$(_d_0, _s0_0, _p_0)));
}

function $size$() {
  return 18;
}

function $pts$() {
  return 110;
}

function $bench$(_size_0, _seed_0) {
  return $run$(_size_0, _seed_0, 32, 16);
}
export default {
  "Sel.fit": run_lib((a0) => { const r = (run_loop($Sel$fit$((a0)))); (a0); return r; }, 1),
  "Sel.seed": run_lib((a0) => { const r = (run_loop($Sel$seed$((a0)))); (a0); return r; }, 1),
  "b2u": run_lib((a0) => { const r = (run_loop($b2u$((a0)))); (a0); return r; }, 1),
  "prng": run_lib((a0) => { const r = (run_loop($prng$((a0)))); (a0); return r; }, 1),
  "sel.go": run_lib((a0, a1, a2) => { const r = (run_loop($sel$go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "sel": run_lib((a0, a1, a2) => { const r = (run_loop($sel$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "adiff": run_lib((a0, a1) => { const r = (run_loop($adiff$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "node": run_lib((a0, a1, a2) => { const r = (run_loop($node$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "gen.leaf": run_lib((a0, a1) => { const r = (run_loop($gen$leaf$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "gen": run_lib((a0, a1) => { const r = (run_loop($gen$(nat_host(a0), (a1)))); BigInt(a0); (a1); return r; }, 2),
  "eval": run_lib((a0, a1) => { const r = (run_loop($eval$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "esize": run_lib((a0) => { const r = (run_loop($esize$((a0)))); (a0); return r; }, 1),
  "floop": run_lib((a0, a1, a2) => { const r = (run_loop($floop$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "cand": run_lib((a0, a1) => { const r = (run_loop($cand$((a0), nat_host(a1)))); (a0); BigInt(a1); return r; }, 2),
  "pick": run_lib((a0, a1) => { const r = (run_loop($pick$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "batch": run_lib((a0, a1, a2) => { const r = (run_loop($batch$(nat_host(a0), (a1), nat_host(a2)))); BigInt(a0); (a1); BigInt(a2); return r; }, 3),
  "climb": run_lib((a0, a1, a2, a3) => { const r = (run_loop($climb$(nat_host(a0), (a1), (a2), nat_host(a3)))); BigInt(a0); (a1); (a2); BigInt(a3); return r; }, 4),
  "run.fin": run_lib((a0, a1, a2) => { const r = (run_loop($run$fin$(nat_host(a0), nat_host(a1), (a2)))); BigInt(a0); BigInt(a1); (a2); return r; }, 3),
  "run": run_lib((a0, a1, a2, a3) => { const r = (run_loop($run$(nat_host(a0), (a1), nat_host(a2), nat_host(a3)))); BigInt(a0); (a1); BigInt(a2); BigInt(a3); return r; }, 4),
  "size": run_lib(() => { const r = BigInt(run_loop($size$()));  return r; }, 0),
  "pts": run_lib(() => { const r = BigInt(run_loop($pts$()));  return r; }, 0),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
};
