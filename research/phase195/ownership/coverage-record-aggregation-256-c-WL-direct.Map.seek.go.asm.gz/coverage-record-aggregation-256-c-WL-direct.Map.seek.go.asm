
/home/ai/bend2/build/publish/bend/selfhost/build/phase184/bend-products01/coverage-record-aggregation-256/bend-c/program:     file format elf64-x86-64


Disassembly of section .text:

000000000002afc0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_>:
   2afc0:	push   %rbp
   2afc1:	sub    $0x50,%rsp
   2afc5:	mov    %rsi,%rbx
   2afc8:	movabs $0xffff0000000000,%rax
   2afd2:	movabs $0xffffffff80,%r10
   2afdc:	mov    %rsi,%rcx
   2afdf:	and    %rax,%rcx
   2afe2:	movabs $0x2d0000000000,%rsi
   2afec:	cmp    %rsi,%rcx
   2afef:	jne    2b027 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x67>
   2aff1:	mov    %r14,(%rsp)
   2aff5:	lea    0x7f(%r10),%r8
   2aff9:	mov    %rbx,%rsi
   2affc:	and    %r8,%rsi
   2afff:	test   %rbx,%rbx
   2b002:	js     2b075 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xb5>
   2b004:	mov    (%r12,%rsi,8),%r11
   2b008:	mov    0x8(%r12,%rsi,8),%rbp
   2b00d:	mov    0x10(%r12,%rsi,8),%r14
   2b012:	mov    %rsi,%rcx
   2b015:	cmp    $0x3108280,%rcx
   2b01c:	jae    2b0f5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x135>
   2b022:	jmpq   2b12d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16d>
   2b027:	movabs $0x7e00000000000000,%r9
   2b031:	and    %rdx,%rax
   2b034:	movabs $0x80000000000,%rcx
   2b03e:	cmp    %rcx,%rax
   2b041:	jne    30a8e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5ace>
   2b047:	lea    0x7f(%r10),%rax
   2b04b:	and    %rdx,%rax
   2b04e:	test   %rdx,%rdx
   2b051:	js     2b1be <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1fe>
   2b057:	mov    (%r12,%rax,8),%rbp
   2b05b:	mov    0x8(%r12,%rax,8),%rdx
   2b060:	mov    %rax,%rcx
   2b063:	cmp    $0x3108280,%rcx
   2b06a:	jae    2b22f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26f>
   2b070:	jmpq   2b266 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a6>
   2b075:	mov    %r8,%r9
   2b078:	mov    0x4(%r12,%rsi,8),%ecx
   2b07d:	mov    (%r12,%rsi,8),%edi
   2b081:	mov    %edi,%r8d
   2b084:	and    $0xffffff,%r8d
   2b08b:	cmp    $0x1,%r8d
   2b08f:	jne    2d8c6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2906>
   2b095:	mov    (%r12,%rsi,8),%ebx
   2b099:	shl    $0x20,%rcx
   2b09d:	or     %rdi,%rcx
   2b0a0:	shr    $0x18,%rcx
   2b0a4:	mov    (%r12,%rcx,8),%r11
   2b0a8:	mov    0x8(%r12,%rcx,8),%rbp
   2b0ad:	mov    0x10(%r12,%rcx,8),%r14
   2b0b2:	mov    0x0(%r13),%rdi
   2b0b6:	mov    %rdi,(%r12,%rsi,8)
   2b0ba:	mov    %rsi,0x0(%r13)
   2b0be:	mov    0x100(%r13),%rsi
   2b0c5:	inc    %rsi
   2b0c8:	mov    %rsi,0x100(%r13)
   2b0cf:	cmpb   $0x1,0x11eb3a(%rip)        # 149c10 <KEEP_WORDS>
   2b0d6:	jne    2e367 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x33a7>
   2b0dc:	cmp    $0x8000,%rsi
   2b0e3:	jae    2e367 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x33a7>
   2b0e9:	mov    %r9,%r8
   2b0ec:	cmp    $0x3108280,%rcx
   2b0f3:	jb     2b12d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16d>
   2b0f5:	mov    0x10(%r13),%rsi
   2b0f9:	mov    %rsi,(%r12,%rcx,8)
   2b0fd:	mov    %rcx,0x10(%r13)
   2b101:	mov    0x110(%r13),%rcx
   2b108:	add    $0x4,%rcx
   2b10c:	mov    %rcx,0x110(%r13)
   2b113:	cmpb   $0x1,0x11eaf6(%rip)        # 149c10 <KEEP_WORDS>
   2b11a:	jne    2d88a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28ca>
   2b120:	cmp    $0x8000,%rcx
   2b127:	jae    2d88a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28ca>
   2b12d:	mov    %rbp,%rcx
   2b130:	shr    $0x28,%rcx
   2b134:	cmp    $0x2d,%cx
   2b138:	je     2b37f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3bf>
   2b13e:	movzwl %cx,%ecx
   2b141:	cmp    $0x2c,%ecx
   2b144:	je     2b356 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x396>
   2b14a:	cmp    $0x2b,%ecx
   2b14d:	jne    30b32 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b72>
   2b153:	mov    %r14,%rcx
   2b156:	shr    $0x28,%rcx
   2b15a:	cmp    $0x2d,%cx
   2b15e:	je     2b704 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x744>
   2b164:	movzwl %cx,%ecx
   2b167:	cmp    $0x2c,%ecx
   2b16a:	je     2b6d2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x712>
   2b170:	cmp    $0x2b,%ecx
   2b173:	jne    30f24 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5f64>
   2b179:	and    %rdx,%rax
   2b17c:	movabs $0x80000000000,%rcx
   2b186:	cmp    %rcx,%rax
   2b189:	jne    3146e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x64ae>
   2b18f:	and    %rdx,%r8
   2b192:	test   %rdx,%rdx
   2b195:	mov    %r15d,0x30(%rsp)
   2b19a:	js     2d69c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26dc>
   2b1a0:	mov    (%r12,%r8,8),%r9
   2b1a4:	mov    0x8(%r12,%r8,8),%rax
   2b1a9:	mov    %r8,%rcx
   2b1ac:	cmp    $0x3108280,%rcx
   2b1b3:	jae    2d714 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2754>
   2b1b9:	jmpq   2d74c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x278c>
   2b1be:	mov    0x4(%r12,%rax,8),%ecx
   2b1c3:	mov    (%r12,%rax,8),%esi
   2b1c7:	mov    %esi,%edi
   2b1c9:	and    $0xffffff,%edi
   2b1cf:	cmp    $0x1,%edi
   2b1d2:	jne    2d912 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2952>
   2b1d8:	mov    (%r12,%rax,8),%edx
   2b1dc:	shl    $0x20,%rcx
   2b1e0:	or     %rsi,%rcx
   2b1e3:	shr    $0x18,%rcx
   2b1e7:	mov    (%r12,%rcx,8),%rbp
   2b1eb:	mov    0x8(%r12,%rcx,8),%rdx
   2b1f0:	mov    0x0(%r13),%rsi
   2b1f4:	mov    %rsi,(%r12,%rax,8)
   2b1f8:	mov    %rax,0x0(%r13)
   2b1fc:	mov    0x100(%r13),%rax
   2b203:	inc    %rax
   2b206:	mov    %rax,0x100(%r13)
   2b20d:	cmpb   $0x1,0x11e9fc(%rip)        # 149c10 <KEEP_WORDS>
   2b214:	jne    2e395 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x33d5>
   2b21a:	cmp    $0x8000,%rax
   2b220:	jae    2e395 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x33d5>
   2b226:	cmp    $0x3108280,%rcx
   2b22d:	jb     2b266 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a6>
   2b22f:	mov    0x8(%r13),%rax
   2b233:	mov    %rax,(%r12,%rcx,8)
   2b237:	mov    %rcx,0x8(%r13)
   2b23b:	mov    0x108(%r13),%rax
   2b242:	add    $0x2,%rax
   2b246:	mov    %rax,0x108(%r13)
   2b24d:	cmpb   $0x1,0x11e9bc(%rip)        # 149c10 <KEEP_WORDS>
   2b254:	jne    2d8b1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28f1>
   2b25a:	cmp    $0x8000,%rax
   2b260:	jae    2d8b1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28f1>
   2b266:	test   %r9,%rdx
   2b269:	sete   %al
   2b26c:	cmp    $0xffffffffffffffff,%rdx
   2b270:	sete   %cl
   2b273:	or     %al,%cl
   2b275:	and    %rdx,%r10
   2b278:	cmp    $0x3108280,%r10
   2b27f:	setb   %al
   2b282:	or     %cl,%al
   2b284:	jne    2b291 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2d1>
   2b286:	mov    %r12,%rdi
   2b289:	mov    %r13,%rsi
   2b28c:	callq  c660 <term_drop>
   2b291:	mov    0x8(%r13),%r8
   2b295:	test   %r8,%r8
   2b298:	je     2b73b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x77b>
   2b29e:	mov    (%r12,%r8,8),%rax
   2b2a2:	mov    %rax,0x8(%r13)
   2b2a6:	addq   $0xfffffffffffffffe,0x108(%r13)
   2b2ae:	mov    %rbp,%rax
   2b2b1:	shr    $0x38,%rax
   2b2b5:	cmp    $0x2,%eax
   2b2b8:	je     2b75e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x79e>
   2b2be:	movabs $0xff00000000000000,%rcx
   2b2c8:	movabs $0x200080000000000,%rsi
   2b2d2:	mov    %rbp,(%r12,%r8,8)
   2b2d6:	movabs $0x1000b0000000000,%rax
   2b2e0:	mov    %rax,0x8(%r12,%r8,8)
   2b2e5:	mov    0x8(%r13),%r9
   2b2e9:	test   %r9,%r9
   2b2ec:	je     2b779 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x7b9>
   2b2f2:	mov    (%r12,%r9,8),%rax
   2b2f6:	mov    %rax,0x8(%r13)
   2b2fa:	addq   $0xfffffffffffffffe,0x108(%r13)
   2b302:	or     %rsi,%r8
   2b305:	and    %rbx,%rcx
   2b308:	movabs $0x200000000000000,%rax
   2b312:	cmp    %rax,%rcx
   2b315:	je     2b797 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x7d7>
   2b31b:	mov    %rbx,(%r12,%r9,8)
   2b31f:	mov    %r8,%rax
   2b322:	shr    $0x38,%rax
   2b326:	cmp    $0x2,%eax
   2b329:	jbe    2b7b8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x7f8>
   2b32f:	mov    %r8,0x8(%r12,%r9,8)
   2b334:	or     %r9,%rsi
   2b337:	mov    -0x8(%r14),%eax
   2b33b:	add    $0xfffffffffffffff8,%r14
   2b33f:	lea    0x1c56a(%rip),%rcx        # 478b0 <wl_tab>
   2b346:	mov    (%rcx,%rax,8),%rax
   2b34a:	mov    $0x1,%edi
   2b34f:	add    $0x50,%rsp
   2b353:	pop    %rbp
   2b354:	jmpq   *%rax
   2b356:	mov    %rbp,%rsi
   2b359:	and    %r8,%rsi
   2b35c:	test   %rbp,%rbp
   2b35f:	js     2b3bb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3fb>
   2b361:	mov    (%r12,%rsi,8),%rbp
   2b365:	mov    0x8(%r12,%rsi,8),%rbx
   2b36a:	mov    %rsi,%rcx
   2b36d:	cmp    $0x3108280,%rcx
   2b374:	jae    2b42d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x46d>
   2b37a:	jmpq   2b465 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a5>
   2b37f:	mov    %rbp,%rsi
   2b382:	and    %r8,%rsi
   2b385:	test   %rbp,%rbp
   2b388:	js     2b4ce <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x50e>
   2b38e:	mov    (%r12,%rsi,8),%rbx
   2b392:	mov    0x8(%r12,%rsi,8),%rcx
   2b397:	mov    %rcx,0x18(%rsp)
   2b39c:	mov    0x10(%r12,%rsi,8),%rcx
   2b3a1:	mov    %rcx,0x8(%rsp)
   2b3a6:	mov    %rsi,%rcx
   2b3a9:	cmp    $0x3108280,%rcx
   2b3b0:	jae    2b555 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x595>
   2b3b6:	jmpq   2b58d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5cd>
   2b3bb:	mov    0x4(%r12,%rsi,8),%ecx
   2b3c0:	mov    (%r12,%rsi,8),%edi
   2b3c4:	mov    %edi,%ebx
   2b3c6:	and    $0xffffff,%ebx
   2b3cc:	cmp    $0x1,%ebx
   2b3cf:	jne    2e408 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3448>
   2b3d5:	mov    (%r12,%rsi,8),%ebx
   2b3d9:	shl    $0x20,%rcx
   2b3dd:	or     %rdi,%rcx
   2b3e0:	shr    $0x18,%rcx
   2b3e4:	mov    (%r12,%rcx,8),%rbp
   2b3e8:	mov    0x8(%r12,%rcx,8),%rbx
   2b3ed:	mov    0x0(%r13),%rdi
   2b3f1:	mov    %rdi,(%r12,%rsi,8)
   2b3f5:	mov    %rsi,0x0(%r13)
   2b3f9:	mov    0x100(%r13),%rsi
   2b400:	inc    %rsi
   2b403:	mov    %rsi,0x100(%r13)
   2b40a:	cmpb   $0x1,0x11e7ff(%rip)        # 149c10 <KEEP_WORDS>
   2b411:	jne    2e4bc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x34fc>
   2b417:	cmp    $0x8000,%rsi
   2b41e:	jae    2e4bc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x34fc>
   2b424:	cmp    $0x3108280,%rcx
   2b42b:	jb     2b465 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a5>
   2b42d:	mov    0x8(%r13),%rsi
   2b431:	mov    %rsi,(%r12,%rcx,8)
   2b435:	mov    %rcx,0x8(%r13)
   2b439:	mov    0x108(%r13),%rcx
   2b440:	add    $0x2,%rcx
   2b444:	mov    %rcx,0x108(%r13)
   2b44b:	cmpb   $0x1,0x11e7be(%rip)        # 149c10 <KEEP_WORDS>
   2b452:	jne    2e3ba <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x33fa>
   2b458:	cmp    $0x8000,%rcx
   2b45f:	jae    2e3ba <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x33fa>
   2b465:	mov    %r14,%rcx
   2b468:	shr    $0x28,%rcx
   2b46c:	cmp    $0x2d,%cx
   2b470:	je     2b628 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x668>
   2b476:	movzwl %cx,%ecx
   2b479:	cmp    $0x2c,%ecx
   2b47c:	je     2b5f6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x636>
   2b482:	cmp    $0x2b,%ecx
   2b485:	jne    30c7a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5cba>
   2b48b:	and    %rdx,%rax
   2b48e:	movabs $0x80000000000,%rcx
   2b498:	cmp    %rcx,%rax
   2b49b:	jne    314eb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x652b>
   2b4a1:	mov    %rdx,%rsi
   2b4a4:	and    %r8,%rsi
   2b4a7:	test   %rdx,%rdx
   2b4aa:	js     2cc40 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1c80>
   2b4b0:	mov    (%r12,%rsi,8),%rdi
   2b4b4:	mov    0x8(%r12,%rsi,8),%rax
   2b4b9:	mov    %rsi,%rcx
   2b4bc:	cmp    $0x3108280,%rcx
   2b4c3:	jae    2ccca <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d0a>
   2b4c9:	jmpq   2cd02 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d42>
   2b4ce:	mov    %rdx,%r9
   2b4d1:	mov    0x4(%r12,%rsi,8),%ecx
   2b4d6:	mov    (%r12,%rsi,8),%edx
   2b4da:	mov    %edx,%edi
   2b4dc:	and    $0xffffff,%edi
   2b4e2:	cmp    $0x1,%edi
   2b4e5:	jne    2e461 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x34a1>
   2b4eb:	mov    (%r12,%rsi,8),%edi
   2b4ef:	shl    $0x20,%rcx
   2b4f3:	or     %rdx,%rcx
   2b4f6:	shr    $0x18,%rcx
   2b4fa:	mov    (%r12,%rcx,8),%rbx
   2b4fe:	mov    0x8(%r12,%rcx,8),%rdx
   2b503:	mov    %rdx,0x18(%rsp)
   2b508:	mov    0x10(%r12,%rcx,8),%rdx
   2b50d:	mov    %rdx,0x8(%rsp)
   2b512:	mov    0x0(%r13),%rdx
   2b516:	mov    %rdx,(%r12,%rsi,8)
   2b51a:	mov    %rsi,0x0(%r13)
   2b51e:	mov    0x100(%r13),%rdx
   2b525:	inc    %rdx
   2b528:	mov    %rdx,0x100(%r13)
   2b52f:	cmpb   $0x1,0x11e6da(%rip)        # 149c10 <KEEP_WORDS>
   2b536:	jne    2e4fd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x353d>
   2b53c:	cmp    $0x8000,%rdx
   2b543:	jae    2e4fd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x353d>
   2b549:	mov    %r9,%rdx
   2b54c:	cmp    $0x3108280,%rcx
   2b553:	jb     2b58d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5cd>
   2b555:	mov    0x10(%r13),%rsi
   2b559:	mov    %rsi,(%r12,%rcx,8)
   2b55d:	mov    %rcx,0x10(%r13)
   2b561:	mov    0x110(%r13),%rcx
   2b568:	add    $0x4,%rcx
   2b56c:	mov    %rcx,0x110(%r13)
   2b573:	cmpb   $0x1,0x11e696(%rip)        # 149c10 <KEEP_WORDS>
   2b57a:	jne    2e3e1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3421>
   2b580:	cmp    $0x8000,%rcx
   2b587:	jae    2e3e1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3421>
   2b58d:	mov    %r14,%rcx
   2b590:	shr    $0x28,%rcx
   2b594:	cmp    $0x2d,%cx
   2b598:	je     2b69b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6db>
   2b59e:	movzwl %cx,%ecx
   2b5a1:	cmp    $0x2c,%ecx
   2b5a4:	je     2b669 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6a9>
   2b5aa:	cmp    $0x2b,%ecx
   2b5ad:	jne    30dab <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5deb>
   2b5b3:	and    %rdx,%rax
   2b5b6:	movabs $0x80000000000,%rcx
   2b5c0:	cmp    %rcx,%rax
   2b5c3:	jne    315df <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x661f>
   2b5c9:	mov    %rdx,%rsi
   2b5cc:	and    %r8,%rsi
   2b5cf:	test   %rdx,%rdx
   2b5d2:	js     2d19b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x21db>
   2b5d8:	mov    (%r12,%rsi,8),%rbp
   2b5dc:	mov    0x8(%r12,%rsi,8),%rax
   2b5e1:	mov    %rsi,%rcx
   2b5e4:	cmp    $0x3108280,%rcx
   2b5eb:	jae    2d213 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2253>
   2b5f1:	jmpq   2d24b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x228b>
   2b5f6:	mov    %r14,%rsi
   2b5f9:	and    %r8,%rsi
   2b5fc:	test   %r14,%r14
   2b5ff:	js     2b7d9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x819>
   2b605:	mov    (%r12,%rsi,8),%r9
   2b609:	mov    0x8(%r12,%rsi,8),%rcx
   2b60e:	mov    %rcx,0x8(%rsp)
   2b613:	mov    %rsi,%rcx
   2b616:	cmp    $0x3108280,%rcx
   2b61d:	jae    2b860 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8a0>
   2b623:	jmpq   2b898 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8d8>
   2b628:	mov    %r14,%rsi
   2b62b:	and    %r8,%rsi
   2b62e:	test   %r14,%r14
   2b631:	js     2b8e2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x922>
   2b637:	mov    (%r12,%rsi,8),%rcx
   2b63b:	mov    %rcx,0x10(%rsp)
   2b640:	mov    0x8(%r12,%rsi,8),%rcx
   2b645:	mov    %rcx,0x18(%rsp)
   2b64a:	mov    0x10(%r12,%rsi,8),%rcx
   2b64f:	mov    %rcx,0x8(%rsp)
   2b654:	mov    %rsi,%rcx
   2b657:	cmp    $0x3108280,%rcx
   2b65e:	jae    2b96e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9ae>
   2b664:	jmpq   2b9a6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9e6>
   2b669:	mov    %r14,%rsi
   2b66c:	and    %r8,%rsi
   2b66f:	test   %r14,%r14
   2b672:	js     2b9f0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xa30>
   2b678:	mov    (%r12,%rsi,8),%r9
   2b67c:	mov    0x8(%r12,%rsi,8),%rcx
   2b681:	mov    %rcx,0x10(%rsp)
   2b686:	mov    %rsi,%rcx
   2b689:	cmp    $0x3108280,%rcx
   2b690:	jae    2ba70 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xab0>
   2b696:	jmpq   2baa8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xae8>
   2b69b:	mov    %r14,%rsi
   2b69e:	and    %r8,%rsi
   2b6a1:	test   %r14,%r14
   2b6a4:	js     2baed <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xb2d>
   2b6aa:	mov    (%r12,%rsi,8),%rcx
   2b6ae:	mov    %rcx,0x10(%rsp)
   2b6b3:	mov    0x8(%r12,%rsi,8),%r9
   2b6b8:	mov    0x10(%r12,%rsi,8),%rdi
   2b6bd:	mov    %rsi,%rcx
   2b6c0:	cmp    $0x3108280,%rcx
   2b6c7:	jae    2bb6f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbaf>
   2b6cd:	jmpq   2bba7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbe7>
   2b6d2:	mov    %r14,%rsi
   2b6d5:	and    %r8,%rsi
   2b6d8:	test   %r14,%r14
   2b6db:	js     2bbf1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xc31>
   2b6e1:	mov    (%r12,%rsi,8),%rbp
   2b6e5:	mov    0x8(%r12,%rsi,8),%rcx
   2b6ea:	mov    %rcx,0x8(%rsp)
   2b6ef:	mov    %rsi,%rcx
   2b6f2:	cmp    $0x3108280,%rcx
   2b6f9:	jae    2bc68 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xca8>
   2b6ff:	jmpq   2bca0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xce0>
   2b704:	mov    %r14,%rsi
   2b707:	and    %r8,%rsi
   2b70a:	test   %r14,%r14
   2b70d:	js     2bce3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xd23>
   2b713:	mov    (%r12,%rsi,8),%rbx
   2b717:	mov    0x8(%r12,%rsi,8),%rdi
   2b71c:	mov    0x10(%r12,%rsi,8),%rcx
   2b721:	mov    %rcx,0x8(%rsp)
   2b726:	mov    %rsi,%rcx
   2b729:	cmp    $0x3108280,%rcx
   2b730:	jae    2bd65 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xda5>
   2b736:	jmpq   2bd9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xddd>
   2b73b:	mov    %r12,%rdi
   2b73e:	mov    %r13,%rsi
   2b741:	mov    $0x1,%edx
   2b746:	callq  45448 <heap_alloc_miss>
   2b74b:	mov    %rax,%r8
   2b74e:	mov    %rbp,%rax
   2b751:	shr    $0x38,%rax
   2b755:	cmp    $0x2,%eax
   2b758:	jne    2b2be <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2fe>
   2b75e:	mov    %r12,%rdi
   2b761:	mov    %r13,%rsi
   2b764:	mov    %rbp,%rdx
   2b767:	mov    $0x1,%ecx
   2b76c:	callq  4574e <rfc_wrap>
   2b771:	mov    %rax,%rbp
   2b774:	jmpq   2b2be <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2fe>
   2b779:	mov    %r12,%rdi
   2b77c:	mov    %rsi,%r9
   2b77f:	mov    %r13,%rsi
   2b782:	mov    $0x1,%edx
   2b787:	callq  45448 <heap_alloc_miss>
   2b78c:	mov    %r9,%rsi
   2b78f:	mov    %rax,%r9
   2b792:	jmpq   2b302 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x342>
   2b797:	mov    %r12,%rdi
   2b79a:	mov    %rsi,%r10
   2b79d:	mov    %r13,%rsi
   2b7a0:	mov    %rbx,%rdx
   2b7a3:	mov    $0x1,%ecx
   2b7a8:	callq  4574e <rfc_wrap>
   2b7ad:	mov    %r10,%rsi
   2b7b0:	mov    %rax,%rbx
   2b7b3:	jmpq   2b31b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x35b>
   2b7b8:	mov    %r12,%rdi
   2b7bb:	mov    %rsi,%r10
   2b7be:	mov    %r13,%rsi
   2b7c1:	mov    %r8,%rdx
   2b7c4:	mov    $0x1,%ecx
   2b7c9:	callq  4574e <rfc_wrap>
   2b7ce:	mov    %r10,%rsi
   2b7d1:	mov    %rax,%r8
   2b7d4:	jmpq   2b32f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x36f>
   2b7d9:	mov    %rbp,0x20(%rsp)
   2b7de:	mov    %rbx,%rbp
   2b7e1:	mov    0x4(%r12,%rsi,8),%ecx
   2b7e6:	mov    (%r12,%rsi,8),%edi
   2b7ea:	mov    %edi,%ebx
   2b7ec:	and    $0xffffff,%ebx
   2b7f2:	cmp    $0x1,%ebx
   2b7f5:	jne    303c7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5407>
   2b7fb:	mov    (%r12,%rsi,8),%ebx
   2b7ff:	shl    $0x20,%rcx
   2b803:	or     %rdi,%rcx
   2b806:	shr    $0x18,%rcx
   2b80a:	mov    (%r12,%rcx,8),%r9
   2b80e:	mov    0x8(%r12,%rcx,8),%rdi
   2b813:	mov    %rdi,0x8(%rsp)
   2b818:	mov    0x0(%r13),%rdi
   2b81c:	mov    %rdi,(%r12,%rsi,8)
   2b820:	mov    %rsi,0x0(%r13)
   2b824:	mov    0x100(%r13),%rsi
   2b82b:	inc    %rsi
   2b82e:	mov    %rsi,0x100(%r13)
   2b835:	cmpb   $0x1,0x11e3d4(%rip)        # 149c10 <KEEP_WORDS>
   2b83c:	jne    307e0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5820>
   2b842:	cmp    $0x8000,%rsi
   2b849:	jae    307e0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5820>
   2b84f:	mov    %rbp,%rbx
   2b852:	mov    0x20(%rsp),%rbp
   2b857:	cmp    $0x3108280,%rcx
   2b85e:	jb     2b898 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8d8>
   2b860:	mov    0x8(%r13),%rsi
   2b864:	mov    %rsi,(%r12,%rcx,8)
   2b868:	mov    %rcx,0x8(%r13)
   2b86c:	mov    0x108(%r13),%rcx
   2b873:	add    $0x2,%rcx
   2b877:	mov    %rcx,0x108(%r13)
   2b87e:	cmpb   $0x1,0x11e38b(%rip)        # 149c10 <KEEP_WORDS>
   2b885:	jne    301b4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x51f4>
   2b88b:	cmp    $0x8000,%rcx
   2b892:	jae    301b4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x51f4>
   2b898:	and    %rdx,%rax
   2b89b:	movabs $0x80000000000,%rcx
   2b8a5:	cmp    %rcx,%rax
   2b8a8:	mov    %r15d,0x30(%rsp)
   2b8ad:	jne    30ff3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6033>
   2b8b3:	and    %rdx,%r8
   2b8b6:	test   %rdx,%rdx
   2b8b9:	js     2bde0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xe20>
   2b8bf:	mov    (%r12,%r8,8),%rax
   2b8c3:	mov    %rax,0x18(%rsp)
   2b8c8:	mov    0x8(%r12,%r8,8),%rax
   2b8cd:	mov    %r8,%rcx
   2b8d0:	cmp    $0x3108280,%rcx
   2b8d7:	jae    2be57 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xe97>
   2b8dd:	jmpq   2be8f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xecf>
   2b8e2:	mov    %rdx,%r9
   2b8e5:	mov    0x4(%r12,%rsi,8),%ecx
   2b8ea:	mov    (%r12,%rsi,8),%edx
   2b8ee:	mov    %edx,%edi
   2b8f0:	and    $0xffffff,%edi
   2b8f6:	cmp    $0x1,%edi
   2b8f9:	jne    3041d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x545d>
   2b8ff:	mov    (%r12,%rsi,8),%edi
   2b903:	shl    $0x20,%rcx
   2b907:	or     %rdx,%rcx
   2b90a:	shr    $0x18,%rcx
   2b90e:	mov    (%r12,%rcx,8),%rdx
   2b912:	mov    %rdx,0x10(%rsp)
   2b917:	mov    0x8(%r12,%rcx,8),%rdx
   2b91c:	mov    %rdx,0x18(%rsp)
   2b921:	mov    0x10(%r12,%rcx,8),%rdx
   2b926:	mov    %rdx,0x8(%rsp)
   2b92b:	mov    0x0(%r13),%rdx
   2b92f:	mov    %rdx,(%r12,%rsi,8)
   2b933:	mov    %rsi,0x0(%r13)
   2b937:	mov    0x100(%r13),%rdx
   2b93e:	inc    %rdx
   2b941:	mov    %rdx,0x100(%r13)
   2b948:	cmpb   $0x1,0x11e2c1(%rip)        # 149c10 <KEEP_WORDS>
   2b94f:	jne    30819 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5859>
   2b955:	cmp    $0x8000,%rdx
   2b95c:	jae    30819 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5859>
   2b962:	mov    %r9,%rdx
   2b965:	cmp    $0x3108280,%rcx
   2b96c:	jb     2b9a6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9e6>
   2b96e:	mov    0x10(%r13),%rsi
   2b972:	mov    %rsi,(%r12,%rcx,8)
   2b976:	mov    %rcx,0x10(%r13)
   2b97a:	mov    0x110(%r13),%rcx
   2b981:	add    $0x4,%rcx
   2b985:	mov    %rcx,0x110(%r13)
   2b98c:	cmpb   $0x1,0x11e27d(%rip)        # 149c10 <KEEP_WORDS>
   2b993:	jne    301e1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5221>
   2b999:	cmp    $0x8000,%rcx
   2b9a0:	jae    301e1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5221>
   2b9a6:	and    %rdx,%rax
   2b9a9:	movabs $0x80000000000,%rcx
   2b9b3:	cmp    %rcx,%rax
   2b9b6:	mov    %r15d,0x30(%rsp)
   2b9bb:	jne    31150 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6190>
   2b9c1:	and    %rdx,%r8
   2b9c4:	test   %rdx,%rdx
   2b9c7:	js     2c2c5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1305>
   2b9cd:	mov    (%r12,%r8,8),%rax
   2b9d1:	mov    %rax,0x20(%rsp)
   2b9d6:	mov    0x8(%r12,%r8,8),%rax
   2b9db:	mov    %r8,%rcx
   2b9de:	cmp    $0x3108280,%rcx
   2b9e5:	jae    2c33c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x137c>
   2b9eb:	jmpq   2c374 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x13b4>
   2b9f0:	mov    %r8,%rbp
   2b9f3:	mov    0x4(%r12,%rsi,8),%ecx
   2b9f8:	mov    (%r12,%rsi,8),%edi
   2b9fc:	mov    %edi,%r8d
   2b9ff:	and    $0xffffff,%r8d
   2ba06:	cmp    $0x1,%r8d
   2ba0a:	jne    30483 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x54c3>
   2ba10:	mov    (%r12,%rsi,8),%r8d
   2ba14:	shl    $0x20,%rcx
   2ba18:	or     %rdi,%rcx
   2ba1b:	shr    $0x18,%rcx
   2ba1f:	mov    (%r12,%rcx,8),%r9
   2ba23:	mov    0x8(%r12,%rcx,8),%rdi
   2ba28:	mov    %rdi,0x10(%rsp)
   2ba2d:	mov    0x0(%r13),%rdi
   2ba31:	mov    %rdi,(%r12,%rsi,8)
   2ba35:	mov    %rsi,0x0(%r13)
   2ba39:	mov    0x100(%r13),%rsi
   2ba40:	inc    %rsi
   2ba43:	mov    %rsi,0x100(%r13)
   2ba4a:	cmpb   $0x1,0x11e1bf(%rip)        # 149c10 <KEEP_WORDS>
   2ba51:	jne    3084d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x588d>
   2ba57:	cmp    $0x8000,%rsi
   2ba5e:	jae    3084d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x588d>
   2ba64:	mov    %rbp,%r8
   2ba67:	cmp    $0x3108280,%rcx
   2ba6e:	jb     2baa8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xae8>
   2ba70:	mov    0x8(%r13),%rsi
   2ba74:	mov    %rsi,(%r12,%rcx,8)
   2ba78:	mov    %rcx,0x8(%r13)
   2ba7c:	mov    0x108(%r13),%rcx
   2ba83:	add    $0x2,%rcx
   2ba87:	mov    %rcx,0x108(%r13)
   2ba8e:	cmpb   $0x1,0x11e17b(%rip)        # 149c10 <KEEP_WORDS>
   2ba95:	jne    30208 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5248>
   2ba9b:	cmp    $0x8000,%rcx
   2baa2:	jae    30208 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5248>
   2baa8:	and    %rdx,%rax
   2baab:	movabs $0x80000000000,%rcx
   2bab5:	cmp    %rcx,%rax
   2bab8:	mov    %r15d,0x30(%rsp)
   2babd:	jne    312df <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x631f>
   2bac3:	and    %rdx,%r8
   2bac6:	test   %rdx,%rdx
   2bac9:	js     2c65f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x169f>
   2bacf:	mov    (%r12,%r8,8),%r10
   2bad3:	mov    0x8(%r12,%r8,8),%rax
   2bad8:	mov    %r8,%rcx
   2badb:	cmp    $0x3108280,%rcx
   2bae2:	jae    2c6dd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x171d>
   2bae8:	jmpq   2c715 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1755>
   2baed:	mov    %rdx,%rbp
   2baf0:	mov    0x4(%r12,%rsi,8),%ecx
   2baf5:	mov    (%r12,%rsi,8),%edx
   2baf9:	mov    %edx,%edi
   2bafb:	and    $0xffffff,%edi
   2bb01:	cmp    $0x1,%edi
   2bb04:	jne    304da <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x551a>
   2bb0a:	mov    (%r12,%rsi,8),%edi
   2bb0e:	shl    $0x20,%rcx
   2bb12:	or     %rdx,%rcx
   2bb15:	shr    $0x18,%rcx
   2bb19:	mov    (%r12,%rcx,8),%rdx
   2bb1d:	mov    %rdx,0x10(%rsp)
   2bb22:	mov    0x8(%r12,%rcx,8),%r9
   2bb27:	mov    0x10(%r12,%rcx,8),%rdi
   2bb2c:	mov    0x0(%r13),%rdx
   2bb30:	mov    %rdx,(%r12,%rsi,8)
   2bb34:	mov    %rsi,0x0(%r13)
   2bb38:	mov    0x100(%r13),%rdx
   2bb3f:	inc    %rdx
   2bb42:	mov    %rdx,0x100(%r13)
   2bb49:	cmpb   $0x1,0x11e0c0(%rip)        # 149c10 <KEEP_WORDS>
   2bb50:	jne    30881 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x58c1>
   2bb56:	cmp    $0x8000,%rdx
   2bb5d:	jae    30881 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x58c1>
   2bb63:	mov    %rbp,%rdx
   2bb66:	cmp    $0x3108280,%rcx
   2bb6d:	jb     2bba7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbe7>
   2bb6f:	mov    0x10(%r13),%rsi
   2bb73:	mov    %rsi,(%r12,%rcx,8)
   2bb77:	mov    %rcx,0x10(%r13)
   2bb7b:	mov    0x110(%r13),%rcx
   2bb82:	add    $0x4,%rcx
   2bb86:	mov    %rcx,0x110(%r13)
   2bb8d:	cmpb   $0x1,0x11e07c(%rip)        # 149c10 <KEEP_WORDS>
   2bb94:	jne    30235 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5275>
   2bb9a:	cmp    $0x8000,%rcx
   2bba1:	jae    30235 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5275>
   2bba7:	and    %rdx,%rax
   2bbaa:	movabs $0x80000000000,%rcx
   2bbb4:	cmp    %rcx,%rax
   2bbb7:	mov    %r15d,0x30(%rsp)
   2bbbc:	jne    31705 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6745>
   2bbc2:	and    %rdx,%r8
   2bbc5:	test   %rdx,%rdx
   2bbc8:	js     2ca11 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a51>
   2bbce:	mov    (%r12,%r8,8),%rax
   2bbd2:	mov    %rax,0x20(%rsp)
   2bbd7:	mov    0x8(%r12,%r8,8),%rax
   2bbdc:	mov    %r8,%rcx
   2bbdf:	cmp    $0x3108280,%rcx
   2bbe6:	jae    2ca94 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ad4>
   2bbec:	jmpq   2cacc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b0c>
   2bbf1:	mov    0x4(%r12,%rsi,8),%ecx
   2bbf6:	mov    (%r12,%rsi,8),%edi
   2bbfa:	mov    %edi,%ebx
   2bbfc:	and    $0xffffff,%ebx
   2bc02:	cmp    $0x1,%ebx
   2bc05:	jne    30540 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5580>
   2bc0b:	mov    (%r12,%rsi,8),%ebx
   2bc0f:	shl    $0x20,%rcx
   2bc13:	or     %rdi,%rcx
   2bc16:	shr    $0x18,%rcx
   2bc1a:	mov    (%r12,%rcx,8),%rbp
   2bc1e:	mov    0x8(%r12,%rcx,8),%rdi
   2bc23:	mov    %rdi,0x8(%rsp)
   2bc28:	mov    0x0(%r13),%rdi
   2bc2c:	mov    %rdi,(%r12,%rsi,8)
   2bc30:	mov    %rsi,0x0(%r13)
   2bc34:	mov    0x100(%r13),%rsi
   2bc3b:	inc    %rsi
   2bc3e:	mov    %rsi,0x100(%r13)
   2bc45:	cmpb   $0x1,0x11dfc4(%rip)        # 149c10 <KEEP_WORDS>
   2bc4c:	jne    308bf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x58ff>
   2bc52:	cmp    $0x8000,%rsi
   2bc59:	jae    308bf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x58ff>
   2bc5f:	cmp    $0x3108280,%rcx
   2bc66:	jb     2bca0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xce0>
   2bc68:	mov    0x8(%r13),%rsi
   2bc6c:	mov    %rsi,(%r12,%rcx,8)
   2bc70:	mov    %rcx,0x8(%r13)
   2bc74:	mov    0x108(%r13),%rcx
   2bc7b:	add    $0x2,%rcx
   2bc7f:	mov    %rcx,0x108(%r13)
   2bc86:	cmpb   $0x1,0x11df83(%rip)        # 149c10 <KEEP_WORDS>
   2bc8d:	jne    30268 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x52a8>
   2bc93:	cmp    $0x8000,%rcx
   2bc9a:	jae    30268 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x52a8>
   2bca0:	and    %rdx,%rax
   2bca3:	movabs $0x80000000000,%rcx
   2bcad:	cmp    %rcx,%rax
   2bcb0:	jne    318d0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6910>
   2bcb6:	mov    %rdx,%rsi
   2bcb9:	and    %r8,%rsi
   2bcbc:	test   %rdx,%rdx
   2bcbf:	js     2cf0d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1f4d>
   2bcc5:	mov    (%r12,%rsi,8),%rdi
   2bcc9:	mov    0x8(%r12,%rsi,8),%rax
   2bcce:	mov    %rsi,%rcx
   2bcd1:	cmp    $0x3108280,%rcx
   2bcd8:	jae    2cf85 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1fc5>
   2bcde:	jmpq   2cfbd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ffd>
   2bce3:	mov    %rdx,%r9
   2bce6:	mov    0x4(%r12,%rsi,8),%ecx
   2bceb:	mov    (%r12,%rsi,8),%edx
   2bcef:	mov    %edx,%edi
   2bcf1:	and    $0xffffff,%edi
   2bcf7:	cmp    $0x1,%edi
   2bcfa:	jne    3058a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x55ca>
   2bd00:	mov    (%r12,%rsi,8),%edi
   2bd04:	shl    $0x20,%rcx
   2bd08:	or     %rdx,%rcx
   2bd0b:	shr    $0x18,%rcx
   2bd0f:	mov    (%r12,%rcx,8),%rbx
   2bd13:	mov    0x8(%r12,%rcx,8),%rdi
   2bd18:	mov    0x10(%r12,%rcx,8),%rdx
   2bd1d:	mov    %rdx,0x8(%rsp)
   2bd22:	mov    0x0(%r13),%rdx
   2bd26:	mov    %rdx,(%r12,%rsi,8)
   2bd2a:	mov    %rsi,0x0(%r13)
   2bd2e:	mov    0x100(%r13),%rdx
   2bd35:	inc    %rdx
   2bd38:	mov    %rdx,0x100(%r13)
   2bd3f:	cmpb   $0x1,0x11deca(%rip)        # 149c10 <KEEP_WORDS>
   2bd46:	jne    308f0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5930>
   2bd4c:	cmp    $0x8000,%rdx
   2bd53:	jae    308f0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5930>
   2bd59:	mov    %r9,%rdx
   2bd5c:	cmp    $0x3108280,%rcx
   2bd63:	jb     2bd9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xddd>
   2bd65:	mov    0x10(%r13),%rsi
   2bd69:	mov    %rsi,(%r12,%rcx,8)
   2bd6d:	mov    %rcx,0x10(%r13)
   2bd71:	mov    0x110(%r13),%rcx
   2bd78:	add    $0x4,%rcx
   2bd7c:	mov    %rcx,0x110(%r13)
   2bd83:	cmpb   $0x1,0x11de86(%rip)        # 149c10 <KEEP_WORDS>
   2bd8a:	jne    3028f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x52cf>
   2bd90:	cmp    $0x8000,%rcx
   2bd97:	jae    3028f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x52cf>
   2bd9d:	and    %rdx,%rax
   2bda0:	movabs $0x80000000000,%rcx
   2bdaa:	cmp    %rcx,%rax
   2bdad:	jne    319d2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6a12>
   2bdb3:	mov    %rdx,%rsi
   2bdb6:	and    %r8,%rsi
   2bdb9:	test   %rdx,%rdx
   2bdbc:	js     2d421 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2461>
   2bdc2:	mov    (%r12,%rsi,8),%rbp
   2bdc6:	mov    0x8(%r12,%rsi,8),%rax
   2bdcb:	mov    %rsi,%rcx
   2bdce:	cmp    $0x3108280,%rcx
   2bdd5:	jae    2d49f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x24df>
   2bddb:	jmpq   2d4d7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2517>
   2bde0:	mov    0x4(%r12,%r8,8),%ecx
   2bde5:	mov    (%r12,%r8,8),%eax
   2bde9:	mov    %eax,%esi
   2bdeb:	and    $0xffffff,%esi
   2bdf1:	cmp    $0x1,%esi
   2bdf4:	jne    305e3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5623>
   2bdfa:	mov    (%r12,%r8,8),%edx
   2bdfe:	shl    $0x20,%rcx
   2be02:	or     %rax,%rcx
   2be05:	shr    $0x18,%rcx
   2be09:	mov    (%r12,%rcx,8),%rax
   2be0d:	mov    %rax,0x18(%rsp)
   2be12:	mov    0x8(%r12,%rcx,8),%rax
   2be17:	mov    0x0(%r13),%rdx
   2be1b:	mov    %rdx,(%r12,%r8,8)
   2be1f:	mov    %r8,0x0(%r13)
   2be23:	mov    0x100(%r13),%rdx
   2be2a:	inc    %rdx
   2be2d:	mov    %rdx,0x100(%r13)
   2be34:	cmpb   $0x1,0x11ddd5(%rip)        # 149c10 <KEEP_WORDS>
   2be3b:	jne    3092a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x596a>
   2be41:	cmp    $0x8000,%rdx
   2be48:	jae    3092a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x596a>
   2be4e:	cmp    $0x3108280,%rcx
   2be55:	jb     2be8f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xecf>
   2be57:	mov    0x8(%r13),%rdx
   2be5b:	mov    %rdx,(%r12,%rcx,8)
   2be5f:	mov    %rcx,0x8(%r13)
   2be63:	mov    0x108(%r13),%rcx
   2be6a:	add    $0x2,%rcx
   2be6e:	mov    %rcx,0x108(%r13)
   2be75:	cmpb   $0x1,0x11dd94(%rip)        # 149c10 <KEEP_WORDS>
   2be7c:	jne    302bc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x52fc>
   2be82:	cmp    $0x8000,%rcx
   2be89:	jae    302bc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x52fc>
   2be8f:	cmp    $0x1,%rax
   2be93:	mov    %r11,0x38(%rsp)
   2be98:	je     2c0bc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10fc>
   2be9e:	movabs $0x7fffff0000000000,%rcx
   2bea8:	and    %rcx,%rax
   2beab:	movabs $0x100020000000000,%rcx
   2beb5:	cmp    %rcx,%rax
   2beb8:	je     2c0bc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10fc>
   2bebe:	mov    %r9,%r14
   2bec1:	mov    %r12,%rdi
   2bec4:	mov    %r13,%rsi
   2bec7:	mov    %rbp,%rdx
   2beca:	callq  43610 <term_keep>
   2becf:	mov    %rax,%r15
   2bed2:	mov    0x8(%r13),%r10
   2bed6:	test   %r10,%r10
   2bed9:	je     2ee59 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3e99>
   2bedf:	mov    (%r12,%r10,8),%rax
   2bee3:	mov    %rax,0x8(%r13)
   2bee7:	addq   $0xfffffffffffffffe,0x108(%r13)
   2beef:	mov    0x8(%rsp),%rcx
   2bef4:	mov    %r14,%r9
   2bef7:	movabs $0xff00000000000000,%r14
   2bf01:	mov    %r15,%r8
   2bf04:	and    %r14,%r8
   2bf07:	movabs $0x200000000000000,%rsi
   2bf11:	mov    %r15,%rax
   2bf14:	cmp    %rsi,%r8
   2bf17:	mov    0x38(%rsp),%rdx
   2bf1c:	je     2ee71 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3eb1>
   2bf22:	mov    %rax,(%r12,%r10,8)
   2bf26:	mov    %rbx,%rax
   2bf29:	and    %r14,%rax
   2bf2c:	cmp    %rsi,%rax
   2bf2f:	je     2ee99 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ed9>
   2bf35:	mov    %rbx,0x8(%r12,%r10,8)
   2bf3a:	mov    0x8(%r13),%rbx
   2bf3e:	test   %rbx,%rbx
   2bf41:	je     2eed1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3f11>
   2bf47:	mov    (%r12,%rbx,8),%rax
   2bf4b:	mov    %rax,0x8(%r13)
   2bf4f:	addq   $0xfffffffffffffffe,0x108(%r13)
   2bf57:	mov    %r9,%rax
   2bf5a:	and    %r14,%rax
   2bf5d:	cmp    %rsi,%rax
   2bf60:	je     2eefe <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3f3e>
   2bf66:	mov    %r9,(%r12,%rbx,8)
   2bf6a:	mov    %rcx,%rax
   2bf6d:	and    %r14,%rax
   2bf70:	cmp    %rsi,%rax
   2bf73:	je     2ef29 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3f69>
   2bf79:	movabs $0x2002c0000000000,%rbp
   2bf83:	mov    %rcx,0x8(%r12,%rbx,8)
   2bf88:	mov    0x10(%r13),%r9
   2bf8c:	test   %r9,%r9
   2bf8f:	je     2ef4f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3f8f>
   2bf95:	mov    (%r12,%r9,8),%rax
   2bf99:	mov    %rax,0x10(%r13)
   2bf9d:	addq   $0xfffffffffffffffc,0x110(%r13)
   2bfa5:	or     %rbp,%r10
   2bfa8:	mov    %rdx,%rax
   2bfab:	and    %r14,%rax
   2bfae:	cmp    %rsi,%rax
   2bfb1:	je     2ef72 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3fb2>
   2bfb7:	or     %rbp,%rbx
   2bfba:	movabs $0x300000000000000,%rbp
   2bfc4:	mov    %rdx,(%r12,%r9,8)
   2bfc8:	mov    %r10,%rax
   2bfcb:	shr    $0x38,%rax
   2bfcf:	cmp    $0x2,%eax
   2bfd2:	jbe    2ef94 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3fd4>
   2bfd8:	mov    %r10,0x8(%r12,%r9,8)
   2bfdd:	cmp    %rbp,%rbx
   2bfe0:	jb     2efc8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4008>
   2bfe6:	mov    %rbx,0x10(%r12,%r9,8)
   2bfeb:	mov    0x0(%r13),%r10
   2bfef:	test   %r10,%r10
   2bff2:	je     2eff6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4036>
   2bff8:	mov    (%r12,%r10,8),%rax
   2bffc:	mov    %rax,0x0(%r13)
   2c000:	decq   0x100(%r13)
   2c007:	cmp    %rsi,%r8
   2c00a:	je     2f015 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4055>
   2c010:	mov    %r15,(%r12,%r10,8)
   2c014:	movabs $0x2000c0000000000,%rcx
   2c01e:	mov    0x8(%r13),%r8
   2c022:	test   %r8,%r8
   2c025:	je     2f036 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4076>
   2c02b:	mov    (%r12,%r8,8),%rax
   2c02f:	mov    %rax,0x8(%r13)
   2c033:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c03b:	mov    0x18(%rsp),%rax
   2c040:	or     %rcx,%r10
   2c043:	and    %rax,%r14
   2c046:	cmp    %rsi,%r14
   2c049:	je     2f054 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4094>
   2c04f:	mov    (%rsp),%r14
   2c053:	movabs $0x2002d0000000000,%rbx
   2c05d:	mov    %rax,(%r12,%r8,8)
   2c061:	cmp    %rbp,%r10
   2c064:	jb     2f06c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x40ac>
   2c06a:	or     %rbx,%r9
   2c06d:	movabs $0x200080000000000,%rsi
   2c077:	mov    %r10,0x8(%r12,%r8,8)
   2c07c:	mov    0x8(%r13),%r10
   2c080:	test   %r10,%r10
   2c083:	je     2f087 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x40c7>
   2c089:	mov    (%r12,%r10,8),%rax
   2c08d:	mov    %rax,0x8(%r13)
   2c091:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c099:	or     %rsi,%r8
   2c09c:	cmp    %rbp,%r9
   2c09f:	jb     2f0ac <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x40ec>
   2c0a5:	mov    %r9,(%r12,%r10,8)
   2c0a9:	cmp    %rbp,%r8
   2c0ac:	jb     2c5af <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15ef>
   2c0b2:	mov    %r8,0x8(%r12,%r10,8)
   2c0b7:	jmpq   2c2bd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x12fd>
   2c0bc:	mov    %rbp,%r8
   2c0bf:	mov    0x8(%r13),%rbp
   2c0c3:	test   %rbp,%rbp
   2c0c6:	je     2e639 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3679>
   2c0cc:	mov    (%r12,%rbp,8),%rax
   2c0d0:	mov    %rax,0x8(%r13)
   2c0d4:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c0dc:	movabs $0xff00000000000000,%r14
   2c0e6:	mov    %r8,%rax
   2c0e9:	shr    $0x38,%rax
   2c0ed:	cmp    $0x2,%eax
   2c0f0:	je     2e651 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3691>
   2c0f6:	mov    %r8,(%r12,%rbp,8)
   2c0fa:	mov    %rbx,%rax
   2c0fd:	and    %r14,%rax
   2c100:	movabs $0x200000000000000,%rcx
   2c10a:	cmp    %rcx,%rax
   2c10d:	je     2e66c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x36ac>
   2c113:	mov    %rbx,0x8(%r12,%rbp,8)
   2c118:	mov    %r12,%rdi
   2c11b:	mov    %r13,%rsi
   2c11e:	mov    %r9,%rdx
   2c121:	callq  43610 <term_keep>
   2c126:	mov    %rax,%r15
   2c129:	mov    0x8(%r13),%r10
   2c12d:	test   %r10,%r10
   2c130:	je     2e687 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x36c7>
   2c136:	mov    (%r12,%r10,8),%rax
   2c13a:	mov    %rax,0x8(%r13)
   2c13e:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c146:	mov    0x8(%rsp),%rcx
   2c14b:	mov    %r15,%r9
   2c14e:	and    %r14,%r9
   2c151:	mov    %r15,%rax
   2c154:	movabs $0x200000000000000,%rsi
   2c15e:	cmp    %rsi,%r9
   2c161:	mov    0x38(%rsp),%rdx
   2c166:	je     2e69f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x36df>
   2c16c:	mov    %rax,(%r12,%r10,8)
   2c170:	mov    %rcx,%rax
   2c173:	and    %r14,%rax
   2c176:	cmp    %rsi,%rax
   2c179:	je     2e6cb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x370b>
   2c17f:	movabs $0x2002c0000000000,%rbx
   2c189:	mov    %rcx,0x8(%r12,%r10,8)
   2c18e:	mov    0x10(%r13),%r8
   2c192:	test   %r8,%r8
   2c195:	je     2e6f5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3735>
   2c19b:	mov    (%r12,%r8,8),%rax
   2c19f:	mov    %rax,0x10(%r13)
   2c1a3:	addq   $0xfffffffffffffffc,0x110(%r13)
   2c1ab:	or     %rbx,%rbp
   2c1ae:	mov    %rdx,%rax
   2c1b1:	and    %r14,%rax
   2c1b4:	cmp    %rsi,%rax
   2c1b7:	je     2e71c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x375c>
   2c1bd:	or     %rbx,%r10
   2c1c0:	movabs $0x300000000000000,%rdi
   2c1ca:	mov    %rdx,(%r12,%r8,8)
   2c1ce:	mov    %rbp,%rax
   2c1d1:	shr    $0x38,%rax
   2c1d5:	cmp    $0x2,%eax
   2c1d8:	jbe    2e73e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x377e>
   2c1de:	mov    %rbp,0x8(%r12,%r8,8)
   2c1e3:	cmp    %rdi,%r10
   2c1e6:	jb     2e772 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x37b2>
   2c1ec:	mov    %r10,0x10(%r12,%r8,8)
   2c1f1:	mov    0x0(%r13),%r10
   2c1f5:	test   %r10,%r10
   2c1f8:	je     2e7aa <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x37ea>
   2c1fe:	mov    (%r12,%r10,8),%rax
   2c202:	mov    %rax,0x0(%r13)
   2c206:	decq   0x100(%r13)
   2c20d:	cmp    %rsi,%r9
   2c210:	je     2e7d3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3813>
   2c216:	mov    %r15,(%r12,%r10,8)
   2c21a:	movabs $0x2000c0000000000,%rcx
   2c224:	mov    0x8(%r13),%r9
   2c228:	test   %r9,%r9
   2c22b:	je     2e7fe <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x383e>
   2c231:	mov    (%r12,%r9,8),%rax
   2c235:	mov    %rax,0x8(%r13)
   2c239:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c241:	mov    0x18(%rsp),%rax
   2c246:	or     %rcx,%r10
   2c249:	and    %rax,%r14
   2c24c:	cmp    %rsi,%r14
   2c24f:	je     2e826 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3866>
   2c255:	mov    (%rsp),%r14
   2c259:	movabs $0x2002d0000000000,%rbx
   2c263:	mov    %rax,(%r12,%r9,8)
   2c267:	cmp    %rdi,%r10
   2c26a:	jb     2e844 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3884>
   2c270:	or     %rbx,%r8
   2c273:	movabs $0x200080000000000,%rsi
   2c27d:	mov    %r10,0x8(%r12,%r9,8)
   2c282:	mov    0x8(%r13),%r10
   2c286:	test   %r10,%r10
   2c289:	je     2e865 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x38a5>
   2c28f:	mov    (%r12,%r10,8),%rax
   2c293:	mov    %rax,0x8(%r13)
   2c297:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c29f:	or     %rsi,%r9
   2c2a2:	cmp    %rdi,%r8
   2c2a5:	jb     2e890 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x38d0>
   2c2ab:	mov    %r8,(%r12,%r10,8)
   2c2af:	cmp    %rdi,%r9
   2c2b2:	jb     2c9f0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a30>
   2c2b8:	mov    %r9,0x8(%r12,%r10,8)
   2c2bd:	or     %r10,%rsi
   2c2c0:	jmpq   2e13d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x317d>
   2c2c5:	mov    0x4(%r12,%r8,8),%ecx
   2c2ca:	mov    (%r12,%r8,8),%eax
   2c2ce:	mov    %eax,%esi
   2c2d0:	and    $0xffffff,%esi
   2c2d6:	cmp    $0x1,%esi
   2c2d9:	jne    3061e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x565e>
   2c2df:	mov    (%r12,%r8,8),%edx
   2c2e3:	shl    $0x20,%rcx
   2c2e7:	or     %rax,%rcx
   2c2ea:	shr    $0x18,%rcx
   2c2ee:	mov    (%r12,%rcx,8),%rax
   2c2f2:	mov    %rax,0x20(%rsp)
   2c2f7:	mov    0x8(%r12,%rcx,8),%rax
   2c2fc:	mov    0x0(%r13),%rdx
   2c300:	mov    %rdx,(%r12,%r8,8)
   2c304:	mov    %r8,0x0(%r13)
   2c308:	mov    0x100(%r13),%rdx
   2c30f:	inc    %rdx
   2c312:	mov    %rdx,0x100(%r13)
   2c319:	cmpb   $0x1,0x11d8f0(%rip)        # 149c10 <KEEP_WORDS>
   2c320:	jne    3094f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x598f>
   2c326:	cmp    $0x8000,%rdx
   2c32d:	jae    3094f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x598f>
   2c333:	cmp    $0x3108280,%rcx
   2c33a:	jb     2c374 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x13b4>
   2c33c:	mov    0x8(%r13),%rdx
   2c340:	mov    %rdx,(%r12,%rcx,8)
   2c344:	mov    %rcx,0x8(%r13)
   2c348:	mov    0x108(%r13),%rcx
   2c34f:	add    $0x2,%rcx
   2c353:	mov    %rcx,0x108(%r13)
   2c35a:	cmpb   $0x1,0x11d8af(%rip)        # 149c10 <KEEP_WORDS>
   2c361:	jne    302d7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5317>
   2c367:	cmp    $0x8000,%rcx
   2c36e:	jae    302d7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5317>
   2c374:	cmp    $0x1,%rax
   2c378:	je     2c5d0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1610>
   2c37e:	movabs $0x7fffff0000000000,%rcx
   2c388:	and    %rcx,%rax
   2c38b:	movabs $0x100020000000000,%rcx
   2c395:	cmp    %rcx,%rax
   2c398:	je     2c5d0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1610>
   2c39e:	mov    %r11,0x38(%rsp)
   2c3a3:	mov    %r12,%rdi
   2c3a6:	mov    %r13,%rsi
   2c3a9:	mov    %rbp,%rdx
   2c3ac:	callq  43610 <term_keep>
   2c3b1:	mov    %rax,%r8
   2c3b4:	mov    0x8(%r13),%r10
   2c3b8:	test   %r10,%r10
   2c3bb:	je     2f223 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4263>
   2c3c1:	mov    (%r12,%r10,8),%rax
   2c3c5:	mov    %rax,0x8(%r13)
   2c3c9:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c3d1:	mov    0x18(%rsp),%rcx
   2c3d6:	movabs $0xff00000000000000,%r14
   2c3e0:	mov    %r8,%rbp
   2c3e3:	and    %r14,%rbp
   2c3e6:	movabs $0x200000000000000,%r15
   2c3f0:	mov    %r8,%rax
   2c3f3:	cmp    %r15,%rbp
   2c3f6:	mov    0x38(%rsp),%rdx
   2c3fb:	mov    0x8(%rsp),%r9
   2c400:	mov    0x10(%rsp),%r11
   2c405:	je     2f23b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x427b>
   2c40b:	mov    %rax,(%r12,%r10,8)
   2c40f:	mov    %rbx,%rax
   2c412:	and    %r14,%rax
   2c415:	cmp    %r15,%rax
   2c418:	je     2f267 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x42a7>
   2c41e:	mov    %rbx,0x8(%r12,%r10,8)
   2c423:	mov    0x10(%r13),%rbx
   2c427:	test   %rbx,%rbx
   2c42a:	je     2f2a3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x42e3>
   2c430:	mov    (%r12,%rbx,8),%rax
   2c434:	mov    %rax,0x10(%r13)
   2c438:	addq   $0xfffffffffffffffc,0x110(%r13)
   2c440:	mov    %r11,%rax
   2c443:	and    %r14,%rax
   2c446:	cmp    %r15,%rax
   2c449:	je     2f2d4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4314>
   2c44f:	mov    %r11,(%r12,%rbx,8)
   2c453:	mov    %rcx,%rax
   2c456:	and    %r14,%rax
   2c459:	cmp    %r15,%rax
   2c45c:	je     2f2fe <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x433e>
   2c462:	mov    %rcx,0x8(%r12,%rbx,8)
   2c467:	mov    %r9,%rax
   2c46a:	and    %r14,%rax
   2c46d:	cmp    %r15,%rax
   2c470:	je     2f323 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4363>
   2c476:	movabs $0x2002c0000000000,%rcx
   2c480:	mov    %r9,0x10(%r12,%rbx,8)
   2c485:	mov    0x10(%r13),%r9
   2c489:	test   %r9,%r9
   2c48c:	je     2f343 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4383>
   2c492:	mov    (%r12,%r9,8),%rax
   2c496:	mov    %rax,0x10(%r13)
   2c49a:	addq   $0xfffffffffffffffc,0x110(%r13)
   2c4a2:	movabs $0x2002d0000000000,%rsi
   2c4ac:	or     %rcx,%r10
   2c4af:	mov    %rdx,%rax
   2c4b2:	and    %r14,%rax
   2c4b5:	cmp    %r15,%rax
   2c4b8:	je     2f360 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x43a0>
   2c4be:	or     %rsi,%rbx
   2c4c1:	movabs $0x300000000000000,%rdi
   2c4cb:	mov    %rdx,(%r12,%r9,8)
   2c4cf:	mov    %r10,%rax
   2c4d2:	shr    $0x38,%rax
   2c4d6:	cmp    $0x2,%eax
   2c4d9:	jbe    2f382 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x43c2>
   2c4df:	mov    %r10,0x8(%r12,%r9,8)
   2c4e4:	cmp    %rdi,%rbx
   2c4e7:	jb     2f3ba <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x43fa>
   2c4ed:	mov    %rbx,0x10(%r12,%r9,8)
   2c4f2:	mov    0x0(%r13),%r10
   2c4f6:	test   %r10,%r10
   2c4f9:	je     2f3f2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4432>
   2c4ff:	mov    (%r12,%r10,8),%rax
   2c503:	mov    %rax,0x0(%r13)
   2c507:	decq   0x100(%r13)
   2c50e:	mov    0x20(%rsp),%rbx
   2c513:	cmp    %r15,%rbp
   2c516:	je     2f41c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x445c>
   2c51c:	mov    %r8,(%r12,%r10,8)
   2c520:	movabs $0x2000c0000000000,%rcx
   2c52a:	mov    0x8(%r13),%r8
   2c52e:	test   %r8,%r8
   2c531:	je     2f447 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4487>
   2c537:	mov    (%r12,%r8,8),%rax
   2c53b:	mov    %rax,0x8(%r13)
   2c53f:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c547:	or     %rcx,%r10
   2c54a:	and    %rbx,%r14
   2c54d:	cmp    %r15,%r14
   2c550:	je     2f475 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x44b5>
   2c556:	mov    (%rsp),%r14
   2c55a:	mov    %rbx,(%r12,%r8,8)
   2c55e:	cmp    %rdi,%r10
   2c561:	jb     2f4a8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x44e8>
   2c567:	or     %rsi,%r9
   2c56a:	movabs $0x200080000000000,%rsi
   2c574:	mov    %r10,0x8(%r12,%r8,8)
   2c579:	mov    0x8(%r13),%r10
   2c57d:	test   %r10,%r10
   2c580:	je     2f4cf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x450f>
   2c586:	mov    (%r12,%r10,8),%rax
   2c58a:	mov    %rax,0x8(%r13)
   2c58e:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c596:	or     %rsi,%r8
   2c599:	cmp    %rdi,%r9
   2c59c:	jb     2f4fa <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x453a>
   2c5a2:	mov    %r9,(%r12,%r10,8)
   2c5a6:	cmp    %rdi,%r8
   2c5a9:	jae    2c0b2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10f2>
   2c5af:	mov    %r12,%rdi
   2c5b2:	mov    %rsi,%r9
   2c5b5:	mov    %r13,%rsi
   2c5b8:	mov    %r8,%rdx
   2c5bb:	mov    $0x1,%ecx
   2c5c0:	callq  4574e <rfc_wrap>
   2c5c5:	mov    %r9,%rsi
   2c5c8:	mov    %rax,%r8
   2c5cb:	jmpq   2c0b2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10f2>
   2c5d0:	mov    0x8(%r13),%r8
   2c5d4:	test   %r8,%r8
   2c5d7:	je     2e8c4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3904>
   2c5dd:	mov    (%r12,%r8,8),%rax
   2c5e1:	mov    %rax,0x8(%r13)
   2c5e5:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c5ed:	movabs $0xff00000000000000,%r14
   2c5f7:	mov    %rbp,%rax
   2c5fa:	shr    $0x38,%rax
   2c5fe:	cmp    $0x2,%eax
   2c601:	je     2e8e2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3922>
   2c607:	mov    %rbp,(%r12,%r8,8)
   2c60b:	mov    %rbx,%rax
   2c60e:	and    %r14,%rax
   2c611:	movabs $0x200000000000000,%rbp
   2c61b:	cmp    %rbp,%rax
   2c61e:	je     2e903 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3943>
   2c624:	mov    %rbx,0x8(%r12,%r8,8)
   2c629:	movabs $0x2002c0000000000,%rbx
   2c633:	or     %r8,%rbx
   2c636:	test   %r15d,%r15d
   2c639:	je     2d93f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x297f>
   2c63f:	mov    (%rsp),%rax
   2c643:	mov    %r11,(%rax)
   2c646:	mov    %rbx,0x8(%rax)
   2c64a:	movq   $0x13e,0x10(%rax)
   2c652:	add    $0x18,%rax
   2c656:	mov    %rax,(%rsp)
   2c65a:	jmpq   2d990 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x29d0>
   2c65f:	mov    %r9,%r14
   2c662:	mov    %r11,%r9
   2c665:	mov    0x4(%r12,%r8,8),%ecx
   2c66a:	mov    (%r12,%r8,8),%eax
   2c66e:	mov    %eax,%esi
   2c670:	and    $0xffffff,%esi
   2c676:	cmp    $0x1,%esi
   2c679:	jne    30653 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5693>
   2c67f:	mov    (%r12,%r8,8),%edx
   2c683:	shl    $0x20,%rcx
   2c687:	or     %rax,%rcx
   2c68a:	shr    $0x18,%rcx
   2c68e:	mov    (%r12,%rcx,8),%r10
   2c692:	mov    0x8(%r12,%rcx,8),%rax
   2c697:	mov    0x0(%r13),%rdx
   2c69b:	mov    %rdx,(%r12,%r8,8)
   2c69f:	mov    %r8,0x0(%r13)
   2c6a3:	mov    0x100(%r13),%rdx
   2c6aa:	inc    %rdx
   2c6ad:	mov    %rdx,0x100(%r13)
   2c6b4:	cmpb   $0x1,0x11d555(%rip)        # 149c10 <KEEP_WORDS>
   2c6bb:	jne    30974 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x59b4>
   2c6c1:	cmp    $0x8000,%rdx
   2c6c8:	jae    30974 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x59b4>
   2c6ce:	mov    %r9,%r11
   2c6d1:	mov    %r14,%r9
   2c6d4:	cmp    $0x3108280,%rcx
   2c6db:	jb     2c715 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1755>
   2c6dd:	mov    0x8(%r13),%rdx
   2c6e1:	mov    %rdx,(%r12,%rcx,8)
   2c6e5:	mov    %rcx,0x8(%r13)
   2c6e9:	mov    0x108(%r13),%rcx
   2c6f0:	add    $0x2,%rcx
   2c6f4:	mov    %rcx,0x108(%r13)
   2c6fb:	cmpb   $0x1,0x11d50e(%rip)        # 149c10 <KEEP_WORDS>
   2c702:	jne    302f2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5332>
   2c708:	cmp    $0x8000,%rcx
   2c70f:	jae    302f2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5332>
   2c715:	cmp    $0x1,%rax
   2c719:	mov    %r10,0x20(%rsp)
   2c71e:	je     2c7d8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1818>
   2c724:	movabs $0x7fffff0000000000,%rcx
   2c72e:	and    %rcx,%rax
   2c731:	movabs $0x100020000000000,%rcx
   2c73b:	cmp    %rcx,%rax
   2c73e:	je     2c7d8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1818>
   2c744:	mov    0x8(%r13),%r8
   2c748:	test   %r8,%r8
   2c74b:	mov    0x10(%rsp),%rdx
   2c750:	je     2f52e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x456e>
   2c756:	mov    (%r12,%r8,8),%rax
   2c75a:	mov    %rax,0x8(%r13)
   2c75e:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c766:	movabs $0xff00000000000000,%r14
   2c770:	mov    %r9,%rax
   2c773:	shr    $0x38,%rax
   2c777:	cmp    $0x2,%eax
   2c77a:	je     2f551 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4591>
   2c780:	mov    %r9,(%r12,%r8,8)
   2c784:	mov    %rdx,%rax
   2c787:	and    %r14,%rax
   2c78a:	movabs $0x200000000000000,%rcx
   2c794:	cmp    %rcx,%rax
   2c797:	je     2f577 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x45b7>
   2c79d:	mov    %rdx,0x8(%r12,%r8,8)
   2c7a2:	movabs $0x2002c0000000000,%rbp
   2c7ac:	or     %r8,%rbp
   2c7af:	test   %r15d,%r15d
   2c7b2:	je     2dcfa <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2d3a>
   2c7b8:	mov    (%rsp),%rax
   2c7bc:	mov    %r11,(%rax)
   2c7bf:	mov    %rbp,0x8(%rax)
   2c7c3:	movq   $0x148,0x10(%rax)
   2c7cb:	add    $0x18,%rax
   2c7cf:	mov    %rax,(%rsp)
   2c7d3:	jmpq   2dd4b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2d8b>
   2c7d8:	mov    0x10(%r13),%rbp
   2c7dc:	test   %rbp,%rbp
   2c7df:	je     2e924 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3964>
   2c7e5:	mov    (%r12,%rbp,8),%rax
   2c7e9:	mov    %rax,0x10(%r13)
   2c7ed:	addq   $0xfffffffffffffffc,0x110(%r13)
   2c7f5:	movabs $0xff00000000000000,%r14
   2c7ff:	mov    %rbx,%rax
   2c802:	shr    $0x38,%rax
   2c806:	cmp    $0x2,%eax
   2c809:	mov    0x8(%rsp),%rdx
   2c80e:	mov    0x18(%rsp),%rcx
   2c813:	je     2e942 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3982>
   2c819:	mov    %rbx,(%r12,%rbp,8)
   2c81d:	mov    %rcx,%rax
   2c820:	and    %r14,%rax
   2c823:	movabs $0x200000000000000,%rsi
   2c82d:	cmp    %rsi,%rax
   2c830:	je     2e96d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x39ad>
   2c836:	mov    %r11,%rbx
   2c839:	mov    %rcx,0x8(%r12,%rbp,8)
   2c83e:	mov    %rdx,%rax
   2c841:	and    %r14,%rax
   2c844:	cmp    %rsi,%rax
   2c847:	je     2e999 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x39d9>
   2c84d:	mov    %rdx,0x10(%r12,%rbp,8)
   2c852:	mov    %r12,%rdi
   2c855:	mov    %r13,%rsi
   2c858:	mov    %r9,%rdx
   2c85b:	callq  43610 <term_keep>
   2c860:	mov    %rax,%r15
   2c863:	mov    0x8(%r13),%r10
   2c867:	test   %r10,%r10
   2c86a:	je     2e9b1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x39f1>
   2c870:	mov    (%r12,%r10,8),%rax
   2c874:	mov    %rax,0x8(%r13)
   2c878:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c880:	mov    0x10(%rsp),%rcx
   2c885:	mov    %r15,%r9
   2c888:	and    %r14,%r9
   2c88b:	mov    %r15,%rax
   2c88e:	movabs $0x200000000000000,%rsi
   2c898:	cmp    %rsi,%r9
   2c89b:	mov    %rbx,%rdx
   2c89e:	je     2e9c9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3a09>
   2c8a4:	mov    %rax,(%r12,%r10,8)
   2c8a8:	mov    %rcx,%rax
   2c8ab:	and    %r14,%rax
   2c8ae:	cmp    %rsi,%rax
   2c8b1:	je     2e9f3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3a33>
   2c8b7:	movabs $0x2002d0000000000,%rdi
   2c8c1:	mov    %rcx,0x8(%r12,%r10,8)
   2c8c6:	mov    0x10(%r13),%r8
   2c8ca:	test   %r8,%r8
   2c8cd:	je     2ea1b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3a5b>
   2c8d3:	mov    (%r12,%r8,8),%rax
   2c8d7:	mov    %rax,0x10(%r13)
   2c8db:	addq   $0xfffffffffffffffc,0x110(%r13)
   2c8e3:	movabs $0x2002c0000000000,%rbx
   2c8ed:	or     %rdi,%rbp
   2c8f0:	mov    %rdx,%rax
   2c8f3:	and    %r14,%rax
   2c8f6:	cmp    %rsi,%rax
   2c8f9:	je     2ea46 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3a86>
   2c8ff:	or     %rbx,%r10
   2c902:	movabs $0x300000000000000,%r11
   2c90c:	mov    %rdx,(%r12,%r8,8)
   2c910:	mov    %rbp,%rax
   2c913:	shr    $0x38,%rax
   2c917:	cmp    $0x2,%eax
   2c91a:	jbe    2ea72 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ab2>
   2c920:	mov    %rbp,0x8(%r12,%r8,8)
   2c925:	cmp    %r11,%r10
   2c928:	jb     2eaac <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3aec>
   2c92e:	mov    0x20(%rsp),%rbx
   2c933:	mov    %r10,0x10(%r12,%r8,8)
   2c938:	mov    0x0(%r13),%r10
   2c93c:	test   %r10,%r10
   2c93f:	je     2eadd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3b1d>
   2c945:	mov    (%r12,%r10,8),%rax
   2c949:	mov    %rax,0x0(%r13)
   2c94d:	decq   0x100(%r13)
   2c954:	cmp    %rsi,%r9
   2c957:	je     2eb0c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3b4c>
   2c95d:	mov    %r15,(%r12,%r10,8)
   2c961:	movabs $0x2000c0000000000,%rcx
   2c96b:	mov    0x8(%r13),%r9
   2c96f:	test   %r9,%r9
   2c972:	je     2eb3d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3b7d>
   2c978:	mov    (%r12,%r9,8),%rax
   2c97c:	mov    %rax,0x8(%r13)
   2c980:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c988:	or     %rcx,%r10
   2c98b:	and    %rbx,%r14
   2c98e:	cmp    %rsi,%r14
   2c991:	je     2eb75 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3bb5>
   2c997:	mov    (%rsp),%r14
   2c99b:	mov    %rbx,(%r12,%r9,8)
   2c99f:	cmp    %r11,%r10
   2c9a2:	jb     2eba8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3be8>
   2c9a8:	or     %rdi,%r8
   2c9ab:	movabs $0x200080000000000,%rsi
   2c9b5:	mov    %r10,0x8(%r12,%r9,8)
   2c9ba:	mov    0x8(%r13),%r10
   2c9be:	test   %r10,%r10
   2c9c1:	je     2ebcf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3c0f>
   2c9c7:	mov    (%r12,%r10,8),%rax
   2c9cb:	mov    %rax,0x8(%r13)
   2c9cf:	addq   $0xfffffffffffffffe,0x108(%r13)
   2c9d7:	or     %rsi,%r9
   2c9da:	cmp    %r11,%r8
   2c9dd:	jb     2ebfa <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3c3a>
   2c9e3:	mov    %r8,(%r12,%r10,8)
   2c9e7:	cmp    %r11,%r9
   2c9ea:	jae    2c2b8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x12f8>
   2c9f0:	mov    %r12,%rdi
   2c9f3:	mov    %rsi,%r8
   2c9f6:	mov    %r13,%rsi
   2c9f9:	mov    %r9,%rdx
   2c9fc:	mov    $0x1,%ecx
   2ca01:	callq  4574e <rfc_wrap>
   2ca06:	mov    %r8,%rsi
   2ca09:	mov    %rax,%r9
   2ca0c:	jmpq   2c2b8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x12f8>
   2ca11:	mov    %r9,%r14
   2ca14:	mov    %r11,%r9
   2ca17:	mov    0x4(%r12,%r8,8),%ecx
   2ca1c:	mov    (%r12,%r8,8),%eax
   2ca20:	mov    %eax,%esi
   2ca22:	and    $0xffffff,%esi
   2ca28:	cmp    $0x1,%esi
   2ca2b:	jne    30683 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x56c3>
   2ca31:	mov    (%r12,%r8,8),%edx
   2ca35:	shl    $0x20,%rcx
   2ca39:	or     %rax,%rcx
   2ca3c:	shr    $0x18,%rcx
   2ca40:	mov    (%r12,%rcx,8),%rax
   2ca44:	mov    %rax,0x20(%rsp)
   2ca49:	mov    0x8(%r12,%rcx,8),%rax
   2ca4e:	mov    0x0(%r13),%rdx
   2ca52:	mov    %rdx,(%r12,%r8,8)
   2ca56:	mov    %r8,0x0(%r13)
   2ca5a:	mov    0x100(%r13),%rdx
   2ca61:	inc    %rdx
   2ca64:	mov    %rdx,0x100(%r13)
   2ca6b:	cmpb   $0x1,0x11d19e(%rip)        # 149c10 <KEEP_WORDS>
   2ca72:	jne    30999 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x59d9>
   2ca78:	cmp    $0x8000,%rdx
   2ca7f:	jae    30999 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x59d9>
   2ca85:	mov    %r9,%r11
   2ca88:	mov    %r14,%r9
   2ca8b:	cmp    $0x3108280,%rcx
   2ca92:	jb     2cacc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b0c>
   2ca94:	mov    0x8(%r13),%rdx
   2ca98:	mov    %rdx,(%r12,%rcx,8)
   2ca9c:	mov    %rcx,0x8(%r13)
   2caa0:	mov    0x108(%r13),%rcx
   2caa7:	add    $0x2,%rcx
   2caab:	mov    %rcx,0x108(%r13)
   2cab2:	cmpb   $0x1,0x11d157(%rip)        # 149c10 <KEEP_WORDS>
   2cab9:	jne    3030d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x534d>
   2cabf:	cmp    $0x8000,%rcx
   2cac6:	jae    3030d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x534d>
   2cacc:	movabs $0xff00000000000000,%rbp
   2cad6:	movabs $0x2002d0000000000,%r10
   2cae0:	mov    0x10(%r13),%r14
   2cae4:	cmp    $0x1,%rax
   2cae8:	je     2cb9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1bdd>
   2caee:	movabs $0x7fffff0000000000,%rcx
   2caf8:	and    %rcx,%rax
   2cafb:	movabs $0x100020000000000,%rcx
   2cb05:	cmp    %rcx,%rax
   2cb08:	je     2cb9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1bdd>
   2cb0e:	test   %r14,%r14
   2cb11:	mov    0x10(%rsp),%rdx
   2cb16:	je     2f79d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x47dd>
   2cb1c:	mov    (%r12,%r14,8),%rax
   2cb20:	mov    %rax,0x10(%r13)
   2cb24:	addq   $0xfffffffffffffffc,0x110(%r13)
   2cb2c:	mov    %rdx,%rax
   2cb2f:	and    %rbp,%rax
   2cb32:	movabs $0x200000000000000,%rcx
   2cb3c:	cmp    %rcx,%rax
   2cb3f:	je     2f7c6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4806>
   2cb45:	mov    %rdx,(%r12,%r14,8)
   2cb49:	mov    %r9,%rax
   2cb4c:	and    %rbp,%rax
   2cb4f:	cmp    %rcx,%rax
   2cb52:	je     2f804 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4844>
   2cb58:	mov    %r9,0x8(%r12,%r14,8)
   2cb5d:	mov    %rdi,%rax
   2cb60:	and    %rbp,%rax
   2cb63:	cmp    %rcx,%rax
   2cb66:	je     2f835 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4875>
   2cb6c:	mov    %rdi,0x10(%r12,%r14,8)
   2cb71:	or     %r10,%r14
   2cb74:	test   %r15d,%r15d
   2cb77:	je     2f862 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x48a2>
   2cb7d:	mov    (%rsp),%rax
   2cb81:	mov    %r11,(%rax)
   2cb84:	mov    %r14,0x8(%rax)
   2cb88:	movq   $0x14c,0x10(%rax)
   2cb90:	add    $0x18,%rax
   2cb94:	mov    %rax,(%rsp)
   2cb98:	jmpq   2f8b3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x48f3>
   2cb9d:	test   %r14,%r14
   2cba0:	je     2eca4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ce4>
   2cba6:	mov    (%r12,%r14,8),%rax
   2cbaa:	mov    %rax,0x10(%r13)
   2cbae:	addq   $0xfffffffffffffffc,0x110(%r13)
   2cbb6:	mov    %rbx,%rax
   2cbb9:	and    %rbp,%rax
   2cbbc:	movabs $0x200000000000000,%rsi
   2cbc6:	cmp    %rsi,%rax
   2cbc9:	mov    0x8(%rsp),%rdx
   2cbce:	mov    0x18(%rsp),%rcx
   2cbd3:	je     2ecc8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3d08>
   2cbd9:	mov    %rbx,(%r12,%r14,8)
   2cbdd:	mov    %rcx,%rax
   2cbe0:	and    %rbp,%rax
   2cbe3:	cmp    %rsi,%rax
   2cbe6:	je     2ed13 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3d53>
   2cbec:	mov    %rcx,0x8(%r12,%r14,8)
   2cbf1:	mov    %rdx,%rax
   2cbf4:	and    %rbp,%rax
   2cbf7:	cmp    %rsi,%rax
   2cbfa:	je     2ed55 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3d95>
   2cc00:	mov    %r9,0x48(%rsp)
   2cc05:	mov    %rdi,0x40(%rsp)
   2cc0a:	mov    %rdx,0x10(%r12,%r14,8)
   2cc0f:	or     %r10,%r14
   2cc12:	test   %r15d,%r15d
   2cc15:	mov    0x10(%rsp),%rdx
   2cc1a:	je     2da65 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2aa5>
   2cc20:	mov    (%rsp),%rax
   2cc24:	mov    %r11,(%rax)
   2cc27:	mov    %r14,0x8(%rax)
   2cc2b:	movq   $0x14e,0x10(%rax)
   2cc33:	add    $0x18,%rax
   2cc37:	mov    %rax,(%rsp)
   2cc3b:	jmpq   2dab1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2af1>
   2cc40:	mov    %rbp,%r9
   2cc43:	mov    %rbx,%rbp
   2cc46:	mov    %r10,%rbx
   2cc49:	mov    %r11,%r10
   2cc4c:	mov    0x4(%r12,%rsi,8),%ecx
   2cc51:	mov    (%r12,%rsi,8),%eax
   2cc55:	mov    %eax,%edi
   2cc57:	and    $0xffffff,%edi
   2cc5d:	cmp    $0x1,%edi
   2cc60:	jne    306be <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x56fe>
   2cc66:	mov    (%r12,%rsi,8),%edx
   2cc6a:	shl    $0x20,%rcx
   2cc6e:	or     %rax,%rcx
   2cc71:	shr    $0x18,%rcx
   2cc75:	mov    (%r12,%rcx,8),%rdi
   2cc79:	mov    0x8(%r12,%rcx,8),%rax
   2cc7e:	mov    0x0(%r13),%rdx
   2cc82:	mov    %rdx,(%r12,%rsi,8)
   2cc86:	mov    %rsi,0x0(%r13)
   2cc8a:	mov    0x100(%r13),%rdx
   2cc91:	inc    %rdx
   2cc94:	mov    %rdx,0x100(%r13)
   2cc9b:	cmpb   $0x1,0x11cf6e(%rip)        # 149c10 <KEEP_WORDS>
   2cca2:	jne    309c4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a04>
   2cca8:	cmp    $0x8000,%rdx
   2ccaf:	jae    309c4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a04>
   2ccb5:	mov    %r10,%r11
   2ccb8:	mov    %rbx,%r10
   2ccbb:	mov    %rbp,%rbx
   2ccbe:	mov    %r9,%rbp
   2ccc1:	cmp    $0x3108280,%rcx
   2ccc8:	jb     2cd02 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d42>
   2ccca:	mov    0x8(%r13),%rdx
   2ccce:	mov    %rdx,(%r12,%rcx,8)
   2ccd2:	mov    %rcx,0x8(%r13)
   2ccd6:	mov    0x108(%r13),%rcx
   2ccdd:	add    $0x2,%rcx
   2cce1:	mov    %rcx,0x108(%r13)
   2cce8:	cmpb   $0x1,0x11cf21(%rip)        # 149c10 <KEEP_WORDS>
   2ccef:	jne    3032e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x536e>
   2ccf5:	cmp    $0x8000,%rcx
   2ccfc:	jae    3032e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x536e>
   2cd02:	cmp    $0x1,%rax
   2cd06:	je     2cd78 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1db8>
   2cd08:	movabs $0x7fffff0000000000,%rcx
   2cd12:	and    %rcx,%rax
   2cd15:	movabs $0x100020000000000,%rcx
   2cd1f:	cmp    %rcx,%rax
   2cd22:	je     2cd78 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1db8>
   2cd24:	test   %rbp,%rbp
   2cd27:	mov    %r15d,0x30(%rsp)
   2cd2c:	js     2df8c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2fcc>
   2cd32:	mov    %rbp,%rax
   2cd35:	shr    $0x39,%rax
   2cd39:	sete   %al
   2cd3c:	and    %rbp,%r10
   2cd3f:	cmp    $0x3108280,%r10
   2cd46:	setb   %cl
   2cd49:	or     %al,%cl
   2cd4b:	jne    2dfa7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2fe7>
   2cd51:	mov    %rdi,%r9
   2cd54:	mov    %r12,%rdi
   2cd57:	mov    %r13,%rsi
   2cd5a:	mov    %rbp,%rdx
   2cd5d:	mov    $0x2,%ecx
   2cd62:	mov    %r11,%r8
   2cd65:	callq  4574e <rfc_wrap>
   2cd6a:	mov    %r9,%rdi
   2cd6d:	mov    %r8,%r11
   2cd70:	mov    %rax,%rbp
   2cd73:	jmpq   2dfa7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2fe7>
   2cd78:	mov    0x8(%r13),%r10
   2cd7c:	test   %r10,%r10
   2cd7f:	je     2f0da <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x411a>
   2cd85:	mov    (%r12,%r10,8),%rax
   2cd89:	mov    %rax,0x8(%r13)
   2cd8d:	addq   $0xfffffffffffffffe,0x108(%r13)
   2cd95:	movabs $0xff00000000000000,%r14
   2cd9f:	mov    %rbp,%rax
   2cda2:	shr    $0x38,%rax
   2cda6:	cmp    $0x2,%eax
   2cda9:	je     2f0fe <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x413e>
   2cdaf:	mov    %rbp,(%r12,%r10,8)
   2cdb3:	mov    %rbx,%rdx
   2cdb6:	mov    %rbx,%rax
   2cdb9:	and    %r14,%rax
   2cdbc:	movabs $0x200000000000000,%rbx
   2cdc6:	cmp    %rbx,%rax
   2cdc9:	je     2f125 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4165>
   2cdcf:	mov    %rdx,0x8(%r12,%r10,8)
   2cdd4:	movabs $0x2002c0000000000,%rcx
   2cdde:	mov    0x10(%r13),%r8
   2cde2:	test   %r8,%r8
   2cde5:	je     2f149 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4189>
   2cdeb:	mov    (%r12,%r8,8),%rax
   2cdef:	mov    %rax,0x10(%r13)
   2cdf3:	addq   $0xfffffffffffffffc,0x110(%r13)
   2cdfb:	or     %rcx,%r10
   2cdfe:	mov    %r11,%rax
   2ce01:	and    %r14,%rax
   2ce04:	cmp    %rbx,%rax
   2ce07:	je     2f16d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x41ad>
   2ce0d:	mov    %r11,(%r12,%r8,8)
   2ce11:	mov    %r10,%rax
   2ce14:	shr    $0x38,%rax
   2ce18:	cmp    $0x2,%eax
   2ce1b:	jbe    2f18e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x41ce>
   2ce21:	mov    %r10,0x8(%r12,%r8,8)
   2ce26:	movabs $0x1002b0000000000,%rax
   2ce30:	mov    %rax,0x10(%r12,%r8,8)
   2ce35:	mov    0x8(%r13),%r10
   2ce39:	test   %r10,%r10
   2ce3c:	je     2f1af <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x41ef>
   2ce42:	mov    (%r12,%r10,8),%rax
   2ce46:	mov    %rax,0x8(%r13)
   2ce4a:	addq   $0xfffffffffffffffe,0x108(%r13)
   2ce52:	movabs $0x2002d0000000000,%rbp
   2ce5c:	and    %rdi,%r14
   2ce5f:	cmp    %rbx,%r14
   2ce62:	je     2f1de <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x421e>
   2ce68:	mov    (%rsp),%r14
   2ce6c:	movabs $0x300000000000000,%rbx
   2ce76:	or     %rbp,%r8
   2ce79:	movabs $0x200080000000000,%rsi
   2ce83:	mov    %rdi,(%r12,%r10,8)
   2ce87:	movabs $0x1000b0000000000,%rax
   2ce91:	mov    %rax,0x8(%r12,%r10,8)
   2ce96:	mov    0x8(%r13),%r9
   2ce9a:	test   %r9,%r9
   2ce9d:	je     2f1f9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4239>
   2cea3:	mov    (%r12,%r9,8),%rax
   2cea7:	mov    %rax,0x8(%r13)
   2ceab:	addq   $0xfffffffffffffffe,0x108(%r13)
   2ceb3:	or     %rsi,%r10
   2ceb6:	cmp    %rbx,%r8
   2ceb9:	jae    2d130 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2170>
   2cebf:	mov    %r12,%rdi
   2cec2:	mov    %rsi,%r14
   2cec5:	mov    %r13,%rsi
   2cec8:	mov    %r8,%rdx
   2cecb:	mov    $0x1,%ecx
   2ced0:	callq  4574e <rfc_wrap>
   2ced5:	mov    %r14,%rsi
   2ced8:	mov    (%rsp),%r14
   2cedc:	mov    %rax,%r8
   2cedf:	mov    %r8,(%r12,%r9,8)
   2cee3:	cmp    %rbx,%r10
   2cee6:	jae    2d13d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x217d>
   2ceec:	mov    %r12,%rdi
   2ceef:	mov    %rsi,%r8
   2cef2:	mov    %r13,%rsi
   2cef5:	mov    %r10,%rdx
   2cef8:	mov    $0x1,%ecx
   2cefd:	callq  4574e <rfc_wrap>
   2cf02:	mov    %r8,%rsi
   2cf05:	mov    %rax,%r10
   2cf08:	jmpq   2d13d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x217d>
   2cf0d:	mov    %r11,%r9
   2cf10:	mov    0x4(%r12,%rsi,8),%ecx
   2cf15:	mov    (%r12,%rsi,8),%eax
   2cf19:	mov    %eax,%edi
   2cf1b:	and    $0xffffff,%edi
   2cf21:	cmp    $0x1,%edi
   2cf24:	jne    30704 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5744>
   2cf2a:	mov    (%r12,%rsi,8),%edx
   2cf2e:	shl    $0x20,%rcx
   2cf32:	or     %rax,%rcx
   2cf35:	shr    $0x18,%rcx
   2cf39:	mov    (%r12,%rcx,8),%rdi
   2cf3d:	mov    0x8(%r12,%rcx,8),%rax
   2cf42:	mov    0x0(%r13),%rdx
   2cf46:	mov    %rdx,(%r12,%rsi,8)
   2cf4a:	mov    %rsi,0x0(%r13)
   2cf4e:	mov    0x100(%r13),%rdx
   2cf55:	inc    %rdx
   2cf58:	mov    %rdx,0x100(%r13)
   2cf5f:	cmpb   $0x1,0x11ccaa(%rip)        # 149c10 <KEEP_WORDS>
   2cf66:	jne    309dc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a1c>
   2cf6c:	cmp    $0x8000,%rdx
   2cf73:	jae    309dc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a1c>
   2cf79:	mov    %r9,%r11
   2cf7c:	cmp    $0x3108280,%rcx
   2cf83:	jb     2cfbd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ffd>
   2cf85:	mov    0x8(%r13),%rdx
   2cf89:	mov    %rdx,(%r12,%rcx,8)
   2cf8d:	mov    %rcx,0x8(%r13)
   2cf91:	mov    0x108(%r13),%rcx
   2cf98:	add    $0x2,%rcx
   2cf9c:	mov    %rcx,0x108(%r13)
   2cfa3:	cmpb   $0x1,0x11cc66(%rip)        # 149c10 <KEEP_WORDS>
   2cfaa:	jne    3034f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x538f>
   2cfb0:	cmp    $0x8000,%rcx
   2cfb7:	jae    3034f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x538f>
   2cfbd:	cmp    $0x1,%rax
   2cfc1:	je     2d147 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2187>
   2cfc7:	movabs $0x7fffff0000000000,%rcx
   2cfd1:	and    %rcx,%rax
   2cfd4:	movabs $0x100020000000000,%rcx
   2cfde:	cmp    %rcx,%rax
   2cfe1:	je     2d147 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2187>
   2cfe7:	mov    0x8(%r13),%r10
   2cfeb:	test   %r10,%r10
   2cfee:	je     2fa35 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a75>
   2cff4:	mov    (%r12,%r10,8),%rax
   2cff8:	mov    %rax,0x8(%r13)
   2cffc:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d004:	movabs $0xff00000000000000,%r9
   2d00e:	mov    %rbp,%rax
   2d011:	shr    $0x38,%rax
   2d015:	cmp    $0x2,%eax
   2d018:	mov    0x8(%rsp),%rdx
   2d01d:	je     2fa59 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a99>
   2d023:	mov    %rbp,(%r12,%r10,8)
   2d027:	mov    %rdx,%rax
   2d02a:	and    %r9,%rax
   2d02d:	movabs $0x200000000000000,%rbx
   2d037:	cmp    %rbx,%rax
   2d03a:	je     2fa85 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4ac5>
   2d040:	mov    %rdx,0x8(%r12,%r10,8)
   2d045:	movabs $0x2002c0000000000,%rcx
   2d04f:	mov    0x10(%r13),%r8
   2d053:	test   %r8,%r8
   2d056:	je     2faa9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4ae9>
   2d05c:	mov    (%r12,%r8,8),%rax
   2d060:	mov    %rax,0x10(%r13)
   2d064:	addq   $0xfffffffffffffffc,0x110(%r13)
   2d06c:	or     %rcx,%r10
   2d06f:	mov    %r11,%rax
   2d072:	and    %r9,%rax
   2d075:	cmp    %rbx,%rax
   2d078:	je     2facd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4b0d>
   2d07e:	mov    %r11,(%r12,%r8,8)
   2d082:	movabs $0x1002b0000000000,%rax
   2d08c:	mov    %rax,0x8(%r12,%r8,8)
   2d091:	mov    %r10,%rax
   2d094:	shr    $0x38,%rax
   2d098:	cmp    $0x2,%eax
   2d09b:	jbe    2faee <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4b2e>
   2d0a1:	mov    %r10,0x10(%r12,%r8,8)
   2d0a6:	mov    0x8(%r13),%r10
   2d0aa:	test   %r10,%r10
   2d0ad:	je     2fb1c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4b5c>
   2d0b3:	mov    (%r12,%r10,8),%rax
   2d0b7:	mov    %rax,0x8(%r13)
   2d0bb:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d0c3:	movabs $0x2002d0000000000,%r14
   2d0cd:	and    %rdi,%r9
   2d0d0:	cmp    %rbx,%r9
   2d0d3:	je     2fb4b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4b8b>
   2d0d9:	movabs $0x300000000000000,%rbx
   2d0e3:	or     %r14,%r8
   2d0e6:	movabs $0x200080000000000,%rsi
   2d0f0:	mov    %rdi,(%r12,%r10,8)
   2d0f4:	movabs $0x1000b0000000000,%rax
   2d0fe:	mov    %rax,0x8(%r12,%r10,8)
   2d103:	mov    0x8(%r13),%r9
   2d107:	test   %r9,%r9
   2d10a:	je     2fb66 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4ba6>
   2d110:	mov    (%r12,%r9,8),%rax
   2d114:	mov    %rax,0x8(%r13)
   2d118:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d120:	mov    (%rsp),%r14
   2d124:	or     %rsi,%r10
   2d127:	cmp    %rbx,%r8
   2d12a:	jb     2cebf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1eff>
   2d130:	mov    %r8,(%r12,%r9,8)
   2d134:	cmp    %rbx,%r10
   2d137:	jb     2ceec <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1f2c>
   2d13d:	mov    %r10,0x8(%r12,%r9,8)
   2d142:	jmpq   2b334 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x374>
   2d147:	test   %rbp,%rbp
   2d14a:	mov    %r15d,0x30(%rsp)
   2d14f:	js     2db5a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b9a>
   2d155:	mov    %rbp,%rax
   2d158:	shr    $0x39,%rax
   2d15c:	sete   %al
   2d15f:	and    %rbp,%r10
   2d162:	cmp    $0x3108280,%r10
   2d169:	setb   %cl
   2d16c:	or     %al,%cl
   2d16e:	jne    2db75 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2bb5>
   2d174:	mov    %rdi,%r9
   2d177:	mov    %r12,%rdi
   2d17a:	mov    %r13,%rsi
   2d17d:	mov    %rbp,%rdx
   2d180:	mov    $0x2,%ecx
   2d185:	mov    %r11,%r8
   2d188:	callq  4574e <rfc_wrap>
   2d18d:	mov    %r9,%rdi
   2d190:	mov    %r8,%r11
   2d193:	mov    %rax,%rbp
   2d196:	jmpq   2db75 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2bb5>
   2d19b:	mov    %r11,%r9
   2d19e:	mov    0x4(%r12,%rsi,8),%ecx
   2d1a3:	mov    (%r12,%rsi,8),%eax
   2d1a7:	mov    %eax,%edi
   2d1a9:	and    $0xffffff,%edi
   2d1af:	cmp    $0x1,%edi
   2d1b2:	jne    3073a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x577a>
   2d1b8:	mov    (%r12,%rsi,8),%edx
   2d1bc:	shl    $0x20,%rcx
   2d1c0:	or     %rax,%rcx
   2d1c3:	shr    $0x18,%rcx
   2d1c7:	mov    (%r12,%rcx,8),%rbp
   2d1cb:	mov    0x8(%r12,%rcx,8),%rax
   2d1d0:	mov    0x0(%r13),%rdx
   2d1d4:	mov    %rdx,(%r12,%rsi,8)
   2d1d8:	mov    %rsi,0x0(%r13)
   2d1dc:	mov    0x100(%r13),%rdx
   2d1e3:	inc    %rdx
   2d1e6:	mov    %rdx,0x100(%r13)
   2d1ed:	cmpb   $0x1,0x11ca1c(%rip)        # 149c10 <KEEP_WORDS>
   2d1f4:	jne    30a04 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a44>
   2d1fa:	cmp    $0x8000,%rdx
   2d201:	jae    30a04 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a44>
   2d207:	mov    %r9,%r11
   2d20a:	cmp    $0x3108280,%rcx
   2d211:	jb     2d24b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x228b>
   2d213:	mov    0x8(%r13),%rdx
   2d217:	mov    %rdx,(%r12,%rcx,8)
   2d21b:	mov    %rcx,0x8(%r13)
   2d21f:	mov    0x108(%r13),%rcx
   2d226:	add    $0x2,%rcx
   2d22a:	mov    %rcx,0x108(%r13)
   2d231:	cmpb   $0x1,0x11c9d8(%rip)        # 149c10 <KEEP_WORDS>
   2d238:	jne    30370 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x53b0>
   2d23e:	cmp    $0x8000,%rcx
   2d245:	jae    30370 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x53b0>
   2d24b:	movabs $0x1002b0000000000,%rsi
   2d255:	cmp    $0x1,%rax
   2d259:	je     2d2a5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x22e5>
   2d25b:	movabs $0x7fffff0000000000,%rcx
   2d265:	and    %rcx,%rax
   2d268:	movabs $0x100020000000000,%rcx
   2d272:	cmp    %rcx,%rax
   2d275:	je     2d2a5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x22e5>
   2d277:	test   %r15d,%r15d
   2d27a:	mov    %rbp,0x20(%rsp)
   2d27f:	je     2e161 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x31a1>
   2d285:	mov    (%rsp),%rax
   2d289:	mov    %r11,(%rax)
   2d28c:	mov    %rsi,0x8(%rax)
   2d290:	movq   $0x144,0x10(%rax)
   2d298:	add    $0x18,%rax
   2d29c:	mov    %rax,(%rsp)
   2d2a0:	jmpq   2e1cc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x320c>
   2d2a5:	mov    0x10(%r13),%r9
   2d2a9:	test   %r9,%r9
   2d2ac:	je     2f5f5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4635>
   2d2b2:	mov    (%r12,%r9,8),%rax
   2d2b6:	mov    %rax,0x10(%r13)
   2d2ba:	addq   $0xfffffffffffffffc,0x110(%r13)
   2d2c2:	movabs $0xff00000000000000,%r10
   2d2cc:	mov    %rbx,%rax
   2d2cf:	shr    $0x38,%rax
   2d2d3:	cmp    $0x2,%eax
   2d2d6:	mov    0x8(%rsp),%rdx
   2d2db:	mov    0x18(%rsp),%rcx
   2d2e0:	je     2f619 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4659>
   2d2e6:	mov    %rbx,(%r12,%r9,8)
   2d2ea:	mov    %rcx,%rax
   2d2ed:	and    %r10,%rax
   2d2f0:	movabs $0x200000000000000,%rbx
   2d2fa:	cmp    %rbx,%rax
   2d2fd:	je     2f64a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x468a>
   2d303:	mov    %rcx,0x8(%r12,%r9,8)
   2d308:	mov    %rdx,%rax
   2d30b:	and    %r10,%rax
   2d30e:	cmp    %rbx,%rax
   2d311:	je     2f676 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x46b6>
   2d317:	movabs $0x2002d0000000000,%r14
   2d321:	mov    %rdx,0x10(%r12,%r9,8)
   2d326:	mov    0x10(%r13),%r8
   2d32a:	test   %r8,%r8
   2d32d:	je     2f69a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x46da>
   2d333:	mov    (%r12,%r8,8),%rax
   2d337:	mov    %rax,0x10(%r13)
   2d33b:	addq   $0xfffffffffffffffc,0x110(%r13)
   2d343:	or     %r14,%r9
   2d346:	mov    %r11,%rax
   2d349:	and    %r10,%rax
   2d34c:	cmp    %rbx,%rax
   2d34f:	je     2f6be <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x46fe>
   2d355:	mov    %r11,(%r12,%r8,8)
   2d359:	mov    %r9,%rax
   2d35c:	shr    $0x38,%rax
   2d360:	cmp    $0x2,%eax
   2d363:	jbe    2f6e3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4723>
   2d369:	mov    %r9,0x8(%r12,%r8,8)
   2d36e:	mov    %rsi,0x10(%r12,%r8,8)
   2d373:	mov    0x8(%r13),%r9
   2d377:	test   %r9,%r9
   2d37a:	je     2f708 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4748>
   2d380:	mov    (%r12,%r9,8),%rax
   2d384:	mov    %rax,0x8(%r13)
   2d388:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d390:	and    %rbp,%r10
   2d393:	cmp    %rbx,%r10
   2d396:	je     2f727 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4767>
   2d39c:	movabs $0x300000000000000,%rbx
   2d3a6:	or     %r14,%r8
   2d3a9:	movabs $0x200080000000000,%rsi
   2d3b3:	mov    %rbp,(%r12,%r9,8)
   2d3b7:	movabs $0x1000b0000000000,%rax
   2d3c1:	mov    %rax,0x8(%r12,%r9,8)
   2d3c6:	mov    0x8(%r13),%r10
   2d3ca:	test   %r10,%r10
   2d3cd:	je     2f742 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4782>
   2d3d3:	mov    (%r12,%r10,8),%rax
   2d3d7:	mov    %rax,0x8(%r13)
   2d3db:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d3e3:	mov    (%rsp),%r14
   2d3e7:	or     %rsi,%r9
   2d3ea:	cmp    %rbx,%r8
   2d3ed:	jb     2f76b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x47ab>
   2d3f3:	mov    %r8,(%r12,%r10,8)
   2d3f7:	cmp    %rbx,%r9
   2d3fa:	jae    2d661 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26a1>
   2d400:	mov    %r12,%rdi
   2d403:	mov    %rsi,%r8
   2d406:	mov    %r13,%rsi
   2d409:	mov    %r9,%rdx
   2d40c:	mov    $0x1,%ecx
   2d411:	callq  4574e <rfc_wrap>
   2d416:	mov    %r8,%rsi
   2d419:	mov    %rax,%r9
   2d41c:	jmpq   2d661 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26a1>
   2d421:	mov    %rdi,%r14
   2d424:	mov    %r11,%r9
   2d427:	mov    0x4(%r12,%rsi,8),%ecx
   2d42c:	mov    (%r12,%rsi,8),%eax
   2d430:	mov    %eax,%edi
   2d432:	and    $0xffffff,%edi
   2d438:	cmp    $0x1,%edi
   2d43b:	jne    30773 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x57b3>
   2d441:	mov    (%r12,%rsi,8),%edx
   2d445:	shl    $0x20,%rcx
   2d449:	or     %rax,%rcx
   2d44c:	shr    $0x18,%rcx
   2d450:	mov    (%r12,%rcx,8),%rbp
   2d454:	mov    0x8(%r12,%rcx,8),%rax
   2d459:	mov    0x0(%r13),%rdx
   2d45d:	mov    %rdx,(%r12,%rsi,8)
   2d461:	mov    %rsi,0x0(%r13)
   2d465:	mov    0x100(%r13),%rdx
   2d46c:	inc    %rdx
   2d46f:	mov    %rdx,0x100(%r13)
   2d476:	cmpb   $0x1,0x11c793(%rip)        # 149c10 <KEEP_WORDS>
   2d47d:	jne    30a26 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a66>
   2d483:	cmp    $0x8000,%rdx
   2d48a:	jae    30a26 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a66>
   2d490:	mov    %r9,%r11
   2d493:	mov    %r14,%rdi
   2d496:	cmp    $0x3108280,%rcx
   2d49d:	jb     2d4d7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2517>
   2d49f:	mov    0x8(%r13),%rdx
   2d4a3:	mov    %rdx,(%r12,%rcx,8)
   2d4a7:	mov    %rcx,0x8(%r13)
   2d4ab:	mov    0x108(%r13),%rcx
   2d4b2:	add    $0x2,%rcx
   2d4b6:	mov    %rcx,0x108(%r13)
   2d4bd:	cmpb   $0x1,0x11c74c(%rip)        # 149c10 <KEEP_WORDS>
   2d4c4:	jne    3038b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x53cb>
   2d4ca:	cmp    $0x8000,%rcx
   2d4d1:	jae    3038b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x53cb>
   2d4d7:	movabs $0x1002b0000000000,%rdx
   2d4e1:	cmp    $0x1,%rax
   2d4e5:	je     2d66e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26ae>
   2d4eb:	movabs $0x7fffff0000000000,%rcx
   2d4f5:	and    %rcx,%rax
   2d4f8:	movabs $0x100020000000000,%rcx
   2d502:	cmp    %rcx,%rax
   2d505:	je     2d66e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26ae>
   2d50b:	mov    0x10(%r13),%r9
   2d50f:	test   %r9,%r9
   2d512:	je     2fb94 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4bd4>
   2d518:	mov    (%r12,%r9,8),%rax
   2d51c:	mov    %rax,0x10(%r13)
   2d520:	addq   $0xfffffffffffffffc,0x110(%r13)
   2d528:	movabs $0xff00000000000000,%r10
   2d532:	mov    %rbx,%rax
   2d535:	shr    $0x38,%rax
   2d539:	cmp    $0x2,%eax
   2d53c:	je     2fbbe <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4bfe>
   2d542:	mov    %rbx,(%r12,%r9,8)
   2d546:	mov    %rdi,%rax
   2d549:	and    %r10,%rax
   2d54c:	movabs $0x200000000000000,%r14
   2d556:	cmp    %r14,%rax
   2d559:	je     2fbef <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4c2f>
   2d55f:	mov    %rdi,0x8(%r12,%r9,8)
   2d564:	mov    0x8(%rsp),%rax
   2d569:	mov    %rax,%rcx
   2d56c:	and    %r10,%rcx
   2d56f:	cmp    %r14,%rcx
   2d572:	je     2fc16 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4c56>
   2d578:	movabs $0x2002d0000000000,%rbx
   2d582:	mov    %rax,0x10(%r12,%r9,8)
   2d587:	mov    0x10(%r13),%r8
   2d58b:	test   %r8,%r8
   2d58e:	je     2fc3a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4c7a>
   2d594:	mov    (%r12,%r8,8),%rax
   2d598:	mov    %rax,0x10(%r13)
   2d59c:	addq   $0xfffffffffffffffc,0x110(%r13)
   2d5a4:	or     %rbx,%r9
   2d5a7:	mov    %r11,%rax
   2d5aa:	and    %r10,%rax
   2d5ad:	cmp    %r14,%rax
   2d5b0:	je     2fc5e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4c9e>
   2d5b6:	mov    %r11,(%r12,%r8,8)
   2d5ba:	mov    %rdx,0x8(%r12,%r8,8)
   2d5bf:	mov    %r9,%rax
   2d5c2:	shr    $0x38,%rax
   2d5c6:	cmp    $0x2,%eax
   2d5c9:	jbe    2fc83 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4cc3>
   2d5cf:	mov    %r9,0x10(%r12,%r8,8)
   2d5d4:	mov    0x8(%r13),%r9
   2d5d8:	test   %r9,%r9
   2d5db:	je     2fcab <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4ceb>
   2d5e1:	mov    (%r12,%r9,8),%rax
   2d5e5:	mov    %rax,0x8(%r13)
   2d5e9:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d5f1:	and    %rbp,%r10
   2d5f4:	cmp    %r14,%r10
   2d5f7:	je     2fcca <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4d0a>
   2d5fd:	movabs $0x300000000000000,%r14
   2d607:	or     %rbx,%r8
   2d60a:	movabs $0x200080000000000,%rsi
   2d614:	mov    %rbp,(%r12,%r9,8)
   2d618:	movabs $0x1000b0000000000,%rax
   2d622:	mov    %rax,0x8(%r12,%r9,8)
   2d627:	mov    0x8(%r13),%r10
   2d62b:	test   %r10,%r10
   2d62e:	je     2fce5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4d25>
   2d634:	mov    (%r12,%r10,8),%rax
   2d638:	mov    %rax,0x8(%r13)
   2d63c:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d644:	or     %rsi,%r9
   2d647:	cmp    %r14,%r8
   2d64a:	jb     2fd0a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4d4a>
   2d650:	mov    %r8,(%r12,%r10,8)
   2d654:	cmp    %r14,%r9
   2d657:	jb     2fd33 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4d73>
   2d65d:	mov    (%rsp),%r14
   2d661:	mov    %r9,0x8(%r12,%r10,8)
   2d666:	or     %r10,%rsi
   2d669:	jmpq   2b337 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x377>
   2d66e:	test   %r15d,%r15d
   2d671:	mov    %rbp,0x18(%rsp)
   2d676:	je     2de28 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2e68>
   2d67c:	mov    (%rsp),%rax
   2d680:	mov    %r11,(%rax)
   2d683:	mov    %rdx,0x8(%rax)
   2d687:	movq   $0x134,0x10(%rax)
   2d68f:	add    $0x18,%rax
   2d693:	mov    %rax,(%rsp)
   2d697:	jmpq   2dea4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2ee4>
   2d69c:	mov    %r11,%r10
   2d69f:	mov    0x4(%r12,%r8,8),%ecx
   2d6a4:	mov    (%r12,%r8,8),%eax
   2d6a8:	mov    %eax,%esi
   2d6aa:	and    $0xffffff,%esi
   2d6b0:	cmp    $0x1,%esi
   2d6b3:	jne    307b3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x57f3>
   2d6b9:	mov    (%r12,%r8,8),%edx
   2d6bd:	shl    $0x20,%rcx
   2d6c1:	or     %rax,%rcx
   2d6c4:	shr    $0x18,%rcx
   2d6c8:	mov    (%r12,%rcx,8),%r9
   2d6cc:	mov    0x8(%r12,%rcx,8),%rax
   2d6d1:	mov    0x0(%r13),%rdx
   2d6d5:	mov    %rdx,(%r12,%r8,8)
   2d6d9:	mov    %r8,0x0(%r13)
   2d6dd:	mov    0x100(%r13),%rdx
   2d6e4:	inc    %rdx
   2d6e7:	mov    %rdx,0x100(%r13)
   2d6ee:	cmpb   $0x1,0x11c51b(%rip)        # 149c10 <KEEP_WORDS>
   2d6f5:	jne    30a4b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a8b>
   2d6fb:	cmp    $0x8000,%rdx
   2d702:	jae    30a4b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5a8b>
   2d708:	mov    %r10,%r11
   2d70b:	cmp    $0x3108280,%rcx
   2d712:	jb     2d74c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x278c>
   2d714:	mov    0x8(%r13),%rdx
   2d718:	mov    %rdx,(%r12,%rcx,8)
   2d71c:	mov    %rcx,0x8(%r13)
   2d720:	mov    0x108(%r13),%rcx
   2d727:	add    $0x2,%rcx
   2d72b:	mov    %rcx,0x108(%r13)
   2d732:	cmpb   $0x1,0x11c4d7(%rip)        # 149c10 <KEEP_WORDS>
   2d739:	jne    303ac <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x53ec>
   2d73f:	cmp    $0x8000,%rcx
   2d746:	jae    303ac <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x53ec>
   2d74c:	movabs $0xff00000000000000,%r15
   2d756:	movabs $0x300000000000000,%r14
   2d760:	movabs $0x2002d0000000000,%rsi
   2d76a:	movabs $0x200080000000000,%r8
   2d774:	movabs $0x1002b0000000000,%rbx
   2d77e:	movabs $0x1000b0000000000,%rdx
   2d788:	mov    0x10(%r13),%r10
   2d78c:	cmp    $0x1,%rax
   2d790:	je     2d7ac <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x27ec>
   2d792:	movabs $0x7fffff0000000000,%rcx
   2d79c:	and    %rcx,%rax
   2d79f:	movabs $0x100020000000000,%rcx
   2d7a9:	cmp    %rcx,%rax
   2d7ac:	test   %r10,%r10
   2d7af:	je     2e531 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3571>
   2d7b5:	mov    (%r12,%r10,8),%rax
   2d7b9:	mov    %rax,0x10(%r13)
   2d7bd:	addq   $0xfffffffffffffffc,0x110(%r13)
   2d7c5:	mov    %r11,%rax
   2d7c8:	and    %r15,%rax
   2d7cb:	movabs $0x200000000000000,%rbp
   2d7d5:	cmp    %rbp,%rax
   2d7d8:	je     2e55b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x359b>
   2d7de:	mov    %r11,(%r12,%r10,8)
   2d7e2:	mov    %rbx,0x8(%r12,%r10,8)
   2d7e7:	mov    %rbx,0x10(%r12,%r10,8)
   2d7ec:	mov    0x8(%r13),%rbx
   2d7f0:	test   %rbx,%rbx
   2d7f3:	je     2e58a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x35ca>
   2d7f9:	mov    (%r12,%rbx,8),%rax
   2d7fd:	mov    %rax,0x8(%r13)
   2d801:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d809:	and    %r9,%r15
   2d80c:	cmp    %rbp,%r15
   2d80f:	je     2e5b5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x35f5>
   2d815:	or     %rsi,%r10
   2d818:	mov    %r9,(%r12,%rbx,8)
   2d81c:	mov    %rdx,0x8(%r12,%rbx,8)
   2d821:	mov    0x8(%r13),%r9
   2d825:	test   %r9,%r9
   2d828:	je     2e5dc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x361c>
   2d82e:	mov    (%r12,%r9,8),%rax
   2d832:	mov    %rax,0x8(%r13)
   2d836:	addq   $0xfffffffffffffffe,0x108(%r13)
   2d83e:	or     %r8,%rbx
   2d841:	cmp    %r14,%r10
   2d844:	jb     2e5fb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x363b>
   2d84a:	mov    %r10,(%r12,%r9,8)
   2d84e:	cmp    %r14,%rbx
   2d851:	jb     2e61e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x365e>
   2d857:	mov    (%rsp),%r14
   2d85b:	mov    0x30(%rsp),%r15d
   2d860:	mov    %rbx,0x8(%r12,%r9,8)
   2d865:	or     %r9,%r8
   2d868:	mov    -0x8(%r14),%eax
   2d86c:	add    $0xfffffffffffffff8,%r14
   2d870:	lea    0x1a039(%rip),%rcx        # 478b0 <wl_tab>
   2d877:	mov    (%rcx,%rax,8),%rax
   2d87b:	mov    $0x1,%edi
   2d880:	mov    %r8,%rsi
   2d883:	add    $0x50,%rsp
   2d887:	pop    %rbp
   2d888:	jmpq   *%rax
   2d88a:	mov    %r12,%rdi
   2d88d:	mov    %r13,%rsi
   2d890:	mov    %rdx,%rcx
   2d893:	mov    $0x2,%edx
   2d898:	mov    %r8,%r9
   2d89b:	mov    %r11,%r8
   2d89e:	callq  45321 <heap_hand>
   2d8a3:	mov    %r8,%r11
   2d8a6:	mov    %r9,%r8
   2d8a9:	mov    %rcx,%rdx
   2d8ac:	jmpq   2b12d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16d>
   2d8b1:	mov    %r12,%rdi
   2d8b4:	mov    %r13,%rsi
   2d8b7:	mov    %rdx,%rax
   2d8ba:	mov    $0x1,%edx
   2d8bf:	callq  45321 <heap_hand>
   2d8c4:	jmp    2d937 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2977>
   2d8c6:	shl    $0x20,%rcx
   2d8ca:	or     %rdi,%rcx
   2d8cd:	shr    $0x18,%rcx
   2d8d1:	mov    (%r12,%rcx,8),%r10
   2d8d5:	mov    0x8(%r12,%rcx,8),%rbp
   2d8da:	mov    0x10(%r12,%rcx,8),%r14
   2d8df:	mov    %r12,%rdi
   2d8e2:	mov    %r13,%rsi
   2d8e5:	mov    %rdx,0x28(%rsp)
   2d8ea:	mov    %rbx,%rdx
   2d8ed:	mov    $0x3,%r8d
   2d8f3:	callq  453b2 <span_fade>
   2d8f8:	mov    %r10,%r11
   2d8fb:	movabs $0xffffffff80,%r10
   2d905:	mov    0x28(%rsp),%rdx
   2d90a:	mov    %r9,%r8
   2d90d:	jmpq   2b12d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16d>
   2d912:	shl    $0x20,%rcx
   2d916:	or     %rsi,%rcx
   2d919:	shr    $0x18,%rcx
   2d91d:	mov    (%r12,%rcx,8),%rbp
   2d921:	mov    0x8(%r12,%rcx,8),%rax
   2d926:	mov    %r12,%rdi
   2d929:	mov    %r13,%rsi
   2d92c:	mov    $0x2,%r8d
   2d932:	callq  453b2 <span_fade>
   2d937:	mov    %rax,%rdx
   2d93a:	jmpq   2b266 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a6>
   2d93f:	mov    (%rsp),%rbp
   2d943:	mov    -0x18(%rbp),%rcx
   2d947:	mov    -0x10(%rbp),%r8d
   2d94b:	mov    %r12,%rdi
   2d94e:	mov    %r13,%rsi
   2d951:	mov    $0x13e,%edx
   2d956:	mov    $0x1,%r9d
   2d95c:	mov    %r11,%r15
   2d95f:	callq  caf0 <task_node>
   2d964:	mov    %r15,(%r12,%rax,8)
   2d968:	mov    %rbx,0x8(%r12,%rax,8)
   2d96d:	movabs $0x5013e0000000000,%rcx
   2d977:	or     %rax,%rcx
   2d97a:	mov    %rcx,-0x18(%rbp)
   2d97e:	movq   $0x2,-0x10(%rbp)
   2d986:	movabs $0x200000000000000,%rbp
   2d990:	mov    %r12,%rdi
   2d993:	mov    %r13,%rsi
   2d996:	mov    0x10(%rsp),%rdx
   2d99b:	callq  43610 <term_keep>
   2d9a0:	mov    %rax,%rbx
   2d9a3:	mov    0x10(%r13),%r8
   2d9a7:	test   %r8,%r8
   2d9aa:	je     2ec2e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3c6e>
   2d9b0:	mov    (%r12,%r8,8),%rax
   2d9b4:	mov    %rax,0x10(%r13)
   2d9b8:	addq   $0xfffffffffffffffc,0x110(%r13)
   2d9c0:	mov    %rbx,%rcx
   2d9c3:	and    %r14,%rcx
   2d9c6:	mov    %rbx,%rax
   2d9c9:	cmp    %rbp,%rcx
   2d9cc:	mov    0x30(%rsp),%r15d
   2d9d1:	mov    0x8(%rsp),%rdx
   2d9d6:	je     2ec46 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3c86>
   2d9dc:	mov    %rax,(%r12,%r8,8)
   2d9e0:	mov    0x18(%rsp),%rax
   2d9e5:	mov    %rax,%rcx
   2d9e8:	and    %r14,%rcx
   2d9eb:	cmp    %rbp,%rcx
   2d9ee:	je     2ec63 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ca3>
   2d9f4:	mov    %rax,0x8(%r12,%r8,8)
   2d9f9:	and    %rdx,%r14
   2d9fc:	cmp    %rbp,%r14
   2d9ff:	je     2ec8c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ccc>
   2da05:	movabs $0x2002d0000000000,%rbp
   2da0f:	or     %r8,%rbp
   2da12:	mov    %rdx,0x10(%r12,%r8,8)
   2da17:	test   %r15d,%r15d
   2da1a:	je     2da30 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a70>
   2da1c:	mov    (%rsp),%r14
   2da20:	mov    %rbp,(%r14)
   2da23:	movq   $0x13f,0x8(%r14)
   2da2b:	jmpq   2f955 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4995>
   2da30:	mov    (%rsp),%r14
   2da34:	mov    -0x18(%r14),%rcx
   2da38:	mov    -0x10(%r14),%r8d
   2da3c:	mov    %r12,%rdi
   2da3f:	mov    %r13,%rsi
   2da42:	mov    $0x13f,%edx
   2da47:	mov    $0x1,%r9d
   2da4d:	callq  caf0 <task_node>
   2da52:	mov    %rbp,(%r12,%rax,8)
   2da56:	movabs $0x5013f0000000000,%rcx
   2da60:	jmpq   2fa11 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a51>
   2da65:	mov    (%rsp),%rbx
   2da69:	mov    -0x18(%rbx),%rcx
   2da6d:	mov    -0x10(%rbx),%r8d
   2da71:	mov    %r12,%rdi
   2da74:	mov    %r13,%rsi
   2da77:	mov    $0x14e,%edx
   2da7c:	mov    $0x1,%r9d
   2da82:	mov    %r11,%r15
   2da85:	callq  caf0 <task_node>
   2da8a:	mov    %r15,(%r12,%rax,8)
   2da8e:	mov    %r14,0x8(%r12,%rax,8)
   2da93:	movabs $0x5014e0000000000,%rcx
   2da9d:	or     %rax,%rcx
   2daa0:	mov    %rcx,-0x18(%rbx)
   2daa4:	mov    0x10(%rsp),%rdx
   2daa9:	movq   $0x2,-0x10(%rbx)
   2dab1:	mov    %r12,%rdi
   2dab4:	mov    %r13,%rsi
   2dab7:	callq  43610 <term_keep>
   2dabc:	mov    %rax,%rbx
   2dabf:	mov    0x10(%r13),%r8
   2dac3:	test   %r8,%r8
   2dac6:	je     2ed85 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3dc5>
   2dacc:	mov    (%r12,%r8,8),%rax
   2dad0:	mov    %rax,0x10(%r13)
   2dad4:	addq   $0xfffffffffffffffc,0x110(%r13)
   2dadc:	mov    0x48(%rsp),%r9
   2dae1:	mov    %rbx,%rcx
   2dae4:	and    %rbp,%rcx
   2dae7:	mov    %rbx,%rax
   2daea:	movabs $0x200000000000000,%rdx
   2daf4:	cmp    %rdx,%rcx
   2daf7:	mov    0x30(%rsp),%r15d
   2dafc:	mov    0x40(%rsp),%rcx
   2db01:	movabs $0x2002d0000000000,%r10
   2db0b:	je     2ed9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3ddd>
   2db11:	mov    %rax,(%r12,%r8,8)
   2db15:	mov    %r9,%rax
   2db18:	and    %rbp,%rax
   2db1b:	cmp    %rdx,%rax
   2db1e:	je     2edc4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3e04>
   2db24:	mov    %r9,0x8(%r12,%r8,8)
   2db29:	and    %rcx,%rbp
   2db2c:	cmp    %rdx,%rbp
   2db2f:	je     2edfa <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3e3a>
   2db35:	or     %r8,%r10
   2db38:	mov    %rcx,0x10(%r12,%r8,8)
   2db3d:	test   %r15d,%r15d
   2db40:	je     2ee21 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3e61>
   2db46:	mov    (%rsp),%r14
   2db4a:	mov    %r10,(%r14)
   2db4d:	movq   $0x14f,0x8(%r14)
   2db55:	jmpq   2f955 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4995>
   2db5a:	and    %rbp,%r8
   2db5d:	mov    $0x1,%eax
   2db62:	lock xadd %eax,(%r12,%r8,8)
   2db68:	not    %eax
   2db6a:	test   $0xfffffe,%eax
   2db6f:	je     31afb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6b3b>
   2db75:	mov    0x8(%r13),%r10
   2db79:	test   %r10,%r10
   2db7c:	mov    0x8(%rsp),%rdx
   2db81:	je     2fd54 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4d94>
   2db87:	mov    (%r12,%r10,8),%rax
   2db8b:	mov    %rax,0x8(%r13)
   2db8f:	addq   $0xfffffffffffffffe,0x108(%r13)
   2db97:	movabs $0xff00000000000000,%r14
   2dba1:	mov    %rbp,%rbx
   2dba4:	and    %r14,%rbx
   2dba7:	movabs $0x200000000000000,%r9
   2dbb1:	mov    %rbp,%rax
   2dbb4:	cmp    %r9,%rbx
   2dbb7:	je     2fd7d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4dbd>
   2dbbd:	mov    %rax,(%r12,%r10,8)
   2dbc1:	mov    %rdx,%rax
   2dbc4:	and    %r14,%rax
   2dbc7:	cmp    %r9,%rax
   2dbca:	je     2fda6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4de6>
   2dbd0:	mov    %rdx,0x8(%r12,%r10,8)
   2dbd5:	movabs $0x2002c0000000000,%rcx
   2dbdf:	mov    0x10(%r13),%r8
   2dbe3:	test   %r8,%r8
   2dbe6:	je     2fdca <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4e0a>
   2dbec:	mov    (%r12,%r8,8),%rax
   2dbf0:	mov    %rax,0x10(%r13)
   2dbf4:	addq   $0xfffffffffffffffc,0x110(%r13)
   2dbfc:	or     %rcx,%r10
   2dbff:	mov    %r11,%rax
   2dc02:	and    %r14,%rax
   2dc05:	cmp    %r9,%rax
   2dc08:	je     2fdee <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4e2e>
   2dc0e:	mov    %r11,(%r12,%r8,8)
   2dc12:	movabs $0x1002b0000000000,%rax
   2dc1c:	mov    %rax,0x8(%r12,%r8,8)
   2dc21:	mov    %r10,%rax
   2dc24:	shr    $0x38,%rax
   2dc28:	cmp    $0x2,%eax
   2dc2b:	jbe    2fe0f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4e4f>
   2dc31:	mov    %r10,0x10(%r12,%r8,8)
   2dc36:	mov    0x0(%r13),%r15
   2dc3a:	test   %r15,%r15
   2dc3d:	je     2fe3d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4e7d>
   2dc43:	mov    (%r12,%r15,8),%rax
   2dc47:	mov    %rax,0x0(%r13)
   2dc4b:	decq   0x100(%r13)
   2dc52:	cmp    %r9,%rbx
   2dc55:	je     2fe5c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4e9c>
   2dc5b:	mov    %rbp,(%r12,%r15,8)
   2dc5f:	movabs $0x2000c0000000000,%rcx
   2dc69:	mov    0x8(%r13),%r10
   2dc6d:	test   %r10,%r10
   2dc70:	je     2fe7d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4ebd>
   2dc76:	mov    (%r12,%r10,8),%rax
   2dc7a:	mov    %rax,0x8(%r13)
   2dc7e:	addq   $0xfffffffffffffffe,0x108(%r13)
   2dc86:	movabs $0x300000000000000,%rbx
   2dc90:	or     %rcx,%r15
   2dc93:	and    %rdi,%r14
   2dc96:	cmp    %r9,%r14
   2dc99:	je     2fe9b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4edb>
   2dc9f:	mov    (%rsp),%r14
   2dca3:	movabs $0x2002d0000000000,%r9
   2dcad:	mov    %rdi,(%r12,%r10,8)
   2dcb1:	cmp    %rbx,%r15
   2dcb4:	jb     2feb6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4ef6>
   2dcba:	or     %r9,%r8
   2dcbd:	movabs $0x200080000000000,%rsi
   2dcc7:	mov    %r15,0x8(%r12,%r10,8)
   2dccc:	mov    0x8(%r13),%r9
   2dcd0:	test   %r9,%r9
   2dcd3:	je     2fed1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4f11>
   2dcd9:	mov    (%r12,%r9,8),%rax
   2dcdd:	mov    %rax,0x8(%r13)
   2dce1:	addq   $0xfffffffffffffffe,0x108(%r13)
   2dce9:	or     %rsi,%r10
   2dcec:	cmp    %rbx,%r8
   2dcef:	jae    2e128 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3168>
   2dcf5:	jmpq   2fef6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4f36>
   2dcfa:	mov    %rbx,0x10(%rsp)
   2dcff:	mov    (%rsp),%rbx
   2dd03:	mov    -0x18(%rbx),%rcx
   2dd07:	mov    -0x10(%rbx),%r8d
   2dd0b:	mov    %r12,%rdi
   2dd0e:	mov    %r13,%rsi
   2dd11:	mov    $0x148,%edx
   2dd16:	mov    $0x1,%r9d
   2dd1c:	mov    %r11,%r15
   2dd1f:	callq  caf0 <task_node>
   2dd24:	mov    %r15,(%r12,%rax,8)
   2dd28:	mov    %rbp,0x8(%r12,%rax,8)
   2dd2d:	movabs $0x501480000000000,%rcx
   2dd37:	or     %rax,%rcx
   2dd3a:	mov    %rcx,-0x18(%rbx)
   2dd3e:	movq   $0x2,-0x10(%rbx)
   2dd46:	mov    0x10(%rsp),%rbx
   2dd4b:	mov    %r12,%rdi
   2dd4e:	mov    %r13,%rsi
   2dd51:	mov    %rbx,%rdx
   2dd54:	callq  43610 <term_keep>
   2dd59:	mov    %rax,%rbx
   2dd5c:	mov    0x10(%r13),%r8
   2dd60:	test   %r8,%r8
   2dd63:	je     2f595 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x45d5>
   2dd69:	mov    (%r12,%r8,8),%rax
   2dd6d:	mov    %rax,0x10(%r13)
   2dd71:	addq   $0xfffffffffffffffc,0x110(%r13)
   2dd79:	movabs $0x200000000000000,%r9
   2dd83:	mov    %rbx,%rcx
   2dd86:	and    %r14,%rcx
   2dd89:	mov    %rbx,%rax
   2dd8c:	cmp    %r9,%rcx
   2dd8f:	mov    0x30(%rsp),%r15d
   2dd94:	je     2f5ad <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x45ed>
   2dd9a:	mov    %rax,(%r12,%r8,8)
   2dd9e:	mov    0x18(%rsp),%rdx
   2dda3:	mov    %rdx,%rax
   2dda6:	and    %r14,%rax
   2dda9:	cmp    %r9,%rax
   2ddac:	je     2f5c5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4605>
   2ddb2:	mov    %rdx,0x8(%r12,%r8,8)
   2ddb7:	mov    0x8(%rsp),%rax
   2ddbc:	and    %rax,%r14
   2ddbf:	cmp    %r9,%r14
   2ddc2:	je     2f5dd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x461d>
   2ddc8:	movabs $0x2002d0000000000,%rbp
   2ddd2:	or     %r8,%rbp
   2ddd5:	mov    %rax,0x10(%r12,%r8,8)
   2ddda:	test   %r15d,%r15d
   2dddd:	je     2ddf3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2e33>
   2dddf:	mov    (%rsp),%r14
   2dde3:	mov    %rbp,(%r14)
   2dde6:	movq   $0x149,0x8(%r14)
   2ddee:	jmpq   2f955 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4995>
   2ddf3:	mov    (%rsp),%r14
   2ddf7:	mov    -0x18(%r14),%rcx
   2ddfb:	mov    -0x10(%r14),%r8d
   2ddff:	mov    %r12,%rdi
   2de02:	mov    %r13,%rsi
   2de05:	mov    $0x149,%edx
   2de0a:	mov    $0x1,%r9d
   2de10:	callq  caf0 <task_node>
   2de15:	mov    %rbp,(%r12,%rax,8)
   2de19:	movabs $0x501490000000000,%rcx
   2de23:	jmpq   2fa11 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a51>
   2de28:	mov    (%rsp),%r14
   2de2c:	mov    -0x18(%r14),%rcx
   2de30:	mov    %r8,0x40(%rsp)
   2de35:	mov    -0x10(%r14),%r8d
   2de39:	mov    %rdi,0x20(%rsp)
   2de3e:	mov    %r12,%rdi
   2de41:	mov    %r13,%rsi
   2de44:	mov    $0x134,%edx
   2de49:	mov    $0x1,%r9d
   2de4f:	mov    %r11,0x38(%rsp)
   2de54:	mov    %rbx,0x10(%rsp)
   2de59:	mov    %r10,%rbp
   2de5c:	callq  caf0 <task_node>
   2de61:	mov    0x20(%rsp),%rdi
   2de66:	mov    0x40(%rsp),%r8
   2de6b:	mov    %rbp,%r10
   2de6e:	mov    0x10(%rsp),%rbx
   2de73:	mov    0x38(%rsp),%rcx
   2de78:	mov    %rcx,(%r12,%rax,8)
   2de7c:	movabs $0x1002b0000000000,%rcx
   2de86:	mov    %rcx,0x8(%r12,%rax,8)
   2de8b:	movabs $0x501340000000000,%rcx
   2de95:	or     %rax,%rcx
   2de98:	mov    %rcx,-0x18(%r14)
   2de9c:	movq   $0x2,-0x10(%r14)
   2dea4:	test   %rbx,%rbx
   2dea7:	js     2dece <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2f0e>
   2dea9:	mov    %rbx,%rax
   2deac:	shr    $0x39,%rax
   2deb0:	sete   %al
   2deb3:	and    %rbx,%r10
   2deb6:	cmp    $0x3108280,%r10
   2debd:	setb   %cl
   2dec0:	or     %al,%cl
   2dec2:	je     30a6d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5aad>
   2dec8:	mov    (%rsp),%r14
   2decc:	jmp    2deed <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2f2d>
   2dece:	and    %rbx,%r8
   2ded1:	mov    $0x1,%eax
   2ded6:	lock xadd %eax,(%r12,%r8,8)
   2dedc:	not    %eax
   2dede:	test   $0xfffffe,%eax
   2dee3:	mov    (%rsp),%r14
   2dee7:	je     31afb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6b3b>
   2deed:	mov    0x10(%r13),%r8
   2def1:	test   %r8,%r8
   2def4:	je     2ff44 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4f84>
   2defa:	mov    (%r12,%r8,8),%rax
   2defe:	mov    %rax,0x10(%r13)
   2df02:	addq   $0xfffffffffffffffc,0x110(%r13)
   2df0a:	movabs $0xff00000000000000,%r9
   2df14:	mov    %rbx,%rcx
   2df17:	shr    $0x38,%rcx
   2df1b:	mov    %rbx,%rax
   2df1e:	cmp    $0x2,%ecx
   2df21:	je     2ff62 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4fa2>
   2df27:	mov    %rax,(%r12,%r8,8)
   2df2b:	mov    %rdi,%rax
   2df2e:	and    %r9,%rax
   2df31:	movabs $0x200000000000000,%r10
   2df3b:	cmp    %r10,%rax
   2df3e:	je     2ff80 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4fc0>
   2df44:	mov    %rdi,0x8(%r12,%r8,8)
   2df49:	mov    0x8(%rsp),%rax
   2df4e:	and    %rax,%r9
   2df51:	mov    %rbx,%rbp
   2df54:	cmp    %r10,%r9
   2df57:	je     2ff9b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4fdb>
   2df5d:	movabs $0x2002d0000000000,%rbx
   2df67:	or     %r8,%rbx
   2df6a:	mov    %rax,0x10(%r12,%r8,8)
   2df6f:	test   %r15d,%r15d
   2df72:	je     2e2c3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3303>
   2df78:	mov    %rbx,(%r14)
   2df7b:	movq   $0x135,0x8(%r14)
   2df83:	add    $0x10,%r14
   2df87:	jmpq   2e301 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3341>
   2df8c:	and    %rbp,%r8
   2df8f:	mov    $0x1,%eax
   2df94:	lock xadd %eax,(%r12,%r8,8)
   2df9a:	not    %eax
   2df9c:	test   $0xfffffe,%eax
   2dfa1:	je     31afb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6b3b>
   2dfa7:	mov    0x8(%r13),%r10
   2dfab:	mov    %rbx,%r15
   2dfae:	test   %r10,%r10
   2dfb1:	je     2ffb3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4ff3>
   2dfb7:	mov    (%r12,%r10,8),%rax
   2dfbb:	mov    %rax,0x8(%r13)
   2dfbf:	addq   $0xfffffffffffffffe,0x108(%r13)
   2dfc7:	movabs $0xff00000000000000,%r14
   2dfd1:	mov    %rbp,%rbx
   2dfd4:	and    %r14,%rbx
   2dfd7:	mov    %rbp,%rax
   2dfda:	movabs $0x200000000000000,%rbp
   2dfe4:	mov    %rax,%r9
   2dfe7:	cmp    %rbp,%rbx
   2dfea:	je     2ffd7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5017>
   2dff0:	mov    %rax,(%r12,%r10,8)
   2dff4:	mov    %r15,%rax
   2dff7:	and    %r14,%rax
   2dffa:	cmp    %rbp,%rax
   2dffd:	je     2ffff <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x503f>
   2e003:	mov    %r15,0x8(%r12,%r10,8)
   2e008:	movabs $0x2002c0000000000,%rcx
   2e012:	mov    0x10(%r13),%r8
   2e016:	test   %r8,%r8
   2e019:	je     3002a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x506a>
   2e01f:	mov    (%r12,%r8,8),%rax
   2e023:	mov    %rax,0x10(%r13)
   2e027:	addq   $0xfffffffffffffffc,0x110(%r13)
   2e02f:	or     %rcx,%r10
   2e032:	mov    %r11,%rax
   2e035:	and    %r14,%rax
   2e038:	cmp    %rbp,%rax
   2e03b:	je     3004e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x508e>
   2e041:	mov    %r11,(%r12,%r8,8)
   2e045:	mov    %r10,%rax
   2e048:	shr    $0x38,%rax
   2e04c:	cmp    $0x2,%eax
   2e04f:	jbe    3006f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x50af>
   2e055:	mov    %r10,0x8(%r12,%r8,8)
   2e05a:	movabs $0x1002b0000000000,%rax
   2e064:	mov    %rax,0x10(%r12,%r8,8)
   2e069:	mov    0x0(%r13),%r15
   2e06d:	test   %r15,%r15
   2e070:	je     30090 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x50d0>
   2e076:	mov    (%r12,%r15,8),%rax
   2e07a:	mov    %rax,0x0(%r13)
   2e07e:	decq   0x100(%r13)
   2e085:	cmp    %rbp,%rbx
   2e088:	je     300af <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x50ef>
   2e08e:	mov    %r9,(%r12,%r15,8)
   2e092:	movabs $0x2000c0000000000,%rcx
   2e09c:	mov    0x8(%r13),%r10
   2e0a0:	test   %r10,%r10
   2e0a3:	je     300d0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5110>
   2e0a9:	mov    (%r12,%r10,8),%rax
   2e0ad:	mov    %rax,0x8(%r13)
   2e0b1:	addq   $0xfffffffffffffffe,0x108(%r13)
   2e0b9:	movabs $0x300000000000000,%rbx
   2e0c3:	or     %rcx,%r15
   2e0c6:	and    %rdi,%r14
   2e0c9:	cmp    %rbp,%r14
   2e0cc:	je     300ee <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x512e>
   2e0d2:	movabs $0x2002d0000000000,%r14
   2e0dc:	mov    %rdi,(%r12,%r10,8)
   2e0e0:	cmp    %rbx,%r15
   2e0e3:	jb     3011b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x515b>
   2e0e9:	or     %r14,%r8
   2e0ec:	movabs $0x200080000000000,%rsi
   2e0f6:	mov    %r15,0x8(%r12,%r10,8)
   2e0fb:	mov    0x8(%r13),%r9
   2e0ff:	test   %r9,%r9
   2e102:	je     30136 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5176>
   2e108:	mov    (%r12,%r9,8),%rax
   2e10c:	mov    %rax,0x8(%r13)
   2e110:	addq   $0xfffffffffffffffe,0x108(%r13)
   2e118:	mov    (%rsp),%r14
   2e11c:	or     %rsi,%r10
   2e11f:	cmp    %rbx,%r8
   2e122:	jb     2fef6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4f36>
   2e128:	mov    %r8,(%r12,%r9,8)
   2e12c:	cmp    %rbx,%r10
   2e12f:	jb     2ff23 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4f63>
   2e135:	mov    %r10,0x8(%r12,%r9,8)
   2e13a:	or     %r9,%rsi
   2e13d:	mov    -0x8(%r14),%eax
   2e141:	add    $0xfffffffffffffff8,%r14
   2e145:	lea    0x19764(%rip),%rcx        # 478b0 <wl_tab>
   2e14c:	mov    (%rcx,%rax,8),%rax
   2e150:	mov    0x30(%rsp),%r15d
   2e155:	mov    $0x1,%edi
   2e15a:	add    $0x50,%rsp
   2e15e:	pop    %rbp
   2e15f:	jmpq   *%rax
   2e161:	mov    (%rsp),%rbp
   2e165:	mov    -0x18(%rbp),%rcx
   2e169:	mov    %r8,0x40(%rsp)
   2e16e:	mov    -0x10(%rbp),%r8d
   2e172:	mov    %r12,%rdi
   2e175:	mov    %r13,%rsi
   2e178:	mov    $0x144,%edx
   2e17d:	mov    $0x1,%r9d
   2e183:	mov    %rbx,0x10(%rsp)
   2e188:	mov    %r11,%rbx
   2e18b:	mov    %r10,%r14
   2e18e:	callq  caf0 <task_node>
   2e193:	mov    0x40(%rsp),%r8
   2e198:	mov    %r14,%r10
   2e19b:	mov    %rbx,(%r12,%rax,8)
   2e19f:	mov    0x10(%rsp),%rbx
   2e1a4:	movabs $0x1002b0000000000,%rcx
   2e1ae:	mov    %rcx,0x8(%r12,%rax,8)
   2e1b3:	movabs $0x501440000000000,%rcx
   2e1bd:	or     %rax,%rcx
   2e1c0:	mov    %rcx,-0x18(%rbp)
   2e1c4:	movq   $0x2,-0x10(%rbp)
   2e1cc:	test   %rbx,%rbx
   2e1cf:	js     2e204 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3244>
   2e1d1:	mov    %rbx,%rax
   2e1d4:	shr    $0x39,%rax
   2e1d8:	sete   %al
   2e1db:	and    %rbx,%r10
   2e1de:	cmp    $0x3108280,%r10
   2e1e5:	setb   %cl
   2e1e8:	or     %al,%cl
   2e1ea:	jne    2e21f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x325f>
   2e1ec:	mov    %r12,%rdi
   2e1ef:	mov    %r13,%rsi
   2e1f2:	mov    %rbx,%rdx
   2e1f5:	mov    $0x2,%ecx
   2e1fa:	callq  4574e <rfc_wrap>
   2e1ff:	mov    %rax,%rbx
   2e202:	jmp    2e21f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x325f>
   2e204:	and    %rbx,%r8
   2e207:	mov    $0x1,%eax
   2e20c:	lock xadd %eax,(%r12,%r8,8)
   2e212:	not    %eax
   2e214:	test   $0xfffffe,%eax
   2e219:	je     31afb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6b3b>
   2e21f:	mov    0x10(%r13),%r8
   2e223:	test   %r8,%r8
   2e226:	je     30154 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5194>
   2e22c:	mov    (%r12,%r8,8),%rax
   2e230:	mov    %rax,0x10(%r13)
   2e234:	addq   $0xfffffffffffffffc,0x110(%r13)
   2e23c:	movabs $0xff00000000000000,%r9
   2e246:	mov    %rbx,%rcx
   2e249:	shr    $0x38,%rcx
   2e24d:	mov    %rbx,%rax
   2e250:	cmp    $0x2,%ecx
   2e253:	je     3016c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x51ac>
   2e259:	mov    %rax,(%r12,%r8,8)
   2e25d:	mov    0x18(%rsp),%rdx
   2e262:	mov    %rdx,%rax
   2e265:	and    %r9,%rax
   2e268:	movabs $0x200000000000000,%r10
   2e272:	cmp    %r10,%rax
   2e275:	je     30184 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x51c4>
   2e27b:	mov    %rdx,0x8(%r12,%r8,8)
   2e280:	mov    0x8(%rsp),%rax
   2e285:	and    %rax,%r9
   2e288:	mov    %rbx,%rbp
   2e28b:	cmp    %r10,%r9
   2e28e:	je     3019c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x51dc>
   2e294:	movabs $0x2002d0000000000,%rbx
   2e29e:	or     %r8,%rbx
   2e2a1:	mov    %rax,0x10(%r12,%r8,8)
   2e2a6:	test   %r15d,%r15d
   2e2a9:	je     2e313 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3353>
   2e2ab:	mov    (%rsp),%r14
   2e2af:	mov    %rbx,(%r14)
   2e2b2:	movq   $0x145,0x8(%r14)
   2e2ba:	add    $0x10,%r14
   2e2be:	jmpq   2e355 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3395>
   2e2c3:	mov    -0x18(%r14),%rcx
   2e2c7:	mov    -0x10(%r14),%r8d
   2e2cb:	mov    %r12,%rdi
   2e2ce:	mov    %r13,%rsi
   2e2d1:	mov    $0x135,%edx
   2e2d6:	mov    $0x1,%r9d
   2e2dc:	callq  caf0 <task_node>
   2e2e1:	mov    %rbx,(%r12,%rax,8)
   2e2e5:	movabs $0x501350000000000,%rcx
   2e2ef:	or     %rax,%rcx
   2e2f2:	mov    %rcx,-0x18(%r14)
   2e2f6:	movq   $0x1,-0x10(%r14)
   2e2fe:	xor    %r15d,%r15d
   2e301:	mov    0x18(%rsp),%rsi
   2e306:	mov    %rbp,%rdx
   2e309:	add    $0x50,%rsp
   2e30d:	pop    %rbp
   2e30e:	jmpq   1b760 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
   2e313:	mov    (%rsp),%r14
   2e317:	mov    -0x18(%r14),%rcx
   2e31b:	mov    -0x10(%r14),%r8d
   2e31f:	mov    %r12,%rdi
   2e322:	mov    %r13,%rsi
   2e325:	mov    $0x145,%edx
   2e32a:	mov    $0x1,%r9d
   2e330:	callq  caf0 <task_node>
   2e335:	mov    %rbx,(%r12,%rax,8)
   2e339:	movabs $0x501450000000000,%rcx
   2e343:	or     %rax,%rcx
   2e346:	mov    %rcx,-0x18(%r14)
   2e34a:	movq   $0x1,-0x10(%r14)
   2e352:	xor    %r15d,%r15d
   2e355:	mov    0x20(%rsp),%rsi
   2e35a:	mov    %rbp,%rdx
   2e35d:	add    $0x50,%rsp
   2e361:	pop    %rbp
   2e362:	jmpq   1b760 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
   2e367:	mov    %r12,%rdi
   2e36a:	mov    %r13,%rsi
   2e36d:	mov    %rdx,%r8
   2e370:	xor    %edx,%edx
   2e372:	mov    %r11,%rbx
   2e375:	callq  45321 <heap_hand>
   2e37a:	mov    %rbx,%r11
   2e37d:	mov    %r8,%rdx
   2e380:	mov    %r9,%r8
   2e383:	cmp    $0x3108280,%rcx
   2e38a:	jae    2b0f5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x135>
   2e390:	jmpq   2b12d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16d>
   2e395:	mov    %r12,%rdi
   2e398:	mov    %r13,%rsi
   2e39b:	mov    %rdx,%rax
   2e39e:	xor    %edx,%edx
   2e3a0:	callq  45321 <heap_hand>
   2e3a5:	mov    %rax,%rdx
   2e3a8:	cmp    $0x3108280,%rcx
   2e3af:	jae    2b22f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26f>
   2e3b5:	jmpq   2b266 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a6>
   2e3ba:	mov    %r12,%rdi
   2e3bd:	mov    %r13,%rsi
   2e3c0:	mov    %rdx,%rcx
   2e3c3:	mov    $0x1,%edx
   2e3c8:	mov    %r8,%r9
   2e3cb:	mov    %r11,%r8
   2e3ce:	callq  45321 <heap_hand>
   2e3d3:	mov    %r8,%r11
   2e3d6:	mov    %r9,%r8
   2e3d9:	mov    %rcx,%rdx
   2e3dc:	jmpq   2b465 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a5>
   2e3e1:	mov    %r12,%rdi
   2e3e4:	mov    %r13,%rsi
   2e3e7:	mov    %rdx,%rcx
   2e3ea:	mov    $0x2,%edx
   2e3ef:	mov    %r8,%r9
   2e3f2:	mov    %r11,%r8
   2e3f5:	callq  45321 <heap_hand>
   2e3fa:	mov    %r8,%r11
   2e3fd:	mov    %r9,%r8
   2e400:	mov    %rcx,%rdx
   2e403:	jmpq   2b58d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5cd>
   2e408:	shl    $0x20,%rcx
   2e40c:	or     %rdi,%rcx
   2e40f:	shr    $0x18,%rcx
   2e413:	mov    (%r12,%rcx,8),%rsi
   2e417:	mov    %rsi,0x20(%rsp)
   2e41c:	mov    0x8(%r12,%rcx,8),%rsi
   2e421:	mov    %rsi,0x8(%rsp)
   2e426:	mov    %r12,%rdi
   2e429:	mov    %r13,%rsi
   2e42c:	mov    %rdx,%r9
   2e42f:	mov    %rbp,%rdx
   2e432:	mov    %r8,%rbp
   2e435:	mov    $0x2,%r8d
   2e43b:	mov    %r10,%rbx
   2e43e:	mov    %r11,%r10
   2e441:	callq  453b2 <span_fade>
   2e446:	mov    %rbp,%r8
   2e449:	mov    0x20(%rsp),%rbp
   2e44e:	mov    %r10,%r11
   2e451:	mov    %rbx,%r10
   2e454:	mov    0x8(%rsp),%rbx
   2e459:	mov    %r9,%rdx
   2e45c:	jmpq   2b465 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a5>
   2e461:	shl    $0x20,%rcx
   2e465:	or     %rdx,%rcx
   2e468:	shr    $0x18,%rcx
   2e46c:	mov    (%r12,%rcx,8),%rdx
   2e470:	mov    %rdx,0x10(%rsp)
   2e475:	mov    0x8(%r12,%rcx,8),%rdx
   2e47a:	mov    %rdx,0x18(%rsp)
   2e47f:	mov    0x10(%r12,%rcx,8),%rdx
   2e484:	mov    %rdx,0x8(%rsp)
   2e489:	mov    %r12,%rdi
   2e48c:	mov    %r13,%rsi
   2e48f:	mov    %rbp,%rdx
   2e492:	mov    %r8,%rbp
   2e495:	mov    $0x3,%r8d
   2e49b:	mov    %r10,%rbx
   2e49e:	mov    %r11,%r10
   2e4a1:	callq  453b2 <span_fade>
   2e4a6:	mov    %rbp,%r8
   2e4a9:	mov    %r10,%r11
   2e4ac:	mov    %rbx,%r10
   2e4af:	mov    0x10(%rsp),%rbx
   2e4b4:	mov    %r9,%rdx
   2e4b7:	jmpq   2b58d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5cd>
   2e4bc:	mov    %r12,%rdi
   2e4bf:	mov    %r13,%rsi
   2e4c2:	mov    %rbp,0x20(%rsp)
   2e4c7:	mov    %rbx,%rbp
   2e4ca:	mov    %r8,%rbx
   2e4cd:	mov    %rdx,%r8
   2e4d0:	xor    %edx,%edx
   2e4d2:	mov    %r11,%r9
   2e4d5:	callq  45321 <heap_hand>
   2e4da:	mov    %r9,%r11
   2e4dd:	mov    %r8,%rdx
   2e4e0:	mov    %rbx,%r8
   2e4e3:	mov    %rbp,%rbx
   2e4e6:	mov    0x20(%rsp),%rbp
   2e4eb:	cmp    $0x3108280,%rcx
   2e4f2:	jae    2b42d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x46d>
   2e4f8:	jmpq   2b465 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a5>
   2e4fd:	mov    %r12,%rdi
   2e500:	mov    %r13,%rsi
   2e503:	xor    %edx,%edx
   2e505:	mov    %rbx,%rbp
   2e508:	mov    %r8,%rbx
   2e50b:	mov    %r11,%r8
   2e50e:	callq  45321 <heap_hand>
   2e513:	mov    %r8,%r11
   2e516:	mov    %rbx,%r8
   2e519:	mov    %rbp,%rbx
   2e51c:	mov    %r9,%rdx
   2e51f:	cmp    $0x3108280,%rcx
   2e526:	jae    2b555 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x595>
   2e52c:	jmpq   2b58d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5cd>
   2e531:	mov    %r12,%rdi
   2e534:	mov    %rsi,%rbp
   2e537:	mov    %r13,%rsi
   2e53a:	mov    %rdx,%r10
   2e53d:	mov    $0x2,%edx
   2e542:	mov    %r11,%rcx
   2e545:	callq  45448 <heap_alloc_miss>
   2e54a:	mov    %rbp,%rsi
   2e54d:	mov    %r10,%rdx
   2e550:	mov    %rcx,%r11
   2e553:	mov    %rax,%r10
   2e556:	jmpq   2d7c5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2805>
   2e55b:	mov    %r12,%rdi
   2e55e:	mov    %r13,%rsi
   2e561:	mov    %r11,%rdx
   2e564:	mov    $0x1,%ecx
   2e569:	callq  4574e <rfc_wrap>
   2e56e:	movabs $0x2002d0000000000,%rsi
   2e578:	movabs $0x1000b0000000000,%rdx
   2e582:	mov    %rax,%r11
   2e585:	jmpq   2d7de <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x281e>
   2e58a:	mov    %r12,%rdi
   2e58d:	mov    %rsi,%rbx
   2e590:	mov    %r13,%rsi
   2e593:	mov    %rdx,%rcx
   2e596:	mov    $0x1,%edx
   2e59b:	callq  45448 <heap_alloc_miss>
   2e5a0:	mov    %rbx,%rsi
   2e5a3:	mov    %rcx,%rdx
   2e5a6:	mov    %rax,%rbx
   2e5a9:	and    %r9,%r15
   2e5ac:	cmp    %rbp,%r15
   2e5af:	jne    2d815 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2855>
   2e5b5:	mov    %r12,%rdi
   2e5b8:	mov    %rsi,%rbp
   2e5bb:	mov    %r13,%rsi
   2e5be:	mov    %rdx,%r15
   2e5c1:	mov    %r9,%rdx
   2e5c4:	mov    $0x1,%ecx
   2e5c9:	callq  4574e <rfc_wrap>
   2e5ce:	mov    %rbp,%rsi
   2e5d1:	mov    %r15,%rdx
   2e5d4:	mov    %rax,%r9
   2e5d7:	jmpq   2d815 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2855>
   2e5dc:	mov    %r12,%rdi
   2e5df:	mov    %r13,%rsi
   2e5e2:	mov    $0x1,%edx
   2e5e7:	callq  45448 <heap_alloc_miss>
   2e5ec:	mov    %rax,%r9
   2e5ef:	or     %r8,%rbx
   2e5f2:	cmp    %r14,%r10
   2e5f5:	jae    2d84a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x288a>
   2e5fb:	mov    %r12,%rdi
   2e5fe:	mov    %r13,%rsi
   2e601:	mov    %r10,%rdx
   2e604:	mov    $0x1,%ecx
   2e609:	callq  4574e <rfc_wrap>
   2e60e:	mov    %rax,%r10
   2e611:	mov    %r10,(%r12,%r9,8)
   2e615:	cmp    %r14,%rbx
   2e618:	jae    2d857 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2897>
   2e61e:	mov    %r12,%rdi
   2e621:	mov    %r13,%rsi
   2e624:	mov    %rbx,%rdx
   2e627:	mov    $0x1,%ecx
   2e62c:	callq  4574e <rfc_wrap>
   2e631:	mov    %rax,%rbx
   2e634:	jmpq   2d857 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2897>
   2e639:	mov    %r12,%rdi
   2e63c:	mov    %r13,%rsi
   2e63f:	mov    $0x1,%edx
   2e644:	callq  45448 <heap_alloc_miss>
   2e649:	mov    %rax,%rbp
   2e64c:	jmpq   2c0dc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x111c>
   2e651:	mov    %r12,%rdi
   2e654:	mov    %r13,%rsi
   2e657:	mov    %r8,%rdx
   2e65a:	mov    $0x1,%ecx
   2e65f:	callq  4574e <rfc_wrap>
   2e664:	mov    %rax,%r8
   2e667:	jmpq   2c0f6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1136>
   2e66c:	mov    %r12,%rdi
   2e66f:	mov    %r13,%rsi
   2e672:	mov    %rbx,%rdx
   2e675:	mov    $0x1,%ecx
   2e67a:	callq  4574e <rfc_wrap>
   2e67f:	mov    %rax,%rbx
   2e682:	jmpq   2c113 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1153>
   2e687:	mov    %r12,%rdi
   2e68a:	mov    %r13,%rsi
   2e68d:	mov    $0x1,%edx
   2e692:	callq  45448 <heap_alloc_miss>
   2e697:	mov    %rax,%r10
   2e69a:	jmpq   2c146 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1186>
   2e69f:	mov    %r12,%rdi
   2e6a2:	mov    %r13,%rsi
   2e6a5:	mov    %r15,%rdx
   2e6a8:	mov    $0x1,%ecx
   2e6ad:	callq  4574e <rfc_wrap>
   2e6b2:	movabs $0x200000000000000,%rsi
   2e6bc:	mov    0x8(%rsp),%rcx
   2e6c1:	mov    0x38(%rsp),%rdx
   2e6c6:	jmpq   2c16c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x11ac>
   2e6cb:	mov    %r12,%rdi
   2e6ce:	mov    %r13,%rsi
   2e6d1:	mov    %rcx,%rdx
   2e6d4:	mov    $0x1,%ecx
   2e6d9:	callq  4574e <rfc_wrap>
   2e6de:	movabs $0x200000000000000,%rsi
   2e6e8:	mov    0x38(%rsp),%rdx
   2e6ed:	mov    %rax,%rcx
   2e6f0:	jmpq   2c17f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x11bf>
   2e6f5:	mov    %r12,%rdi
   2e6f8:	mov    %r13,%rsi
   2e6fb:	mov    $0x2,%edx
   2e700:	callq  45448 <heap_alloc_miss>
   2e705:	movabs $0x200000000000000,%rsi
   2e70f:	mov    0x38(%rsp),%rdx
   2e714:	mov    %rax,%r8
   2e717:	jmpq   2c1ab <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x11eb>
   2e71c:	mov    %r12,%rdi
   2e71f:	mov    %r13,%rsi
   2e722:	mov    $0x1,%ecx
   2e727:	callq  4574e <rfc_wrap>
   2e72c:	movabs $0x200000000000000,%rsi
   2e736:	mov    %rax,%rdx
   2e739:	jmpq   2c1bd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x11fd>
   2e73e:	mov    %rdi,%rbx
   2e741:	mov    %r12,%rdi
   2e744:	mov    %r13,%rsi
   2e747:	mov    %rbp,%rdx
   2e74a:	mov    $0x1,%ecx
   2e74f:	callq  4574e <rfc_wrap>
   2e754:	mov    %rbx,%rdi
   2e757:	movabs $0x200000000000000,%rsi
   2e761:	mov    %rax,%rbp
   2e764:	mov    %rbp,0x8(%r12,%r8,8)
   2e769:	cmp    %rdi,%r10
   2e76c:	jae    2c1ec <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x122c>
   2e772:	mov    %rdi,%rbx
   2e775:	mov    %r12,%rdi
   2e778:	mov    %r13,%rsi
   2e77b:	mov    %r10,%rdx
   2e77e:	mov    $0x1,%ecx
   2e783:	callq  4574e <rfc_wrap>
   2e788:	mov    %rbx,%rdi
   2e78b:	movabs $0x200000000000000,%rsi
   2e795:	mov    %rax,%r10
   2e798:	mov    %r10,0x10(%r12,%r8,8)
   2e79d:	mov    0x0(%r13),%r10
   2e7a1:	test   %r10,%r10
   2e7a4:	jne    2c1fe <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x123e>
   2e7aa:	mov    %rdi,%rcx
   2e7ad:	mov    %r12,%rdi
   2e7b0:	mov    %r13,%rsi
   2e7b3:	xor    %edx,%edx
   2e7b5:	callq  45448 <heap_alloc_miss>
   2e7ba:	mov    %rcx,%rdi
   2e7bd:	movabs $0x200000000000000,%rsi
   2e7c7:	mov    %rax,%r10
   2e7ca:	cmp    %rsi,%r9
   2e7cd:	jne    2c216 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1256>
   2e7d3:	mov    %rdi,%r9
   2e7d6:	mov    %r12,%rdi
   2e7d9:	mov    %r13,%rsi
   2e7dc:	mov    %r15,%rdx
   2e7df:	mov    $0x1,%ecx
   2e7e4:	callq  4574e <rfc_wrap>
   2e7e9:	mov    %r9,%rdi
   2e7ec:	movabs $0x200000000000000,%rsi
   2e7f6:	mov    %rax,%r15
   2e7f9:	jmpq   2c216 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1256>
   2e7fe:	mov    %rdi,%r9
   2e801:	mov    %r12,%rdi
   2e804:	mov    %r13,%rsi
   2e807:	mov    $0x1,%edx
   2e80c:	callq  45448 <heap_alloc_miss>
   2e811:	mov    %r9,%rdi
   2e814:	movabs $0x200000000000000,%rsi
   2e81e:	mov    %rax,%r9
   2e821:	jmpq   2c241 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1281>
   2e826:	mov    %rdi,%rbx
   2e829:	mov    %r12,%rdi
   2e82c:	mov    %r13,%rsi
   2e82f:	mov    %rax,%rdx
   2e832:	mov    $0x1,%ecx
   2e837:	callq  4574e <rfc_wrap>
   2e83c:	mov    %rbx,%rdi
   2e83f:	jmpq   2c255 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1295>
   2e844:	mov    %rdi,%r15
   2e847:	mov    %r12,%rdi
   2e84a:	mov    %r13,%rsi
   2e84d:	mov    %r10,%rdx
   2e850:	mov    $0x1,%ecx
   2e855:	callq  4574e <rfc_wrap>
   2e85a:	mov    %r15,%rdi
   2e85d:	mov    %rax,%r10
   2e860:	jmpq   2c270 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x12b0>
   2e865:	mov    %rdi,%r10
   2e868:	mov    %r12,%rdi
   2e86b:	mov    %rsi,%rcx
   2e86e:	mov    %r13,%rsi
   2e871:	mov    $0x1,%edx
   2e876:	callq  45448 <heap_alloc_miss>
   2e87b:	mov    %r10,%rdi
   2e87e:	mov    %rcx,%rsi
   2e881:	mov    %rax,%r10
   2e884:	or     %rsi,%r9
   2e887:	cmp    %rdi,%r8
   2e88a:	jae    2c2ab <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x12eb>
   2e890:	mov    %rdi,%r15
   2e893:	mov    %r12,%rdi
   2e896:	mov    %rsi,%rbx
   2e899:	mov    %r13,%rsi
   2e89c:	mov    %r8,%rdx
   2e89f:	mov    $0x1,%ecx
   2e8a4:	callq  4574e <rfc_wrap>
   2e8a9:	mov    %r15,%rdi
   2e8ac:	mov    %rbx,%rsi
   2e8af:	mov    %rax,%r8
   2e8b2:	mov    %r8,(%r12,%r10,8)
   2e8b6:	cmp    %rdi,%r9
   2e8b9:	jae    2c2b8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x12f8>
   2e8bf:	jmpq   2c9f0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a30>
   2e8c4:	mov    %r12,%rdi
   2e8c7:	mov    %r13,%rsi
   2e8ca:	mov    $0x1,%edx
   2e8cf:	mov    %r11,%rcx
   2e8d2:	callq  45448 <heap_alloc_miss>
   2e8d7:	mov    %rcx,%r11
   2e8da:	mov    %rax,%r8
   2e8dd:	jmpq   2c5ed <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x162d>
   2e8e2:	mov    %r12,%rdi
   2e8e5:	mov    %r13,%rsi
   2e8e8:	mov    %rbp,%rdx
   2e8eb:	mov    $0x1,%ecx
   2e8f0:	mov    %r11,%r9
   2e8f3:	callq  4574e <rfc_wrap>
   2e8f8:	mov    %r9,%r11
   2e8fb:	mov    %rax,%rbp
   2e8fe:	jmpq   2c607 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1647>
   2e903:	mov    %r12,%rdi
   2e906:	mov    %r13,%rsi
   2e909:	mov    %rbx,%rdx
   2e90c:	mov    $0x1,%ecx
   2e911:	mov    %r11,%r9
   2e914:	callq  4574e <rfc_wrap>
   2e919:	mov    %r9,%r11
   2e91c:	mov    %rax,%rbx
   2e91f:	jmpq   2c624 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1664>
   2e924:	mov    %r12,%rdi
   2e927:	mov    %r13,%rsi
   2e92a:	mov    $0x2,%edx
   2e92f:	mov    %r11,%rcx
   2e932:	callq  45448 <heap_alloc_miss>
   2e937:	mov    %rcx,%r11
   2e93a:	mov    %rax,%rbp
   2e93d:	jmpq   2c7f5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1835>
   2e942:	mov    %r12,%rdi
   2e945:	mov    %r13,%rsi
   2e948:	mov    %rbx,%rdx
   2e94b:	mov    $0x1,%ecx
   2e950:	mov    %r11,%r8
   2e953:	callq  4574e <rfc_wrap>
   2e958:	mov    0x18(%rsp),%rcx
   2e95d:	mov    0x8(%rsp),%rdx
   2e962:	mov    %r8,%r11
   2e965:	mov    %rax,%rbx
   2e968:	jmpq   2c819 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1859>
   2e96d:	mov    %r12,%rdi
   2e970:	mov    %rsi,%r10
   2e973:	mov    %r13,%rsi
   2e976:	mov    %rcx,%rdx
   2e979:	mov    $0x1,%ecx
   2e97e:	mov    %r11,%r8
   2e981:	callq  4574e <rfc_wrap>
   2e986:	mov    %r10,%rsi
   2e989:	mov    0x8(%rsp),%rdx
   2e98e:	mov    %r8,%r11
   2e991:	mov    %rax,%rcx
   2e994:	jmpq   2c836 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1876>
   2e999:	mov    %r12,%rdi
   2e99c:	mov    %r13,%rsi
   2e99f:	mov    $0x1,%ecx
   2e9a4:	callq  4574e <rfc_wrap>
   2e9a9:	mov    %rax,%rdx
   2e9ac:	jmpq   2c84d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x188d>
   2e9b1:	mov    %r12,%rdi
   2e9b4:	mov    %r13,%rsi
   2e9b7:	mov    $0x1,%edx
   2e9bc:	callq  45448 <heap_alloc_miss>
   2e9c1:	mov    %rax,%r10
   2e9c4:	jmpq   2c880 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x18c0>
   2e9c9:	mov    %r12,%rdi
   2e9cc:	mov    %r13,%rsi
   2e9cf:	mov    %r15,%rdx
   2e9d2:	mov    $0x1,%ecx
   2e9d7:	callq  4574e <rfc_wrap>
   2e9dc:	movabs $0x200000000000000,%rsi
   2e9e6:	mov    0x10(%rsp),%rcx
   2e9eb:	mov    %rbx,%rdx
   2e9ee:	jmpq   2c8a4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x18e4>
   2e9f3:	mov    %r12,%rdi
   2e9f6:	mov    %r13,%rsi
   2e9f9:	mov    %rcx,%rdx
   2e9fc:	mov    $0x1,%ecx
   2ea01:	callq  4574e <rfc_wrap>
   2ea06:	movabs $0x200000000000000,%rsi
   2ea10:	mov    %rbx,%rdx
   2ea13:	mov    %rax,%rcx
   2ea16:	jmpq   2c8b7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x18f7>
   2ea1b:	mov    %rdi,%rcx
   2ea1e:	mov    %r12,%rdi
   2ea21:	mov    %r13,%rsi
   2ea24:	mov    $0x2,%edx
   2ea29:	callq  45448 <heap_alloc_miss>
   2ea2e:	mov    %rcx,%rdi
   2ea31:	movabs $0x200000000000000,%rsi
   2ea3b:	mov    %rbx,%rdx
   2ea3e:	mov    %rax,%r8
   2ea41:	jmpq   2c8e3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1923>
   2ea46:	mov    %r12,%rdi
   2ea49:	mov    %r13,%rsi
   2ea4c:	mov    $0x1,%ecx
   2ea51:	callq  4574e <rfc_wrap>
   2ea56:	movabs $0x2002d0000000000,%rdi
   2ea60:	movabs $0x200000000000000,%rsi
   2ea6a:	mov    %rax,%rdx
   2ea6d:	jmpq   2c8ff <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x193f>
   2ea72:	mov    %rdi,%rbx
   2ea75:	mov    %r12,%rdi
   2ea78:	mov    %r13,%rsi
   2ea7b:	mov    %rbp,%rdx
   2ea7e:	mov    $0x1,%ecx
   2ea83:	mov    %r11,%rbp
   2ea86:	callq  4574e <rfc_wrap>
   2ea8b:	mov    %rbp,%r11
   2ea8e:	mov    %rbx,%rdi
   2ea91:	movabs $0x200000000000000,%rsi
   2ea9b:	mov    %rax,%rbp
   2ea9e:	mov    %rbp,0x8(%r12,%r8,8)
   2eaa3:	cmp    %r11,%r10
   2eaa6:	jae    2c92e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x196e>
   2eaac:	mov    %rdi,%rbx
   2eaaf:	mov    %r12,%rdi
   2eab2:	mov    %r13,%rsi
   2eab5:	mov    %r10,%rdx
   2eab8:	mov    $0x1,%ecx
   2eabd:	mov    %r11,%r10
   2eac0:	callq  4574e <rfc_wrap>
   2eac5:	mov    %r10,%r11
   2eac8:	mov    %rbx,%rdi
   2eacb:	movabs $0x200000000000000,%rsi
   2ead5:	mov    %rax,%r10
   2ead8:	jmpq   2c92e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x196e>
   2eadd:	mov    %rdi,%rcx
   2eae0:	mov    %r12,%rdi
   2eae3:	mov    %r13,%rsi
   2eae6:	xor    %edx,%edx
   2eae8:	mov    %r11,%r10
   2eaeb:	callq  45448 <heap_alloc_miss>
   2eaf0:	mov    %r10,%r11
   2eaf3:	mov    %rcx,%rdi
   2eaf6:	movabs $0x200000000000000,%rsi
   2eb00:	mov    %rax,%r10
   2eb03:	cmp    %rsi,%r9
   2eb06:	jne    2c95d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x199d>
   2eb0c:	mov    %rdi,%r9
   2eb0f:	mov    %r12,%rdi
   2eb12:	mov    %r13,%rsi
   2eb15:	mov    %r15,%rdx
   2eb18:	mov    $0x1,%ecx
   2eb1d:	mov    %r11,%r15
   2eb20:	callq  4574e <rfc_wrap>
   2eb25:	mov    %r15,%r11
   2eb28:	mov    %r9,%rdi
   2eb2b:	movabs $0x200000000000000,%rsi
   2eb35:	mov    %rax,%r15
   2eb38:	jmpq   2c95d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x199d>
   2eb3d:	mov    %rdi,%r9
   2eb40:	mov    %r12,%rdi
   2eb43:	mov    %r13,%rsi
   2eb46:	mov    $0x1,%edx
   2eb4b:	mov    %r11,%r15
   2eb4e:	callq  45448 <heap_alloc_miss>
   2eb53:	mov    %r15,%r11
   2eb56:	mov    %r9,%rdi
   2eb59:	movabs $0x200000000000000,%rsi
   2eb63:	mov    %rax,%r9
   2eb66:	or     %rcx,%r10
   2eb69:	and    %rbx,%r14
   2eb6c:	cmp    %rsi,%r14
   2eb6f:	jne    2c997 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x19d7>
   2eb75:	mov    %rdi,%r14
   2eb78:	mov    %r12,%rdi
   2eb7b:	mov    %r13,%rsi
   2eb7e:	mov    %rbx,%rdx
   2eb81:	mov    $0x1,%ecx
   2eb86:	mov    %r11,%rbx
   2eb89:	callq  4574e <rfc_wrap>
   2eb8e:	mov    %rbx,%r11
   2eb91:	mov    %r14,%rdi
   2eb94:	mov    %rax,%rbx
   2eb97:	mov    (%rsp),%r14
   2eb9b:	mov    %rbx,(%r12,%r9,8)
   2eb9f:	cmp    %r11,%r10
   2eba2:	jae    2c9a8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x19e8>
   2eba8:	mov    %rdi,%rbx
   2ebab:	mov    %r12,%rdi
   2ebae:	mov    %r13,%rsi
   2ebb1:	mov    %r10,%rdx
   2ebb4:	mov    $0x1,%ecx
   2ebb9:	mov    %r11,%r10
   2ebbc:	callq  4574e <rfc_wrap>
   2ebc1:	mov    %r10,%r11
   2ebc4:	mov    %rbx,%rdi
   2ebc7:	mov    %rax,%r10
   2ebca:	jmpq   2c9a8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x19e8>
   2ebcf:	mov    %r12,%rdi
   2ebd2:	mov    %rsi,%rcx
   2ebd5:	mov    %r13,%rsi
   2ebd8:	mov    $0x1,%edx
   2ebdd:	mov    %r11,%r10
   2ebe0:	callq  45448 <heap_alloc_miss>
   2ebe5:	mov    %r10,%r11
   2ebe8:	mov    %rcx,%rsi
   2ebeb:	mov    %rax,%r10
   2ebee:	or     %rsi,%r9
   2ebf1:	cmp    %r11,%r8
   2ebf4:	jae    2c9e3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a23>
   2ebfa:	mov    %r12,%rdi
   2ebfd:	mov    %rsi,%rbx
   2ec00:	mov    %r13,%rsi
   2ec03:	mov    %r8,%rdx
   2ec06:	mov    $0x1,%ecx
   2ec0b:	mov    %r11,%r8
   2ec0e:	callq  4574e <rfc_wrap>
   2ec13:	mov    %r8,%r11
   2ec16:	mov    %rbx,%rsi
   2ec19:	mov    %rax,%r8
   2ec1c:	mov    %r8,(%r12,%r10,8)
   2ec20:	cmp    %r11,%r9
   2ec23:	jae    2c2b8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x12f8>
   2ec29:	jmpq   2c9f0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a30>
   2ec2e:	mov    %r12,%rdi
   2ec31:	mov    %r13,%rsi
   2ec34:	mov    $0x2,%edx
   2ec39:	callq  45448 <heap_alloc_miss>
   2ec3e:	mov    %rax,%r8
   2ec41:	jmpq   2d9c0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a00>
   2ec46:	mov    %r12,%rdi
   2ec49:	mov    %r13,%rsi
   2ec4c:	mov    %rbx,%rdx
   2ec4f:	mov    $0x1,%ecx
   2ec54:	callq  4574e <rfc_wrap>
   2ec59:	mov    0x8(%rsp),%rdx
   2ec5e:	jmpq   2d9dc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a1c>
   2ec63:	mov    %r12,%rdi
   2ec66:	mov    %r13,%rsi
   2ec69:	mov    %rax,%rdx
   2ec6c:	mov    $0x1,%ecx
   2ec71:	callq  4574e <rfc_wrap>
   2ec76:	mov    0x8(%rsp),%rdx
   2ec7b:	mov    %rax,0x8(%r12,%r8,8)
   2ec80:	and    %rdx,%r14
   2ec83:	cmp    %rbp,%r14
   2ec86:	jne    2da05 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a45>
   2ec8c:	mov    %r12,%rdi
   2ec8f:	mov    %r13,%rsi
   2ec92:	mov    $0x1,%ecx
   2ec97:	callq  4574e <rfc_wrap>
   2ec9c:	mov    %rax,%rdx
   2ec9f:	jmpq   2da05 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2a45>
   2eca4:	mov    %rdi,%r8
   2eca7:	mov    %r12,%rdi
   2ecaa:	mov    %r13,%rsi
   2ecad:	mov    $0x2,%edx
   2ecb2:	mov    %r11,%rcx
   2ecb5:	callq  45448 <heap_alloc_miss>
   2ecba:	mov    %r8,%rdi
   2ecbd:	mov    %rcx,%r11
   2ecc0:	mov    %rax,%r14
   2ecc3:	jmpq   2cbb6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1bf6>
   2ecc8:	mov    %r9,%r10
   2eccb:	mov    %rdi,%r9
   2ecce:	mov    %r12,%rdi
   2ecd1:	mov    %r13,%rsi
   2ecd4:	mov    %rbx,%rdx
   2ecd7:	mov    $0x1,%ecx
   2ecdc:	mov    %r11,%r8
   2ecdf:	callq  4574e <rfc_wrap>
   2ece4:	movabs $0x200000000000000,%rsi
   2ecee:	mov    %r9,%rdi
   2ecf1:	mov    %r10,%r9
   2ecf4:	movabs $0x2002d0000000000,%r10
   2ecfe:	mov    0x18(%rsp),%rcx
   2ed03:	mov    0x8(%rsp),%rdx
   2ed08:	mov    %r8,%r11
   2ed0b:	mov    %rax,%rbx
   2ed0e:	jmpq   2cbd9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1c19>
   2ed13:	mov    %r10,%rbx
   2ed16:	mov    %r9,%r10
   2ed19:	mov    %rdi,%r9
   2ed1c:	mov    %r12,%rdi
   2ed1f:	mov    %r13,%rsi
   2ed22:	mov    %rcx,%rdx
   2ed25:	mov    $0x1,%ecx
   2ed2a:	mov    %r11,%r8
   2ed2d:	callq  4574e <rfc_wrap>
   2ed32:	movabs $0x200000000000000,%rsi
   2ed3c:	mov    %r9,%rdi
   2ed3f:	mov    %r10,%r9
   2ed42:	mov    %rbx,%r10
   2ed45:	mov    0x8(%rsp),%rdx
   2ed4a:	mov    %r8,%r11
   2ed4d:	mov    %rax,%rcx
   2ed50:	jmpq   2cbec <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1c2c>
   2ed55:	mov    %r10,%rbx
   2ed58:	mov    %r9,%r10
   2ed5b:	mov    %rdi,%r9
   2ed5e:	mov    %r12,%rdi
   2ed61:	mov    %r13,%rsi
   2ed64:	mov    $0x1,%ecx
   2ed69:	mov    %r11,%r8
   2ed6c:	callq  4574e <rfc_wrap>
   2ed71:	mov    %r9,%rdi
   2ed74:	mov    %r10,%r9
   2ed77:	mov    %rbx,%r10
   2ed7a:	mov    %r8,%r11
   2ed7d:	mov    %rax,%rdx
   2ed80:	jmpq   2cc00 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1c40>
   2ed85:	mov    %r12,%rdi
   2ed88:	mov    %r13,%rsi
   2ed8b:	mov    $0x2,%edx
   2ed90:	callq  45448 <heap_alloc_miss>
   2ed95:	mov    %rax,%r8
   2ed98:	jmpq   2dadc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b1c>
   2ed9d:	mov    %r12,%rdi
   2eda0:	mov    %r13,%rsi
   2eda3:	mov    %rbx,%rdx
   2eda6:	mov    $0x1,%ecx
   2edab:	callq  4574e <rfc_wrap>
   2edb0:	movabs $0x200000000000000,%rdx
   2edba:	mov    0x40(%rsp),%rcx
   2edbf:	jmpq   2db11 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b51>
   2edc4:	mov    %r12,%rdi
   2edc7:	mov    %r13,%rsi
   2edca:	mov    %r9,%rdx
   2edcd:	mov    $0x1,%ecx
   2edd2:	callq  4574e <rfc_wrap>
   2edd7:	movabs $0x200000000000000,%rdx
   2ede1:	mov    0x40(%rsp),%rcx
   2ede6:	mov    %rax,%r9
   2ede9:	mov    %r9,0x8(%r12,%r8,8)
   2edee:	and    %rcx,%rbp
   2edf1:	cmp    %rdx,%rbp
   2edf4:	jne    2db35 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b75>
   2edfa:	mov    %r12,%rdi
   2edfd:	mov    %r13,%rsi
   2ee00:	mov    %rcx,%rdx
   2ee03:	mov    $0x1,%ecx
   2ee08:	callq  4574e <rfc_wrap>
   2ee0d:	mov    %rax,%rcx
   2ee10:	or     %r8,%r10
   2ee13:	mov    %rcx,0x10(%r12,%r8,8)
   2ee18:	test   %r15d,%r15d
   2ee1b:	jne    2db46 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2b86>
   2ee21:	mov    (%rsp),%r14
   2ee25:	mov    -0x18(%r14),%rcx
   2ee29:	mov    -0x10(%r14),%r8d
   2ee2d:	mov    %r12,%rdi
   2ee30:	mov    %r13,%rsi
   2ee33:	mov    $0x14f,%edx
   2ee38:	mov    $0x1,%r9d
   2ee3e:	mov    %r10,%r15
   2ee41:	callq  caf0 <task_node>
   2ee46:	mov    %r15,(%r12,%rax,8)
   2ee4a:	movabs $0x5014f0000000000,%rcx
   2ee54:	jmpq   2fa11 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a51>
   2ee59:	mov    %r12,%rdi
   2ee5c:	mov    %r13,%rsi
   2ee5f:	mov    $0x1,%edx
   2ee64:	callq  45448 <heap_alloc_miss>
   2ee69:	mov    %rax,%r10
   2ee6c:	jmpq   2beef <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf2f>
   2ee71:	mov    %r12,%rdi
   2ee74:	mov    %rsi,%rbp
   2ee77:	mov    %r13,%rsi
   2ee7a:	mov    %r15,%rdx
   2ee7d:	mov    $0x1,%ecx
   2ee82:	callq  4574e <rfc_wrap>
   2ee87:	mov    %rbp,%rsi
   2ee8a:	mov    0x8(%rsp),%rcx
   2ee8f:	mov    0x38(%rsp),%rdx
   2ee94:	jmpq   2bf22 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf62>
   2ee99:	mov    %r12,%rdi
   2ee9c:	mov    %rsi,%rbp
   2ee9f:	mov    %r13,%rsi
   2eea2:	mov    %rbx,%rdx
   2eea5:	mov    $0x1,%ecx
   2eeaa:	callq  4574e <rfc_wrap>
   2eeaf:	mov    %rbp,%rsi
   2eeb2:	mov    0x8(%rsp),%rcx
   2eeb7:	mov    0x38(%rsp),%rdx
   2eebc:	mov    %rax,%rbx
   2eebf:	mov    %rbx,0x8(%r12,%r10,8)
   2eec4:	mov    0x8(%r13),%rbx
   2eec8:	test   %rbx,%rbx
   2eecb:	jne    2bf47 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf87>
   2eed1:	mov    %r12,%rdi
   2eed4:	mov    %rsi,%rbx
   2eed7:	mov    %r13,%rsi
   2eeda:	mov    $0x1,%edx
   2eedf:	callq  45448 <heap_alloc_miss>
   2eee4:	mov    %rbx,%rsi
   2eee7:	mov    0x38(%rsp),%rdx
   2eeec:	mov    %rax,%rbx
   2eeef:	mov    %r9,%rax
   2eef2:	and    %r14,%rax
   2eef5:	cmp    %rsi,%rax
   2eef8:	jne    2bf66 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xfa6>
   2eefe:	mov    %r12,%rdi
   2ef01:	mov    %rsi,%rbp
   2ef04:	mov    %r13,%rsi
   2ef07:	mov    %r9,%rdx
   2ef0a:	mov    $0x1,%ecx
   2ef0f:	callq  4574e <rfc_wrap>
   2ef14:	mov    %rbp,%rsi
   2ef17:	mov    0x8(%rsp),%rcx
   2ef1c:	mov    0x38(%rsp),%rdx
   2ef21:	mov    %rax,%r9
   2ef24:	jmpq   2bf66 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xfa6>
   2ef29:	mov    %r12,%rdi
   2ef2c:	mov    %rsi,%r9
   2ef2f:	mov    %r13,%rsi
   2ef32:	mov    %rcx,%rdx
   2ef35:	mov    $0x1,%ecx
   2ef3a:	callq  4574e <rfc_wrap>
   2ef3f:	mov    %r9,%rsi
   2ef42:	mov    0x38(%rsp),%rdx
   2ef47:	mov    %rax,%rcx
   2ef4a:	jmpq   2bf79 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xfb9>
   2ef4f:	mov    %r12,%rdi
   2ef52:	mov    %rsi,%rcx
   2ef55:	mov    %r13,%rsi
   2ef58:	mov    $0x2,%edx
   2ef5d:	callq  45448 <heap_alloc_miss>
   2ef62:	mov    %rcx,%rsi
   2ef65:	mov    0x38(%rsp),%rdx
   2ef6a:	mov    %rax,%r9
   2ef6d:	jmpq   2bfa5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xfe5>
   2ef72:	mov    %r12,%rdi
   2ef75:	mov    %r13,%rsi
   2ef78:	mov    $0x1,%ecx
   2ef7d:	callq  4574e <rfc_wrap>
   2ef82:	movabs $0x200000000000000,%rsi
   2ef8c:	mov    %rax,%rdx
   2ef8f:	jmpq   2bfb7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xff7>
   2ef94:	mov    %r12,%rdi
   2ef97:	mov    %rsi,%rbp
   2ef9a:	mov    %r13,%rsi
   2ef9d:	mov    %r10,%rdx
   2efa0:	mov    $0x1,%ecx
   2efa5:	callq  4574e <rfc_wrap>
   2efaa:	mov    %rbp,%rsi
   2efad:	movabs $0x300000000000000,%rbp
   2efb7:	mov    %rax,%r10
   2efba:	mov    %r10,0x8(%r12,%r9,8)
   2efbf:	cmp    %rbp,%rbx
   2efc2:	jae    2bfe6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1026>
   2efc8:	mov    %r12,%rdi
   2efcb:	mov    %rsi,%r10
   2efce:	mov    %r13,%rsi
   2efd1:	mov    %rbx,%rdx
   2efd4:	mov    $0x1,%ecx
   2efd9:	callq  4574e <rfc_wrap>
   2efde:	mov    %r10,%rsi
   2efe1:	mov    %rax,%rbx
   2efe4:	mov    %rbx,0x10(%r12,%r9,8)
   2efe9:	mov    0x0(%r13),%r10
   2efed:	test   %r10,%r10
   2eff0:	jne    2bff8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1038>
   2eff6:	mov    %r12,%rdi
   2eff9:	mov    %rsi,%rcx
   2effc:	mov    %r13,%rsi
   2efff:	xor    %edx,%edx
   2f001:	callq  45448 <heap_alloc_miss>
   2f006:	mov    %rcx,%rsi
   2f009:	mov    %rax,%r10
   2f00c:	cmp    %rsi,%r8
   2f00f:	jne    2c010 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1050>
   2f015:	mov    %r12,%rdi
   2f018:	mov    %rsi,%r8
   2f01b:	mov    %r13,%rsi
   2f01e:	mov    %r15,%rdx
   2f021:	mov    $0x1,%ecx
   2f026:	callq  4574e <rfc_wrap>
   2f02b:	mov    %r8,%rsi
   2f02e:	mov    %rax,%r15
   2f031:	jmpq   2c010 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1050>
   2f036:	mov    %r12,%rdi
   2f039:	mov    %rsi,%r8
   2f03c:	mov    %r13,%rsi
   2f03f:	mov    $0x1,%edx
   2f044:	callq  45448 <heap_alloc_miss>
   2f049:	mov    %r8,%rsi
   2f04c:	mov    %rax,%r8
   2f04f:	jmpq   2c03b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x107b>
   2f054:	mov    %r12,%rdi
   2f057:	mov    %r13,%rsi
   2f05a:	mov    %rax,%rdx
   2f05d:	mov    $0x1,%ecx
   2f062:	callq  4574e <rfc_wrap>
   2f067:	jmpq   2c04f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x108f>
   2f06c:	mov    %r12,%rdi
   2f06f:	mov    %r13,%rsi
   2f072:	mov    %r10,%rdx
   2f075:	mov    $0x1,%ecx
   2f07a:	callq  4574e <rfc_wrap>
   2f07f:	mov    %rax,%r10
   2f082:	jmpq   2c06a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10aa>
   2f087:	mov    %r12,%rdi
   2f08a:	mov    %rsi,%rcx
   2f08d:	mov    %r13,%rsi
   2f090:	mov    $0x1,%edx
   2f095:	callq  45448 <heap_alloc_miss>
   2f09a:	mov    %rcx,%rsi
   2f09d:	mov    %rax,%r10
   2f0a0:	or     %rsi,%r8
   2f0a3:	cmp    %rbp,%r9
   2f0a6:	jae    2c0a5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10e5>
   2f0ac:	mov    %r12,%rdi
   2f0af:	mov    %rsi,%rbx
   2f0b2:	mov    %r13,%rsi
   2f0b5:	mov    %r9,%rdx
   2f0b8:	mov    $0x1,%ecx
   2f0bd:	callq  4574e <rfc_wrap>
   2f0c2:	mov    %rbx,%rsi
   2f0c5:	mov    %rax,%r9
   2f0c8:	mov    %r9,(%r12,%r10,8)
   2f0cc:	cmp    %rbp,%r8
   2f0cf:	jae    2c0b2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10f2>
   2f0d5:	jmpq   2c5af <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15ef>
   2f0da:	mov    %rdi,%r8
   2f0dd:	mov    %r12,%rdi
   2f0e0:	mov    %r13,%rsi
   2f0e3:	mov    $0x1,%edx
   2f0e8:	mov    %r11,%rcx
   2f0eb:	callq  45448 <heap_alloc_miss>
   2f0f0:	mov    %r8,%rdi
   2f0f3:	mov    %rcx,%r11
   2f0f6:	mov    %rax,%r10
   2f0f9:	jmpq   2cd95 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1dd5>
   2f0fe:	mov    %rdi,%r9
   2f101:	mov    %r12,%rdi
   2f104:	mov    %r13,%rsi
   2f107:	mov    %rbp,%rdx
   2f10a:	mov    $0x1,%ecx
   2f10f:	mov    %r11,%r8
   2f112:	callq  4574e <rfc_wrap>
   2f117:	mov    %r9,%rdi
   2f11a:	mov    %r8,%r11
   2f11d:	mov    %rax,%rbp
   2f120:	jmpq   2cdaf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1def>
   2f125:	mov    %rdi,%r9
   2f128:	mov    %r12,%rdi
   2f12b:	mov    %r13,%rsi
   2f12e:	mov    $0x1,%ecx
   2f133:	mov    %r11,%r8
   2f136:	callq  4574e <rfc_wrap>
   2f13b:	mov    %r9,%rdi
   2f13e:	mov    %r8,%r11
   2f141:	mov    %rax,%rdx
   2f144:	jmpq   2cdcf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e0f>
   2f149:	mov    %rdi,%r9
   2f14c:	mov    %r12,%rdi
   2f14f:	mov    %r13,%rsi
   2f152:	mov    $0x2,%edx
   2f157:	mov    %r11,%r8
   2f15a:	callq  45448 <heap_alloc_miss>
   2f15f:	mov    %r9,%rdi
   2f162:	mov    %r8,%r11
   2f165:	mov    %rax,%r8
   2f168:	jmpq   2cdfb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e3b>
   2f16d:	mov    %rdi,%r9
   2f170:	mov    %r12,%rdi
   2f173:	mov    %r13,%rsi
   2f176:	mov    %r11,%rdx
   2f179:	mov    $0x1,%ecx
   2f17e:	callq  4574e <rfc_wrap>
   2f183:	mov    %r9,%rdi
   2f186:	mov    %rax,%r11
   2f189:	jmpq   2ce0d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e4d>
   2f18e:	mov    %rdi,%r9
   2f191:	mov    %r12,%rdi
   2f194:	mov    %r13,%rsi
   2f197:	mov    %r10,%rdx
   2f19a:	mov    $0x1,%ecx
   2f19f:	callq  4574e <rfc_wrap>
   2f1a4:	mov    %r9,%rdi
   2f1a7:	mov    %rax,%r10
   2f1aa:	jmpq   2ce21 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e61>
   2f1af:	mov    %rdi,%rcx
   2f1b2:	mov    %r12,%rdi
   2f1b5:	mov    %r13,%rsi
   2f1b8:	mov    $0x1,%edx
   2f1bd:	callq  45448 <heap_alloc_miss>
   2f1c2:	mov    %rcx,%rdi
   2f1c5:	mov    %rax,%r10
   2f1c8:	movabs $0x2002d0000000000,%rbp
   2f1d2:	and    %rdi,%r14
   2f1d5:	cmp    %rbx,%r14
   2f1d8:	jne    2ce68 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ea8>
   2f1de:	mov    %rdi,%rdx
   2f1e1:	mov    %r12,%rdi
   2f1e4:	mov    %r13,%rsi
   2f1e7:	mov    $0x1,%ecx
   2f1ec:	callq  4574e <rfc_wrap>
   2f1f1:	mov    %rax,%rdi
   2f1f4:	jmpq   2ce68 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ea8>
   2f1f9:	mov    %r12,%rdi
   2f1fc:	mov    %rsi,%rcx
   2f1ff:	mov    %r13,%rsi
   2f202:	mov    $0x1,%edx
   2f207:	callq  45448 <heap_alloc_miss>
   2f20c:	mov    %rcx,%rsi
   2f20f:	mov    %rax,%r9
   2f212:	or     %rsi,%r10
   2f215:	cmp    %rbx,%r8
   2f218:	jae    2d130 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2170>
   2f21e:	jmpq   2cebf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1eff>
   2f223:	mov    %r12,%rdi
   2f226:	mov    %r13,%rsi
   2f229:	mov    $0x1,%edx
   2f22e:	callq  45448 <heap_alloc_miss>
   2f233:	mov    %rax,%r10
   2f236:	jmpq   2c3d1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1411>
   2f23b:	mov    %r12,%rdi
   2f23e:	mov    %r13,%rsi
   2f241:	mov    %r8,%rdx
   2f244:	mov    $0x1,%ecx
   2f249:	callq  4574e <rfc_wrap>
   2f24e:	mov    0x10(%rsp),%r11
   2f253:	mov    0x18(%rsp),%rcx
   2f258:	mov    0x8(%rsp),%r9
   2f25d:	mov    0x38(%rsp),%rdx
   2f262:	jmpq   2c40b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x144b>
   2f267:	mov    %r12,%rdi
   2f26a:	mov    %r13,%rsi
   2f26d:	mov    %rbx,%rdx
   2f270:	mov    $0x1,%ecx
   2f275:	callq  4574e <rfc_wrap>
   2f27a:	mov    0x10(%rsp),%r11
   2f27f:	mov    0x18(%rsp),%rcx
   2f284:	mov    0x8(%rsp),%r9
   2f289:	mov    0x38(%rsp),%rdx
   2f28e:	mov    %rax,%rbx
   2f291:	mov    %rbx,0x8(%r12,%r10,8)
   2f296:	mov    0x10(%r13),%rbx
   2f29a:	test   %rbx,%rbx
   2f29d:	jne    2c430 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1470>
   2f2a3:	mov    %r12,%rdi
   2f2a6:	mov    %r13,%rsi
   2f2a9:	mov    $0x2,%edx
   2f2ae:	callq  45448 <heap_alloc_miss>
   2f2b3:	mov    0x10(%rsp),%r11
   2f2b8:	mov    0x8(%rsp),%r9
   2f2bd:	mov    0x38(%rsp),%rdx
   2f2c2:	mov    %rax,%rbx
   2f2c5:	mov    %r11,%rax
   2f2c8:	and    %r14,%rax
   2f2cb:	cmp    %r15,%rax
   2f2ce:	jne    2c44f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x148f>
   2f2d4:	mov    %r12,%rdi
   2f2d7:	mov    %r13,%rsi
   2f2da:	mov    %r11,%rdx
   2f2dd:	mov    $0x1,%ecx
   2f2e2:	callq  4574e <rfc_wrap>
   2f2e7:	mov    0x18(%rsp),%rcx
   2f2ec:	mov    0x8(%rsp),%r9
   2f2f1:	mov    0x38(%rsp),%rdx
   2f2f6:	mov    %rax,%r11
   2f2f9:	jmpq   2c44f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x148f>
   2f2fe:	mov    %r12,%rdi
   2f301:	mov    %r13,%rsi
   2f304:	mov    %rcx,%rdx
   2f307:	mov    $0x1,%ecx
   2f30c:	callq  4574e <rfc_wrap>
   2f311:	mov    0x8(%rsp),%r9
   2f316:	mov    0x38(%rsp),%rdx
   2f31b:	mov    %rax,%rcx
   2f31e:	jmpq   2c462 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x14a2>
   2f323:	mov    %r12,%rdi
   2f326:	mov    %r13,%rsi
   2f329:	mov    %r9,%rdx
   2f32c:	mov    $0x1,%ecx
   2f331:	callq  4574e <rfc_wrap>
   2f336:	mov    0x38(%rsp),%rdx
   2f33b:	mov    %rax,%r9
   2f33e:	jmpq   2c476 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x14b6>
   2f343:	mov    %r12,%rdi
   2f346:	mov    %r13,%rsi
   2f349:	mov    $0x2,%edx
   2f34e:	callq  45448 <heap_alloc_miss>
   2f353:	mov    0x38(%rsp),%rdx
   2f358:	mov    %rax,%r9
   2f35b:	jmpq   2c4a2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x14e2>
   2f360:	mov    %r12,%rdi
   2f363:	mov    %r13,%rsi
   2f366:	mov    $0x1,%ecx
   2f36b:	callq  4574e <rfc_wrap>
   2f370:	movabs $0x2002d0000000000,%rsi
   2f37a:	mov    %rax,%rdx
   2f37d:	jmpq   2c4be <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x14fe>
   2f382:	mov    %r12,%rdi
   2f385:	mov    %r13,%rsi
   2f388:	mov    %r10,%rdx
   2f38b:	mov    $0x1,%ecx
   2f390:	callq  4574e <rfc_wrap>
   2f395:	movabs $0x2002d0000000000,%rsi
   2f39f:	movabs $0x300000000000000,%rdi
   2f3a9:	mov    %rax,%r10
   2f3ac:	mov    %r10,0x8(%r12,%r9,8)
   2f3b1:	cmp    %rdi,%rbx
   2f3b4:	jae    2c4ed <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x152d>
   2f3ba:	mov    %r12,%rdi
   2f3bd:	mov    %rsi,%r10
   2f3c0:	mov    %r13,%rsi
   2f3c3:	mov    %rbx,%rdx
   2f3c6:	mov    $0x1,%ecx
   2f3cb:	callq  4574e <rfc_wrap>
   2f3d0:	mov    %r10,%rsi
   2f3d3:	movabs $0x300000000000000,%rdi
   2f3dd:	mov    %rax,%rbx
   2f3e0:	mov    %rbx,0x10(%r12,%r9,8)
   2f3e5:	mov    0x0(%r13),%r10
   2f3e9:	test   %r10,%r10
   2f3ec:	jne    2c4ff <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x153f>
   2f3f2:	mov    %rdi,%rcx
   2f3f5:	mov    %r12,%rdi
   2f3f8:	mov    %rsi,%r10
   2f3fb:	mov    %r13,%rsi
   2f3fe:	xor    %edx,%edx
   2f400:	callq  45448 <heap_alloc_miss>
   2f405:	mov    %r10,%rsi
   2f408:	mov    %rcx,%rdi
   2f40b:	mov    %rax,%r10
   2f40e:	mov    0x20(%rsp),%rbx
   2f413:	cmp    %r15,%rbp
   2f416:	jne    2c51c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x155c>
   2f41c:	mov    %r12,%rdi
   2f41f:	mov    %rsi,%rbp
   2f422:	mov    %r13,%rsi
   2f425:	mov    %r8,%rdx
   2f428:	mov    $0x1,%ecx
   2f42d:	callq  4574e <rfc_wrap>
   2f432:	mov    %rbp,%rsi
   2f435:	movabs $0x300000000000000,%rdi
   2f43f:	mov    %rax,%r8
   2f442:	jmpq   2c51c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x155c>
   2f447:	mov    %rdi,%r8
   2f44a:	mov    %r12,%rdi
   2f44d:	mov    %rsi,%rbp
   2f450:	mov    %r13,%rsi
   2f453:	mov    $0x1,%edx
   2f458:	callq  45448 <heap_alloc_miss>
   2f45d:	mov    %rbp,%rsi
   2f460:	mov    %r8,%rdi
   2f463:	mov    %rax,%r8
   2f466:	or     %rcx,%r10
   2f469:	and    %rbx,%r14
   2f46c:	cmp    %r15,%r14
   2f46f:	jne    2c556 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1596>
   2f475:	mov    %rdi,%r14
   2f478:	mov    %r12,%rdi
   2f47b:	mov    %rsi,%r15
   2f47e:	mov    %r13,%rsi
   2f481:	mov    %rbx,%rdx
   2f484:	mov    $0x1,%ecx
   2f489:	callq  4574e <rfc_wrap>
   2f48e:	mov    %r15,%rsi
   2f491:	mov    %r14,%rdi
   2f494:	mov    %rax,%rbx
   2f497:	mov    (%rsp),%r14
   2f49b:	mov    %rbx,(%r12,%r8,8)
   2f49f:	cmp    %rdi,%r10
   2f4a2:	jae    2c567 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15a7>
   2f4a8:	mov    %rdi,%rbx
   2f4ab:	mov    %r12,%rdi
   2f4ae:	mov    %rsi,%r15
   2f4b1:	mov    %r13,%rsi
   2f4b4:	mov    %r10,%rdx
   2f4b7:	mov    $0x1,%ecx
   2f4bc:	callq  4574e <rfc_wrap>
   2f4c1:	mov    %r15,%rsi
   2f4c4:	mov    %rbx,%rdi
   2f4c7:	mov    %rax,%r10
   2f4ca:	jmpq   2c567 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15a7>
   2f4cf:	mov    %rdi,%r10
   2f4d2:	mov    %r12,%rdi
   2f4d5:	mov    %rsi,%rcx
   2f4d8:	mov    %r13,%rsi
   2f4db:	mov    $0x1,%edx
   2f4e0:	callq  45448 <heap_alloc_miss>
   2f4e5:	mov    %r10,%rdi
   2f4e8:	mov    %rcx,%rsi
   2f4eb:	mov    %rax,%r10
   2f4ee:	or     %rsi,%r8
   2f4f1:	cmp    %rdi,%r9
   2f4f4:	jae    2c5a2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15e2>
   2f4fa:	mov    %rdi,%r15
   2f4fd:	mov    %r12,%rdi
   2f500:	mov    %rsi,%rbx
   2f503:	mov    %r13,%rsi
   2f506:	mov    %r9,%rdx
   2f509:	mov    $0x1,%ecx
   2f50e:	callq  4574e <rfc_wrap>
   2f513:	mov    %r15,%rdi
   2f516:	mov    %rbx,%rsi
   2f519:	mov    %rax,%r9
   2f51c:	mov    %r9,(%r12,%r10,8)
   2f520:	cmp    %rdi,%r8
   2f523:	jae    2c0b2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x10f2>
   2f529:	jmpq   2c5af <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15ef>
   2f52e:	mov    %r12,%rdi
   2f531:	mov    %r13,%rsi
   2f534:	mov    $0x1,%edx
   2f539:	mov    %r11,%rcx
   2f53c:	callq  45448 <heap_alloc_miss>
   2f541:	mov    %rcx,%r11
   2f544:	mov    0x10(%rsp),%rdx
   2f549:	mov    %rax,%r8
   2f54c:	jmpq   2c766 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x17a6>
   2f551:	mov    %r12,%rdi
   2f554:	mov    %r13,%rsi
   2f557:	mov    %r9,%rdx
   2f55a:	mov    $0x1,%ecx
   2f55f:	mov    %r11,%r9
   2f562:	callq  4574e <rfc_wrap>
   2f567:	mov    0x10(%rsp),%rdx
   2f56c:	mov    %r9,%r11
   2f56f:	mov    %rax,%r9
   2f572:	jmpq   2c780 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x17c0>
   2f577:	mov    %r12,%rdi
   2f57a:	mov    %r13,%rsi
   2f57d:	mov    $0x1,%ecx
   2f582:	mov    %r11,%r9
   2f585:	callq  4574e <rfc_wrap>
   2f58a:	mov    %r9,%r11
   2f58d:	mov    %rax,%rdx
   2f590:	jmpq   2c79d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x17dd>
   2f595:	mov    %r12,%rdi
   2f598:	mov    %r13,%rsi
   2f59b:	mov    $0x2,%edx
   2f5a0:	callq  45448 <heap_alloc_miss>
   2f5a5:	mov    %rax,%r8
   2f5a8:	jmpq   2dd79 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2db9>
   2f5ad:	mov    %r12,%rdi
   2f5b0:	mov    %r13,%rsi
   2f5b3:	mov    %rbx,%rdx
   2f5b6:	mov    $0x1,%ecx
   2f5bb:	callq  4574e <rfc_wrap>
   2f5c0:	jmpq   2dd9a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2dda>
   2f5c5:	mov    %r12,%rdi
   2f5c8:	mov    %r13,%rsi
   2f5cb:	mov    $0x1,%ecx
   2f5d0:	callq  4574e <rfc_wrap>
   2f5d5:	mov    %rax,%rdx
   2f5d8:	jmpq   2ddb2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2df2>
   2f5dd:	mov    %r12,%rdi
   2f5e0:	mov    %r13,%rsi
   2f5e3:	mov    %rax,%rdx
   2f5e6:	mov    $0x1,%ecx
   2f5eb:	callq  4574e <rfc_wrap>
   2f5f0:	jmpq   2ddc8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2e08>
   2f5f5:	mov    %r12,%rdi
   2f5f8:	mov    %rsi,%r8
   2f5fb:	mov    %r13,%rsi
   2f5fe:	mov    $0x2,%edx
   2f603:	mov    %r11,%rcx
   2f606:	callq  45448 <heap_alloc_miss>
   2f60b:	mov    %r8,%rsi
   2f60e:	mov    %rcx,%r11
   2f611:	mov    %rax,%r9
   2f614:	jmpq   2d2c2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2302>
   2f619:	mov    %r12,%rdi
   2f61c:	mov    %rsi,%r14
   2f61f:	mov    %r13,%rsi
   2f622:	mov    %rbx,%rdx
   2f625:	mov    $0x1,%ecx
   2f62a:	mov    %r11,%r8
   2f62d:	callq  4574e <rfc_wrap>
   2f632:	mov    %r14,%rsi
   2f635:	mov    0x18(%rsp),%rcx
   2f63a:	mov    0x8(%rsp),%rdx
   2f63f:	mov    %r8,%r11
   2f642:	mov    %rax,%rbx
   2f645:	jmpq   2d2e6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2326>
   2f64a:	mov    %r12,%rdi
   2f64d:	mov    %rsi,%r14
   2f650:	mov    %r13,%rsi
   2f653:	mov    %rcx,%rdx
   2f656:	mov    $0x1,%ecx
   2f65b:	mov    %r11,%r8
   2f65e:	callq  4574e <rfc_wrap>
   2f663:	mov    %r14,%rsi
   2f666:	mov    0x8(%rsp),%rdx
   2f66b:	mov    %r8,%r11
   2f66e:	mov    %rax,%rcx
   2f671:	jmpq   2d303 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2343>
   2f676:	mov    %r12,%rdi
   2f679:	mov    %rsi,%r14
   2f67c:	mov    %r13,%rsi
   2f67f:	mov    $0x1,%ecx
   2f684:	mov    %r11,%r8
   2f687:	callq  4574e <rfc_wrap>
   2f68c:	mov    %r14,%rsi
   2f68f:	mov    %r8,%r11
   2f692:	mov    %rax,%rdx
   2f695:	jmpq   2d317 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2357>
   2f69a:	mov    %r12,%rdi
   2f69d:	mov    %rsi,%r8
   2f6a0:	mov    %r13,%rsi
   2f6a3:	mov    $0x2,%edx
   2f6a8:	mov    %r11,%rcx
   2f6ab:	callq  45448 <heap_alloc_miss>
   2f6b0:	mov    %r8,%rsi
   2f6b3:	mov    %rcx,%r11
   2f6b6:	mov    %rax,%r8
   2f6b9:	jmpq   2d343 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2383>
   2f6be:	mov    %r12,%rdi
   2f6c1:	mov    %r13,%rsi
   2f6c4:	mov    %r11,%rdx
   2f6c7:	mov    $0x1,%ecx
   2f6cc:	callq  4574e <rfc_wrap>
   2f6d1:	movabs $0x1002b0000000000,%rsi
   2f6db:	mov    %rax,%r11
   2f6de:	jmpq   2d355 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2395>
   2f6e3:	mov    %r12,%rdi
   2f6e6:	mov    %r13,%rsi
   2f6e9:	mov    %r9,%rdx
   2f6ec:	mov    $0x1,%ecx
   2f6f1:	callq  4574e <rfc_wrap>
   2f6f6:	movabs $0x1002b0000000000,%rsi
   2f700:	mov    %rax,%r9
   2f703:	jmpq   2d369 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x23a9>
   2f708:	mov    %r12,%rdi
   2f70b:	mov    %r13,%rsi
   2f70e:	mov    $0x1,%edx
   2f713:	callq  45448 <heap_alloc_miss>
   2f718:	mov    %rax,%r9
   2f71b:	and    %rbp,%r10
   2f71e:	cmp    %rbx,%r10
   2f721:	jne    2d39c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x23dc>
   2f727:	mov    %r12,%rdi
   2f72a:	mov    %r13,%rsi
   2f72d:	mov    %rbp,%rdx
   2f730:	mov    $0x1,%ecx
   2f735:	callq  4574e <rfc_wrap>
   2f73a:	mov    %rax,%rbp
   2f73d:	jmpq   2d39c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x23dc>
   2f742:	mov    %r12,%rdi
   2f745:	mov    %rsi,%rcx
   2f748:	mov    %r13,%rsi
   2f74b:	mov    $0x1,%edx
   2f750:	callq  45448 <heap_alloc_miss>
   2f755:	mov    %rcx,%rsi
   2f758:	mov    %rax,%r10
   2f75b:	mov    (%rsp),%r14
   2f75f:	or     %rsi,%r9
   2f762:	cmp    %rbx,%r8
   2f765:	jae    2d3f3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2433>
   2f76b:	mov    %r12,%rdi
   2f76e:	mov    %rsi,%r14
   2f771:	mov    %r13,%rsi
   2f774:	mov    %r8,%rdx
   2f777:	mov    $0x1,%ecx
   2f77c:	callq  4574e <rfc_wrap>
   2f781:	mov    %r14,%rsi
   2f784:	mov    (%rsp),%r14
   2f788:	mov    %rax,%r8
   2f78b:	mov    %r8,(%r12,%r10,8)
   2f78f:	cmp    %rbx,%r9
   2f792:	jae    2d661 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26a1>
   2f798:	jmpq   2d400 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2440>
   2f79d:	mov    %rdi,%r8
   2f7a0:	mov    %r12,%rdi
   2f7a3:	mov    %r13,%rsi
   2f7a6:	mov    $0x2,%edx
   2f7ab:	mov    %r11,%rcx
   2f7ae:	callq  45448 <heap_alloc_miss>
   2f7b3:	mov    %r8,%rdi
   2f7b6:	mov    %rcx,%r11
   2f7b9:	mov    0x10(%rsp),%rdx
   2f7be:	mov    %rax,%r14
   2f7c1:	jmpq   2cb2c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b6c>
   2f7c6:	mov    %r9,%r10
   2f7c9:	mov    %rdi,%r9
   2f7cc:	mov    %r12,%rdi
   2f7cf:	mov    %r13,%rsi
   2f7d2:	mov    $0x1,%ecx
   2f7d7:	mov    %r11,%r8
   2f7da:	callq  4574e <rfc_wrap>
   2f7df:	movabs $0x200000000000000,%rcx
   2f7e9:	mov    %r9,%rdi
   2f7ec:	mov    %r10,%r9
   2f7ef:	movabs $0x2002d0000000000,%r10
   2f7f9:	mov    %r8,%r11
   2f7fc:	mov    %rax,%rdx
   2f7ff:	jmpq   2cb45 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b85>
   2f804:	mov    %r9,%rdx
   2f807:	mov    %rdi,%r9
   2f80a:	mov    %r12,%rdi
   2f80d:	mov    %r13,%rsi
   2f810:	mov    $0x1,%ecx
   2f815:	mov    %r11,%r8
   2f818:	callq  4574e <rfc_wrap>
   2f81d:	movabs $0x200000000000000,%rcx
   2f827:	mov    %r9,%rdi
   2f82a:	mov    %r8,%r11
   2f82d:	mov    %rax,%r9
   2f830:	jmpq   2cb58 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b98>
   2f835:	mov    %rdi,%rdx
   2f838:	mov    %r12,%rdi
   2f83b:	mov    %r13,%rsi
   2f83e:	mov    $0x1,%ecx
   2f843:	mov    %r11,%r8
   2f846:	callq  4574e <rfc_wrap>
   2f84b:	mov    %r8,%r11
   2f84e:	mov    %rax,%rdi
   2f851:	mov    %rdi,0x10(%r12,%r14,8)
   2f856:	or     %r10,%r14
   2f859:	test   %r15d,%r15d
   2f85c:	jne    2cb7d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1bbd>
   2f862:	mov    %rbx,0x10(%rsp)
   2f867:	mov    (%rsp),%rbx
   2f86b:	mov    -0x18(%rbx),%rcx
   2f86f:	mov    -0x10(%rbx),%r8d
   2f873:	mov    %r12,%rdi
   2f876:	mov    %r13,%rsi
   2f879:	mov    $0x14c,%edx
   2f87e:	mov    $0x1,%r9d
   2f884:	mov    %r11,%r15
   2f887:	callq  caf0 <task_node>
   2f88c:	mov    %r15,(%r12,%rax,8)
   2f890:	mov    %r14,0x8(%r12,%rax,8)
   2f895:	movabs $0x5014c0000000000,%rcx
   2f89f:	or     %rax,%rcx
   2f8a2:	mov    %rcx,-0x18(%rbx)
   2f8a6:	movq   $0x2,-0x10(%rbx)
   2f8ae:	mov    0x10(%rsp),%rbx
   2f8b3:	mov    %r12,%rdi
   2f8b6:	mov    %r13,%rsi
   2f8b9:	mov    %rbx,%rdx
   2f8bc:	callq  43610 <term_keep>
   2f8c1:	mov    %rax,%rbx
   2f8c4:	mov    0x10(%r13),%r8
   2f8c8:	test   %r8,%r8
   2f8cb:	je     2f95e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x499e>
   2f8d1:	mov    (%r12,%r8,8),%rax
   2f8d5:	mov    %rax,0x10(%r13)
   2f8d9:	addq   $0xfffffffffffffffc,0x110(%r13)
   2f8e1:	mov    %rbx,%rcx
   2f8e4:	and    %rbp,%rcx
   2f8e7:	mov    %rbx,%rax
   2f8ea:	movabs $0x200000000000000,%rdx
   2f8f4:	cmp    %rdx,%rcx
   2f8f7:	mov    %rdx,%rcx
   2f8fa:	mov    0x30(%rsp),%r15d
   2f8ff:	movabs $0x2002d0000000000,%r10
   2f909:	je     2f976 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x49b6>
   2f90b:	mov    %rax,(%r12,%r8,8)
   2f90f:	mov    0x18(%rsp),%rdx
   2f914:	mov    %rdx,%rax
   2f917:	and    %rbp,%rax
   2f91a:	cmp    %rcx,%rax
   2f91d:	je     2f998 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x49d8>
   2f91f:	mov    %rdx,0x8(%r12,%r8,8)
   2f924:	mov    0x8(%rsp),%rax
   2f929:	and    %rax,%rbp
   2f92c:	cmp    %rcx,%rbp
   2f92f:	je     2f9ba <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x49fa>
   2f935:	or     %r8,%r10
   2f938:	mov    %rax,0x10(%r12,%r8,8)
   2f93d:	test   %r15d,%r15d
   2f940:	je     2f9de <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a1e>
   2f946:	mov    (%rsp),%r14
   2f94a:	mov    %r10,(%r14)
   2f94d:	movq   $0x14d,0x8(%r14)
   2f955:	add    $0x10,%r14
   2f959:	jmpq   2fa23 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4a63>
   2f95e:	mov    %r12,%rdi
   2f961:	mov    %r13,%rsi
   2f964:	mov    $0x2,%edx
   2f969:	callq  45448 <heap_alloc_miss>
   2f96e:	mov    %rax,%r8
   2f971:	jmpq   2f8e1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4921>
   2f976:	mov    %r12,%rdi
   2f979:	mov    %r13,%rsi
   2f97c:	mov    %rbx,%rdx
   2f97f:	mov    $0x1,%ecx
   2f984:	callq  4574e <rfc_wrap>
   2f989:	movabs $0x200000000000000,%rcx
   2f993:	jmpq   2f90b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x494b>
   2f998:	mov    %r12,%rdi
   2f99b:	mov    %r13,%rsi
   2f99e:	mov    $0x1,%ecx
   2f9a3:	callq  4574e <rfc_wrap>
   2f9a8:	movabs $0x200000000000000,%rcx
   2f9b2:	mov    %rax,%rdx
   2f9b5:	jmpq   2f91f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x495f>
   2f9ba:	mov    %r12,%rdi
   2f9bd:	mov    %r13,%rsi
   2f9c0:	mov    %rax,%rdx
   2f9c3:	mov    $0x1,%ecx
   2f9c8:	callq  4574e <rfc_wrap>
   2f9cd:	or     %r8,%r10
   2f9d0:	mov    %rax,0x10(%r12,%r8,8)
   2f9d5:	test   %r15d,%r15d
   2f9d8:	jne    2f946 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x4986>
   2f9de:	mov    (%rsp),%r14
   2f9e2:	mov    -0x18(%r14),%rcx
   2f9e6:	mov    -0x10(%r14),%r8d
   2f9ea:	mov    %r12,%rdi
   2f9ed:	mov    %r13,%rsi
   2f9f0:	mov    $0x14d,%edx
   2f9f5:	mov    $0x1,%r9d
   2f9fb:	mov    %r10,%r15
   2f9fe:	callq  caf0 <task_node>
   2fa03:	mov    %r15,(%r12,%rax,8)
   2fa07:	movabs $0x5014d0000000000,%rcx
   2fa11:	or     %rax,%rcx
   2fa14:	mov    %rcx,-0x18(%r14)
   2fa18:	movq   $0x1,-0x10(%r14)
   2fa20:	xor    %r15d,%r15d
   2fa23:	mov    0x20(%rsp),%rsi
   2fa28:	mov    %rbx,%rdx
   2fa2b:	add    $0x50,%rsp
   2fa2f:	pop    %rbp
   2fa30:	jmpq   1b760 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
   2fa35:	mov    %rdi,%r8
   2fa38:	mov    %r12,%rdi
   2fa3b:	mov    %r13,%rsi
   2fa3e:	mov    $0x1,%edx
   2fa43:	mov    %r11,%rcx
   2fa46:	callq  45448 <heap_alloc_miss>
   2fa4b:	mov    %r8,%rdi
   2fa4e:	mov    %rcx,%r11
   2fa51:	mov    %rax,%r10
   2fa54:	jmpq   2d004 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2044>
   2fa59:	mov    %rdi,%rbx
   2fa5c:	mov    %r12,%rdi
   2fa5f:	mov    %r13,%rsi
   2fa62:	mov    %rbp,%rdx
   2fa65:	mov    $0x1,%ecx
   2fa6a:	mov    %r11,%r8
   2fa6d:	callq  4574e <rfc_wrap>
   2fa72:	mov    %rbx,%rdi
   2fa75:	mov    %r8,%r11
   2fa78:	mov    0x8(%rsp),%rdx
   2fa7d:	mov    %rax,%rbp
   2fa80:	jmpq   2d023 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2063>
   2fa85:	mov    %rdi,%r14
   2fa88:	mov    %r12,%rdi
   2fa8b:	mov    %r13,%rsi
   2fa8e:	mov    $0x1,%ecx
   2fa93:	mov    %r11,%r8
   2fa96:	callq  4574e <rfc_wrap>
   2fa9b:	mov    %r14,%rdi
   2fa9e:	mov    %r8,%r11
   2faa1:	mov    %rax,%rdx
   2faa4:	jmpq   2d040 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2080>
   2faa9:	mov    %rdi,%r14
   2faac:	mov    %r12,%rdi
   2faaf:	mov    %r13,%rsi
   2fab2:	mov    $0x2,%edx
   2fab7:	mov    %r11,%r8
   2faba:	callq  45448 <heap_alloc_miss>
   2fabf:	mov    %r14,%rdi
   2fac2:	mov    %r8,%r11
   2fac5:	mov    %rax,%r8
   2fac8:	jmpq   2d06c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x20ac>
   2facd:	mov    %rdi,%r14
   2fad0:	mov    %r12,%rdi
   2fad3:	mov    %r13,%rsi
   2fad6:	mov    %r11,%rdx
   2fad9:	mov    $0x1,%ecx
   2fade:	callq  4574e <rfc_wrap>
   2fae3:	mov    %r14,%rdi
   2fae6:	mov    %rax,%r11
   2fae9:	jmpq   2d07e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x20be>
   2faee:	mov    %rdi,%r14
   2faf1:	mov    %r12,%rdi
   2faf4:	mov    %r13,%rsi
   2faf7:	mov    %r10,%rdx
   2fafa:	mov    $0x1,%ecx
   2faff:	callq  4574e <rfc_wrap>
   2fb04:	mov    %r14,%rdi
   2fb07:	mov    %rax,%r10
   2fb0a:	mov    %r10,0x10(%r12,%r8,8)
   2fb0f:	mov    0x8(%r13),%r10
   2fb13:	test   %r10,%r10
   2fb16:	jne    2d0b3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x20f3>
   2fb1c:	mov    %rdi,%rcx
   2fb1f:	mov    %r12,%rdi
   2fb22:	mov    %r13,%rsi
   2fb25:	mov    $0x1,%edx
   2fb2a:	callq  45448 <heap_alloc_miss>
   2fb2f:	mov    %rcx,%rdi
   2fb32:	mov    %rax,%r10
   2fb35:	movabs $0x2002d0000000000,%r14
   2fb3f:	and    %rdi,%r9
   2fb42:	cmp    %rbx,%r9
   2fb45:	jne    2d0d9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2119>
   2fb4b:	mov    %rdi,%rdx
   2fb4e:	mov    %r12,%rdi
   2fb51:	mov    %r13,%rsi
   2fb54:	mov    $0x1,%ecx
   2fb59:	callq  4574e <rfc_wrap>
   2fb5e:	mov    %rax,%rdi
   2fb61:	jmpq   2d0d9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2119>
   2fb66:	mov    %r12,%rdi
   2fb69:	mov    %rsi,%rcx
   2fb6c:	mov    %r13,%rsi
   2fb6f:	mov    $0x1,%edx
   2fb74:	callq  45448 <heap_alloc_miss>
   2fb79:	mov    %rcx,%rsi
   2fb7c:	mov    %rax,%r9
   2fb7f:	mov    (%rsp),%r14
   2fb83:	or     %rsi,%r10
   2fb86:	cmp    %rbx,%r8
   2fb89:	jae    2d130 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2170>
   2fb8f:	jmpq   2cebf <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1eff>
   2fb94:	mov    %rdi,%r8
   2fb97:	mov    %r12,%rdi
   2fb9a:	mov    %r13,%rsi
   2fb9d:	mov    %rdx,%r9
   2fba0:	mov    $0x2,%edx
   2fba5:	mov    %r11,%rcx
   2fba8:	callq  45448 <heap_alloc_miss>
   2fbad:	mov    %r9,%rdx
   2fbb0:	mov    %r8,%rdi
   2fbb3:	mov    %rcx,%r11
   2fbb6:	mov    %rax,%r9
   2fbb9:	jmpq   2d528 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2568>
   2fbbe:	mov    %rdi,0x20(%rsp)
   2fbc3:	mov    %r12,%rdi
   2fbc6:	mov    %r13,%rsi
   2fbc9:	mov    %rdx,%r14
   2fbcc:	mov    %rbx,%rdx
   2fbcf:	mov    $0x1,%ecx
   2fbd4:	mov    %r11,%r8
   2fbd7:	callq  4574e <rfc_wrap>
   2fbdc:	mov    %r14,%rdx
   2fbdf:	mov    0x20(%rsp),%rdi
   2fbe4:	mov    %r8,%r11
   2fbe7:	mov    %rax,%rbx
   2fbea:	jmpq   2d542 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2582>
   2fbef:	mov    %rdx,%rbx
   2fbf2:	mov    %rdi,%rdx
   2fbf5:	mov    %r12,%rdi
   2fbf8:	mov    %r13,%rsi
   2fbfb:	mov    $0x1,%ecx
   2fc00:	mov    %r11,%r8
   2fc03:	callq  4574e <rfc_wrap>
   2fc08:	mov    %rbx,%rdx
   2fc0b:	mov    %r8,%r11
   2fc0e:	mov    %rax,%rdi
   2fc11:	jmpq   2d55f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x259f>
   2fc16:	mov    %rdx,%rbx
   2fc19:	mov    %rax,%rdx
   2fc1c:	mov    %r12,%rdi
   2fc1f:	mov    %r13,%rsi
   2fc22:	mov    $0x1,%ecx
   2fc27:	mov    %r11,%r8
   2fc2a:	callq  4574e <rfc_wrap>
   2fc2f:	mov    %rbx,%rdx
   2fc32:	mov    %r8,%r11
   2fc35:	jmpq   2d578 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x25b8>
   2fc3a:	mov    %r12,%rdi
   2fc3d:	mov    %r13,%rsi
   2fc40:	mov    %rdx,%r8
   2fc43:	mov    $0x2,%edx
   2fc48:	mov    %r11,%rcx
   2fc4b:	callq  45448 <heap_alloc_miss>
   2fc50:	mov    %r8,%rdx
   2fc53:	mov    %rcx,%r11
   2fc56:	mov    %rax,%r8
   2fc59:	jmpq   2d5a4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x25e4>
   2fc5e:	mov    %r12,%rdi
   2fc61:	mov    %r13,%rsi
   2fc64:	mov    %r11,%rdx
   2fc67:	mov    $0x1,%ecx
   2fc6c:	callq  4574e <rfc_wrap>
   2fc71:	movabs $0x1002b0000000000,%rdx
   2fc7b:	mov    %rax,%r11
   2fc7e:	jmpq   2d5b6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x25f6>
   2fc83:	mov    %r12,%rdi
   2fc86:	mov    %r13,%rsi
   2fc89:	mov    %r9,%rdx
   2fc8c:	mov    $0x1,%ecx
   2fc91:	callq  4574e <rfc_wrap>
   2fc96:	mov    %rax,%r9
   2fc99:	mov    %r9,0x10(%r12,%r8,8)
   2fc9e:	mov    0x8(%r13),%r9
   2fca2:	test   %r9,%r9
   2fca5:	jne    2d5e1 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2621>
   2fcab:	mov    %r12,%rdi
   2fcae:	mov    %r13,%rsi
   2fcb1:	mov    $0x1,%edx
   2fcb6:	callq  45448 <heap_alloc_miss>
   2fcbb:	mov    %rax,%r9
   2fcbe:	and    %rbp,%r10
   2fcc1:	cmp    %r14,%r10
   2fcc4:	jne    2d5fd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x263d>
   2fcca:	mov    %r12,%rdi
   2fccd:	mov    %r13,%rsi
   2fcd0:	mov    %rbp,%rdx
   2fcd3:	mov    $0x1,%ecx
   2fcd8:	callq  4574e <rfc_wrap>
   2fcdd:	mov    %rax,%rbp
   2fce0:	jmpq   2d5fd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x263d>
   2fce5:	mov    %r12,%rdi
   2fce8:	mov    %rsi,%rcx
   2fceb:	mov    %r13,%rsi
   2fcee:	mov    $0x1,%edx
   2fcf3:	callq  45448 <heap_alloc_miss>
   2fcf8:	mov    %rcx,%rsi
   2fcfb:	mov    %rax,%r10
   2fcfe:	or     %rsi,%r9
   2fd01:	cmp    %r14,%r8
   2fd04:	jae    2d650 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2690>
   2fd0a:	mov    %r12,%rdi
   2fd0d:	mov    %rsi,%rbx
   2fd10:	mov    %r13,%rsi
   2fd13:	mov    %r8,%rdx
   2fd16:	mov    $0x1,%ecx
   2fd1b:	callq  4574e <rfc_wrap>
   2fd20:	mov    %rbx,%rsi
   2fd23:	mov    %rax,%r8
   2fd26:	mov    %r8,(%r12,%r10,8)
   2fd2a:	cmp    %r14,%r9
   2fd2d:	jae    2d65d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x269d>
   2fd33:	mov    %r12,%rdi
   2fd36:	mov    %rsi,%r8
   2fd39:	mov    %r13,%rsi
   2fd3c:	mov    %r9,%rdx
   2fd3f:	mov    $0x1,%ecx
   2fd44:	callq  4574e <rfc_wrap>
   2fd49:	mov    %r8,%rsi
   2fd4c:	mov    %rax,%r9
   2fd4f:	jmpq   2d65d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x269d>
   2fd54:	mov    %rdi,%r8
   2fd57:	mov    %r12,%rdi
   2fd5a:	mov    %r13,%rsi
   2fd5d:	mov    $0x1,%edx
   2fd62:	mov    %r11,%rcx
   2fd65:	callq  45448 <heap_alloc_miss>
   2fd6a:	mov    %r8,%rdi
   2fd6d:	mov    0x8(%rsp),%rdx
   2fd72:	mov    %rcx,%r11
   2fd75:	mov    %rax,%r10
   2fd78:	jmpq   2db97 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2bd7>
   2fd7d:	mov    %rdi,%r15
   2fd80:	mov    %r12,%rdi
   2fd83:	mov    %r13,%rsi
   2fd86:	mov    %rbp,%rdx
   2fd89:	mov    $0x1,%ecx
   2fd8e:	mov    %r11,%r8
   2fd91:	callq  4574e <rfc_wrap>
   2fd96:	mov    %r15,%rdi
   2fd99:	mov    %r8,%r11
   2fd9c:	mov    0x8(%rsp),%rdx
   2fda1:	jmpq   2dbbd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2bfd>
   2fda6:	mov    %rdi,%r15
   2fda9:	mov    %r12,%rdi
   2fdac:	mov    %r13,%rsi
   2fdaf:	mov    $0x1,%ecx
   2fdb4:	mov    %r11,%r8
   2fdb7:	callq  4574e <rfc_wrap>
   2fdbc:	mov    %r15,%rdi
   2fdbf:	mov    %r8,%r11
   2fdc2:	mov    %rax,%rdx
   2fdc5:	jmpq   2dbd0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c10>
   2fdca:	mov    %rdi,%r15
   2fdcd:	mov    %r12,%rdi
   2fdd0:	mov    %r13,%rsi
   2fdd3:	mov    $0x2,%edx
   2fdd8:	mov    %r11,%r8
   2fddb:	callq  45448 <heap_alloc_miss>
   2fde0:	mov    %r15,%rdi
   2fde3:	mov    %r8,%r11
   2fde6:	mov    %rax,%r8
   2fde9:	jmpq   2dbfc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c3c>
   2fdee:	mov    %rdi,%r15
   2fdf1:	mov    %r12,%rdi
   2fdf4:	mov    %r13,%rsi
   2fdf7:	mov    %r11,%rdx
   2fdfa:	mov    $0x1,%ecx
   2fdff:	callq  4574e <rfc_wrap>
   2fe04:	mov    %r15,%rdi
   2fe07:	mov    %rax,%r11
   2fe0a:	jmpq   2dc0e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c4e>
   2fe0f:	mov    %rdi,%r15
   2fe12:	mov    %r12,%rdi
   2fe15:	mov    %r13,%rsi
   2fe18:	mov    %r10,%rdx
   2fe1b:	mov    $0x1,%ecx
   2fe20:	callq  4574e <rfc_wrap>
   2fe25:	mov    %r15,%rdi
   2fe28:	mov    %rax,%r10
   2fe2b:	mov    %r10,0x10(%r12,%r8,8)
   2fe30:	mov    0x0(%r13),%r15
   2fe34:	test   %r15,%r15
   2fe37:	jne    2dc43 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c83>
   2fe3d:	mov    %rdi,%rcx
   2fe40:	mov    %r12,%rdi
   2fe43:	mov    %r13,%rsi
   2fe46:	xor    %edx,%edx
   2fe48:	callq  45448 <heap_alloc_miss>
   2fe4d:	mov    %rcx,%rdi
   2fe50:	mov    %rax,%r15
   2fe53:	cmp    %r9,%rbx
   2fe56:	jne    2dc5b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c9b>
   2fe5c:	mov    %rdi,%r10
   2fe5f:	mov    %r12,%rdi
   2fe62:	mov    %r13,%rsi
   2fe65:	mov    %rbp,%rdx
   2fe68:	mov    $0x1,%ecx
   2fe6d:	callq  4574e <rfc_wrap>
   2fe72:	mov    %r10,%rdi
   2fe75:	mov    %rax,%rbp
   2fe78:	jmpq   2dc5b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2c9b>
   2fe7d:	mov    %rdi,%r10
   2fe80:	mov    %r12,%rdi
   2fe83:	mov    %r13,%rsi
   2fe86:	mov    $0x1,%edx
   2fe8b:	callq  45448 <heap_alloc_miss>
   2fe90:	mov    %r10,%rdi
   2fe93:	mov    %rax,%r10
   2fe96:	jmpq   2dc86 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2cc6>
   2fe9b:	mov    %rdi,%rdx
   2fe9e:	mov    %r12,%rdi
   2fea1:	mov    %r13,%rsi
   2fea4:	mov    $0x1,%ecx
   2fea9:	callq  4574e <rfc_wrap>
   2feae:	mov    %rax,%rdi
   2feb1:	jmpq   2dc9f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2cdf>
   2feb6:	mov    %r12,%rdi
   2feb9:	mov    %r13,%rsi
   2febc:	mov    %r15,%rdx
   2febf:	mov    $0x1,%ecx
   2fec4:	callq  4574e <rfc_wrap>
   2fec9:	mov    %rax,%r15
   2fecc:	jmpq   2dcba <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2cfa>
   2fed1:	mov    %r12,%rdi
   2fed4:	mov    %rsi,%rcx
   2fed7:	mov    %r13,%rsi
   2feda:	mov    $0x1,%edx
   2fedf:	callq  45448 <heap_alloc_miss>
   2fee4:	mov    %rcx,%rsi
   2fee7:	mov    %rax,%r9
   2feea:	or     %rsi,%r10
   2feed:	cmp    %rbx,%r8
   2fef0:	jae    2e128 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3168>
   2fef6:	mov    %r12,%rdi
   2fef9:	mov    %rsi,%r14
   2fefc:	mov    %r13,%rsi
   2feff:	mov    %r8,%rdx
   2ff02:	mov    $0x1,%ecx
   2ff07:	callq  4574e <rfc_wrap>
   2ff0c:	mov    %r14,%rsi
   2ff0f:	mov    (%rsp),%r14
   2ff13:	mov    %rax,%r8
   2ff16:	mov    %r8,(%r12,%r9,8)
   2ff1a:	cmp    %rbx,%r10
   2ff1d:	jae    2e135 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3175>
   2ff23:	mov    %r12,%rdi
   2ff26:	mov    %rsi,%r8
   2ff29:	mov    %r13,%rsi
   2ff2c:	mov    %r10,%rdx
   2ff2f:	mov    $0x1,%ecx
   2ff34:	callq  4574e <rfc_wrap>
   2ff39:	mov    %r8,%rsi
   2ff3c:	mov    %rax,%r10
   2ff3f:	jmpq   2e135 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3175>
   2ff44:	mov    %rdi,%rcx
   2ff47:	mov    %r12,%rdi
   2ff4a:	mov    %r13,%rsi
   2ff4d:	mov    $0x2,%edx
   2ff52:	callq  45448 <heap_alloc_miss>
   2ff57:	mov    %rcx,%rdi
   2ff5a:	mov    %rax,%r8
   2ff5d:	jmpq   2df0a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2f4a>
   2ff62:	mov    %rdi,%r10
   2ff65:	mov    %r12,%rdi
   2ff68:	mov    %r13,%rsi
   2ff6b:	mov    %rbx,%rdx
   2ff6e:	mov    $0x1,%ecx
   2ff73:	callq  4574e <rfc_wrap>
   2ff78:	mov    %r10,%rdi
   2ff7b:	jmpq   2df27 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2f67>
   2ff80:	mov    %rdi,%rdx
   2ff83:	mov    %r12,%rdi
   2ff86:	mov    %r13,%rsi
   2ff89:	mov    $0x1,%ecx
   2ff8e:	callq  4574e <rfc_wrap>
   2ff93:	mov    %rax,%rdi
   2ff96:	jmpq   2df44 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2f84>
   2ff9b:	mov    %rax,%rdx
   2ff9e:	mov    %r12,%rdi
   2ffa1:	mov    %r13,%rsi
   2ffa4:	mov    $0x1,%ecx
   2ffa9:	callq  4574e <rfc_wrap>
   2ffae:	jmpq   2df5d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2f9d>
   2ffb3:	mov    %rdi,%r8
   2ffb6:	mov    %r12,%rdi
   2ffb9:	mov    %r13,%rsi
   2ffbc:	mov    $0x1,%edx
   2ffc1:	mov    %r11,%rcx
   2ffc4:	callq  45448 <heap_alloc_miss>
   2ffc9:	mov    %r8,%rdi
   2ffcc:	mov    %rcx,%r11
   2ffcf:	mov    %rax,%r10
   2ffd2:	jmpq   2dfc7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3007>
   2ffd7:	mov    %rdi,0x8(%rsp)
   2ffdc:	mov    %r12,%rdi
   2ffdf:	mov    %r13,%rsi
   2ffe2:	mov    %r9,%rdx
   2ffe5:	mov    $0x1,%ecx
   2ffea:	mov    %r11,%r8
   2ffed:	callq  4574e <rfc_wrap>
   2fff2:	mov    0x8(%rsp),%rdi
   2fff7:	mov    %r8,%r11
   2fffa:	jmpq   2dff0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3030>
   2ffff:	mov    %rdi,0x8(%rsp)
   30004:	mov    %r12,%rdi
   30007:	mov    %r13,%rsi
   3000a:	mov    %r15,%rdx
   3000d:	mov    $0x1,%ecx
   30012:	mov    %r11,%r8
   30015:	callq  4574e <rfc_wrap>
   3001a:	mov    0x8(%rsp),%rdi
   3001f:	mov    %r8,%r11
   30022:	mov    %rax,%r15
   30025:	jmpq   2e003 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3043>
   3002a:	mov    %rdi,%r15
   3002d:	mov    %r12,%rdi
   30030:	mov    %r13,%rsi
   30033:	mov    $0x2,%edx
   30038:	mov    %r11,%r8
   3003b:	callq  45448 <heap_alloc_miss>
   30040:	mov    %r15,%rdi
   30043:	mov    %r8,%r11
   30046:	mov    %rax,%r8
   30049:	jmpq   2e02f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x306f>
   3004e:	mov    %rdi,%r15
   30051:	mov    %r12,%rdi
   30054:	mov    %r13,%rsi
   30057:	mov    %r11,%rdx
   3005a:	mov    $0x1,%ecx
   3005f:	callq  4574e <rfc_wrap>
   30064:	mov    %r15,%rdi
   30067:	mov    %rax,%r11
   3006a:	jmpq   2e041 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3081>
   3006f:	mov    %rdi,%r15
   30072:	mov    %r12,%rdi
   30075:	mov    %r13,%rsi
   30078:	mov    %r10,%rdx
   3007b:	mov    $0x1,%ecx
   30080:	callq  4574e <rfc_wrap>
   30085:	mov    %r15,%rdi
   30088:	mov    %rax,%r10
   3008b:	jmpq   2e055 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3095>
   30090:	mov    %rdi,%rcx
   30093:	mov    %r12,%rdi
   30096:	mov    %r13,%rsi
   30099:	xor    %edx,%edx
   3009b:	callq  45448 <heap_alloc_miss>
   300a0:	mov    %rcx,%rdi
   300a3:	mov    %rax,%r15
   300a6:	cmp    %rbp,%rbx
   300a9:	jne    2e08e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x30ce>
   300af:	mov    %rdi,%r10
   300b2:	mov    %r12,%rdi
   300b5:	mov    %r13,%rsi
   300b8:	mov    %r9,%rdx
   300bb:	mov    $0x1,%ecx
   300c0:	callq  4574e <rfc_wrap>
   300c5:	mov    %r10,%rdi
   300c8:	mov    %rax,%r9
   300cb:	jmpq   2e08e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x30ce>
   300d0:	mov    %rdi,%r9
   300d3:	mov    %r12,%rdi
   300d6:	mov    %r13,%rsi
   300d9:	mov    $0x1,%edx
   300de:	callq  45448 <heap_alloc_miss>
   300e3:	mov    %r9,%rdi
   300e6:	mov    %rax,%r10
   300e9:	jmpq   2e0b9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x30f9>
   300ee:	mov    %rdi,%rdx
   300f1:	mov    %r12,%rdi
   300f4:	mov    %r13,%rsi
   300f7:	mov    $0x1,%ecx
   300fc:	callq  4574e <rfc_wrap>
   30101:	mov    %rax,%rdi
   30104:	movabs $0x2002d0000000000,%r14
   3010e:	mov    %rdi,(%r12,%r10,8)
   30112:	cmp    %rbx,%r15
   30115:	jae    2e0e9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3129>
   3011b:	mov    %r12,%rdi
   3011e:	mov    %r13,%rsi
   30121:	mov    %r15,%rdx
   30124:	mov    $0x1,%ecx
   30129:	callq  4574e <rfc_wrap>
   3012e:	mov    %rax,%r15
   30131:	jmpq   2e0e9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3129>
   30136:	mov    %r12,%rdi
   30139:	mov    %rsi,%rcx
   3013c:	mov    %r13,%rsi
   3013f:	mov    $0x1,%edx
   30144:	callq  45448 <heap_alloc_miss>
   30149:	mov    %rcx,%rsi
   3014c:	mov    %rax,%r9
   3014f:	jmpq   2e118 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3158>
   30154:	mov    %r12,%rdi
   30157:	mov    %r13,%rsi
   3015a:	mov    $0x2,%edx
   3015f:	callq  45448 <heap_alloc_miss>
   30164:	mov    %rax,%r8
   30167:	jmpq   2e23c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x327c>
   3016c:	mov    %r12,%rdi
   3016f:	mov    %r13,%rsi
   30172:	mov    %rbx,%rdx
   30175:	mov    $0x1,%ecx
   3017a:	callq  4574e <rfc_wrap>
   3017f:	jmpq   2e259 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x3299>
   30184:	mov    %r12,%rdi
   30187:	mov    %r13,%rsi
   3018a:	mov    $0x1,%ecx
   3018f:	callq  4574e <rfc_wrap>
   30194:	mov    %rax,%rdx
   30197:	jmpq   2e27b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x32bb>
   3019c:	mov    %r12,%rdi
   3019f:	mov    %r13,%rsi
   301a2:	mov    %rax,%rdx
   301a5:	mov    $0x1,%ecx
   301aa:	callq  4574e <rfc_wrap>
   301af:	jmpq   2e294 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x32d4>
   301b4:	mov    %r12,%rdi
   301b7:	mov    %r13,%rsi
   301ba:	mov    %rdx,%rcx
   301bd:	mov    $0x1,%edx
   301c2:	mov    %r9,%r14
   301c5:	mov    %r8,%r9
   301c8:	mov    %r11,%r8
   301cb:	callq  45321 <heap_hand>
   301d0:	mov    %r8,%r11
   301d3:	mov    %r9,%r8
   301d6:	mov    %r14,%r9
   301d9:	mov    %rcx,%rdx
   301dc:	jmpq   2b898 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8d8>
   301e1:	mov    %r12,%rdi
   301e4:	mov    %r13,%rsi
   301e7:	mov    %rdx,%rcx
   301ea:	mov    $0x2,%edx
   301ef:	mov    %r8,%r9
   301f2:	mov    %r11,%r8
   301f5:	callq  45321 <heap_hand>
   301fa:	mov    %r8,%r11
   301fd:	mov    %r9,%r8
   30200:	mov    %rcx,%rdx
   30203:	jmpq   2b9a6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9e6>
   30208:	mov    %r12,%rdi
   3020b:	mov    %r13,%rsi
   3020e:	mov    %rdx,%rcx
   30211:	mov    $0x1,%edx
   30216:	mov    %r9,%r14
   30219:	mov    %r8,%r9
   3021c:	mov    %r11,%r8
   3021f:	callq  45321 <heap_hand>
   30224:	mov    %r8,%r11
   30227:	mov    %r9,%r8
   3022a:	mov    %r14,%r9
   3022d:	mov    %rcx,%rdx
   30230:	jmpq   2baa8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xae8>
   30235:	mov    %rdi,%r14
   30238:	mov    %r12,%rdi
   3023b:	mov    %r13,%rsi
   3023e:	mov    %rdx,%rcx
   30241:	mov    $0x2,%edx
   30246:	mov    %r9,%rbp
   30249:	mov    %r8,%r9
   3024c:	mov    %r11,%r8
   3024f:	callq  45321 <heap_hand>
   30254:	mov    %r14,%rdi
   30257:	mov    %r8,%r11
   3025a:	mov    %r9,%r8
   3025d:	mov    %rbp,%r9
   30260:	mov    %rcx,%rdx
   30263:	jmpq   2bba7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbe7>
   30268:	mov    %r12,%rdi
   3026b:	mov    %r13,%rsi
   3026e:	mov    %rdx,%rcx
   30271:	mov    $0x1,%edx
   30276:	mov    %r8,%r9
   30279:	mov    %r11,%r8
   3027c:	callq  45321 <heap_hand>
   30281:	mov    %r8,%r11
   30284:	mov    %r9,%r8
   30287:	mov    %rcx,%rdx
   3028a:	jmpq   2bca0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xce0>
   3028f:	mov    %rdi,%r14
   30292:	mov    %r12,%rdi
   30295:	mov    %r13,%rsi
   30298:	mov    %rdx,%rcx
   3029b:	mov    $0x2,%edx
   302a0:	mov    %r8,%r9
   302a3:	mov    %r11,%r8
   302a6:	callq  45321 <heap_hand>
   302ab:	mov    %r14,%rdi
   302ae:	mov    %r8,%r11
   302b1:	mov    %r9,%r8
   302b4:	mov    %rcx,%rdx
   302b7:	jmpq   2bd9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xddd>
   302bc:	mov    %r12,%rdi
   302bf:	mov    %r13,%rsi
   302c2:	mov    $0x1,%edx
   302c7:	mov    %r11,%rcx
   302ca:	callq  45321 <heap_hand>
   302cf:	mov    %rcx,%r11
   302d2:	jmpq   2be8f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xecf>
   302d7:	mov    %r12,%rdi
   302da:	mov    %r13,%rsi
   302dd:	mov    $0x1,%edx
   302e2:	mov    %r11,%rcx
   302e5:	callq  45321 <heap_hand>
   302ea:	mov    %rcx,%r11
   302ed:	jmpq   2c374 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x13b4>
   302f2:	mov    %r12,%rdi
   302f5:	mov    %r13,%rsi
   302f8:	mov    $0x1,%edx
   302fd:	mov    %r11,%rcx
   30300:	callq  45321 <heap_hand>
   30305:	mov    %rcx,%r11
   30308:	jmpq   2c715 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1755>
   3030d:	mov    %rdi,%r8
   30310:	mov    %r12,%rdi
   30313:	mov    %r13,%rsi
   30316:	mov    $0x1,%edx
   3031b:	mov    %r11,%rcx
   3031e:	callq  45321 <heap_hand>
   30323:	mov    %r8,%rdi
   30326:	mov    %rcx,%r11
   30329:	jmpq   2cacc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b0c>
   3032e:	mov    %rdi,%r9
   30331:	mov    %r12,%rdi
   30334:	mov    %r13,%rsi
   30337:	mov    $0x1,%edx
   3033c:	mov    %r11,%rcx
   3033f:	callq  45321 <heap_hand>
   30344:	mov    %r9,%rdi
   30347:	mov    %rcx,%r11
   3034a:	jmpq   2cd02 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d42>
   3034f:	mov    %rdi,%r9
   30352:	mov    %r12,%rdi
   30355:	mov    %r13,%rsi
   30358:	mov    $0x1,%edx
   3035d:	mov    %r11,%rcx
   30360:	callq  45321 <heap_hand>
   30365:	mov    %r9,%rdi
   30368:	mov    %rcx,%r11
   3036b:	jmpq   2cfbd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ffd>
   30370:	mov    %r12,%rdi
   30373:	mov    %r13,%rsi
   30376:	mov    $0x1,%edx
   3037b:	mov    %r11,%rcx
   3037e:	callq  45321 <heap_hand>
   30383:	mov    %rcx,%r11
   30386:	jmpq   2d24b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x228b>
   3038b:	mov    %rdi,%r9
   3038e:	mov    %r12,%rdi
   30391:	mov    %r13,%rsi
   30394:	mov    $0x1,%edx
   30399:	mov    %r11,%rcx
   3039c:	callq  45321 <heap_hand>
   303a1:	mov    %r9,%rdi
   303a4:	mov    %rcx,%r11
   303a7:	jmpq   2d4d7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2517>
   303ac:	mov    %r12,%rdi
   303af:	mov    %r13,%rsi
   303b2:	mov    $0x1,%edx
   303b7:	mov    %r11,%rcx
   303ba:	callq  45321 <heap_hand>
   303bf:	mov    %rcx,%r11
   303c2:	jmpq   2d74c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x278c>
   303c7:	shl    $0x20,%rcx
   303cb:	or     %rdi,%rcx
   303ce:	shr    $0x18,%rcx
   303d2:	mov    (%r12,%rcx,8),%r9
   303d6:	mov    0x8(%r12,%rcx,8),%rsi
   303db:	mov    %rsi,0x8(%rsp)
   303e0:	mov    %r12,%rdi
   303e3:	mov    %r13,%rsi
   303e6:	mov    %rdx,0x28(%rsp)
   303eb:	mov    %r14,%rdx
   303ee:	mov    %r8,%r14
   303f1:	mov    $0x2,%r8d
   303f7:	mov    %r10,%rbx
   303fa:	mov    %r11,%r10
   303fd:	callq  453b2 <span_fade>
   30402:	mov    %r14,%r8
   30405:	mov    %r10,%r11
   30408:	mov    %rbx,%r10
   3040b:	mov    0x28(%rsp),%rdx
   30410:	mov    %rbp,%rbx
   30413:	mov    0x20(%rsp),%rbp
   30418:	jmpq   2b898 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8d8>
   3041d:	shl    $0x20,%rcx
   30421:	or     %rdx,%rcx
   30424:	shr    $0x18,%rcx
   30428:	mov    (%r12,%rcx,8),%rdx
   3042c:	mov    %rdx,0x10(%rsp)
   30431:	mov    0x8(%r12,%rcx,8),%rdx
   30436:	mov    %rdx,0x18(%rsp)
   3043b:	mov    0x10(%r12,%rcx,8),%rdx
   30440:	mov    %rdx,0x8(%rsp)
   30445:	mov    %r12,%rdi
   30448:	mov    %r13,%rsi
   3044b:	mov    %r14,%rdx
   3044e:	mov    %r8,%r14
   30451:	mov    $0x3,%r8d
   30457:	mov    %rbp,0x20(%rsp)
   3045c:	mov    %rbx,%rbp
   3045f:	mov    %r10,%rbx
   30462:	mov    %r11,%r10
   30465:	callq  453b2 <span_fade>
   3046a:	mov    %r14,%r8
   3046d:	mov    %r10,%r11
   30470:	mov    %rbx,%r10
   30473:	mov    %rbp,%rbx
   30476:	mov    0x20(%rsp),%rbp
   3047b:	mov    %r9,%rdx
   3047e:	jmpq   2b9a6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9e6>
   30483:	shl    $0x20,%rcx
   30487:	or     %rdi,%rcx
   3048a:	shr    $0x18,%rcx
   3048e:	mov    (%r12,%rcx,8),%rsi
   30492:	mov    %rsi,0x20(%rsp)
   30497:	mov    0x8(%r12,%rcx,8),%rsi
   3049c:	mov    %rsi,0x10(%rsp)
   304a1:	mov    %r12,%rdi
   304a4:	mov    %r13,%rsi
   304a7:	mov    %rdx,%r9
   304aa:	mov    %r14,%rdx
   304ad:	mov    $0x2,%r8d
   304b3:	mov    %rbx,%r14
   304b6:	mov    %r10,%rbx
   304b9:	mov    %r11,%r10
   304bc:	callq  453b2 <span_fade>
   304c1:	mov    %r10,%r11
   304c4:	mov    %rbx,%r10
   304c7:	mov    %r14,%rbx
   304ca:	mov    %r9,%rdx
   304cd:	mov    0x20(%rsp),%r9
   304d2:	mov    %rbp,%r8
   304d5:	jmpq   2baa8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xae8>
   304da:	shl    $0x20,%rcx
   304de:	or     %rdx,%rcx
   304e1:	shr    $0x18,%rcx
   304e5:	mov    (%r12,%rcx,8),%rdx
   304e9:	mov    %rdx,0x10(%rsp)
   304ee:	mov    0x8(%r12,%rcx,8),%rdx
   304f3:	mov    %rdx,0x48(%rsp)
   304f8:	mov    0x10(%r12,%rcx,8),%rdx
   304fd:	mov    %rdx,0x40(%rsp)
   30502:	mov    %r12,%rdi
   30505:	mov    %r13,%rsi
   30508:	mov    %r14,%rdx
   3050b:	mov    %r8,%r14
   3050e:	mov    $0x3,%r8d
   30514:	mov    %rbx,%r9
   30517:	mov    %r10,%rbx
   3051a:	mov    %r11,%r10
   3051d:	callq  453b2 <span_fade>
   30522:	mov    0x40(%rsp),%rdi
   30527:	mov    %r14,%r8
   3052a:	mov    %r10,%r11
   3052d:	mov    %rbx,%r10
   30530:	mov    %r9,%rbx
   30533:	mov    %rbp,%rdx
   30536:	mov    0x48(%rsp),%r9
   3053b:	jmpq   2bba7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbe7>
   30540:	shl    $0x20,%rcx
   30544:	or     %rdi,%rcx
   30547:	shr    $0x18,%rcx
   3054b:	mov    (%r12,%rcx,8),%rbp
   3054f:	mov    0x8(%r12,%rcx,8),%rsi
   30554:	mov    %rsi,0x8(%rsp)
   30559:	mov    %r12,%rdi
   3055c:	mov    %r13,%rsi
   3055f:	mov    %rdx,%r9
   30562:	mov    %r14,%rdx
   30565:	mov    %r8,%r14
   30568:	mov    $0x2,%r8d
   3056e:	mov    %r10,%rbx
   30571:	mov    %r11,%r10
   30574:	callq  453b2 <span_fade>
   30579:	mov    %r14,%r8
   3057c:	mov    %r10,%r11
   3057f:	mov    %rbx,%r10
   30582:	mov    %r9,%rdx
   30585:	jmpq   2bca0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xce0>
   3058a:	shl    $0x20,%rcx
   3058e:	or     %rdx,%rcx
   30591:	shr    $0x18,%rcx
   30595:	mov    (%r12,%rcx,8),%rdx
   30599:	mov    %rdx,0x10(%rsp)
   3059e:	mov    0x8(%r12,%rcx,8),%rbp
   305a3:	mov    0x10(%r12,%rcx,8),%rdx
   305a8:	mov    %rdx,0x8(%rsp)
   305ad:	mov    %r12,%rdi
   305b0:	mov    %r13,%rsi
   305b3:	mov    %r14,%rdx
   305b6:	mov    %r8,%r14
   305b9:	mov    $0x3,%r8d
   305bf:	mov    %r10,%rbx
   305c2:	mov    %r11,%r10
   305c5:	callq  453b2 <span_fade>
   305ca:	mov    %rbp,%rdi
   305cd:	mov    %r14,%r8
   305d0:	mov    %r10,%r11
   305d3:	mov    %rbx,%r10
   305d6:	mov    0x10(%rsp),%rbx
   305db:	mov    %r9,%rdx
   305de:	jmpq   2bd9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xddd>
   305e3:	shl    $0x20,%rcx
   305e7:	or     %rax,%rcx
   305ea:	shr    $0x18,%rcx
   305ee:	mov    (%r12,%rcx,8),%rax
   305f2:	mov    %rax,0x18(%rsp)
   305f7:	mov    0x8(%r12,%rcx,8),%rax
   305fc:	mov    %r12,%rdi
   305ff:	mov    %r13,%rsi
   30602:	mov    $0x2,%r8d
   30608:	mov    %r9,%r10
   3060b:	mov    %r11,%r9
   3060e:	callq  453b2 <span_fade>
   30613:	mov    %r9,%r11
   30616:	mov    %r10,%r9
   30619:	jmpq   2be8f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xecf>
   3061e:	shl    $0x20,%rcx
   30622:	or     %rax,%rcx
   30625:	shr    $0x18,%rcx
   30629:	mov    (%r12,%rcx,8),%rax
   3062d:	mov    %rax,0x20(%rsp)
   30632:	mov    0x8(%r12,%rcx,8),%rax
   30637:	mov    %r12,%rdi
   3063a:	mov    %r13,%rsi
   3063d:	mov    $0x2,%r8d
   30643:	mov    %r11,%r9
   30646:	callq  453b2 <span_fade>
   3064b:	mov    %r9,%r11
   3064e:	jmpq   2c374 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x13b4>
   30653:	shl    $0x20,%rcx
   30657:	or     %rax,%rcx
   3065a:	shr    $0x18,%rcx
   3065e:	mov    (%r12,%rcx,8),%r10
   30662:	mov    0x8(%r12,%rcx,8),%rax
   30667:	mov    %r12,%rdi
   3066a:	mov    %r13,%rsi
   3066d:	mov    $0x2,%r8d
   30673:	callq  453b2 <span_fade>
   30678:	mov    %r9,%r11
   3067b:	mov    %r14,%r9
   3067e:	jmpq   2c715 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1755>
   30683:	shl    $0x20,%rcx
   30687:	or     %rax,%rcx
   3068a:	shr    $0x18,%rcx
   3068e:	mov    (%r12,%rcx,8),%rax
   30692:	mov    %rax,0x20(%rsp)
   30697:	mov    0x8(%r12,%rcx,8),%rax
   3069c:	mov    %rdi,%r10
   3069f:	mov    %r12,%rdi
   306a2:	mov    %r13,%rsi
   306a5:	mov    $0x2,%r8d
   306ab:	callq  453b2 <span_fade>
   306b0:	mov    %r10,%rdi
   306b3:	mov    %r9,%r11
   306b6:	mov    %r14,%r9
   306b9:	jmpq   2cacc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b0c>
   306be:	shl    $0x20,%rcx
   306c2:	or     %rax,%rcx
   306c5:	shr    $0x18,%rcx
   306c9:	mov    (%r12,%rcx,8),%rax
   306cd:	mov    %rax,0x8(%rsp)
   306d2:	mov    0x8(%r12,%rcx,8),%rax
   306d7:	mov    %r12,%rdi
   306da:	mov    %r13,%rsi
   306dd:	mov    %r8,%r14
   306e0:	mov    $0x2,%r8d
   306e6:	callq  453b2 <span_fade>
   306eb:	mov    0x8(%rsp),%rdi
   306f0:	mov    %r14,%r8
   306f3:	mov    %r10,%r11
   306f6:	mov    %rbx,%r10
   306f9:	mov    %rbp,%rbx
   306fc:	mov    %r9,%rbp
   306ff:	jmpq   2cd02 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d42>
   30704:	shl    $0x20,%rcx
   30708:	or     %rax,%rcx
   3070b:	shr    $0x18,%rcx
   3070f:	mov    (%r12,%rcx,8),%r14
   30713:	mov    0x8(%r12,%rcx,8),%rax
   30718:	mov    %r12,%rdi
   3071b:	mov    %r13,%rsi
   3071e:	mov    %r8,%rbx
   30721:	mov    $0x2,%r8d
   30727:	callq  453b2 <span_fade>
   3072c:	mov    %r14,%rdi
   3072f:	mov    %rbx,%r8
   30732:	mov    %r9,%r11
   30735:	jmpq   2cfbd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ffd>
   3073a:	shl    $0x20,%rcx
   3073e:	or     %rax,%rcx
   30741:	shr    $0x18,%rcx
   30745:	mov    (%r12,%rcx,8),%rbp
   30749:	mov    0x8(%r12,%rcx,8),%rax
   3074e:	mov    %r12,%rdi
   30751:	mov    %r13,%rsi
   30754:	mov    %rbx,%r14
   30757:	mov    %r8,%rbx
   3075a:	mov    $0x2,%r8d
   30760:	callq  453b2 <span_fade>
   30765:	mov    %rbx,%r8
   30768:	mov    %r14,%rbx
   3076b:	mov    %r9,%r11
   3076e:	jmpq   2d24b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x228b>
   30773:	shl    $0x20,%rcx
   30777:	or     %rax,%rcx
   3077a:	shr    $0x18,%rcx
   3077e:	mov    (%r12,%rcx,8),%rbp
   30782:	mov    0x8(%r12,%rcx,8),%rax
   30787:	mov    %r12,%rdi
   3078a:	mov    %r13,%rsi
   3078d:	mov    %rbx,0x10(%rsp)
   30792:	mov    %r8,%rbx
   30795:	mov    $0x2,%r8d
   3079b:	callq  453b2 <span_fade>
   307a0:	mov    %rbx,%r8
   307a3:	mov    0x10(%rsp),%rbx
   307a8:	mov    %r9,%r11
   307ab:	mov    %r14,%rdi
   307ae:	jmpq   2d4d7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2517>
   307b3:	shl    $0x20,%rcx
   307b7:	or     %rax,%rcx
   307ba:	shr    $0x18,%rcx
   307be:	mov    (%r12,%rcx,8),%r9
   307c2:	mov    0x8(%r12,%rcx,8),%rax
   307c7:	mov    %r12,%rdi
   307ca:	mov    %r13,%rsi
   307cd:	mov    $0x2,%r8d
   307d3:	callq  453b2 <span_fade>
   307d8:	mov    %r10,%r11
   307db:	jmpq   2d74c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x278c>
   307e0:	mov    %r12,%rdi
   307e3:	mov    %r13,%rsi
   307e6:	mov    %r8,%rbx
   307e9:	mov    %rdx,%r8
   307ec:	xor    %edx,%edx
   307ee:	mov    %r11,%r14
   307f1:	callq  45321 <heap_hand>
   307f6:	mov    %r14,%r11
   307f9:	mov    %r8,%rdx
   307fc:	mov    %rbx,%r8
   307ff:	mov    %rbp,%rbx
   30802:	mov    0x20(%rsp),%rbp
   30807:	cmp    $0x3108280,%rcx
   3080e:	jb     2b898 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8d8>
   30814:	jmpq   2b860 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x8a0>
   30819:	mov    %r12,%rdi
   3081c:	mov    %r13,%rsi
   3081f:	xor    %edx,%edx
   30821:	mov    %rbx,%r14
   30824:	mov    %r8,%rbx
   30827:	mov    %r11,%r8
   3082a:	callq  45321 <heap_hand>
   3082f:	mov    %r8,%r11
   30832:	mov    %rbx,%r8
   30835:	mov    %r14,%rbx
   30838:	mov    %r9,%rdx
   3083b:	cmp    $0x3108280,%rcx
   30842:	jae    2b96e <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9ae>
   30848:	jmpq   2b9a6 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9e6>
   3084d:	mov    %r12,%rdi
   30850:	mov    %r13,%rsi
   30853:	mov    %rdx,%r8
   30856:	xor    %edx,%edx
   30858:	mov    %r9,%r14
   3085b:	mov    %r11,%r9
   3085e:	callq  45321 <heap_hand>
   30863:	mov    %r9,%r11
   30866:	mov    %r14,%r9
   30869:	mov    %r8,%rdx
   3086c:	mov    %rbp,%r8
   3086f:	cmp    $0x3108280,%rcx
   30876:	jae    2ba70 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xab0>
   3087c:	jmpq   2baa8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xae8>
   30881:	mov    %rdi,0x40(%rsp)
   30886:	mov    %r12,%rdi
   30889:	mov    %r13,%rsi
   3088c:	xor    %edx,%edx
   3088e:	mov    %rbx,%r14
   30891:	mov    %r8,%rbx
   30894:	mov    %r11,%r8
   30897:	callq  45321 <heap_hand>
   3089c:	mov    0x40(%rsp),%rdi
   308a1:	mov    %r8,%r11
   308a4:	mov    %rbx,%r8
   308a7:	mov    %r14,%rbx
   308aa:	mov    %rbp,%rdx
   308ad:	cmp    $0x3108280,%rcx
   308b4:	jae    2bb6f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbaf>
   308ba:	jmpq   2bba7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbe7>
   308bf:	mov    %r12,%rdi
   308c2:	mov    %r13,%rsi
   308c5:	mov    %r8,%rbx
   308c8:	mov    %rdx,%r8
   308cb:	xor    %edx,%edx
   308cd:	mov    %r11,%r9
   308d0:	callq  45321 <heap_hand>
   308d5:	mov    %r9,%r11
   308d8:	mov    %r8,%rdx
   308db:	mov    %rbx,%r8
   308de:	cmp    $0x3108280,%rcx
   308e5:	jae    2bc68 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xca8>
   308eb:	jmpq   2bca0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xce0>
   308f0:	mov    %rdi,%rbp
   308f3:	mov    %r12,%rdi
   308f6:	mov    %r13,%rsi
   308f9:	xor    %edx,%edx
   308fb:	mov    %rbx,%r14
   308fe:	mov    %r8,%rbx
   30901:	mov    %r11,%r8
   30904:	callq  45321 <heap_hand>
   30909:	mov    %rbp,%rdi
   3090c:	mov    %r8,%r11
   3090f:	mov    %rbx,%r8
   30912:	mov    %r14,%rbx
   30915:	mov    %r9,%rdx
   30918:	cmp    $0x3108280,%rcx
   3091f:	jae    2bd65 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xda5>
   30925:	jmpq   2bd9d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xddd>
   3092a:	mov    %r12,%rdi
   3092d:	mov    %r13,%rsi
   30930:	xor    %edx,%edx
   30932:	mov    %r11,%r8
   30935:	callq  45321 <heap_hand>
   3093a:	mov    %r8,%r11
   3093d:	cmp    $0x3108280,%rcx
   30944:	jae    2be57 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xe97>
   3094a:	jmpq   2be8f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xecf>
   3094f:	mov    %r12,%rdi
   30952:	mov    %r13,%rsi
   30955:	xor    %edx,%edx
   30957:	mov    %r11,%r8
   3095a:	callq  45321 <heap_hand>
   3095f:	mov    %r8,%r11
   30962:	cmp    $0x3108280,%rcx
   30969:	jae    2c33c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x137c>
   3096f:	jmpq   2c374 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x13b4>
   30974:	mov    %r12,%rdi
   30977:	mov    %r13,%rsi
   3097a:	xor    %edx,%edx
   3097c:	callq  45321 <heap_hand>
   30981:	mov    %r9,%r11
   30984:	mov    %r14,%r9
   30987:	cmp    $0x3108280,%rcx
   3098e:	jb     2c715 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1755>
   30994:	jmpq   2c6dd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x171d>
   30999:	mov    %rdi,%r8
   3099c:	mov    %r12,%rdi
   3099f:	mov    %r13,%rsi
   309a2:	xor    %edx,%edx
   309a4:	callq  45321 <heap_hand>
   309a9:	mov    %r8,%rdi
   309ac:	mov    %r9,%r11
   309af:	mov    %r14,%r9
   309b2:	cmp    $0x3108280,%rcx
   309b9:	jb     2cacc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b0c>
   309bf:	jmpq   2ca94 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ad4>
   309c4:	mov    %rdi,%r14
   309c7:	mov    %r12,%rdi
   309ca:	mov    %r13,%rsi
   309cd:	xor    %edx,%edx
   309cf:	callq  45321 <heap_hand>
   309d4:	mov    %r14,%rdi
   309d7:	jmpq   2ccb5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1cf5>
   309dc:	mov    %rdi,%rbx
   309df:	mov    %r12,%rdi
   309e2:	mov    %r13,%rsi
   309e5:	xor    %edx,%edx
   309e7:	callq  45321 <heap_hand>
   309ec:	mov    %rbx,%rdi
   309ef:	mov    %r9,%r11
   309f2:	cmp    $0x3108280,%rcx
   309f9:	jae    2cf85 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1fc5>
   309ff:	jmpq   2cfbd <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ffd>
   30a04:	mov    %r12,%rdi
   30a07:	mov    %r13,%rsi
   30a0a:	xor    %edx,%edx
   30a0c:	callq  45321 <heap_hand>
   30a11:	mov    %r9,%r11
   30a14:	cmp    $0x3108280,%rcx
   30a1b:	jae    2d213 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2253>
   30a21:	jmpq   2d24b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x228b>
   30a26:	mov    %r12,%rdi
   30a29:	mov    %r13,%rsi
   30a2c:	xor    %edx,%edx
   30a2e:	callq  45321 <heap_hand>
   30a33:	mov    %r9,%r11
   30a36:	mov    %r14,%rdi
   30a39:	cmp    $0x3108280,%rcx
   30a40:	jb     2d4d7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2517>
   30a46:	jmpq   2d49f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x24df>
   30a4b:	mov    %r12,%rdi
   30a4e:	mov    %r13,%rsi
   30a51:	xor    %edx,%edx
   30a53:	callq  45321 <heap_hand>
   30a58:	mov    %r10,%r11
   30a5b:	cmp    $0x3108280,%rcx
   30a62:	jae    2d714 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2754>
   30a68:	jmpq   2d74c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x278c>
   30a6d:	mov    %rdi,%r8
   30a70:	mov    %r12,%rdi
   30a73:	mov    %r13,%rsi
   30a76:	mov    %rbx,%rdx
   30a79:	mov    $0x2,%ecx
   30a7e:	callq  4574e <rfc_wrap>
   30a83:	mov    %r8,%rdi
   30a86:	mov    %rax,%rbx
   30a89:	jmpq   2dec8 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2f08>
   30a8e:	mov    %r15d,%ebp
   30a91:	mov    %r14,%r15
   30a94:	mov    %rdx,%r14
   30a97:	test   %r9,%rbx
   30a9a:	sete   %al
   30a9d:	cmp    $0xffffffffffffffff,%rbx
   30aa1:	sete   %cl
   30aa4:	or     %al,%cl
   30aa6:	and    %rbx,%r10
   30aa9:	cmp    $0x3108280,%r10
   30ab0:	setb   %al
   30ab3:	or     %cl,%al
   30ab5:	jne    30ac5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b05>
   30ab7:	mov    %r12,%rdi
   30aba:	mov    %r13,%rsi
   30abd:	mov    %rbx,%rdx
   30ac0:	callq  c660 <term_drop>
   30ac5:	test   %ebp,%ebp
   30ac7:	jne    30b14 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b54>
   30ac9:	mov    -0x18(%r15),%rcx
   30acd:	lea    -0x10(%r15),%rbx
   30ad1:	mov    -0x10(%r15),%r8d
   30ad5:	mov    %r12,%rdi
   30ad8:	mov    %r13,%rsi
   30adb:	mov    $0x157,%edx
   30ae0:	mov    $0x1,%r9d
   30ae6:	callq  caf0 <task_node>
   30aeb:	mov    %r14,(%r12,%rax,8)
   30aef:	movabs $0x501570000000000,%rcx
   30af9:	or     %rax,%rcx
   30afc:	mov    %rcx,-0x18(%r15)
   30b00:	mov    $0x1,%eax
   30b05:	mov    %rax,(%rbx)
   30b08:	lea    -0x2b87f(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   30b0f:	callq  452c0 <err_fail>
   30b14:	mov    %r14,(%r15)
   30b17:	add    $0x8,%r15
   30b1b:	mov    %r15,%rbx
   30b1e:	mov    $0x157,%eax
   30b23:	mov    %rax,(%rbx)
   30b26:	lea    -0x2b89d(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   30b2d:	callq  452c0 <err_fail>
   30b32:	mov    %r15d,%ebx
   30b35:	mov    %rdx,%r15
   30b38:	movabs $0x7e00000000000000,%rax
   30b42:	test   %rax,%r11
   30b45:	sete   %al
   30b48:	cmp    $0xffffffffffffffff,%r11
   30b4c:	sete   %cl
   30b4f:	or     %al,%cl
   30b51:	and    %r11,%r10
   30b54:	cmp    $0x3108280,%r10
   30b5b:	setb   %al
   30b5e:	or     %cl,%al
   30b60:	jne    30b70 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5bb0>
   30b62:	mov    %r11,%rdx
   30b65:	mov    %r12,%rdi
   30b68:	mov    %r13,%rsi
   30b6b:	callq  c660 <term_drop>
   30b70:	test   %ebx,%ebx
   30b72:	jne    30c43 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5c83>
   30b78:	mov    (%rsp),%rbx
   30b7c:	mov    -0x18(%rbx),%rcx
   30b80:	lea    -0x10(%rbx),%rax
   30b84:	mov    %rax,0x30(%rsp)
   30b89:	mov    -0x10(%rbx),%r8d
   30b8d:	mov    %r12,%rdi
   30b90:	mov    %r13,%rsi
   30b93:	mov    $0x154,%edx
   30b98:	mov    $0x1,%r9d
   30b9e:	callq  caf0 <task_node>
   30ba3:	mov    %r15,(%r12,%rax,8)
   30ba7:	movabs $0x501540000000000,%rcx
   30bb1:	or     %rax,%rcx
   30bb4:	mov    %rcx,-0x18(%rbx)
   30bb8:	movq   $0x1,-0x10(%rbx)
   30bc0:	mov    %r12,%rdi
   30bc3:	mov    %r13,%rsi
   30bc6:	mov    $0x155,%edx
   30bcb:	mov    $0x1,%r8d
   30bd1:	mov    $0x1,%r9d
   30bd7:	callq  caf0 <task_node>
   30bdc:	mov    %r14,(%r12,%rax,8)
   30be0:	movabs $0x501550000000000,%rcx
   30bea:	or     %rax,%rcx
   30bed:	mov    %rcx,-0x18(%rbx)
   30bf1:	movq   $0x1,-0x10(%rbx)
   30bf9:	mov    %r12,%rdi
   30bfc:	mov    %r13,%rsi
   30bff:	mov    $0x156,%edx
   30c04:	mov    $0x1,%r8d
   30c0a:	mov    $0x1,%r9d
   30c10:	callq  caf0 <task_node>
   30c15:	mov    %rbp,(%r12,%rax,8)
   30c19:	movabs $0x501560000000000,%rcx
   30c23:	or     %rax,%rcx
   30c26:	mov    %rcx,-0x18(%rbx)
   30c2a:	mov    $0x1,%eax
   30c2f:	mov    0x30(%rsp),%rbx
   30c34:	mov    %rax,(%rbx)
   30c37:	lea    -0x2b9ae(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   30c3e:	callq  452c0 <err_fail>
   30c43:	mov    (%rsp),%rbx
   30c47:	mov    %r15,(%rbx)
   30c4a:	movq   $0x154,0x8(%rbx)
   30c52:	mov    %r14,0x10(%rbx)
   30c56:	movq   $0x155,0x18(%rbx)
   30c5e:	mov    %rbp,0x20(%rbx)
   30c62:	add    $0x28,%rbx
   30c66:	mov    $0x156,%eax
   30c6b:	mov    %rax,(%rbx)
   30c6e:	lea    -0x2b9e5(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   30c75:	callq  452c0 <err_fail>
   30c7a:	mov    %rbx,0x8(%rsp)
   30c7f:	mov    %r15d,0x30(%rsp)
   30c84:	mov    %rdx,0x28(%rsp)
   30c89:	movabs $0x7e00000000000000,%r15
   30c93:	test   %r15,%r11
   30c96:	sete   %al
   30c99:	cmp    $0xffffffffffffffff,%r11
   30c9d:	sete   %cl
   30ca0:	or     %al,%cl
   30ca2:	mov    %r11,%rdx
   30ca5:	mov    %r10,%rbx
   30ca8:	and    %r10,%r11
   30cab:	cmp    $0x3108280,%r11
   30cb2:	setb   %al
   30cb5:	or     %cl,%al
   30cb7:	jne    30cc4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5d04>
   30cb9:	mov    %r12,%rdi
   30cbc:	mov    %r13,%rsi
   30cbf:	callq  c660 <term_drop>
   30cc4:	test   %r15,%rbp
   30cc7:	sete   %al
   30cca:	cmp    $0xffffffffffffffff,%rbp
   30cce:	sete   %cl
   30cd1:	or     %al,%cl
   30cd3:	mov    %rbp,%rax
   30cd6:	and    %rbx,%rax
   30cd9:	cmp    $0x3108280,%rax
   30cdf:	setb   %al
   30ce2:	or     %cl,%al
   30ce4:	jne    30cf4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5d34>
   30ce6:	mov    %r12,%rdi
   30ce9:	mov    %r13,%rsi
   30cec:	mov    %rbp,%rdx
   30cef:	callq  c660 <term_drop>
   30cf4:	mov    0x8(%rsp),%rdx
   30cf9:	test   %r15,%rdx
   30cfc:	sete   %al
   30cff:	cmp    $0xffffffffffffffff,%rdx
   30d03:	sete   %cl
   30d06:	or     %al,%cl
   30d08:	and    %rdx,%rbx
   30d0b:	cmp    $0x3108280,%rbx
   30d12:	setb   %al
   30d15:	or     %cl,%al
   30d17:	jne    30d29 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5d69>
   30d19:	mov    %r12,%rdi
   30d1c:	mov    %r13,%rsi
   30d1f:	mov    0x8(%rsp),%rdx
   30d24:	callq  c660 <term_drop>
   30d29:	cmpl   $0x0,0x30(%rsp)
   30d2e:	jne    31b07 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6b47>
   30d34:	mov    (%rsp),%rbp
   30d38:	mov    -0x18(%rbp),%rcx
   30d3c:	lea    -0x10(%rbp),%r15
   30d40:	mov    -0x10(%rbp),%r8d
   30d44:	mov    %r12,%rdi
   30d47:	mov    %r13,%rsi
   30d4a:	mov    $0x142,%edx
   30d4f:	mov    $0x1,%r9d
   30d55:	callq  caf0 <task_node>
   30d5a:	mov    0x28(%rsp),%rcx
   30d5f:	mov    %rcx,(%r12,%rax,8)
   30d63:	movabs $0x501420000000000,%rcx
   30d6d:	or     %rax,%rcx
   30d70:	mov    %rcx,-0x18(%rbp)
   30d74:	movq   $0x1,-0x10(%rbp)
   30d7c:	mov    %r12,%rdi
   30d7f:	mov    %r13,%rsi
   30d82:	mov    $0x143,%edx
   30d87:	mov    $0x1,%r8d
   30d8d:	mov    $0x1,%r9d
   30d93:	callq  caf0 <task_node>
   30d98:	mov    %r14,(%r12,%rax,8)
   30d9c:	movabs $0x501430000000000,%rcx
   30da6:	jmpq   30fd5 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6015>
   30dab:	mov    %r15d,0x30(%rsp)
   30db0:	mov    %rdx,0x28(%rsp)
   30db5:	movabs $0x7e00000000000000,%rbp
   30dbf:	test   %rbp,%r11
   30dc2:	sete   %al
   30dc5:	cmp    $0xffffffffffffffff,%r11
   30dc9:	sete   %cl
   30dcc:	or     %al,%cl
   30dce:	mov    %r11,%rdx
   30dd1:	mov    %r10,%r15
   30dd4:	and    %r10,%r11
   30dd7:	cmp    $0x3108280,%r11
   30dde:	setb   %al
   30de1:	or     %cl,%al
   30de3:	jne    30df0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5e30>
   30de5:	mov    %r12,%rdi
   30de8:	mov    %r13,%rsi
   30deb:	callq  c660 <term_drop>
   30df0:	test   %rbp,%rbx
   30df3:	sete   %al
   30df6:	cmp    $0xffffffffffffffff,%rbx
   30dfa:	sete   %cl
   30dfd:	or     %al,%cl
   30dff:	mov    %rbx,%rax
   30e02:	and    %r15,%rax
   30e05:	cmp    $0x3108280,%rax
   30e0b:	setb   %al
   30e0e:	or     %cl,%al
   30e10:	jne    30e20 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5e60>
   30e12:	mov    %r12,%rdi
   30e15:	mov    %r13,%rsi
   30e18:	mov    %rbx,%rdx
   30e1b:	callq  c660 <term_drop>
   30e20:	mov    0x18(%rsp),%rdx
   30e25:	test   %rbp,%rdx
   30e28:	sete   %al
   30e2b:	cmp    $0xffffffffffffffff,%rdx
   30e2f:	sete   %cl
   30e32:	or     %al,%cl
   30e34:	mov    %rdx,%rax
   30e37:	and    %r15,%rax
   30e3a:	cmp    $0x3108280,%rax
   30e40:	setb   %al
   30e43:	or     %cl,%al
   30e45:	jne    30e57 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5e97>
   30e47:	mov    %r12,%rdi
   30e4a:	mov    %r13,%rsi
   30e4d:	mov    0x18(%rsp),%rdx
   30e52:	callq  c660 <term_drop>
   30e57:	mov    0x8(%rsp),%rdx
   30e5c:	test   %rbp,%rdx
   30e5f:	sete   %al
   30e62:	cmp    $0xffffffffffffffff,%rdx
   30e66:	sete   %cl
   30e69:	or     %al,%cl
   30e6b:	and    %rdx,%r15
   30e6e:	cmp    $0x3108280,%r15
   30e75:	setb   %al
   30e78:	or     %cl,%al
   30e7a:	jne    30e8c <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5ecc>
   30e7c:	mov    %r12,%rdi
   30e7f:	mov    %r13,%rsi
   30e82:	mov    0x8(%rsp),%rdx
   30e87:	callq  c660 <term_drop>
   30e8c:	cmpl   $0x0,0x30(%rsp)
   30e91:	jne    31b3a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6b7a>
   30e97:	mov    (%rsp),%rbp
   30e9b:	mov    -0x18(%rbp),%rcx
   30e9f:	lea    -0x10(%rbp),%rbx
   30ea3:	mov    -0x10(%rbp),%r8d
   30ea7:	mov    %r12,%rdi
   30eaa:	mov    %r13,%rsi
   30ead:	mov    $0x152,%edx
   30eb2:	mov    $0x1,%r9d
   30eb8:	callq  caf0 <task_node>
   30ebd:	mov    0x28(%rsp),%rcx
   30ec2:	mov    %rcx,(%r12,%rax,8)
   30ec6:	movabs $0x501520000000000,%rcx
   30ed0:	or     %rax,%rcx
   30ed3:	mov    %rcx,-0x18(%rbp)
   30ed7:	movq   $0x1,-0x10(%rbp)
   30edf:	mov    %r12,%rdi
   30ee2:	mov    %r13,%rsi
   30ee5:	mov    $0x153,%edx
   30eea:	mov    $0x1,%r8d
   30ef0:	mov    $0x1,%r9d
   30ef6:	callq  caf0 <task_node>
   30efb:	mov    %r14,(%r12,%rax,8)
   30eff:	movabs $0x501530000000000,%rcx
   30f09:	or     %rax,%rcx
   30f0c:	mov    %rcx,-0x18(%rbp)
   30f10:	mov    $0x1,%eax
   30f15:	mov    %rax,(%rbx)
   30f18:	lea    -0x2bc8f(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   30f1f:	callq  452c0 <err_fail>
   30f24:	mov    %rdx,%rbx
   30f27:	movabs $0x7e00000000000000,%rax
   30f31:	test   %rax,%r11
   30f34:	sete   %al
   30f37:	cmp    $0xffffffffffffffff,%r11
   30f3b:	sete   %cl
   30f3e:	or     %al,%cl
   30f40:	and    %r11,%r10
   30f43:	cmp    $0x3108280,%r10
   30f4a:	setb   %al
   30f4d:	or     %cl,%al
   30f4f:	jne    30f5f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5f9f>
   30f51:	mov    %r11,%rdx
   30f54:	mov    %r12,%rdi
   30f57:	mov    %r13,%rsi
   30f5a:	callq  c660 <term_drop>
   30f5f:	test   %r15d,%r15d
   30f62:	jne    31b6a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6baa>
   30f68:	mov    (%rsp),%rbp
   30f6c:	mov    -0x18(%rbp),%rcx
   30f70:	lea    -0x10(%rbp),%r15
   30f74:	mov    -0x10(%rbp),%r8d
   30f78:	mov    %r12,%rdi
   30f7b:	mov    %r13,%rsi
   30f7e:	mov    $0x138,%edx
   30f83:	mov    $0x1,%r9d
   30f89:	callq  caf0 <task_node>
   30f8e:	mov    %rbx,(%r12,%rax,8)
   30f92:	movabs $0x501380000000000,%rcx
   30f9c:	or     %rax,%rcx
   30f9f:	mov    %rcx,-0x18(%rbp)
   30fa3:	movq   $0x1,-0x10(%rbp)
   30fab:	mov    %r12,%rdi
   30fae:	mov    %r13,%rsi
   30fb1:	mov    $0x139,%edx
   30fb6:	mov    $0x1,%r8d
   30fbc:	mov    $0x1,%r9d
   30fc2:	callq  caf0 <task_node>
   30fc7:	mov    %r14,(%r12,%rax,8)
   30fcb:	movabs $0x501390000000000,%rcx
   30fd5:	or     %rax,%rcx
   30fd8:	mov    %rcx,-0x18(%rbp)
   30fdc:	mov    $0x1,%eax
   30fe1:	mov    %r15,%r14
   30fe4:	mov    %rax,(%r14)
   30fe7:	lea    -0x2bd5e(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   30fee:	callq  452c0 <err_fail>
   30ff3:	mov    %r9,0x18(%rsp)
   30ff8:	mov    %rbp,%r14
   30ffb:	mov    %rdx,0x28(%rsp)
   31000:	movabs $0x7e00000000000000,%r15
   3100a:	test   %r15,%r11
   3100d:	sete   %al
   31010:	cmp    $0xffffffffffffffff,%r11
   31014:	sete   %cl
   31017:	or     %al,%cl
   31019:	mov    %r11,%rdx
   3101c:	mov    %r10,%rbp
   3101f:	and    %r10,%r11
   31022:	cmp    $0x3108280,%r11
   31029:	setb   %al
   3102c:	or     %cl,%al
   3102e:	jne    3103b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x607b>
   31030:	mov    %r12,%rdi
   31033:	mov    %r13,%rsi
   31036:	callq  c660 <term_drop>
   3103b:	test   %r15,%r14
   3103e:	sete   %al
   31041:	cmp    $0xffffffffffffffff,%r14
   31045:	sete   %cl
   31048:	or     %al,%cl
   3104a:	mov    %r14,%rax
   3104d:	and    %rbp,%rax
   31050:	cmp    $0x3108280,%rax
   31056:	setb   %al
   31059:	or     %cl,%al
   3105b:	jne    3106b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x60ab>
   3105d:	mov    %r12,%rdi
   31060:	mov    %r13,%rsi
   31063:	mov    %r14,%rdx
   31066:	callq  c660 <term_drop>
   3106b:	test   %r15,%rbx
   3106e:	sete   %al
   31071:	cmp    $0xffffffffffffffff,%rbx
   31075:	sete   %cl
   31078:	or     %al,%cl
   3107a:	mov    %rbx,%rax
   3107d:	and    %rbp,%rax
   31080:	cmp    $0x3108280,%rax
   31086:	setb   %al
   31089:	or     %cl,%al
   3108b:	jne    3109b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x60db>
   3108d:	mov    %r12,%rdi
   31090:	mov    %r13,%rsi
   31093:	mov    %rbx,%rdx
   31096:	callq  c660 <term_drop>
   3109b:	mov    0x18(%rsp),%rdx
   310a0:	test   %r15,%rdx
   310a3:	sete   %al
   310a6:	cmp    $0xffffffffffffffff,%rdx
   310aa:	sete   %cl
   310ad:	or     %al,%cl
   310af:	mov    %rdx,%rax
   310b2:	and    %rbp,%rax
   310b5:	cmp    $0x3108280,%rax
   310bb:	setb   %al
   310be:	or     %cl,%al
   310c0:	jne    310d2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6112>
   310c2:	mov    %r12,%rdi
   310c5:	mov    %r13,%rsi
   310c8:	mov    0x18(%rsp),%rdx
   310cd:	callq  c660 <term_drop>
   310d2:	mov    0x8(%rsp),%rdx
   310d7:	test   %r15,%rdx
   310da:	sete   %al
   310dd:	cmp    $0xffffffffffffffff,%rdx
   310e1:	sete   %cl
   310e4:	or     %al,%cl
   310e6:	and    %rdx,%rbp
   310e9:	cmp    $0x3108280,%rbp
   310f0:	setb   %al
   310f3:	or     %cl,%al
   310f5:	jne    31107 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6147>
   310f7:	mov    %r12,%rdi
   310fa:	mov    %r13,%rsi
   310fd:	mov    0x8(%rsp),%rdx
   31102:	callq  c660 <term_drop>
   31107:	cmpl   $0x0,0x30(%rsp)
   3110c:	jne    31b98 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6bd8>
   31112:	mov    (%rsp),%r15
   31116:	mov    -0x18(%r15),%rcx
   3111a:	lea    -0x10(%r15),%r14
   3111e:	mov    -0x10(%r15),%r8d
   31122:	mov    %r12,%rdi
   31125:	mov    %r13,%rsi
   31128:	mov    $0x13d,%edx
   3112d:	mov    $0x1,%r9d
   31133:	callq  caf0 <task_node>
   31138:	mov    0x28(%rsp),%rcx
   3113d:	mov    %rcx,(%r12,%rax,8)
   31141:	movabs $0x5013d0000000000,%rcx
   3114b:	jmpq   319b7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x69f7>
   31150:	mov    %rbp,%r14
   31153:	mov    %rdx,0x28(%rsp)
   31158:	movabs $0x7e00000000000000,%r15
   31162:	test   %r15,%r11
   31165:	sete   %al
   31168:	cmp    $0xffffffffffffffff,%r11
   3116c:	sete   %cl
   3116f:	or     %al,%cl
   31171:	mov    %r11,%rdx
   31174:	mov    %r10,%rbp
   31177:	and    %r10,%r11
   3117a:	cmp    $0x3108280,%r11
   31181:	setb   %al
   31184:	or     %cl,%al
   31186:	jne    31193 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x61d3>
   31188:	mov    %r12,%rdi
   3118b:	mov    %r13,%rsi
   3118e:	callq  c660 <term_drop>
   31193:	test   %r15,%r14
   31196:	sete   %al
   31199:	cmp    $0xffffffffffffffff,%r14
   3119d:	sete   %cl
   311a0:	or     %al,%cl
   311a2:	mov    %r14,%rax
   311a5:	and    %rbp,%rax
   311a8:	cmp    $0x3108280,%rax
   311ae:	setb   %al
   311b1:	or     %cl,%al
   311b3:	jne    311c3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6203>
   311b5:	mov    %r12,%rdi
   311b8:	mov    %r13,%rsi
   311bb:	mov    %r14,%rdx
   311be:	callq  c660 <term_drop>
   311c3:	test   %r15,%rbx
   311c6:	sete   %al
   311c9:	cmp    $0xffffffffffffffff,%rbx
   311cd:	sete   %cl
   311d0:	or     %al,%cl
   311d2:	mov    %rbx,%rax
   311d5:	and    %rbp,%rax
   311d8:	cmp    $0x3108280,%rax
   311de:	setb   %al
   311e1:	or     %cl,%al
   311e3:	jne    311f3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6233>
   311e5:	mov    %r12,%rdi
   311e8:	mov    %r13,%rsi
   311eb:	mov    %rbx,%rdx
   311ee:	callq  c660 <term_drop>
   311f3:	mov    0x10(%rsp),%rdx
   311f8:	test   %r15,%rdx
   311fb:	sete   %al
   311fe:	cmp    $0xffffffffffffffff,%rdx
   31202:	sete   %cl
   31205:	or     %al,%cl
   31207:	mov    %rdx,%rax
   3120a:	and    %rbp,%rax
   3120d:	cmp    $0x3108280,%rax
   31213:	setb   %al
   31216:	or     %cl,%al
   31218:	jne    3122a <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x626a>
   3121a:	mov    %r12,%rdi
   3121d:	mov    %r13,%rsi
   31220:	mov    0x10(%rsp),%rdx
   31225:	callq  c660 <term_drop>
   3122a:	mov    0x18(%rsp),%rdx
   3122f:	test   %r15,%rdx
   31232:	sete   %al
   31235:	cmp    $0xffffffffffffffff,%rdx
   31239:	sete   %cl
   3123c:	or     %al,%cl
   3123e:	mov    %rdx,%rax
   31241:	and    %rbp,%rax
   31244:	cmp    $0x3108280,%rax
   3124a:	setb   %al
   3124d:	or     %cl,%al
   3124f:	jne    31261 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x62a1>
   31251:	mov    %r12,%rdi
   31254:	mov    %r13,%rsi
   31257:	mov    0x18(%rsp),%rdx
   3125c:	callq  c660 <term_drop>
   31261:	mov    0x8(%rsp),%rdx
   31266:	test   %r15,%rdx
   31269:	sete   %al
   3126c:	cmp    $0xffffffffffffffff,%rdx
   31270:	sete   %cl
   31273:	or     %al,%cl
   31275:	and    %rdx,%rbp
   31278:	cmp    $0x3108280,%rbp
   3127f:	setb   %al
   31282:	or     %cl,%al
   31284:	jne    31296 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x62d6>
   31286:	mov    %r12,%rdi
   31289:	mov    %r13,%rsi
   3128c:	mov    0x8(%rsp),%rdx
   31291:	callq  c660 <term_drop>
   31296:	cmpl   $0x0,0x30(%rsp)
   3129b:	jne    31bbc <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6bfc>
   312a1:	mov    (%rsp),%r15
   312a5:	mov    -0x18(%r15),%rcx
   312a9:	lea    -0x10(%r15),%rbx
   312ad:	mov    -0x10(%r15),%r8d
   312b1:	mov    %r12,%rdi
   312b4:	mov    %r13,%rsi
   312b7:	mov    $0x141,%edx
   312bc:	mov    $0x1,%r9d
   312c2:	callq  caf0 <task_node>
   312c7:	mov    0x28(%rsp),%rcx
   312cc:	mov    %rcx,(%r12,%rax,8)
   312d0:	movabs $0x501410000000000,%rcx
   312da:	jmpq   30af9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b39>
   312df:	mov    %r9,%r14
   312e2:	mov    %rdx,0x28(%rsp)
   312e7:	movabs $0x7e00000000000000,%r15
   312f1:	test   %r15,%r11
   312f4:	sete   %al
   312f7:	cmp    $0xffffffffffffffff,%r11
   312fb:	sete   %cl
   312fe:	or     %al,%cl
   31300:	mov    %r11,%rdx
   31303:	mov    %r10,%rbp
   31306:	and    %r10,%r11
   31309:	cmp    $0x3108280,%r11
   31310:	setb   %al
   31313:	or     %cl,%al
   31315:	jne    31322 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6362>
   31317:	mov    %r12,%rdi
   3131a:	mov    %r13,%rsi
   3131d:	callq  c660 <term_drop>
   31322:	test   %r15,%rbx
   31325:	sete   %al
   31328:	cmp    $0xffffffffffffffff,%rbx
   3132c:	sete   %cl
   3132f:	or     %al,%cl
   31331:	mov    %rbx,%rax
   31334:	and    %rbp,%rax
   31337:	cmp    $0x3108280,%rax
   3133d:	setb   %al
   31340:	or     %cl,%al
   31342:	jne    31352 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6392>
   31344:	mov    %r12,%rdi
   31347:	mov    %r13,%rsi
   3134a:	mov    %rbx,%rdx
   3134d:	callq  c660 <term_drop>
   31352:	mov    0x18(%rsp),%rdx
   31357:	test   %r15,%rdx
   3135a:	sete   %al
   3135d:	cmp    $0xffffffffffffffff,%rdx
   31361:	sete   %cl
   31364:	or     %al,%cl
   31366:	mov    %rdx,%rax
   31369:	and    %rbp,%rax
   3136c:	cmp    $0x3108280,%rax
   31372:	setb   %al
   31375:	or     %cl,%al
   31377:	jne    31389 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x63c9>
   31379:	mov    %r12,%rdi
   3137c:	mov    %r13,%rsi
   3137f:	mov    0x18(%rsp),%rdx
   31384:	callq  c660 <term_drop>
   31389:	mov    0x8(%rsp),%rdx
   3138e:	test   %r15,%rdx
   31391:	sete   %al
   31394:	cmp    $0xffffffffffffffff,%rdx
   31398:	sete   %cl
   3139b:	or     %al,%cl
   3139d:	mov    %rdx,%rax
   313a0:	and    %rbp,%rax
   313a3:	cmp    $0x3108280,%rax
   313a9:	setb   %al
   313ac:	or     %cl,%al
   313ae:	jne    313c0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6400>
   313b0:	mov    %r12,%rdi
   313b3:	mov    %r13,%rsi
   313b6:	mov    0x8(%rsp),%rdx
   313bb:	callq  c660 <term_drop>
   313c0:	test   %r15,%r14
   313c3:	sete   %al
   313c6:	cmp    $0xffffffffffffffff,%r14
   313ca:	sete   %cl
   313cd:	or     %al,%cl
   313cf:	mov    %r14,%rax
   313d2:	and    %rbp,%rax
   313d5:	cmp    $0x3108280,%rax
   313db:	setb   %al
   313de:	or     %cl,%al
   313e0:	jne    313f0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6430>
   313e2:	mov    %r12,%rdi
   313e5:	mov    %r13,%rsi
   313e8:	mov    %r14,%rdx
   313eb:	callq  c660 <term_drop>
   313f0:	mov    0x10(%rsp),%rdx
   313f5:	test   %r15,%rdx
   313f8:	sete   %al
   313fb:	cmp    $0xffffffffffffffff,%rdx
   313ff:	sete   %cl
   31402:	or     %al,%cl
   31404:	and    %rdx,%rbp
   31407:	cmp    $0x3108280,%rbp
   3140e:	setb   %al
   31411:	or     %cl,%al
   31413:	jne    31425 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6465>
   31415:	mov    %r12,%rdi
   31418:	mov    %r13,%rsi
   3141b:	mov    0x10(%rsp),%rdx
   31420:	callq  c660 <term_drop>
   31425:	cmpl   $0x0,0x30(%rsp)
   3142a:	jne    31be0 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6c20>
   31430:	mov    (%rsp),%r15
   31434:	mov    -0x18(%r15),%rcx
   31438:	lea    -0x10(%r15),%rbx
   3143c:	mov    -0x10(%r15),%r8d
   31440:	mov    %r12,%rdi
   31443:	mov    %r13,%rsi
   31446:	mov    $0x14b,%edx
   3144b:	mov    $0x1,%r9d
   31451:	callq  caf0 <task_node>
   31456:	mov    0x28(%rsp),%rcx
   3145b:	mov    %rcx,(%r12,%rax,8)
   3145f:	movabs $0x5014b0000000000,%rcx
   31469:	jmpq   30af9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b39>
   3146e:	mov    %rdx,%rbx
   31471:	movabs $0x7e00000000000000,%rax
   3147b:	test   %rax,%r11
   3147e:	sete   %al
   31481:	cmp    $0xffffffffffffffff,%r11
   31485:	sete   %cl
   31488:	or     %al,%cl
   3148a:	and    %r11,%r10
   3148d:	cmp    $0x3108280,%r10
   31494:	setb   %al
   31497:	or     %cl,%al
   31499:	jne    314a9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x64e9>
   3149b:	mov    %r11,%rdx
   3149e:	mov    %r12,%rdi
   314a1:	mov    %r13,%rsi
   314a4:	callq  c660 <term_drop>
   314a9:	test   %r15d,%r15d
   314ac:	jne    31c04 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6c44>
   314b2:	mov    (%rsp),%r15
   314b6:	mov    -0x18(%r15),%rcx
   314ba:	lea    -0x10(%r15),%r14
   314be:	mov    -0x10(%r15),%r8d
   314c2:	mov    %r12,%rdi
   314c5:	mov    %r13,%rsi
   314c8:	mov    $0x131,%edx
   314cd:	mov    $0x1,%r9d
   314d3:	callq  caf0 <task_node>
   314d8:	mov    %rbx,(%r12,%rax,8)
   314dc:	movabs $0x501310000000000,%rcx
   314e6:	jmpq   319b7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x69f7>
   314eb:	mov    %rbp,%r14
   314ee:	mov    %rbx,0x8(%rsp)
   314f3:	mov    %rdx,0x28(%rsp)
   314f8:	movabs $0x7e00000000000000,%rbx
   31502:	test   %rbx,%r11
   31505:	sete   %al
   31508:	cmp    $0xffffffffffffffff,%r11
   3150c:	sete   %cl
   3150f:	or     %al,%cl
   31511:	mov    %r11,%rdx
   31514:	mov    %r10,%rbp
   31517:	and    %r10,%r11
   3151a:	cmp    $0x3108280,%r11
   31521:	setb   %al
   31524:	or     %cl,%al
   31526:	jne    31533 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6573>
   31528:	mov    %r12,%rdi
   3152b:	mov    %r13,%rsi
   3152e:	callq  c660 <term_drop>
   31533:	test   %rbx,%r14
   31536:	sete   %al
   31539:	cmp    $0xffffffffffffffff,%r14
   3153d:	sete   %cl
   31540:	or     %al,%cl
   31542:	mov    %r14,%rax
   31545:	and    %rbp,%rax
   31548:	cmp    $0x3108280,%rax
   3154e:	setb   %al
   31551:	or     %cl,%al
   31553:	jne    31563 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x65a3>
   31555:	mov    %r12,%rdi
   31558:	mov    %r13,%rsi
   3155b:	mov    %r14,%rdx
   3155e:	callq  c660 <term_drop>
   31563:	mov    0x8(%rsp),%rdx
   31568:	test   %rbx,%rdx
   3156b:	sete   %al
   3156e:	cmp    $0xffffffffffffffff,%rdx
   31572:	sete   %cl
   31575:	or     %al,%cl
   31577:	and    %rdx,%rbp
   3157a:	cmp    $0x3108280,%rbp
   31581:	setb   %al
   31584:	or     %cl,%al
   31586:	jne    31598 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x65d8>
   31588:	mov    %r12,%rdi
   3158b:	mov    %r13,%rsi
   3158e:	mov    0x8(%rsp),%rdx
   31593:	callq  c660 <term_drop>
   31598:	test   %r15d,%r15d
   3159b:	jne    31c23 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6c63>
   315a1:	mov    (%rsp),%r15
   315a5:	mov    -0x18(%r15),%rcx
   315a9:	lea    -0x10(%r15),%r14
   315ad:	mov    -0x10(%r15),%r8d
   315b1:	mov    %r12,%rdi
   315b4:	mov    %r13,%rsi
   315b7:	mov    $0x13b,%edx
   315bc:	mov    $0x1,%r9d
   315c2:	callq  caf0 <task_node>
   315c7:	mov    0x28(%rsp),%rcx
   315cc:	mov    %rcx,(%r12,%rax,8)
   315d0:	movabs $0x5013b0000000000,%rcx
   315da:	jmpq   319b7 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x69f7>
   315df:	mov    %r15d,%r14d
   315e2:	mov    %rdx,0x28(%rsp)
   315e7:	movabs $0x7e00000000000000,%r15
   315f1:	test   %r15,%r11
   315f4:	sete   %al
   315f7:	cmp    $0xffffffffffffffff,%r11
   315fb:	sete   %cl
   315fe:	or     %al,%cl
   31600:	mov    %r11,%rdx
   31603:	mov    %r10,%rbp
   31606:	and    %r10,%r11
   31609:	cmp    $0x3108280,%r11
   31610:	setb   %al
   31613:	or     %cl,%al
   31615:	jne    31622 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6662>
   31617:	mov    %r12,%rdi
   3161a:	mov    %r13,%rsi
   3161d:	callq  c660 <term_drop>
   31622:	test   %r15,%rbx
   31625:	sete   %al
   31628:	cmp    $0xffffffffffffffff,%rbx
   3162c:	sete   %cl
   3162f:	or     %al,%cl
   31631:	mov    %rbx,%rax
   31634:	and    %rbp,%rax
   31637:	cmp    $0x3108280,%rax
   3163d:	setb   %al
   31640:	or     %cl,%al
   31642:	jne    31652 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6692>
   31644:	mov    %r12,%rdi
   31647:	mov    %r13,%rsi
   3164a:	mov    %rbx,%rdx
   3164d:	callq  c660 <term_drop>
   31652:	mov    0x18(%rsp),%rdx
   31657:	test   %r15,%rdx
   3165a:	sete   %al
   3165d:	cmp    $0xffffffffffffffff,%rdx
   31661:	sete   %cl
   31664:	or     %al,%cl
   31666:	mov    %rdx,%rax
   31669:	and    %rbp,%rax
   3166c:	cmp    $0x3108280,%rax
   31672:	setb   %al
   31675:	or     %cl,%al
   31677:	jne    31689 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x66c9>
   31679:	mov    %r12,%rdi
   3167c:	mov    %r13,%rsi
   3167f:	mov    0x18(%rsp),%rdx
   31684:	callq  c660 <term_drop>
   31689:	mov    0x8(%rsp),%rdx
   3168e:	test   %r15,%rdx
   31691:	sete   %al
   31694:	cmp    $0xffffffffffffffff,%rdx
   31698:	sete   %cl
   3169b:	or     %al,%cl
   3169d:	and    %rdx,%rbp
   316a0:	cmp    $0x3108280,%rbp
   316a7:	setb   %al
   316aa:	or     %cl,%al
   316ac:	jne    316be <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x66fe>
   316ae:	mov    %r12,%rdi
   316b1:	mov    %r13,%rsi
   316b4:	mov    0x8(%rsp),%rdx
   316b9:	callq  c660 <term_drop>
   316be:	test   %r14d,%r14d
   316c1:	jne    31c47 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6c87>
   316c7:	mov    (%rsp),%r15
   316cb:	mov    -0x18(%r15),%rcx
   316cf:	lea    -0x10(%r15),%rbx
   316d3:	mov    -0x10(%r15),%r8d
   316d7:	mov    %r12,%rdi
   316da:	mov    %r13,%rsi
   316dd:	mov    $0x147,%edx
   316e2:	mov    $0x1,%r9d
   316e8:	callq  caf0 <task_node>
   316ed:	mov    0x28(%rsp),%rcx
   316f2:	mov    %rcx,(%r12,%rax,8)
   316f6:	movabs $0x501470000000000,%rcx
   31700:	jmpq   30af9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b39>
   31705:	mov    %r9,%r14
   31708:	mov    %rdi,0x40(%rsp)
   3170d:	mov    %rdx,0x28(%rsp)
   31712:	movabs $0x7e00000000000000,%r15
   3171c:	test   %r15,%r11
   3171f:	sete   %al
   31722:	cmp    $0xffffffffffffffff,%r11
   31726:	sete   %cl
   31729:	or     %al,%cl
   3172b:	mov    %r11,%rdx
   3172e:	mov    %r10,%rbp
   31731:	and    %r10,%r11
   31734:	cmp    $0x3108280,%r11
   3173b:	setb   %al
   3173e:	or     %cl,%al
   31740:	jne    3174d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x678d>
   31742:	mov    %r12,%rdi
   31745:	mov    %r13,%rsi
   31748:	callq  c660 <term_drop>
   3174d:	test   %r15,%rbx
   31750:	sete   %al
   31753:	cmp    $0xffffffffffffffff,%rbx
   31757:	sete   %cl
   3175a:	or     %al,%cl
   3175c:	mov    %rbx,%rax
   3175f:	and    %rbp,%rax
   31762:	cmp    $0x3108280,%rax
   31768:	setb   %al
   3176b:	or     %cl,%al
   3176d:	jne    3177d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x67bd>
   3176f:	mov    %r12,%rdi
   31772:	mov    %r13,%rsi
   31775:	mov    %rbx,%rdx
   31778:	callq  c660 <term_drop>
   3177d:	mov    0x18(%rsp),%rdx
   31782:	test   %r15,%rdx
   31785:	sete   %al
   31788:	cmp    $0xffffffffffffffff,%rdx
   3178c:	sete   %cl
   3178f:	or     %al,%cl
   31791:	mov    %rdx,%rax
   31794:	and    %rbp,%rax
   31797:	cmp    $0x3108280,%rax
   3179d:	setb   %al
   317a0:	or     %cl,%al
   317a2:	jne    317b4 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x67f4>
   317a4:	mov    %r12,%rdi
   317a7:	mov    %r13,%rsi
   317aa:	mov    0x18(%rsp),%rdx
   317af:	callq  c660 <term_drop>
   317b4:	mov    0x8(%rsp),%rdx
   317b9:	test   %r15,%rdx
   317bc:	sete   %al
   317bf:	cmp    $0xffffffffffffffff,%rdx
   317c3:	sete   %cl
   317c6:	or     %al,%cl
   317c8:	mov    %rdx,%rax
   317cb:	and    %rbp,%rax
   317ce:	cmp    $0x3108280,%rax
   317d4:	setb   %al
   317d7:	or     %cl,%al
   317d9:	jne    317eb <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x682b>
   317db:	mov    %r12,%rdi
   317de:	mov    %r13,%rsi
   317e1:	mov    0x8(%rsp),%rdx
   317e6:	callq  c660 <term_drop>
   317eb:	mov    0x10(%rsp),%rdx
   317f0:	test   %r15,%rdx
   317f3:	sete   %al
   317f6:	cmp    $0xffffffffffffffff,%rdx
   317fa:	sete   %cl
   317fd:	or     %al,%cl
   317ff:	mov    %rdx,%rax
   31802:	and    %rbp,%rax
   31805:	cmp    $0x3108280,%rax
   3180b:	setb   %al
   3180e:	or     %cl,%al
   31810:	jne    31822 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6862>
   31812:	mov    %r12,%rdi
   31815:	mov    %r13,%rsi
   31818:	mov    0x10(%rsp),%rdx
   3181d:	callq  c660 <term_drop>
   31822:	test   %r15,%r14
   31825:	sete   %al
   31828:	cmp    $0xffffffffffffffff,%r14
   3182c:	sete   %cl
   3182f:	or     %al,%cl
   31831:	mov    %r14,%rax
   31834:	and    %rbp,%rax
   31837:	cmp    $0x3108280,%rax
   3183d:	setb   %al
   31840:	or     %cl,%al
   31842:	jne    31852 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6892>
   31844:	mov    %r12,%rdi
   31847:	mov    %r13,%rsi
   3184a:	mov    %r14,%rdx
   3184d:	callq  c660 <term_drop>
   31852:	mov    0x40(%rsp),%rdx
   31857:	test   %r15,%rdx
   3185a:	sete   %al
   3185d:	cmp    $0xffffffffffffffff,%rdx
   31861:	sete   %cl
   31864:	or     %al,%cl
   31866:	and    %rdx,%rbp
   31869:	cmp    $0x3108280,%rbp
   31870:	setb   %al
   31873:	or     %cl,%al
   31875:	jne    31887 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x68c7>
   31877:	mov    %r12,%rdi
   3187a:	mov    %r13,%rsi
   3187d:	mov    0x40(%rsp),%rdx
   31882:	callq  c660 <term_drop>
   31887:	cmpl   $0x0,0x30(%rsp)
   3188c:	jne    31c6b <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6cab>
   31892:	mov    (%rsp),%r15
   31896:	mov    -0x18(%r15),%rcx
   3189a:	lea    -0x10(%r15),%rbx
   3189e:	mov    -0x10(%r15),%r8d
   318a2:	mov    %r12,%rdi
   318a5:	mov    %r13,%rsi
   318a8:	mov    $0x151,%edx
   318ad:	mov    $0x1,%r9d
   318b3:	callq  caf0 <task_node>
   318b8:	mov    0x28(%rsp),%rcx
   318bd:	mov    %rcx,(%r12,%rax,8)
   318c1:	movabs $0x501510000000000,%rcx
   318cb:	jmpq   30af9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b39>
   318d0:	mov    %rdx,0x28(%rsp)
   318d5:	movabs $0x7e00000000000000,%r14
   318df:	test   %r14,%r11
   318e2:	sete   %al
   318e5:	cmp    $0xffffffffffffffff,%r11
   318e9:	sete   %cl
   318ec:	or     %al,%cl
   318ee:	mov    %r11,%rdx
   318f1:	mov    %r10,%rbx
   318f4:	and    %r10,%r11
   318f7:	cmp    $0x3108280,%r11
   318fe:	setb   %al
   31901:	or     %cl,%al
   31903:	jne    31910 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6950>
   31905:	mov    %r12,%rdi
   31908:	mov    %r13,%rsi
   3190b:	callq  c660 <term_drop>
   31910:	test   %r14,%rbp
   31913:	sete   %al
   31916:	cmp    $0xffffffffffffffff,%rbp
   3191a:	sete   %cl
   3191d:	or     %al,%cl
   3191f:	mov    %rbp,%rax
   31922:	and    %rbx,%rax
   31925:	cmp    $0x3108280,%rax
   3192b:	setb   %al
   3192e:	or     %cl,%al
   31930:	jne    31940 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6980>
   31932:	mov    %r12,%rdi
   31935:	mov    %r13,%rsi
   31938:	mov    %rbp,%rdx
   3193b:	callq  c660 <term_drop>
   31940:	mov    0x8(%rsp),%rdx
   31945:	test   %r14,%rdx
   31948:	sete   %al
   3194b:	cmp    $0xffffffffffffffff,%rdx
   3194f:	sete   %cl
   31952:	or     %al,%cl
   31954:	and    %rdx,%rbx
   31957:	cmp    $0x3108280,%rbx
   3195e:	setb   %al
   31961:	or     %cl,%al
   31963:	jne    31975 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x69b5>
   31965:	mov    %r12,%rdi
   31968:	mov    %r13,%rsi
   3196b:	mov    0x8(%rsp),%rdx
   31970:	callq  c660 <term_drop>
   31975:	test   %r15d,%r15d
   31978:	jne    31c8f <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6ccf>
   3197e:	mov    (%rsp),%r15
   31982:	mov    -0x18(%r15),%rcx
   31986:	lea    -0x10(%r15),%r14
   3198a:	mov    -0x10(%r15),%r8d
   3198e:	mov    %r12,%rdi
   31991:	mov    %r13,%rsi
   31994:	mov    $0x133,%edx
   31999:	mov    $0x1,%r9d
   3199f:	callq  caf0 <task_node>
   319a4:	mov    0x28(%rsp),%rcx
   319a9:	mov    %rcx,(%r12,%rax,8)
   319ad:	movabs $0x501330000000000,%rcx
   319b7:	or     %rax,%rcx
   319ba:	mov    %rcx,-0x18(%r15)
   319be:	mov    $0x1,%eax
   319c3:	mov    %rax,(%r14)
   319c6:	lea    -0x2c73d(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   319cd:	callq  452c0 <err_fail>
   319d2:	mov    %rdi,%rbp
   319d5:	mov    %rbx,%r14
   319d8:	mov    %r15d,0x30(%rsp)
   319dd:	mov    %rdx,0x28(%rsp)
   319e2:	movabs $0x7e00000000000000,%r15
   319ec:	test   %r15,%r11
   319ef:	sete   %al
   319f2:	cmp    $0xffffffffffffffff,%r11
   319f6:	sete   %cl
   319f9:	or     %al,%cl
   319fb:	mov    %r11,%rdx
   319fe:	mov    %r10,%rbx
   31a01:	and    %r10,%r11
   31a04:	cmp    $0x3108280,%r11
   31a0b:	setb   %al
   31a0e:	or     %cl,%al
   31a10:	jne    31a1d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6a5d>
   31a12:	mov    %r12,%rdi
   31a15:	mov    %r13,%rsi
   31a18:	callq  c660 <term_drop>
   31a1d:	test   %r15,%r14
   31a20:	sete   %al
   31a23:	cmp    $0xffffffffffffffff,%r14
   31a27:	sete   %cl
   31a2a:	or     %al,%cl
   31a2c:	mov    %r14,%rax
   31a2f:	and    %rbx,%rax
   31a32:	cmp    $0x3108280,%rax
   31a38:	setb   %al
   31a3b:	or     %cl,%al
   31a3d:	jne    31a4d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6a8d>
   31a3f:	mov    %r12,%rdi
   31a42:	mov    %r13,%rsi
   31a45:	mov    %r14,%rdx
   31a48:	callq  c660 <term_drop>
   31a4d:	test   %r15,%rbp
   31a50:	sete   %al
   31a53:	cmp    $0xffffffffffffffff,%rbp
   31a57:	sete   %cl
   31a5a:	or     %al,%cl
   31a5c:	mov    %rbp,%rax
   31a5f:	and    %rbx,%rax
   31a62:	cmp    $0x3108280,%rax
   31a68:	setb   %al
   31a6b:	or     %cl,%al
   31a6d:	jne    31a7d <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6abd>
   31a6f:	mov    %r12,%rdi
   31a72:	mov    %r13,%rsi
   31a75:	mov    %rbp,%rdx
   31a78:	callq  c660 <term_drop>
   31a7d:	mov    0x8(%rsp),%rdx
   31a82:	test   %r15,%rdx
   31a85:	sete   %al
   31a88:	cmp    $0xffffffffffffffff,%rdx
   31a8c:	sete   %cl
   31a8f:	or     %al,%cl
   31a91:	and    %rdx,%rbx
   31a94:	cmp    $0x3108280,%rbx
   31a9b:	setb   %al
   31a9e:	or     %cl,%al
   31aa0:	jne    31ab2 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6af2>
   31aa2:	mov    %r12,%rdi
   31aa5:	mov    %r13,%rsi
   31aa8:	mov    0x8(%rsp),%rdx
   31aad:	callq  c660 <term_drop>
   31ab2:	cmpl   $0x0,0x30(%rsp)
   31ab7:	jne    31cb3 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6cf3>
   31abd:	mov    (%rsp),%r15
   31ac1:	mov    -0x18(%r15),%rcx
   31ac5:	lea    -0x10(%r15),%rbx
   31ac9:	mov    -0x10(%r15),%r8d
   31acd:	mov    %r12,%rdi
   31ad0:	mov    %r13,%rsi
   31ad3:	mov    $0x137,%edx
   31ad8:	mov    $0x1,%r9d
   31ade:	callq  caf0 <task_node>
   31ae3:	mov    0x28(%rsp),%rcx
   31ae8:	mov    %rcx,(%r12,%rax,8)
   31aec:	movabs $0x501370000000000,%rcx
   31af6:	jmpq   30af9 <WL_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5b39>
   31afb:	lea    -0x2c2a9(%rip),%rdi        # 5859 <FID_RESW_T+0xa29>
   31b02:	callq  452c0 <err_fail>
   31b07:	mov    (%rsp),%rax
   31b0b:	mov    0x28(%rsp),%rcx
   31b10:	mov    %rcx,(%rax)
   31b13:	movq   $0x142,0x8(%rax)
   31b1b:	mov    %r14,0x10(%rax)
   31b1f:	add    $0x18,%rax
   31b23:	mov    %rax,%r14
   31b26:	mov    $0x143,%eax
   31b2b:	mov    %rax,(%r14)
   31b2e:	lea    -0x2c8a5(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31b35:	callq  452c0 <err_fail>
   31b3a:	mov    (%rsp),%rbx
   31b3e:	mov    0x28(%rsp),%rax
   31b43:	mov    %rax,(%rbx)
   31b46:	movq   $0x152,0x8(%rbx)
   31b4e:	mov    %r14,0x10(%rbx)
   31b52:	add    $0x18,%rbx
   31b56:	mov    $0x153,%eax
   31b5b:	mov    %rax,(%rbx)
   31b5e:	lea    -0x2c8d5(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31b65:	callq  452c0 <err_fail>
   31b6a:	mov    (%rsp),%rax
   31b6e:	mov    %rbx,(%rax)
   31b71:	movq   $0x138,0x8(%rax)
   31b79:	mov    %r14,0x10(%rax)
   31b7d:	add    $0x18,%rax
   31b81:	mov    %rax,%r14
   31b84:	mov    $0x139,%eax
   31b89:	mov    %rax,(%r14)
   31b8c:	lea    -0x2c903(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31b93:	callq  452c0 <err_fail>
   31b98:	mov    (%rsp),%r14
   31b9c:	mov    0x28(%rsp),%rax
   31ba1:	mov    %rax,(%r14)
   31ba4:	add    $0x8,%r14
   31ba8:	mov    $0x13d,%eax
   31bad:	mov    %rax,(%r14)
   31bb0:	lea    -0x2c927(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31bb7:	callq  452c0 <err_fail>
   31bbc:	mov    (%rsp),%rbx
   31bc0:	mov    0x28(%rsp),%rax
   31bc5:	mov    %rax,(%rbx)
   31bc8:	add    $0x8,%rbx
   31bcc:	mov    $0x141,%eax
   31bd1:	mov    %rax,(%rbx)
   31bd4:	lea    -0x2c94b(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31bdb:	callq  452c0 <err_fail>
   31be0:	mov    (%rsp),%rbx
   31be4:	mov    0x28(%rsp),%rax
   31be9:	mov    %rax,(%rbx)
   31bec:	add    $0x8,%rbx
   31bf0:	mov    $0x14b,%eax
   31bf5:	mov    %rax,(%rbx)
   31bf8:	lea    -0x2c96f(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31bff:	callq  452c0 <err_fail>
   31c04:	mov    (%rsp),%r14
   31c08:	mov    %rbx,(%r14)
   31c0b:	add    $0x8,%r14
   31c0f:	mov    $0x131,%eax
   31c14:	mov    %rax,(%r14)
   31c17:	lea    -0x2c98e(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31c1e:	callq  452c0 <err_fail>
   31c23:	mov    (%rsp),%r14
   31c27:	mov    0x28(%rsp),%rax
   31c2c:	mov    %rax,(%r14)
   31c2f:	add    $0x8,%r14
   31c33:	mov    $0x13b,%eax
   31c38:	mov    %rax,(%r14)
   31c3b:	lea    -0x2c9b2(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31c42:	callq  452c0 <err_fail>
   31c47:	mov    (%rsp),%rbx
   31c4b:	mov    0x28(%rsp),%rax
   31c50:	mov    %rax,(%rbx)
   31c53:	add    $0x8,%rbx
   31c57:	mov    $0x147,%eax
   31c5c:	mov    %rax,(%rbx)
   31c5f:	lea    -0x2c9d6(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31c66:	callq  452c0 <err_fail>
   31c6b:	mov    (%rsp),%rbx
   31c6f:	mov    0x28(%rsp),%rax
   31c74:	mov    %rax,(%rbx)
   31c77:	add    $0x8,%rbx
   31c7b:	mov    $0x151,%eax
   31c80:	mov    %rax,(%rbx)
   31c83:	lea    -0x2c9fa(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31c8a:	callq  452c0 <err_fail>
   31c8f:	mov    (%rsp),%r14
   31c93:	mov    0x28(%rsp),%rax
   31c98:	mov    %rax,(%r14)
   31c9b:	add    $0x8,%r14
   31c9f:	mov    $0x133,%eax
   31ca4:	mov    %rax,(%r14)
   31ca7:	lea    -0x2ca1e(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31cae:	callq  452c0 <err_fail>
   31cb3:	mov    (%rsp),%rbx
   31cb7:	mov    0x28(%rsp),%rax
   31cbc:	mov    %rax,(%rbx)
   31cbf:	add    $0x8,%rbx
   31cc3:	mov    $0x137,%eax
   31cc8:	mov    %rax,(%rbx)
   31ccb:	lea    -0x2ca42(%rip),%rdi        # 5290 <FID_RESW_T+0x460>
   31cd2:	callq  452c0 <err_fail>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
