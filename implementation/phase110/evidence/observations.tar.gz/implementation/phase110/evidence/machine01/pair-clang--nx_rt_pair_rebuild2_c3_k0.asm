
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403850 <nx_rt_pair_rebuild2_c3_k0>:
  403850:	push   %r14
  403852:	mov    %rsi,%r10
  403855:	mov    %rdx,%r8
  403858:	movabs $0xffffffffff,%r9
  403862:	push   %r13
  403864:	and    %r10,%r9
  403867:	push   %r12
  403869:	lea    0x0(,%r9,8),%rax
  403871:	push   %rbp
  403872:	sub    $0x18,%rsp
  403876:	mov    (%rdi),%rbp
  403879:	mov    0x8(%rdi),%rsi
  40387d:	lea    0x0(%rbp,%rax,1),%rdx
  403882:	test   %r10,%r10
  403885:	js     4038e0 <nx_rt_pair_rebuild2_c3_k0+0x90>
  403887:	mov    (%rdx),%r13
  40388a:	mov    0x8(%rbp,%rax,1),%r12
  40388f:	cmp    $0x310817f,%r9
  403896:	jbe    4038c0 <nx_rt_pair_rebuild2_c3_k0+0x70>
  403898:	mov    %r13,%rcx
  40389b:	mov    $0x3,%edx
  4038a0:	mov    %rbp,%rdi
  4038a3:	callq  401f70 <nx_construct2>
  4038a8:	add    $0x18,%rsp
  4038ac:	mov    %r12,%rdx
  4038af:	pop    %rbp
  4038b0:	pop    %r12
  4038b2:	pop    %r13
  4038b4:	pop    %r14
  4038b6:	retq   
  4038b7:	nopw   0x0(%rax,%rax,1)
  4038c0:	mov    0x8(%rsi),%r9
  4038c4:	test   %r9,%r9
  4038c7:	je     401907 <nx_rt_pair_rebuild2_c3_k0.cold>
  4038cd:	mov    0x0(%rbp,%r9,8),%rax
  4038d2:	subq   $0x2,0x108(%rsi)
  4038da:	mov    %rax,0x8(%rsi)
  4038de:	jmp    403898 <nx_rt_pair_rebuild2_c3_k0+0x48>
  4038e0:	mov    0x4(%rdx),%eax
  4038e3:	mov    (%rdx),%ecx
  4038e5:	shl    $0x20,%rax
  4038e9:	or     %rcx,%rax
  4038ec:	mov    %rax,%r14
  4038ef:	and    $0xffffff,%eax
  4038f4:	shr    $0x18,%r14
  4038f8:	lea    0x0(,%r14,8),%rcx
  403900:	lea    0x8(%rbp,%rcx,1),%rdi
  403905:	add    %rbp,%rcx
  403908:	cmp    $0x1,%rax
  40390c:	jne    401945 <nx_rt_pair_rebuild2_c3_k0.cold+0x3e>
  403912:	mov    (%rdx),%eax
  403914:	mov    (%rsi),%rax
  403917:	mov    (%rcx),%r13
  40391a:	mov    (%rdi),%r12
  40391d:	mov    %rax,(%rdx)
  403920:	mov    0x100(%rsi),%rax
  403927:	mov    0x3d8ab(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40392d:	mov    %r9,(%rsi)
  403930:	add    $0x1,%rax
  403934:	mov    %rax,0x100(%rsi)
  40393b:	cmp    %rdx,%rax
  40393e:	jae    40192e <nx_rt_pair_rebuild2_c3_k0.cold+0x27>
  403944:	mov    %r14,%r9
  403947:	jmpq   40388f <nx_rt_pair_rebuild2_c3_k0+0x3f>

Disassembly of section .fini:
