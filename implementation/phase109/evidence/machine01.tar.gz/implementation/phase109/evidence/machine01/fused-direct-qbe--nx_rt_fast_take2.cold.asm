
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040160f <nx_rt_fast_take2.cold>:
  40160f:	mov    $0x1,%edx
  401614:	mov    %rbp,%rsi
  401617:	callq  401100 <heap_hand>
  40161c:	jmpq   4028c4 <nx_rt_fast_take2+0x44>
  401621:	xor    %edx,%edx
  401623:	mov    %rbp,%rsi
  401626:	callq  401100 <heap_hand>
  40162b:	jmpq   402989 <nx_rt_fast_take2+0x109>
  401630:	mov    (%r9),%rax
  401633:	mov    %rsi,%rdx
  401636:	mov    %r12,%rcx
  401639:	mov    %rbp,%rsi
  40163c:	mov    %rax,0x10(%rbx)
  401640:	mov    (%r8),%rax
  401643:	mov    %rax,0x18(%rbx)
  401647:	callq  4014c6 <span_fade.constprop.0>
  40164c:	jmpq   4028c4 <nx_rt_fast_take2+0x44>

Disassembly of section .fini:
