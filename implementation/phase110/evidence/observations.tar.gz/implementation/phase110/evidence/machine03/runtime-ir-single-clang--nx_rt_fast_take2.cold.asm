
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004015fe <nx_rt_fast_take2.cold>:
  4015fe:	mov    $0x1,%edx
  401603:	mov    %rbp,%rsi
  401606:	callq  401100 <heap_hand>
  40160b:	jmpq   403114 <nx_rt_fast_take2+0x44>
  401610:	xor    %edx,%edx
  401612:	mov    %rbp,%rsi
  401615:	callq  401100 <heap_hand>
  40161a:	jmpq   4031d9 <nx_rt_fast_take2+0x109>
  40161f:	mov    (%r9),%rax
  401622:	mov    %rsi,%rdx
  401625:	mov    %r12,%rcx
  401628:	mov    %rbp,%rsi
  40162b:	mov    %rax,0x10(%rbx)
  40162f:	mov    (%r8),%rax
  401632:	mov    %rax,0x18(%rbx)
  401636:	callq  401471 <span_fade.constprop.0>
  40163b:	jmpq   403114 <nx_rt_fast_take2+0x44>

Disassembly of section .fini:
