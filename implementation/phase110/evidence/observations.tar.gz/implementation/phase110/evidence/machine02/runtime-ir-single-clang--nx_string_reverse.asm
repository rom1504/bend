
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402080 <nx_string_reverse>:
  402080:	push   %rbp
  402081:	push   %r15
  402083:	push   %r14
  402085:	push   %r13
  402087:	push   %r12
  402089:	push   %rbx
  40208a:	sub    $0x18,%rsp
  40208e:	mov    %rdx,%r14
  402091:	mov    %rsi,%rbp
  402094:	mov    %rdi,%rbx
  402097:	callq  404600 <nx_rt_ir_heap>
  40209c:	mov    %rax,%r15
  40209f:	mov    %rbx,0x8(%rsp)
  4020a4:	mov    %rbx,%rdi
  4020a7:	callq  404670 <nx_rt_ir_alc>
  4020ac:	mov    %rax,%rsi
  4020af:	movabs $0xffffffffff,%r12
  4020b9:	mov    %rax,0x10(%rsp)
  4020be:	jmp    4020e8 <nx_string_reverse+0x68>
  4020c0:	mov    0x8(%rsp),%rbx
  4020c5:	mov    %rbx,%rdi
  4020c8:	mov    %rbp,%rsi
  4020cb:	mov    %r14,%rdx
  4020ce:	callq  403f60 <nx_rt_rebuild2_c3_k0>
  4020d3:	mov    %rax,%r14
  4020d6:	mov    %rbx,%rdi
  4020d9:	xor    %esi,%esi
  4020db:	callq  4032f0 <nx_rt_fast_field>
  4020e0:	mov    0x10(%rsp),%rsi
  4020e5:	mov    %rax,%rbp
  4020e8:	mov    %rbp,%rax
  4020eb:	shr    $0x28,%rax
  4020ef:	cmp    $0x3,%ax
  4020f3:	jne    4022d1 <nx_string_reverse+0x251>
  4020f9:	mov    %rbp,%r13
  4020fc:	and    %r12,%r13
  4020ff:	test   %rbp,%rbp
  402102:	js     402130 <nx_string_reverse+0xb0>
  402104:	cmp    $0x3108180,%r13
  40210b:	jb     4020c0 <nx_string_reverse+0x40>
  40210d:	lea    (%r15,%r13,8),%rbx
  402111:	mov    (%r15,%r13,8),%r12
  402115:	mov    0x8(%r15,%r13,8),%rbp
  40211a:	lea    (%r15,%r13,8),%rdi
  40211e:	add    $0x8,%rdi
  402122:	jmpq   4021ac <nx_string_reverse+0x12c>
  402127:	nopw   0x0(%rax,%rax,1)
  402130:	mov    (%r15,%r13,8),%rbx
  402134:	mov    %ebx,%eax
  402136:	and    $0xffffff,%eax
  40213b:	cmp    $0x1,%eax
  40213e:	jne    4020c0 <nx_string_reverse+0x40>
  402140:	mov    %rbx,%rax
  402143:	shr    $0x1f,%rax
  402147:	cmp    $0x62102,%rax
  40214d:	jbe    4020c0 <nx_string_reverse+0x40>
  402153:	shr    $0x18,%rbx
  402157:	lea    (%r15,%rbx,8),%rax
  40215b:	mov    %rax,(%rsp)
  40215f:	mov    (%r15,%rbx,8),%r12
  402163:	mov    0x8(%r15,%rbx,8),%rbp
  402168:	lea    0x8(%r15,%rbx,8),%rdi
  40216d:	mov    (%rsi),%rax
  402170:	mov    %rax,(%r15,%r13,8)
  402174:	mov    %r13,(%rsi)
  402177:	mov    0x100(%rsi),%rax
  40217e:	inc    %rax
  402181:	mov    %rax,0x100(%rsi)
  402188:	cmp    $0x8000,%rax
  40218e:	jb     4021a5 <nx_string_reverse+0x125>
  402190:	mov    %rdi,%r13
  402193:	mov    0x8(%rsp),%rdi
  402198:	callq  401c36 <nx_rt_ir_hand0>
  40219d:	mov    %r13,%rdi
  4021a0:	mov    0x10(%rsp),%rsi
  4021a5:	mov    %rbx,%r13
  4021a8:	mov    (%rsp),%rbx
  4021ac:	mov    %r12,%rax
  4021af:	movabs $0xff00000000000000,%rcx
  4021b9:	and    %rcx,%rax
  4021bc:	movabs $0x200000000000000,%rcx
  4021c6:	cmp    %rcx,%rax
  4021c9:	jne    40222c <nx_string_reverse+0x1ac>
  4021cb:	mov    (%rsi),%rax
  4021ce:	test   %rax,%rax
  4021d1:	je     4021e7 <nx_string_reverse+0x167>
  4021d3:	lea    (%r15,%rax,8),%rcx
  4021d7:	mov    (%r15,%rax,8),%rdx
  4021db:	mov    %rdx,(%rsi)
  4021de:	decq   0x100(%rsi)
  4021e5:	jmp    402202 <nx_string_reverse+0x182>
  4021e7:	mov    %rdi,(%rsp)
  4021eb:	mov    0x8(%rsp),%rdi
  4021f0:	callq  401c25 <nx_rt_ir_alloc0>
  4021f5:	mov    (%rsp),%rdi
  4021f9:	mov    0x10(%rsp),%rsi
  4021fe:	lea    (%r15,%rax,8),%rcx
  402202:	mov    %r12,%rdx
  402205:	shl    $0x18,%rdx
  402209:	inc    %rdx
  40220c:	mov    %rdx,(%rcx)
  40220f:	movabs $0x2ffff0000000000,%rcx
  402219:	and    %rcx,%r12
  40221c:	movabs $0x8000000000000000,%rcx
  402226:	or     %rcx,%rax
  402229:	or     %rax,%r12
  40222c:	mov    %r14,%rax
  40222f:	movabs $0xff00000000000000,%rcx
  402239:	and    %rcx,%rax
  40223c:	movabs $0x200000000000000,%rcx
  402246:	cmp    %rcx,%rax
  402249:	jne    4022ac <nx_string_reverse+0x22c>
  40224b:	mov    (%rsi),%rax
  40224e:	test   %rax,%rax
  402251:	je     402267 <nx_string_reverse+0x1e7>
  402253:	lea    (%r15,%rax,8),%rcx
  402257:	mov    (%r15,%rax,8),%rdx
  40225b:	mov    %rdx,(%rsi)
  40225e:	decq   0x100(%rsi)
  402265:	jmp    402282 <nx_string_reverse+0x202>
  402267:	mov    %rdi,(%rsp)
  40226b:	mov    0x8(%rsp),%rdi
  402270:	callq  401c25 <nx_rt_ir_alloc0>
  402275:	mov    (%rsp),%rdi
  402279:	mov    0x10(%rsp),%rsi
  40227e:	lea    (%r15,%rax,8),%rcx
  402282:	mov    %r14,%rdx
  402285:	shl    $0x18,%rdx
  402289:	inc    %rdx
  40228c:	mov    %rdx,(%rcx)
  40228f:	movabs $0x2ffff0000000000,%rcx
  402299:	and    %rcx,%r14
  40229c:	movabs $0x8000000000000000,%rcx
  4022a6:	or     %rcx,%r14
  4022a9:	or     %rax,%r14
  4022ac:	mov    %r12,(%rbx)
  4022af:	mov    %r14,(%rdi)
  4022b2:	movabs $0x200030000000000,%rax
  4022bc:	or     %rax,%r13
  4022bf:	mov    %r13,%r14
  4022c2:	movabs $0xffffffffff,%r12
  4022cc:	jmpq   4020e8 <nx_string_reverse+0x68>
  4022d1:	movzwl %ax,%eax
  4022d4:	cmp    $0x2,%eax
  4022d7:	jne    4022eb <nx_string_reverse+0x26b>
  4022d9:	mov    %r14,%rax
  4022dc:	add    $0x18,%rsp
  4022e0:	pop    %rbx
  4022e1:	pop    %r12
  4022e3:	pop    %r13
  4022e5:	pop    %r14
  4022e7:	pop    %r15
  4022e9:	pop    %rbp
  4022ea:	retq   
  4022eb:	mov    0x8(%rsp),%rdi
  4022f0:	mov    $0x1,%esi
  4022f5:	add    $0x18,%rsp
  4022f9:	pop    %rbx
  4022fa:	pop    %r12
  4022fc:	pop    %r13
  4022fe:	pop    %r14
  402300:	pop    %r15
  402302:	pop    %rbp
  402303:	jmpq   402af0 <nx_rt_fail>

Disassembly of section .fini:
