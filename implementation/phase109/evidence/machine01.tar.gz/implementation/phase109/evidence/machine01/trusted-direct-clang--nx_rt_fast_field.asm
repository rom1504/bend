
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004029c0 <nx_rt_fast_field>:
  4029c0:	mov    %esi,%ecx
  4029c2:	mov    $0xfffffffe,%eax
  4029c7:	rol    %cl,%eax
  4029c9:	add    $0x2,%rcx
  4029cd:	and    %eax,0x20(%rdi)
  4029d0:	mov    (%rdi,%rcx,8),%rax
  4029d4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  4029dc:	retq   

Disassembly of section .fini:
