
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004038b0 <nx_rt_pair_rebuild2_c3_k0>:
  4038b0:	push   %r14
  4038b2:	mov    %rsi,%r10
  4038b5:	mov    %rdx,%r8
  4038b8:	movabs $0xffffffffff,%r9
  4038c2:	push   %r13
  4038c4:	and    %r10,%r9
  4038c7:	push   %r12
  4038c9:	lea    0x0(,%r9,8),%rax
  4038d1:	push   %rbp
  4038d2:	sub    $0x18,%rsp
  4038d6:	mov    (%rdi),%rbp
  4038d9:	mov    0x8(%rdi),%rsi
  4038dd:	lea    0x0(%rbp,%rax,1),%rdx
  4038e2:	test   %r10,%r10
  4038e5:	js     403940 <nx_rt_pair_rebuild2_c3_k0+0x90>
  4038e7:	mov    (%rdx),%r13
  4038ea:	mov    0x8(%rbp,%rax,1),%r12
  4038ef:	cmp    $0x310817f,%r9
  4038f6:	jbe    403920 <nx_rt_pair_rebuild2_c3_k0+0x70>
  4038f8:	mov    %r13,%rcx
  4038fb:	mov    $0x3,%edx
  403900:	mov    %rbp,%rdi
  403903:	callq  401fd0 <nx_construct2>
  403908:	add    $0x18,%rsp
  40390c:	mov    %r12,%rdx
  40390f:	pop    %rbp
  403910:	pop    %r12
  403912:	pop    %r13
  403914:	pop    %r14
  403916:	retq   
  403917:	nopw   0x0(%rax,%rax,1)
  403920:	mov    0x8(%rsi),%r9
  403924:	test   %r9,%r9
  403927:	je     401907 <nx_rt_pair_rebuild2_c3_k0.cold>
  40392d:	mov    0x0(%rbp,%r9,8),%rax
  403932:	subq   $0x2,0x108(%rsi)
  40393a:	mov    %rax,0x8(%rsi)
  40393e:	jmp    4038f8 <nx_rt_pair_rebuild2_c3_k0+0x48>
  403940:	mov    0x4(%rdx),%eax
  403943:	mov    (%rdx),%ecx
  403945:	shl    $0x20,%rax
  403949:	or     %rcx,%rax
  40394c:	mov    %rax,%r14
  40394f:	and    $0xffffff,%eax
  403954:	shr    $0x18,%r14
  403958:	lea    0x0(,%r14,8),%rcx
  403960:	lea    0x8(%rbp,%rcx,1),%rdi
  403965:	add    %rbp,%rcx
  403968:	cmp    $0x1,%rax
  40396c:	jne    401945 <nx_rt_pair_rebuild2_c3_k0.cold+0x3e>
  403972:	mov    (%rdx),%eax
  403974:	mov    (%rsi),%rax
  403977:	mov    (%rcx),%r13
  40397a:	mov    (%rdi),%r12
  40397d:	mov    %rax,(%rdx)
  403980:	mov    0x100(%rsi),%rax
  403987:	mov    0x3d84b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40398d:	mov    %r9,(%rsi)
  403990:	add    $0x1,%rax
  403994:	mov    %rax,0x100(%rsi)
  40399b:	cmp    %rdx,%rax
  40399e:	jae    40192e <nx_rt_pair_rebuild2_c3_k0.cold+0x27>
  4039a4:	mov    %r14,%r9
  4039a7:	jmpq   4038ef <nx_rt_pair_rebuild2_c3_k0+0x3f>

Disassembly of section .fini:
