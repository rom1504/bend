000000000041a390 <p125_rt_ctor3>:
  41a390:	push   r15
  41a392:	mov    rax,rdi
  41a395:	push   r14
  41a397:	push   r13
  41a399:	push   r12
  41a39b:	mov    r12,rdx
  41a39e:	push   rbp
  41a39f:	push   rbx
  41a3a0:	mov    ebx,esi
  41a3a2:	sub    rsp,0x18
  41a3a6:	mov    r14,QWORD PTR [rax+0x8]
  41a3aa:	mov    rdi,QWORD PTR [rdi]
  41a3ad:	mov    r13,QWORD PTR [r14+0x10]
  41a3b1:	test   r13,r13
  41a3b4:	je     405095 <p125_rt_ctor3.cold>
  41a3ba:	mov    rax,QWORD PTR [rdi+r13*8]
  41a3be:	sub    QWORD PTR [r14+0x110],0x4
  41a3c6:	mov    QWORD PTR [r14+0x10],rax
  41a3ca:	mov    rax,QWORD PTR [rip+0x1088ff]        # 522cd0 <p111_program_active>
  41a3d1:	test   BYTE PTR [rax+0x58],0x8
  41a3d5:	je     41a3e4 <p125_rt_ctor3+0x54>
  41a3d7:	mov    rax,QWORD PTR [rax+0x88]
  41a3de:	cmp    BYTE PTR [rax+rbx*1],0x0
  41a3e2:	je     41a440 <p125_rt_ctor3+0xb0>
  41a3e4:	lea    r15,[rdi+r13*8]
  41a3e8:	xor    ebp,ebp
  41a3ea:	mov    rdx,QWORD PTR [r12+rbp*1]
  41a3ee:	mov    rax,rdx
  41a3f1:	shr    rax,0x38
  41a3f5:	and    eax,0x7f
  41a3f8:	cmp    rax,0x2
  41a3fc:	je     41a430 <p125_rt_ctor3+0xa0>
  41a3fe:	mov    QWORD PTR [r15+rbp*1],rdx
  41a402:	add    rbp,0x8
  41a406:	cmp    rbp,0x18
  41a40a:	jne    41a3ea <p125_rt_ctor3+0x5a>
  41a40c:	mov    rax,rbx
  41a40f:	add    rsp,0x18
  41a413:	shl    rax,0x28
  41a417:	pop    rbx
  41a418:	pop    rbp
  41a419:	or     rax,r13
  41a41c:	pop    r12
  41a41e:	pop    r13
  41a420:	bts    rax,0x39
  41a425:	pop    r14
  41a427:	pop    r15
  41a429:	ret    
  41a42a:	nop    WORD PTR [rax+rax*1+0x0]
  41a430:	test   rdx,rdx
  41a433:	js     41a3fe <p125_rt_ctor3+0x6e>
  41a435:	jmp    4050b4 <p125_rt_ctor3.cold+0x1f>
  41a43a:	nop    WORD PTR [rax+rax*1+0x0]
  41a440:	lea    rcx,[rdi+r13*8]
  41a444:	xor    eax,eax
  41a446:	mov    rdx,QWORD PTR [r12+rax*1]
  41a44a:	mov    QWORD PTR [rcx+rax*1],rdx
  41a44e:	add    rax,0x8
  41a452:	cmp    rax,0x18
  41a456:	jne    41a446 <p125_rt_ctor3+0xb6>
  41a458:	jmp    41a40c <p125_rt_ctor3+0x7c>
  41a45a:	nop    WORD PTR [rax+rax*1+0x0]

