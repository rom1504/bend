
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004036b0 <nx_rt_pair_rebuild2_c1_k0>:
  4036b0:	push   %r15
  4036b2:	push   %r14
  4036b4:	push   %r13
  4036b6:	push   %r12
  4036b8:	mov    %rdx,%r12
  4036bb:	push   %rbp
  4036bc:	push   %rbx
  4036bd:	movabs $0xffffffffff,%rbx
  4036c7:	and    %rsi,%rbx
  4036ca:	lea    0x0(,%rbx,8),%rdx
  4036d2:	sub    $0x18,%rsp
  4036d6:	mov    (%rdi),%rbp
  4036d9:	mov    0x8(%rdi),%r15
  4036dd:	lea    0x0(%rbp,%rdx,1),%rax
  4036e2:	test   %rsi,%rsi
  4036e5:	js     4037a0 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  4036eb:	mov    (%rax),%r14
  4036ee:	mov    0x8(%rbp,%rdx,1),%r13
  4036f3:	cmp    $0x310817f,%rbx
  4036fa:	jbe    403770 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  4036fc:	lea    0x0(%rbp,%rbx,8),%r8
  403701:	mov    %r14,%rax
  403704:	shr    $0x38,%rax
  403708:	and    $0x7f,%eax
  40370b:	cmp    $0x2,%rax
  40370f:	je     403750 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403711:	mov    %r12,%rax
  403714:	mov    %r14,(%r8)
  403717:	lea    0x8(%rbp,%rbx,8),%r14
  40371c:	shr    $0x38,%rax
  403720:	and    $0x7f,%eax
  403723:	cmp    $0x2,%rax
  403727:	je     403760 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403729:	movabs $0x200010000000000,%rax
  403733:	mov    %r12,(%r14)
  403736:	mov    %r13,%rdx
  403739:	add    $0x18,%rsp
  40373d:	or     %rbx,%rax
  403740:	pop    %rbx
  403741:	pop    %rbp
  403742:	pop    %r12
  403744:	pop    %r13
  403746:	pop    %r14
  403748:	pop    %r15
  40374a:	retq   
  40374b:	nopl   0x0(%rax,%rax,1)
  403750:	test   %r14,%r14
  403753:	js     403711 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403755:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  40375a:	nopw   0x0(%rax,%rax,1)
  403760:	test   %r12,%r12
  403763:	js     403729 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403765:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  40376a:	nopw   0x0(%rax,%rax,1)
  403770:	mov    0x8(%r15),%rbx
  403774:	test   %rbx,%rbx
  403777:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  40377d:	lea    0x0(%rbp,%rbx,8),%r8
  403782:	mov    (%r8),%rax
  403785:	subq   $0x2,0x108(%r15)
  40378d:	mov    %rax,0x8(%r15)
  403791:	jmpq   403701 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403796:	nopw   %cs:0x0(%rax,%rax,1)
  4037a0:	mov    0x4(%rax),%edx
  4037a3:	mov    (%rax),%ecx
  4037a5:	shl    $0x20,%rdx
  4037a9:	or     %rcx,%rdx
  4037ac:	mov    %rdx,%rcx
  4037af:	and    $0xffffff,%edx
  4037b5:	shr    $0x18,%rcx
  4037b9:	lea    0x8(,%rcx,8),%rdi
  4037c1:	lea    0x0(%rbp,%rdi,1),%r8
  4037c6:	lea    -0x8(%rbp,%rdi,1),%rdi
  4037cb:	cmp    $0x1,%rdx
  4037cf:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  4037d5:	mov    (%rax),%edx
  4037d7:	mov    (%r15),%rdx
  4037da:	mov    (%rdi),%r14
  4037dd:	mov    (%r8),%r13
  4037e0:	mov    %rdx,(%rax)
  4037e3:	mov    0x100(%r15),%rax
  4037ea:	mov    0x3d9e8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4037f0:	mov    %rbx,(%r15)
  4037f3:	add    $0x1,%rax
  4037f7:	mov    %rax,0x100(%r15)
  4037fe:	cmp    %rdx,%rax
  403801:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403807:	mov    %rcx,%rbx
  40380a:	jmpq   4036f3 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
