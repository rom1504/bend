
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402c40 <nx_rt_fast_id>:
  402c40:	shr    $0x28,%rsi
  402c44:	movzwl %si,%eax
  402c47:	retq   

Disassembly of section .fini:
