    9820:	push   %rax
    9821:	mov    %esi,%ecx
    9823:	add    %esi,%edx
    9825:	mov    0x8(%r13),%rax
    9829:	test   %rax,%rax
    982c:	je     99a9 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x189>
    9832:	mov    (%r12,%rax,8),%rsi
    9836:	mov    %rsi,0x8(%r13)
    983a:	addq   $0xfffffffffffffffe,0x108(%r13)
    9842:	movabs $0xffffffffff,%r10
    984c:	mov    %rcx,(%r12,%rax,8)
    9850:	mov    %rdx,0x8(%r12,%rax,8)
    9855:	movabs $0x200a40000000000,%r9
    985f:	or     %rax,%r9
    9862:	test   %rax,%rax
    9865:	js     988e <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x6e>
    9867:	lea    -0x7f(%r10),%rcx
    986b:	and    %rcx,%rax
    986e:	cmp    $0x3108180,%rax
    9874:	jb     98aa <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x8a>
    9876:	mov    %r12,%rdi
    9879:	mov    %r13,%rsi
    987c:	mov    %r9,%rdx
    987f:	mov    $0x2,%ecx
    9884:	callq  1184e <rfc_wrap>
    9889:	mov    %rax,%r9
    988c:	jmp    98aa <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x8a>
    988e:	and    %r10,%rax
    9891:	mov    $0x1,%ecx
    9896:	lock xadd %ecx,(%r12,%rax,8)
    989c:	not    %ecx
    989e:	test   $0xfffffe,%ecx
    98a4:	je     9b81 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x361>
    98aa:	movabs $0xffff0000000000,%rax
    98b4:	and    %r9,%rax
    98b7:	movabs $0xa40000000000,%rcx
    98c1:	cmp    %rcx,%rax
    98c4:	jne    9b42 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x322>
    98ca:	mov    %r9,%rdx
    98cd:	and    %r10,%rdx
    98d0:	test   %r9,%r9
    98d3:	js     98ea <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0xca>
    98d5:	mov    (%r12,%rdx,8),%rax
    98d9:	mov    %rdx,%rcx
    98dc:	cmp    $0x3108180,%rcx
    98e3:	jae    9957 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x137>
    98e5:	jmpq   9987 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x167>
    98ea:	mov    0x4(%r12,%rdx,8),%ecx
    98ef:	mov    (%r12,%rdx,8),%eax
    98f3:	mov    %eax,%esi
    98f5:	and    $0xffffff,%esi
    98fb:	cmp    $0x1,%esi
    98fe:	jne    99d6 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x1b6>
    9904:	mov    (%r12,%rdx,8),%esi
    9908:	shl    $0x20,%rcx
    990c:	or     %rax,%rcx
    990f:	shr    $0x18,%rcx
    9913:	mov    (%r12,%rcx,8),%rax
    9917:	mov    0x0(%r13),%rsi
    991b:	mov    %rsi,(%r12,%rdx,8)
    991f:	mov    %rdx,0x0(%r13)
    9923:	mov    0x100(%r13),%rdx
    992a:	inc    %rdx
    992d:	mov    %rdx,0x100(%r13)
    9934:	cmpb   $0x1,0x10b8d5(%rip)        # 115210 <KEEP_WORDS>
    993b:	jne    9b23 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x303>
    9941:	cmp    $0x8000,%rdx
    9948:	jae    9b23 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x303>
    994e:	cmp    $0x3108180,%rcx
    9955:	jb     9987 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x167>
    9957:	mov    0x8(%r13),%rdx
    995b:	mov    %rdx,(%r12,%rcx,8)
    995f:	mov    %rcx,0x8(%r13)
    9963:	mov    0x108(%r13),%rcx
    996a:	add    $0x2,%rcx
    996e:	mov    %rcx,0x108(%r13)
    9975:	cmpb   $0x1,0x10b894(%rip)        # 115210 <KEEP_WORDS>
    997c:	jne    99c4 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x1a4>
    997e:	cmp    $0x8000,%rcx
    9985:	jae    99c4 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x1a4>
    9987:	test   %r9,%r9
    998a:	js     99f9 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x1d9>
    998c:	and    %r10,%r9
    998f:	mov    0x8(%r12,%r9,8),%rsi
    9994:	mov    %r9,%rcx
    9997:	cmp    $0x3108180,%rcx
    999e:	jae    9a6a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x24a>
    99a4:	jmpq   9a9a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x27a>
    99a9:	mov    %r12,%rdi
    99ac:	mov    %r13,%rsi
    99af:	mov    %rdx,%r8
    99b2:	mov    $0x1,%edx
    99b7:	callq  11548 <heap_alloc_miss>
    99bc:	mov    %r8,%rdx
    99bf:	jmpq   9842 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x22>
    99c4:	mov    %r12,%rdi
    99c7:	mov    %r13,%rsi
    99ca:	mov    $0x1,%edx
    99cf:	callq  11421 <heap_hand>
    99d4:	jmp    9987 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x167>
    99d6:	shl    $0x20,%rcx
    99da:	or     %rax,%rcx
    99dd:	shr    $0x18,%rcx
    99e1:	mov    (%r12,%rcx,8),%rax
    99e5:	mov    %r12,%rdi
    99e8:	mov    %r13,%rsi
    99eb:	mov    %r9,%rdx
    99ee:	mov    $0x2,%r8d
    99f4:	callq  114b2 <span_fade>
    99f9:	and    %r9,%r10
    99fc:	mov    0x4(%r12,%r10,8),%ecx
    9a01:	mov    (%r12,%r10,8),%edx
    9a05:	mov    %edx,%esi
    9a07:	and    $0xffffff,%esi
    9a0d:	cmp    $0x1,%esi
    9a10:	jne    9ad5 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x2b5>
    9a16:	mov    (%r12,%r10,8),%esi
    9a1a:	shl    $0x20,%rcx
    9a1e:	or     %rdx,%rcx
    9a21:	shr    $0x18,%rcx
    9a25:	mov    0x8(%r12,%rcx,8),%rsi
    9a2a:	mov    0x0(%r13),%rdx
    9a2e:	mov    %rdx,(%r12,%r10,8)
    9a32:	mov    %r10,0x0(%r13)
    9a36:	mov    0x100(%r13),%rdx
    9a3d:	inc    %rdx
    9a40:	mov    %rdx,0x100(%r13)
    9a47:	cmpb   $0x1,0x10b7c2(%rip)        # 115210 <KEEP_WORDS>
    9a4e:	jne    9afe <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x2de>
    9a54:	cmp    $0x8000,%rdx
    9a5b:	jae    9afe <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x2de>
    9a61:	cmp    $0x3108180,%rcx
    9a68:	jb     9a9a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x27a>
    9a6a:	mov    0x8(%r13),%rdx
    9a6e:	mov    %rdx,(%r12,%rcx,8)
    9a72:	mov    %rcx,0x8(%r13)
    9a76:	mov    0x108(%r13),%rcx
    9a7d:	add    $0x2,%rcx
    9a81:	mov    %rcx,0x108(%r13)
    9a88:	cmpb   $0x1,0x10b781(%rip)        # 115210 <KEEP_WORDS>
    9a8f:	jne    9abd <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x29d>
    9a91:	cmp    $0x8000,%rcx
    9a98:	jae    9abd <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x29d>
    9a9a:	lea    (%rax,%rax,2),%eax
    9a9d:	xor    $0x7,%esi
    9aa0:	add    %eax,%esi
    9aa2:	mov    -0x8(%r14),%eax
    9aa6:	add    $0xfffffffffffffff8,%r14
    9aaa:	lea    0x9eff(%rip),%rcx        # 139b0 <wl_tab>
    9ab1:	mov    (%rcx,%rax,8),%rax
    9ab5:	mov    $0x1,%edi
    9aba:	pop    %rcx
    9abb:	jmpq   *%rax
    9abd:	mov    %r12,%rdi
    9ac0:	mov    %rsi,%rcx
    9ac3:	mov    %r13,%rsi
    9ac6:	mov    $0x1,%edx
    9acb:	callq  11421 <heap_hand>
    9ad0:	mov    %rcx,%rsi
    9ad3:	jmp    9a9a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x27a>
    9ad5:	shl    $0x20,%rcx
    9ad9:	or     %rdx,%rcx
    9adc:	shr    $0x18,%rcx
    9ae0:	mov    0x8(%r12,%rcx,8),%r10
    9ae5:	mov    %r12,%rdi
    9ae8:	mov    %r13,%rsi
    9aeb:	mov    %r9,%rdx
    9aee:	mov    $0x2,%r8d
    9af4:	callq  114b2 <span_fade>
    9af9:	mov    %r10,%rsi
    9afc:	jmp    9a9a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x27a>
    9afe:	mov    %r12,%rdi
    9b01:	mov    %rsi,%r8
    9b04:	mov    %r13,%rsi
    9b07:	xor    %edx,%edx
    9b09:	callq  11421 <heap_hand>
    9b0e:	mov    %r8,%rsi
    9b11:	cmp    $0x3108180,%rcx
    9b18:	jae    9a6a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x24a>
    9b1e:	jmpq   9a9a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x27a>
    9b23:	mov    %r12,%rdi
    9b26:	mov    %r13,%rsi
    9b29:	xor    %edx,%edx
    9b2b:	callq  11421 <heap_hand>
    9b30:	cmp    $0x3108180,%rcx
    9b37:	jae    9957 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x137>
    9b3d:	jmpq   9987 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x167>
    9b42:	cmp    $0xffffffffffffffff,%r9
    9b46:	je     9b75 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x355>
    9b48:	movabs $0x7e00000000000000,%rax
    9b52:	and    %r9,%rax
    9b55:	je     9b75 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x355>
    9b57:	add    $0xffffffffffffff81,%r10
    9b5b:	and    %r9,%r10
    9b5e:	cmp    $0x3108180,%r10
    9b65:	jb     9b75 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x355>
    9b67:	mov    %r12,%rdi
    9b6a:	mov    %r13,%rsi
    9b6d:	mov    %r9,%rdx
    9b70:	callq  6ac0 <term_drop>
    9b75:	lea    -0x766c(%rip),%rdi        # 2510 <FID_RESW_T+0x310>
    9b7c:	callq  113c0 <err_fail>
    9b81:	lea    -0x70af(%rip),%rdi        # 2ad9 <FID_RESW_T+0x8d9>
    9b88:	callq  113c0 <err_fail>
    9b8d:	nopl   (%rax)
