
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403f60 <nx_rt_rebuild2_c3_k0>:
  403f60:	push   %r15
  403f62:	push   %r14
  403f64:	push   %r13
  403f66:	push   %r12
  403f68:	mov    %rdx,%r12
  403f6b:	push   %rbp
  403f6c:	mov    %rdi,%rbp
  403f6f:	push   %rbx
  403f70:	movabs $0xffffffffff,%rbx
  403f7a:	and    %rsi,%rbx
  403f7d:	lea    0x0(,%rbx,8),%rdx
  403f85:	sub    $0x18,%rsp
  403f89:	mov    (%rdi),%r13
  403f8c:	mov    0x8(%rdi),%r15
  403f90:	lea    0x0(%r13,%rdx,1),%rax
  403f95:	test   %rsi,%rsi
  403f98:	js     404060 <nx_rt_rebuild2_c3_k0+0x100>
  403f9e:	mov    (%rax),%r14
  403fa1:	mov    0x8(%r13,%rdx,1),%r9
  403fa6:	cmp    $0x310817f,%rbx
  403fad:	jbe    404038 <nx_rt_rebuild2_c3_k0+0xd8>
  403fb3:	lea    0x0(%r13,%rbx,8),%r8
  403fb8:	mov    %r14,%rax
  403fbb:	mov    %r9,0x10(%rbp)
  403fbf:	shr    $0x38,%rax
  403fc3:	movq   $0xffffffffffffffff,0x18(%rbp)
  403fcb:	and    $0x7f,%eax
  403fce:	movl   $0x1,0x20(%rbp)
  403fd5:	cmp    $0x2,%rax
  403fd9:	je     404018 <nx_rt_rebuild2_c3_k0+0xb8>
  403fdb:	mov    %r12,%rax
  403fde:	mov    %r14,(%r8)
  403fe1:	lea    0x8(%r13,%rbx,8),%rbp
  403fe6:	shr    $0x38,%rax
  403fea:	and    $0x7f,%eax
  403fed:	cmp    $0x2,%rax
  403ff1:	je     404028 <nx_rt_rebuild2_c3_k0+0xc8>
  403ff3:	movabs $0x200030000000000,%rax
  403ffd:	mov    %r12,0x0(%rbp)
  404001:	add    $0x18,%rsp
  404005:	or     %rbx,%rax
  404008:	pop    %rbx
  404009:	pop    %rbp
  40400a:	pop    %r12
  40400c:	pop    %r13
  40400e:	pop    %r14
  404010:	pop    %r15
  404012:	retq   
  404013:	nopl   0x0(%rax,%rax,1)
  404018:	test   %r14,%r14
  40401b:	js     403fdb <nx_rt_rebuild2_c3_k0+0x7b>
  40401d:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  404022:	nopw   0x0(%rax,%rax,1)
  404028:	test   %r12,%r12
  40402b:	js     403ff3 <nx_rt_rebuild2_c3_k0+0x93>
  40402d:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  404032:	nopw   0x0(%rax,%rax,1)
  404038:	mov    0x8(%r15),%rbx
  40403c:	test   %rbx,%rbx
  40403f:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  404045:	lea    0x0(%r13,%rbx,8),%r8
  40404a:	mov    (%r8),%rax
  40404d:	subq   $0x2,0x108(%r15)
  404055:	mov    %rax,0x8(%r15)
  404059:	jmpq   403fb8 <nx_rt_rebuild2_c3_k0+0x58>
  40405e:	xchg   %ax,%ax
  404060:	mov    0x4(%rax),%edx
  404063:	mov    (%rax),%ecx
  404065:	shl    $0x20,%rdx
  404069:	or     %rcx,%rdx
  40406c:	mov    %rdx,%rcx
  40406f:	and    $0xffffff,%edx
  404075:	shr    $0x18,%rcx
  404079:	lea    0x8(,%rcx,8),%rdi
  404081:	lea    0x0(%r13,%rdi,1),%r8
  404086:	lea    -0x8(%r13,%rdi,1),%rdi
  40408b:	cmp    $0x1,%rdx
  40408f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  404095:	mov    (%rax),%edx
  404097:	mov    (%r15),%rdx
  40409a:	mov    (%rdi),%r14
  40409d:	mov    (%r8),%r9
  4040a0:	mov    %rdx,(%rax)
  4040a3:	mov    0x100(%r15),%rax
  4040aa:	mov    0x3e128(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4040b0:	mov    %rbx,(%r15)
  4040b3:	add    $0x1,%rax
  4040b7:	mov    %rax,0x100(%r15)
  4040be:	cmp    %rdx,%rax
  4040c1:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  4040c7:	mov    %rcx,%rbx
  4040ca:	jmpq   403fa6 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
