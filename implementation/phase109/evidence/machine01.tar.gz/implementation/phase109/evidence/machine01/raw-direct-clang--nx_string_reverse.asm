
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401920 <nx_string_reverse>:
  401920:	push   %r15
  401922:	push   %r14
  401924:	push   %r12
  401926:	push   %rbx
  401927:	push   %rax
  401928:	mov    %rdx,%rbx
  40192b:	mov    %rsi,%r15
  40192e:	mov    %rdi,%r14
  401931:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  401940:	callq  4021f0 <nx_rt_id>
  401945:	cmp    $0x2,%eax
  401948:	je     4019a0 <nx_string_reverse+0x80>
  40194a:	mov    %r14,%rdi
  40194d:	mov    %r15,%rsi
  401950:	callq  4021f0 <nx_rt_id>
  401955:	cmp    $0x3,%eax
  401958:	jne    4019af <nx_string_reverse+0x8f>
  40195a:	mov    %r14,%rdi
  40195d:	mov    %r15,%rsi
  401960:	callq  402530 <nx_rt_take2>
  401965:	mov    %r14,%rdi
  401968:	xor    %esi,%esi
  40196a:	callq  4026c0 <nx_rt_field>
  40196f:	mov    %rax,%r12
  401972:	mov    %r14,%rdi
  401975:	mov    $0x1,%esi
  40197a:	callq  4026c0 <nx_rt_field>
  40197f:	mov    %rax,%r15
  401982:	mov    %r14,%rdi
  401985:	mov    $0x3,%esi
  40198a:	mov    %r12,%rdx
  40198d:	mov    %rbx,%rcx
  401990:	callq  4024a0 <nx_rt_build2>
  401995:	mov    %rax,%rbx
  401998:	mov    %r14,%rdi
  40199b:	mov    %r15,%rsi
  40199e:	jmp    401940 <nx_string_reverse+0x20>
  4019a0:	mov    %rbx,%rax
  4019a3:	add    $0x8,%rsp
  4019a7:	pop    %rbx
  4019a8:	pop    %r12
  4019aa:	pop    %r14
  4019ac:	pop    %r15
  4019ae:	retq   
  4019af:	mov    %r14,%rdi
  4019b2:	mov    $0x1,%esi
  4019b7:	add    $0x8,%rsp
  4019bb:	pop    %rbx
  4019bc:	pop    %r12
  4019be:	pop    %r14
  4019c0:	pop    %r15
  4019c2:	jmpq   402230 <nx_rt_fail>

Disassembly of section .fini:
