
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404140 <nx_rt_rebuild2_c3_k0>:
  404140:	push   %r15
  404142:	push   %r14
  404144:	push   %r13
  404146:	push   %r12
  404148:	mov    %rdx,%r12
  40414b:	push   %rbp
  40414c:	mov    %rdi,%rbp
  40414f:	push   %rbx
  404150:	movabs $0xffffffffff,%rbx
  40415a:	and    %rsi,%rbx
  40415d:	lea    0x0(,%rbx,8),%rdx
  404165:	sub    $0x18,%rsp
  404169:	mov    (%rdi),%r13
  40416c:	mov    0x8(%rdi),%r15
  404170:	lea    0x0(%r13,%rdx,1),%rax
  404175:	test   %rsi,%rsi
  404178:	js     404240 <nx_rt_rebuild2_c3_k0+0x100>
  40417e:	mov    (%rax),%r14
  404181:	mov    0x8(%r13,%rdx,1),%r9
  404186:	cmp    $0x310817f,%rbx
  40418d:	jbe    404218 <nx_rt_rebuild2_c3_k0+0xd8>
  404193:	lea    0x0(%r13,%rbx,8),%r8
  404198:	mov    %r14,%rax
  40419b:	mov    %r9,0x10(%rbp)
  40419f:	shr    $0x38,%rax
  4041a3:	movq   $0xffffffffffffffff,0x18(%rbp)
  4041ab:	and    $0x7f,%eax
  4041ae:	movl   $0x1,0x20(%rbp)
  4041b5:	cmp    $0x2,%rax
  4041b9:	je     4041f8 <nx_rt_rebuild2_c3_k0+0xb8>
  4041bb:	mov    %r12,%rax
  4041be:	mov    %r14,(%r8)
  4041c1:	lea    0x8(%r13,%rbx,8),%rbp
  4041c6:	shr    $0x38,%rax
  4041ca:	and    $0x7f,%eax
  4041cd:	cmp    $0x2,%rax
  4041d1:	je     404208 <nx_rt_rebuild2_c3_k0+0xc8>
  4041d3:	movabs $0x200030000000000,%rax
  4041dd:	mov    %r12,0x0(%rbp)
  4041e1:	add    $0x18,%rsp
  4041e5:	or     %rbx,%rax
  4041e8:	pop    %rbx
  4041e9:	pop    %rbp
  4041ea:	pop    %r12
  4041ec:	pop    %r13
  4041ee:	pop    %r14
  4041f0:	pop    %r15
  4041f2:	retq   
  4041f3:	nopl   0x0(%rax,%rax,1)
  4041f8:	test   %r14,%r14
  4041fb:	js     4041bb <nx_rt_rebuild2_c3_k0+0x7b>
  4041fd:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  404202:	nopw   0x0(%rax,%rax,1)
  404208:	test   %r12,%r12
  40420b:	js     4041d3 <nx_rt_rebuild2_c3_k0+0x93>
  40420d:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  404212:	nopw   0x0(%rax,%rax,1)
  404218:	mov    0x8(%r15),%rbx
  40421c:	test   %rbx,%rbx
  40421f:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  404225:	lea    0x0(%r13,%rbx,8),%r8
  40422a:	mov    (%r8),%rax
  40422d:	subq   $0x2,0x108(%r15)
  404235:	mov    %rax,0x8(%r15)
  404239:	jmpq   404198 <nx_rt_rebuild2_c3_k0+0x58>
  40423e:	xchg   %ax,%ax
  404240:	mov    0x4(%rax),%edx
  404243:	mov    (%rax),%ecx
  404245:	shl    $0x20,%rdx
  404249:	or     %rcx,%rdx
  40424c:	mov    %rdx,%rcx
  40424f:	and    $0xffffff,%edx
  404255:	shr    $0x18,%rcx
  404259:	lea    0x8(,%rcx,8),%rdi
  404261:	lea    0x0(%r13,%rdi,1),%r8
  404266:	lea    -0x8(%r13,%rdi,1),%rdi
  40426b:	cmp    $0x1,%rdx
  40426f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  404275:	mov    (%rax),%edx
  404277:	mov    (%r15),%rdx
  40427a:	mov    (%rdi),%r14
  40427d:	mov    (%r8),%r9
  404280:	mov    %rdx,(%rax)
  404283:	mov    0x100(%r15),%rax
  40428a:	mov    0x3df48(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404290:	mov    %rbx,(%r15)
  404293:	add    $0x1,%rax
  404297:	mov    %rax,0x100(%r15)
  40429e:	cmp    %rdx,%rax
  4042a1:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  4042a7:	mov    %rcx,%rbx
  4042aa:	jmpq   404186 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
