
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004035c0 <nx_rt_rebuild2_c1_k0>:
  4035c0:	push   %r15
  4035c2:	push   %r14
  4035c4:	push   %r13
  4035c6:	push   %r12
  4035c8:	mov    %rdx,%r12
  4035cb:	push   %rbp
  4035cc:	mov    %rdi,%rbp
  4035cf:	push   %rbx
  4035d0:	movabs $0xffffffffff,%rbx
  4035da:	and    %rsi,%rbx
  4035dd:	lea    0x0(,%rbx,8),%rdx
  4035e5:	sub    $0x18,%rsp
  4035e9:	mov    (%rdi),%r13
  4035ec:	mov    0x8(%rdi),%r15
  4035f0:	lea    0x0(%r13,%rdx,1),%rax
  4035f5:	test   %rsi,%rsi
  4035f8:	js     4036c0 <nx_rt_rebuild2_c1_k0+0x100>
  4035fe:	mov    (%rax),%r14
  403601:	mov    0x8(%r13,%rdx,1),%r9
  403606:	cmp    $0x310817f,%rbx
  40360d:	jbe    403698 <nx_rt_rebuild2_c1_k0+0xd8>
  403613:	lea    0x0(%r13,%rbx,8),%r8
  403618:	mov    %r14,%rax
  40361b:	mov    %r9,0x10(%rbp)
  40361f:	shr    $0x38,%rax
  403623:	movq   $0xffffffffffffffff,0x18(%rbp)
  40362b:	and    $0x7f,%eax
  40362e:	movl   $0x1,0x20(%rbp)
  403635:	cmp    $0x2,%rax
  403639:	je     403678 <nx_rt_rebuild2_c1_k0+0xb8>
  40363b:	mov    %r12,%rax
  40363e:	mov    %r14,(%r8)
  403641:	lea    0x8(%r13,%rbx,8),%rbp
  403646:	shr    $0x38,%rax
  40364a:	and    $0x7f,%eax
  40364d:	cmp    $0x2,%rax
  403651:	je     403688 <nx_rt_rebuild2_c1_k0+0xc8>
  403653:	movabs $0x200010000000000,%rax
  40365d:	mov    %r12,0x0(%rbp)
  403661:	add    $0x18,%rsp
  403665:	or     %rbx,%rax
  403668:	pop    %rbx
  403669:	pop    %rbp
  40366a:	pop    %r12
  40366c:	pop    %r13
  40366e:	pop    %r14
  403670:	pop    %r15
  403672:	retq   
  403673:	nopl   0x0(%rax,%rax,1)
  403678:	test   %r14,%r14
  40367b:	js     40363b <nx_rt_rebuild2_c1_k0+0x7b>
  40367d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403682:	nopw   0x0(%rax,%rax,1)
  403688:	test   %r12,%r12
  40368b:	js     403653 <nx_rt_rebuild2_c1_k0+0x93>
  40368d:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403692:	nopw   0x0(%rax,%rax,1)
  403698:	mov    0x8(%r15),%rbx
  40369c:	test   %rbx,%rbx
  40369f:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  4036a5:	lea    0x0(%r13,%rbx,8),%r8
  4036aa:	mov    (%r8),%rax
  4036ad:	subq   $0x2,0x108(%r15)
  4036b5:	mov    %rax,0x8(%r15)
  4036b9:	jmpq   403618 <nx_rt_rebuild2_c1_k0+0x58>
  4036be:	xchg   %ax,%ax
  4036c0:	mov    0x4(%rax),%edx
  4036c3:	mov    (%rax),%ecx
  4036c5:	shl    $0x20,%rdx
  4036c9:	or     %rcx,%rdx
  4036cc:	mov    %rdx,%rcx
  4036cf:	and    $0xffffff,%edx
  4036d5:	shr    $0x18,%rcx
  4036d9:	lea    0x8(,%rcx,8),%rdi
  4036e1:	lea    0x0(%r13,%rdi,1),%r8
  4036e6:	lea    -0x8(%r13,%rdi,1),%rdi
  4036eb:	cmp    $0x1,%rdx
  4036ef:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  4036f5:	mov    (%rax),%edx
  4036f7:	mov    (%r15),%rdx
  4036fa:	mov    (%rdi),%r14
  4036fd:	mov    (%r8),%r9
  403700:	mov    %rdx,(%rax)
  403703:	mov    0x100(%r15),%rax
  40370a:	mov    0x3dac8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403710:	mov    %rbx,(%r15)
  403713:	add    $0x1,%rax
  403717:	mov    %rax,0x100(%r15)
  40371e:	cmp    %rdx,%rax
  403721:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  403727:	mov    %rcx,%rbx
  40372a:	jmpq   403606 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
