// Phase66: current Base blocking result ABI on the retained IoAct scheduler.
// Adapted through upstream 018751270e800bc222a93dad7f257083ee53a5f7.
// Uses the retained selfhost runtime and its CID_* constructor ABI.
// TCP
// ===

// A recv that finds nothing (the socket is non-blocking) parks until
// the socket is readable. Zero-size requests fail before any wait.
// What it finds, read makes a String (io_str) or a List of bytes (io_list).
static Term tcp_recv_with(Env e, IoWork* w, IoPack more,
  Term (*read)(Env, const char*, u64)) {
  int fd  = (int)w->hand;
  w->size = io_sys_end(w, recv(fd, w->data, (size_t)w->made, 0));
  if (w->code == EAGAIN) {
    return io_wait_on(w, fd, POLLIN, 0, more);
  }
  Term r = w->code ? io_fail(e, w->code, NULL)
    : io_done(e, w->size == 0 ? term_pak(CID_NONE, 0)
      : io_box(e, CID_SOME, read(e, w->data, w->size)));
  free(w->data);
  return io_tup(e, io_hand(w->hand), r);
}

static Term tcp_recv_start(Env e, Term* f, IoWork* w, IoPack more) {
  w->hand = (intptr_t)io_hand_v(f[0]);
  if (f[1] == 0) {
    return io_tup(e, io_hand(w->hand), io_fail(e, EINVAL, NULL));
  }
  w->made = f[1] < INT32_MAX ? (intptr_t)f[1] : INT32_MAX;
  w->data = io_mem(malloc((size_t)w->made));
  return more(e, w);
}

#ifdef CID_TCP_RECV

static Term tcp_recv_more(Env e, IoWork* w) {
  return tcp_recv_with(e, w, tcp_recv_more, io_str);
}

Term tcp_recv_run(Env e, Term* f, IoWork* w) {
  return tcp_recv_start(e, f, w, tcp_recv_more);
}

static void __attribute__((constructor)) tcp_recv_use(void) {
  io_eff(CID_TCP_RECV, tcp_recv_run, 0);
}

#endif

#ifdef CID_TCP_RECV_BYTES

static Term tcp_recv_bytes_more(Env e, IoWork* w) {
  return tcp_recv_with(e, w, tcp_recv_bytes_more, io_list);
}

Term tcp_recv_bytes_run(Env e, Term* f, IoWork* w) {
  return tcp_recv_start(e, f, w, tcp_recv_bytes_more);
}

static void __attribute__((constructor)) tcp_recv_bytes_use(void) {
  io_eff(CID_TCP_RECV_BYTES, tcp_recv_bytes_run, 0);
}

#endif
