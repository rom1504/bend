
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402810 <nx_rt_fast_build2>:
  402810:	push   %r15
  402812:	push   %r14
  402814:	push   %r13
  402816:	mov    %rdx,%r13
  402819:	push   %r12
  40281b:	mov    %rcx,%r12
  40281e:	push   %rbp
  40281f:	push   %rbx
  402820:	mov    %esi,%ebx
  402822:	sub    $0x18,%rsp
  402826:	mov    0x8(%rdi),%r14
  40282a:	mov    (%rdi),%r15
  40282d:	mov    0x8(%r14),%rbp
  402831:	test   %rbp,%rbp
  402834:	je     4015f3 <nx_rt_fast_build2.cold+0x40>
  40283a:	lea    (%r15,%rbp,8),%r8
  40283e:	mov    (%r8),%rax
  402841:	subq   $0x2,0x108(%r14)
  402849:	mov    %rax,0x8(%r14)
  40284d:	mov    %r13,%rax
  402850:	shr    $0x38,%rax
  402854:	and    $0x7f,%eax
  402857:	cmp    $0x2,%rax
  40285b:	je     4028a0 <nx_rt_fast_build2+0x90>
  40285d:	mov    %r12,%rax
  402860:	mov    %r13,(%r8)
  402863:	lea    0x8(%r15,%rbp,8),%r13
  402868:	shr    $0x38,%rax
  40286c:	and    $0x7f,%eax
  40286f:	cmp    $0x2,%rax
  402873:	je     4028b0 <nx_rt_fast_build2+0xa0>
  402875:	mov    %rbx,%rax
  402878:	mov    %r12,0x0(%r13)
  40287c:	add    $0x18,%rsp
  402880:	shl    $0x28,%rax
  402884:	pop    %rbx
  402885:	or     %rbp,%rax
  402888:	pop    %rbp
  402889:	pop    %r12
  40288b:	bts    $0x39,%rax
  402890:	pop    %r13
  402892:	pop    %r14
  402894:	pop    %r15
  402896:	retq   
  402897:	nopw   0x0(%rax,%rax,1)
  4028a0:	test   %r13,%r13
  4028a3:	js     40285d <nx_rt_fast_build2+0x4d>
  4028a5:	jmpq   4015b3 <nx_rt_fast_build2.cold>
  4028aa:	nopw   0x0(%rax,%rax,1)
  4028b0:	test   %r12,%r12
  4028b3:	js     402875 <nx_rt_fast_build2+0x65>
  4028b5:	jmpq   4015d8 <nx_rt_fast_build2.cold+0x25>

Disassembly of section .fini:
