
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c70 <nx_string_reverse>:
  401c70:	mov    %rsi,%rax
  401c73:	mov    %rdx,%r8
  401c76:	shr    $0x28,%rax
  401c7a:	cmp    $0x2,%ax
  401c7e:	je     401cce <nx_string_reverse+0x5e>
  401c80:	movzwl %ax,%edx
  401c83:	push   %rbp
  401c84:	mov    %rdi,%rbp
  401c87:	cmp    $0x3,%rdx
  401c8b:	je     401c96 <nx_string_reverse+0x26>
  401c8d:	jmp    401cc0 <nx_string_reverse+0x50>
  401c8f:	nop
  401c90:	cmp    $0x3,%rdx
  401c94:	jne    401cc0 <nx_string_reverse+0x50>
  401c96:	mov    %r8,%rdx
  401c99:	mov    %rbp,%rdi
  401c9c:	callq  403890 <nx_rt_pair_rebuild2_c3_k0>
  401ca1:	mov    %rax,%r8
  401ca4:	mov    %rdx,%rax
  401ca7:	mov    %rdx,%rsi
  401caa:	shr    $0x28,%rax
  401cae:	movzwl %ax,%edx
  401cb1:	cmp    $0x2,%ax
  401cb5:	jne    401c90 <nx_string_reverse+0x20>
  401cb7:	mov    %r8,%rax
  401cba:	pop    %rbp
  401cbb:	retq   
  401cbc:	nopl   0x0(%rax)
  401cc0:	mov    %rbp,%rdi
  401cc3:	mov    $0x1,%esi
  401cc8:	pop    %rbp
  401cc9:	jmpq   402540 <nx_rt_fail>
  401cce:	mov    %rdx,%rax
  401cd1:	retq   

Disassembly of section .fini:
