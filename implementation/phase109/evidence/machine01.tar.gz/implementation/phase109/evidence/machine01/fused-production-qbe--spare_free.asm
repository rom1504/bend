
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401aa0 <spare_free>:
  401aa0:	endbr64 
  401aa4:	push   %rbp
  401aa5:	mov    %rsp,%rbp
  401aa8:	sub    $0x10,%rsp
  401aac:	mov    %rdi,-0x10(%rbp)
  401ab0:	mov    %rsi,-0x8(%rbp)
  401ab4:	cmp    $0x3108180,%rcx
  401abb:	jb     401aca <spare_free+0x2a>
  401abd:	mov    -0x10(%rbp),%rdi
  401ac1:	mov    -0x8(%rbp),%rsi
  401ac5:	callq  401a20 <heap_free>
  401aca:	leaveq 
  401acb:	retq   

Disassembly of section .fini:
