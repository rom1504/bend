
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	endbr64 
  401c04:	push   %rbp
  401c05:	mov    %rsp,%rbp
  401c08:	push   %rbx
  401c09:	push   %r12
  401c0b:	mov    %rdx,%rax
  401c0e:	mov    %rax,%rdx
  401c11:	data16 nopw %cs:0x0(%rax,%rax,1)
  401c1c:	nopl   0x0(%rax)
  401c20:	mov    %rsi,%rax
  401c23:	shr    $0x28,%rax
  401c27:	and    $0xffff,%rax
  401c2d:	cmp    $0x0,%rax
  401c31:	je     401c6b <nx_list_reverse+0x6b>
  401c33:	cmp    $0x1,%rax
  401c37:	jne    401c5f <nx_list_reverse+0x5f>
  401c39:	mov    %rdi,%rbx
  401c3c:	callq  403380 <nx_rt_rebuild2_c1_k0>
  401c41:	mov    %rbx,%rdi
  401c44:	mov    %rax,%r12
  401c47:	mov    $0x0,%esi
  401c4c:	mov    %rdi,%rbx
  401c4f:	callq  402d10 <nx_rt_fast_field>
  401c54:	mov    %r12,%rdx
  401c57:	mov    %rbx,%rdi
  401c5a:	mov    %rax,%rsi
  401c5d:	jmp    401c20 <nx_list_reverse+0x20>
  401c5f:	mov    $0x1,%esi
  401c64:	callq  402560 <nx_rt_fail>
  401c69:	jmp    401c6e <nx_list_reverse+0x6e>
  401c6b:	mov    %rdx,%rax
  401c6e:	pop    %r12
  401c70:	pop    %rbx
  401c71:	leaveq 
  401c72:	retq   

Disassembly of section .fini:
