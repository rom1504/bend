
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004039c0 <nx_rt_rebuild2_c1_k0>:
  4039c0:	push   %r15
  4039c2:	push   %r14
  4039c4:	push   %r13
  4039c6:	push   %r12
  4039c8:	mov    %rdx,%r12
  4039cb:	push   %rbp
  4039cc:	mov    %rdi,%rbp
  4039cf:	push   %rbx
  4039d0:	movabs $0xffffffffff,%rbx
  4039da:	and    %rsi,%rbx
  4039dd:	lea    0x0(,%rbx,8),%rdx
  4039e5:	sub    $0x18,%rsp
  4039e9:	mov    (%rdi),%r13
  4039ec:	mov    0x8(%rdi),%r15
  4039f0:	lea    0x0(%r13,%rdx,1),%rax
  4039f5:	test   %rsi,%rsi
  4039f8:	js     403ac0 <nx_rt_rebuild2_c1_k0+0x100>
  4039fe:	mov    (%rax),%r14
  403a01:	mov    0x8(%r13,%rdx,1),%r9
  403a06:	cmp    $0x310817f,%rbx
  403a0d:	jbe    403a98 <nx_rt_rebuild2_c1_k0+0xd8>
  403a13:	lea    0x0(%r13,%rbx,8),%r8
  403a18:	mov    %r14,%rax
  403a1b:	mov    %r9,0x10(%rbp)
  403a1f:	shr    $0x38,%rax
  403a23:	movq   $0xffffffffffffffff,0x18(%rbp)
  403a2b:	and    $0x7f,%eax
  403a2e:	movl   $0x1,0x20(%rbp)
  403a35:	cmp    $0x2,%rax
  403a39:	je     403a78 <nx_rt_rebuild2_c1_k0+0xb8>
  403a3b:	mov    %r12,%rax
  403a3e:	mov    %r14,(%r8)
  403a41:	lea    0x8(%r13,%rbx,8),%rbp
  403a46:	shr    $0x38,%rax
  403a4a:	and    $0x7f,%eax
  403a4d:	cmp    $0x2,%rax
  403a51:	je     403a88 <nx_rt_rebuild2_c1_k0+0xc8>
  403a53:	movabs $0x200010000000000,%rax
  403a5d:	mov    %r12,0x0(%rbp)
  403a61:	add    $0x18,%rsp
  403a65:	or     %rbx,%rax
  403a68:	pop    %rbx
  403a69:	pop    %rbp
  403a6a:	pop    %r12
  403a6c:	pop    %r13
  403a6e:	pop    %r14
  403a70:	pop    %r15
  403a72:	retq   
  403a73:	nopl   0x0(%rax,%rax,1)
  403a78:	test   %r14,%r14
  403a7b:	js     403a3b <nx_rt_rebuild2_c1_k0+0x7b>
  403a7d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403a82:	nopw   0x0(%rax,%rax,1)
  403a88:	test   %r12,%r12
  403a8b:	js     403a53 <nx_rt_rebuild2_c1_k0+0x93>
  403a8d:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403a92:	nopw   0x0(%rax,%rax,1)
  403a98:	mov    0x8(%r15),%rbx
  403a9c:	test   %rbx,%rbx
  403a9f:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  403aa5:	lea    0x0(%r13,%rbx,8),%r8
  403aaa:	mov    (%r8),%rax
  403aad:	subq   $0x2,0x108(%r15)
  403ab5:	mov    %rax,0x8(%r15)
  403ab9:	jmpq   403a18 <nx_rt_rebuild2_c1_k0+0x58>
  403abe:	xchg   %ax,%ax
  403ac0:	mov    0x4(%rax),%edx
  403ac3:	mov    (%rax),%ecx
  403ac5:	shl    $0x20,%rdx
  403ac9:	or     %rcx,%rdx
  403acc:	mov    %rdx,%rcx
  403acf:	and    $0xffffff,%edx
  403ad5:	shr    $0x18,%rcx
  403ad9:	lea    0x8(,%rcx,8),%rdi
  403ae1:	lea    0x0(%r13,%rdi,1),%r8
  403ae6:	lea    -0x8(%r13,%rdi,1),%rdi
  403aeb:	cmp    $0x1,%rdx
  403aef:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  403af5:	mov    (%rax),%edx
  403af7:	mov    (%r15),%rdx
  403afa:	mov    (%rdi),%r14
  403afd:	mov    (%r8),%r9
  403b00:	mov    %rdx,(%rax)
  403b03:	mov    0x100(%r15),%rax
  403b0a:	mov    0x3e6c8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403b10:	mov    %rbx,(%r15)
  403b13:	add    $0x1,%rax
  403b17:	mov    %rax,0x100(%r15)
  403b1e:	cmp    %rdx,%rax
  403b21:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  403b27:	mov    %rcx,%rbx
  403b2a:	jmpq   403a06 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
