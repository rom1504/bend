#!/usr/bin/env python3
"""Four compiler images: fresh API/first-request latency, repeated requests, separate diagnostics."""
import argparse, hashlib, json, statistics, subprocess, sys, time
from pathlib import Path
HERE=Path('/home/ai/bend2/build/publish/bend/selfhost/tools/performance/phase60/latency'); ROOT=Path('/home/ai/bend2/build/publish/bend'); PROGRAMS=HERE.parents[1]/'programs'
WORKER=Path('/home/ai/bend2/build/publish/bend/selfhost/build/phase60/method03/worker.mjs')
sys.path.insert(0,str(PROGRAMS))
from support import ExecutionGuard,save
PIN='018751270e800bc222a93dad7f257083ee53a5f7'
p=argparse.ArgumentParser(description=__doc__)
p.add_argument('out',type=Path)
p.add_argument('--bindings',type=Path,default=Path('/home/ai/bend2/build/publish/bend/selfhost/build/phase60/method03/bindings.json'))
p.add_argument('--node',type=Path,default=Path('/home/ai/.nvm/versions/node/v24.18.0/bin/node'))
p.add_argument('--upstream',type=Path,default=ROOT/'selfhost/.bootstrap/upstream-phase23')
p.add_argument('--cases',default='all')
p.add_argument('--catalog',type=Path,default=HERE.parent/'catalog.json')
p.add_argument('--driver-receipt',type=Path,help='Required only for stage mode; adjacent private instrumented driver')
p.add_argument('--roles',default='direct,typescript')
p.add_argument('--rounds',type=int,default=3)
p.add_argument('--warm-requests',type=int,default=3)
p.add_argument('--mode',choices=['clean','cpu','allocation','stages'],default='clean')
p.add_argument('--preparations',type=Path,help='Reuse a completed Phase60 report with matching prepared roles/cases/images')
p.add_argument('--prepare-only',action='store_true',help='Prepare/check outputs and caches; launch no measurement samples')
p.add_argument('--seconds',type=int,default=1800)
p.add_argument('--child-seconds',type=int,default=180)
a=p.parse_args();out=a.out.resolve();assert out.is_relative_to(ROOT/'selfhost/build/phase60') and not out.exists()
assert 1<=a.rounds<=8 and 20<=a.seconds<=7200 and 0<=a.warm_requests<=3 and 10<=a.child_seconds<=600
binding=json.loads(a.bindings.read_text());assert binding['kind']=='phase60-compiler-image-bindings' and binding['version']==1
assert binding['comparison']=='fixed-source' and binding['roles']=={'direct': {'kind': 'direct', 'attempt': {'file': '/home/ai/bend2/build/publish/bend/selfhost/build/phase58/checked-last01/attempt.json', 'sha256': 'e500b277beb16202d1e16aa5f24ebbd6964ca8ba3eaed41e7ff0b988cd266de1', 'bytes': 290955}, 'emission': {'file': '/home/ai/bend2/build/publish/bend/selfhost/build/phase58/final-last01/bootstrap/full/report.json', 'sha256': 'd952025b0cacfa72b56f074b53df0e2a5fa3e8bbd3c844108f335f1704c3a99a', 'bytes': 12796}}}
roles=a.roles.split(',');assert roles and len(set(roles))==len(roles) and all(x.isidentifier() for x in roles) and set(roles)<={'direct','typescript'}
names=a.cases.split(',');assert names and len(set(names))==len(names)
def identity(file):
 file=Path(file).resolve(strict=True);h=hashlib.sha256()
 with file.open('rb') as stream:
  for block in iter(lambda:stream.read(2**20),b''):h.update(block)
 return dict(file=str(file),sha256=h.hexdigest())
def read(file):return json.loads(Path(file).read_text())
def verify(items):
 for item in items:assert identity(item['file'])=={k:item[k] for k in ['file','sha256']},item['file']
upstream=a.upstream.resolve();node=a.node.resolve();catalog=a.catalog.resolve()
assert subprocess.check_output(['git','-C',str(upstream),'rev-parse','HEAD'],text=True).strip()==PIN
subprocess.run(['git','-C',str(upstream),'diff','--exit-code','HEAD','--','bend2'],check=True,stdout=subprocess.DEVNULL)
assert identity(catalog)['sha256']=='d5903c18804afa14b9ca4fc51196d1d419148989a9496e768822f6637004c9ba'
cat=read(catalog);assert cat['kind']=='phase60-compiler-corpus-catalog' and cat['complete'] and cat['pass']
assert cat['upstreamCommit']==PIN and len(cat['compileInputs'])==23 and len(cat['points'])==45
assert len({x['id'] for x in cat['compileInputs']})==23 and len({x['id'] for x in cat['points']})==45
if not a.preparations:verify(cat['inputs'])
all_cases={x['id']:x for x in cat['compileInputs']}
assert set(x['compileInputId'] for x in cat['points'])==set(all_cases)
if names==['all']:names=list(all_cases)
assert set(names)<=set(all_cases)
cases=[all_cases[name] for name in names]
for case in cases:
 assert case['options']=={'mode':'library','backend':'direct'} and case['roots']=='ordinary-library-exports'
 assert set(case['references'])=={'direct','typescript'} and case['pointIds']
 assert set(case['pointIds'])=={x['id'] for x in cat['points'] if x['compileInputId']==case['id']}
 verify([case['source'],*case['files'],*case['emissionInputs'],*case['references'].values()])
assert identity('/home/ai/bend2/build/publish/bend/selfhost/build/phase60/method03/profile.mjs')['sha256']=='5df8aed83fdd2e573a3989ffa4d8ebf1e26d995b0dbabea9031d28e59ead5313'
inputs=[identity(x) for x in [__file__,WORKER,Path('/home/ai/bend2/build/publish/bend/selfhost/build/phase60/method03/setup.mjs'),Path('/home/ai/bend2/build/publish/bend/selfhost/build/phase60/method03/profile.mjs'),
 HERE.parents[1]/'phase54/bootstrap/adapter.mjs',ROOT/'selfhost/tools/development/workflow.mjs',
 ROOT/'selfhost/tools/development/process.mjs',ROOT/'selfhost/tools/conformance/inventory.mjs',
 PROGRAMS/'support.py',PROGRAMS/'profile.mjs',catalog,node,a.bindings,
 *[upstream/'bend2'/n for n in ['bend.ts','comp.ts','base.bend']]]]
case_inputs=[i for x in cases for i in [x['source'],*x['files'],*x['emissionInputs'],*x['references'].values()]]
stage_driver=None
if a.mode=='stages':
 assert a.preparations and a.driver_receipt and not a.prepare_only
 stage_driver=read(a.driver_receipt)
 assert stage_driver['kind']=='phase60-private-driver-stage-derivation' and stage_driver['complete'] and stage_driver['pass'] and stage_driver['exactInverse']
 assert stage_driver['producer']['sha256']=='997f955151abae64ccc35839167393e361229df1cd2438052f6d603d3a901142' and stage_driver['clock']['sha256']=='d606d5c9ef43e3afbc60d60ca31bbb5972daf1831c63aee5d4e058822c2f2c37'
 assert Path(stage_driver['output']['file']).resolve().is_relative_to(ROOT/'selfhost/build/phase60')
 inputs += [identity(a.driver_receipt),stage_driver['source'],stage_driver['output'],stage_driver['producer'],stage_driver['clock'],identity(Path('/home/ai/bend2/build/publish/bend/selfhost/build/phase60/method03/worker-stages.mjs'))]
reuse=None
if a.preparations:
 assert a.preparations.resolve().is_relative_to(ROOT/'selfhost/build/phase60')
 reuse=read(a.preparations);assert reuse['kind']=='phase60-candidate-image-library-latency' and reuse['complete']
 inputs.append(identity(a.preparations));verify([reuse['config']]);old=read(reuse['config']['file'])
 assert old['imageBindings']==identity(a.bindings) and old['upstream']==str(upstream) and old['node']==identity(node)
 for row in cases:assert row in old['cases']
 assert set(roles)<=set(old['roles'])
verify(inputs);out.mkdir(parents=True);assert out.resolve().is_relative_to((ROOT/'selfhost/build/phase60').resolve())
config=dict(kind='phase60-candidate-image-library-plan',roles=roles,rounds=a.rounds,backend='direct',mode=a.mode,
 prepareOnly=a.prepare_only,catalog=identity(catalog),catalogQualificationAuditedHere=not bool(a.preparations),stageDriver=identity(a.driver_receipt) if stage_driver else None,
 imageBindings=identity(a.bindings),node=identity(node),upstream=str(upstream),upstreamCommit=PIN,cases=cases,inputs=inputs,
 warmRequests=a.warm_requests if a.mode=='clean' else 0,comparison=binding['comparison'],profile=dict(targetMs=1,maxRequests=1,samplingIntervalUs=1000,samplingIntervalBytes=131072),
 resources=dict(cpu=3,heapMiB=1024,rssMiB=2048,availableMiB=4096,secondsPerChild=a.child_seconds,totalSeconds=a.seconds),
 protocol='Fresh process per role/case/round. Private Bend Base disk caches primed once outside samples. Explicit ordinary API load then first ordinary library request and the configured later requests; no persistent inspector. TS imports include its compiler. Cyclic role rotation; role count and rounds determine position balance. CPU/allocation are separate fresh diagnostic processes: capture actual compiler import, API load and exactly one first compile; no prior compile or warm request, output validation after stop. Never mix profile times into clean statistics.')
save(out/'plan.json',config);config_id=identity(out/'plan.json')
report=dict(methodDerivation=identity(Path(__file__).with_name('derivation.json')),kind='phase60-candidate-image-library-latency',complete=False,config=config_id,mode=a.mode,
 preparations=[],rows=[],statistics={},failures=[],inputs=inputs,
 coverage=dict(compileInputIds=names,pointIds=[p['id'] for p in cat['points'] if p['compileInputId'] in names],oracleFreshness='inherited-qualified',freshRuntimeExecutions=0))
report['pass']=False;save(out/'report.json',report);started=time.monotonic()
def launch(guard,request,prefix):
 verify(inputs);request_file=Path(str(prefix)+'.request.json');result_file=Path(str(prefix)+'.result.json')
 save(request_file,{**request,'config':config_id})
 flags=[]
 execution=guard.run(['taskset','-c','3',str(node),'--stack-size=4096','--max-old-space-size=1024',*flags,
  str(Path('/home/ai/bend2/build/publish/bend/selfhost/build/phase60/method03/worker-stages.mjs') if a.mode=='stages' and request['stage']=='sample' else WORKER),str(request_file),str(result_file)],Path(str(prefix)+'-process'),min(started+a.seconds,time.monotonic()+a.child_seconds))
 observation=None;observation_error=None
 if result_file.exists():
  try:observation=read(result_file)
  except Exception as error:observation_error=repr(error)
 success=bool(execution['complete'] and execution.get('returncode')==0 and observation and observation.get('complete') and observation.get('pass'))
 entry=dict(execution=execution,observation=observation,result=identity(result_file) if result_file.exists() else None,success=success,request=request,observationError=observation_error)
 if not success:report['failures'].append(dict(stage=request['stage'],role=request['role'],case=request.get('case'),sample=request.get('sample'),process=str(prefix)+'-process',reason=execution.get('stoppedFor') or observation_error or (observation or {}).get('error') or 'worker failure'))
 report['preparations' if request['stage']=='prepare' else 'rows'].append(entry);save(out/'report.json',report)
 if success:assert observation['affinity'].split(':',1)[1].strip()=='3'
 verify(inputs);return entry
try:
 with ExecutionGuard(rss_mib=2048,available_mib=4096) as guard:
  preparations={}
  for role in roles:
   if reuse:
    row=next(x for x in reuse['preparations'] if (x.get('observation') or {}).get('role',x.get('request',{}).get('role'))==role)
    if row.get('result'):verify([row['result']]);assert row['observation']==read(row['result']['file'])
    if not row['success']:report['failures'].append(dict(stage='prepare',role=role,reason='retained preparation failed'))
    report['preparations'].append(row)
   else:
    dest=out/('prepare-'+role);dest.mkdir()
    row=launch(guard,dict(stage='prepare',role=role,out=str(dest)),out/('prepare-'+role))
   preparations[role]=row
  report['preparationsReusedFrom']=identity(a.preparations) if reuse else None
  report['qualifiedRawOutputReferences']=[dict(case=case['id'],pointIds=case['pointIds'],references=case['references']) for case in cases]
  report['preparationSeconds']=time.monotonic()-started;timing_start=time.monotonic()
  for case in ([] if a.prepare_only else cases):
   for sample in range(a.rounds):
    offset=sample%len(roles);order=roles[offset:]+roles[:offset]
    for role in order:
     prefix=out/(case['id']+'-'+str(sample)+'-'+role)
     reason=('preparation-failed' if not preparations[role]['success'] else
       'signal' if guard.interrupted else 'campaign-deadline' if time.monotonic()>=started+a.seconds else None)
     if reason:
      row=dict(success=False,skipped=True,reason=reason,execution=None,observation=None,result=None)
      report['rows'].append(row);report['failures'].append(dict(stage='sample',role=role,case=case['id'],sample=sample,reason=reason))
     else:
      row=launch(guard,dict(stage='sample',role=role,case=case['id'],sample=sample,
       preparation=preparations[role]['result'],output=str(prefix)+'.mjs',profileOut=str(prefix)+'-profile'),prefix)
     row.update(case=case['id'],sample=sample,role=role);save(out/'report.json',report)
  report['measurementStageSeconds']=time.monotonic()-timing_start
  def stats(xs):return dict(median=statistics.median(xs),min=min(xs),max=max(xs),samples=xs)
  if a.mode=='clean' and not a.prepare_only:
   for case in cases:
    report['statistics'][case['id']]={}
    for role in roles:
     rows=[x for x in report['rows'] if x['case']==case['id'] and x['role']==role and x['success']]
     if len(rows)!=a.rounds:
      report['statistics'][case['id']][role]=dict(complete=False,expectedSamples=a.rounds,successfulSamples=len(rows));continue
     values={k:stats([r['observation'][k] for r in rows]) for k in ['firstRequestMs','hostImportMs','apiLoadMs','importApiAndFirstMs','maxRssKiB']}
     warm=[[x['requestMs'] for x in r['observation']['warmRequests']] for r in rows];assert all(len(x)==a.warm_requests for x in warm)
     values.update(warmRequestMedianMs=stats([statistics.median(x) for x in warm]) if a.warm_requests else None,warmRequestMsByProcess=warm,
       processWallMs=stats([r['execution']['wallSeconds']*1000 for r in rows]),
       peakTreeRssBytes=stats([r['execution']['peakTreeRssBytes'] for r in rows]),
       outputBytes=stats([r['observation']['output']['bytes'] for r in rows]))
     report['statistics'][case['id']][role]=values
  assert len(report['rows'])==(0 if a.prepare_only else len(cases)*len(roles)*a.rounds)
  verify(inputs);verify(case_inputs)
  if not a.preparations:verify(cat['inputs'])
  report['complete']=True;report['pass']=not report['failures']
  report['successfulWorkers']=sum(x['success'] for x in report['rows']);report['expectedWorkers']=0 if a.prepare_only else len(cases)*len(roles)*a.rounds
except BaseException as error:
 report['error']=repr(error);raise
finally:
 report['wallSeconds']=time.monotonic()-started;save(out/'report.json',report)
print(json.dumps(dict(pass_=report['pass'],rows=len(report['rows']),failed=len(report['failures']),mode=a.mode,report=str(out/'report.json'))))
if not report['pass']:raise SystemExit(1)
