
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004040d0 <nx_rt_pair_rebuild2_c3_k0>:
  4040d0:	push   %r15
  4040d2:	push   %r14
  4040d4:	push   %r13
  4040d6:	push   %r12
  4040d8:	mov    %rdx,%r12
  4040db:	push   %rbp
  4040dc:	push   %rbx
  4040dd:	movabs $0xffffffffff,%rbx
  4040e7:	and    %rsi,%rbx
  4040ea:	lea    0x0(,%rbx,8),%rdx
  4040f2:	sub    $0x18,%rsp
  4040f6:	mov    (%rdi),%rbp
  4040f9:	mov    0x8(%rdi),%r15
  4040fd:	lea    0x0(%rbp,%rdx,1),%rax
  404102:	test   %rsi,%rsi
  404105:	js     4041c0 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  40410b:	mov    (%rax),%r14
  40410e:	mov    0x8(%rbp,%rdx,1),%r13
  404113:	cmp    $0x310817f,%rbx
  40411a:	jbe    404190 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  40411c:	lea    0x0(%rbp,%rbx,8),%r8
  404121:	mov    %r14,%rax
  404124:	shr    $0x38,%rax
  404128:	and    $0x7f,%eax
  40412b:	cmp    $0x2,%rax
  40412f:	je     404170 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  404131:	mov    %r12,%rax
  404134:	mov    %r14,(%r8)
  404137:	lea    0x8(%rbp,%rbx,8),%r14
  40413c:	shr    $0x38,%rax
  404140:	and    $0x7f,%eax
  404143:	cmp    $0x2,%rax
  404147:	je     404180 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  404149:	movabs $0x200030000000000,%rax
  404153:	mov    %r12,(%r14)
  404156:	mov    %r13,%rdx
  404159:	add    $0x18,%rsp
  40415d:	or     %rbx,%rax
  404160:	pop    %rbx
  404161:	pop    %rbp
  404162:	pop    %r12
  404164:	pop    %r13
  404166:	pop    %r14
  404168:	pop    %r15
  40416a:	retq   
  40416b:	nopl   0x0(%rax,%rax,1)
  404170:	test   %r14,%r14
  404173:	js     404131 <nx_rt_pair_rebuild2_c3_k0+0x61>
  404175:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  40417a:	nopw   0x0(%rax,%rax,1)
  404180:	test   %r12,%r12
  404183:	js     404149 <nx_rt_pair_rebuild2_c3_k0+0x79>
  404185:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  40418a:	nopw   0x0(%rax,%rax,1)
  404190:	mov    0x8(%r15),%rbx
  404194:	test   %rbx,%rbx
  404197:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  40419d:	lea    0x0(%rbp,%rbx,8),%r8
  4041a2:	mov    (%r8),%rax
  4041a5:	subq   $0x2,0x108(%r15)
  4041ad:	mov    %rax,0x8(%r15)
  4041b1:	jmpq   404121 <nx_rt_pair_rebuild2_c3_k0+0x51>
  4041b6:	nopw   %cs:0x0(%rax,%rax,1)
  4041c0:	mov    0x4(%rax),%edx
  4041c3:	mov    (%rax),%ecx
  4041c5:	shl    $0x20,%rdx
  4041c9:	or     %rcx,%rdx
  4041cc:	mov    %rdx,%rcx
  4041cf:	and    $0xffffff,%edx
  4041d5:	shr    $0x18,%rcx
  4041d9:	lea    0x8(,%rcx,8),%rdi
  4041e1:	lea    0x0(%rbp,%rdi,1),%r8
  4041e6:	lea    -0x8(%rbp,%rdi,1),%rdi
  4041eb:	cmp    $0x1,%rdx
  4041ef:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  4041f5:	mov    (%rax),%edx
  4041f7:	mov    (%r15),%rdx
  4041fa:	mov    (%rdi),%r14
  4041fd:	mov    (%r8),%r13
  404200:	mov    %rdx,(%rax)
  404203:	mov    0x100(%r15),%rax
  40420a:	mov    0x3dfc8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404210:	mov    %rbx,(%r15)
  404213:	add    $0x1,%rax
  404217:	mov    %rax,0x100(%r15)
  40421e:	cmp    %rdx,%rax
  404221:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  404227:	mov    %rcx,%rbx
  40422a:	jmpq   404113 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
