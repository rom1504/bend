  408e87:	push   %rbp
  408e88:	mov    %rsp,%rbp
  408e8b:	sub    $0x930,%rsp
  408e92:	mov    %r12,-0x10(%rbp)
  408e96:	mov    %rbx,-0x8(%rbp)
  408e9a:	mov    %r13,-0x18(%rbp)
  408e9e:	mov    %rdi,%rax
  408ea1:	mov    %rax,%r12
  408ea4:	mov    %rsi,%rax
  408ea7:	mov    %rax,%rdi
  408eaa:	mov    %rdx,%rax
  408ead:	mov    %rax,%rsi
  408eb0:	lea    -0x840(%rbp),%r10
  408eb7:	mov    %rdi,%r11
  408eba:	mov    %r11,(%r10)
  408ebd:	lea    -0x840(%rbp),%r10
  408ec4:	mov    %rsi,%r11
  408ec7:	mov    %r11,0x8(%r10)
  408ecb:	mov    %r12,%rdi
  408ece:	movabs $0xa4,%rsi
  408ed8:	mov    %esi,%esi
  408eda:	lea    -0x840(%rbp),%rdx
  408ee1:	xor    %eax,%eax
  408ee3:	callq  41b230 <p125_rt_ctor2>
  408ee8:	mov    %rax,%rdi
  408eeb:	mov    %r12,%r10
  408eee:	mov    %r10,0x10(%rsp)
  408ef3:	mov    %rdi,%r10
  408ef6:	mov    %r10,0x18(%rsp)
  408efb:	mov    0x10(%rsp),%rdi
  408f00:	mov    0x18(%rsp),%rsi
  408f05:	xor    %eax,%eax
  408f07:	callq  4154f0 <p111_rt_keep>
  408f0c:	mov    %rax,%rbx
  408f0f:	mov    %r12,%rdi
  408f12:	mov    %rbx,%rsi
  408f15:	xor    %eax,%eax
  408f17:	callq  4088bf <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_108_101_102_116_>
  408f1c:	mov    %rax,%r13
  408f1f:	mov    %r12,%rdi
  408f22:	mov    %rbx,%rsi
  408f25:	xor    %eax,%eax
  408f27:	callq  40852b <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_114_105_103_104_116_>
  408f2c:	mov    %rax,%rdi
  408f2f:	mov    %r13d,%r13d
  408f32:	mov    %edi,%edi
  408f34:	mov    %rdi,%r11
  408f37:	mov    %r13,%rdi
  408f3a:	add    %r11d,%edi
  408f3d:	mov    %rdi,%rax
  408f40:	mov    -0x10(%rbp),%r12
  408f44:	mov    -0x8(%rbp),%rbx
  408f48:	mov    -0x18(%rbp),%r13
  408f4c:	mov    %rbp,%rsp
  408f4f:	pop    %rbp
  408f50:	retq   
