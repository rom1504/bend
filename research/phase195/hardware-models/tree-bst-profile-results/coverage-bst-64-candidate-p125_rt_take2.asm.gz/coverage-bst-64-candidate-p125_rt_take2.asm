000000000041dbc0 <p125_rt_take2>:
  41dbc0:	push   r12
  41dbc2:	mov    rax,rdx
  41dbc5:	mov    rdx,rsi
  41dbc8:	push   rbx
  41dbc9:	shr    rdx,0x28
  41dbcd:	movzx  edx,dx
  41dbd0:	sub    rsp,0x8
  41dbd4:	mov    rcx,QWORD PTR [rip+0x108ef5]        # 526ad0 <p111_program_active>
  41dbdb:	cmp    QWORD PTR [rcx+0x18],rdx
  41dbdf:	ja     41dbf0 <p125_rt_take2+0x30>
  41dbe1:	lea    rdi,[rip+0x177b]        # 41f363 <_IO_stdin_used+0x363>
  41dbe8:	call   413ef0 <err_fail>
  41dbed:	nop    DWORD PTR [rax]
  41dbf0:	mov    rbx,rdi
  41dbf3:	mov    rdi,QWORD PTR [rcx+0x80]
  41dbfa:	cmp    BYTE PTR [rdi+rdx*1],0x2
  41dbfe:	jne    41dbe1 <p125_rt_take2+0x21>
  41dc00:	mov    rdx,rsi
  41dc03:	shr    rdx,0x38
  41dc07:	and    edx,0x7f
  41dc0a:	cmp    rdx,0x2
  41dc0e:	jne    41dd3b <p125_rt_take2+0x17b>
  41dc14:	movabs rdx,0xffffffffff
  41dc1e:	mov    rdi,QWORD PTR [rbx]
  41dc21:	and    rdx,rsi
  41dc24:	lea    r9,[rdx*8+0x0]
  41dc2c:	lea    r8,[rdi+r9*1]
  41dc30:	test   rsi,rsi
  41dc33:	js     41dcb8 <p125_rt_take2+0xf8>
  41dc39:	mov    rsi,QWORD PTR [r8]
  41dc3c:	mov    QWORD PTR [rax],rsi
  41dc3f:	mov    rsi,QWORD PTR [rdi+r9*1+0x8]
  41dc44:	mov    QWORD PTR [rax+0x8],rsi
  41dc48:	mov    rax,QWORD PTR [rcx+0x40]
  41dc4c:	add    rax,0x7f
  41dc50:	and    rax,0xffffffffffffff80
  41dc54:	add    rax,0x3108200
  41dc5a:	cmp    rax,rdx
  41dc5d:	jbe    41dc70 <p125_rt_take2+0xb0>
  41dc5f:	add    rsp,0x8
  41dc63:	mov    eax,0x2
  41dc68:	pop    rbx
  41dc69:	pop    r12
  41dc6b:	ret    
  41dc6c:	nop    DWORD PTR [rax+0x0]
  41dc70:	mov    rsi,QWORD PTR [rbx+0x8]
  41dc74:	mov    rdi,QWORD PTR [rbx]
  41dc77:	mov    rax,QWORD PTR [rsi+0x8]
  41dc7b:	mov    QWORD PTR [rdi+rdx*8],rax
  41dc7f:	mov    rax,QWORD PTR [rsi+0x108]
  41dc86:	mov    QWORD PTR [rsi+0x8],rdx
  41dc8a:	mov    edx,DWORD PTR [rip+0x108ef4]        # 526b84 <KEEP_WORDS>
  41dc90:	add    rax,0x2
  41dc94:	mov    QWORD PTR [rsi+0x108],rax
  41dc9b:	cmp    rax,rdx
  41dc9e:	jae    405067 <p125_rt_take2.cold+0x2f>
  41dca4:	add    rsp,0x8
  41dca8:	mov    eax,0x2
  41dcad:	pop    rbx
  41dcae:	pop    r12
  41dcb0:	ret    
  41dcb1:	nop    DWORD PTR [rax+0x0]
  41dcb8:	mov    r9,QWORD PTR [rbx+0x8]
  41dcbc:	mov    ecx,DWORD PTR [r8+0x4]
  41dcc0:	mov    r10d,DWORD PTR [r8]
  41dcc3:	shl    rcx,0x20
  41dcc7:	or     rcx,r10
  41dcca:	mov    r12,rcx
  41dccd:	and    ecx,0xffffff
  41dcd3:	shr    r12,0x18
  41dcd7:	lea    r10,[r12*8+0x0]
  41dcdf:	lea    r11,[rdi+r10*1]
  41dce3:	lea    r10,[r10+rdi*1+0x8]
  41dce8:	cmp    rcx,0x1
  41dcec:	jne    405038 <p125_rt_take2.cold>
  41dcf2:	mov    ecx,DWORD PTR [r8]
  41dcf5:	mov    rcx,QWORD PTR [r11]
  41dcf8:	mov    QWORD PTR [rax],rcx
  41dcfb:	mov    rcx,QWORD PTR [r10]
  41dcfe:	mov    QWORD PTR [rax+0x8],rcx
  41dd02:	mov    rax,QWORD PTR [r9]
  41dd05:	mov    QWORD PTR [r8],rax
  41dd08:	mov    rax,QWORD PTR [r9+0x100]
  41dd0f:	mov    QWORD PTR [r9],rdx
  41dd12:	mov    edx,DWORD PTR [rip+0x108e6c]        # 526b84 <KEEP_WORDS>
  41dd18:	add    rax,0x1
  41dd1c:	mov    QWORD PTR [r9+0x100],rax
  41dd23:	cmp    rax,rdx
  41dd26:	jae    405076 <p125_rt_take2.cold+0x3e>
  41dd2c:	mov    rcx,QWORD PTR [rip+0x108d9d]        # 526ad0 <p111_program_active>
  41dd33:	mov    rdx,r12
  41dd36:	jmp    41dc48 <p125_rt_take2+0x88>
  41dd3b:	lea    rdi,[rip+0x21de]        # 41ff20 <_IO_stdin_used+0xf20>
  41dd42:	call   413ef0 <err_fail>
  41dd47:	nop    WORD PTR [rax+rax*1+0x0]

