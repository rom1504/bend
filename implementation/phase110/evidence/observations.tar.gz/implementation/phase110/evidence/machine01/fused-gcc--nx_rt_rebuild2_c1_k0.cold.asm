
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004016c4 <nx_rt_rebuild2_c1_k0.cold>:
  4016c4:	mov    $0x1,%edx
  4016c9:	mov    %r8,0x18(%rsp)
  4016ce:	mov    %rdi,0x10(%rsp)
  4016d3:	mov    %rsi,0x8(%rsp)
  4016d8:	callq  401178 <heap_alloc_miss>
  4016dd:	mov    0x8(%rsp),%rsi
  4016e2:	mov    0x10(%rsp),%rdi
  4016e7:	mov    0x18(%rsp),%r8
  4016ec:	mov    %rax,%r9
  4016ef:	jmpq   4033a9 <nx_rt_rebuild2_c1_k0+0x49>
  4016f4:	xor    %edx,%edx
  4016f6:	mov    %r8,0x8(%rsp)
  4016fb:	callq  401100 <heap_hand>
  401700:	mov    0x8(%rsp),%r8
  401705:	jmpq   403466 <nx_rt_rebuild2_c1_k0+0x106>
  40170a:	mov    %r13,%rcx
  40170d:	mov    %r10,%rdx
  401710:	mov    %r8,0x18(%rsp)
  401715:	mov    0x0(%rbp),%r12
  401719:	mov    %rdi,0x10(%rsp)
  40171e:	mov    (%r11),%rbp
  401721:	mov    %rsi,0x8(%rsp)
  401726:	callq  4014c6 <span_fade.constprop.0>
  40172b:	mov    0x8(%rsp),%rsi
  401730:	mov    0x10(%rsp),%rdi
  401735:	mov    0x18(%rsp),%r8
  40173a:	jmpq   4033d8 <nx_rt_rebuild2_c1_k0+0x78>

Disassembly of section .fini:
