
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401cc0 <nx_construct2>:
  401cc0:	push   %r12
  401cc2:	mov    %rcx,%rax
  401cc5:	push   %rbp
  401cc6:	shr    $0x38,%rax
  401cca:	lea    0x0(,%r9,8),%rbp
  401cd2:	push   %rbx
  401cd3:	and    $0x7f,%eax
  401cd6:	mov    %edx,%ebx
  401cd8:	lea    (%rdi,%rbp,1),%r12
  401cdc:	mov    %rcx,%rdx
  401cdf:	sub    $0x20,%rsp
  401ce3:	cmp    $0x2,%rax
  401ce7:	je     401d20 <nx_construct2+0x60>
  401ce9:	mov    %r8,%rax
  401cec:	mov    %rdx,(%r12)
  401cf0:	lea    0x8(%rbp,%rdi,1),%rbp
  401cf5:	shr    $0x38,%rax
  401cf9:	and    $0x7f,%eax
  401cfc:	cmp    $0x2,%rax
  401d00:	je     401d30 <nx_construct2+0x70>
  401d02:	mov    %rbx,%rax
  401d05:	mov    %r8,0x0(%rbp)
  401d09:	add    $0x20,%rsp
  401d0d:	shl    $0x28,%rax
  401d11:	pop    %rbx
  401d12:	pop    %rbp
  401d13:	or     %r9,%rax
  401d16:	pop    %r12
  401d18:	bts    $0x39,%rax
  401d1d:	retq   
  401d1e:	xchg   %ax,%ax
  401d20:	test   %rcx,%rcx
  401d23:	js     401ce9 <nx_construct2+0x29>
  401d25:	jmpq   401410 <nx_construct2.cold>
  401d2a:	nopw   0x0(%rax,%rax,1)
  401d30:	test   %r8,%r8
  401d33:	js     401d02 <nx_construct2+0x42>
  401d35:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
