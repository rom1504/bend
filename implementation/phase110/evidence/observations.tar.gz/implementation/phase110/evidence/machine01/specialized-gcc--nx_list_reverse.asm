
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	push   %r12
  401c02:	mov    %rsi,%rax
  401c05:	mov    %rdx,%r12
  401c08:	push   %rbp
  401c09:	shr    $0x28,%rax
  401c0d:	sub    $0x8,%rsp
  401c11:	and    $0xffff,%eax
  401c16:	je     401c54 <nx_list_reverse+0x54>
  401c18:	mov    %rdi,%rbp
  401c1b:	cmp    $0x1,%rax
  401c1f:	je     401c2e <nx_list_reverse+0x2e>
  401c21:	jmp    401c60 <nx_list_reverse+0x60>
  401c23:	nopl   0x0(%rax,%rax,1)
  401c28:	cmp    $0x1,%rax
  401c2c:	jne    401c60 <nx_list_reverse+0x60>
  401c2e:	mov    %r12,%rdx
  401c31:	mov    %rbp,%rdi
  401c34:	callq  403380 <nx_rt_rebuild2_c1_k0>
  401c39:	xor    %esi,%esi
  401c3b:	mov    %rbp,%rdi
  401c3e:	mov    %rax,%r12
  401c41:	callq  402d10 <nx_rt_fast_field>
  401c46:	mov    %rax,%rsi
  401c49:	shr    $0x28,%rax
  401c4d:	and    $0xffff,%eax
  401c52:	jne    401c28 <nx_list_reverse+0x28>
  401c54:	add    $0x8,%rsp
  401c58:	mov    %r12,%rax
  401c5b:	pop    %rbp
  401c5c:	pop    %r12
  401c5e:	retq   
  401c5f:	nop
  401c60:	add    $0x8,%rsp
  401c64:	mov    %rbp,%rdi
  401c67:	mov    $0x1,%esi
  401c6c:	pop    %rbp
  401c6d:	pop    %r12
  401c6f:	jmpq   402560 <nx_rt_fail>

Disassembly of section .fini:
