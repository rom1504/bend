000000000040922e <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_>:
  40922e:	push   rbp
  40922f:	mov    rbp,rsp
  409232:	sub    rsp,0x960
  409239:	mov    QWORD PTR [rbp-0x10],r12
  40923d:	mov    QWORD PTR [rbp-0x8],rbx
  409241:	mov    QWORD PTR [rbp-0x18],r13
  409245:	mov    QWORD PTR [rbp-0x20],r14
  409249:	mov    rax,rdi
  40924c:	mov    r12,rax
  40924f:	mov    rax,rsi
  409252:	mov    rsi,rax
  409255:	mov    rax,rdx
  409258:	mov    rbx,rax
  40925b:	mov    rdi,rsi
  40925e:	shr    rdi,0x28
  409262:	and    rdi,0xffff
  409269:	movabs r11,0x11
  409273:	cmp    rdi,r11
  409276:	sete   dil
  40927a:	movzx  edi,dil
  40927e:	mov    r10,rdi
  409281:	test   r10d,r10d
  409284:	je     4092a2 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x74>
  40928a:	mov    rax,rbx
  40928d:	mov    r12,QWORD PTR [rbp-0x10]
  409291:	mov    rbx,QWORD PTR [rbp-0x8]
  409295:	mov    r13,QWORD PTR [rbp-0x18]
  409299:	mov    r14,QWORD PTR [rbp-0x20]
  40929d:	mov    rsp,rbp
  4092a0:	pop    rbp
  4092a1:	ret    
  4092a2:	mov    rdi,rsi
  4092a5:	shr    rdi,0x28
  4092a9:	and    rdi,0xffff
  4092b0:	movabs r11,0x12
  4092ba:	cmp    rdi,r11
  4092bd:	sete   dil
  4092c1:	movzx  edi,dil
  4092c5:	mov    r10,rdi
  4092c8:	test   r10d,r10d
  4092cb:	je     409585 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x357>
  4092d1:	mov    r10,r12
  4092d4:	mov    QWORD PTR [rsp+0x18],r10
  4092d9:	mov    r10,rsi
  4092dc:	mov    QWORD PTR [rsp+0x20],r10
  4092e1:	lea    r10,[rbp-0x840]
  4092e8:	mov    QWORD PTR [rsp+0x28],r10
  4092ed:	mov    rdi,QWORD PTR [rsp+0x18]
  4092f2:	mov    rsi,QWORD PTR [rsp+0x20]
  4092f7:	mov    rdx,QWORD PTR [rsp+0x28]
  4092fc:	xor    eax,eax
  4092fe:	call   41dbc0 <p125_rt_take2>
  409303:	mov    QWORD PTR [rbp-0x8b0],rax
  40930a:	lea    r10,[rbp-0x840]
  409311:	mov    rsi,QWORD PTR [r10]
  409314:	lea    r10,[rbp-0x840]
  40931b:	mov    r14,QWORD PTR [r10+0x8]
  40931f:	mov    rdi,rsi
  409322:	shr    rdi,0x28
  409326:	and    rdi,0xffff
  40932d:	movabs r11,0xa6
  409337:	cmp    rdi,r11
  40933a:	sete   dil
  40933e:	movzx  edi,dil
  409342:	mov    r10,rdi
  409345:	test   r10d,r10d
  409348:	je     409549 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x31b>
  40934e:	mov    r10,r12
  409351:	mov    QWORD PTR [rsp+0x18],r10
  409356:	mov    r10,rsi
  409359:	mov    QWORD PTR [rsp+0x20],r10
  40935e:	lea    r10,[rbp-0x840]
  409365:	mov    QWORD PTR [rsp+0x28],r10
  40936a:	mov    rdi,QWORD PTR [rsp+0x18]
  40936f:	mov    rsi,QWORD PTR [rsp+0x20]
  409374:	mov    rdx,QWORD PTR [rsp+0x28]
  409379:	xor    eax,eax
  40937b:	call   41de20 <p125_rt_take3>
  409380:	mov    QWORD PTR [rbp-0x8b0],rax
  409387:	lea    r10,[rbp-0x840]
  40938e:	mov    r13,QWORD PTR [r10]
  409391:	lea    r10,[rbp-0x840]
  409398:	mov    rdx,QWORD PTR [r10+0x8]
  40939c:	lea    r10,[rbp-0x840]
  4093a3:	mov    rsi,QWORD PTR [r10+0x10]
  4093a7:	mov    r9,rsi
  4093aa:	cmp    r9,0x1
  4093b1:	sete   r9b
  4093b5:	movzx  r9d,r9b
  4093b9:	mov    rdi,rsi
  4093bc:	shr    rdi,0x28
  4093c0:	and    rdi,0x7fffff
  4093c7:	movabs r8,0x2
  4093d1:	or     r8,0x10000
  4093d8:	cmp    rdi,r8
  4093db:	sete   dil
  4093df:	movzx  edi,dil
  4093e3:	or     edi,r9d
  4093e6:	mov    r10,rdi
  4093e9:	test   r10d,r10d
  4093ec:	je     409443 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x215>
  4093f2:	lea    r10,[rbp-0x840]
  4093f9:	mov    r11,rbx
  4093fc:	mov    QWORD PTR [r10],r11
  4093ff:	lea    r10,[rbp-0x840]
  409406:	mov    r11,r13
  409409:	mov    QWORD PTR [r10+0x8],r11
  40940d:	lea    r10,[rbp-0x840]
  409414:	mov    r11,rdx
  409417:	mov    QWORD PTR [r10+0x10],r11
  40941b:	mov    rdi,r12
  40941e:	movabs rsi,0xa5
  409428:	mov    esi,esi
  40942a:	lea    rdx,[rbp-0x840]
  409431:	xor    eax,eax
  409433:	call   41dd50 <p125_rt_ctor3>
  409438:	mov    rbx,rax
  40943b:	mov    rsi,r14
  40943e:	jmp    40925b <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2d>
  409443:	mov    r9,rsi
  409446:	cmp    r9,0x1
  40944d:	sete   r9b
  409451:	movzx  r9d,r9b
  409455:	mov    rdi,rsi
  409458:	shr    rdi,0x28
  40945c:	and    rdi,0x7fffff
  409463:	movabs r8,0x2
  40946d:	or     r8,0x10000
  409474:	cmp    rdi,r8
  409477:	sete   dil
  40947b:	movzx  edi,dil
  40947f:	or     edi,r9d
  409482:	xor    edi,0x1
  409488:	mov    r10,rdi
  40948b:	test   r10d,r10d
  40948e:	je     4094e5 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2b7>
  409494:	lea    r10,[rbp-0x840]
  40949b:	mov    r11,rdx
  40949e:	mov    QWORD PTR [r10],r11
  4094a1:	lea    r10,[rbp-0x840]
  4094a8:	mov    r11,r13
  4094ab:	mov    QWORD PTR [r10+0x8],r11
  4094af:	lea    r10,[rbp-0x840]
  4094b6:	mov    r11,rbx
  4094b9:	mov    QWORD PTR [r10+0x10],r11
  4094bd:	mov    rdi,r12
  4094c0:	movabs rsi,0xa5
  4094ca:	mov    esi,esi
  4094cc:	lea    rdx,[rbp-0x840]
  4094d3:	xor    eax,eax
  4094d5:	call   41dd50 <p125_rt_ctor3>
  4094da:	mov    rbx,rax
  4094dd:	mov    rsi,r14
  4094e0:	jmp    40925b <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2d>
  4094e5:	mov    r10,r12
  4094e8:	mov    QWORD PTR [rsp+0x10],r10
  4094ed:	mov    r10,rdx
  4094f0:	mov    QWORD PTR [rsp+0x18],r10
  4094f5:	mov    rdi,QWORD PTR [rsp+0x10]
  4094fa:	mov    rsi,QWORD PTR [rsp+0x18]
  4094ff:	xor    eax,eax
  409501:	call   417e20 <p111_rt_sink>
  409506:	mov    QWORD PTR [rbp-0x8b0],rax
  40950d:	mov    rdi,r12
  409510:	movabs rsi,0x4
  40951a:	mov    esi,esi
  40951c:	xor    eax,eax
  40951e:	call   4185b0 <p111_rt_fail>
  409523:	mov    QWORD PTR [rbp-0x8b0],rax
  40952a:	movabs rax,0x0
  409534:	mov    r12,QWORD PTR [rbp-0x10]
  409538:	mov    rbx,QWORD PTR [rbp-0x8]
  40953c:	mov    r13,QWORD PTR [rbp-0x18]
  409540:	mov    r14,QWORD PTR [rbp-0x20]
  409544:	mov    rsp,rbp
  409547:	pop    rbp
  409548:	ret    
  409549:	mov    rdi,r12
  40954c:	movabs rsi,0x4
  409556:	mov    esi,esi
  409558:	xor    eax,eax
  40955a:	call   4185b0 <p111_rt_fail>
  40955f:	mov    QWORD PTR [rbp-0x8b0],rax
  409566:	movabs rax,0x0
  409570:	mov    r12,QWORD PTR [rbp-0x10]
  409574:	mov    rbx,QWORD PTR [rbp-0x8]
  409578:	mov    r13,QWORD PTR [rbp-0x18]
  40957c:	mov    r14,QWORD PTR [rbp-0x20]
  409580:	mov    rsp,rbp
  409583:	pop    rbp
  409584:	ret    
  409585:	mov    rdi,r12
  409588:	movabs rsi,0x4
  409592:	mov    esi,esi
  409594:	xor    eax,eax
  409596:	call   4185b0 <p111_rt_fail>
  40959b:	mov    QWORD PTR [rbp-0x8b0],rax
  4095a2:	movabs rax,0x0
  4095ac:	mov    r12,QWORD PTR [rbp-0x10]
  4095b0:	mov    rbx,QWORD PTR [rbp-0x8]
  4095b4:	mov    r13,QWORD PTR [rbp-0x18]
  4095b8:	mov    r14,QWORD PTR [rbp-0x20]
  4095bc:	mov    rsp,rbp
  4095bf:	pop    rbp
  4095c0:	ret    

