
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403370 <nx_rt_rebuild2>:
  403370:	push   %r15
  403372:	push   %r14
  403374:	push   %r13
  403376:	mov    %ecx,%r13d
  403379:	push   %r12
  40337b:	mov    %rdi,%r12
  40337e:	push   %rbp
  40337f:	movabs $0xffffffffff,%rbp
  403389:	push   %rbx
  40338a:	and    %rsi,%rbp
  40338d:	mov    %edx,%ebx
  40338f:	lea    0x0(,%rbp,8),%rdx
  403397:	sub    $0x28,%rsp
  40339b:	mov    (%rdi),%r14
  40339e:	mov    0x8(%rdi),%r15
  4033a2:	lea    (%r14,%rdx,1),%rax
  4033a6:	test   %rsi,%rsi
  4033a9:	js     403490 <nx_rt_rebuild2+0x120>
  4033af:	mov    (%rax),%rax
  4033b2:	mov    %rax,0x10(%rsp)
  4033b7:	mov    0x8(%r14,%rdx,1),%rax
  4033bc:	mov    %rax,0x18(%rsp)
  4033c1:	cmp    $0x310817f,%rbp
  4033c8:	jbe    403468 <nx_rt_rebuild2+0xf8>
  4033ce:	lea    (%r14,%rbp,8),%r9
  4033d2:	mov    $0x1,%eax
  4033d7:	mov    0x10(%rsp,%r13,8),%rdx
  4033dc:	movq   $0xffffffffffffffff,0x18(%r12)
  4033e5:	movl   $0x1,0x20(%r12)
  4033ee:	sub    %r13d,%eax
  4033f1:	mov    0x10(%rsp,%rax,8),%rax
  4033f6:	mov    %rax,0x10(%r12)
  4033fb:	mov    %rdx,%rax
  4033fe:	shr    $0x38,%rax
  403402:	and    $0x7f,%eax
  403405:	cmp    $0x2,%rax
  403409:	je     403448 <nx_rt_rebuild2+0xd8>
  40340b:	mov    %r8,%rax
  40340e:	mov    %rdx,(%r9)
  403411:	lea    0x8(%r14,%rbp,8),%r12
  403416:	shr    $0x38,%rax
  40341a:	and    $0x7f,%eax
  40341d:	cmp    $0x2,%rax
  403421:	je     403458 <nx_rt_rebuild2+0xe8>
  403423:	mov    %rbx,%rax
  403426:	mov    %r8,(%r12)
  40342a:	add    $0x28,%rsp
  40342e:	shl    $0x28,%rax
  403432:	pop    %rbx
  403433:	or     %rbp,%rax
  403436:	pop    %rbp
  403437:	pop    %r12
  403439:	bts    $0x39,%rax
  40343e:	pop    %r13
  403440:	pop    %r14
  403442:	pop    %r15
  403444:	retq   
  403445:	nopl   (%rax)
  403448:	test   %rdx,%rdx
  40344b:	js     40340b <nx_rt_rebuild2+0x9b>
  40344d:	jmpq   401640 <nx_rt_rebuild2.cold>
  403452:	nopw   0x0(%rax,%rax,1)
  403458:	test   %r8,%r8
  40345b:	js     403423 <nx_rt_rebuild2+0xb3>
  40345d:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  403462:	nopw   0x0(%rax,%rax,1)
  403468:	mov    0x8(%r15),%rbp
  40346c:	test   %rbp,%rbp
  40346f:	je     401685 <nx_rt_rebuild2.cold+0x45>
  403475:	lea    (%r14,%rbp,8),%r9
  403479:	mov    (%r9),%rax
  40347c:	subq   $0x2,0x108(%r15)
  403484:	mov    %rax,0x8(%r15)
  403488:	jmpq   4033d2 <nx_rt_rebuild2+0x62>
  40348d:	nopl   (%rax)
  403490:	mov    0x4(%rax),%edx
  403493:	mov    (%rax),%ecx
  403495:	shl    $0x20,%rdx
  403499:	or     %rcx,%rdx
  40349c:	mov    %rdx,%rcx
  40349f:	and    $0xffffff,%edx
  4034a5:	shr    $0x18,%rcx
  4034a9:	lea    0x0(,%rcx,8),%rdi
  4034b1:	lea    (%r14,%rdi,1),%r9
  4034b5:	lea    0x8(%r14,%rdi,1),%rdi
  4034ba:	cmp    $0x1,%rdx
  4034be:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  4034c4:	mov    (%rax),%edx
  4034c6:	mov    (%r9),%rdx
  4034c9:	mov    %rdx,0x10(%rsp)
  4034ce:	mov    (%rdi),%rdx
  4034d1:	mov    %rdx,0x18(%rsp)
  4034d6:	mov    (%r15),%rdx
  4034d9:	mov    %rdx,(%rax)
  4034dc:	mov    0x100(%r15),%rax
  4034e3:	mov    0x3ecef(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4034e9:	mov    %rbp,(%r15)
  4034ec:	add    $0x1,%rax
  4034f0:	mov    %rax,0x100(%r15)
  4034f7:	cmp    %rdx,%rax
  4034fa:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  403500:	mov    %rcx,%rbp
  403503:	jmpq   4033c1 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
