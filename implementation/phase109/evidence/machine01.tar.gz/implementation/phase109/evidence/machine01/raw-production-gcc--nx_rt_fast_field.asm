
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ad0 <nx_rt_fast_field>:
  402ad0:	mov    %esi,%ecx
  402ad2:	mov    $0xfffffffe,%eax
  402ad7:	rol    %cl,%eax
  402ad9:	add    $0x2,%rcx
  402add:	and    %eax,0x20(%rdi)
  402ae0:	mov    (%rdi,%rcx,8),%rax
  402ae4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402aec:	retq   

Disassembly of section .fini:
