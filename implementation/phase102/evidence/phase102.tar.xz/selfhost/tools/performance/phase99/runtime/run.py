#!/usr/bin/env python3
"""Changed-batch acquisition and exact Phase93 timing reuse; root owns target execution."""
import argparse
import importlib.util
import json
import math
from pathlib import Path
import statistics
import sys
from types import SimpleNamespace

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]
QPATH = HERE.parent / 'qualification/reuse.py'
spec = importlib.util.spec_from_file_location('phase99_runtime_baseline', QPATH)
Q = importlib.util.module_from_spec(spec); spec.loader.exec_module(Q)
S = Q.support
PARENT = ROOT / 'selfhost/tools/performance/phase93/run.py'
assert S.pin(PARENT)['sha256'] == '2c2785d1543a044d1a603c292ff28cd4cf76cf8afb9892552e66036a2d99b64b'
# The two historical modules both use the name support. Import Phase93 against
# its own unchanged Phase92 support, then restore the qualification module.
previous_support, previous_path = sys.modules.pop('support'), list(sys.path)
try:
    spec = importlib.util.spec_from_file_location('phase99_original_phase93_run', PARENT)
    R = importlib.util.module_from_spec(spec); spec.loader.exec_module(R)
finally:
    sys.modules['support'] = previous_support; sys.path[:] = previous_path


def load(b, path):
    rp = b.bind(path); value = S.read(rp['file'])
    assert value['complete'] and not value.get('error') and value.get('inputsUnchanged', True)
    b.tree(value.get('inputs', [])); return rp, value


def same(a, b): return all(a[key] == b[key] for key in ['sha256', 'bytes'])


def methods(b):
    for item in R.methods(): b.bind(item)
    b.bind(__file__); b.bind(QPATH); b.bind(HERE.parent / 'qualification/baseline.json')


def bind_job(b, job):
    assert job['guardExit'] == 0 and S.bounded_exit(job['process'], 0)
    folder = Path(job['guard']); assert S.read(b.bind(folder / 'process.json')['file']) == job['process']
    for stream in ['stdout.log', 'stderr.log']: b.bind(folder / stream)
    argv = job['command'][job['command'].index('--') + 1:]
    assert job['process']['command'][-len(argv):] == argv


def acquire(a, out):
    b = S.Bindings(); ctx = S.baseline(b); methods(b)
    changed_pin, changed = load(b, a.changed_plan)
    assert changed['kind'] == 'phase98-phase93-changed-batch-plan'
    continuity_pin, continuity = load(b, a.changed_plan.parent / 'report.json')
    assert continuity['passed'] and continuity['changedPlan'] == changed_pin and continuity['producer'] == changed['producer']
    plan_pin, plan = load(b, changed['continuityPlan']); assert continuity['plan'] == plan_pin and len(plan['cases']) == 45
    changed_ids = [row['id'] for row in changed['cases']]
    assert changed_ids == continuity['changedCases'] and set(changed_ids).isdisjoint(continuity['unchangedCases'])
    assert set(changed_ids) | set(continuity['unchangedCases']) == {row['id'] for row in plan['cases']}
    producers = {}
    for stage, path in [('b1', a.b1_build), ('b2', a.b2_build)]:
        build = S.read(path); producers[stage] = S.authenticate(build['binary'], stage, build['source'], path, b, ctx)
    assert producers['b1']['source'] == producers['b2']['source'] and producers['b2'] == changed['producer']
    policy = S.backend_policy(continuity['backendPolicy']['file'], producers['b2']['source'], b)
    old_pin, old = load(b, ROOT / 'selfhost/build/phase98/origin-batch-continuity01/report.json')
    assert old['passed'] and old['allHistoricalCExact'] and old['plan'] == plan_pin and old['counts']['exactC'] == 45
    baseline = S.baseline_producer(ctx, 'b2')
    assert all(old['producer'][key] == baseline[key] for key in ['binary', 'source', 'build'])
    current_rows = {row['id']:row for row in continuity['rows']}; old_rows = {row['id']:row for row in old['rows']}
    report = dict(kind='phase99-native-runtime-acquisition', complete=False, inputsUnchanged=False,
        executionPerformed=False,
        source=producers['b2']['source'], producers=producers, changedPlan=changed_pin, continuity=continuity_pin,
        priorPhase98Continuity=old_pin, backendPolicy=policy, changedCases=changed_ids, cases=[], inputs=[],
        compilationWallSeconds=0.0, emissions=[], zeroWorkControl=plan['zeroWorkControl'], zeroObservations=[], method=S.pin(__file__))
    def save(): report['inputs'] = list(b.rows.values()); R.save(out / 'report.json', report)
    save()
    try:
        for case in plan['cases']:
            name = case['id']; original = case['originalCase']; b.bind(case['source'])
            assert current_rows[name]['passed'] and old_rows[name]['passed'] and old_rows[name]['exactHistoricalC']
            candidate_c = b.bind(current_rows[name]['output']); assert same(b.bind(old_rows[name]['output']), case['historicalC'])
            for product in case['historicalProducts'].values():
                b.bind(product['c']); b.bind(product['binary']); bind_job(b, product['build'])
            row = dict(original, passed=False, sameNativeC=True, products=dict(case['historicalProducts']),
                       phase98Product=case['historicalProducts']['own'], candidateC=candidate_c)
            report['cases'].append(row); save()
            if name in changed_ids:
                selected = next(value for value in changed['cases'] if value['id'] == name)
                assert selected == dict(case, candidateC=candidate_c)
                directory = out / name; directory.mkdir()
                report['executionPerformed'] = True; save()
                with S.S.ExecutionGuard(rss_mib=2048, available_mib=4096) as guard:
                    emission = S.run_request(guard, ctx, producers['b1'], case['source'], directory / 'b1', seconds=60,
                                             oracle=candidate_c, expected_diagnostic=case['expectedDiagnostic'])
                emission['id'] = name; report['emissions'].append(emission); save()
                assert emission['passed'] and emission['exactC']; b.bind(emission['output']); b.bind(emission['diagnosticFile'])
                for item in emission['raw']: b.bind(item)
                cc = ctx['clang']['file']; binary = directory / 'candidate.program'
                command = [cc, '-isystem', str(Path(cc).parents[1] / 'include/clang'), '-std=c11', '-O3', candidate_c['file'], '-o', str(binary), '-lpthread', '-lm']
                job = R.guard(directory / 'clang', command, 60); bind_job(b, job)
                row['products']['own'] = dict(c=candidate_c, binary=b.bind(binary), build=job)
                report['compilationWallSeconds'] += job['process']['wallSeconds']
                row['cAgreement'] = 'Fresh candidate B1/B2 full-C equality'
            else:
                assert current_rows[name]['exactHistoricalC'] and same(candidate_c, case['historicalC'])
                row['cAgreement'] = 'Fresh candidate B2 exact historical C; retained original B1/B2 product evidence, no fresh B1 batch request'
            row['passed'] = True; save()
            if name == 'scalar-region-0' and name in changed_ids:
                for role in ['own', 'upstream']:
                    observation = R.sample(out / ('zero-' + role), row, role, 8, 1)
                    bind_job(b, observation['job']); b.bind(observation['child'])
                    report['zeroObservations'].append(observation); save()
        calibration = {case['id']:case['calibration'] for case in plan['cases'] if case['calibration'] is not None}
        assert len(calibration) == 44 and 'scalar-region-0' not in calibration
        R.save(out / 'calibration.json', dict(complete=True, plan=calibration, originals=plan['calibrationReports'], targetsRun=False))
        b.bind(out / 'calibration.json'); b.unchanged(); report.update(complete=True, inputsUnchanged=True,
            scope='Only changed C rebuilt with original Clang22 C11-O3 recipe. All45 candidate product identities retained; unchanged products reuse exact C, not fresh timing. Compilation wall time is separate from program elapsedMs. Zero-work ratio stays undefined.')
        save()
        for comparator in ['phase98', 'upstream']:
            cases = []
            for row in report['cases']:
                products = dict(row['products'])
                if comparator == 'phase98': products['upstream'] = row['phase98Product']
                cases.append(dict(row, products=products))
            R.save(out / (comparator + '-products.json'), dict(complete=True, inputsUnchanged=True, cases=cases,
                kind='phase99-runtime-comparison-products', comparator=comparator, acquisition=b.bind(out / 'report.json'),
                source=report['source'], changedCases=changed_ids, method=S.pin(__file__),
                roleMeaning=dict(own='Selected candidate product', upstream='Retained ' + comparator + ' native product; legacy Phase93 role label')))
    except BaseException as error: report.update(complete=False, inputsUnchanged=False, error=repr(error)); save(); raise


def timing(a, out):
    b = S.Bindings(); methods(b); product_pin, products = load(b, a.products)
    acquired_pin, acquired = load(b, products['acquisition'])
    assert products['kind'] == 'phase99-runtime-comparison-products'
    assert products['source'] == acquired['source'] and products['changedCases'] == acquired['changedCases']
    assert products['comparator'] in ['phase98', 'upstream'] and len(products['cases']) == len(acquired['cases']) == 45
    for row, original in zip(products['cases'], acquired['cases']):
        expected = dict(original['products'])
        if products['comparator'] == 'phase98': expected['upstream'] = original['phase98Product']
        assert row == dict(original, products=expected)
    names = [row['id'] for row in products['cases'] if row['id'] != 'scalar-region-0' and (a.all or row['id'] in products['changedCases'])]
    assert names, 'No changed measurable cases; do not launch an empty campaign'
    if a.all: assert len(names) == 44
    plans = a.plans or [Path(acquired_pin['file']).parent / 'calibration.json']
    for path in plans:
        b.bind(path)
        if a.plans:
            calibration_pin, calibration = load(b, path)
            context_pin, context = load(b, path.parent / 'context.json')
            assert calibration['kind'] == 'phase93-native-runtime-calibrate' and context['timing'] == calibration_pin
            assert context['source'] == products['source'] and context['productManifest'] == product_pin
            assert context['parentMethod'] == b.bind(PARENT) and context['method'] == b.bind(__file__)
    envelope = dict(complete=False, method=S.pin(__file__), parentMethod=b.bind(PARENT), source=products['source'],
        productManifest=product_pin, acquisition=acquired_pin, comparator=products['comparator'], cases=names,
        all44=a.all, rounds=3, targetMs=250, inputs=[], compilationWallSeconds=acquired['compilationWallSeconds'],
        scope='Fresh selected runtime samples via unchanged Phase93 functions. Legacy own/upstream labels mean candidate/named comparator. Build time excluded; zero-work ratio undefined.')
    def save(): envelope['inputs'] = list(b.rows.values()); R.save(out / 'context.json', envelope)
    save()
    try:
        args = SimpleNamespace(action=a.action, acquired=[a.products], cases=','.join(names), plans=plans, rounds=3, target_ms=250)
        R.timing(args, out)
        receipt = S.read(out / 'report.json'); assert receipt['complete']
        for row in receipt['records']:
            bind_job(b, row['job']); child = S.read(b.bind(row['child'])['file'])
            case = next(case for case in products['cases'] if case['id'] == row['case'])
            expected = str(case['expected']) + '\n' + str(row['warmups']) + '\n' + str(row['repetitions']) + '\n' + str(row['elapsedMs']) + '\n'
            assert child['stdout'] == expected and child['stderr'] == '' and child['returncode'] == 0
        b.unchanged(); envelope.update(complete=True, inputsUnchanged=True, timing=b.bind(out / 'report.json')); save()
        if a.action == 'measure':
            rows = []
            for name in names:
                records = [row for row in receipt['records'] if row['case'] == name]
                assert len(records) == 6 and all(row['qualified'] and row['elapsedMs'] >= 100 for row in records)
                roles = {role:[1000 * row['elapsedMs'] / row['repetitions'] for row in records if row['role'] == role] for role in ['own', 'upstream']}
                assert all(len(values) == 3 for values in roles.values())
                case = next(case for case in products['cases'] if case['id'] == name)
                rows.append(dict(id=name, original=case['original'], mediansUs={role:statistics.median(values) for role, values in roles.items()},
                    rangesUs={role:[min(values), max(values)] for role, values in roles.items()}, ratio=statistics.median(roles['own']) / statistics.median(roles['upstream'])))
            gm = lambda values: math.exp(statistics.mean(math.log(value) for value in values))
            groups = {}
            for row in rows: groups.setdefault(row['original']['sha256'], []).append(row['ratio'])
            R.save(out / 'summary.json', dict(complete=True, source=products['source'], context=S.pin(out / 'context.json'),
                comparator=products['comparator'], freshlyMeasuredCases=len(rows), all44=a.all, rows=rows,
                equalPointGeomean=gm(row['ratio'] for row in rows), equalSourceGeomean=gm(gm(values) for values in groups.values()),
                zeroWorkRatio=None, compilationWallSeconds=acquired['compilationWallSeconds'], scope=envelope['scope']))
    except BaseException as error: envelope['error'] = repr(error); save(); raise


def main():
    p = argparse.ArgumentParser(description=__doc__); p.add_argument('action', choices=['acquire', 'measure', 'calibrate'])
    p.add_argument('--out', type=Path, required=True)
    for name in ['changed-plan', 'b1-build', 'b2-build', 'products']: p.add_argument('--' + name, type=Path)
    p.add_argument('--plans', type=Path, nargs='+'); p.add_argument('--all', action='store_true', help='Freshly time all44 nonzero products; default changed subset only')
    a = p.parse_args(); out = a.out.resolve(); assert out.is_relative_to(ROOT / 'selfhost/build/phase99') and not out.exists()
    assert all([a.changed_plan, a.b1_build, a.b2_build]) if a.action == 'acquire' else a.products
    out.mkdir(parents=True)
    if a.action == 'acquire': acquire(a, out)
    else: timing(a, out)


if __name__ == '__main__': main()
