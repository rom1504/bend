
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402980 <nx_rt_rebuild2>:
  402980:	movabs $0xffffffffff,%r9
  40298a:	push   %r14
  40298c:	push   %r13
  40298e:	and    %rsi,%r9
  402991:	mov    %edx,%r13d
  402994:	push   %r12
  402996:	lea    0x0(,%r9,8),%rdx
  40299e:	push   %rbp
  40299f:	mov    %ecx,%ebp
  4029a1:	push   %rbx
  4029a2:	mov    %rdi,%rbx
  4029a5:	sub    $0x20,%rsp
  4029a9:	mov    (%rdi),%rdi
  4029ac:	mov    0x8(%rbx),%r12
  4029b0:	lea    (%rdi,%rdx,1),%rax
  4029b4:	test   %rsi,%rsi
  4029b7:	js     402a38 <nx_rt_rebuild2+0xb8>
  4029b9:	mov    (%rax),%rax
  4029bc:	mov    %rax,0x10(%rsp)
  4029c1:	mov    0x8(%rdi,%rdx,1),%rax
  4029c6:	mov    %rax,0x18(%rsp)
  4029cb:	cmp    $0x310817f,%r9
  4029d2:	jbe    402a10 <nx_rt_rebuild2+0x90>
  4029d4:	mov    $0x1,%eax
  4029d9:	mov    0x10(%rsp,%rbp,8),%rcx
  4029de:	mov    %r13d,%edx
  4029e1:	mov    %r12,%rsi
  4029e4:	sub    %ebp,%eax
  4029e6:	movq   $0xffffffffffffffff,0x18(%rbx)
  4029ee:	mov    0x10(%rsp,%rax,8),%rax
  4029f3:	movl   $0x1,0x20(%rbx)
  4029fa:	mov    %rax,0x10(%rbx)
  4029fe:	add    $0x20,%rsp
  402a02:	pop    %rbx
  402a03:	pop    %rbp
  402a04:	pop    %r12
  402a06:	pop    %r13
  402a08:	pop    %r14
  402a0a:	jmpq   401c20 <nx_construct2>
  402a0f:	nop
  402a10:	mov    0x8(%r12),%r9
  402a15:	test   %r9,%r9
  402a18:	je     401651 <nx_rt_rebuild2.cold>
  402a1e:	mov    (%rdi,%r9,8),%rax
  402a22:	subq   $0x2,0x108(%r12)
  402a2b:	mov    %rax,0x8(%r12)
  402a30:	jmp    4029d4 <nx_rt_rebuild2+0x54>
  402a32:	nopw   0x0(%rax,%rax,1)
  402a38:	mov    0x4(%rax),%edx
  402a3b:	mov    (%rax),%ecx
  402a3d:	shl    $0x20,%rdx
  402a41:	or     %rcx,%rdx
  402a44:	mov    %rdx,%r14
  402a47:	and    $0xffffff,%edx
  402a4d:	shr    $0x18,%r14
  402a51:	lea    0x0(,%r14,8),%r10
  402a59:	lea    (%rdi,%r10,1),%r11
  402a5d:	lea    0x8(%rdi,%r10,1),%r10
  402a62:	cmp    $0x1,%rdx
  402a66:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402a6c:	mov    (%rax),%edx
  402a6e:	mov    (%r11),%rdx
  402a71:	mov    %rdx,0x10(%rsp)
  402a76:	mov    (%r10),%rdx
  402a79:	mov    %rdx,0x18(%rsp)
  402a7e:	mov    (%r12),%rdx
  402a82:	mov    %rdx,(%rax)
  402a85:	mov    0x100(%r12),%rax
  402a8d:	mov    0x4745(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402a93:	mov    %r9,(%r12)
  402a97:	add    $0x1,%rax
  402a9b:	mov    %rax,0x100(%r12)
  402aa3:	cmp    %rdx,%rax
  402aa6:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402aac:	mov    %r14,%r9
  402aaf:	jmpq   4029cb <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
