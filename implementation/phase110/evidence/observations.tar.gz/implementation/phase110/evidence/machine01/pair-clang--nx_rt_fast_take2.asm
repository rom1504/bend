
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402b90 <nx_rt_fast_take2>:
  402b90:	movabs $0xffffffffff,%rax
  402b9a:	push   %r12
  402b9c:	and    %rsi,%rax
  402b9f:	push   %rbp
  402ba0:	push   %rbx
  402ba1:	mov    %rdi,%rbx
  402ba4:	mov    (%rdi),%rdi
  402ba7:	lea    0x0(,%rax,8),%rcx
  402baf:	mov    0x8(%rbx),%rbp
  402bb3:	lea    (%rdi,%rcx,1),%rdx
  402bb7:	test   %rsi,%rsi
  402bba:	js     402c28 <nx_rt_fast_take2+0x98>
  402bbc:	mov    (%rdx),%rdx
  402bbf:	mov    %rdx,0x10(%rbx)
  402bc3:	mov    0x8(%rdi,%rcx,1),%rdx
  402bc8:	mov    %rdx,0x18(%rbx)
  402bcc:	cmp    $0x310817f,%rax
  402bd2:	ja     402be8 <nx_rt_fast_take2+0x58>
  402bd4:	movl   $0x3,0x20(%rbx)
  402bdb:	xor    %eax,%eax
  402bdd:	pop    %rbx
  402bde:	pop    %rbp
  402bdf:	pop    %r12
  402be1:	retq   
  402be2:	nopw   0x0(%rax,%rax,1)
  402be8:	mov    0x8(%rbp),%rdx
  402bec:	mov    %rdx,(%rdi,%rax,8)
  402bf0:	mov    0x3e5e2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402bf6:	mov    %rax,0x8(%rbp)
  402bfa:	mov    0x108(%rbp),%rax
  402c01:	add    $0x2,%rax
  402c05:	mov    %rax,0x108(%rbp)
  402c0c:	cmp    %rdx,%rax
  402c0f:	jae    40160f <nx_rt_fast_take2.cold>
  402c15:	movl   $0x3,0x20(%rbx)
  402c1c:	xor    %eax,%eax
  402c1e:	pop    %rbx
  402c1f:	pop    %rbp
  402c20:	pop    %r12
  402c22:	retq   
  402c23:	nopl   0x0(%rax,%rax,1)
  402c28:	mov    0x4(%rdx),%ecx
  402c2b:	mov    (%rdx),%r8d
  402c2e:	shl    $0x20,%rcx
  402c32:	or     %r8,%rcx
  402c35:	mov    %rcx,%r12
  402c38:	and    $0xffffff,%ecx
  402c3e:	shr    $0x18,%r12
  402c42:	lea    0x0(,%r12,8),%r8
  402c4a:	lea    (%rdi,%r8,1),%r9
  402c4e:	lea    0x8(%rdi,%r8,1),%r8
  402c53:	cmp    $0x1,%rcx
  402c57:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  402c5d:	mov    (%rdx),%ecx
  402c5f:	mov    (%r9),%rcx
  402c62:	mov    %rcx,0x10(%rbx)
  402c66:	mov    (%r8),%rcx
  402c69:	mov    %rcx,0x18(%rbx)
  402c6d:	mov    0x0(%rbp),%rcx
  402c71:	mov    %rcx,(%rdx)
  402c74:	mov    0x3e55e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402c7a:	mov    %rax,0x0(%rbp)
  402c7e:	mov    0x100(%rbp),%rax
  402c85:	add    $0x1,%rax
  402c89:	mov    %rax,0x100(%rbp)
  402c90:	cmp    %rdx,%rax
  402c93:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402c99:	mov    %r12,%rax
  402c9c:	jmpq   402bcc <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
