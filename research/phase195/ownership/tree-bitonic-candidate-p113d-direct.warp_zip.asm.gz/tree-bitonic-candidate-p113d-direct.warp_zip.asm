
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/tree-bitonic/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000408309 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>:
  408309:	push   %rbp
  40830a:	mov    %rsp,%rbp
  40830d:	sub    $0x9e0,%rsp
  408314:	mov    %r12,-0x10(%rbp)
  408318:	mov    %rbx,-0x8(%rbp)
  40831c:	mov    %r13,-0x18(%rbp)
  408320:	mov    %r14,-0x20(%rbp)
  408324:	mov    %rdi,%rax
  408327:	mov    %rax,%r12
  40832a:	mov    %rsi,%rax
  40832d:	mov    %rax,%rsi
  408330:	mov    %rdx,%rax
  408333:	mov    %rax,%rbx
  408336:	mov    %rsi,%rdi
  408339:	shr    $0x28,%rdi
  40833d:	and    $0xffff,%rdi
  408344:	movabs $0xa5,%r11
  40834e:	cmp    %r11,%rdi
  408351:	jne    4085dc <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x2d3>
  408357:	mov    %r12,%r10
  40835a:	mov    %r10,0x18(%rsp)
  40835f:	mov    %rsi,%r10
  408362:	mov    %r10,0x20(%rsp)
  408367:	lea    -0x840(%rbp),%r10
  40836e:	mov    %r10,0x28(%rsp)
  408373:	mov    0x18(%rsp),%rdi
  408378:	mov    0x20(%rsp),%rsi
  40837d:	mov    0x28(%rsp),%rdx
  408382:	xor    %eax,%eax
  408384:	callq  421d40 <p125_rt_take2>
  408389:	mov    %rax,-0x8b0(%rbp)
  408390:	lea    -0x840(%rbp),%r10
  408397:	mov    (%r10),%r13
  40839a:	lea    -0x840(%rbp),%r10
  4083a1:	mov    0x8(%r10),%r14
  4083a5:	mov    %rbx,%rdi
  4083a8:	shr    $0x28,%rdi
  4083ac:	and    $0xffff,%rdi
  4083b3:	movabs $0xa5,%r11
  4083bd:	cmp    %r11,%rdi
  4083c0:	jne    4084c2 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x1b9>
  4083c6:	mov    %r12,%rdi
  4083c9:	mov    %rbx,%rsi
  4083cc:	lea    -0x840(%rbp),%rdx
  4083d3:	xor    %eax,%eax
  4083d5:	callq  421d40 <p125_rt_take2>
  4083da:	mov    %rax,-0x8b0(%rbp)
  4083e1:	lea    -0x840(%rbp),%r10
  4083e8:	mov    (%r10),%rdi
  4083eb:	lea    -0x840(%rbp),%r10
  4083f2:	mov    0x8(%r10),%rbx
  4083f6:	lea    -0x840(%rbp),%r10
  4083fd:	mov    %r13,%r11
  408400:	mov    %r11,(%r10)
  408403:	lea    -0x840(%rbp),%r10
  40840a:	mov    %rdi,%r11
  40840d:	mov    %r11,0x8(%r10)
  408411:	mov    %r12,%rdi
  408414:	movabs $0xa5,%rsi
  40841e:	mov    %esi,%esi
  408420:	lea    -0x840(%rbp),%rdx
  408427:	xor    %eax,%eax
  408429:	callq  421c50 <p125_rt_ctor2>
  40842e:	mov    %rax,%rdi
  408431:	mov    %rdi,%r13
  408434:	lea    -0x840(%rbp),%r10
  40843b:	mov    %r14,%r11
  40843e:	mov    %r11,(%r10)
  408441:	lea    -0x840(%rbp),%r10
  408448:	mov    %rbx,%r11
  40844b:	mov    %r11,0x8(%r10)
  40844f:	mov    %r12,%rdi
  408452:	movabs $0xa5,%rsi
  40845c:	mov    %esi,%esi
  40845e:	lea    -0x840(%rbp),%rdx
  408465:	xor    %eax,%eax
  408467:	callq  421c50 <p125_rt_ctor2>
  40846c:	mov    %rax,%rdi
  40846f:	lea    -0x840(%rbp),%r10
  408476:	mov    %r13,%r11
  408479:	mov    %r11,(%r10)
  40847c:	lea    -0x840(%rbp),%r10
  408483:	mov    %rdi,%r11
  408486:	mov    %r11,0x8(%r10)
  40848a:	mov    %r12,%rdi
  40848d:	movabs $0xa5,%rsi
  408497:	mov    %esi,%esi
  408499:	lea    -0x840(%rbp),%rdx
  4084a0:	xor    %eax,%eax
  4084a2:	callq  421c50 <p125_rt_ctor2>
  4084a7:	mov    %rax,%rdi
  4084aa:	mov    %rdi,%rax
  4084ad:	mov    -0x10(%rbp),%r12
  4084b1:	mov    -0x8(%rbp),%rbx
  4084b5:	mov    -0x18(%rbp),%r13
  4084b9:	mov    -0x20(%rbp),%r14
  4084bd:	mov    %rbp,%rsp
  4084c0:	pop    %rbp
  4084c1:	retq   
  4084c2:	mov    %r12,%rdi
  4084c5:	mov    %r13,%rsi
  4084c8:	xor    %eax,%eax
  4084ca:	callq  41bfa0 <p111_rt_sink>
  4084cf:	mov    %rax,-0x8b0(%rbp)
  4084d6:	mov    %r12,%rdi
  4084d9:	mov    %r14,%rsi
  4084dc:	xor    %eax,%eax
  4084de:	callq  41bfa0 <p111_rt_sink>
  4084e3:	mov    %rax,-0x8b0(%rbp)
  4084ea:	mov    %rbx,%rdi
  4084ed:	shr    $0x28,%rdi
  4084f1:	and    $0xffff,%rdi
  4084f8:	movabs $0xa4,%r11
  408502:	cmp    %r11,%rdi
  408505:	jne    4085a0 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x297>
  40850b:	mov    %rbx,%rdi
  40850e:	shr    $0x28,%rdi
  408512:	and    $0x7fffff,%rdi
  408519:	movabs $0xa4,%rsi
  408523:	or     $0x10000,%rsi
  40852a:	cmp    %rsi,%rdi
  40852d:	jne    408555 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x24c>
  408533:	movabs $0xffffffffff,%r11
  40853d:	mov    %rbx,%rdi
  408540:	and    %r11,%rdi
  408543:	lea    -0x840(%rbp),%r10
  40854a:	mov    %rdi,%r11
  40854d:	mov    %r11,(%r10)
  408550:	jmpq   408570 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x267>
  408555:	mov    %r12,%rdi
  408558:	mov    %rbx,%rsi
  40855b:	lea    -0x840(%rbp),%rdx
  408562:	xor    %eax,%eax
  408564:	callq  421ac0 <p125_rt_take1>
  408569:	mov    %rax,-0x8b0(%rbp)
  408570:	lea    -0x840(%rbp),%r10
  408577:	mov    (%r10),%r10
  40857a:	mov    %r10,-0x910(%rbp)
  408581:	movabs $0x100a40000000000,%rax
  40858b:	mov    -0x10(%rbp),%r12
  40858f:	mov    -0x8(%rbp),%rbx
  408593:	mov    -0x18(%rbp),%r13
  408597:	mov    -0x20(%rbp),%r14
  40859b:	mov    %rbp,%rsp
  40859e:	pop    %rbp
  40859f:	retq   
  4085a0:	mov    %r12,%rdi
  4085a3:	movabs $0x4,%rsi
  4085ad:	mov    %esi,%esi
  4085af:	xor    %eax,%eax
  4085b1:	callq  41c730 <p111_rt_fail>
  4085b6:	mov    %rax,-0x8b0(%rbp)
  4085bd:	movabs $0x0,%rax
  4085c7:	mov    -0x10(%rbp),%r12
  4085cb:	mov    -0x8(%rbp),%rbx
  4085cf:	mov    -0x18(%rbp),%r13
  4085d3:	mov    -0x20(%rbp),%r14
  4085d7:	mov    %rbp,%rsp
  4085da:	pop    %rbp
  4085db:	retq   
  4085dc:	mov    %rsi,%rdi
  4085df:	shr    $0x28,%rdi
  4085e3:	and    $0xffff,%rdi
  4085ea:	movabs $0xa4,%r11
  4085f4:	cmp    %r11,%rdi
  4085f7:	jne    40882f <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x526>
  4085fd:	mov    %rsi,%rdi
  408600:	shr    $0x28,%rdi
  408604:	and    $0x7fffff,%rdi
  40860b:	movabs $0xa4,%rdx
  408615:	or     $0x10000,%rdx
  40861c:	cmp    %rdx,%rdi
  40861f:	jne    408647 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x33e>
  408625:	movabs $0xffffffffff,%r11
  40862f:	mov    %rsi,%rdi
  408632:	and    %r11,%rdi
  408635:	lea    -0x840(%rbp),%r10
  40863c:	mov    %rdi,%r11
  40863f:	mov    %r11,(%r10)
  408642:	jmpq   408680 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x377>
  408647:	mov    %r12,%r10
  40864a:	mov    %r10,0x18(%rsp)
  40864f:	mov    %rsi,%r10
  408652:	mov    %r10,0x20(%rsp)
  408657:	lea    -0x840(%rbp),%r10
  40865e:	mov    %r10,0x28(%rsp)
  408663:	mov    0x18(%rsp),%rdi
  408668:	mov    0x20(%rsp),%rsi
  40866d:	mov    0x28(%rsp),%rdx
  408672:	xor    %eax,%eax
  408674:	callq  421ac0 <p125_rt_take1>
  408679:	mov    %rax,-0x8b0(%rbp)
  408680:	lea    -0x840(%rbp),%r10
  408687:	mov    (%r10),%r10
  40868a:	mov    %r10,-0x940(%rbp)
  408691:	mov    %rbx,%rdi
  408694:	shr    $0x28,%rdi
  408698:	and    $0xffff,%rdi
  40869f:	movabs $0xa5,%r11
  4086a9:	cmp    %r11,%rdi
  4086ac:	jne    40873d <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x434>
  4086b2:	mov    %r12,%rdi
  4086b5:	mov    %rbx,%rsi
  4086b8:	lea    -0x840(%rbp),%rdx
  4086bf:	xor    %eax,%eax
  4086c1:	callq  421d40 <p125_rt_take2>
  4086c6:	mov    %rax,-0x8b0(%rbp)
  4086cd:	lea    -0x840(%rbp),%r10
  4086d4:	mov    (%r10),%rdi
  4086d7:	lea    -0x840(%rbp),%r10
  4086de:	mov    0x8(%r10),%rbx
  4086e2:	mov    %r12,%r10
  4086e5:	mov    %r10,0x10(%rsp)
  4086ea:	mov    %rdi,%r10
  4086ed:	mov    %r10,0x18(%rsp)
  4086f2:	mov    0x10(%rsp),%rdi
  4086f7:	mov    0x18(%rsp),%rsi
  4086fc:	xor    %eax,%eax
  4086fe:	callq  41bfa0 <p111_rt_sink>
  408703:	mov    %rax,-0x8b0(%rbp)
  40870a:	mov    %r12,%rdi
  40870d:	mov    %rbx,%rsi
  408710:	xor    %eax,%eax
  408712:	callq  41bfa0 <p111_rt_sink>
  408717:	mov    %rax,-0x8b0(%rbp)
  40871e:	movabs $0x100a40000000000,%rax
  408728:	mov    -0x10(%rbp),%r12
  40872c:	mov    -0x8(%rbp),%rbx
  408730:	mov    -0x18(%rbp),%r13
  408734:	mov    -0x20(%rbp),%r14
  408738:	mov    %rbp,%rsp
  40873b:	pop    %rbp
  40873c:	retq   
  40873d:	mov    %rbx,%rdi
  408740:	shr    $0x28,%rdi
  408744:	and    $0xffff,%rdi
  40874b:	movabs $0xa4,%r11
  408755:	cmp    %r11,%rdi
  408758:	jne    4087f3 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x4ea>
  40875e:	mov    %rbx,%rdi
  408761:	shr    $0x28,%rdi
  408765:	and    $0x7fffff,%rdi
  40876c:	movabs $0xa4,%rsi
  408776:	or     $0x10000,%rsi
  40877d:	cmp    %rsi,%rdi
  408780:	jne    4087a8 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x49f>
  408786:	movabs $0xffffffffff,%r11
  408790:	mov    %rbx,%rdi
  408793:	and    %r11,%rdi
  408796:	lea    -0x840(%rbp),%r10
  40879d:	mov    %rdi,%r11
  4087a0:	mov    %r11,(%r10)
  4087a3:	jmpq   4087c3 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x4ba>
  4087a8:	mov    %r12,%rdi
  4087ab:	mov    %rbx,%rsi
  4087ae:	lea    -0x840(%rbp),%rdx
  4087b5:	xor    %eax,%eax
  4087b7:	callq  421ac0 <p125_rt_take1>
  4087bc:	mov    %rax,-0x8b0(%rbp)
  4087c3:	lea    -0x840(%rbp),%r10
  4087ca:	mov    (%r10),%r10
  4087cd:	mov    %r10,-0x980(%rbp)
  4087d4:	movabs $0x100a40000000000,%rax
  4087de:	mov    -0x10(%rbp),%r12
  4087e2:	mov    -0x8(%rbp),%rbx
  4087e6:	mov    -0x18(%rbp),%r13
  4087ea:	mov    -0x20(%rbp),%r14
  4087ee:	mov    %rbp,%rsp
  4087f1:	pop    %rbp
  4087f2:	retq   
  4087f3:	mov    %r12,%rdi
  4087f6:	movabs $0x4,%rsi
  408800:	mov    %esi,%esi
  408802:	xor    %eax,%eax
  408804:	callq  41c730 <p111_rt_fail>
  408809:	mov    %rax,-0x8b0(%rbp)
  408810:	movabs $0x0,%rax
  40881a:	mov    -0x10(%rbp),%r12
  40881e:	mov    -0x8(%rbp),%rbx
  408822:	mov    -0x18(%rbp),%r13
  408826:	mov    -0x20(%rbp),%r14
  40882a:	mov    %rbp,%rsp
  40882d:	pop    %rbp
  40882e:	retq   
  40882f:	mov    %r12,%rdi
  408832:	movabs $0x4,%rsi
  40883c:	mov    %esi,%esi
  40883e:	xor    %eax,%eax
  408840:	callq  41c730 <p111_rt_fail>
  408845:	mov    %rax,-0x8b0(%rbp)
  40884c:	movabs $0x0,%rax
  408856:	mov    -0x10(%rbp),%r12
  40885a:	mov    -0x8(%rbp),%rbx
  40885e:	mov    -0x18(%rbp),%r13
  408862:	mov    -0x20(%rbp),%r14
  408866:	mov    %rbp,%rsp
  408869:	pop    %rbp
  40886a:	retq   

Disassembly of section .fini:
