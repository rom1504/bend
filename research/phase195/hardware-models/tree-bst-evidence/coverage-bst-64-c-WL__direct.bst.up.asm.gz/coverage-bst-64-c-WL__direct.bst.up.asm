000000000000ae80 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_>:
    ae80:	push   rbp
    ae81:	sub    rsp,0x10
    ae85:	mov    r8,rdx
    ae88:	mov    rbp,rsi
    ae8b:	mov    DWORD PTR [rsp+0x4],r15d
    ae90:	mov    QWORD PTR [rsp+0x8],r14
    ae95:	movabs rax,0xffffffff80
    ae9f:	lea    r9,[rax+0x7f]
    aea3:	movabs r11,0xffff0000000000
    aead:	movabs r15,0x200a50000000000
    aeb7:	jmp    aef7 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x77>
    aeb9:	mov    rdi,r12
    aebc:	mov    rsi,r13
    aebf:	mov    edx,0x2
    aec4:	call   13ff8 <heap_alloc_miss>
    aec9:	movabs r11,0xffff0000000000
    aed3:	data16 data16 data16 nop WORD PTR cs:[rax+rax*1+0x0]
    aee0:	mov    rcx,r8
    aee3:	mov    QWORD PTR [r12+rax*8],rcx
    aee7:	mov    QWORD PTR [r12+rax*8+0x8],r14
    aeec:	mov    QWORD PTR [r12+rax*8+0x10],rbx
    aef1:	or     rax,r15
    aef4:	mov    r8,rax
    aef7:	mov    rax,rbp
    aefa:	shr    rax,0x28
    aefe:	cmp    ax,0x12
    af02:	jne    b24e <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x3ce>
    af08:	mov    rdx,rbp
    af0b:	and    rdx,r9
    af0e:	test   rbp,rbp
    af11:	js     af30 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0xb0>
    af13:	mov    rax,QWORD PTR [r12+rdx*8]
    af17:	mov    rbp,QWORD PTR [r12+rdx*8+0x8]
    af1c:	mov    rcx,rdx
    af1f:	cmp    rcx,0x3108180
    af26:	jae    afa2 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x122>
    af28:	jmp    afda <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x15a>
    af2d:	nop    DWORD PTR [rax]
    af30:	mov    ecx,DWORD PTR [r12+rdx*8+0x4]
    af35:	mov    eax,DWORD PTR [r12+rdx*8]
    af39:	mov    esi,eax
    af3b:	and    esi,0xffffff
    af41:	cmp    esi,0x1
    af44:	jne    b17a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2fa>
    af4a:	mov    esi,DWORD PTR [r12+rdx*8]
    af4e:	shl    rcx,0x20
    af52:	or     rcx,rax
    af55:	shr    rcx,0x18
    af59:	mov    rax,QWORD PTR [r12+rcx*8]
    af5d:	mov    rbp,QWORD PTR [r12+rcx*8+0x8]
    af62:	mov    rsi,QWORD PTR [r13+0x0]
    af66:	mov    QWORD PTR [r12+rdx*8],rsi
    af6a:	mov    QWORD PTR [r13+0x0],rdx
    af6e:	mov    rdx,QWORD PTR [r13+0x100]
    af75:	inc    rdx
    af78:	mov    QWORD PTR [r13+0x100],rdx
    af7f:	cmp    BYTE PTR [rip+0x10ce0a],0x1        # 117d90 <KEEP_WORDS>
    af86:	jne    b1fc <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x37c>
    af8c:	cmp    rdx,0x8000
    af93:	jae    b1fc <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x37c>
    af99:	cmp    rcx,0x3108180
    afa0:	jb     afda <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x15a>
    afa2:	mov    rdx,QWORD PTR [r13+0x8]
    afa6:	mov    QWORD PTR [r12+rcx*8],rdx
    afaa:	mov    QWORD PTR [r13+0x8],rcx
    afae:	mov    rcx,QWORD PTR [r13+0x108]
    afb5:	add    rcx,0x2
    afb9:	mov    QWORD PTR [r13+0x108],rcx
    afc0:	cmp    BYTE PTR [rip+0x10cdc9],0x1        # 117d90 <KEEP_WORDS>
    afc7:	jne    b13c <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2bc>
    afcd:	cmp    rcx,0x8000
    afd4:	jae    b13c <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2bc>
    afda:	mov    rcx,rax
    afdd:	and    rcx,r11
    afe0:	movabs rdx,0xa60000000000
    afea:	cmp    rcx,rdx
    afed:	jne    b291 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x411>
    aff3:	mov    rdx,rax
    aff6:	and    rdx,r9
    aff9:	test   rax,rax
    affc:	js     b020 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x1a0>
    affe:	mov    r14d,DWORD PTR [r12+rdx*8]
    b002:	mov    rbx,QWORD PTR [r12+rdx*8+0x8]
    b007:	mov    r10d,DWORD PTR [r12+rdx*8+0x10]
    b00c:	mov    rcx,rdx
    b00f:	cmp    rcx,0x3108180
    b016:	jae    b096 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x216>
    b018:	jmp    b0cd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x24d>
    b01d:	nop    DWORD PTR [rax]
    b020:	mov    ecx,DWORD PTR [r12+rdx*8+0x4]
    b025:	mov    esi,DWORD PTR [r12+rdx*8]
    b029:	mov    edi,esi
    b02b:	and    edi,0xffffff
    b031:	cmp    edi,0x1
    b034:	jne    b1ba <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x33a>
    b03a:	mov    eax,DWORD PTR [r12+rdx*8]
    b03e:	shl    rcx,0x20
    b042:	or     rcx,rsi
    b045:	shr    rcx,0x18
    b049:	mov    r14d,DWORD PTR [r12+rcx*8]
    b04d:	mov    rbx,QWORD PTR [r12+rcx*8+0x8]
    b052:	mov    r10d,DWORD PTR [r12+rcx*8+0x10]
    b057:	mov    rax,QWORD PTR [r13+0x0]
    b05b:	mov    QWORD PTR [r12+rdx*8],rax
    b05f:	mov    QWORD PTR [r13+0x0],rdx
    b063:	mov    rax,QWORD PTR [r13+0x100]
    b06a:	inc    rax
    b06d:	mov    QWORD PTR [r13+0x100],rax
    b074:	cmp    BYTE PTR [rip+0x10cd15],0x1        # 117d90 <KEEP_WORDS>
    b07b:	jne    b225 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x3a5>
    b081:	cmp    rax,0x8000
    b087:	jae    b225 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x3a5>
    b08d:	cmp    rcx,0x3108180
    b094:	jb     b0cd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x24d>
    b096:	mov    rax,QWORD PTR [r13+0x10]
    b09a:	mov    QWORD PTR [r12+rcx*8],rax
    b09e:	mov    QWORD PTR [r13+0x10],rcx
    b0a2:	mov    rax,QWORD PTR [r13+0x110]
    b0a9:	add    rax,0x4
    b0ad:	mov    QWORD PTR [r13+0x110],rax
    b0b4:	cmp    BYTE PTR [rip+0x10ccd5],0x1        # 117d90 <KEEP_WORDS>
    b0bb:	jne    b15b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2db>
    b0c1:	cmp    rax,0x8000
    b0c7:	jae    b15b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2db>
    b0cd:	mov    rax,QWORD PTR [r13+0x10]
    b0d1:	cmp    r10d,0x1
    b0d5:	jne    b100 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x280>
    b0d7:	test   rax,rax
    b0da:	je     aeb9 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x39>
    b0e0:	mov    rcx,QWORD PTR [r12+rax*8]
    b0e4:	mov    QWORD PTR [r13+0x10],rcx
    b0e8:	add    QWORD PTR [r13+0x110],0xfffffffffffffffc
    b0f0:	jmp    aee0 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x60>
    b0f5:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
    b100:	test   rax,rax
    b103:	je     b120 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2a0>
    b105:	mov    rcx,QWORD PTR [r12+rax*8]
    b109:	mov    QWORD PTR [r13+0x10],rcx
    b10d:	add    QWORD PTR [r13+0x110],0xfffffffffffffffc
    b115:	mov    rcx,rbx
    b118:	mov    rbx,r8
    b11b:	jmp    aee3 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x63>
    b120:	mov    rdi,r12
    b123:	mov    rsi,r13
    b126:	mov    edx,0x2
    b12b:	call   13ff8 <heap_alloc_miss>
    b130:	movabs r11,0xffff0000000000
    b13a:	jmp    b115 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x295>
    b13c:	mov    rdi,r12
    b13f:	mov    rsi,r13
    b142:	mov    edx,0x1
    b147:	call   13ed1 <heap_hand>
    b14c:	movabs r11,0xffff0000000000
    b156:	jmp    afda <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x15a>
    b15b:	mov    rdi,r12
    b15e:	mov    rsi,r13
    b161:	mov    edx,0x2
    b166:	call   13ed1 <heap_hand>
    b16b:	movabs r11,0xffff0000000000
    b175:	jmp    b0cd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x24d>
    b17a:	shl    rcx,0x20
    b17e:	or     rcx,rax
    b181:	shr    rcx,0x18
    b185:	mov    rax,QWORD PTR [r12+rcx*8]
    b189:	mov    r10,QWORD PTR [r12+rcx*8+0x8]
    b18e:	mov    rdi,r12
    b191:	mov    rsi,r13
    b194:	mov    rdx,rbp
    b197:	mov    rbx,r8
    b19a:	mov    r8d,0x2
    b1a0:	call   13f62 <span_fade>
    b1a5:	movabs r11,0xffff0000000000
    b1af:	mov    r8,rbx
    b1b2:	mov    rbp,r10
    b1b5:	jmp    afda <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x15a>
    b1ba:	shl    rcx,0x20
    b1be:	or     rcx,rsi
    b1c1:	shr    rcx,0x18
    b1c5:	mov    r14d,DWORD PTR [r12+rcx*8]
    b1c9:	mov    rbx,QWORD PTR [r12+rcx*8+0x8]
    b1ce:	mov    r10d,DWORD PTR [r12+rcx*8+0x10]
    b1d3:	mov    rdi,r12
    b1d6:	mov    rsi,r13
    b1d9:	mov    rdx,rax
    b1dc:	mov    rax,r8
    b1df:	mov    r8d,0x3
    b1e5:	call   13f62 <span_fade>
    b1ea:	movabs r11,0xffff0000000000
    b1f4:	mov    r8,rax
    b1f7:	jmp    b0cd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x24d>
    b1fc:	mov    rdi,r12
    b1ff:	mov    rsi,r13
    b202:	xor    edx,edx
    b204:	call   13ed1 <heap_hand>
    b209:	movabs r11,0xffff0000000000
    b213:	cmp    rcx,0x3108180
    b21a:	jae    afa2 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x122>
    b220:	jmp    afda <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x15a>
    b225:	mov    rdi,r12
    b228:	mov    rsi,r13
    b22b:	xor    edx,edx
    b22d:	call   13ed1 <heap_hand>
    b232:	movabs r11,0xffff0000000000
    b23c:	cmp    rcx,0x3108180
    b243:	jae    b096 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x216>
    b249:	jmp    b0cd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x24d>
    b24e:	movzx  eax,ax
    b251:	cmp    eax,0x11
    b254:	jne    b282 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x402>
    b256:	mov    r14,QWORD PTR [rsp+0x8]
    b25b:	mov    eax,DWORD PTR [r14-0x8]
    b25f:	add    r14,0xfffffffffffffff8
    b263:	lea    rcx,[rip+0xb1f6]        # 16460 <wl_tab>
    b26a:	mov    rax,QWORD PTR [rcx+rax*8]
    b26e:	mov    r15d,DWORD PTR [rsp+0x4]
    b273:	mov    edi,0x1
    b278:	mov    rsi,r8
    b27b:	add    rsp,0x10
    b27f:	pop    rbp
    b280:	jmp    rax
    b282:	mov    r14,r8
    b285:	movabs rbx,0x7e00000000000000
    b28f:	jmp    b2d9 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x459>
    b291:	mov    r14,r8
    b294:	movabs rbx,0x7e00000000000000
    b29e:	test   rax,rbx
    b2a1:	sete   cl
    b2a4:	cmp    rax,0xffffffffffffffff
    b2a8:	sete   dl
    b2ab:	or     dl,cl
    b2ad:	mov    rcx,rax
    b2b0:	movabs rsi,0xffffffff80
    b2ba:	and    rcx,rsi
    b2bd:	cmp    rcx,0x3108180
    b2c4:	setb   cl
    b2c7:	or     cl,dl
    b2c9:	jne    b2d9 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x459>
    b2cb:	mov    rdi,r12
    b2ce:	mov    rsi,r13
    b2d1:	mov    rdx,rax
    b2d4:	call   6de0 <term_drop>
    b2d9:	test   rbp,rbx
    b2dc:	sete   al
    b2df:	cmp    rbp,0xffffffffffffffff
    b2e3:	sete   cl
    b2e6:	or     cl,al
    b2e8:	mov    rax,rbp
    b2eb:	movabs rdx,0xffffffff80
    b2f5:	and    rax,rdx
    b2f8:	cmp    rax,0x3108180
    b2fe:	setb   al
    b301:	or     al,cl
    b303:	jne    b313 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x493>
    b305:	mov    rdi,r12
    b308:	mov    rsi,r13
    b30b:	mov    rdx,rbp
    b30e:	call   6de0 <term_drop>
    b313:	test   r14,rbx
    b316:	sete   al
    b319:	cmp    r14,0xffffffffffffffff
    b31d:	sete   cl
    b320:	or     cl,al
    b322:	movabs rax,0xffffffff80
    b32c:	and    rax,r14
    b32f:	cmp    rax,0x3108180
    b335:	setb   al
    b338:	or     al,cl
    b33a:	jne    b34a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x4ca>
    b33c:	mov    rdi,r12
    b33f:	mov    rsi,r13
    b342:	mov    rdx,r14
    b345:	call   6de0 <term_drop>
    b34a:	lea    rdi,[rip+0xffffffffffff733f]        # 2690 <FID_RESW_T+0x320>
    b351:	call   13e70 <err_fail>
    b356:	nop    WORD PTR cs:[rax+rax*1+0x0]

