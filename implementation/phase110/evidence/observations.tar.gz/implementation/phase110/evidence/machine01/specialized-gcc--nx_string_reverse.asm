
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c80 <nx_string_reverse>:
  401c80:	push   %r12
  401c82:	mov    %rsi,%rax
  401c85:	mov    %rdx,%r12
  401c88:	push   %rbp
  401c89:	shr    $0x28,%rax
  401c8d:	sub    $0x8,%rsp
  401c91:	cmp    $0x2,%ax
  401c95:	je     401cd6 <nx_string_reverse+0x56>
  401c97:	movzwl %ax,%edx
  401c9a:	mov    %rdi,%rbp
  401c9d:	cmp    $0x3,%rdx
  401ca1:	je     401cae <nx_string_reverse+0x2e>
  401ca3:	jmp    401ce8 <nx_string_reverse+0x68>
  401ca5:	nopl   (%rax)
  401ca8:	cmp    $0x3,%rdx
  401cac:	jne    401ce8 <nx_string_reverse+0x68>
  401cae:	mov    %r12,%rdx
  401cb1:	mov    %rbp,%rdi
  401cb4:	callq  4037a0 <nx_rt_rebuild2_c3_k0>
  401cb9:	xor    %esi,%esi
  401cbb:	mov    %rbp,%rdi
  401cbe:	mov    %rax,%r12
  401cc1:	callq  402d10 <nx_rt_fast_field>
  401cc6:	mov    %rax,%rsi
  401cc9:	shr    $0x28,%rax
  401ccd:	movzwl %ax,%edx
  401cd0:	cmp    $0x2,%ax
  401cd4:	jne    401ca8 <nx_string_reverse+0x28>
  401cd6:	add    $0x8,%rsp
  401cda:	mov    %r12,%rax
  401cdd:	pop    %rbp
  401cde:	pop    %r12
  401ce0:	retq   
  401ce1:	nopl   0x0(%rax)
  401ce8:	add    $0x8,%rsp
  401cec:	mov    %rbp,%rdi
  401cef:	mov    $0x1,%esi
  401cf4:	pop    %rbp
  401cf5:	pop    %r12
  401cf7:	jmpq   402560 <nx_rt_fail>

Disassembly of section .fini:
