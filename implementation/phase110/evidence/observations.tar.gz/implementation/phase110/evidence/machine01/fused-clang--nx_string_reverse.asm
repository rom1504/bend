
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c70 <nx_string_reverse>:
  401c70:	push   %r15
  401c72:	push   %r14
  401c74:	push   %rbx
  401c75:	mov    %rdx,%r14
  401c78:	mov    %rsi,%r15
  401c7b:	mov    %rdi,%rbx
  401c7e:	xchg   %ax,%ax
  401c80:	mov    %rbx,%rdi
  401c83:	mov    %r15,%rsi
  401c86:	callq  402a40 <nx_rt_fast_id>
  401c8b:	cmp    $0x3,%eax
  401c8e:	jne    401cb7 <nx_string_reverse+0x47>
  401c90:	mov    %rbx,%rdi
  401c93:	mov    %r15,%rsi
  401c96:	mov    $0x3,%edx
  401c9b:	xor    %ecx,%ecx
  401c9d:	mov    %r14,%r8
  401ca0:	callq  402d10 <nx_rt_rebuild2>
  401ca5:	mov    %rax,%r14
  401ca8:	mov    %rbx,%rdi
  401cab:	xor    %esi,%esi
  401cad:	callq  402cf0 <nx_rt_fast_field>
  401cb2:	mov    %rax,%r15
  401cb5:	jmp    401c80 <nx_string_reverse+0x10>
  401cb7:	cmp    $0x2,%eax
  401cba:	jne    401cc5 <nx_string_reverse+0x55>
  401cbc:	mov    %r14,%rax
  401cbf:	pop    %rbx
  401cc0:	pop    %r14
  401cc2:	pop    %r15
  401cc4:	retq   
  401cc5:	mov    %rbx,%rdi
  401cc8:	mov    $0x1,%esi
  401ccd:	pop    %rbx
  401cce:	pop    %r14
  401cd0:	pop    %r15
  401cd2:	jmpq   402540 <nx_rt_fail>

Disassembly of section .fini:
