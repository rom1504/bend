
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004037a0 <nx_rt_rebuild2_c3_k0>:
  4037a0:	push   %r13
  4037a2:	mov    %rsi,%r10
  4037a5:	mov    %rdx,%r8
  4037a8:	movabs $0xffffffffff,%r9
  4037b2:	push   %r12
  4037b4:	and    %r10,%r9
  4037b7:	push   %rbp
  4037b8:	lea    0x0(,%r9,8),%rax
  4037c0:	push   %rbx
  4037c1:	mov    %rdi,%rbx
  4037c4:	sub    $0x28,%rsp
  4037c8:	mov    (%rdi),%rdi
  4037cb:	mov    0x8(%rbx),%rsi
  4037cf:	lea    (%rdi,%rax,1),%rdx
  4037d3:	test   %r10,%r10
  4037d6:	js     403840 <nx_rt_rebuild2_c3_k0+0xa0>
  4037d8:	mov    (%rdx),%r12
  4037db:	mov    0x8(%rdi,%rax,1),%rbp
  4037e0:	cmp    $0x310817f,%r9
  4037e7:	jbe    403818 <nx_rt_rebuild2_c3_k0+0x78>
  4037e9:	mov    %rbp,0x10(%rbx)
  4037ed:	mov    %r12,%rcx
  4037f0:	mov    $0x3,%edx
  4037f5:	movq   $0xffffffffffffffff,0x18(%rbx)
  4037fd:	movl   $0x1,0x20(%rbx)
  403804:	add    $0x28,%rsp
  403808:	pop    %rbx
  403809:	pop    %rbp
  40380a:	pop    %r12
  40380c:	pop    %r13
  40380e:	jmpq   401fd0 <nx_construct2>
  403813:	nopl   0x0(%rax,%rax,1)
  403818:	mov    0x8(%rsi),%r9
  40381c:	test   %r9,%r9
  40381f:	je     40188c <nx_rt_rebuild2_c3_k0.cold>
  403825:	mov    (%rdi,%r9,8),%rax
  403829:	subq   $0x2,0x108(%rsi)
  403831:	mov    %rax,0x8(%rsi)
  403835:	jmp    4037e9 <nx_rt_rebuild2_c3_k0+0x49>
  403837:	nopw   0x0(%rax,%rax,1)
  403840:	mov    0x4(%rdx),%eax
  403843:	mov    (%rdx),%ecx
  403845:	shl    $0x20,%rax
  403849:	or     %rcx,%rax
  40384c:	mov    %rax,%r13
  40384f:	and    $0xffffff,%eax
  403854:	shr    $0x18,%r13
  403858:	lea    0x0(,%r13,8),%r11
  403860:	lea    (%rdi,%r11,1),%rbp
  403864:	lea    0x8(%rdi,%r11,1),%r11
  403869:	cmp    $0x1,%rax
  40386d:	jne    4018d2 <nx_rt_rebuild2_c3_k0.cold+0x46>
  403873:	mov    (%rdx),%eax
  403875:	mov    (%rsi),%rax
  403878:	mov    0x0(%rbp),%r12
  40387c:	mov    (%r11),%rbp
  40387f:	mov    %rax,(%rdx)
  403882:	mov    0x100(%rsi),%rax
  403889:	mov    0x3d949(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40388f:	mov    %r9,(%rsi)
  403892:	add    $0x1,%rax
  403896:	mov    %rax,0x100(%rsi)
  40389d:	cmp    %rdx,%rax
  4038a0:	jae    4018bc <nx_rt_rebuild2_c3_k0.cold+0x30>
  4038a6:	mov    %r13,%r9
  4038a9:	jmpq   4037e0 <nx_rt_rebuild2_c3_k0+0x40>

Disassembly of section .fini:
