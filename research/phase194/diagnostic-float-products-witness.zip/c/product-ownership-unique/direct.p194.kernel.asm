    9b40:	test   %rsi,%rsi
    9b43:	je     9bce <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x8e>
    9b49:	mov    %rsi,%rdi
    9b4c:	mov    %rsi,%rax
    9b4f:	and    $0x3,%rdi
    9b53:	je     9b7c <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x3c>
    9b55:	mov    %edx,%r8d
    9b58:	nopl   0x0(%rax,%rax,1)
    9b60:	dec    %rax
    9b63:	lea    0x1(%r8),%edx
    9b67:	add    %ecx,%r8d
    9b6a:	xor    $0x7,%r8d
    9b6e:	lea    (%rcx,%rcx,2),%ecx
    9b71:	add    %r8d,%ecx
    9b74:	mov    %edx,%r8d
    9b77:	dec    %rdi
    9b7a:	jne    9b60 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x20>
    9b7c:	cmp    $0x4,%rsi
    9b80:	jb     9bce <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x8e>
    9b82:	data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
    9b90:	lea    (%rdx,%rcx,1),%esi
    9b93:	xor    $0x7,%esi
    9b96:	lea    (%rcx,%rcx,2),%ecx
    9b99:	add    %esi,%ecx
    9b9b:	mov    %edx,%esi
    9b9d:	lea    (%rsi,%rcx,1),%edi
    9ba0:	inc    %edi
    9ba2:	xor    $0x7,%edi
    9ba5:	lea    (%rcx,%rcx,2),%ecx
    9ba8:	add    %edi,%ecx
    9baa:	lea    (%rsi,%rcx,1),%edi
    9bad:	add    $0x2,%edi
    9bb0:	xor    $0x7,%edi
    9bb3:	lea    (%rcx,%rcx,2),%ecx
    9bb6:	add    %edi,%ecx
    9bb8:	add    $0x4,%edx
    9bbb:	add    %ecx,%esi
    9bbd:	add    $0x3,%esi
    9bc0:	xor    $0x7,%esi
    9bc3:	lea    (%rcx,%rcx,2),%ecx
    9bc6:	add    %esi,%ecx
    9bc8:	add    $0xfffffffffffffffc,%rax
    9bcc:	jne    9b90 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x50>
    9bce:	mov    %ecx,%esi
    9bd0:	mov    -0x8(%r14),%eax
    9bd4:	add    $0xfffffffffffffff8,%r14
    9bd8:	lea    0x95b1(%rip),%rcx        # 13190 <wl_tab>
    9bdf:	mov    (%rcx,%rax,8),%rax
    9be3:	mov    $0x1,%edi
    9be8:	jmpq   *%rax
    9bea:	nopw   0x0(%rax,%rax,1)
