  406a30:	endbr64 
  406a34:	push   %rbp
  406a35:	mov    %rsp,%rbp
  406a38:	mov    %rdx,%rax
  406a3b:	mov    %rax,%rdx
  406a3e:	xchg   %ax,%ax
  406a40:	cmp    $0x0,%rsi
  406a44:	je     406a70 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x40>
  406a46:	sub    $0x1,%rsi
  406a4a:	movq   %rdx,%xmm1
  406a4f:	movss  %xmm1,%xmm0
  406a53:	addss  0xf5ad(%rip),%xmm0        # 416008 <_IO_stdin_used+0x8>
  406a5b:	mulss  0xf5a1(%rip),%xmm0        # 416004 <_IO_stdin_used+0x4>
  406a63:	subss  %xmm1,%xmm0
  406a67:	movq   %xmm0,%rax
  406a6c:	mov    %eax,%edx
  406a6e:	jmp    406a40 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x10>
  406a70:	mov    %rdx,%rax
  406a73:	leaveq 
  406a74:	retq   
  406a75:	data16 nopw %cs:0x0(%rax,%rax,1)
