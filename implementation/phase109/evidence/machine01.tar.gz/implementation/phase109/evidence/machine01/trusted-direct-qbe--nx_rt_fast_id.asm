
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402730 <nx_rt_fast_id>:
  402730:	shr    $0x28,%rsi
  402734:	movzwl %si,%eax
  402737:	retq   

Disassembly of section .fini:
