000000000040afd0 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>:
  40afd0:	endbr64 
  40afd4:	push   rbp
  40afd5:	mov    rbp,rsp
  40afd8:	sub    rsp,0x1008
  40afdf:	push   rbx
  40afe0:	push   r12
  40afe2:	push   r13
  40afe4:	mov    rax,rdx
  40afe7:	mov    rdx,rax
  40afea:	mov    ebx,0x0
  40afef:	nop
  40aff0:	cs cs cs mov rax,rsi
  40aff6:	shr    rax,0x28
  40affa:	and    rax,0xffff
  40b000:	cmp    rax,0xa4
  40b006:	je     40b0d9 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x109>
  40b00c:	cmp    rax,0xa5
  40b012:	jne    40b088 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0xb8>
  40b014:	mov    r13,rdx
  40b017:	lea    rdx,[rbp-0x1000]
  40b01e:	mov    r12,rdi
  40b021:	call   4182e0 <p125_rt_take3>
  40b026:	mov    rdx,r13
  40b029:	mov    rdi,r12
  40b02c:	mov    rsi,QWORD PTR [rbp-0x1000]
  40b033:	mov    rcx,QWORD PTR [rbp-0xff8]
  40b03a:	mov    rax,QWORD PTR [rbp-0xff0]
  40b041:	mov    QWORD PTR [rbp-0x1000],rcx
  40b048:	mov    QWORD PTR [rbp-0xff8],rax
  40b04f:	mov    rax,QWORD PTR [rdi+0x10]
  40b053:	mov    QWORD PTR [rax],rcx
  40b056:	mov    rcx,QWORD PTR [rbp-0xff8]
  40b05d:	mov    QWORD PTR [rax+0x8],rcx
  40b061:	mov    QWORD PTR [rax+0x10],0x48
  40b069:	add    rax,0x18
  40b06d:	mov    QWORD PTR [rdi+0x10],rax
  40b071:	add    rbx,0x1
  40b075:	mov    QWORD PTR [rbp-0x1000],rsi
  40b07c:	mov    QWORD PTR [rbp-0xff8],rdx
  40b083:	jmp    40aff0 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x20>
  40b088:	mov    rax,rdx
  40b08b:	mov    QWORD PTR [rbp-0x1000],rax
  40b092:	mov    rbx,rax
  40b095:	mov    rax,QWORD PTR [rdi+0x10]
  40b099:	mov    QWORD PTR [rax],rbx
  40b09c:	mov    QWORD PTR [rax+0x8],0x49
  40b0a4:	add    rax,0x10
  40b0a8:	mov    QWORD PTR [rdi+0x10],rax
  40b0ac:	mov    QWORD PTR [rbp-0x1000],rsi
  40b0b3:	mov    rax,QWORD PTR [rdi+0x10]
  40b0b7:	mov    QWORD PTR [rax],rsi
  40b0ba:	mov    QWORD PTR [rax+0x8],0x4a
  40b0c2:	add    rax,0x10
  40b0c6:	mov    QWORD PTR [rdi+0x10],rax
  40b0ca:	mov    esi,0x4
  40b0cf:	call   412a70 <p111_rt_fail>
  40b0d4:	jmp    40b15d <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x18d>
  40b0d9:	cmp    rbx,0x0
  40b0dd:	je     40b15a <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x18a>
  40b0df:	mov    rcx,QWORD PTR [rdi+0x10]
  40b0e3:	mov    rax,rcx
  40b0e6:	add    rax,0xfffffffffffffff8
  40b0ea:	mov    QWORD PTR [rdi+0x10],rax
  40b0ee:	mov    rax,QWORD PTR [rcx-0x8]
  40b0f2:	cmp    rax,0x48
  40b0f6:	jne    40b14e <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x17e>
  40b0f8:	mov    rax,rcx
  40b0fb:	sub    rax,0x18
  40b0ff:	mov    QWORD PTR [rdi+0x10],rax
  40b103:	mov    rax,QWORD PTR [rax]
  40b106:	sub    rcx,0x10
  40b10a:	mov    rsi,QWORD PTR [rcx]
  40b10d:	mov    ecx,0xffffffff
  40b112:	and    rcx,rdx
  40b115:	imul   rcx,rcx,0xa
  40b119:	mov    edx,0xffffffff
  40b11e:	and    rcx,rdx
  40b121:	mov    edx,0xffffffff
  40b126:	and    rax,rdx
  40b129:	add    rax,rcx
  40b12c:	mov    ecx,0xffffffff
  40b131:	mov    rdx,rax
  40b134:	and    rdx,rcx
  40b137:	mov    QWORD PTR [rbp-0x800],rsi
  40b13e:	mov    QWORD PTR [rbp-0x7f8],rdx
  40b145:	sub    rbx,0x1
  40b149:	jmp    40aff0 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x20>
  40b14e:	mov    esi,0x4
  40b153:	call   412a70 <p111_rt_fail>
  40b158:	jmp    40b15d <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x18d>
  40b15a:	mov    rax,rdx
  40b15d:	pop    r13
  40b15f:	pop    r12
  40b161:	pop    rbx
  40b162:	leave  
  40b163:	ret    
  40b164:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  40b16f:	nop

