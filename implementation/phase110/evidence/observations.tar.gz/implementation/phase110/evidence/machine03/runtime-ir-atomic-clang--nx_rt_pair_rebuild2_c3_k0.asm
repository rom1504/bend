
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403ff0 <nx_rt_pair_rebuild2_c3_k0>:
  403ff0:	push   %r15
  403ff2:	push   %r14
  403ff4:	push   %r13
  403ff6:	push   %r12
  403ff8:	mov    %rdx,%r12
  403ffb:	push   %rbp
  403ffc:	push   %rbx
  403ffd:	movabs $0xffffffffff,%rbx
  404007:	and    %rsi,%rbx
  40400a:	lea    0x0(,%rbx,8),%rdx
  404012:	sub    $0x18,%rsp
  404016:	mov    (%rdi),%rbp
  404019:	mov    0x8(%rdi),%r15
  40401d:	lea    0x0(%rbp,%rdx,1),%rax
  404022:	test   %rsi,%rsi
  404025:	js     4040e0 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  40402b:	mov    (%rax),%r14
  40402e:	mov    0x8(%rbp,%rdx,1),%r13
  404033:	cmp    $0x310817f,%rbx
  40403a:	jbe    4040b0 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  40403c:	lea    0x0(%rbp,%rbx,8),%r8
  404041:	mov    %r14,%rax
  404044:	shr    $0x38,%rax
  404048:	and    $0x7f,%eax
  40404b:	cmp    $0x2,%rax
  40404f:	je     404090 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  404051:	mov    %r12,%rax
  404054:	mov    %r14,(%r8)
  404057:	lea    0x8(%rbp,%rbx,8),%r14
  40405c:	shr    $0x38,%rax
  404060:	and    $0x7f,%eax
  404063:	cmp    $0x2,%rax
  404067:	je     4040a0 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  404069:	movabs $0x200030000000000,%rax
  404073:	mov    %r12,(%r14)
  404076:	mov    %r13,%rdx
  404079:	add    $0x18,%rsp
  40407d:	or     %rbx,%rax
  404080:	pop    %rbx
  404081:	pop    %rbp
  404082:	pop    %r12
  404084:	pop    %r13
  404086:	pop    %r14
  404088:	pop    %r15
  40408a:	retq   
  40408b:	nopl   0x0(%rax,%rax,1)
  404090:	test   %r14,%r14
  404093:	js     404051 <nx_rt_pair_rebuild2_c3_k0+0x61>
  404095:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  40409a:	nopw   0x0(%rax,%rax,1)
  4040a0:	test   %r12,%r12
  4040a3:	js     404069 <nx_rt_pair_rebuild2_c3_k0+0x79>
  4040a5:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  4040aa:	nopw   0x0(%rax,%rax,1)
  4040b0:	mov    0x8(%r15),%rbx
  4040b4:	test   %rbx,%rbx
  4040b7:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  4040bd:	lea    0x0(%rbp,%rbx,8),%r8
  4040c2:	mov    (%r8),%rax
  4040c5:	subq   $0x2,0x108(%r15)
  4040cd:	mov    %rax,0x8(%r15)
  4040d1:	jmpq   404041 <nx_rt_pair_rebuild2_c3_k0+0x51>
  4040d6:	nopw   %cs:0x0(%rax,%rax,1)
  4040e0:	mov    0x4(%rax),%edx
  4040e3:	mov    (%rax),%ecx
  4040e5:	shl    $0x20,%rdx
  4040e9:	or     %rcx,%rdx
  4040ec:	mov    %rdx,%rcx
  4040ef:	and    $0xffffff,%edx
  4040f5:	shr    $0x18,%rcx
  4040f9:	lea    0x8(,%rcx,8),%rdi
  404101:	lea    0x0(%rbp,%rdi,1),%r8
  404106:	lea    -0x8(%rbp,%rdi,1),%rdi
  40410b:	cmp    $0x1,%rdx
  40410f:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  404115:	mov    (%rax),%edx
  404117:	mov    (%r15),%rdx
  40411a:	mov    (%rdi),%r14
  40411d:	mov    (%r8),%r13
  404120:	mov    %rdx,(%rax)
  404123:	mov    0x100(%r15),%rax
  40412a:	mov    0x3e0a8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404130:	mov    %rbx,(%r15)
  404133:	add    $0x1,%rax
  404137:	mov    %rax,0x100(%r15)
  40413e:	cmp    %rdx,%rax
  404141:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  404147:	mov    %rcx,%rbx
  40414a:	jmpq   404033 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
