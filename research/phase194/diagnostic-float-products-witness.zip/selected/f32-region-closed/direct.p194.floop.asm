  4083bb:	push   %rbp
  4083bc:	mov    %rsp,%rbp
  4083bf:	sub    $0x920,%rsp
  4083c6:	mov    %r12,-0x10(%rbp)
  4083ca:	mov    %rdi,%rax
  4083cd:	mov    %rax,%r12
  4083d0:	mov    %rsi,%rax
  4083d3:	mov    %rax,%rdi
  4083d6:	mov    %rdx,%rax
  4083d9:	mov    %rax,%rsi
  4083dc:	mov    %rdi,%rdx
  4083df:	cmp    $0x0,%rdx
  4083e6:	sete   %dl
  4083e9:	movzbl %dl,%edx
  4083ec:	mov    %rdx,%r10
  4083ef:	test   %r10d,%r10d
  4083f2:	je     408404 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x49>
  4083f8:	mov    %rsi,%rax
  4083fb:	mov    -0x10(%rbp),%r12
  4083ff:	mov    %rbp,%rsp
  408402:	pop    %rbp
  408403:	retq   
  408404:	mov    %rdi,%rdx
  408407:	cmp    $0x0,%rdx
  40840e:	setne  %dl
  408411:	movzbl %dl,%edx
  408414:	mov    %rdx,%r10
  408417:	test   %r10d,%r10d
  40841a:	je     40846e <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0xb3>
  408420:	mov    %rdi,%rdx
  408423:	sub    $0x1,%rdx
  40842a:	movabs $0x3e800000,%r10
  408434:	movd   %r10d,%xmm1
  408439:	movd   %esi,%xmm2
  40843d:	addss  %xmm1,%xmm2
  408441:	movabs $0x40000000,%r10
  40844b:	movd   %r10d,%xmm1
  408450:	movaps %xmm2,%xmm3
  408453:	mulss  %xmm1,%xmm3
  408457:	movd   %esi,%xmm1
  40845b:	movaps %xmm3,%xmm0
  40845e:	subss  %xmm1,%xmm0
  408462:	movd   %xmm0,%esi
  408466:	mov    %rdx,%rdi
  408469:	jmpq   4083dc <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x21>
  40846e:	mov    %r12,%rdi
  408471:	movabs $0x4,%rsi
  40847b:	mov    %esi,%esi
  40847d:	xor    %eax,%eax
  40847f:	callq  415340 <p111_rt_fail>
  408484:	mov    %rax,-0x8c8(%rbp)
  40848b:	movabs $0x0,%rax
  408495:	mov    -0x10(%rbp),%r12
  408499:	mov    %rbp,%rsp
  40849c:	pop    %rbp
  40849d:	retq   
