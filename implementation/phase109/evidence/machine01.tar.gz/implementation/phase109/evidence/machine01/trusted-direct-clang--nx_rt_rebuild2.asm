
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004029e0 <nx_rt_rebuild2>:
  4029e0:	movabs $0xffffffffff,%r9
  4029ea:	push   %r14
  4029ec:	push   %r13
  4029ee:	and    %rsi,%r9
  4029f1:	mov    %edx,%r13d
  4029f4:	push   %r12
  4029f6:	lea    0x0(,%r9,8),%rdx
  4029fe:	push   %rbp
  4029ff:	mov    %ecx,%ebp
  402a01:	push   %rbx
  402a02:	mov    %rdi,%rbx
  402a05:	sub    $0x20,%rsp
  402a09:	mov    (%rdi),%rdi
  402a0c:	mov    0x8(%rbx),%r12
  402a10:	lea    (%rdi,%rdx,1),%rax
  402a14:	test   %rsi,%rsi
  402a17:	js     402a98 <nx_rt_rebuild2+0xb8>
  402a19:	mov    (%rax),%rax
  402a1c:	mov    %rax,0x10(%rsp)
  402a21:	mov    0x8(%rdi,%rdx,1),%rax
  402a26:	mov    %rax,0x18(%rsp)
  402a2b:	cmp    $0x310817f,%r9
  402a32:	jbe    402a70 <nx_rt_rebuild2+0x90>
  402a34:	mov    $0x1,%eax
  402a39:	mov    0x10(%rsp,%rbp,8),%rcx
  402a3e:	mov    %r13d,%edx
  402a41:	mov    %r12,%rsi
  402a44:	sub    %ebp,%eax
  402a46:	movq   $0xffffffffffffffff,0x18(%rbx)
  402a4e:	mov    0x10(%rsp,%rax,8),%rax
  402a53:	movl   $0x1,0x20(%rbx)
  402a5a:	mov    %rax,0x10(%rbx)
  402a5e:	add    $0x20,%rsp
  402a62:	pop    %rbx
  402a63:	pop    %rbp
  402a64:	pop    %r12
  402a66:	pop    %r13
  402a68:	pop    %r14
  402a6a:	jmpq   401c80 <nx_construct2>
  402a6f:	nop
  402a70:	mov    0x8(%r12),%r9
  402a75:	test   %r9,%r9
  402a78:	je     401651 <nx_rt_rebuild2.cold>
  402a7e:	mov    (%rdi,%r9,8),%rax
  402a82:	subq   $0x2,0x108(%r12)
  402a8b:	mov    %rax,0x8(%r12)
  402a90:	jmp    402a34 <nx_rt_rebuild2+0x54>
  402a92:	nopw   0x0(%rax,%rax,1)
  402a98:	mov    0x4(%rax),%edx
  402a9b:	mov    (%rax),%ecx
  402a9d:	shl    $0x20,%rdx
  402aa1:	or     %rcx,%rdx
  402aa4:	mov    %rdx,%r14
  402aa7:	and    $0xffffff,%edx
  402aad:	shr    $0x18,%r14
  402ab1:	lea    0x0(,%r14,8),%r10
  402ab9:	lea    (%rdi,%r10,1),%r11
  402abd:	lea    0x8(%rdi,%r10,1),%r10
  402ac2:	cmp    $0x1,%rdx
  402ac6:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402acc:	mov    (%rax),%edx
  402ace:	mov    (%r11),%rdx
  402ad1:	mov    %rdx,0x10(%rsp)
  402ad6:	mov    (%r10),%rdx
  402ad9:	mov    %rdx,0x18(%rsp)
  402ade:	mov    (%r12),%rdx
  402ae2:	mov    %rdx,(%rax)
  402ae5:	mov    0x100(%r12),%rax
  402aed:	mov    0x46e5(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402af3:	mov    %r9,(%r12)
  402af7:	add    $0x1,%rax
  402afb:	mov    %rax,0x100(%r12)
  402b03:	cmp    %rdx,%rax
  402b06:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402b0c:	mov    %r14,%r9
  402b0f:	jmpq   402a2b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
