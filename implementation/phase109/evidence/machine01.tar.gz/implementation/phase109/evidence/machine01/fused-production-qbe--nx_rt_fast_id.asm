
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403180 <nx_rt_fast_id>:
  403180:	endbr64 
  403184:	push   %rbp
  403185:	mov    %rsp,%rbp
  403188:	mov    %rsi,%rdi
  40318b:	callq  401b30 <term_aux>
  403190:	leaveq 
  403191:	retq   

Disassembly of section .fini:
