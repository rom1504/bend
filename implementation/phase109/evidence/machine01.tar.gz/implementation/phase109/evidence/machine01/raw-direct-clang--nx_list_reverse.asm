
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401870 <nx_list_reverse>:
  401870:	push   %r15
  401872:	push   %r14
  401874:	push   %r12
  401876:	push   %rbx
  401877:	push   %rax
  401878:	mov    %rdx,%rbx
  40187b:	mov    %rsi,%r15
  40187e:	mov    %rdi,%r14
  401881:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  401890:	callq  4021f0 <nx_rt_id>
  401895:	test   %eax,%eax
  401897:	je     4018ef <nx_list_reverse+0x7f>
  401899:	mov    %r14,%rdi
  40189c:	mov    %r15,%rsi
  40189f:	callq  4021f0 <nx_rt_id>
  4018a4:	cmp    $0x1,%eax
  4018a7:	jne    4018fe <nx_list_reverse+0x8e>
  4018a9:	mov    %r14,%rdi
  4018ac:	mov    %r15,%rsi
  4018af:	callq  402530 <nx_rt_take2>
  4018b4:	mov    %r14,%rdi
  4018b7:	xor    %esi,%esi
  4018b9:	callq  4026c0 <nx_rt_field>
  4018be:	mov    %rax,%r12
  4018c1:	mov    %r14,%rdi
  4018c4:	mov    $0x1,%esi
  4018c9:	callq  4026c0 <nx_rt_field>
  4018ce:	mov    %rax,%r15
  4018d1:	mov    %r14,%rdi
  4018d4:	mov    $0x1,%esi
  4018d9:	mov    %r12,%rdx
  4018dc:	mov    %rbx,%rcx
  4018df:	callq  4024a0 <nx_rt_build2>
  4018e4:	mov    %rax,%rbx
  4018e7:	mov    %r14,%rdi
  4018ea:	mov    %r15,%rsi
  4018ed:	jmp    401890 <nx_list_reverse+0x20>
  4018ef:	mov    %rbx,%rax
  4018f2:	add    $0x8,%rsp
  4018f6:	pop    %rbx
  4018f7:	pop    %r12
  4018f9:	pop    %r14
  4018fb:	pop    %r15
  4018fd:	retq   
  4018fe:	mov    %r14,%rdi
  401901:	mov    $0x1,%esi
  401906:	add    $0x8,%rsp
  40190a:	pop    %rbx
  40190b:	pop    %r12
  40190d:	pop    %r14
  40190f:	pop    %r15
  401911:	jmpq   402230 <nx_rt_fail>

Disassembly of section .fini:
