#define NATIVE_READONLY_OBSERVERS 1
#define NATIVE_PACK_CTORS 1
#define NATIVE_TYPED_SCALARS 0
#define NATIVE_COLD_USER_CTORS 0
#define NATIVE_SCALAR_ARRAYS 0
#define NATIVE_UNSHARED_ARRAYS 0

// Imports
// =======

#pragma clang fp contract(off)

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(__CUDACC_RTC__)
#ifndef __APPLE__
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
// #include, not #import: bend -o reads an #import as an effect's framework
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

#ifdef __METAL_VERSION__
// coherent(device) (MSL 3.2): M1-class parts else lose stores across
// threadgroups within a dispatch
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#define DEVL    coherent(device) device
#else
#define DEV     device
#define DEVL    device
#endif
#define GA32    threadgroup atomic_uint
#define THR     thread
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define A32(p)  ((DEV atomic_uint*)(p))
#define RLX     memory_order_relaxed
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)

#define g32_ini(p)    atomic_store_explicit(p, 0, RLX)
#define g32_add(p, v) atomic_fetch_add_explicit(p, v, RLX)
#define g32_get(p)    atomic_load_explicit(p, RLX)
#else
#define DEVL
#define THR
#define INLINE  static inline
#define CONSTV  static const

#define g32_ini(p)    a32_store(p, 0)
#define g32_add(p, v) a32_add(p, v)
#define g32_get(p)    a32_load(p)
#ifdef __CUDACC_RTC__
// plain data stays L1-cacheable: cross-lane handoffs go through a32 + FENCE
#define DEV
#define GA32    __shared__ u32
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#define DEV
// only clang 19+ has both, and only it compiles preserve_most soundly
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#endif
#endif
#define FAR static __attribute__((noinline))

// A segment: a case of the device's switch; on the host, a preserve_none
// function (WL_SIG) left by a musttail call, its words fresh at WL_OPEN.
#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Reply
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue
#define WL_POP()    { sp -= LANE_STEP; WL_DYN((Fid)STK(0)); }

#define LANE_STEP (DEVICE ? (int64_t)CUBE : 1)
#define STK(I)    sp[(int64_t)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); WL_POP(); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  Loc wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + HEAP_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
typedef float f32;
#elif defined(__CUDACC_RTC__)
typedef unsigned long long u64;
typedef long long          int64_t;
typedef unsigned int       u32;
typedef unsigned char      u8;
typedef float              f32;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
typedef float    f32;
#endif

typedef u64 Loc;
#define LOC_MASK ((1ull << 40) - 1)

typedef u32 Cls;
typedef u32 Fid;

typedef u64 Term;
#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)

#define RFC_BIT  (1ull << 63)
#define RFC_CNT  ((1u << 24) - 1)

typedef Term Reply;

typedef u32 Err;
#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

typedef u32 Ring;

typedef DEV u64* Corpus;

typedef struct {
  Corpus   mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

typedef DEVL Term* Stk;

typedef Term Nat;
#define NAT_IMM ((1ull << 48) - 1)

typedef Term U32;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

#ifdef __METAL_VERSION__
typedef threadgroup atomic_uint* Cur;
#else
typedef u32* Cur;
#endif

// Constants
// =========

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define ALC_WORDS NCLS_ALL
#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * ALC_WORDS)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

#if !DEVICE

typedef pthread_mutex_t lock;

static Corpus CORPUS;
static u64    ALC[CUBE_T + 1][3 * ALC_WORDS] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
// the bag: 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the device)
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32            pool_size;
static _Atomic u32    pool_row;
static bool           pool_grow;
static _Atomic u64    pool_tick;
static _Atomic u32    pool_done;
static lock           pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t pool_wake = PTHREAD_COND_INITIALIZER;

// The device program compiles from the binary's own text.
#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static Stk  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --help            show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define FID_109_97_105_110_ 0
#define FID_110_97_116_105_118_101_95_107_95_49_48_50_55_ 1
#define FID_110_97_116_105_118_101_95_107_95_49_48_50_56_ 2
#define FID_110_97_116_105_118_101_95_107_95_49_48_50_57_ 3
#define FID_110_97_116_105_118_101_95_107_95_49_48_51_49_ 4
#define FID_73_79_46_98_105_110_100_ 5
#define FID_110_97_116_105_118_101_95_107_95_50_48_54_48_ 6
#define FID_110_97_116_105_118_101_95_107_95_50_48_54_49_ 7
#define FID_110_97_116_105_118_101_95_107_95_50_48_54_50_ 8
#define FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_ 9
#define FID_110_97_116_105_118_101_95_107_95_50_48_55_48_ 10
#define FID_110_97_116_105_118_101_95_107_95_50_48_55_49_ 11
#define FID_110_97_116_105_118_101_95_107_95_50_48_55_52_ 12
#define FID_73_79_46_97_114_103_115_ 13
#define FID_110_97_116_105_118_101_95_107_95_51_49_48_50_ 14
#define FID_36_100_105_114_101_99_116_46_73_79_46_97_114_103_115_ 15
#define FID_99_108_105_95_109_97_105_110_ 16
#define FID_110_97_116_105_118_101_95_107_95_52_49_51_49_ 17
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_109_97_105_110_ 18
#define FID_110_97_116_105_118_101_95_107_95_52_49_51_54_ 19
#define FID_110_97_116_105_118_101_95_107_95_52_49_52_49_ 20
#define FID_110_97_116_105_118_101_95_107_95_52_49_52_50_ 21
#define FID_110_97_116_105_118_101_95_107_95_52_49_52_54_ 22
#define FID_99_108_105_95_100_105_115_112_97_116_99_104_ 23
#define FID_110_97_116_105_118_101_95_107_95_53_49_55_50_ 24
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_115_112_97_116_99_104_ 25
#define FID_110_97_116_105_118_101_95_107_95_53_49_56_51_ 26
#define FID_110_97_116_105_118_101_95_107_95_53_49_56_53_ 27
#define FID_110_97_116_105_118_101_95_107_95_53_49_57_48_ 28
#define FID_110_97_116_105_118_101_95_107_95_53_49_57_49_ 29
#define FID_110_97_116_105_118_101_95_107_95_53_49_57_50_ 30
#define FID_110_97_116_105_118_101_95_107_95_53_49_57_52_ 31
#define FID_110_97_116_105_118_101_95_107_95_53_49_57_55_ 32
#define FID_110_97_116_105_118_101_95_107_95_53_50_48_49_ 33
#define FID_110_97_116_105_118_101_95_107_95_53_50_48_50_ 34
#define FID_110_97_116_105_118_101_95_107_95_53_50_48_54_ 35
#define FID_110_97_116_105_118_101_95_107_95_53_50_48_55_ 36
#define FID_110_97_116_105_118_101_95_107_95_53_50_48_56_ 37
#define FID_110_97_116_105_118_101_95_107_95_53_50_49_48_ 38
#define FID_110_97_116_105_118_101_95_107_95_53_50_49_51_ 39
#define FID_110_97_116_105_118_101_95_107_95_53_50_49_55_ 40
#define FID_110_97_116_105_118_101_95_107_95_53_50_50_54_ 41
#define FID_73_79_46_100_105_101_ 42
#define FID_110_97_116_105_118_101_95_107_95_54_50_53_52_ 43
#define FID_110_97_116_105_118_101_95_107_95_54_50_53_53_ 44
#define FID_110_97_116_105_118_101_95_107_95_54_50_53_54_ 45
#define FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_ 46
#define FID_83_116_114_105_110_103_46_97_112_112_101_110_100_ 47
#define FID_110_97_116_105_118_101_95_107_95_55_50_57_49_ 48
#define FID_110_97_116_105_118_101_95_107_95_55_50_57_50_ 49
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_97_112_112_101_110_100_ 50
#define FID_110_97_116_105_118_101_95_107_95_55_51_49_48_ 51
#define FID_110_97_116_105_118_101_95_107_95_55_51_49_51_ 52
#define FID_99_108_105_95_104_101_108_112_ 53
#define FID_73_79_46_112_114_105_110_116_ 54
#define FID_110_97_116_105_118_101_95_107_95_57_51_54_50_ 55
#define FID_110_97_116_105_118_101_95_107_95_57_51_54_51_ 56
#define FID_36_100_105_114_101_99_116_46_73_79_46_112_114_105_110_116_ 57
#define FID_73_79_46_112_117_114_101_ 58
#define FID_110_97_116_105_118_101_95_107_95_49_48_51_57_53_ 59
#define FID_110_97_116_105_118_101_95_107_95_49_48_51_57_54_ 60
#define FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_ 61
#define FID_99_108_105_95_114_101_113_117_101_115_116_ 62
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_50_57_ 63
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_51_48_ 64
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_51_49_ 65
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_113_117_101_115_116_ 66
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_48_ 67
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_49_ 68
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_ 69
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_52_ 70
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_56_ 71
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_57_ 72
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_53_48_ 73
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_53_50_ 74
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_ 75
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_53_55_ 76
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_53_56_ 77
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_54_48_ 78
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_54_52_ 79
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_54_53_ 80
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_54_54_ 81
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_54_56_ 82
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_55_50_ 83
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_55_51_ 84
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_55_52_ 85
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_55_54_ 86
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_56_48_ 87
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_56_49_ 88
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_56_50_ 89
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_56_52_ 90
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_56_56_ 91
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_56_57_ 92
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_57_48_ 93
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_57_50_ 94
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_57_54_ 95
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_57_55_ 96
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_57_56_ 97
#define FID_110_97_116_105_118_101_95_107_95_49_49_53_48_48_ 98
#define FID_110_97_116_105_118_101_95_107_95_49_49_53_48_51_ 99
#define FID_110_97_116_105_118_101_95_107_95_49_49_53_48_56_ 100
#define FID_110_97_116_105_118_101_95_107_95_49_49_53_49_49_ 101
#define FID_110_97_116_105_118_101_95_107_95_49_49_53_50_48_ 102
#define FID_110_97_116_105_118_101_95_107_95_49_49_53_50_57_ 103
#define FID_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_ 104
#define FID_110_97_116_105_118_101_95_107_95_49_50_53_53_52_ 105
#define FID_110_97_116_105_118_101_95_107_95_49_50_53_53_53_ 106
#define FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_ 107
#define FID_99_108_105_95_112_97_115_115_ 108
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_56_54_ 109
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_115_115_ 110
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_57_49_ 111
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_57_57_ 112
#define FID_110_97_116_105_118_101_95_107_95_49_51_54_48_51_ 113
#define FID_110_97_116_105_118_101_95_107_95_49_51_54_48_54_ 114
#define FID_99_108_105_95_97_115_115_101_116_ 115
#define FID_110_97_116_105_118_101_95_107_95_49_52_54_51_51_ 116
#define FID_110_97_116_105_118_101_95_107_95_49_52_54_51_52_ 117
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_97_115_115_101_116_ 118
#define FID_110_97_116_105_118_101_95_107_95_49_52_55_49_50_ 119
#define FID_110_97_116_105_118_101_95_107_95_49_52_55_50_52_ 120
#define FID_99_108_105_95_100_105_103_101_115_116_ 121
#define FID_110_97_116_105_118_101_95_107_95_49_53_55_53_48_ 122
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_103_101_115_116_ 123
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_50_54_ 124
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_50_57_ 125
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_51_50_ 126
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_51_53_ 127
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_51_56_ 128
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_52_49_ 129
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_52_52_ 130
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_52_55_ 131
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_53_48_ 132
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_53_51_ 133
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_53_54_ 134
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_53_57_ 135
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_54_50_ 136
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_54_53_ 137
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_54_56_ 138
#define FID_110_97_116_105_118_101_95_107_95_49_54_56_55_49_ 139
#define FID_107_99_ 140
#define FID_110_97_116_105_118_101_95_107_95_49_55_56_57_57_ 141
#define FID_110_97_116_105_118_101_95_107_95_49_55_57_48_48_ 142
#define FID_110_97_116_105_118_101_95_107_95_49_55_57_48_49_ 143
#define FID_36_100_105_114_101_99_116_46_107_99_ 144
#define FID_110_97_116_105_118_101_95_107_95_49_55_57_49_57_ 145
#define FID_110_97_116_105_118_101_95_107_95_49_55_57_50_50_ 146
#define FID_110_97_116_105_118_101_95_107_95_49_55_57_50_53_ 147
#define FID_83_116_114_105_110_103_46_101_113_ 148
#define FID_110_97_116_105_118_101_95_107_95_49_56_57_53_50_ 149
#define FID_110_97_116_105_118_101_95_107_95_49_56_57_53_51_ 150
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_101_113_ 151
#define FID_67_109_112_46_105_115_95_101_113_ 152
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_56_54_ 153
#define FID_36_100_105_114_101_99_116_46_67_109_112_46_105_115_95_101_113_ 154
#define FID_83_116_114_105_110_103_46_111_114_100_101_114_ 155
#define FID_110_97_116_105_118_101_95_107_95_50_49_48_49_52_ 156
#define FID_110_97_116_105_118_101_95_107_95_50_49_48_49_53_ 157
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_111_114_100_101_114_ 158
#define FID_80_97_105_114_46_115_110_100_ 159
#define FID_110_97_116_105_118_101_95_107_95_50_50_48_52_56_ 160
#define FID_36_100_105_114_101_99_116_46_80_97_105_114_46_115_110_100_ 161
#define FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_ 162
#define FID_83_116_114_105_110_103_46_99_109_112_ 163
#define FID_110_97_116_105_118_101_95_107_95_50_51_48_56_49_ 164
#define FID_110_97_116_105_118_101_95_107_95_50_51_48_56_50_ 165
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_ 166
#define FID_110_97_116_105_118_101_95_107_95_50_51_49_48_49_ 167
#define FID_110_97_116_105_118_101_95_107_95_50_51_49_50_53_ 168
#define FID_110_97_116_105_118_101_95_107_95_50_51_49_50_56_ 169
#define FID_110_97_116_105_118_101_95_107_95_50_51_49_51_49_ 170
#define FID_83_116_114_105_110_103_46_99_109_112_46_102_105_110_ 171
#define FID_110_97_116_105_118_101_95_107_95_50_52_49_53_57_ 172
#define FID_110_97_116_105_118_101_95_107_95_50_52_49_54_48_ 173
#define FID_110_97_116_105_118_101_95_107_95_50_52_49_54_49_ 174
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_102_105_110_ 175
#define FID_110_97_116_105_118_101_95_107_95_50_52_50_48_53_ 176
#define FID_110_97_116_105_118_101_95_107_95_50_52_50_48_56_ 177
#define FID_110_97_116_105_118_101_95_107_95_50_52_50_49_49_ 178
#define FID_110_97_116_105_118_101_95_107_95_50_52_50_49_52_ 179
#define FID_83_116_114_105_110_103_46_99_109_112_46_114_101_99_ 180
#define FID_110_97_116_105_118_101_95_107_95_50_53_50_52_50_ 181
#define FID_110_97_116_105_118_101_95_107_95_50_53_50_52_51_ 182
#define FID_110_97_116_105_118_101_95_107_95_50_53_50_52_52_ 183
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_114_101_99_ 184
#define FID_110_97_116_105_118_101_95_107_95_50_53_50_55_48_ 185
#define FID_110_97_116_105_118_101_95_107_95_50_53_50_55_51_ 186
#define FID_110_97_116_105_118_101_95_107_95_50_53_50_55_54_ 187
#define FID_67_104_97_114_46_99_109_112_ 188
#define FID_110_97_116_105_118_101_95_107_95_50_54_51_48_51_ 189
#define FID_110_97_116_105_118_101_95_107_95_50_54_51_48_52_ 190
#define FID_36_100_105_114_101_99_116_46_67_104_97_114_46_99_109_112_ 191
#define FID_110_97_116_105_118_101_95_107_95_50_54_51_50_52_ 192
#define FID_110_97_116_105_118_101_95_107_95_50_54_51_50_55_ 193
#define FID_110_97_116_105_118_101_95_107_95_50_54_51_51_48_ 194
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_99_109_112_ 195
#define FID_110_97_116_105_118_101_95_107_95_50_55_51_53_53_ 196
#define FID_110_97_116_105_118_101_95_107_95_50_55_51_53_54_ 197
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_99_109_112_ 198
#define FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_ 199
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_56_53_ 200
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_ 201
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_57_49_ 202
#define FID_99_108_105_95_114_101_97_100_ 203
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_49_56_ 204
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_49_57_ 205
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_ 206
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_50_54_ 207
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_50_55_ 208
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_50_56_ 209
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_51_48_ 210
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_51_54_ 211
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_51_57_ 212
#define FID_110_97_116_105_118_101_95_107_95_50_57_52_52_50_ 213
#define FID_78_97_116_105_118_101_72_111_115_116_46_114_101_97_100_ 214
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_54_55_ 215
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_54_56_ 216
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_54_57_ 217
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_55_48_ 218
#define FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_114_101_97_100_ 219
#define FID_99_108_105_95_114_101_97_100_95_100_111_110_101_ 220
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_ 221
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_48_55_ 222
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_95_100_111_110_101_ 223
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_49_54_ 224
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_51_55_ 225
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_52_49_ 226
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_52_52_ 227
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_52_55_ 228
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_53_48_ 229
#define FID_78_97_116_105_118_101_72_111_115_116_46_112_117_98_108_105_115_104_ 230
#define FID_110_97_116_105_118_101_95_107_95_51_50_53_55_53_ 231
#define FID_110_97_116_105_118_101_95_107_95_51_50_53_55_54_ 232
#define FID_110_97_116_105_118_101_95_107_95_51_50_53_55_55_ 233
#define FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_112_117_98_108_105_115_104_ 234
#define FID_99_108_105_95_112_97_114_115_101_ 235
#define FID_110_97_116_105_118_101_95_107_95_51_51_54_49_48_ 236
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_114_115_101_ 237
#define FID_110_97_116_105_118_101_95_107_95_51_51_55_53_56_ 238
#define FID_110_97_116_105_118_101_95_107_95_51_51_55_54_49_ 239
#define FID_99_108_105_95_111_112_116_105_111_110_115_ 240
#define FID_110_97_116_105_118_101_95_107_95_51_52_56_48_52_ 241
#define FID_110_97_116_105_118_101_95_107_95_51_52_56_48_53_ 242
#define FID_110_97_116_105_118_101_95_107_95_51_52_56_48_54_ 243
#define FID_110_97_116_105_118_101_95_107_95_51_52_56_48_55_ 244
#define FID_110_97_116_105_118_101_95_107_95_51_52_56_48_56_ 245
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_ 246
#define FID_110_97_116_105_118_101_95_107_95_51_52_56_57_57_ 247
#define FID_110_97_116_105_118_101_95_107_95_51_53_50_48_56_ 248
#define FID_110_97_116_105_118_101_95_107_95_51_53_50_55_55_ 249
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_54_52_ 250
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_54_55_ 251
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_55_50_ 252
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_55_53_ 253
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_55_56_ 254
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_56_49_ 255
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_56_52_ 256
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_56_55_ 257
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_57_48_ 258
#define FID_110_97_116_105_118_101_95_107_95_51_53_51_57_51_ 259
#define FID_36_110_97_116_105_118_101_46_66_111_111_108_46_111_114_ 260
#define FID_110_97_116_105_118_101_95_107_95_51_54_52_49_56_ 261
#define FID_110_97_116_105_118_101_95_107_95_51_54_52_49_57_ 262
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_66_111_111_108_46_111_114_ 263
#define FID_66_111_111_108_46_97_110_100_ 264
#define FID_110_97_116_105_118_101_95_107_95_51_55_52_52_57_ 265
#define FID_110_97_116_105_118_101_95_107_95_51_55_52_53_48_ 266
#define FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_ 267
#define FID_110_97_116_105_118_101_95_107_95_51_55_52_54_48_ 268
#define FID_110_97_116_105_118_101_95_107_95_51_55_52_54_51_ 269
#define FID_66_111_111_108_46_110_111_116_ 270
#define FID_110_97_116_105_118_101_95_107_95_51_56_52_56_57_ 271
#define FID_36_100_105_114_101_99_116_46_66_111_111_108_46_110_111_116_ 272
#define FID_110_97_116_105_118_101_95_107_95_51_56_52_57_51_ 273
#define FID_99_108_105_95_111_117_116_112_117_116_ 274
#define FID_110_97_116_105_118_101_95_107_95_51_57_53_50_50_ 275
#define FID_110_97_116_105_118_101_95_107_95_51_57_53_50_51_ 276
#define FID_110_97_116_105_118_101_95_107_95_51_57_53_50_52_ 277
#define FID_110_97_116_105_118_101_95_107_95_51_57_53_50_53_ 278
#define FID_36_100_105_114_101_99_116_46_99_108_105_95_111_117_116_112_117_116_ 279
#define FID_110_97_116_105_118_101_95_107_95_51_57_54_56_48_ 280
#define FID_110_97_116_105_118_101_95_107_95_51_57_54_56_51_ 281
#define FID_110_97_116_105_118_101_95_107_95_51_57_54_57_48_ 282
#define FID_110_97_116_105_118_101_95_107_95_51_57_54_57_51_ 283
#define FID_110_97_116_105_118_101_95_107_95_51_57_54_57_54_ 284
#define FID_110_97_116_105_118_101_95_107_95_51_57_54_57_57_ 285
#define FID_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_ 286
#define FID_110_97_116_105_118_101_95_107_95_52_48_55_50_54_ 287
#define FID_110_97_116_105_118_101_95_107_95_52_48_55_50_55_ 288
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_ 289
#define FID_110_97_116_105_118_101_95_107_95_52_48_55_51_55_ 290
#define FID_110_97_116_105_118_101_95_107_95_52_48_55_53_50_ 291
#define FID_110_97_116_105_118_101_95_107_95_52_48_55_53_53_ 292
#define FID_110_97_116_105_118_101_95_107_95_52_48_55_53_56_ 293
#define FID_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_ 294
#define FID_110_97_116_105_118_101_95_107_95_52_49_55_56_54_ 295
#define FID_110_97_116_105_118_101_95_107_95_52_49_55_56_55_ 296
#define FID_110_97_116_105_118_101_95_107_95_52_49_55_56_56_ 297
#define FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_ 298
#define FID_110_97_116_105_118_101_95_107_95_52_49_55_57_56_ 299
#define FID_67_104_97_114_46_105_115_95_101_113_ 300
#define FID_110_97_116_105_118_101_95_107_95_52_50_56_50_53_ 301
#define FID_110_97_116_105_118_101_95_107_95_52_50_56_50_54_ 302
#define FID_36_100_105_114_101_99_116_46_67_104_97_114_46_105_115_95_101_113_ 303
#define FID_110_97_116_105_118_101_95_107_95_52_50_56_51_56_ 304
#define FID_110_97_116_105_118_101_95_107_95_52_50_56_52_49_ 305
#define FID_110_97_116_105_118_101_95_107_95_52_50_56_52_52_ 306
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_ 307
#define FID_110_97_116_105_118_101_95_107_95_52_51_56_54_57_ 308
#define FID_110_97_116_105_118_101_95_107_95_52_51_56_55_48_ 309
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_ 310
#define FID_IO_EMIT 311
#define BEND_CLO_APPLY 312
#define FID_EXIT 313
#define FID_ENTER 314
#define CID_UNIT 0
#define CID_FALSE 1
#define CID_TRUE 2
#define CID_LT 3
#define CID_EQ 4
#define CID_GT 5
#define CID_INL 6
#define CID_INR 7
#define CID_TUPLE 8
#define CID_ZERO 9
#define CID_SUCC 10
#define CID_NONE 11
#define CID_SOME 12
#define CID_FAIL 13
#define CID_DONE 14
#define CID_READY 15
#define CID_WAIT 16
#define CID_NIL 17
#define CID_CON 18
#define CID_WNIL 19
#define CID_WCON 20
#define CID_U32 21
#define CID_F32 22
#define CID_CHR 23
#define CID_SNIL 24
#define CID_SCON 25
#define CID_ALEAF 26
#define CID_ANODE 27
#define CID_PIX 28
#define CID_QUA 29
#define CID_KEY 30
#define CID_MOUSE 31
#define CID_MOVE 32
#define CID_LOOK 33
#define CID_SCROLL 34
#define CID_CLOSE 35
#define CID_MTIP 36
#define CID_MLEAF 37
#define CID_MNODE 38
#define CID_FILE 39
#define CID_SOCKET 40
#define CID_LISTENER 41
#define CID_WINDOW 42
#define CID_AUDIO 43
#define CID_CHAN 44
#define CID_EMIT 45
#define CID_HALT 46
#define CID_APP 47
#define CID_IO_PRINT 48
#define CID_IO_WRITE 49
#define CID_IO_PRINT_ERR 50
#define CID_IO_GET_ENV 51
#define CID_IO_ARGS 52
#define CID_PROCESS_RUN 53
#define CID_IO_RANDOM_U32 54
#define CID_IO_SPAWN 55
#define CID_IO_SLEEP 56
#define CID_IO_NOW 57
#define CID_IO_THREAD_COUNT 58
#define CID_CHAN_NEW 59
#define CID_CHAN_SEND 60
#define CID_CHAN_RECV 61
#define CID_CHAN_TRY_SEND 62
#define CID_CHAN_TRY_RECV 63
#define CID_CHAN_CLOSE 64
#define CID_FILE_OPEN 65
#define CID_FILE_READ 66
#define CID_FILE_READ_BYTES 67
#define CID_FILE_READ_AT 68
#define CID_FILE_SIZE 69
#define CID_FILE_WRITE 70
#define CID_FILE_WRITE_BYTES 71
#define CID_FILE_CLOSE 72
#define CID_TCP_LISTEN 73
#define CID_TCP_ACCEPT 74
#define CID_TCP_TRY_ACCEPT 75
#define CID_TCP_CONNECT 76
#define CID_TCP_SEND 77
#define CID_TCP_TRY_SEND 78
#define CID_TCP_RECV 79
#define CID_TCP_TRY_RECV 80
#define CID_TCP_SEND_BYTES 81
#define CID_TCP_TRY_SEND_BYTES 82
#define CID_TCP_RECV_BYTES 83
#define CID_TCP_TRY_RECV_BYTES 84
#define CID_UDP_BIND 85
#define CID_UDP_SEND_TO 86
#define CID_UDP_TRY_SEND_TO 87
#define CID_UDP_SEND_BYTES_TO 88
#define CID_UDP_TRY_SEND_BYTES_TO 89
#define CID_UDP_RECV_FROM 90
#define CID_UDP_TRY_RECV_FROM 91
#define CID_UDP_RECV_BYTES_FROM 92
#define CID_UDP_TRY_RECV_BYTES_FROM 93
#define CID_SOCKET_CLOSE 94
#define CID_LISTENER_CLOSE 95
#define CID_WINDOW_OPEN 96
#define CID_WINDOW_FRAME 97
#define CID_WINDOW_SET_TITLE 98
#define CID_WINDOW_GRAB 99
#define CID_WINDOW_CLOSE 100
#define CID_AUDIO_OPEN 101
#define CID_AUDIO_WRITE 102
#define CID_AUDIO_CLOSE 103
#define CID_U32_TO_F32 104
#define CID_F32_TO_U32 105
#define CID_F32_ADD 106
#define CID_F32_SUB 107
#define CID_F32_MUL 108
#define CID_F32_DIV 109
#define CID_F32_MOD 110
#define CID_F32_POW 111
#define CID_F32_ATAN2 112
#define CID_F32_NEG 113
#define CID_F32_ABS 114
#define CID_F32_SQRT 115
#define CID_F32_EXP 116
#define CID_F32_LOG 117
#define CID_F32_LOG2 118
#define CID_F32_LOG10 119
#define CID_F32_SIN 120
#define CID_F32_COS 121
#define CID_F32_TAN 122
#define CID_F32_ASIN 123
#define CID_F32_ACOS 124
#define CID_F32_ATAN 125
#define CID_F32_SINH 126
#define CID_F32_COSH 127
#define CID_F32_TANH 128
#define CID_F32_FLOOR 129
#define CID_F32_CEIL 130
#define CID_F32_TRUNC 131
#define CID_F32_IS_EQ 132
#define CID_F32_IS_NE 133
#define CID_F32_IS_LT 134
#define CID_F32_IS_LE 135
#define CID_F32_IS_GT 136
#define CID_F32_IS_GE 137
#define CID_F32_SHOW 138
#define CID_F32_BITS 139
#define CID_F32_READ 140
#define CID_ARRAY_ATOMIC_ADD 141
#define CID_ARRAY_ATOMIC_MIN 142
#define CID_ARRAY_ATOMIC_MAX 143
#define CID_ARRAY_ATOMIC_AND 144
#define CID_ARRAY_ATOMIC_OR 145
#define CID_ARRAY_ATOMIC_XOR 146
#define CID_ARRAY_ATOMIC_EXCH 147
#define CID_ARRAY_ATOMIC_CAS 148
#define CID_ARRAY_ATOMIC_FADD 149
#define CID_NATIVEHOST_READ 150
#define CID_NATIVEHOST_PATH 151
#define CID_NATIVEHOST_PUBLISH 152
#define CID__CTOR_67_76_73_69_114_114_111_114_ 153
#define CID__CTOR_67_76_73_72_101_108_112_ 154
#define CID__CTOR_67_76_73_86_101_114_115_105_111_110_ 155
#define CID__CTOR_67_76_73_82_101_113_117_101_115_116_ 156
#define WL_RESW 1
#define BANGS 0
#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6, r7;
#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
    if ((N) <= 7) break; r7 = e.mem[(A) + 7]; \
  } while (0);
#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); break; \
    case 1: r1 = (X); break; \
    case 2: r2 = (X); break; \
    case 3: r3 = (X); break; \
    case 4: r4 = (X); break; \
    case 5: r5 = (X); break; \
    case 6: r6 = (X); break; \
    case 7: r7 = (X); break; \
  }
#define WL_SAVE(V) (V)[0] = r0; 
#define WL_TAKE(V) r0 = (V)[0]; 
#define WL_SIG Env e, Stk sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6, Term r7
#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6, r7
CONSTV u8 FID_ARITY_T[] = { 0, 1, 2, 3, 1, 0, 1, 2, 3, 3, 2, 3, 2, 0, 1, 1, 0, 1, 1, 1, 2, 3, 2, 0, 1, 1, 3, 3, 1, 2, 3, 1, 2, 1, 2, 1, 2, 3, 1, 2, 1, 2, 0, 1, 2, 3, 3, 0, 1, 2, 2, 2, 2, 0, 0, 1, 2, 2, 0, 1, 2, 2, 0, 1, 2, 3, 3, 3, 2, 3, 3, 3, 2, 3, 3, 3, 2, 3, 3, 2, 2, 3, 2, 2, 2, 3, 2, 2, 2, 3, 2, 1, 2, 3, 1, 1, 2, 3, 1, 2, 2, 2, 2, 1, 0, 1, 2, 2, 0, 1, 1, 2, 3, 2, 2, 0, 1, 2, 2, 3, 2, 0, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 1, 2, 3, 3, 2, 2, 2, 0, 1, 2, 2, 0, 1, 1, 0, 1, 2, 2, 0, 1, 1, 2, 0, 1, 2, 2, 2, 2, 2, 2, 0, 1, 2, 3, 3, 2, 2, 2, 2, 0, 1, 2, 3, 3, 2, 2, 2, 0, 1, 2, 2, 2, 2, 2, 0, 1, 2, 2, 0, 1, 1, 2, 0, 1, 2, 2, 2, 2, 3, 2, 1, 2, 2, 0, 1, 2, 3, 4, 4, 0, 1, 2, 2, 2, 3, 2, 2, 2, 2, 0, 1, 2, 3, 3, 0, 1, 1, 2, 2, 0, 1, 2, 3, 4, 5, 5, 2, 2, 8, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 1, 2, 2, 0, 1, 2, 2, 2, 2, 0, 1, 1, 2, 0, 1, 2, 3, 4, 4, 2, 2, 2, 2, 2, 2, 0, 1, 2, 2, 2, 2, 2, 2, 0, 1, 2, 3, 3, 2, 0, 1, 2, 2, 2, 2, 2, 0, 1, 2, 2, 1, 2 };
CONSTV u8 FID_FLAG_T[] = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0 };
CONSTV u8 FID_RESW_T[] = { 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 0, 1, 0, 0, 0, 1, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0 };
CONSTV u8 CID_ARITY_T[] = { 0, 0, 0, 0, 0, 0, 1, 1, 2, 0, 1, 0, 1, 1, 1, 1, 1, 0, 2, 0, 2, 1, 1, 1, 0, 2, 1, 2, 1, 4, 2, 4, 2, 2, 4, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 1, 6, 1, 2, 2, 1, 1, 2, 3, 2, 4, 3, 2, 3, 3, 3, 4, 2, 3, 3, 2, 3, 2, 3, 3, 3, 4, 3, 4, 3, 4, 3, 4, 3, 5, 6, 5, 6, 3, 4, 3, 4, 2, 2, 4, 3, 3, 3, 2, 2, 3, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 4, 3, 4, 2, 3, 1, 0, 0, 3, 0 };
CONSTV u8 CID_HOT_T[] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 };
#define STAT_LEN 3788
#define WL_TABLE WL_X(FID_109_97_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_50_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_50_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_50_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_51_49_) WL_X(FID_73_79_46_98_105_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_54_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_54_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_54_50_) WL_X(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_55_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_55_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_55_52_) WL_X(FID_73_79_46_97_114_103_115_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_48_50_) WL_X(FID_36_100_105_114_101_99_116_46_73_79_46_97_114_103_115_) WL_X(FID_99_108_105_95_109_97_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_51_49_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_109_97_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_51_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_52_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_52_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_52_54_) WL_X(FID_99_108_105_95_100_105_115_112_97_116_99_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_55_50_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_115_112_97_116_99_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_56_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_56_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_57_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_57_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_57_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_57_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_57_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_48_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_48_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_48_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_48_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_48_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_49_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_49_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_49_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_50_50_54_) WL_X(FID_73_79_46_100_105_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_53_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_53_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_53_54_) WL_X(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_) WL_X(FID_83_116_114_105_110_103_46_97_112_112_101_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_55_50_57_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_55_50_57_50_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_97_112_112_101_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_55_51_49_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_55_51_49_51_) WL_X(FID_99_108_105_95_104_101_108_112_) WL_X(FID_73_79_46_112_114_105_110_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_57_51_54_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_57_51_54_51_) WL_X(FID_36_100_105_114_101_99_116_46_73_79_46_112_114_105_110_116_) WL_X(FID_73_79_46_112_117_114_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_51_57_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_51_57_54_) WL_X(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_) WL_X(FID_99_108_105_95_114_101_113_117_101_115_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_49_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_113_117_101_115_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_53_49_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_53_50_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_53_50_57_) WL_X(FID_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_50_53_53_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_50_53_53_53_) WL_X(FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_) WL_X(FID_99_108_105_95_112_97_115_115_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_56_54_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_115_115_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_57_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_57_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_54_48_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_54_48_54_) WL_X(FID_99_108_105_95_97_115_115_101_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_54_51_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_54_51_52_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_97_115_115_101_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_55_49_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_55_50_52_) WL_X(FID_99_108_105_95_100_105_103_101_115_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_53_55_53_48_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_103_101_115_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_50_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_50_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_56_55_49_) WL_X(FID_107_99_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_56_57_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_57_48_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_57_48_49_) WL_X(FID_36_100_105_114_101_99_116_46_107_99_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_57_49_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_57_50_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_57_50_53_) WL_X(FID_83_116_114_105_110_103_46_101_113_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_56_57_53_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_56_57_53_51_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_101_113_) WL_X(FID_67_109_112_46_105_115_95_101_113_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_54_) WL_X(FID_36_100_105_114_101_99_116_46_67_109_112_46_105_115_95_101_113_) WL_X(FID_83_116_114_105_110_103_46_111_114_100_101_114_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_49_48_49_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_49_48_49_53_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_111_114_100_101_114_) WL_X(FID_80_97_105_114_46_115_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_50_48_52_56_) WL_X(FID_36_100_105_114_101_99_116_46_80_97_105_114_46_115_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_) WL_X(FID_83_116_114_105_110_103_46_99_109_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_50_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_49_48_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_49_50_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_49_50_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_49_51_49_) WL_X(FID_83_116_114_105_110_103_46_99_109_112_46_102_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_49_53_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_49_54_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_49_54_49_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_102_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_50_48_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_50_48_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_50_49_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_50_49_52_) WL_X(FID_83_116_114_105_110_103_46_99_109_112_46_114_101_99_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_52_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_114_101_99_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_54_) WL_X(FID_67_104_97_114_46_99_109_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_54_51_48_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_54_51_48_52_) WL_X(FID_36_100_105_114_101_99_116_46_67_104_97_114_46_99_109_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_54_51_50_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_54_51_50_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_54_51_51_48_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_99_109_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_55_51_53_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_55_51_53_54_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_99_109_112_) WL_X(FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_56_53_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_57_49_) WL_X(FID_99_108_105_95_114_101_97_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_49_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_49_57_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_52_52_50_) WL_X(FID_78_97_116_105_118_101_72_111_115_116_46_114_101_97_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_55_48_) WL_X(FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_114_101_97_100_) WL_X(FID_99_108_105_95_114_101_97_100_95_100_111_110_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_55_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_95_100_111_110_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_51_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_53_48_) WL_X(FID_78_97_116_105_118_101_72_111_115_116_46_112_117_98_108_105_115_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_55_) WL_X(FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_112_117_98_108_105_115_104_) WL_X(FID_99_108_105_95_112_97_114_115_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_51_54_49_48_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_114_115_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_51_55_53_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_51_55_54_49_) WL_X(FID_99_108_105_95_111_112_116_105_111_110_115_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_56_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_56_57_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_50_48_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_50_55_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_54_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_54_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_57_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_51_57_51_) WL_X(FID_36_110_97_116_105_118_101_46_66_111_111_108_46_111_114_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_54_52_49_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_54_52_49_57_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_66_111_111_108_46_111_114_) WL_X(FID_66_111_111_108_46_97_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_52_52_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_52_53_48_) WL_X(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_52_54_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_52_54_51_) WL_X(FID_66_111_111_108_46_110_111_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_56_52_56_57_) WL_X(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_110_111_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_56_52_57_51_) WL_X(FID_99_108_105_95_111_117_116_112_117_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_53_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_117_116_112_117_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_54_56_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_54_56_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_57_) WL_X(FID_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_55_50_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_55_50_55_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_55_51_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_56_) WL_X(FID_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_56_) WL_X(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_55_57_56_) WL_X(FID_67_104_97_114_46_105_115_95_101_113_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_56_50_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_56_50_54_) WL_X(FID_36_100_105_114_101_99_116_46_67_104_97_114_46_105_115_95_101_113_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_56_51_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_56_52_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_56_52_52_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_51_56_54_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_51_56_55_48_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_) WL_X(FID_IO_EMIT) WL_X(BEND_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_109_97_105_110_
#define MAIN_PURE 0
#if !DEVICE
static const u32 SHOW_DESC[] = { 0 };
static const char* SHOW_NAMES[] = {"False", "True", "Unit"};
#endif


#define TAB_AT(T, S, I) T[S < I ? S : I]

// Fid
// ===

#define fid_arity(x) ((u32)FID_ARITY_T[x])

#define fid_bangs(x) ((bool)(FID_FLAG_T[x] & 1))

#define fid_nofk(x) ((bool)(FID_FLAG_T[x] & 2))

#define fid_seqk(x) (fid_resw(x) != 0)

#define fid_resw(x) ((u32)FID_RESW_T[x])

// Cid
// ===

#define cid_arity(x) ((u32)CID_ARITY_T[x])
#define cid_hot(x) ((bool)CID_HOT_T[x])

// A32
// ===

#ifdef __METAL_VERSION__

// via a volatile local: else the M1 backend folds the zext into the atomic
// load, cannot legalize it, and the pipeline build dies
#define a32_load(p)      \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })
#define a32_store(p, v)  atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v)    atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v)    atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_swp(p, e, v) \
  atomic_compare_exchange_weak_explicit(A32(p), e, v, RLX, RLX)

#elif defined(__CUDACC_RTC__)

#define a32_load(p)     (*(volatile u32*)(p))
#define a32_store(p, v) (*(volatile u32*)(p) = (v))
#define a32_add(p, v)   atomicAdd((u32*)(p), v)
#define a32_sub(p, v)   atomicSub((u32*)(p), v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#endif

#if DEVICE

INLINE u32 a32_sub_rel(DEV u32* p, u32 v) {
  FENCE();
  return a32_sub(p, v);
}

INLINE void a32_store_rel(DEV u32* p, u32 v) {
  FENCE();
  a32_store(p, v);
}

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = a32_load(p);
  FENCE();
  return v;
}

#define a32_acq(p) FENCE()

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = a32_swp(p, e, v);
  FENCE();
  return ok;
}

#else

#define a32_load(p)         __atomic_load_n(p, __ATOMIC_RELAXED)
#define a32_store(p, v)     __atomic_store_n(p, v, __ATOMIC_RELAXED)
#define a32_add(p, v)       __atomic_fetch_add(p, v, __ATOMIC_RELAXED)
#define a32_sub(p, v)       __atomic_fetch_sub(p, v, __ATOMIC_RELAXED)
#define a32_sub_rel(p, v)   __atomic_fetch_sub(p, v, __ATOMIC_RELEASE)
#define a32_store_rel(p, v) __atomic_store_n(p, v, __ATOMIC_RELEASE)
#define a32_load_acq(p)     __atomic_load_n(p, __ATOMIC_ACQUIRE)
#define a32_acq(p)          ((void)a32_load_acq(p))

INLINE bool a32_cas(u32* p, u32* e, u32 v) {
  return __atomic_compare_exchange_n(
    p, e, v, 1, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE);
}

#endif

#define a32_at(H, word) ((DEV u32*)&(H)[word])

// Err
// ===

#if DEVICE

INLINE void err_post(Corpus H, Err code) {
  u32 seen = 0;
  while (seen == 0 && !a32_cas(a32_at(H, H_ERROR_CODE), &seen, code)) {}
}

#else

static const char* ERR_TEXT[] = { "", "runtime fail-stop", "runtime fail-stop", "out of memory: run again with a bigger span, as in --gpu 8GB", "a function the device does not hold", "a Nat past the largest immediate 2^48-1", "runtime fail-stop", "memory fault (machine stack overflow?)", "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(Corpus H, Err code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  // A machine stack fault can interrupt stdio or exhaust the handler's small
  // alternate stack. Only async-signal-safe operations may run here.
  static const char message[] = "bend: memory fault (machine stack overflow?)\n";
  (void)write(STDERR_FILENO, message, sizeof(message) - 1);
  _exit(1);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
// Metal's atan2 is NaN at the origin; libm answers +-0 or +-pi there
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

// Metal folds a constant dividend within 128 of 2^32 through an f32: divide
// its half, then fix the odd bit.
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE U32 f32_to_u32(U32 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE Nat nat_chk(Env e, Nat n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE Nat nat_mul(Env e, Nat a, Nat b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

// Cls
// ===

INLINE Cls cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

// Bank
// ====

// One stack of exact generations per class; 2 heap_words / max(CHUNK,
// 2^c) entries cover the old ones plus a pass of returns. The host
// pops and pushes at rd under bank_lock; a device pass pops down from
// rd and pushes above top, and the host then compacts [top, wr) onto
// rd, so a pass never sees what it handed.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE Loc bank_pop(Corpus H, Cls c) {
  DEV Bank* b = bank_at(H, c);
  Loc got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(Corpus H, Cls c, Loc head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class (a tile row on the device): HOT, a LIFO chain of
// free slots (word 0 the head it replaced); LEN, its exact length in
// words, off the chain; on the host COLD, one generation. A free is a
// push and an add. A host free at KEEP_WORDS (a slot for a wide class)
// runs heap_hand: COLD to the bank, HOT parked as COLD, generations
// exact. A miss takes COLD, else a bank entry, else a quantum of at
// most a generation, and sets LEN to what it took: no adoption past a
// generation, no list re-aged. A device lane keeps its frees for the
// pass; at the kernel end dev_cut hands its complete generations,
// walking only those. KEEP_WORDS is CAP_WORDS, or CHUNK with the GPU
// (fixed at boot), so a device lane may adopt every host entry.
// Bounds: a host lane and class under 2 max(KEEP_WORDS, 2^c) words, a
// device one under max(CHUNK, 2^c) after each kernel plus its own
// frees within one, bank entries exact. The bump grows only when this
// lane's HOT and COLD and the class's bank are empty. A zero row is an
// empty lane.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, ALC_WORDS + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * ALC_WORDS + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

OUTLINE void heap_hand(Env e, Cls cls) {
  Loc cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(Corpus H, u64 need);
#endif

OUTLINE Loc heap_alloc_miss(Env e, Cls cls) {
  Corpus H = e.mem;
  Loc  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      p = 0;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE Loc heap_alloc(Env e, Cls cls) {
  Loc h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, Cls cls, Loc loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

// Spare
// =====

INLINE void spare_free(Env e, Cls cls, Loc loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, Cls cls, Loc loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE Loc term_loc(Term t) {
  return t & LOC_MASK;
}

// A static node (below the heap) is trivial, as is a captureless closure.
INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  Loc r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

INLINE u64 rfc_view(Env e, Loc r) {
  DEV u32* w = a32_at(e.mem, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, Loc r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), 1);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 2);
}

INLINE Loc term_peek(Env e, Term t) {
  if (term_rfc(t)) {
    return rfc_view(e, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

INLINE Cls blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE Cls blk_span(Term t) {
  Cls c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t);

INLINE void blk_free(Env e, Term t) {
  if (term_rfc(t)) {
    term_drop(e, t);
  } else {
    heap_free(e, blk_span(t), term_loc(t));
  }
}

FAR void term_drop(Env e, Term t) {
  Corpus H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      Loc      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        blk_free(e, t);
      } else {
        u32 aux = (u32)term_aux(t);
        Loc loc = term_loc(t);
        u32 n   = 0;
        Cls cls;
        if (tag == TAG_ARR) {
          cls = 64 | blk_cls(t);
        } else {
          u32 ar;
          if (tag == TAG_CTR) {
            ar = cid_arity(aux);
          } else if (tag == TAG_CLO) {
            ar = fid_arity(aux) - 1;
          } else {
            ar = fid_arity(aux);
          }
          n   = ar;
          cls = cls_fit(tag == TAG_TSK ? ar + 2 : ar);
        }
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step)) {
        return;
      }
      if (cur == 0) {
        return;
      }
      Loc  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      Cls  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, Loc src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE Loc ctr_take(Env e, Term t, u32 n, THR Term* out) {
  Corpus H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  Loc r    = term_loc(t);
  u64 cell = rfc_view(e, r);
  Loc src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    Loc l = term_peek(e, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

#ifndef NATIVE_SCALAR_ARRAYS
#define NATIVE_SCALAR_ARRAYS 0
#endif
#ifndef NATIVE_UNSHARED_ARRAYS
#define NATIVE_UNSHARED_ARRAYS 0
#endif

// A block owns one allocation in its physical class (an ARR of class
// c 2^c Terms in 2^c words, a BUF 2^c u32 in 2^buf_wcls(c) words) and
// blk_free returns it there. A match on ANode is blk_half twice: each
// half allocated in its class and copied, the source freed shallow by
// the high call (its elements moved; the emitter binds the low half
// first). ANode{l, r} is blk_node: the merged class, l and r copied
// and freed shallow. Shared handles instead retain copied ARR elements and
// decrement their RFC; Array.clone keeps the original first and a fresh copy
// second. A match to the leaves copies
// O(n log n) words where a view copied none; get, set, swap, size and
// new open no half.

#define BLK_ALLOC(n, w) \
  Loc n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(Corpus H, Loc loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(Corpus H, bool arr, Loc loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(Corpus H, bool arr, Loc loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, U32 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, Loc at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

// A shared leaf gives its caller a retained element before dropping the handle.
INLINE Term blk_leaf(Env e, Term a) {
  Loc at = term_peek(e, a);
  if (term_tag(a) == TAG_BUF) return blk_read(e.mem, false, at, 0);
  return term_rfc(a) ? blk_keep(e, at) : e.mem[at];
}

// Packed arrays use adjacent U32 slots; uniform arrays use each word's low half.
// Existing a32 operations provide a single atomic update for every backend.
INLINE u64 array_atomic(Env e, Term a, u32 i, u32 v, u32 x, u32 op) {
  Loc loc = term_peek(e, a);
  u32 at = blk_at(a, i, 0);
  DEV u32* p = a32_at(e.mem, loc) + (term_tag(a) == TAG_BUF ? at : 2 * at);
  u32 old = a32_load(p);
  for (;;) {
    u32 next = v;
    switch (op) {
      case 1: next = old + v; break;
      case 2: next = old < v ? old : v; break;
      case 3: next = old > v ? old : v; break;
      case 4: next = old & v; break;
      case 5: next = old | v; break;
      case 6: next = old ^ v; break;
      case 8: next = old == v ? x : old; break;
      case 9: next = (u32)f32_rewrap(f32_unbox(old) + f32_unbox(v)); break;
    }
    u32 expected = old;
    if (a32_cas(p, &expected, next)) {
      return old;
    }
    old = expected;
  }
}

OUTLINE Term blk_copy(Env e, Term a) {
  Corpus H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  Cls cls = blk_span(a);
  Loc src = term_peek(e, a);
  BLK_ALLOC(dst, cls)
  for (u64 j = 0; j < (1ull << cls); j += 1) {
    H[dst + j] = arr ? blk_keep(e, src + j) : H[src + j];
  }
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  Corpus H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  Cls c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  Loc pl = term_peek(e, l);
  Loc pr = term_peek(e, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    for (u64 w = 0; w < cw; w += 1) {
      H[n + w]      = arr && term_rfc(l) ? blk_keep(e, pl + w) : H[pl + w];
      H[n + cw + w] = arr && term_rfc(r) ? blk_keep(e, pr + w) : H[pr + w];
    }
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  Corpus H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  Cls c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  Cls cw = arr ? c : buf_wcls(c);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, term_peek(e, a), hi);
  } else {
    Loc src = term_peek(e, a) + ((u64)hi << cw);
    for (u64 w = 0; w < (1ull << cw); w += 1) {
      H[n + w] = arr && term_rfc(a) ? blk_keep(e, src + w) : H[src + w];
    }
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, Nat d, u32 lgs, u32 n, THR Term* v) {
  Corpus H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  Cls c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; j < n; j += 1) {
    Term w = v[j];
    if (arr && d > 0 && !term_triv(w)) {
      if (d >= 24) {
        err_post(H, ERR_RFCS);
      } else if (term_rfc(w)) {
        rfc_bump(e, term_loc(w), (1u << d) - 1);
      } else {
        w = rfc_wrap(e, w, 1u << d);
      }
    }
    v[j] = w;
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// The checked compiler may select one scalar layout for all reachable arrays.
// Raw/unknown programs retain the uniform word ABI. Handle sharing is independent.
INLINE Term native_array_get(Env e, Term a, u32 i) {
  u32 at = blk_at(a, i, 0);
  Loc loc = NATIVE_UNSHARED_ARRAYS ? term_loc(a) : term_peek(e, a);
  return NATIVE_SCALAR_ARRAYS ? blk_read(e.mem, false, loc, at) : blk_keep(e, loc + at);
}

INLINE Term native_array_swap(Env e, Term a, u32 i, Term value) {
  u32 at = blk_at(a, i, 0);
  Loc loc = NATIVE_UNSHARED_ARRAYS ? term_loc(a) : term_peek(e, a);
  Term old = blk_read(e.mem, !NATIVE_SCALAR_ARRAYS, loc, at);
  blk_write(e.mem, !NATIVE_SCALAR_ARRAYS, loc, at, NATIVE_SCALAR_ARRAYS ? value : rfc_seal(e, value));
  return old;
}

INLINE void native_array_set(Env e, Term a, u32 i, Term value) {
  u32 at = blk_at(a, i, 0);
  Loc loc = NATIVE_UNSHARED_ARRAYS ? term_loc(a) : term_peek(e, a);
  if (!NATIVE_SCALAR_ARRAYS) term_sink(e, blk_read(e.mem, true, loc, at));
  blk_write(e.mem, !NATIVE_SCALAR_ARRAYS, loc, at, NATIVE_SCALAR_ARRAYS ? value : rfc_seal(e, value));
}

// Ring
// ====

// planes LANES wide: a smaller bag has deeper rings in the same region
#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(Corpus H, Ring r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE Ring ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (g32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE Loc task_node(Env e, Fid fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  Loc loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE Loc task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(Corpus H, Term cont, u32 idx, THR Term* v, u32 n) {
  Loc at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  Loc tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(Corpus H, Term join, u32 base, u32 stride, Cur cur) {
  Loc loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      Ring to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(Corpus H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(Corpus H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 110ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 0), 105ull, term_ctr(CID_SCON, STAT_OFF + 2), 116ull, term_ctr(CID_SCON, STAT_OFF + 4), 112ull, term_ctr(CID_SCON, STAT_OFF + 6), 111ull, term_ctr(CID_SCON, STAT_OFF + 8), 32ull, term_ctr(CID_SCON, STAT_OFF + 10), 116ull, term_ctr(CID_SCON, STAT_OFF + 12), 117ull, term_ctr(CID_SCON, STAT_OFF + 14), 112ull, term_ctr(CID_SCON, STAT_OFF + 16), 116ull, term_ctr(CID_SCON, STAT_OFF + 18), 117ull, term_ctr(CID_SCON, STAT_OFF + 20), 111ull, term_ctr(CID_SCON, STAT_OFF + 22), 32ull, term_ctr(CID_SCON, STAT_OFF + 24), 101ull, term_ctr(CID_SCON, STAT_OFF + 26), 116ull, term_ctr(CID_SCON, STAT_OFF + 28), 97ull, term_ctr(CID_SCON, STAT_OFF + 30), 99ull, term_ctr(CID_SCON, STAT_OFF + 32), 105ull, term_ctr(CID_SCON, STAT_OFF + 34), 108ull, term_ctr(CID_SCON, STAT_OFF + 36), 112ull, term_ctr(CID_SCON, STAT_OFF + 38), 117ull, term_ctr(CID_SCON, STAT_OFF + 40), 100ull, term_ctr(CID_SCON, STAT_OFF + 42), term_ctr(CID_SCON, STAT_OFF + 44), 104ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 47), 97ull, term_ctr(CID_SCON, STAT_OFF + 49), 112ull, term_ctr(CID_SCON, STAT_OFF + 51), 32ull, term_ctr(CID_SCON, STAT_OFF + 53), 116ull, term_ctr(CID_SCON, STAT_OFF + 55), 117ull, term_ctr(CID_SCON, STAT_OFF + 57), 112ull, term_ctr(CID_SCON, STAT_OFF + 59), 116ull, term_ctr(CID_SCON, STAT_OFF + 61), 117ull, term_ctr(CID_SCON, STAT_OFF + 63), 111ull, term_ctr(CID_SCON, STAT_OFF + 65), 32ull, term_ctr(CID_SCON, STAT_OFF + 67), 121ull, term_ctr(CID_SCON, STAT_OFF + 69), 116ull, term_ctr(CID_SCON, STAT_OFF + 71), 112ull, term_ctr(CID_SCON, STAT_OFF + 73), 109ull, term_ctr(CID_SCON, STAT_OFF + 75), 101ull, term_ctr(CID_SCON, STAT_OFF + 77), term_ctr(CID_SCON, STAT_OFF + 79), 103ull, term_ctr(CID_SCON, STAT_OFF + 69), 110ull, term_ctr(CID_SCON, STAT_OFF + 82), 105ull, term_ctr(CID_SCON, STAT_OFF + 84), 115ull, term_ctr(CID_SCON, STAT_OFF + 86), 115ull, term_ctr(CID_SCON, STAT_OFF + 88), 105ull, term_ctr(CID_SCON, STAT_OFF + 90), 109ull, term_ctr(CID_SCON, STAT_OFF + 92), term_ctr(CID_SCON, STAT_OFF + 94), 100ull, term_pak(CID_SNIL, 0), 101ull, term_ctr(CID_SCON, STAT_OFF + 97), 114ull, term_ctr(CID_SCON, STAT_OFF + 99), 105ull, term_ctr(CID_SCON, STAT_OFF + 101), 117ull, term_ctr(CID_SCON, STAT_OFF + 103), 113ull, term_ctr(CID_SCON, STAT_OFF + 105), 101ull, term_ctr(CID_SCON, STAT_OFF + 107), 114ull, term_ctr(CID_SCON, STAT_OFF + 109), 32ull, term_ctr(CID_SCON, STAT_OFF + 111), 101ull, term_ctr(CID_SCON, STAT_OFF + 113), 114ull, term_ctr(CID_SCON, STAT_OFF + 115), 97ull, term_ctr(CID_SCON, STAT_OFF + 117), 32ull, term_ctr(CID_SCON, STAT_OFF + 119), 99ull, term_ctr(CID_SCON, STAT_OFF + 121), 46ull, term_ctr(CID_SCON, STAT_OFF + 123), 84ull, term_ctr(CID_SCON, STAT_OFF + 125), 85ull, term_ctr(CID_SCON, STAT_OFF + 127), 80ull, term_ctr(CID_SCON, STAT_OFF + 129), 84ull, term_ctr(CID_SCON, STAT_OFF + 131), 85ull, term_ctr(CID_SCON, STAT_OFF + 133), 79ull, term_ctr(CID_SCON, STAT_OFF + 135), 32ull, term_ctr(CID_SCON, STAT_OFF + 137), 111ull, term_ctr(CID_SCON, STAT_OFF + 139), 45ull, term_ctr(CID_SCON, STAT_OFF + 141), 32ull, term_ctr(CID_SCON, STAT_OFF + 143), 100ull, term_ctr(CID_SCON, STAT_OFF + 145), 110ull, term_ctr(CID_SCON, STAT_OFF + 147), 97ull, term_ctr(CID_SCON, STAT_OFF + 149), 32ull, term_ctr(CID_SCON, STAT_OFF + 151), 116ull, term_ctr(CID_SCON, STAT_OFF + 153), 117ull, term_ctr(CID_SCON, STAT_OFF + 155), 112ull, term_ctr(CID_SCON, STAT_OFF + 157), 110ull, term_ctr(CID_SCON, STAT_OFF + 159), 105ull, term_ctr(CID_SCON, STAT_OFF + 161), 32ull, term_ctr(CID_SCON, STAT_OFF + 163), 101ull, term_ctr(CID_SCON, STAT_OFF + 165), 110ull, term_ctr(CID_SCON, STAT_OFF + 167), 111ull, term_ctr(CID_SCON, STAT_OFF + 169), term_ctr(CID_SCON, STAT_OFF + 171), 111ull, term_pak(CID_SNIL, 0), 45ull, term_ctr(CID_SCON, STAT_OFF + 174), 116ull, term_pak(CID_SNIL, 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 178), 112ull, term_ctr(CID_SCON, STAT_OFF + 180), 116ull, term_ctr(CID_SCON, STAT_OFF + 182), 117ull, term_ctr(CID_SCON, STAT_OFF + 184), 111ull, term_ctr(CID_SCON, STAT_OFF + 186), 45ull, term_ctr(CID_SCON, STAT_OFF + 188), 45ull, term_ctr(CID_SCON, STAT_OFF + 190), 45ull, term_pak(CID_SNIL, 0), 45ull, term_ctr(CID_SCON, STAT_OFF + 194), 101ull, term_pak(CID_SNIL, 0), 118ull, term_ctr(CID_SCON, STAT_OFF + 198), 105ull, term_ctr(CID_SCON, STAT_OFF + 200), 108ull, term_ctr(CID_SCON, STAT_OFF + 202), 45ull, term_ctr(CID_SCON, STAT_OFF + 204), 45ull, term_ctr(CID_SCON, STAT_OFF + 206), 32ull, term_ctr(CID_SCON, STAT_OFF + 208), 101ull, term_ctr(CID_SCON, STAT_OFF + 210), 116ull, term_ctr(CID_SCON, STAT_OFF + 212), 97ull, term_ctr(CID_SCON, STAT_OFF + 214), 99ull, term_ctr(CID_SCON, STAT_OFF + 216), 105ull, term_ctr(CID_SCON, STAT_OFF + 218), 108ull, term_ctr(CID_SCON, STAT_OFF + 220), 112ull, term_ctr(CID_SCON, STAT_OFF + 222), 117ull, term_ctr(CID_SCON, STAT_OFF + 224), 100ull, term_ctr(CID_SCON, STAT_OFF + 226), term_ctr(CID_SCON, STAT_OFF + 228), 32ull, term_pak(CID_SNIL, 0), 58ull, term_ctr(CID_SCON, STAT_OFF + 231), 110ull, term_ctr(CID_SCON, STAT_OFF + 233), 111ull, term_ctr(CID_SCON, STAT_OFF + 235), 105ull, term_ctr(CID_SCON, STAT_OFF + 237), 116ull, term_ctr(CID_SCON, STAT_OFF + 239), 112ull, term_ctr(CID_SCON, STAT_OFF + 241), 111ull, term_ctr(CID_SCON, STAT_OFF + 243), 32ull, term_ctr(CID_SCON, STAT_OFF + 245), 110ull, term_ctr(CID_SCON, STAT_OFF + 247), 119ull, term_ctr(CID_SCON, STAT_OFF + 249), 111ull, term_ctr(CID_SCON, STAT_OFF + 251), 110ull, term_ctr(CID_SCON, STAT_OFF + 253), 107ull, term_ctr(CID_SCON, STAT_OFF + 255), 110ull, term_ctr(CID_SCON, STAT_OFF + 257), 117ull, term_ctr(CID_SCON, STAT_OFF + 259), 110ull, term_ctr(CID_SCON, STAT_OFF + 61), 105ull, term_ctr(CID_SCON, STAT_OFF + 263), 32ull, term_ctr(CID_SCON, STAT_OFF + 265), 121ull, term_ctr(CID_SCON, STAT_OFF + 267), 116ull, term_ctr(CID_SCON, STAT_OFF + 269), 112ull, term_ctr(CID_SCON, STAT_OFF + 271), 109ull, term_ctr(CID_SCON, STAT_OFF + 273), 101ull, term_ctr(CID_SCON, STAT_OFF + 275), 110ull, term_ctr(CID_SCON, STAT_OFF + 277), 111ull, term_ctr(CID_SCON, STAT_OFF + 279), 110ull, term_ctr(CID_SCON, STAT_OFF + 281), 32ull, term_ctr(CID_SCON, STAT_OFF + 283), 101ull, term_ctr(CID_SCON, STAT_OFF + 285), 110ull, term_ctr(CID_SCON, STAT_OFF + 287), 111ull, term_ctr(CID_SCON, STAT_OFF + 289), 32ull, term_ctr(CID_SCON, STAT_OFF + 291), 121ull, term_ctr(CID_SCON, STAT_OFF + 293), 108ull, term_ctr(CID_SCON, STAT_OFF + 295), 116ull, term_ctr(CID_SCON, STAT_OFF + 297), 99ull, term_ctr(CID_SCON, STAT_OFF + 299), 97ull, term_ctr(CID_SCON, STAT_OFF + 301), 120ull, term_ctr(CID_SCON, STAT_OFF + 303), 101ull, term_ctr(CID_SCON, STAT_OFF + 305), 32ull, term_ctr(CID_SCON, STAT_OFF + 307), 100ull, term_ctr(CID_SCON, STAT_OFF + 309), 101ull, term_ctr(CID_SCON, STAT_OFF + 311), 116ull, term_ctr(CID_SCON, STAT_OFF + 313), 99ull, term_ctr(CID_SCON, STAT_OFF + 315), 101ull, term_ctr(CID_SCON, STAT_OFF + 317), 112ull, term_ctr(CID_SCON, STAT_OFF + 319), 120ull, term_ctr(CID_SCON, STAT_OFF + 321), 101ull, term_ctr(CID_SCON, STAT_OFF + 323), term_ctr(CID_SCON, STAT_OFF + 325), 112ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 328), 101ull, term_ctr(CID_SCON, STAT_OFF + 330), 104ull, term_ctr(CID_SCON, STAT_OFF + 332), 45ull, term_ctr(CID_SCON, STAT_OFF + 334), 45ull, term_ctr(CID_SCON, STAT_OFF + 336), 115ull, term_ctr(CID_SCON, STAT_OFF + 4), 114ull, term_ctr(CID_SCON, STAT_OFF + 340), 101ull, term_ctr(CID_SCON, STAT_OFF + 342), 118ull, term_ctr(CID_SCON, STAT_OFF + 344), 45ull, term_ctr(CID_SCON, STAT_OFF + 346), 45ull, term_ctr(CID_SCON, STAT_OFF + 348), 100ull, term_ctr(CID_SCON, STAT_OFF + 231), 97ull, term_ctr(CID_SCON, STAT_OFF + 352), 101ull, term_ctr(CID_SCON, STAT_OFF + 354), 114ull, term_ctr(CID_SCON, STAT_OFF + 356), term_pak(CID_SNIL, 0), term_pak(CID_SNIL, 0), term_ctr(CID_TUPLE, STAT_OFF + 360), term_pak(CID_EQ, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 97), 101ull, term_ctr(CID_SCON, STAT_OFF + 364), 98ull, term_ctr(CID_SCON, STAT_OFF + 366), 46ull, term_ctr(CID_SCON, STAT_OFF + 368), 101ull, term_ctr(CID_SCON, STAT_OFF + 370), 115ull, term_ctr(CID_SCON, STAT_OFF + 372), 97ull, term_ctr(CID_SCON, STAT_OFF + 374), 98ull, term_ctr(CID_SCON, STAT_OFF + 376), 102ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 380), 97ull, term_ctr(CID_SCON, STAT_OFF + 382), 102ull, term_ctr(CID_SCON, STAT_OFF + 384), 55ull, term_ctr(CID_SCON, STAT_OFF + 386), 102ull, term_ctr(CID_SCON, STAT_OFF + 388), 54ull, term_ctr(CID_SCON, STAT_OFF + 390), 54ull, term_ctr(CID_SCON, STAT_OFF + 392), 97ull, term_ctr(CID_SCON, STAT_OFF + 394), 102ull, term_ctr(CID_SCON, STAT_OFF + 396), 51ull, term_ctr(CID_SCON, STAT_OFF + 398), 55ull, term_ctr(CID_SCON, STAT_OFF + 400), 57ull, term_ctr(CID_SCON, STAT_OFF + 402), 54ull, term_ctr(CID_SCON, STAT_OFF + 404), 100ull, term_ctr(CID_SCON, STAT_OFF + 406), 55ull, term_ctr(CID_SCON, STAT_OFF + 408), 50ull, term_ctr(CID_SCON, STAT_OFF + 410), 56ull, term_ctr(CID_SCON, STAT_OFF + 412), 99ull, term_ctr(CID_SCON, STAT_OFF + 414), 57ull, term_ctr(CID_SCON, STAT_OFF + 416), 54ull, term_ctr(CID_SCON, STAT_OFF + 418), 57ull, term_ctr(CID_SCON, STAT_OFF + 420), 51ull, term_ctr(CID_SCON, STAT_OFF + 422), 49ull, term_ctr(CID_SCON, STAT_OFF + 424), 101ull, term_ctr(CID_SCON, STAT_OFF + 426), 99ull, term_ctr(CID_SCON, STAT_OFF + 428), 57ull, term_ctr(CID_SCON, STAT_OFF + 430), 52ull, term_ctr(CID_SCON, STAT_OFF + 432), 55ull, term_ctr(CID_SCON, STAT_OFF + 434), 52ull, term_ctr(CID_SCON, STAT_OFF + 436), 52ull, term_ctr(CID_SCON, STAT_OFF + 438), 98ull, term_ctr(CID_SCON, STAT_OFF + 440), 99ull, term_ctr(CID_SCON, STAT_OFF + 442), 51ull, term_ctr(CID_SCON, STAT_OFF + 444), 100ull, term_ctr(CID_SCON, STAT_OFF + 446), 98ull, term_ctr(CID_SCON, STAT_OFF + 448), 98ull, term_ctr(CID_SCON, STAT_OFF + 450), 99ull, term_ctr(CID_SCON, STAT_OFF + 452), 101ull, term_ctr(CID_SCON, STAT_OFF + 454), 99ull, term_ctr(CID_SCON, STAT_OFF + 456), 100ull, term_ctr(CID_SCON, STAT_OFF + 458), 101ull, term_ctr(CID_SCON, STAT_OFF + 460), 99ull, term_ctr(CID_SCON, STAT_OFF + 462), 100ull, term_ctr(CID_SCON, STAT_OFF + 464), 99ull, term_ctr(CID_SCON, STAT_OFF + 466), 97ull, term_ctr(CID_SCON, STAT_OFF + 468), 57ull, term_ctr(CID_SCON, STAT_OFF + 470), 51ull, term_ctr(CID_SCON, STAT_OFF + 472), 102ull, term_ctr(CID_SCON, STAT_OFF + 474), 51ull, term_ctr(CID_SCON, STAT_OFF + 476), 101ull, term_ctr(CID_SCON, STAT_OFF + 478), 51ull, term_ctr(CID_SCON, STAT_OFF + 480), 98ull, term_ctr(CID_SCON, STAT_OFF + 482), 98ull, term_ctr(CID_SCON, STAT_OFF + 484), 50ull, term_ctr(CID_SCON, STAT_OFF + 486), 98ull, term_ctr(CID_SCON, STAT_OFF + 488), 50ull, term_ctr(CID_SCON, STAT_OFF + 490), 102ull, term_ctr(CID_SCON, STAT_OFF + 492), 51ull, term_ctr(CID_SCON, STAT_OFF + 494), 52ull, term_ctr(CID_SCON, STAT_OFF + 496), 99ull, term_ctr(CID_SCON, STAT_OFF + 498), 97ull, term_ctr(CID_SCON, STAT_OFF + 500), 57ull, term_ctr(CID_SCON, STAT_OFF + 502), 57ull, term_ctr(CID_SCON, STAT_OFF + 504), 56ull, term_pak(CID_SNIL, 0), 56ull, term_ctr(CID_SCON, STAT_OFF + 508), 112ull, term_ctr(CID_SCON, STAT_OFF + 510), 46ull, term_ctr(CID_SCON, STAT_OFF + 512), 101ull, term_ctr(CID_SCON, STAT_OFF + 514), 115ull, term_ctr(CID_SCON, STAT_OFF + 516), 97ull, term_ctr(CID_SCON, STAT_OFF + 518), 98ull, term_ctr(CID_SCON, STAT_OFF + 520), 55ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 524), 54ull, term_ctr(CID_SCON, STAT_OFF + 526), 56ull, term_ctr(CID_SCON, STAT_OFF + 528), 49ull, term_ctr(CID_SCON, STAT_OFF + 530), 98ull, term_ctr(CID_SCON, STAT_OFF + 532), 56ull, term_ctr(CID_SCON, STAT_OFF + 534), 100ull, term_ctr(CID_SCON, STAT_OFF + 536), 57ull, term_ctr(CID_SCON, STAT_OFF + 538), 52ull, term_ctr(CID_SCON, STAT_OFF + 540), 49ull, term_ctr(CID_SCON, STAT_OFF + 542), 53ull, term_ctr(CID_SCON, STAT_OFF + 544), 50ull, term_ctr(CID_SCON, STAT_OFF + 546), 57ull, term_ctr(CID_SCON, STAT_OFF + 548), 99ull, term_ctr(CID_SCON, STAT_OFF + 550), 55ull, term_ctr(CID_SCON, STAT_OFF + 552), 57ull, term_ctr(CID_SCON, STAT_OFF + 554), 53ull, term_ctr(CID_SCON, STAT_OFF + 556), 100ull, term_ctr(CID_SCON, STAT_OFF + 558), 55ull, term_ctr(CID_SCON, STAT_OFF + 560), 101ull, term_ctr(CID_SCON, STAT_OFF + 562), 100ull, term_ctr(CID_SCON, STAT_OFF + 564), 57ull, term_ctr(CID_SCON, STAT_OFF + 566), 49ull, term_ctr(CID_SCON, STAT_OFF + 568), 51ull, term_ctr(CID_SCON, STAT_OFF + 570), 57ull, term_ctr(CID_SCON, STAT_OFF + 572), 97ull, term_ctr(CID_SCON, STAT_OFF + 574), 52ull, term_ctr(CID_SCON, STAT_OFF + 576), 54ull, term_ctr(CID_SCON, STAT_OFF + 578), 97ull, term_ctr(CID_SCON, STAT_OFF + 580), 52ull, term_ctr(CID_SCON, STAT_OFF + 582), 53ull, term_ctr(CID_SCON, STAT_OFF + 584), 55ull, term_ctr(CID_SCON, STAT_OFF + 586), 55ull, term_ctr(CID_SCON, STAT_OFF + 588), 48ull, term_ctr(CID_SCON, STAT_OFF + 590), 57ull, term_ctr(CID_SCON, STAT_OFF + 592), 53ull, term_ctr(CID_SCON, STAT_OFF + 594), 55ull, term_ctr(CID_SCON, STAT_OFF + 596), 52ull, term_ctr(CID_SCON, STAT_OFF + 598), 57ull, term_ctr(CID_SCON, STAT_OFF + 600), 100ull, term_ctr(CID_SCON, STAT_OFF + 602), 53ull, term_ctr(CID_SCON, STAT_OFF + 604), 102ull, term_ctr(CID_SCON, STAT_OFF + 606), 57ull, term_ctr(CID_SCON, STAT_OFF + 608), 99ull, term_ctr(CID_SCON, STAT_OFF + 610), 102ull, term_ctr(CID_SCON, STAT_OFF + 612), 49ull, term_ctr(CID_SCON, STAT_OFF + 614), 54ull, term_ctr(CID_SCON, STAT_OFF + 616), 56ull, term_ctr(CID_SCON, STAT_OFF + 618), 100ull, term_ctr(CID_SCON, STAT_OFF + 620), 48ull, term_ctr(CID_SCON, STAT_OFF + 622), 50ull, term_ctr(CID_SCON, STAT_OFF + 624), 56ull, term_ctr(CID_SCON, STAT_OFF + 626), 52ull, term_ctr(CID_SCON, STAT_OFF + 628), 56ull, term_ctr(CID_SCON, STAT_OFF + 630), 98ull, term_ctr(CID_SCON, STAT_OFF + 632), 100ull, term_ctr(CID_SCON, STAT_OFF + 634), 100ull, term_ctr(CID_SCON, STAT_OFF + 636), 99ull, term_ctr(CID_SCON, STAT_OFF + 638), 56ull, term_ctr(CID_SCON, STAT_OFF + 640), 102ull, term_ctr(CID_SCON, STAT_OFF + 642), 97ull, term_ctr(CID_SCON, STAT_OFF + 644), 55ull, term_ctr(CID_SCON, STAT_OFF + 646), 48ull, term_ctr(CID_SCON, STAT_OFF + 648), 48ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 652), 114ull, term_ctr(CID_SCON, STAT_OFF + 654), 97ull, term_ctr(CID_SCON, STAT_OFF + 656), 112ull, term_ctr(CID_SCON, STAT_OFF + 658), 46ull, term_ctr(CID_SCON, STAT_OFF + 660), 99ull, term_ctr(CID_SCON, STAT_OFF + 662), 46ull, term_ctr(CID_SCON, STAT_OFF + 664), 101ull, term_ctr(CID_SCON, STAT_OFF + 666), 109ull, term_ctr(CID_SCON, STAT_OFF + 668), 105ull, term_ctr(CID_SCON, STAT_OFF + 670), 116ull, term_ctr(CID_SCON, STAT_OFF + 672), 110ull, term_ctr(CID_SCON, STAT_OFF + 674), 117ull, term_ctr(CID_SCON, STAT_OFF + 676), 114ull, term_ctr(CID_SCON, STAT_OFF + 678), 99ull, term_ctr(CID_SCON, STAT_OFF + 652), 50ull, term_ctr(CID_SCON, STAT_OFF + 682), 55ull, term_ctr(CID_SCON, STAT_OFF + 684), 50ull, term_ctr(CID_SCON, STAT_OFF + 686), 49ull, term_ctr(CID_SCON, STAT_OFF + 688), 54ull, term_ctr(CID_SCON, STAT_OFF + 690), 101ull, term_ctr(CID_SCON, STAT_OFF + 692), 100ull, term_ctr(CID_SCON, STAT_OFF + 694), 49ull, term_ctr(CID_SCON, STAT_OFF + 696), 100ull, term_ctr(CID_SCON, STAT_OFF + 698), 98ull, term_ctr(CID_SCON, STAT_OFF + 700), 48ull, term_ctr(CID_SCON, STAT_OFF + 702), 48ull, term_ctr(CID_SCON, STAT_OFF + 704), 56ull, term_ctr(CID_SCON, STAT_OFF + 706), 57ull, term_ctr(CID_SCON, STAT_OFF + 708), 102ull, term_ctr(CID_SCON, STAT_OFF + 710), 49ull, term_ctr(CID_SCON, STAT_OFF + 712), 48ull, term_ctr(CID_SCON, STAT_OFF + 714), 56ull, term_ctr(CID_SCON, STAT_OFF + 716), 97ull, term_ctr(CID_SCON, STAT_OFF + 718), 53ull, term_ctr(CID_SCON, STAT_OFF + 720), 55ull, term_ctr(CID_SCON, STAT_OFF + 722), 54ull, term_ctr(CID_SCON, STAT_OFF + 724), 97ull, term_ctr(CID_SCON, STAT_OFF + 726), 54ull, term_ctr(CID_SCON, STAT_OFF + 728), 98ull, term_ctr(CID_SCON, STAT_OFF + 730), 100ull, term_ctr(CID_SCON, STAT_OFF + 732), 57ull, term_ctr(CID_SCON, STAT_OFF + 734), 50ull, term_ctr(CID_SCON, STAT_OFF + 736), 53ull, term_ctr(CID_SCON, STAT_OFF + 738), 98ull, term_ctr(CID_SCON, STAT_OFF + 740), 99ull, term_ctr(CID_SCON, STAT_OFF + 742), 57ull, term_ctr(CID_SCON, STAT_OFF + 744), 54ull, term_ctr(CID_SCON, STAT_OFF + 746), 55ull, term_ctr(CID_SCON, STAT_OFF + 748), 55ull, term_ctr(CID_SCON, STAT_OFF + 750), 56ull, term_ctr(CID_SCON, STAT_OFF + 752), 52ull, term_ctr(CID_SCON, STAT_OFF + 754), 53ull, term_ctr(CID_SCON, STAT_OFF + 756), 57ull, term_ctr(CID_SCON, STAT_OFF + 758), 97ull, term_ctr(CID_SCON, STAT_OFF + 760), 57ull, term_ctr(CID_SCON, STAT_OFF + 762), 55ull, term_ctr(CID_SCON, STAT_OFF + 764), 98ull, term_ctr(CID_SCON, STAT_OFF + 766), 100ull, term_ctr(CID_SCON, STAT_OFF + 768), 100ull, term_ctr(CID_SCON, STAT_OFF + 770), 101ull, term_ctr(CID_SCON, STAT_OFF + 772), 48ull, term_ctr(CID_SCON, STAT_OFF + 774), 52ull, term_ctr(CID_SCON, STAT_OFF + 776), 55ull, term_ctr(CID_SCON, STAT_OFF + 778), 102ull, term_ctr(CID_SCON, STAT_OFF + 780), 56ull, term_ctr(CID_SCON, STAT_OFF + 782), 100ull, term_ctr(CID_SCON, STAT_OFF + 784), 56ull, term_ctr(CID_SCON, STAT_OFF + 786), 56ull, term_ctr(CID_SCON, STAT_OFF + 788), 53ull, term_ctr(CID_SCON, STAT_OFF + 790), 54ull, term_ctr(CID_SCON, STAT_OFF + 792), 55ull, term_ctr(CID_SCON, STAT_OFF + 794), 98ull, term_ctr(CID_SCON, STAT_OFF + 796), 52ull, term_ctr(CID_SCON, STAT_OFF + 798), 55ull, term_ctr(CID_SCON, STAT_OFF + 800), 48ull, term_ctr(CID_SCON, STAT_OFF + 802), 102ull, term_ctr(CID_SCON, STAT_OFF + 804), 49ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 808), 114ull, term_ctr(CID_SCON, STAT_OFF + 810), 97ull, term_ctr(CID_SCON, STAT_OFF + 812), 112ull, term_ctr(CID_SCON, STAT_OFF + 814), 46ull, term_ctr(CID_SCON, STAT_OFF + 816), 99ull, term_ctr(CID_SCON, STAT_OFF + 818), 46ull, term_ctr(CID_SCON, STAT_OFF + 820), 101ull, term_ctr(CID_SCON, STAT_OFF + 822), 109ull, term_ctr(CID_SCON, STAT_OFF + 824), 105ull, term_ctr(CID_SCON, STAT_OFF + 826), 116ull, term_ctr(CID_SCON, STAT_OFF + 828), 110ull, term_ctr(CID_SCON, STAT_OFF + 830), 117ull, term_ctr(CID_SCON, STAT_OFF + 832), 114ull, term_ctr(CID_SCON, STAT_OFF + 834), 53ull, term_pak(CID_SNIL, 0), 50ull, term_ctr(CID_SCON, STAT_OFF + 838), 49ull, term_ctr(CID_SCON, STAT_OFF + 840), 57ull, term_ctr(CID_SCON, STAT_OFF + 842), 49ull, term_ctr(CID_SCON, STAT_OFF + 844), 97ull, term_ctr(CID_SCON, STAT_OFF + 846), 101ull, term_ctr(CID_SCON, STAT_OFF + 848), 51ull, term_ctr(CID_SCON, STAT_OFF + 850), 53ull, term_ctr(CID_SCON, STAT_OFF + 852), 56ull, term_ctr(CID_SCON, STAT_OFF + 854), 100ull, term_ctr(CID_SCON, STAT_OFF + 856), 53ull, term_ctr(CID_SCON, STAT_OFF + 858), 102ull, term_ctr(CID_SCON, STAT_OFF + 860), 57ull, term_ctr(CID_SCON, STAT_OFF + 862), 52ull, term_ctr(CID_SCON, STAT_OFF + 864), 98ull, term_ctr(CID_SCON, STAT_OFF + 866), 98ull, term_ctr(CID_SCON, STAT_OFF + 868), 99ull, term_ctr(CID_SCON, STAT_OFF + 870), 49ull, term_ctr(CID_SCON, STAT_OFF + 872), 48ull, term_ctr(CID_SCON, STAT_OFF + 874), 51ull, term_ctr(CID_SCON, STAT_OFF + 876), 57ull, term_ctr(CID_SCON, STAT_OFF + 878), 53ull, term_ctr(CID_SCON, STAT_OFF + 880), 97ull, term_ctr(CID_SCON, STAT_OFF + 882), 56ull, term_ctr(CID_SCON, STAT_OFF + 884), 98ull, term_ctr(CID_SCON, STAT_OFF + 886), 54ull, term_ctr(CID_SCON, STAT_OFF + 888), 57ull, term_ctr(CID_SCON, STAT_OFF + 890), 48ull, term_ctr(CID_SCON, STAT_OFF + 892), 50ull, term_ctr(CID_SCON, STAT_OFF + 894), 49ull, term_ctr(CID_SCON, STAT_OFF + 896), 53ull, term_ctr(CID_SCON, STAT_OFF + 898), 55ull, term_ctr(CID_SCON, STAT_OFF + 900), 102ull, term_ctr(CID_SCON, STAT_OFF + 902), 50ull, term_ctr(CID_SCON, STAT_OFF + 904), 49ull, term_ctr(CID_SCON, STAT_OFF + 906), 51ull, term_ctr(CID_SCON, STAT_OFF + 908), 48ull, term_ctr(CID_SCON, STAT_OFF + 910), 102ull, term_ctr(CID_SCON, STAT_OFF + 912), 53ull, term_ctr(CID_SCON, STAT_OFF + 914), 100ull, term_ctr(CID_SCON, STAT_OFF + 916), 52ull, term_ctr(CID_SCON, STAT_OFF + 918), 99ull, term_ctr(CID_SCON, STAT_OFF + 920), 54ull, term_ctr(CID_SCON, STAT_OFF + 922), 50ull, term_ctr(CID_SCON, STAT_OFF + 924), 51ull, term_ctr(CID_SCON, STAT_OFF + 926), 98ull, term_ctr(CID_SCON, STAT_OFF + 928), 53ull, term_ctr(CID_SCON, STAT_OFF + 930), 54ull, term_ctr(CID_SCON, STAT_OFF + 932), 49ull, term_ctr(CID_SCON, STAT_OFF + 934), 52ull, term_ctr(CID_SCON, STAT_OFF + 936), 50ull, term_ctr(CID_SCON, STAT_OFF + 938), 54ull, term_ctr(CID_SCON, STAT_OFF + 940), 51ull, term_ctr(CID_SCON, STAT_OFF + 942), 51ull, term_ctr(CID_SCON, STAT_OFF + 944), 53ull, term_ctr(CID_SCON, STAT_OFF + 946), 97ull, term_ctr(CID_SCON, STAT_OFF + 948), 53ull, term_ctr(CID_SCON, STAT_OFF + 950), 49ull, term_ctr(CID_SCON, STAT_OFF + 952), 56ull, term_ctr(CID_SCON, STAT_OFF + 954), 99ull, term_ctr(CID_SCON, STAT_OFF + 956), 100ull, term_ctr(CID_SCON, STAT_OFF + 958), 53ull, term_ctr(CID_SCON, STAT_OFF + 960), 98ull, term_ctr(CID_SCON, STAT_OFF + 962), 50ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 966), 114ull, term_ctr(CID_SCON, STAT_OFF + 968), 97ull, term_ctr(CID_SCON, STAT_OFF + 970), 112ull, term_ctr(CID_SCON, STAT_OFF + 972), 46ull, term_ctr(CID_SCON, STAT_OFF + 974), 99ull, term_ctr(CID_SCON, STAT_OFF + 976), 46ull, term_ctr(CID_SCON, STAT_OFF + 978), 101ull, term_ctr(CID_SCON, STAT_OFF + 980), 109ull, term_ctr(CID_SCON, STAT_OFF + 982), 105ull, term_ctr(CID_SCON, STAT_OFF + 984), 116ull, term_ctr(CID_SCON, STAT_OFF + 986), 110ull, term_ctr(CID_SCON, STAT_OFF + 988), 117ull, term_ctr(CID_SCON, STAT_OFF + 990), 114ull, term_ctr(CID_SCON, STAT_OFF + 992), 49ull, term_ctr(CID_SCON, STAT_OFF + 97), 52ull, term_ctr(CID_SCON, STAT_OFF + 996), 98ull, term_ctr(CID_SCON, STAT_OFF + 998), 48ull, term_ctr(CID_SCON, STAT_OFF + 1000), 102ull, term_ctr(CID_SCON, STAT_OFF + 1002), 98ull, term_ctr(CID_SCON, STAT_OFF + 1004), 53ull, term_ctr(CID_SCON, STAT_OFF + 1006), 97ull, term_ctr(CID_SCON, STAT_OFF + 1008), 57ull, term_ctr(CID_SCON, STAT_OFF + 1010), 98ull, term_ctr(CID_SCON, STAT_OFF + 1012), 54ull, term_ctr(CID_SCON, STAT_OFF + 1014), 48ull, term_ctr(CID_SCON, STAT_OFF + 1016), 54ull, term_ctr(CID_SCON, STAT_OFF + 1018), 55ull, term_ctr(CID_SCON, STAT_OFF + 1020), 55ull, term_ctr(CID_SCON, STAT_OFF + 1022), 53ull, term_ctr(CID_SCON, STAT_OFF + 1024), 54ull, term_ctr(CID_SCON, STAT_OFF + 1026), 100ull, term_ctr(CID_SCON, STAT_OFF + 1028), 55ull, term_ctr(CID_SCON, STAT_OFF + 1030), 53ull, term_ctr(CID_SCON, STAT_OFF + 1032), 54ull, term_ctr(CID_SCON, STAT_OFF + 1034), 48ull, term_ctr(CID_SCON, STAT_OFF + 1036), 50ull, term_ctr(CID_SCON, STAT_OFF + 1038), 48ull, term_ctr(CID_SCON, STAT_OFF + 1040), 57ull, term_ctr(CID_SCON, STAT_OFF + 1042), 97ull, term_ctr(CID_SCON, STAT_OFF + 1044), 100ull, term_ctr(CID_SCON, STAT_OFF + 1046), 51ull, term_ctr(CID_SCON, STAT_OFF + 1048), 57ull, term_ctr(CID_SCON, STAT_OFF + 1050), 49ull, term_ctr(CID_SCON, STAT_OFF + 1052), 101ull, term_ctr(CID_SCON, STAT_OFF + 1054), 55ull, term_ctr(CID_SCON, STAT_OFF + 1056), 54ull, term_ctr(CID_SCON, STAT_OFF + 1058), 100ull, term_ctr(CID_SCON, STAT_OFF + 1060), 55ull, term_ctr(CID_SCON, STAT_OFF + 1062), 49ull, term_ctr(CID_SCON, STAT_OFF + 1064), 98ull, term_ctr(CID_SCON, STAT_OFF + 1066), 54ull, term_ctr(CID_SCON, STAT_OFF + 1068), 53ull, term_ctr(CID_SCON, STAT_OFF + 1070), 100ull, term_ctr(CID_SCON, STAT_OFF + 1072), 98ull, term_ctr(CID_SCON, STAT_OFF + 1074), 102ull, term_ctr(CID_SCON, STAT_OFF + 1076), 97ull, term_ctr(CID_SCON, STAT_OFF + 1078), 51ull, term_ctr(CID_SCON, STAT_OFF + 1080), 49ull, term_ctr(CID_SCON, STAT_OFF + 1082), 50ull, term_ctr(CID_SCON, STAT_OFF + 1084), 52ull, term_ctr(CID_SCON, STAT_OFF + 1086), 98ull, term_ctr(CID_SCON, STAT_OFF + 1088), 52ull, term_ctr(CID_SCON, STAT_OFF + 1090), 48ull, term_ctr(CID_SCON, STAT_OFF + 1092), 52ull, term_ctr(CID_SCON, STAT_OFF + 1094), 48ull, term_ctr(CID_SCON, STAT_OFF + 1096), 49ull, term_ctr(CID_SCON, STAT_OFF + 1098), 48ull, term_ctr(CID_SCON, STAT_OFF + 1100), 97ull, term_ctr(CID_SCON, STAT_OFF + 1102), 101ull, term_ctr(CID_SCON, STAT_OFF + 1104), 57ull, term_ctr(CID_SCON, STAT_OFF + 1106), 51ull, term_ctr(CID_SCON, STAT_OFF + 1108), 97ull, term_ctr(CID_SCON, STAT_OFF + 1110), 56ull, term_ctr(CID_SCON, STAT_OFF + 1112), 48ull, term_ctr(CID_SCON, STAT_OFF + 1114), 56ull, term_ctr(CID_SCON, STAT_OFF + 1116), 57ull, term_ctr(CID_SCON, STAT_OFF + 1118), 51ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 1122), 114ull, term_ctr(CID_SCON, STAT_OFF + 1124), 97ull, term_ctr(CID_SCON, STAT_OFF + 1126), 112ull, term_ctr(CID_SCON, STAT_OFF + 1128), 46ull, term_ctr(CID_SCON, STAT_OFF + 1130), 99ull, term_ctr(CID_SCON, STAT_OFF + 1132), 46ull, term_ctr(CID_SCON, STAT_OFF + 1134), 101ull, term_ctr(CID_SCON, STAT_OFF + 1136), 109ull, term_ctr(CID_SCON, STAT_OFF + 1138), 105ull, term_ctr(CID_SCON, STAT_OFF + 1140), 116ull, term_ctr(CID_SCON, STAT_OFF + 1142), 110ull, term_ctr(CID_SCON, STAT_OFF + 1144), 117ull, term_ctr(CID_SCON, STAT_OFF + 1146), 114ull, term_ctr(CID_SCON, STAT_OFF + 1148), 57ull, term_pak(CID_SNIL, 0), 48ull, term_ctr(CID_SCON, STAT_OFF + 1152), 100ull, term_ctr(CID_SCON, STAT_OFF + 1154), 97ull, term_ctr(CID_SCON, STAT_OFF + 1156), 102ull, term_ctr(CID_SCON, STAT_OFF + 1158), 57ull, term_ctr(CID_SCON, STAT_OFF + 1160), 55ull, term_ctr(CID_SCON, STAT_OFF + 1162), 54ull, term_ctr(CID_SCON, STAT_OFF + 1164), 102ull, term_ctr(CID_SCON, STAT_OFF + 1166), 48ull, term_ctr(CID_SCON, STAT_OFF + 1168), 48ull, term_ctr(CID_SCON, STAT_OFF + 1170), 102ull, term_ctr(CID_SCON, STAT_OFF + 1172), 101ull, term_ctr(CID_SCON, STAT_OFF + 1174), 51ull, term_ctr(CID_SCON, STAT_OFF + 1176), 52ull, term_ctr(CID_SCON, STAT_OFF + 1178), 57ull, term_ctr(CID_SCON, STAT_OFF + 1180), 101ull, term_ctr(CID_SCON, STAT_OFF + 1182), 52ull, term_ctr(CID_SCON, STAT_OFF + 1184), 101ull, term_ctr(CID_SCON, STAT_OFF + 1186), 98ull, term_ctr(CID_SCON, STAT_OFF + 1188), 100ull, term_ctr(CID_SCON, STAT_OFF + 1190), 51ull, term_ctr(CID_SCON, STAT_OFF + 1192), 55ull, term_ctr(CID_SCON, STAT_OFF + 1194), 98ull, term_ctr(CID_SCON, STAT_OFF + 1196), 52ull, term_ctr(CID_SCON, STAT_OFF + 1198), 55ull, term_ctr(CID_SCON, STAT_OFF + 1200), 48ull, term_ctr(CID_SCON, STAT_OFF + 1202), 99ull, term_ctr(CID_SCON, STAT_OFF + 1204), 57ull, term_ctr(CID_SCON, STAT_OFF + 1206), 49ull, term_ctr(CID_SCON, STAT_OFF + 1208), 51ull, term_ctr(CID_SCON, STAT_OFF + 1210), 57ull, term_ctr(CID_SCON, STAT_OFF + 1212), 98ull, term_ctr(CID_SCON, STAT_OFF + 1214), 56ull, term_ctr(CID_SCON, STAT_OFF + 1216), 102ull, term_ctr(CID_SCON, STAT_OFF + 1218), 53ull, term_ctr(CID_SCON, STAT_OFF + 1220), 48ull, term_ctr(CID_SCON, STAT_OFF + 1222), 49ull, term_ctr(CID_SCON, STAT_OFF + 1224), 102ull, term_ctr(CID_SCON, STAT_OFF + 1226), 52ull, term_ctr(CID_SCON, STAT_OFF + 1228), 57ull, term_ctr(CID_SCON, STAT_OFF + 1230), 54ull, term_ctr(CID_SCON, STAT_OFF + 1232), 48ull, term_ctr(CID_SCON, STAT_OFF + 1234), 50ull, term_ctr(CID_SCON, STAT_OFF + 1236), 49ull, term_ctr(CID_SCON, STAT_OFF + 1238), 48ull, term_ctr(CID_SCON, STAT_OFF + 1240), 54ull, term_ctr(CID_SCON, STAT_OFF + 1242), 99ull, term_ctr(CID_SCON, STAT_OFF + 1244), 49ull, term_ctr(CID_SCON, STAT_OFF + 1246), 50ull, term_ctr(CID_SCON, STAT_OFF + 1248), 54ull, term_ctr(CID_SCON, STAT_OFF + 1250), 102ull, term_ctr(CID_SCON, STAT_OFF + 1252), 50ull, term_ctr(CID_SCON, STAT_OFF + 1254), 55ull, term_ctr(CID_SCON, STAT_OFF + 1256), 50ull, term_ctr(CID_SCON, STAT_OFF + 1258), 50ull, term_ctr(CID_SCON, STAT_OFF + 1260), 48ull, term_ctr(CID_SCON, STAT_OFF + 1262), 51ull, term_ctr(CID_SCON, STAT_OFF + 1264), 53ull, term_ctr(CID_SCON, STAT_OFF + 1266), 98ull, term_ctr(CID_SCON, STAT_OFF + 1268), 56ull, term_ctr(CID_SCON, STAT_OFF + 1270), 57ull, term_ctr(CID_SCON, STAT_OFF + 1272), 102ull, term_ctr(CID_SCON, STAT_OFF + 1274), 55ull, term_ctr(CID_SCON, STAT_OFF + 1276), 52ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 1280), 114ull, term_ctr(CID_SCON, STAT_OFF + 1282), 97ull, term_ctr(CID_SCON, STAT_OFF + 1284), 112ull, term_ctr(CID_SCON, STAT_OFF + 1286), 46ull, term_ctr(CID_SCON, STAT_OFF + 1288), 99ull, term_ctr(CID_SCON, STAT_OFF + 1290), 46ull, term_ctr(CID_SCON, STAT_OFF + 1292), 101ull, term_ctr(CID_SCON, STAT_OFF + 1294), 109ull, term_ctr(CID_SCON, STAT_OFF + 1296), 105ull, term_ctr(CID_SCON, STAT_OFF + 1298), 116ull, term_ctr(CID_SCON, STAT_OFF + 1300), 110ull, term_ctr(CID_SCON, STAT_OFF + 1302), 117ull, term_ctr(CID_SCON, STAT_OFF + 1304), 114ull, term_ctr(CID_SCON, STAT_OFF + 1306), 98ull, term_pak(CID_SNIL, 0), 100ull, term_ctr(CID_SCON, STAT_OFF + 1310), 57ull, term_ctr(CID_SCON, STAT_OFF + 1312), 102ull, term_ctr(CID_SCON, STAT_OFF + 1314), 52ull, term_ctr(CID_SCON, STAT_OFF + 1316), 52ull, term_ctr(CID_SCON, STAT_OFF + 1318), 56ull, term_ctr(CID_SCON, STAT_OFF + 1320), 98ull, term_ctr(CID_SCON, STAT_OFF + 1322), 98ull, term_ctr(CID_SCON, STAT_OFF + 1324), 48ull, term_ctr(CID_SCON, STAT_OFF + 1326), 57ull, term_ctr(CID_SCON, STAT_OFF + 1328), 53ull, term_ctr(CID_SCON, STAT_OFF + 1330), 99ull, term_ctr(CID_SCON, STAT_OFF + 1332), 50ull, term_ctr(CID_SCON, STAT_OFF + 1334), 48ull, term_ctr(CID_SCON, STAT_OFF + 1336), 54ull, term_ctr(CID_SCON, STAT_OFF + 1338), 54ull, term_ctr(CID_SCON, STAT_OFF + 1340), 51ull, term_ctr(CID_SCON, STAT_OFF + 1342), 54ull, term_ctr(CID_SCON, STAT_OFF + 1344), 53ull, term_ctr(CID_SCON, STAT_OFF + 1346), 48ull, term_ctr(CID_SCON, STAT_OFF + 1348), 99ull, term_ctr(CID_SCON, STAT_OFF + 1350), 56ull, term_ctr(CID_SCON, STAT_OFF + 1352), 48ull, term_ctr(CID_SCON, STAT_OFF + 1354), 55ull, term_ctr(CID_SCON, STAT_OFF + 1356), 98ull, term_ctr(CID_SCON, STAT_OFF + 1358), 50ull, term_ctr(CID_SCON, STAT_OFF + 1360), 55ull, term_ctr(CID_SCON, STAT_OFF + 1362), 52ull, term_ctr(CID_SCON, STAT_OFF + 1364), 49ull, term_ctr(CID_SCON, STAT_OFF + 1366), 98ull, term_ctr(CID_SCON, STAT_OFF + 1368), 100ull, term_ctr(CID_SCON, STAT_OFF + 1370), 53ull, term_ctr(CID_SCON, STAT_OFF + 1372), 57ull, term_ctr(CID_SCON, STAT_OFF + 1374), 98ull, term_ctr(CID_SCON, STAT_OFF + 1376), 53ull, term_ctr(CID_SCON, STAT_OFF + 1378), 57ull, term_ctr(CID_SCON, STAT_OFF + 1380), 50ull, term_ctr(CID_SCON, STAT_OFF + 1382), 102ull, term_ctr(CID_SCON, STAT_OFF + 1384), 56ull, term_ctr(CID_SCON, STAT_OFF + 1386), 52ull, term_ctr(CID_SCON, STAT_OFF + 1388), 55ull, term_ctr(CID_SCON, STAT_OFF + 1390), 102ull, term_ctr(CID_SCON, STAT_OFF + 1392), 57ull, term_ctr(CID_SCON, STAT_OFF + 1394), 51ull, term_ctr(CID_SCON, STAT_OFF + 1396), 56ull, term_ctr(CID_SCON, STAT_OFF + 1398), 99ull, term_ctr(CID_SCON, STAT_OFF + 1400), 51ull, term_ctr(CID_SCON, STAT_OFF + 1402), 54ull, term_ctr(CID_SCON, STAT_OFF + 1404), 54ull, term_ctr(CID_SCON, STAT_OFF + 1406), 52ull, term_ctr(CID_SCON, STAT_OFF + 1408), 51ull, term_ctr(CID_SCON, STAT_OFF + 1410), 57ull, term_ctr(CID_SCON, STAT_OFF + 1412), 49ull, term_ctr(CID_SCON, STAT_OFF + 1414), 48ull, term_ctr(CID_SCON, STAT_OFF + 1416), 101ull, term_ctr(CID_SCON, STAT_OFF + 1418), 49ull, term_ctr(CID_SCON, STAT_OFF + 1420), 53ull, term_ctr(CID_SCON, STAT_OFF + 1422), 52ull, term_ctr(CID_SCON, STAT_OFF + 1424), 98ull, term_ctr(CID_SCON, STAT_OFF + 1426), 50ull, term_ctr(CID_SCON, STAT_OFF + 1428), 55ull, term_ctr(CID_SCON, STAT_OFF + 1430), 99ull, term_ctr(CID_SCON, STAT_OFF + 1432), 97ull, term_ctr(CID_SCON, STAT_OFF + 1434), 99ull, term_pak(CID_SNIL, 0), 46ull, term_ctr(CID_SCON, STAT_OFF + 1438), 115ull, term_ctr(CID_SCON, STAT_OFF + 1440), 103ull, term_ctr(CID_SCON, STAT_OFF + 1442), 114ull, term_ctr(CID_SCON, STAT_OFF + 1444), 97ull, term_ctr(CID_SCON, STAT_OFF + 1446), 47ull, term_ctr(CID_SCON, STAT_OFF + 1448), 115ull, term_ctr(CID_SCON, STAT_OFF + 1450), 102ull, term_ctr(CID_SCON, STAT_OFF + 1452), 102ull, term_ctr(CID_SCON, STAT_OFF + 1454), 101ull, term_ctr(CID_SCON, STAT_OFF + 1456), 101ull, term_ctr(CID_SCON, STAT_OFF + 652), 54ull, term_ctr(CID_SCON, STAT_OFF + 1460), 55ull, term_ctr(CID_SCON, STAT_OFF + 1462), 54ull, term_ctr(CID_SCON, STAT_OFF + 1464), 57ull, term_ctr(CID_SCON, STAT_OFF + 1466), 54ull, term_ctr(CID_SCON, STAT_OFF + 1468), 102ull, term_ctr(CID_SCON, STAT_OFF + 1470), 53ull, term_ctr(CID_SCON, STAT_OFF + 1472), 97ull, term_ctr(CID_SCON, STAT_OFF + 1474), 51ull, term_ctr(CID_SCON, STAT_OFF + 1476), 49ull, term_ctr(CID_SCON, STAT_OFF + 1478), 101ull, term_ctr(CID_SCON, STAT_OFF + 1480), 53ull, term_ctr(CID_SCON, STAT_OFF + 1482), 50ull, term_ctr(CID_SCON, STAT_OFF + 1484), 97ull, term_ctr(CID_SCON, STAT_OFF + 1486), 55ull, term_ctr(CID_SCON, STAT_OFF + 1488), 52ull, term_ctr(CID_SCON, STAT_OFF + 1490), 56ull, term_ctr(CID_SCON, STAT_OFF + 1492), 99ull, term_ctr(CID_SCON, STAT_OFF + 1494), 50ull, term_ctr(CID_SCON, STAT_OFF + 1496), 52ull, term_ctr(CID_SCON, STAT_OFF + 1498), 52ull, term_ctr(CID_SCON, STAT_OFF + 1500), 101ull, term_ctr(CID_SCON, STAT_OFF + 1502), 55ull, term_ctr(CID_SCON, STAT_OFF + 1504), 57ull, term_ctr(CID_SCON, STAT_OFF + 1506), 55ull, term_ctr(CID_SCON, STAT_OFF + 1508), 52ull, term_ctr(CID_SCON, STAT_OFF + 1510), 53ull, term_ctr(CID_SCON, STAT_OFF + 1512), 53ull, term_ctr(CID_SCON, STAT_OFF + 1514), 102ull, term_ctr(CID_SCON, STAT_OFF + 1516), 48ull, term_ctr(CID_SCON, STAT_OFF + 1518), 52ull, term_ctr(CID_SCON, STAT_OFF + 1520), 99ull, term_ctr(CID_SCON, STAT_OFF + 1522), 51ull, term_ctr(CID_SCON, STAT_OFF + 1524), 49ull, term_ctr(CID_SCON, STAT_OFF + 1526), 57ull, term_ctr(CID_SCON, STAT_OFF + 1528), 99ull, term_ctr(CID_SCON, STAT_OFF + 1530), 56ull, term_ctr(CID_SCON, STAT_OFF + 1532), 51ull, term_ctr(CID_SCON, STAT_OFF + 1534), 55ull, term_ctr(CID_SCON, STAT_OFF + 1536), 54ull, term_ctr(CID_SCON, STAT_OFF + 1538), 97ull, term_ctr(CID_SCON, STAT_OFF + 1540), 55ull, term_ctr(CID_SCON, STAT_OFF + 1542), 54ull, term_ctr(CID_SCON, STAT_OFF + 1544), 54ull, term_ctr(CID_SCON, STAT_OFF + 1546), 48ull, term_ctr(CID_SCON, STAT_OFF + 1548), 98ull, term_ctr(CID_SCON, STAT_OFF + 1550), 56ull, term_ctr(CID_SCON, STAT_OFF + 1552), 97ull, term_ctr(CID_SCON, STAT_OFF + 1554), 102ull, term_ctr(CID_SCON, STAT_OFF + 1556), 54ull, term_ctr(CID_SCON, STAT_OFF + 1558), 57ull, term_ctr(CID_SCON, STAT_OFF + 1560), 51ull, term_ctr(CID_SCON, STAT_OFF + 1562), 49ull, term_ctr(CID_SCON, STAT_OFF + 1564), 49ull, term_ctr(CID_SCON, STAT_OFF + 1566), 97ull, term_ctr(CID_SCON, STAT_OFF + 1568), 102ull, term_ctr(CID_SCON, STAT_OFF + 1570), 53ull, term_ctr(CID_SCON, STAT_OFF + 1572), 97ull, term_ctr(CID_SCON, STAT_OFF + 1574), 57ull, term_ctr(CID_SCON, STAT_OFF + 1576), 48ull, term_ctr(CID_SCON, STAT_OFF + 1578), 50ull, term_ctr(CID_SCON, STAT_OFF + 1580), 55ull, term_ctr(CID_SCON, STAT_OFF + 1582), 116ull, term_ctr(CID_SCON, STAT_OFF + 1440), 110ull, term_ctr(CID_SCON, STAT_OFF + 1586), 105ull, term_ctr(CID_SCON, STAT_OFF + 1588), 114ull, term_ctr(CID_SCON, STAT_OFF + 1590), 112ull, term_ctr(CID_SCON, STAT_OFF + 1592), 47ull, term_ctr(CID_SCON, STAT_OFF + 1594), 115ull, term_ctr(CID_SCON, STAT_OFF + 1596), 102ull, term_ctr(CID_SCON, STAT_OFF + 1598), 102ull, term_ctr(CID_SCON, STAT_OFF + 1600), 101ull, term_ctr(CID_SCON, STAT_OFF + 1602), 54ull, term_pak(CID_SNIL, 0), 50ull, term_ctr(CID_SCON, STAT_OFF + 1606), 98ull, term_ctr(CID_SCON, STAT_OFF + 1608), 53ull, term_ctr(CID_SCON, STAT_OFF + 1610), 51ull, term_ctr(CID_SCON, STAT_OFF + 1612), 54ull, term_ctr(CID_SCON, STAT_OFF + 1614), 97ull, term_ctr(CID_SCON, STAT_OFF + 1616), 50ull, term_ctr(CID_SCON, STAT_OFF + 1618), 101ull, term_ctr(CID_SCON, STAT_OFF + 1620), 55ull, term_ctr(CID_SCON, STAT_OFF + 1622), 102ull, term_ctr(CID_SCON, STAT_OFF + 1624), 101ull, term_ctr(CID_SCON, STAT_OFF + 1626), 102ull, term_ctr(CID_SCON, STAT_OFF + 1628), 100ull, term_ctr(CID_SCON, STAT_OFF + 1630), 48ull, term_ctr(CID_SCON, STAT_OFF + 1632), 55ull, term_ctr(CID_SCON, STAT_OFF + 1634), 100ull, term_ctr(CID_SCON, STAT_OFF + 1636), 98ull, term_ctr(CID_SCON, STAT_OFF + 1638), 57ull, term_ctr(CID_SCON, STAT_OFF + 1640), 56ull, term_ctr(CID_SCON, STAT_OFF + 1642), 50ull, term_ctr(CID_SCON, STAT_OFF + 1644), 101ull, term_ctr(CID_SCON, STAT_OFF + 1646), 49ull, term_ctr(CID_SCON, STAT_OFF + 1648), 99ull, term_ctr(CID_SCON, STAT_OFF + 1650), 51ull, term_ctr(CID_SCON, STAT_OFF + 1652), 98ull, term_ctr(CID_SCON, STAT_OFF + 1654), 50ull, term_ctr(CID_SCON, STAT_OFF + 1656), 48ull, term_ctr(CID_SCON, STAT_OFF + 1658), 52ull, term_ctr(CID_SCON, STAT_OFF + 1660), 101ull, term_ctr(CID_SCON, STAT_OFF + 1662), 53ull, term_ctr(CID_SCON, STAT_OFF + 1664), 99ull, term_ctr(CID_SCON, STAT_OFF + 1666), 101ull, term_ctr(CID_SCON, STAT_OFF + 1668), 52ull, term_ctr(CID_SCON, STAT_OFF + 1670), 100ull, term_ctr(CID_SCON, STAT_OFF + 1672), 51ull, term_ctr(CID_SCON, STAT_OFF + 1674), 55ull, term_ctr(CID_SCON, STAT_OFF + 1676), 51ull, term_ctr(CID_SCON, STAT_OFF + 1678), 52ull, term_ctr(CID_SCON, STAT_OFF + 1680), 101ull, term_ctr(CID_SCON, STAT_OFF + 1682), 49ull, term_ctr(CID_SCON, STAT_OFF + 1684), 102ull, term_ctr(CID_SCON, STAT_OFF + 1686), 53ull, term_ctr(CID_SCON, STAT_OFF + 1688), 102ull, term_ctr(CID_SCON, STAT_OFF + 1690), 48ull, term_ctr(CID_SCON, STAT_OFF + 1692), 99ull, term_ctr(CID_SCON, STAT_OFF + 1694), 101ull, term_ctr(CID_SCON, STAT_OFF + 1696), 101ull, term_ctr(CID_SCON, STAT_OFF + 1698), 97ull, term_ctr(CID_SCON, STAT_OFF + 1700), 101ull, term_ctr(CID_SCON, STAT_OFF + 1702), 50ull, term_ctr(CID_SCON, STAT_OFF + 1704), 101ull, term_ctr(CID_SCON, STAT_OFF + 1706), 54ull, term_ctr(CID_SCON, STAT_OFF + 1708), 101ull, term_ctr(CID_SCON, STAT_OFF + 1710), 99ull, term_ctr(CID_SCON, STAT_OFF + 1712), 97ull, term_ctr(CID_SCON, STAT_OFF + 1714), 50ull, term_ctr(CID_SCON, STAT_OFF + 1716), 100ull, term_ctr(CID_SCON, STAT_OFF + 1718), 48ull, term_ctr(CID_SCON, STAT_OFF + 1720), 48ull, term_ctr(CID_SCON, STAT_OFF + 1722), 53ull, term_ctr(CID_SCON, STAT_OFF + 1724), 57ull, term_ctr(CID_SCON, STAT_OFF + 1726), 48ull, term_ctr(CID_SCON, STAT_OFF + 1728), 55ull, term_ctr(CID_SCON, STAT_OFF + 1730), 119ull, term_ctr(CID_SCON, STAT_OFF + 1440), 111ull, term_ctr(CID_SCON, STAT_OFF + 1734), 110ull, term_ctr(CID_SCON, STAT_OFF + 1736), 47ull, term_ctr(CID_SCON, STAT_OFF + 1738), 115ull, term_ctr(CID_SCON, STAT_OFF + 1740), 102ull, term_ctr(CID_SCON, STAT_OFF + 1742), 102ull, term_ctr(CID_SCON, STAT_OFF + 1744), 101ull, term_ctr(CID_SCON, STAT_OFF + 1746), 98ull, term_ctr(CID_SCON, STAT_OFF + 1152), 53ull, term_ctr(CID_SCON, STAT_OFF + 1750), 50ull, term_ctr(CID_SCON, STAT_OFF + 1752), 56ull, term_ctr(CID_SCON, STAT_OFF + 1754), 98ull, term_ctr(CID_SCON, STAT_OFF + 1756), 55ull, term_ctr(CID_SCON, STAT_OFF + 1758), 56ull, term_ctr(CID_SCON, STAT_OFF + 1760), 56ull, term_ctr(CID_SCON, STAT_OFF + 1762), 49ull, term_ctr(CID_SCON, STAT_OFF + 1764), 54ull, term_ctr(CID_SCON, STAT_OFF + 1766), 97ull, term_ctr(CID_SCON, STAT_OFF + 1768), 100ull, term_ctr(CID_SCON, STAT_OFF + 1770), 100ull, term_ctr(CID_SCON, STAT_OFF + 1772), 101ull, term_ctr(CID_SCON, STAT_OFF + 1774), 97ull, term_ctr(CID_SCON, STAT_OFF + 1776), 49ull, term_ctr(CID_SCON, STAT_OFF + 1778), 101ull, term_ctr(CID_SCON, STAT_OFF + 1780), 98ull, term_ctr(CID_SCON, STAT_OFF + 1782), 98ull, term_ctr(CID_SCON, STAT_OFF + 1784), 54ull, term_ctr(CID_SCON, STAT_OFF + 1786), 98ull, term_ctr(CID_SCON, STAT_OFF + 1788), 55ull, term_ctr(CID_SCON, STAT_OFF + 1790), 100ull, term_ctr(CID_SCON, STAT_OFF + 1792), 98ull, term_ctr(CID_SCON, STAT_OFF + 1794), 102ull, term_ctr(CID_SCON, STAT_OFF + 1796), 101ull, term_ctr(CID_SCON, STAT_OFF + 1798), 101ull, term_ctr(CID_SCON, STAT_OFF + 1800), 50ull, term_ctr(CID_SCON, STAT_OFF + 1802), 98ull, term_ctr(CID_SCON, STAT_OFF + 1804), 48ull, term_ctr(CID_SCON, STAT_OFF + 1806), 54ull, term_ctr(CID_SCON, STAT_OFF + 1808), 100ull, term_ctr(CID_SCON, STAT_OFF + 1810), 52ull, term_ctr(CID_SCON, STAT_OFF + 1812), 98ull, term_ctr(CID_SCON, STAT_OFF + 1814), 53ull, term_ctr(CID_SCON, STAT_OFF + 1816), 49ull, term_ctr(CID_SCON, STAT_OFF + 1818), 54ull, term_ctr(CID_SCON, STAT_OFF + 1820), 57ull, term_ctr(CID_SCON, STAT_OFF + 1822), 99ull, term_ctr(CID_SCON, STAT_OFF + 1824), 53ull, term_ctr(CID_SCON, STAT_OFF + 1826), 50ull, term_ctr(CID_SCON, STAT_OFF + 1828), 54ull, term_ctr(CID_SCON, STAT_OFF + 1830), 48ull, term_ctr(CID_SCON, STAT_OFF + 1832), 54ull, term_ctr(CID_SCON, STAT_OFF + 1834), 53ull, term_ctr(CID_SCON, STAT_OFF + 1836), 55ull, term_ctr(CID_SCON, STAT_OFF + 1838), 99ull, term_ctr(CID_SCON, STAT_OFF + 1840), 100ull, term_ctr(CID_SCON, STAT_OFF + 1842), 97ull, term_ctr(CID_SCON, STAT_OFF + 1844), 102ull, term_ctr(CID_SCON, STAT_OFF + 1846), 52ull, term_ctr(CID_SCON, STAT_OFF + 1848), 99ull, term_ctr(CID_SCON, STAT_OFF + 1850), 49ull, term_ctr(CID_SCON, STAT_OFF + 1852), 48ull, term_ctr(CID_SCON, STAT_OFF + 1854), 55ull, term_ctr(CID_SCON, STAT_OFF + 1856), 53ull, term_ctr(CID_SCON, STAT_OFF + 1858), 54ull, term_ctr(CID_SCON, STAT_OFF + 1860), 101ull, term_ctr(CID_SCON, STAT_OFF + 1862), 100ull, term_ctr(CID_SCON, STAT_OFF + 1864), 102ull, term_ctr(CID_SCON, STAT_OFF + 1866), 53ull, term_ctr(CID_SCON, STAT_OFF + 1868), 97ull, term_ctr(CID_SCON, STAT_OFF + 1870), 100ull, term_ctr(CID_SCON, STAT_OFF + 1872), 114ull, term_ctr(CID_SCON, STAT_OFF + 1440), 114ull, term_ctr(CID_SCON, STAT_OFF + 1876), 101ull, term_ctr(CID_SCON, STAT_OFF + 1878), 95ull, term_ctr(CID_SCON, STAT_OFF + 1880), 116ull, term_ctr(CID_SCON, STAT_OFF + 1882), 110ull, term_ctr(CID_SCON, STAT_OFF + 1884), 105ull, term_ctr(CID_SCON, STAT_OFF + 1886), 114ull, term_ctr(CID_SCON, STAT_OFF + 1888), 112ull, term_ctr(CID_SCON, STAT_OFF + 1890), 47ull, term_ctr(CID_SCON, STAT_OFF + 1892), 115ull, term_ctr(CID_SCON, STAT_OFF + 1894), 102ull, term_ctr(CID_SCON, STAT_OFF + 1896), 102ull, term_ctr(CID_SCON, STAT_OFF + 1898), 101ull, term_ctr(CID_SCON, STAT_OFF + 1900), 98ull, term_ctr(CID_SCON, STAT_OFF + 1606), 52ull, term_ctr(CID_SCON, STAT_OFF + 1904), 102ull, term_ctr(CID_SCON, STAT_OFF + 1906), 57ull, term_ctr(CID_SCON, STAT_OFF + 1908), 49ull, term_ctr(CID_SCON, STAT_OFF + 1910), 101ull, term_ctr(CID_SCON, STAT_OFF + 1912), 55ull, term_ctr(CID_SCON, STAT_OFF + 1914), 57ull, term_ctr(CID_SCON, STAT_OFF + 1916), 54ull, term_ctr(CID_SCON, STAT_OFF + 1918), 97ull, term_ctr(CID_SCON, STAT_OFF + 1920), 54ull, term_ctr(CID_SCON, STAT_OFF + 1922), 97ull, term_ctr(CID_SCON, STAT_OFF + 1924), 97ull, term_ctr(CID_SCON, STAT_OFF + 1926), 97ull, term_ctr(CID_SCON, STAT_OFF + 1928), 53ull, term_ctr(CID_SCON, STAT_OFF + 1930), 48ull, term_ctr(CID_SCON, STAT_OFF + 1932), 98ull, term_ctr(CID_SCON, STAT_OFF + 1934), 102ull, term_ctr(CID_SCON, STAT_OFF + 1936), 51ull, term_ctr(CID_SCON, STAT_OFF + 1938), 52ull, term_ctr(CID_SCON, STAT_OFF + 1940), 97ull, term_ctr(CID_SCON, STAT_OFF + 1942), 98ull, term_ctr(CID_SCON, STAT_OFF + 1944), 49ull, term_ctr(CID_SCON, STAT_OFF + 1946), 97ull, term_ctr(CID_SCON, STAT_OFF + 1948), 97ull, term_ctr(CID_SCON, STAT_OFF + 1950), 53ull, term_ctr(CID_SCON, STAT_OFF + 1952), 100ull, term_ctr(CID_SCON, STAT_OFF + 1954), 56ull, term_ctr(CID_SCON, STAT_OFF + 1956), 51ull, term_ctr(CID_SCON, STAT_OFF + 1958), 99ull, term_ctr(CID_SCON, STAT_OFF + 1960), 52ull, term_ctr(CID_SCON, STAT_OFF + 1962), 50ull, term_ctr(CID_SCON, STAT_OFF + 1964), 56ull, term_ctr(CID_SCON, STAT_OFF + 1966), 48ull, term_ctr(CID_SCON, STAT_OFF + 1968), 50ull, term_ctr(CID_SCON, STAT_OFF + 1970), 102ull, term_ctr(CID_SCON, STAT_OFF + 1972), 102ull, term_ctr(CID_SCON, STAT_OFF + 1974), 101ull, term_ctr(CID_SCON, STAT_OFF + 1976), 100ull, term_ctr(CID_SCON, STAT_OFF + 1978), 57ull, term_ctr(CID_SCON, STAT_OFF + 1980), 99ull, term_ctr(CID_SCON, STAT_OFF + 1982), 48ull, term_ctr(CID_SCON, STAT_OFF + 1984), 51ull, term_ctr(CID_SCON, STAT_OFF + 1986), 53ull, term_ctr(CID_SCON, STAT_OFF + 1988), 53ull, term_ctr(CID_SCON, STAT_OFF + 1990), 100ull, term_ctr(CID_SCON, STAT_OFF + 1992), 49ull, term_ctr(CID_SCON, STAT_OFF + 1994), 57ull, term_ctr(CID_SCON, STAT_OFF + 1996), 55ull, term_ctr(CID_SCON, STAT_OFF + 1998), 52ull, term_ctr(CID_SCON, STAT_OFF + 2000), 97ull, term_ctr(CID_SCON, STAT_OFF + 2002), 56ull, term_ctr(CID_SCON, STAT_OFF + 2004), 56ull, term_ctr(CID_SCON, STAT_OFF + 2006), 99ull, term_ctr(CID_SCON, STAT_OFF + 2008), 100ull, term_ctr(CID_SCON, STAT_OFF + 2010), 97ull, term_ctr(CID_SCON, STAT_OFF + 2012), 50ull, term_ctr(CID_SCON, STAT_OFF + 2014), 100ull, term_ctr(CID_SCON, STAT_OFF + 2016), 49ull, term_ctr(CID_SCON, STAT_OFF + 2018), 56ull, term_ctr(CID_SCON, STAT_OFF + 2020), 55ull, term_ctr(CID_SCON, STAT_OFF + 2022), 50ull, term_ctr(CID_SCON, STAT_OFF + 2024), 55ull, term_ctr(CID_SCON, STAT_OFF + 2026), 110ull, term_ctr(CID_SCON, STAT_OFF + 1440), 101ull, term_ctr(CID_SCON, STAT_OFF + 2030), 112ull, term_ctr(CID_SCON, STAT_OFF + 2032), 111ull, term_ctr(CID_SCON, STAT_OFF + 2034), 95ull, term_ctr(CID_SCON, STAT_OFF + 2036), 101ull, term_ctr(CID_SCON, STAT_OFF + 2038), 108ull, term_ctr(CID_SCON, STAT_OFF + 2040), 105ull, term_ctr(CID_SCON, STAT_OFF + 2042), 102ull, term_ctr(CID_SCON, STAT_OFF + 2044), 47ull, term_ctr(CID_SCON, STAT_OFF + 2046), 115ull, term_ctr(CID_SCON, STAT_OFF + 2048), 102ull, term_ctr(CID_SCON, STAT_OFF + 2050), 102ull, term_ctr(CID_SCON, STAT_OFF + 2052), 101ull, term_ctr(CID_SCON, STAT_OFF + 2054), 101ull, term_ctr(CID_SCON, STAT_OFF + 524), 54ull, term_ctr(CID_SCON, STAT_OFF + 2058), 52ull, term_ctr(CID_SCON, STAT_OFF + 2060), 55ull, term_ctr(CID_SCON, STAT_OFF + 2062), 50ull, term_ctr(CID_SCON, STAT_OFF + 2064), 54ull, term_ctr(CID_SCON, STAT_OFF + 2066), 48ull, term_ctr(CID_SCON, STAT_OFF + 2068), 97ull, term_ctr(CID_SCON, STAT_OFF + 2070), 102ull, term_ctr(CID_SCON, STAT_OFF + 2072), 50ull, term_ctr(CID_SCON, STAT_OFF + 2074), 99ull, term_ctr(CID_SCON, STAT_OFF + 2076), 48ull, term_ctr(CID_SCON, STAT_OFF + 2078), 57ull, term_ctr(CID_SCON, STAT_OFF + 2080), 99ull, term_ctr(CID_SCON, STAT_OFF + 2082), 57ull, term_ctr(CID_SCON, STAT_OFF + 2084), 50ull, term_ctr(CID_SCON, STAT_OFF + 2086), 57ull, term_ctr(CID_SCON, STAT_OFF + 2088), 97ull, term_ctr(CID_SCON, STAT_OFF + 2090), 101ull, term_ctr(CID_SCON, STAT_OFF + 2092), 100ull, term_ctr(CID_SCON, STAT_OFF + 2094), 53ull, term_ctr(CID_SCON, STAT_OFF + 2096), 49ull, term_ctr(CID_SCON, STAT_OFF + 2098), 101ull, term_ctr(CID_SCON, STAT_OFF + 2100), 98ull, term_ctr(CID_SCON, STAT_OFF + 2102), 99ull, term_ctr(CID_SCON, STAT_OFF + 2104), 102ull, term_ctr(CID_SCON, STAT_OFF + 2106), 101ull, term_ctr(CID_SCON, STAT_OFF + 2108), 57ull, term_ctr(CID_SCON, STAT_OFF + 2110), 102ull, term_ctr(CID_SCON, STAT_OFF + 2112), 52ull, term_ctr(CID_SCON, STAT_OFF + 2114), 49ull, term_ctr(CID_SCON, STAT_OFF + 2116), 99ull, term_ctr(CID_SCON, STAT_OFF + 2118), 57ull, term_ctr(CID_SCON, STAT_OFF + 2120), 48ull, term_ctr(CID_SCON, STAT_OFF + 2122), 97ull, term_ctr(CID_SCON, STAT_OFF + 2124), 99ull, term_ctr(CID_SCON, STAT_OFF + 2126), 55ull, term_ctr(CID_SCON, STAT_OFF + 2128), 56ull, term_ctr(CID_SCON, STAT_OFF + 2130), 50ull, term_ctr(CID_SCON, STAT_OFF + 2132), 57ull, term_ctr(CID_SCON, STAT_OFF + 2134), 57ull, term_ctr(CID_SCON, STAT_OFF + 2136), 97ull, term_ctr(CID_SCON, STAT_OFF + 2138), 99ull, term_ctr(CID_SCON, STAT_OFF + 2140), 54ull, term_ctr(CID_SCON, STAT_OFF + 2142), 102ull, term_ctr(CID_SCON, STAT_OFF + 2144), 55ull, term_ctr(CID_SCON, STAT_OFF + 2146), 99ull, term_ctr(CID_SCON, STAT_OFF + 2148), 51ull, term_ctr(CID_SCON, STAT_OFF + 2150), 48ull, term_ctr(CID_SCON, STAT_OFF + 2152), 48ull, term_ctr(CID_SCON, STAT_OFF + 2154), 57ull, term_ctr(CID_SCON, STAT_OFF + 2156), 98ull, term_ctr(CID_SCON, STAT_OFF + 2158), 50ull, term_ctr(CID_SCON, STAT_OFF + 2160), 52ull, term_ctr(CID_SCON, STAT_OFF + 2162), 49ull, term_ctr(CID_SCON, STAT_OFF + 2164), 99ull, term_ctr(CID_SCON, STAT_OFF + 2166), 99ull, term_ctr(CID_SCON, STAT_OFF + 2168), 98ull, term_ctr(CID_SCON, STAT_OFF + 2170), 56ull, term_ctr(CID_SCON, STAT_OFF + 2172), 97ull, term_ctr(CID_SCON, STAT_OFF + 2174), 50ull, term_ctr(CID_SCON, STAT_OFF + 2176), 52ull, term_ctr(CID_SCON, STAT_OFF + 2178), 102ull, term_ctr(CID_SCON, STAT_OFF + 2180), 100ull, term_ctr(CID_SCON, STAT_OFF + 1440), 97ull, term_ctr(CID_SCON, STAT_OFF + 2184), 101ull, term_ctr(CID_SCON, STAT_OFF + 2186), 114ull, term_ctr(CID_SCON, STAT_OFF + 2188), 95ull, term_ctr(CID_SCON, STAT_OFF + 2190), 101ull, term_ctr(CID_SCON, STAT_OFF + 2192), 108ull, term_ctr(CID_SCON, STAT_OFF + 2194), 105ull, term_ctr(CID_SCON, STAT_OFF + 2196), 102ull, term_ctr(CID_SCON, STAT_OFF + 2198), 47ull, term_ctr(CID_SCON, STAT_OFF + 2200), 115ull, term_ctr(CID_SCON, STAT_OFF + 2202), 102ull, term_ctr(CID_SCON, STAT_OFF + 2204), 102ull, term_ctr(CID_SCON, STAT_OFF + 2206), 101ull, term_ctr(CID_SCON, STAT_OFF + 2208), 55ull, term_ctr(CID_SCON, STAT_OFF + 508), 54ull, term_ctr(CID_SCON, STAT_OFF + 2212), 98ull, term_ctr(CID_SCON, STAT_OFF + 2214), 102ull, term_ctr(CID_SCON, STAT_OFF + 2216), 49ull, term_ctr(CID_SCON, STAT_OFF + 2218), 51ull, term_ctr(CID_SCON, STAT_OFF + 2220), 102ull, term_ctr(CID_SCON, STAT_OFF + 2222), 101ull, term_ctr(CID_SCON, STAT_OFF + 2224), 100ull, term_ctr(CID_SCON, STAT_OFF + 2226), 97ull, term_ctr(CID_SCON, STAT_OFF + 2228), 57ull, term_ctr(CID_SCON, STAT_OFF + 2230), 55ull, term_ctr(CID_SCON, STAT_OFF + 2232), 53ull, term_ctr(CID_SCON, STAT_OFF + 2234), 51ull, term_ctr(CID_SCON, STAT_OFF + 2236), 102ull, term_ctr(CID_SCON, STAT_OFF + 2238), 98ull, term_ctr(CID_SCON, STAT_OFF + 2240), 102ull, term_ctr(CID_SCON, STAT_OFF + 2242), 99ull, term_ctr(CID_SCON, STAT_OFF + 2244), 56ull, term_ctr(CID_SCON, STAT_OFF + 2246), 48ull, term_ctr(CID_SCON, STAT_OFF + 2248), 57ull, term_ctr(CID_SCON, STAT_OFF + 2250), 56ull, term_ctr(CID_SCON, STAT_OFF + 2252), 55ull, term_ctr(CID_SCON, STAT_OFF + 2254), 54ull, term_ctr(CID_SCON, STAT_OFF + 2256), 97ull, term_ctr(CID_SCON, STAT_OFF + 2258), 55ull, term_ctr(CID_SCON, STAT_OFF + 2260), 97ull, term_ctr(CID_SCON, STAT_OFF + 2262), 55ull, term_ctr(CID_SCON, STAT_OFF + 2264), 98ull, term_ctr(CID_SCON, STAT_OFF + 2266), 102ull, term_ctr(CID_SCON, STAT_OFF + 2268), 98ull, term_ctr(CID_SCON, STAT_OFF + 2270), 54ull, term_ctr(CID_SCON, STAT_OFF + 2272), 97ull, term_ctr(CID_SCON, STAT_OFF + 2274), 101ull, term_ctr(CID_SCON, STAT_OFF + 2276), 101ull, term_ctr(CID_SCON, STAT_OFF + 2278), 55ull, term_ctr(CID_SCON, STAT_OFF + 2280), 49ull, term_ctr(CID_SCON, STAT_OFF + 2282), 99ull, term_ctr(CID_SCON, STAT_OFF + 2284), 48ull, term_ctr(CID_SCON, STAT_OFF + 2286), 50ull, term_ctr(CID_SCON, STAT_OFF + 2288), 102ull, term_ctr(CID_SCON, STAT_OFF + 2290), 98ull, term_ctr(CID_SCON, STAT_OFF + 2292), 51ull, term_ctr(CID_SCON, STAT_OFF + 2294), 100ull, term_ctr(CID_SCON, STAT_OFF + 2296), 100ull, term_ctr(CID_SCON, STAT_OFF + 2298), 50ull, term_ctr(CID_SCON, STAT_OFF + 2300), 98ull, term_ctr(CID_SCON, STAT_OFF + 2302), 53ull, term_ctr(CID_SCON, STAT_OFF + 2304), 53ull, term_ctr(CID_SCON, STAT_OFF + 2306), 98ull, term_ctr(CID_SCON, STAT_OFF + 2308), 97ull, term_ctr(CID_SCON, STAT_OFF + 2310), 51ull, term_ctr(CID_SCON, STAT_OFF + 2312), 56ull, term_ctr(CID_SCON, STAT_OFF + 2314), 97ull, term_ctr(CID_SCON, STAT_OFF + 2316), 99ull, term_ctr(CID_SCON, STAT_OFF + 2318), 54ull, term_ctr(CID_SCON, STAT_OFF + 2320), 54ull, term_ctr(CID_SCON, STAT_OFF + 2322), 50ull, term_ctr(CID_SCON, STAT_OFF + 2324), 52ull, term_ctr(CID_SCON, STAT_OFF + 2326), 52ull, term_ctr(CID_SCON, STAT_OFF + 2328), 102ull, term_ctr(CID_SCON, STAT_OFF + 2330), 97ull, term_ctr(CID_SCON, STAT_OFF + 2332), 54ull, term_ctr(CID_SCON, STAT_OFF + 2334), 101ull, term_ctr(CID_SCON, STAT_OFF + 1440), 122ull, term_ctr(CID_SCON, STAT_OFF + 2338), 105ull, term_ctr(CID_SCON, STAT_OFF + 2340), 115ull, term_ctr(CID_SCON, STAT_OFF + 2342), 95ull, term_ctr(CID_SCON, STAT_OFF + 2344), 101ull, term_ctr(CID_SCON, STAT_OFF + 2346), 108ull, term_ctr(CID_SCON, STAT_OFF + 2348), 105ull, term_ctr(CID_SCON, STAT_OFF + 2350), 102ull, term_ctr(CID_SCON, STAT_OFF + 2352), 47ull, term_ctr(CID_SCON, STAT_OFF + 2354), 115ull, term_ctr(CID_SCON, STAT_OFF + 2356), 102ull, term_ctr(CID_SCON, STAT_OFF + 2358), 102ull, term_ctr(CID_SCON, STAT_OFF + 2360), 101ull, term_ctr(CID_SCON, STAT_OFF + 2362), 100ull, term_ctr(CID_SCON, STAT_OFF + 508), 53ull, term_ctr(CID_SCON, STAT_OFF + 2366), 100ull, term_ctr(CID_SCON, STAT_OFF + 2368), 53ull, term_ctr(CID_SCON, STAT_OFF + 2370), 102ull, term_ctr(CID_SCON, STAT_OFF + 2372), 54ull, term_ctr(CID_SCON, STAT_OFF + 2374), 53ull, term_ctr(CID_SCON, STAT_OFF + 2376), 53ull, term_ctr(CID_SCON, STAT_OFF + 2378), 48ull, term_ctr(CID_SCON, STAT_OFF + 2380), 101ull, term_ctr(CID_SCON, STAT_OFF + 2382), 51ull, term_ctr(CID_SCON, STAT_OFF + 2384), 52ull, term_ctr(CID_SCON, STAT_OFF + 2386), 98ull, term_ctr(CID_SCON, STAT_OFF + 2388), 98ull, term_ctr(CID_SCON, STAT_OFF + 2390), 101ull, term_ctr(CID_SCON, STAT_OFF + 2392), 100ull, term_ctr(CID_SCON, STAT_OFF + 2394), 56ull, term_ctr(CID_SCON, STAT_OFF + 2396), 101ull, term_ctr(CID_SCON, STAT_OFF + 2398), 56ull, term_ctr(CID_SCON, STAT_OFF + 2400), 55ull, term_ctr(CID_SCON, STAT_OFF + 2402), 98ull, term_ctr(CID_SCON, STAT_OFF + 2404), 50ull, term_ctr(CID_SCON, STAT_OFF + 2406), 99ull, term_ctr(CID_SCON, STAT_OFF + 2408), 100ull, term_ctr(CID_SCON, STAT_OFF + 2410), 55ull, term_ctr(CID_SCON, STAT_OFF + 2412), 50ull, term_ctr(CID_SCON, STAT_OFF + 2414), 54ull, term_ctr(CID_SCON, STAT_OFF + 2416), 51ull, term_ctr(CID_SCON, STAT_OFF + 2418), 48ull, term_ctr(CID_SCON, STAT_OFF + 2420), 101ull, term_ctr(CID_SCON, STAT_OFF + 2422), 56ull, term_ctr(CID_SCON, STAT_OFF + 2424), 102ull, term_ctr(CID_SCON, STAT_OFF + 2426), 53ull, term_ctr(CID_SCON, STAT_OFF + 2428), 51ull, term_ctr(CID_SCON, STAT_OFF + 2430), 101ull, term_ctr(CID_SCON, STAT_OFF + 2432), 56ull, term_ctr(CID_SCON, STAT_OFF + 2434), 52ull, term_ctr(CID_SCON, STAT_OFF + 2436), 57ull, term_ctr(CID_SCON, STAT_OFF + 2438), 99ull, term_ctr(CID_SCON, STAT_OFF + 2440), 52ull, term_ctr(CID_SCON, STAT_OFF + 2442), 52ull, term_ctr(CID_SCON, STAT_OFF + 2444), 57ull, term_ctr(CID_SCON, STAT_OFF + 2446), 97ull, term_ctr(CID_SCON, STAT_OFF + 2448), 101ull, term_ctr(CID_SCON, STAT_OFF + 2450), 101ull, term_ctr(CID_SCON, STAT_OFF + 2452), 49ull, term_ctr(CID_SCON, STAT_OFF + 2454), 97ull, term_ctr(CID_SCON, STAT_OFF + 2456), 98ull, term_ctr(CID_SCON, STAT_OFF + 2458), 102ull, term_ctr(CID_SCON, STAT_OFF + 2460), 48ull, term_ctr(CID_SCON, STAT_OFF + 2462), 102ull, term_ctr(CID_SCON, STAT_OFF + 2464), 48ull, term_ctr(CID_SCON, STAT_OFF + 2466), 102ull, term_ctr(CID_SCON, STAT_OFF + 2468), 57ull, term_ctr(CID_SCON, STAT_OFF + 2470), 51ull, term_ctr(CID_SCON, STAT_OFF + 2472), 56ull, term_ctr(CID_SCON, STAT_OFF + 2474), 51ull, term_ctr(CID_SCON, STAT_OFF + 2476), 102ull, term_ctr(CID_SCON, STAT_OFF + 2478), 54ull, term_ctr(CID_SCON, STAT_OFF + 2480), 48ull, term_ctr(CID_SCON, STAT_OFF + 2482), 57ull, term_ctr(CID_SCON, STAT_OFF + 2484), 57ull, term_ctr(CID_SCON, STAT_OFF + 2486), 48ull, term_ctr(CID_SCON, STAT_OFF + 2488), 116ull, term_ctr(CID_SCON, STAT_OFF + 2338), 105ull, term_ctr(CID_SCON, STAT_OFF + 2492), 114ull, term_ctr(CID_SCON, STAT_OFF + 2494), 119ull, term_ctr(CID_SCON, STAT_OFF + 2496), 95ull, term_ctr(CID_SCON, STAT_OFF + 2498), 101ull, term_ctr(CID_SCON, STAT_OFF + 2500), 108ull, term_ctr(CID_SCON, STAT_OFF + 2502), 105ull, term_ctr(CID_SCON, STAT_OFF + 2504), 102ull, term_ctr(CID_SCON, STAT_OFF + 2506), 47ull, term_ctr(CID_SCON, STAT_OFF + 2508), 115ull, term_ctr(CID_SCON, STAT_OFF + 2510), 102ull, term_ctr(CID_SCON, STAT_OFF + 2512), 102ull, term_ctr(CID_SCON, STAT_OFF + 2514), 101ull, term_ctr(CID_SCON, STAT_OFF + 2516), 101ull, term_ctr(CID_SCON, STAT_OFF + 966), 101ull, term_ctr(CID_SCON, STAT_OFF + 2520), 52ull, term_ctr(CID_SCON, STAT_OFF + 2522), 53ull, term_ctr(CID_SCON, STAT_OFF + 2524), 49ull, term_ctr(CID_SCON, STAT_OFF + 2526), 101ull, term_ctr(CID_SCON, STAT_OFF + 2528), 57ull, term_ctr(CID_SCON, STAT_OFF + 2530), 97ull, term_ctr(CID_SCON, STAT_OFF + 2532), 55ull, term_ctr(CID_SCON, STAT_OFF + 2534), 48ull, term_ctr(CID_SCON, STAT_OFF + 2536), 99ull, term_ctr(CID_SCON, STAT_OFF + 2538), 48ull, term_ctr(CID_SCON, STAT_OFF + 2540), 54ull, term_ctr(CID_SCON, STAT_OFF + 2542), 57ull, term_ctr(CID_SCON, STAT_OFF + 2544), 49ull, term_ctr(CID_SCON, STAT_OFF + 2546), 56ull, term_ctr(CID_SCON, STAT_OFF + 2548), 57ull, term_ctr(CID_SCON, STAT_OFF + 2550), 102ull, term_ctr(CID_SCON, STAT_OFF + 2552), 100ull, term_ctr(CID_SCON, STAT_OFF + 2554), 102ull, term_ctr(CID_SCON, STAT_OFF + 2556), 99ull, term_ctr(CID_SCON, STAT_OFF + 2558), 55ull, term_ctr(CID_SCON, STAT_OFF + 2560), 51ull, term_ctr(CID_SCON, STAT_OFF + 2562), 99ull, term_ctr(CID_SCON, STAT_OFF + 2564), 100ull, term_ctr(CID_SCON, STAT_OFF + 2566), 53ull, term_ctr(CID_SCON, STAT_OFF + 2568), 101ull, term_ctr(CID_SCON, STAT_OFF + 2570), 48ull, term_ctr(CID_SCON, STAT_OFF + 2572), 100ull, term_ctr(CID_SCON, STAT_OFF + 2574), 49ull, term_ctr(CID_SCON, STAT_OFF + 2576), 48ull, term_ctr(CID_SCON, STAT_OFF + 2578), 48ull, term_ctr(CID_SCON, STAT_OFF + 2580), 54ull, term_ctr(CID_SCON, STAT_OFF + 2582), 100ull, term_ctr(CID_SCON, STAT_OFF + 2584), 54ull, term_ctr(CID_SCON, STAT_OFF + 2586), 97ull, term_ctr(CID_SCON, STAT_OFF + 2588), 100ull, term_ctr(CID_SCON, STAT_OFF + 2590), 99ull, term_ctr(CID_SCON, STAT_OFF + 2592), 51ull, term_ctr(CID_SCON, STAT_OFF + 2594), 56ull, term_ctr(CID_SCON, STAT_OFF + 2596), 57ull, term_ctr(CID_SCON, STAT_OFF + 2598), 98ull, term_ctr(CID_SCON, STAT_OFF + 2600), 56ull, term_ctr(CID_SCON, STAT_OFF + 2602), 56ull, term_ctr(CID_SCON, STAT_OFF + 2604), 49ull, term_ctr(CID_SCON, STAT_OFF + 2606), 101ull, term_ctr(CID_SCON, STAT_OFF + 2608), 53ull, term_ctr(CID_SCON, STAT_OFF + 2610), 51ull, term_ctr(CID_SCON, STAT_OFF + 2612), 53ull, term_ctr(CID_SCON, STAT_OFF + 2614), 101ull, term_ctr(CID_SCON, STAT_OFF + 2616), 49ull, term_ctr(CID_SCON, STAT_OFF + 2618), 101ull, term_ctr(CID_SCON, STAT_OFF + 2620), 52ull, term_ctr(CID_SCON, STAT_OFF + 2622), 48ull, term_ctr(CID_SCON, STAT_OFF + 2624), 50ull, term_ctr(CID_SCON, STAT_OFF + 2626), 48ull, term_ctr(CID_SCON, STAT_OFF + 2628), 50ull, term_ctr(CID_SCON, STAT_OFF + 2630), 102ull, term_ctr(CID_SCON, STAT_OFF + 2632), 102ull, term_ctr(CID_SCON, STAT_OFF + 2634), 100ull, term_ctr(CID_SCON, STAT_OFF + 2636), 53ull, term_ctr(CID_SCON, STAT_OFF + 2638), 54ull, term_ctr(CID_SCON, STAT_OFF + 2640), 53ull, term_ctr(CID_SCON, STAT_OFF + 2642), 115ull, term_ctr(CID_SCON, STAT_OFF + 2338), 111ull, term_ctr(CID_SCON, STAT_OFF + 2646), 108ull, term_ctr(CID_SCON, STAT_OFF + 2648), 99ull, term_ctr(CID_SCON, STAT_OFF + 2650), 95ull, term_ctr(CID_SCON, STAT_OFF + 2652), 101ull, term_ctr(CID_SCON, STAT_OFF + 2654), 108ull, term_ctr(CID_SCON, STAT_OFF + 2656), 105ull, term_ctr(CID_SCON, STAT_OFF + 2658), 102ull, term_ctr(CID_SCON, STAT_OFF + 2660), 47ull, term_ctr(CID_SCON, STAT_OFF + 2662), 115ull, term_ctr(CID_SCON, STAT_OFF + 2664), 102ull, term_ctr(CID_SCON, STAT_OFF + 2666), 102ull, term_ctr(CID_SCON, STAT_OFF + 2668), 101ull, term_ctr(CID_SCON, STAT_OFF + 2670), 98ull, term_ctr(CID_SCON, STAT_OFF + 1122), 102ull, term_ctr(CID_SCON, STAT_OFF + 2674), 50ull, term_ctr(CID_SCON, STAT_OFF + 2676), 98ull, term_ctr(CID_SCON, STAT_OFF + 2678), 56ull, term_ctr(CID_SCON, STAT_OFF + 2680), 101ull, term_ctr(CID_SCON, STAT_OFF + 2682), 53ull, term_ctr(CID_SCON, STAT_OFF + 2684), 56ull, term_ctr(CID_SCON, STAT_OFF + 2686), 99ull, term_ctr(CID_SCON, STAT_OFF + 2688), 52ull, term_ctr(CID_SCON, STAT_OFF + 2690), 56ull, term_ctr(CID_SCON, STAT_OFF + 2692), 53ull, term_ctr(CID_SCON, STAT_OFF + 2694), 48ull, term_ctr(CID_SCON, STAT_OFF + 2696), 57ull, term_ctr(CID_SCON, STAT_OFF + 2698), 97ull, term_ctr(CID_SCON, STAT_OFF + 2700), 98ull, term_ctr(CID_SCON, STAT_OFF + 2702), 56ull, term_ctr(CID_SCON, STAT_OFF + 2704), 100ull, term_ctr(CID_SCON, STAT_OFF + 2706), 55ull, term_ctr(CID_SCON, STAT_OFF + 2708), 50ull, term_ctr(CID_SCON, STAT_OFF + 2710), 51ull, term_ctr(CID_SCON, STAT_OFF + 2712), 54ull, term_ctr(CID_SCON, STAT_OFF + 2714), 101ull, term_ctr(CID_SCON, STAT_OFF + 2716), 57ull, term_ctr(CID_SCON, STAT_OFF + 2718), 53ull, term_ctr(CID_SCON, STAT_OFF + 2720), 101ull, term_ctr(CID_SCON, STAT_OFF + 2722), 48ull, term_ctr(CID_SCON, STAT_OFF + 2724), 51ull, term_ctr(CID_SCON, STAT_OFF + 2726), 51ull, term_ctr(CID_SCON, STAT_OFF + 2728), 55ull, term_ctr(CID_SCON, STAT_OFF + 2730), 97ull, term_ctr(CID_SCON, STAT_OFF + 2732), 101ull, term_ctr(CID_SCON, STAT_OFF + 2734), 57ull, term_ctr(CID_SCON, STAT_OFF + 2736), 49ull, term_ctr(CID_SCON, STAT_OFF + 2738), 48ull, term_ctr(CID_SCON, STAT_OFF + 2740), 49ull, term_ctr(CID_SCON, STAT_OFF + 2742), 98ull, term_ctr(CID_SCON, STAT_OFF + 2744), 54ull, term_ctr(CID_SCON, STAT_OFF + 2746), 50ull, term_ctr(CID_SCON, STAT_OFF + 2748), 100ull, term_ctr(CID_SCON, STAT_OFF + 2750), 50ull, term_ctr(CID_SCON, STAT_OFF + 2752), 50ull, term_ctr(CID_SCON, STAT_OFF + 2754), 50ull, term_ctr(CID_SCON, STAT_OFF + 2756), 50ull, term_ctr(CID_SCON, STAT_OFF + 2758), 55ull, term_ctr(CID_SCON, STAT_OFF + 2760), 55ull, term_ctr(CID_SCON, STAT_OFF + 2762), 100ull, term_ctr(CID_SCON, STAT_OFF + 2764), 54ull, term_ctr(CID_SCON, STAT_OFF + 2766), 51ull, term_ctr(CID_SCON, STAT_OFF + 2768), 57ull, term_ctr(CID_SCON, STAT_OFF + 2770), 56ull, term_ctr(CID_SCON, STAT_OFF + 2772), 56ull, term_ctr(CID_SCON, STAT_OFF + 2774), 98ull, term_ctr(CID_SCON, STAT_OFF + 2776), 49ull, term_ctr(CID_SCON, STAT_OFF + 2778), 51ull, term_ctr(CID_SCON, STAT_OFF + 2780), 97ull, term_ctr(CID_SCON, STAT_OFF + 2782), 53ull, term_ctr(CID_SCON, STAT_OFF + 2784), 54ull, term_ctr(CID_SCON, STAT_OFF + 2786), 52ull, term_ctr(CID_SCON, STAT_OFF + 2788), 100ull, term_ctr(CID_SCON, STAT_OFF + 2790), 102ull, term_ctr(CID_SCON, STAT_OFF + 2792), 101ull, term_ctr(CID_SCON, STAT_OFF + 2794), 98ull, term_ctr(CID_SCON, STAT_OFF + 2796), 116ull, term_ctr(CID_SCON, STAT_OFF + 233), 101ull, term_ctr(CID_SCON, STAT_OFF + 2800), 115ull, term_ctr(CID_SCON, STAT_OFF + 2802), 115ull, term_ctr(CID_SCON, STAT_OFF + 2804), 97ull, term_ctr(CID_SCON, STAT_OFF + 2806), 32ull, term_ctr(CID_SCON, STAT_OFF + 2808), 114ull, term_ctr(CID_SCON, STAT_OFF + 2810), 101ull, term_ctr(CID_SCON, STAT_OFF + 2812), 108ull, term_ctr(CID_SCON, STAT_OFF + 2814), 105ull, term_ctr(CID_SCON, STAT_OFF + 2816), 112ull, term_ctr(CID_SCON, STAT_OFF + 2818), 109ull, term_ctr(CID_SCON, STAT_OFF + 2820), 111ull, term_ctr(CID_SCON, STAT_OFF + 2822), 99ull, term_ctr(CID_SCON, STAT_OFF + 2824), 32ull, term_ctr(CID_SCON, STAT_OFF + 2826), 110ull, term_ctr(CID_SCON, STAT_OFF + 2828), 119ull, term_ctr(CID_SCON, STAT_OFF + 2830), 111ull, term_ctr(CID_SCON, STAT_OFF + 2832), 110ull, term_ctr(CID_SCON, STAT_OFF + 2834), 107ull, term_ctr(CID_SCON, STAT_OFF + 2836), 110ull, term_ctr(CID_SCON, STAT_OFF + 2838), 117ull, term_ctr(CID_SCON, STAT_OFF + 2840), 47ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 2844), 116ull, term_ctr(CID_SCON, STAT_OFF + 2846), 101ull, term_ctr(CID_SCON, STAT_OFF + 2848), 115ull, term_ctr(CID_SCON, STAT_OFF + 2850), 115ull, term_ctr(CID_SCON, STAT_OFF + 2852), 97ull, term_ctr(CID_SCON, STAT_OFF + 2854), 47ull, term_ctr(CID_SCON, STAT_OFF + 2856), 46ull, term_pak(CID_SNIL, 0), 121ull, term_ctr(CID_SCON, STAT_OFF + 2860), 108ull, term_ctr(CID_SCON, STAT_OFF + 2862), 101ull, term_ctr(CID_SCON, STAT_OFF + 2864), 116ull, term_ctr(CID_SCON, STAT_OFF + 2866), 97ull, term_ctr(CID_SCON, STAT_OFF + 2868), 114ull, term_ctr(CID_SCON, STAT_OFF + 2870), 97ull, term_ctr(CID_SCON, STAT_OFF + 2872), 112ull, term_ctr(CID_SCON, STAT_OFF + 2874), 101ull, term_ctr(CID_SCON, STAT_OFF + 2876), 115ull, term_ctr(CID_SCON, STAT_OFF + 2878), 32ull, term_ctr(CID_SCON, STAT_OFF + 2880), 67ull, term_ctr(CID_SCON, STAT_OFF + 2882), 32ull, term_ctr(CID_SCON, STAT_OFF + 2884), 100ull, term_ctr(CID_SCON, STAT_OFF + 2886), 101ull, term_ctr(CID_SCON, STAT_OFF + 2888), 116ull, term_ctr(CID_SCON, STAT_OFF + 2890), 116ull, term_ctr(CID_SCON, STAT_OFF + 2892), 105ull, term_ctr(CID_SCON, STAT_OFF + 2894), 109ull, term_ctr(CID_SCON, STAT_OFF + 2896), 101ull, term_ctr(CID_SCON, STAT_OFF + 2898), 32ull, term_ctr(CID_SCON, STAT_OFF + 2900), 100ull, term_ctr(CID_SCON, STAT_OFF + 2902), 108ull, term_ctr(CID_SCON, STAT_OFF + 2904), 105ull, term_ctr(CID_SCON, STAT_OFF + 2906), 117ull, term_ctr(CID_SCON, STAT_OFF + 2908), 66ull, term_ctr(CID_SCON, STAT_OFF + 2910), 32ull, term_ctr(CID_SCON, STAT_OFF + 2912), 46ull, term_ctr(CID_SCON, STAT_OFF + 2914), 114ull, term_ctr(CID_SCON, STAT_OFF + 2916), 101ull, term_ctr(CID_SCON, STAT_OFF + 2918), 107ull, term_ctr(CID_SCON, STAT_OFF + 2920), 114ull, term_ctr(CID_SCON, STAT_OFF + 2922), 111ull, term_ctr(CID_SCON, STAT_OFF + 2924), 119ull, term_ctr(CID_SCON, STAT_OFF + 2926), 32ull, term_ctr(CID_SCON, STAT_OFF + 2928), 85ull, term_ctr(CID_SCON, STAT_OFF + 2930), 80ull, term_ctr(CID_SCON, STAT_OFF + 2932), 67ull, term_ctr(CID_SCON, STAT_OFF + 2934), 32ull, term_ctr(CID_SCON, STAT_OFF + 2936), 101ull, term_ctr(CID_SCON, STAT_OFF + 2938), 110ull, term_ctr(CID_SCON, STAT_OFF + 2940), 111ull, term_ctr(CID_SCON, STAT_OFF + 2942), 32ull, term_ctr(CID_SCON, STAT_OFF + 2944), 115ull, term_ctr(CID_SCON, STAT_OFF + 2946), 101ull, term_ctr(CID_SCON, STAT_OFF + 2948), 115ull, term_ctr(CID_SCON, STAT_OFF + 2950), 117ull, term_ctr(CID_SCON, STAT_OFF + 2952), 32ull, term_ctr(CID_SCON, STAT_OFF + 2954), 110ull, term_ctr(CID_SCON, STAT_OFF + 2956), 111ull, term_ctr(CID_SCON, STAT_OFF + 2958), 105ull, term_ctr(CID_SCON, STAT_OFF + 2960), 116ull, term_ctr(CID_SCON, STAT_OFF + 2962), 117ull, term_ctr(CID_SCON, STAT_OFF + 2964), 99ull, term_ctr(CID_SCON, STAT_OFF + 2966), 101ull, term_ctr(CID_SCON, STAT_OFF + 2968), 120ull, term_ctr(CID_SCON, STAT_OFF + 2970), 101ull, term_ctr(CID_SCON, STAT_OFF + 2972), 32ull, term_ctr(CID_SCON, STAT_OFF + 2974), 114ull, term_ctr(CID_SCON, STAT_OFF + 2976), 101ull, term_ctr(CID_SCON, STAT_OFF + 2978), 108ull, term_ctr(CID_SCON, STAT_OFF + 2980), 105ull, term_ctr(CID_SCON, STAT_OFF + 2982), 112ull, term_ctr(CID_SCON, STAT_OFF + 2984), 109ull, term_ctr(CID_SCON, STAT_OFF + 2986), 111ull, term_ctr(CID_SCON, STAT_OFF + 2988), 67ull, term_ctr(CID_SCON, STAT_OFF + 2990), 10ull, term_ctr(CID_SCON, STAT_OFF + 2992), 46ull, term_ctr(CID_SCON, STAT_OFF + 2994), 101ull, term_ctr(CID_SCON, STAT_OFF + 2996), 115ull, term_ctr(CID_SCON, STAT_OFF + 2998), 111ull, term_ctr(CID_SCON, STAT_OFF + 3000), 108ull, term_ctr(CID_SCON, STAT_OFF + 3002), 99ull, term_ctr(CID_SCON, STAT_OFF + 3004), 47ull, term_ctr(CID_SCON, STAT_OFF + 3006), 101ull, term_ctr(CID_SCON, STAT_OFF + 3008), 116ull, term_ctr(CID_SCON, STAT_OFF + 3010), 105ull, term_ctr(CID_SCON, STAT_OFF + 3012), 114ull, term_ctr(CID_SCON, STAT_OFF + 3014), 119ull, term_ctr(CID_SCON, STAT_OFF + 3016), 47ull, term_ctr(CID_SCON, STAT_OFF + 3018), 101ull, term_ctr(CID_SCON, STAT_OFF + 3020), 122ull, term_ctr(CID_SCON, STAT_OFF + 3022), 105ull, term_ctr(CID_SCON, STAT_OFF + 3024), 115ull, term_ctr(CID_SCON, STAT_OFF + 3026), 47ull, term_ctr(CID_SCON, STAT_OFF + 3028), 100ull, term_ctr(CID_SCON, STAT_OFF + 3030), 97ull, term_ctr(CID_SCON, STAT_OFF + 3032), 101ull, term_ctr(CID_SCON, STAT_OFF + 3034), 114ull, term_ctr(CID_SCON, STAT_OFF + 3036), 47ull, term_ctr(CID_SCON, STAT_OFF + 3038), 110ull, term_ctr(CID_SCON, STAT_OFF + 3040), 101ull, term_ctr(CID_SCON, STAT_OFF + 3042), 112ull, term_ctr(CID_SCON, STAT_OFF + 3044), 111ull, term_ctr(CID_SCON, STAT_OFF + 3046), 46ull, term_ctr(CID_SCON, STAT_OFF + 3048), 101ull, term_ctr(CID_SCON, STAT_OFF + 3050), 108ull, term_ctr(CID_SCON, STAT_OFF + 3052), 105ull, term_ctr(CID_SCON, STAT_OFF + 3054), 70ull, term_ctr(CID_SCON, STAT_OFF + 3056), 32ull, term_ctr(CID_SCON, STAT_OFF + 3058), 100ull, term_ctr(CID_SCON, STAT_OFF + 3060), 110ull, term_ctr(CID_SCON, STAT_OFF + 3062), 97ull, term_ctr(CID_SCON, STAT_OFF + 3064), 32ull, term_ctr(CID_SCON, STAT_OFF + 3066), 119ull, term_ctr(CID_SCON, STAT_OFF + 3068), 111ull, term_ctr(CID_SCON, STAT_OFF + 3070), 110ull, term_ctr(CID_SCON, STAT_OFF + 3072), 47ull, term_ctr(CID_SCON, STAT_OFF + 3074), 114ull, term_ctr(CID_SCON, STAT_OFF + 3076), 114ull, term_ctr(CID_SCON, STAT_OFF + 3078), 101ull, term_ctr(CID_SCON, STAT_OFF + 3080), 95ull, term_ctr(CID_SCON, STAT_OFF + 3082), 116ull, term_ctr(CID_SCON, STAT_OFF + 3084), 110ull, term_ctr(CID_SCON, STAT_OFF + 3086), 105ull, term_ctr(CID_SCON, STAT_OFF + 3088), 114ull, term_ctr(CID_SCON, STAT_OFF + 3090), 112ull, term_ctr(CID_SCON, STAT_OFF + 3092), 47ull, term_ctr(CID_SCON, STAT_OFF + 3094), 116ull, term_ctr(CID_SCON, STAT_OFF + 3096), 110ull, term_ctr(CID_SCON, STAT_OFF + 3098), 105ull, term_ctr(CID_SCON, STAT_OFF + 3100), 114ull, term_ctr(CID_SCON, STAT_OFF + 3102), 112ull, term_ctr(CID_SCON, STAT_OFF + 3104), 47ull, term_ctr(CID_SCON, STAT_OFF + 3106), 115ull, term_ctr(CID_SCON, STAT_OFF + 3108), 103ull, term_ctr(CID_SCON, STAT_OFF + 3110), 114ull, term_ctr(CID_SCON, STAT_OFF + 3112), 97ull, term_ctr(CID_SCON, STAT_OFF + 3114), 46ull, term_ctr(CID_SCON, STAT_OFF + 3116), 79ull, term_ctr(CID_SCON, STAT_OFF + 3118), 73ull, term_ctr(CID_SCON, STAT_OFF + 3120), 32ull, term_ctr(CID_SCON, STAT_OFF + 3122), 58ull, term_ctr(CID_SCON, STAT_OFF + 3124), 115ull, term_ctr(CID_SCON, STAT_OFF + 3126), 116ull, term_ctr(CID_SCON, STAT_OFF + 3128), 99ull, term_ctr(CID_SCON, STAT_OFF + 3130), 101ull, term_ctr(CID_SCON, STAT_OFF + 3132), 102ull, term_ctr(CID_SCON, STAT_OFF + 3134), 102ull, term_ctr(CID_SCON, STAT_OFF + 3136), 101ull, term_ctr(CID_SCON, STAT_OFF + 3138), 32ull, term_ctr(CID_SCON, STAT_OFF + 3140), 100ull, term_ctr(CID_SCON, STAT_OFF + 3142), 101ull, term_ctr(CID_SCON, STAT_OFF + 3144), 116ull, term_ctr(CID_SCON, STAT_OFF + 3146), 114ull, term_ctr(CID_SCON, STAT_OFF + 3148), 111ull, term_ctr(CID_SCON, STAT_OFF + 3150), 112ull, term_ctr(CID_SCON, STAT_OFF + 3152), 112ull, term_ctr(CID_SCON, STAT_OFF + 3154), 117ull, term_ctr(CID_SCON, STAT_OFF + 3156), 83ull, term_ctr(CID_SCON, STAT_OFF + 3158), 10ull, term_ctr(CID_SCON, STAT_OFF + 3160), 46ull, term_ctr(CID_SCON, STAT_OFF + 3162), 41ull, term_ctr(CID_SCON, STAT_OFF + 3164), 115ull, term_ctr(CID_SCON, STAT_OFF + 3166), 104ull, term_ctr(CID_SCON, STAT_OFF + 3168), 116ull, term_ctr(CID_SCON, STAT_OFF + 3170), 97ull, term_ctr(CID_SCON, STAT_OFF + 3172), 112ull, term_ctr(CID_SCON, STAT_OFF + 3174), 32ull, term_ctr(CID_SCON, STAT_OFF + 3176), 116ull, term_ctr(CID_SCON, STAT_OFF + 3178), 117ull, term_ctr(CID_SCON, STAT_OFF + 3180), 112ull, term_ctr(CID_SCON, STAT_OFF + 3182), 110ull, term_ctr(CID_SCON, STAT_OFF + 3184), 105ull, term_ctr(CID_SCON, STAT_OFF + 3186), 32ull, term_ctr(CID_SCON, STAT_OFF + 3188), 101ull, term_ctr(CID_SCON, STAT_OFF + 3190), 114ull, term_ctr(CID_SCON, STAT_OFF + 3192), 97ull, term_ctr(CID_SCON, STAT_OFF + 3194), 32ull, term_ctr(CID_SCON, STAT_OFF + 3196), 115ull, term_ctr(CID_SCON, STAT_OFF + 3198), 116ull, term_ctr(CID_SCON, STAT_OFF + 3200), 110ull, term_ctr(CID_SCON, STAT_OFF + 3202), 101ull, term_ctr(CID_SCON, STAT_OFF + 3204), 109ull, term_ctr(CID_SCON, STAT_OFF + 3206), 117ull, term_ctr(CID_SCON, STAT_OFF + 3208), 103ull, term_ctr(CID_SCON, STAT_OFF + 3210), 114ull, term_ctr(CID_SCON, STAT_OFF + 3212), 97ull, term_ctr(CID_SCON, STAT_OFF + 3214), 32ull, term_ctr(CID_SCON, STAT_OFF + 3216), 103ull, term_ctr(CID_SCON, STAT_OFF + 3218), 110ull, term_ctr(CID_SCON, STAT_OFF + 3220), 105ull, term_ctr(CID_SCON, STAT_OFF + 3222), 110ull, term_ctr(CID_SCON, STAT_OFF + 3224), 105ull, term_ctr(CID_SCON, STAT_OFF + 3226), 97ull, term_ctr(CID_SCON, STAT_OFF + 3228), 109ull, term_ctr(CID_SCON, STAT_OFF + 3230), 101ull, term_ctr(CID_SCON, STAT_OFF + 3232), 114ull, term_ctr(CID_SCON, STAT_OFF + 3234), 40ull, term_ctr(CID_SCON, STAT_OFF + 3236), 32ull, term_ctr(CID_SCON, STAT_OFF + 3238), 45ull, term_ctr(CID_SCON, STAT_OFF + 3240), 45ull, term_ctr(CID_SCON, STAT_OFF + 3242), 32ull, term_ctr(CID_SCON, STAT_OFF + 3244), 59ull, term_ctr(CID_SCON, STAT_OFF + 3246), 110ull, term_ctr(CID_SCON, STAT_OFF + 3248), 111ull, term_ctr(CID_SCON, STAT_OFF + 3250), 105ull, term_ctr(CID_SCON, STAT_OFF + 3252), 115ull, term_ctr(CID_SCON, STAT_OFF + 3254), 114ull, term_ctr(CID_SCON, STAT_OFF + 3256), 101ull, term_ctr(CID_SCON, STAT_OFF + 3258), 118ull, term_ctr(CID_SCON, STAT_OFF + 3260), 45ull, term_ctr(CID_SCON, STAT_OFF + 3262), 45ull, term_ctr(CID_SCON, STAT_OFF + 3264), 32ull, term_ctr(CID_SCON, STAT_OFF + 3266), 59ull, term_ctr(CID_SCON, STAT_OFF + 3268), 112ull, term_ctr(CID_SCON, STAT_OFF + 3270), 108ull, term_ctr(CID_SCON, STAT_OFF + 3272), 101ull, term_ctr(CID_SCON, STAT_OFF + 3274), 104ull, term_ctr(CID_SCON, STAT_OFF + 3276), 45ull, term_ctr(CID_SCON, STAT_OFF + 3278), 45ull, term_ctr(CID_SCON, STAT_OFF + 3280), 32ull, term_ctr(CID_SCON, STAT_OFF + 3282), 32ull, term_ctr(CID_SCON, STAT_OFF + 3284), 32ull, term_ctr(CID_SCON, STAT_OFF + 3286), 32ull, term_ctr(CID_SCON, STAT_OFF + 3288), 32ull, term_ctr(CID_SCON, STAT_OFF + 3290), 32ull, term_ctr(CID_SCON, STAT_OFF + 3292), 32ull, term_ctr(CID_SCON, STAT_OFF + 3294), 32ull, term_ctr(CID_SCON, STAT_OFF + 3296), 32ull, term_ctr(CID_SCON, STAT_OFF + 3298), 10ull, term_ctr(CID_SCON, STAT_OFF + 3300), 59ull, term_ctr(CID_SCON, STAT_OFF + 3302), 41ull, term_ctr(CID_SCON, STAT_OFF + 3304), 101ull, term_ctr(CID_SCON, STAT_OFF + 3306), 104ull, term_ctr(CID_SCON, STAT_OFF + 3308), 99ull, term_ctr(CID_SCON, STAT_OFF + 3310), 97ull, term_ctr(CID_SCON, STAT_OFF + 3312), 99ull, term_ctr(CID_SCON, STAT_OFF + 3314), 32ull, term_ctr(CID_SCON, STAT_OFF + 3316), 115ull, term_ctr(CID_SCON, STAT_OFF + 3318), 116ull, term_ctr(CID_SCON, STAT_OFF + 3320), 105ull, term_ctr(CID_SCON, STAT_OFF + 3322), 32ull, term_ctr(CID_SCON, STAT_OFF + 3324), 116ull, term_ctr(CID_SCON, STAT_OFF + 3326), 117ull, term_ctr(CID_SCON, STAT_OFF + 3328), 111ull, term_ctr(CID_SCON, STAT_OFF + 3330), 104ull, term_ctr(CID_SCON, STAT_OFF + 3332), 116ull, term_ctr(CID_SCON, STAT_OFF + 3334), 105ull, term_ctr(CID_SCON, STAT_OFF + 3336), 119ull, term_ctr(CID_SCON, STAT_OFF + 3338), 32ull, term_ctr(CID_SCON, STAT_OFF + 3340), 101ull, term_ctr(CID_SCON, STAT_OFF + 3342), 115ull, term_ctr(CID_SCON, STAT_OFF + 3344), 97ull, term_ctr(CID_SCON, STAT_OFF + 3346), 66ull, term_ctr(CID_SCON, STAT_OFF + 3348), 32ull, term_ctr(CID_SCON, STAT_OFF + 3350), 101ull, term_ctr(CID_SCON, STAT_OFF + 3352), 114ull, term_ctr(CID_SCON, STAT_OFF + 3354), 97ull, term_ctr(CID_SCON, STAT_OFF + 3356), 112ull, term_ctr(CID_SCON, STAT_OFF + 3358), 101ull, term_ctr(CID_SCON, STAT_OFF + 3360), 114ull, term_ctr(CID_SCON, STAT_OFF + 3362), 112ull, term_ctr(CID_SCON, STAT_OFF + 3364), 40ull, term_ctr(CID_SCON, STAT_OFF + 3366), 32ull, term_ctr(CID_SCON, STAT_OFF + 3368), 101ull, term_ctr(CID_SCON, STAT_OFF + 3370), 118ull, term_ctr(CID_SCON, STAT_OFF + 3372), 105ull, term_ctr(CID_SCON, STAT_OFF + 3374), 108ull, term_ctr(CID_SCON, STAT_OFF + 3376), 45ull, term_ctr(CID_SCON, STAT_OFF + 3378), 45ull, term_ctr(CID_SCON, STAT_OFF + 3380), 32ull, term_ctr(CID_SCON, STAT_OFF + 3382), 59ull, term_ctr(CID_SCON, STAT_OFF + 3384), 72ull, term_ctr(CID_SCON, STAT_OFF + 3386), 84ull, term_ctr(CID_SCON, STAT_OFF + 3388), 65ull, term_ctr(CID_SCON, STAT_OFF + 3390), 80ull, term_ctr(CID_SCON, STAT_OFF + 3392), 32ull, term_ctr(CID_SCON, STAT_OFF + 3394), 116ull, term_ctr(CID_SCON, STAT_OFF + 3396), 117ull, term_ctr(CID_SCON, STAT_OFF + 3398), 112ull, term_ctr(CID_SCON, STAT_OFF + 3400), 116ull, term_ctr(CID_SCON, STAT_OFF + 3402), 117ull, term_ctr(CID_SCON, STAT_OFF + 3404), 111ull, term_ctr(CID_SCON, STAT_OFF + 3406), 45ull, term_ctr(CID_SCON, STAT_OFF + 3408), 45ull, term_ctr(CID_SCON, STAT_OFF + 3410), 32ull, term_ctr(CID_SCON, STAT_OFF + 3412), 44ull, term_ctr(CID_SCON, STAT_OFF + 3414), 111ull, term_ctr(CID_SCON, STAT_OFF + 3416), 45ull, term_ctr(CID_SCON, STAT_OFF + 3418), 32ull, term_ctr(CID_SCON, STAT_OFF + 3420), 58ull, term_ctr(CID_SCON, STAT_OFF + 3422), 115ull, term_ctr(CID_SCON, STAT_OFF + 3424), 110ull, term_ctr(CID_SCON, STAT_OFF + 3426), 111ull, term_ctr(CID_SCON, STAT_OFF + 3428), 105ull, term_ctr(CID_SCON, STAT_OFF + 3430), 116ull, term_ctr(CID_SCON, STAT_OFF + 3432), 112ull, term_ctr(CID_SCON, STAT_OFF + 3434), 79ull, term_ctr(CID_SCON, STAT_OFF + 3436), 10ull, term_ctr(CID_SCON, STAT_OFF + 3438), 46ull, term_ctr(CID_SCON, STAT_OFF + 3440), 100ull, term_ctr(CID_SCON, STAT_OFF + 3442), 101ull, term_ctr(CID_SCON, STAT_OFF + 3444), 115ull, term_ctr(CID_SCON, STAT_OFF + 3446), 117ull, term_ctr(CID_SCON, STAT_OFF + 3448), 102ull, term_ctr(CID_SCON, STAT_OFF + 3450), 101ull, term_ctr(CID_SCON, STAT_OFF + 3452), 114ull, term_ctr(CID_SCON, STAT_OFF + 3454), 32ull, term_ctr(CID_SCON, STAT_OFF + 3456), 101ull, term_ctr(CID_SCON, STAT_OFF + 3458), 114ull, term_ctr(CID_SCON, STAT_OFF + 3460), 97ull, term_ctr(CID_SCON, STAT_OFF + 3462), 32ull, term_ctr(CID_SCON, STAT_OFF + 3464), 115ull, term_ctr(CID_SCON, STAT_OFF + 3466), 116ull, term_ctr(CID_SCON, STAT_OFF + 3468), 117ull, term_ctr(CID_SCON, STAT_OFF + 3470), 112ull, term_ctr(CID_SCON, STAT_OFF + 3472), 116ull, term_ctr(CID_SCON, STAT_OFF + 3474), 117ull, term_ctr(CID_SCON, STAT_OFF + 3476), 111ull, term_ctr(CID_SCON, STAT_OFF + 3478), 32ull, term_ctr(CID_SCON, STAT_OFF + 3480), 103ull, term_ctr(CID_SCON, STAT_OFF + 3482), 110ull, term_ctr(CID_SCON, STAT_OFF + 3484), 105ull, term_ctr(CID_SCON, STAT_OFF + 3486), 116ull, term_ctr(CID_SCON, STAT_OFF + 3488), 115ull, term_ctr(CID_SCON, STAT_OFF + 3490), 105ull, term_ctr(CID_SCON, STAT_OFF + 3492), 120ull, term_ctr(CID_SCON, STAT_OFF + 3494), 69ull, term_ctr(CID_SCON, STAT_OFF + 3496), 32ull, term_ctr(CID_SCON, STAT_OFF + 3498), 46ull, term_ctr(CID_SCON, STAT_OFF + 3500), 67ull, term_ctr(CID_SCON, STAT_OFF + 3502), 32ull, term_ctr(CID_SCON, STAT_OFF + 3504), 111ull, term_ctr(CID_SCON, STAT_OFF + 3506), 116ull, term_ctr(CID_SCON, STAT_OFF + 3508), 32ull, term_ctr(CID_SCON, STAT_OFF + 3510), 101ull, term_ctr(CID_SCON, STAT_OFF + 3512), 99ull, term_ctr(CID_SCON, STAT_OFF + 3514), 114ull, term_ctr(CID_SCON, STAT_OFF + 3516), 117ull, term_ctr(CID_SCON, STAT_OFF + 3518), 111ull, term_ctr(CID_SCON, STAT_OFF + 3520), 115ull, term_ctr(CID_SCON, STAT_OFF + 3522), 32ull, term_ctr(CID_SCON, STAT_OFF + 3524), 100ull, term_ctr(CID_SCON, STAT_OFF + 3526), 110ull, term_ctr(CID_SCON, STAT_OFF + 3528), 101ull, term_ctr(CID_SCON, STAT_OFF + 3530), 66ull, term_ctr(CID_SCON, STAT_OFF + 3532), 32ull, term_ctr(CID_SCON, STAT_OFF + 3534), 103ull, term_ctr(CID_SCON, STAT_OFF + 3536), 110ull, term_ctr(CID_SCON, STAT_OFF + 3538), 105ull, term_ctr(CID_SCON, STAT_OFF + 3540), 116ull, term_ctr(CID_SCON, STAT_OFF + 3542), 114ull, term_ctr(CID_SCON, STAT_OFF + 3544), 111ull, term_ctr(CID_SCON, STAT_OFF + 3546), 112ull, term_ctr(CID_SCON, STAT_OFF + 3548), 109ull, term_ctr(CID_SCON, STAT_OFF + 3550), 105ull, term_ctr(CID_SCON, STAT_OFF + 3552), 45ull, term_ctr(CID_SCON, STAT_OFF + 3554), 101ull, term_ctr(CID_SCON, STAT_OFF + 3556), 115ull, term_ctr(CID_SCON, STAT_OFF + 3558), 97ull, term_ctr(CID_SCON, STAT_OFF + 3560), 66ull, term_ctr(CID_SCON, STAT_OFF + 3562), 32ull, term_ctr(CID_SCON, STAT_OFF + 3564), 101ull, term_ctr(CID_SCON, STAT_OFF + 3566), 110ull, term_ctr(CID_SCON, STAT_OFF + 3568), 111ull, term_ctr(CID_SCON, STAT_OFF + 3570), 32ull, term_ctr(CID_SCON, STAT_OFF + 3572), 101ull, term_ctr(CID_SCON, STAT_OFF + 3574), 108ull, term_ctr(CID_SCON, STAT_OFF + 3576), 105ull, term_ctr(CID_SCON, STAT_OFF + 3578), 112ull, term_ctr(CID_SCON, STAT_OFF + 3580), 109ull, term_ctr(CID_SCON, STAT_OFF + 3582), 111ull, term_ctr(CID_SCON, STAT_OFF + 3584), 67ull, term_ctr(CID_SCON, STAT_OFF + 3586), 10ull, term_ctr(CID_SCON, STAT_OFF + 3588), 10ull, term_ctr(CID_SCON, STAT_OFF + 3590), 93ull, term_ctr(CID_SCON, STAT_OFF + 3592), 101ull, term_ctr(CID_SCON, STAT_OFF + 3594), 118ull, term_ctr(CID_SCON, STAT_OFF + 3596), 105ull, term_ctr(CID_SCON, STAT_OFF + 3598), 108ull, term_ctr(CID_SCON, STAT_OFF + 3600), 45ull, term_ctr(CID_SCON, STAT_OFF + 3602), 45ull, term_ctr(CID_SCON, STAT_OFF + 3604), 91ull, term_ctr(CID_SCON, STAT_OFF + 3606), 32ull, term_ctr(CID_SCON, STAT_OFF + 3608), 99ull, term_ctr(CID_SCON, STAT_OFF + 3610), 46ull, term_ctr(CID_SCON, STAT_OFF + 3612), 84ull, term_ctr(CID_SCON, STAT_OFF + 3614), 85ull, term_ctr(CID_SCON, STAT_OFF + 3616), 80ull, term_ctr(CID_SCON, STAT_OFF + 3618), 84ull, term_ctr(CID_SCON, STAT_OFF + 3620), 85ull, term_ctr(CID_SCON, STAT_OFF + 3622), 79ull, term_ctr(CID_SCON, STAT_OFF + 3624), 32ull, term_ctr(CID_SCON, STAT_OFF + 3626), 111ull, term_ctr(CID_SCON, STAT_OFF + 3628), 45ull, term_ctr(CID_SCON, STAT_OFF + 3630), 32ull, term_ctr(CID_SCON, STAT_OFF + 3632), 100ull, term_ctr(CID_SCON, STAT_OFF + 3634), 110ull, term_ctr(CID_SCON, STAT_OFF + 3636), 101ull, term_ctr(CID_SCON, STAT_OFF + 3638), 98ull, term_ctr(CID_SCON, STAT_OFF + 3640), 46ull, term_ctr(CID_SCON, STAT_OFF + 3642), 84ull, term_ctr(CID_SCON, STAT_OFF + 3644), 85ull, term_ctr(CID_SCON, STAT_OFF + 3646), 80ull, term_ctr(CID_SCON, STAT_OFF + 3648), 78ull, term_ctr(CID_SCON, STAT_OFF + 3650), 73ull, term_ctr(CID_SCON, STAT_OFF + 3652), 32ull, term_ctr(CID_SCON, STAT_OFF + 3654), 100ull, term_ctr(CID_SCON, STAT_OFF + 3656), 110ull, term_ctr(CID_SCON, STAT_OFF + 3658), 101ull, term_ctr(CID_SCON, STAT_OFF + 3660), 98ull, term_ctr(CID_SCON, STAT_OFF + 3662), 32ull, term_ctr(CID_SCON, STAT_OFF + 3664), 58ull, term_ctr(CID_SCON, STAT_OFF + 3666), 101ull, term_ctr(CID_SCON, STAT_OFF + 3668), 103ull, term_ctr(CID_SCON, STAT_OFF + 3670), 97ull, term_ctr(CID_SCON, STAT_OFF + 3672), 115ull, term_ctr(CID_SCON, STAT_OFF + 3674), 85ull, term_ctr(CID_SCON, STAT_OFF + 3676), 10ull, term_pak(CID_SNIL, 0), 66ull, term_ctr(CID_SCON, STAT_OFF + 966), 32ull, term_ctr(CID_SCON, STAT_OFF + 3682), 101ull, term_ctr(CID_SCON, STAT_OFF + 3684), 118ull, term_ctr(CID_SCON, STAT_OFF + 3686), 105ull, term_ctr(CID_SCON, STAT_OFF + 3688), 116ull, term_ctr(CID_SCON, STAT_OFF + 3690), 97ull, term_ctr(CID_SCON, STAT_OFF + 3692), 110ull, term_ctr(CID_SCON, STAT_OFF + 3694), 32ull, term_ctr(CID_SCON, STAT_OFF + 3696), 47ull, term_ctr(CID_SCON, STAT_OFF + 3698), 32ull, term_ctr(CID_SCON, STAT_OFF + 3700), 52ull, term_ctr(CID_SCON, STAT_OFF + 3702), 48ull, term_ctr(CID_SCON, STAT_OFF + 3704), 103ull, term_ctr(CID_SCON, STAT_OFF + 3706), 110ull, term_ctr(CID_SCON, STAT_OFF + 3708), 105ull, term_ctr(CID_SCON, STAT_OFF + 3710), 114ull, term_ctr(CID_SCON, STAT_OFF + 3712), 101ull, term_ctr(CID_SCON, STAT_OFF + 3714), 119ull, term_ctr(CID_SCON, STAT_OFF + 3716), 111ull, term_ctr(CID_SCON, STAT_OFF + 3718), 108ull, term_ctr(CID_SCON, STAT_OFF + 3720), 45ull, term_ctr(CID_SCON, STAT_OFF + 3722), 50ull, term_ctr(CID_SCON, STAT_OFF + 3724), 48ull, term_ctr(CID_SCON, STAT_OFF + 3726), 49ull, term_ctr(CID_SCON, STAT_OFF + 3728), 101ull, term_ctr(CID_SCON, STAT_OFF + 3730), 115ull, term_ctr(CID_SCON, STAT_OFF + 3732), 97ull, term_ctr(CID_SCON, STAT_OFF + 3734), 104ull, term_ctr(CID_SCON, STAT_OFF + 3736), 112ull, term_ctr(CID_SCON, STAT_OFF + 3738), 32ull, term_ctr(CID_SCON, STAT_OFF + 3740), 47ull, term_ctr(CID_SCON, STAT_OFF + 3742), 32ull, term_ctr(CID_SCON, STAT_OFF + 3744), 51ull, term_ctr(CID_SCON, STAT_OFF + 3746), 48ull, term_ctr(CID_SCON, STAT_OFF + 3748), 49ull, term_ctr(CID_SCON, STAT_OFF + 3750), 101ull, term_ctr(CID_SCON, STAT_OFF + 3752), 115ull, term_ctr(CID_SCON, STAT_OFF + 3754), 97ull, term_ctr(CID_SCON, STAT_OFF + 3756), 104ull, term_ctr(CID_SCON, STAT_OFF + 3758), 112ull, term_ctr(CID_SCON, STAT_OFF + 3760), 32ull, term_ctr(CID_SCON, STAT_OFF + 3762), 101ull, term_ctr(CID_SCON, STAT_OFF + 3764), 118ull, term_ctr(CID_SCON, STAT_OFF + 3766), 105ull, term_ctr(CID_SCON, STAT_OFF + 3768), 116ull, term_ctr(CID_SCON, STAT_OFF + 3770), 97ull, term_ctr(CID_SCON, STAT_OFF + 3772), 110ull, term_ctr(CID_SCON, STAT_OFF + 3774), 45ull, term_ctr(CID_SCON, STAT_OFF + 3776), 100ull, term_ctr(CID_SCON, STAT_OFF + 3778), 110ull, term_ctr(CID_SCON, STAT_OFF + 3780), 101ull, term_ctr(CID_SCON, STAT_OFF + 3782), 98ull, term_ctr(CID_SCON, STAT_OFF + 3784) };
INLINE bool native_bool(Term t) { return t == 1 || (term_tag(t) == TAG_PAK && term_aux(t) == CID_TRUE); }
INLINE Term native_word(Env e, u32 x) {
  Term w = term_pak(CID_WNIL, 0);
  for (u32 i = 32; i > 0; i--) {
    Loc p = heap_alloc(e, 1);
    e.mem[p] = (x >> (i - 1)) & 1;
    e.mem[p + 1] = rfc_seal(e, w);
    w = term_ctr(CID_WCON, p);
  }
  return w;
}
#if !DEVICE && NATIVE_COLD_CTORS
#endif
#if !DEVICE
#if NATIVE_TYPED_SCALARS
#define NF_SCALAR u32
#else
#define NF_SCALAR Term
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NF_INLINE INLINE __attribute__((always_inline))
#else
#define NF_INLINE INLINE
#endif
/* Experimental private cache of one uniquely transferred constructor cell.
 * ctr_take's returned cell has no remaining owner. Its fields have already
 * moved to ordinary local Terms. Shared inputs return zero; static inputs
 * may return a read-only location below HEAP_OFF and must never be cached.
 * The public wrapper frees any unused cell before publishing its result.
 */
INLINE void p102_trmc_keep_cell(Env e, Term* state, Cls cls, Loc cell) {
  if (cell < HEAP_OFF) return;
  if (state[2]) spare_free(e, (Cls)state[3], (Loc)state[2]);
  state[2] = cell;
  state[3] = cls;
}

INLINE Loc p102_trmc_take_cell(Env e, Term* state, Cls cls) {
  if (state[2] && state[3] == cls) {
    Loc cell = (Loc)state[2];
    state[2] = 0;
    return cell;
  }
  return heap_alloc(e, cls);
}
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(Env e, bool seq, Term* nf_out, Term v_4294967295);
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_97_100_97_112_116_101_114_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(Env e, bool seq, Term* nf_out, Term v_4294967295);
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_83_116_114_105_110_103_46_99_109_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294);
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_97_100_97_112_116_101_114_46_83_116_114_105_110_103_46_99_109_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294);
NF_INLINE Term NF_FID_67_104_97_114_46_105_115_95_101_113_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294);
NF_INLINE Term NF_FID_66_111_111_108_46_110_111_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295);
NF_INLINE Term NF_FID_66_111_111_108_46_97_110_100_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294);
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(Env e, bool seq, Term* nf_out, Term v_4294967295);
NF_INLINE Term NF_FID_67_104_97_114_46_99_109_112_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294);
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_99_109_112_46_114_101_99_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293);
INLINE Term NF_FID_83_116_114_105_110_103_46_99_109_112_46_102_105_110_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294, Term v_4294967293);
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_99_109_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294);
NF_INLINE Term NF_FID_80_97_105_114_46_115_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967295);
INLINE Term NF_FID_83_116_114_105_110_103_46_111_114_100_101_114_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294);
NF_INLINE Term NF_FID_67_109_112_46_105_115_95_101_113_(Env e, bool seq, Term* nf_out, Term v_4294967295);
INLINE Term NF_FID_83_116_114_105_110_103_46_101_113_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294);
INLINE Term NF_FID_99_108_105_95_100_105_103_101_115_116_(Env e, bool seq, Term* nf_out, Term v_4294967295);
NF_INLINE Term NF_FID_99_108_105_95_104_101_108_112_(Env e, bool seq, Term* nf_out);
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294);
NF_INLINE Term NF_FID_73_79_46_100_105_101_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, Term v_4294967294, Term v_4294967293);
NF_INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_80_97_105_114_46_115_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967294, Term v_4294967293);
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(Env e, bool seq, Term* nf_out, Term v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
#if NATIVE_READONLY_OBSERVERS
if ((term_aux(v_4294967295) == CID_SNIL)) {
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = 1;
return 1;
} else {
if ((term_aux(v_4294967295) == CID_SCON)) {
Loc no_loc_1 = term_peek(e, v_4294967295);
Term v_4294967293 = e.mem[no_loc_1 + 0];
Term v_4294967292 = e.mem[no_loc_1 + 1];
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = 0;
return 1;
} else {
err_post(e.mem, ERR_FIDS); return 0;
}
}
#else
return 0;
#endif
}
return 0;
}
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_97_100_97_112_116_101_114_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(Env e, bool seq, Term* nf_out, Term v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
#if NATIVE_READONLY_OBSERVERS
Term no_root_0 = v_4294967295;
if (!seq && err_seen(e.mem)) { return 0; }
Term no_observed[1];
if (!NF_FID_36_111_98_115_101_114_118_101_114_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, no_observed, v_4294967295)) { return 0; }
if (!seq && err_seen(e.mem)) { return 0; }
Term no_scalar_result = no_observed[0];
term_sink(e, no_root_0);
nf_out[0] = no_scalar_result;
return 1;
#else
return 0;
#endif
}
return 0;
}
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_83_116_114_105_110_103_46_99_109_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
#if NATIVE_READONLY_OBSERVERS
if ((term_aux(v_4294967295) == CID_SNIL)) {
if ((term_aux(v_4294967294) == CID_SNIL)) {
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = term_pak(CID_EQ, 0);
return 1;
} else {
if ((term_aux(v_4294967294) == CID_SCON)) {
Loc no_loc_2 = term_peek(e, v_4294967294);
Term v_4294967292 = e.mem[no_loc_2 + 0];
Term v_4294967291 = e.mem[no_loc_2 + 1];
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = term_pak(CID_LT, 0);
return 1;
} else {
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
if ((term_aux(v_4294967295) == CID_SCON)) {
Loc no_loc_3 = term_peek(e, v_4294967295);
Term v_4294967290 = e.mem[no_loc_3 + 0];
Term v_4294967289 = e.mem[no_loc_3 + 1];
if ((term_aux(v_4294967294) == CID_SNIL)) {
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = term_pak(CID_GT, 0);
return 1;
} else {
if ((term_aux(v_4294967294) == CID_SCON)) {
Loc no_loc_5 = term_peek(e, v_4294967294);
Term v_4294967288 = e.mem[no_loc_5 + 0];
Term v_4294967287 = e.mem[no_loc_5 + 1];
if (1) {
Term v_4294967286 = v_4294967290;
if (1) {
Term v_4294967285 = v_4294967288;
Term v_4294967284 = term_pak(((U32_BIN(v_4294967286, >, v_4294967285) + U32_BIN(v_4294967286, >=, v_4294967285))) == 0 ? CID_LT : ((U32_BIN(v_4294967286, >, v_4294967285) + U32_BIN(v_4294967286, >=, v_4294967285))) == 1 ? CID_EQ : CID_GT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967284) == CID_LT)) {
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = term_pak(CID_LT, 0);
return 1;
} else {
if ((term_aux(v_4294967284) == CID_EQ)) {
{
Term nf_arg_0 = v_4294967289;
Term nf_arg_1 = v_4294967287;
v_4294967295 = nf_arg_0;
v_4294967294 = nf_arg_1;
goto nf_again;
}
} else {
if ((term_aux(v_4294967284) == CID_GT)) {
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = term_pak(CID_GT, 0);
return 1;
} else {
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
} else {
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
err_post(e.mem, ERR_FIDS); return 0;
}
}
#else
return 0;
#endif
}
return 0;
}
NF_INLINE Term NF_FID_36_111_98_115_101_114_118_101_114_46_97_100_97_112_116_101_114_46_83_116_114_105_110_103_46_99_109_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
#if NATIVE_READONLY_OBSERVERS
Term no_root_0 = v_4294967295;
Term no_root_1 = v_4294967294;
if (!seq && err_seen(e.mem)) { return 0; }
Term no_observed[1];
if (!NF_FID_36_111_98_115_101_114_118_101_114_46_83_116_114_105_110_103_46_99_109_112_(e, seq, no_observed, v_4294967295, v_4294967294)) { return 0; }
if (!seq && err_seen(e.mem)) { return 0; }
Term no_scalar_result = no_observed[0];
Term v_4294967282;
{
Term v_4294967277;
{
v_4294967277 = no_root_0;
goto nf_join_20;
}
nf_join_20:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967276;
{
v_4294967276 = no_root_1;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_22 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_22 + 0] = v_4294967277;
e.mem[nd_22 + 1] = v_4294967276;
#else
e.mem[nd_22 + 0] = rfc_seal(e, v_4294967277);
e.mem[nd_22 + 1] = rfc_seal(e, v_4294967276);
#endif
v_4294967282 = term_ctr(CID_TUPLE, nd_22);
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = no_scalar_result;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_17 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_17 + 0] = v_4294967282;
e.mem[nd_17 + 1] = v_4294967281;
#else
e.mem[nd_17 + 0] = rfc_seal(e, v_4294967282);
e.mem[nd_17 + 1] = rfc_seal(e, v_4294967281);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_17);
return 1;
#else
return 0;
#endif
}
return 0;
}
NF_INLINE Term NF_FID_67_104_97_114_46_105_115_95_101_113_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294967289 = v_4294967293;
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294967288 = v_4294967292;
Term v_4294967287;
{
v_4294967287 = v_4294967289;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967286;
{
v_4294967286 = v_4294967288;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = U32_BIN(v_4294967287, ==, v_4294967286);
return 1;
} else {
term_sink(e, v_4294967289);
term_sink(e, v_4294967292);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294967293);
term_sink(e, v_4294967292);
err_post(e.mem, ERR_FIDS); return 0;
}
}
return 0;
}
NF_INLINE Term NF_FID_66_111_111_108_46_110_111_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
if ((!native_bool(v_4294967295))) {
nf_out[0] = 1ull;
return 1;
} else {
if (native_bool(v_4294967295)) {
nf_out[0] = 0ull;
return 1;
} else {
term_sink(e, v_4294967295);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_66_111_111_108_46_97_110_100_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((!native_bool(v_4294967293))) {
term_sink(e, v_4294967292);
nf_out[0] = 0ull;
return 1;
} else {
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967289)) {
nf_out[0] = v_4294967288;
return 1;
} else {
term_sink(e, v_4294967289);
term_sink(e, v_4294967288);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(Env e, bool seq, Term* nf_out, Term v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
if ((term_rfc(v_4294967295) && (rfc_view(e, term_loc(v_4294967295)) & RFC_CNT) > 1) || 0) { return NF_FID_36_111_98_115_101_114_118_101_114_46_97_100_97_112_116_101_114_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_out, v_4294967295); }
if ((term_aux(v_4294967295) == CID_SNIL)) {
nf_out[0] = 1ull;
return 1;
} else {
if ((term_aux(v_4294967295) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967295, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294967294 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294967293 = fields[1];
term_sink(e, v_4294967294);
term_sink(e, v_4294967293);
nf_out[0] = 0ull;
return 1;
} else {
term_sink(e, v_4294967295);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_67_104_97_114_46_99_109_112_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294967289 = v_4294967293;
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294967288 = v_4294967292;
v_4294967289 = term_keep(e, v_4294967289);
v_4294967288 = term_keep(e, v_4294967288);
Term v_4294967285;
Term v_4294967284;
{
Term v_4294967273;
{
Term v_4294967267;
{
v_4294967267 = v_4294967289;
goto nf_join_29;
}
nf_join_29:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967273 = v_4294967267;
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967272;
{
Term v_4294967269;
{
v_4294967269 = v_4294967288;
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967272 = v_4294967269;
goto nf_join_25;
}
nf_join_25:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967285 = v_4294967273;
v_4294967284 = v_4294967272;
goto nq_join_10;
}
nq_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967286;
{
Term v_4294967277;
{
v_4294967277 = v_4294967289;
goto nf_join_20;
}
nf_join_20:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967276;
{
v_4294967276 = v_4294967288;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
Term cmp = (U32_BIN(v_4294967277, >, v_4294967276) + U32_BIN(v_4294967277, >=, v_4294967276));
v_4294967286 = term_pak(cmp == 0 ? CID_LT : cmp == 1 ? CID_EQ : CID_GT, 0);
goto nf_join_12;
}
nf_join_12:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
u64 nd_17 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_17 + 0] = v_4294967285;
e.mem[nd_17 + 1] = v_4294967284;
#else
e.mem[nd_17 + 0] = rfc_seal(e, v_4294967285);
e.mem[nd_17 + 1] = rfc_seal(e, v_4294967284);
#endif
v_4294967282 = term_ctr(CID_TUPLE, nd_17);
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_16 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_16 + 0] = v_4294967282;
e.mem[nd_16 + 1] = v_4294967286;
#else
e.mem[nd_16 + 0] = rfc_seal(e, v_4294967282);
e.mem[nd_16 + 1] = rfc_seal(e, v_4294967286);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_16);
return 1;
} else {
term_sink(e, v_4294967289);
term_sink(e, v_4294967292);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294967293);
term_sink(e, v_4294967292);
err_post(e.mem, ERR_FIDS); return 0;
}
}
return 0;
}
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_99_109_112_46_114_101_99_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
if ((term_aux(v_4294967293) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967293, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294967292 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294967291 = fields[1];
Term v_4294967290;
{
v_4294967290 = v_4294967292;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967291;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967290) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967290, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294967286 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294967285 = fields[1];
Term v_4294967282;
Term v_4294967281;
{
Term v_4294967274;
{
Term v_4294967265;
{
v_4294967265 = v_4294967295;
goto nf_join_32;
}
nf_join_32:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967264;
{
v_4294967264 = v_4294967286;
goto nf_join_33;
}
nf_join_33:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_34 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_34 + 0] = v_4294967265;
e.mem[nd_34 + 1] = v_4294967264;
#else
e.mem[nd_34 + 0] = rfc_seal(e, v_4294967265);
e.mem[nd_34 + 1] = rfc_seal(e, v_4294967264);
#endif
v_4294967274 = term_ctr(CID_SCON, nd_34);
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967273;
{
Term v_4294967270;
{
v_4294967270 = v_4294967294;
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967269;
{
v_4294967269 = v_4294967285;
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_29 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_29 + 0] = v_4294967270;
e.mem[nd_29 + 1] = v_4294967269;
#else
e.mem[nd_29 + 0] = rfc_seal(e, v_4294967270);
e.mem[nd_29 + 1] = rfc_seal(e, v_4294967269);
#endif
v_4294967273 = term_ctr(CID_SCON, nd_29);
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967282 = v_4294967274;
v_4294967281 = v_4294967273;
goto nq_join_13;
}
nq_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967283;
{
v_4294967283 = v_4294967289;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967279;
{
u64 nd_20 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_20 + 0] = v_4294967282;
e.mem[nd_20 + 1] = v_4294967281;
#else
e.mem[nd_20 + 0] = rfc_seal(e, v_4294967282);
e.mem[nd_20 + 1] = rfc_seal(e, v_4294967281);
#endif
v_4294967279 = term_ctr(CID_TUPLE, nd_20);
goto nf_join_18;
}
nf_join_18:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_19 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19 + 0] = v_4294967279;
e.mem[nd_19 + 1] = v_4294967283;
#else
e.mem[nd_19 + 0] = rfc_seal(e, v_4294967279);
e.mem[nd_19 + 1] = rfc_seal(e, v_4294967283);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_19);
return 1;
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967294);
term_sink(e, v_4294967290);
term_sink(e, v_4294967289);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967294);
term_sink(e, v_4294967293);
err_post(e.mem, ERR_FIDS); return 0;
}
}
return 0;
}
INLINE Term NF_FID_83_116_114_105_110_103_46_99_109_112_46_102_105_110_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294, Term v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
if ((term_aux(v_4294967293) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967293, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294967292 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294967291 = fields[1];
Term v_4294967290;
{
v_4294967290 = v_4294967292;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967291;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967290) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967290, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294967286 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294967285 = fields[1];
if ((term_aux(v_4294967289) == CID_LT)) {
Term v_4294967282;
Term v_4294967281;
{
Term v_4294967274;
{
Term v_4294967265;
{
v_4294967265 = v_4294967286;
goto nf_join_32;
}
nf_join_32:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967264;
{
v_4294967264 = v_4294967295;
goto nf_join_33;
}
nf_join_33:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_34 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_34 + 0] = v_4294967265;
e.mem[nd_34 + 1] = v_4294967264;
#else
e.mem[nd_34 + 0] = rfc_seal(e, v_4294967265);
e.mem[nd_34 + 1] = rfc_seal(e, v_4294967264);
#endif
v_4294967274 = term_ctr(CID_SCON, nd_34);
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967273;
{
Term v_4294967270;
{
v_4294967270 = v_4294967285;
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967269;
{
v_4294967269 = v_4294967294;
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_29 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_29 + 0] = v_4294967270;
e.mem[nd_29 + 1] = v_4294967269;
#else
e.mem[nd_29 + 0] = rfc_seal(e, v_4294967270);
e.mem[nd_29 + 1] = rfc_seal(e, v_4294967269);
#endif
v_4294967273 = term_ctr(CID_SCON, nd_29);
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967282 = v_4294967274;
v_4294967281 = v_4294967273;
goto nq_join_13;
}
nq_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967283;
{
v_4294967283 = term_pak(CID_LT, 0);
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967279;
{
u64 nd_20 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_20 + 0] = v_4294967282;
e.mem[nd_20 + 1] = v_4294967281;
#else
e.mem[nd_20 + 0] = rfc_seal(e, v_4294967282);
e.mem[nd_20 + 1] = rfc_seal(e, v_4294967281);
#endif
v_4294967279 = term_ctr(CID_TUPLE, nd_20);
goto nf_join_18;
}
nf_join_18:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_19 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19 + 0] = v_4294967279;
e.mem[nd_19 + 1] = v_4294967283;
#else
e.mem[nd_19 + 0] = rfc_seal(e, v_4294967279);
e.mem[nd_19 + 1] = rfc_seal(e, v_4294967283);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_19);
return 1;
} else {
if ((term_aux(v_4294967289) == CID_EQ)) {
Term v_4294967260;
{
v_4294967260 = v_4294967286;
goto nf_join_38;
}
nf_join_38:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967259;
{
v_4294967259 = v_4294967285;
goto nf_join_39;
}
nf_join_39:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967258;
{
Term v_4294967253;
{
v_4294967253 = v_4294967295;
goto nf_join_44;
}
nf_join_44:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967252;
{
v_4294967252 = v_4294967294;
goto nf_join_45;
}
nf_join_45:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_46[1];
if (!NF_FID_83_116_114_105_110_103_46_99_109_112_(e, seq, nq_result_46, v_4294967253, v_4294967252)) { return 0; }
v_4294967258 = nq_result_46[0];
goto nf_join_40;
}
nf_join_40:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_41[1];
if (!NF_FID_83_116_114_105_110_103_46_99_109_112_46_114_101_99_(e, seq, nq_result_41, v_4294967260, v_4294967259, v_4294967258)) { return 0; }
nf_out[0] = nq_result_41[0];
return 1;
} else {
if ((term_aux(v_4294967289) == CID_GT)) {
Term v_4294967246;
Term v_4294967245;
{
Term v_4294967238;
{
Term v_4294967229;
{
v_4294967229 = v_4294967286;
goto nf_join_68;
}
nf_join_68:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967228;
{
v_4294967228 = v_4294967295;
goto nf_join_69;
}
nf_join_69:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_70 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_70 + 0] = v_4294967229;
e.mem[nd_70 + 1] = v_4294967228;
#else
e.mem[nd_70 + 0] = rfc_seal(e, v_4294967229);
e.mem[nd_70 + 1] = rfc_seal(e, v_4294967228);
#endif
v_4294967238 = term_ctr(CID_SCON, nd_70);
goto nf_join_59;
}
nf_join_59:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967237;
{
Term v_4294967234;
{
v_4294967234 = v_4294967285;
goto nf_join_63;
}
nf_join_63:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967233;
{
v_4294967233 = v_4294967294;
goto nf_join_64;
}
nf_join_64:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_65 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_65 + 0] = v_4294967234;
e.mem[nd_65 + 1] = v_4294967233;
#else
e.mem[nd_65 + 0] = rfc_seal(e, v_4294967234);
e.mem[nd_65 + 1] = rfc_seal(e, v_4294967233);
#endif
v_4294967237 = term_ctr(CID_SCON, nd_65);
goto nf_join_60;
}
nf_join_60:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967246 = v_4294967238;
v_4294967245 = v_4294967237;
goto nq_join_49;
}
nq_join_49:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967247;
{
v_4294967247 = term_pak(CID_GT, 0);
goto nf_join_51;
}
nf_join_51:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967243;
{
u64 nd_56 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_56 + 0] = v_4294967246;
e.mem[nd_56 + 1] = v_4294967245;
#else
e.mem[nd_56 + 0] = rfc_seal(e, v_4294967246);
e.mem[nd_56 + 1] = rfc_seal(e, v_4294967245);
#endif
v_4294967243 = term_ctr(CID_TUPLE, nd_56);
goto nf_join_54;
}
nf_join_54:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_55 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_55 + 0] = v_4294967243;
e.mem[nd_55 + 1] = v_4294967247;
#else
e.mem[nd_55 + 0] = rfc_seal(e, v_4294967243);
e.mem[nd_55 + 1] = rfc_seal(e, v_4294967247);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_55);
return 1;
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967294);
term_sink(e, v_4294967286);
term_sink(e, v_4294967285);
term_sink(e, v_4294967289);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967294);
term_sink(e, v_4294967290);
term_sink(e, v_4294967289);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967294);
term_sink(e, v_4294967293);
err_post(e.mem, ERR_FIDS); return 0;
}
}
return 0;
}
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_99_109_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
return NF_FID_36_111_98_115_101_114_118_101_114_46_97_100_97_112_116_101_114_46_83_116_114_105_110_103_46_99_109_112_(e, seq, nf_out, v_4294967295, v_4294967294);
}
return 0;
}
NF_INLINE Term NF_FID_80_97_105_114_46_115_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
if ((term_aux(v_4294967295) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967295, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294967294 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294967293 = fields[1];
term_sink(e, v_4294967294);
nf_out[0] = v_4294967293;
return 1;
} else {
term_sink(e, v_4294967295);
err_post(e.mem, ERR_FIDS); return 0;
}
}
return 0;
}
INLINE Term NF_FID_83_116_114_105_110_103_46_111_114_100_101_114_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
#if NATIVE_READONLY_OBSERVERS
Term no_root_0 = v_4294967295;
Term no_root_1 = v_4294967294;
if (!seq && err_seen(e.mem)) { return 0; }
Term no_observed[1];
if (!NF_FID_36_111_98_115_101_114_118_101_114_46_83_116_114_105_110_103_46_99_109_112_(e, seq, no_observed, v_4294967295, v_4294967294)) { return 0; }
if (!seq && err_seen(e.mem)) { return 0; }
Term no_scalar_result = no_observed[0];
term_sink(e, no_root_0);
term_sink(e, no_root_1);
nf_out[0] = no_scalar_result;
return 1;
#else
return 0;
#endif
}
return 0;
}
NF_INLINE Term NF_FID_67_109_112_46_105_115_95_101_113_(Env e, bool seq, Term* nf_out, Term v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
if ((term_aux(v_4294967295) == CID_EQ)) {
nf_out[0] = 1ull;
return 1;
} else {
term_sink(e, v_4294967295);
nf_out[0] = 0ull;
return 1;
}
}
return 0;
}
INLINE Term NF_FID_83_116_114_105_110_103_46_101_113_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
Term v_4294967290;
{
v_4294967290 = v_4294967295;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967294;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_9[1];
if (!NF_FID_83_116_114_105_110_103_46_111_114_100_101_114_(e, seq, nq_result_9, v_4294967290, v_4294967289)) { return 0; }
v_4294967293 = nq_result_9[0];
goto nf_join_3;
}
nf_join_3:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_4[1];
if (!NF_FID_67_109_112_46_105_115_95_101_113_(e, seq, nq_result_4, v_4294967293)) { return 0; }
nf_out[0] = nq_result_4[0];
return 1;
}
return 0;
}
INLINE Term NF_FID_99_108_105_95_100_105_103_101_115_116_(Env e, bool seq, Term* nf_out, Term v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967294;
{
Term v_4294966147;
{
v_4294966147 = v_4294967295;
goto nf_join_1150;
}
nf_join_1150:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966146;
{
v_4294966146 = term_ctr(CID_SCON, STAT_OFF + 378);
goto nf_join_1151;
}
nf_join_1151:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1152[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1152, v_4294966147, v_4294966146)) { return 0; }
v_4294967294 = nq_result_1152[0];
goto nf_join_65;
}
nf_join_65:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967294)) {
term_sink(e, v_4294967295);
Term v_3591;
{
v_3591 = term_pak(CID_UNIT, 0);
goto nf_join_66;
}
nf_join_66:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3591);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 506);
return 1;
} else {
if ((!native_bool(v_4294967294))) {
Term v_3592;
{
v_3592 = term_pak(CID_UNIT, 0);
goto nf_join_67;
}
nf_join_67:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3592);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967227;
{
Term v_4294966152;
{
v_4294966152 = v_4294967295;
goto nf_join_1145;
}
nf_join_1145:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966151;
{
v_4294966151 = term_ctr(CID_SCON, STAT_OFF + 522);
goto nf_join_1146;
}
nf_join_1146:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1147[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1147, v_4294966152, v_4294966151)) { return 0; }
v_4294967227 = nq_result_1147[0];
goto nf_join_132;
}
nf_join_132:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967227)) {
term_sink(e, v_4294967295);
Term v_3593;
{
v_3593 = term_pak(CID_UNIT, 0);
goto nf_join_133;
}
nf_join_133:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3593);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 650);
return 1;
} else {
if ((!native_bool(v_4294967227))) {
Term v_3594;
{
v_3594 = term_pak(CID_UNIT, 0);
goto nf_join_134;
}
nf_join_134:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3594);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967160;
{
Term v_4294966157;
{
v_4294966157 = v_4294967295;
goto nf_join_1140;
}
nf_join_1140:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966156;
{
v_4294966156 = term_ctr(CID_SCON, STAT_OFF + 680);
goto nf_join_1141;
}
nf_join_1141:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1142[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1142, v_4294966157, v_4294966156)) { return 0; }
v_4294967160 = nq_result_1142[0];
goto nf_join_199;
}
nf_join_199:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967160)) {
term_sink(e, v_4294967295);
Term v_3595;
{
v_3595 = term_pak(CID_UNIT, 0);
goto nf_join_200;
}
nf_join_200:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3595);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 806);
return 1;
} else {
if ((!native_bool(v_4294967160))) {
Term v_3596;
{
v_3596 = term_pak(CID_UNIT, 0);
goto nf_join_201;
}
nf_join_201:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3596);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967093;
{
Term v_4294966162;
{
v_4294966162 = v_4294967295;
goto nf_join_1135;
}
nf_join_1135:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966161;
{
v_4294966161 = term_ctr(CID_SCON, STAT_OFF + 836);
goto nf_join_1136;
}
nf_join_1136:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1137[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1137, v_4294966162, v_4294966161)) { return 0; }
v_4294967093 = nq_result_1137[0];
goto nf_join_266;
}
nf_join_266:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967093)) {
term_sink(e, v_4294967295);
Term v_3597;
{
v_3597 = term_pak(CID_UNIT, 0);
goto nf_join_267;
}
nf_join_267:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3597);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 964);
return 1;
} else {
if ((!native_bool(v_4294967093))) {
Term v_3598;
{
v_3598 = term_pak(CID_UNIT, 0);
goto nf_join_268;
}
nf_join_268:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3598);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967026;
{
Term v_4294966167;
{
v_4294966167 = v_4294967295;
goto nf_join_1130;
}
nf_join_1130:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966166;
{
v_4294966166 = term_ctr(CID_SCON, STAT_OFF + 994);
goto nf_join_1131;
}
nf_join_1131:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1132[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1132, v_4294966167, v_4294966166)) { return 0; }
v_4294967026 = nq_result_1132[0];
goto nf_join_333;
}
nf_join_333:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967026)) {
term_sink(e, v_4294967295);
Term v_3599;
{
v_3599 = term_pak(CID_UNIT, 0);
goto nf_join_334;
}
nf_join_334:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3599);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 1120);
return 1;
} else {
if ((!native_bool(v_4294967026))) {
Term v_3600;
{
v_3600 = term_pak(CID_UNIT, 0);
goto nf_join_335;
}
nf_join_335:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3600);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966959;
{
Term v_4294966172;
{
v_4294966172 = v_4294967295;
goto nf_join_1125;
}
nf_join_1125:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966171;
{
v_4294966171 = term_ctr(CID_SCON, STAT_OFF + 1150);
goto nf_join_1126;
}
nf_join_1126:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1127[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1127, v_4294966172, v_4294966171)) { return 0; }
v_4294966959 = nq_result_1127[0];
goto nf_join_400;
}
nf_join_400:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966959)) {
term_sink(e, v_4294967295);
Term v_3601;
{
v_3601 = term_pak(CID_UNIT, 0);
goto nf_join_401;
}
nf_join_401:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3601);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 1278);
return 1;
} else {
if ((!native_bool(v_4294966959))) {
Term v_3602;
{
v_3602 = term_pak(CID_UNIT, 0);
goto nf_join_402;
}
nf_join_402:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3602);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966892;
{
Term v_4294966177;
{
v_4294966177 = v_4294967295;
goto nf_join_1120;
}
nf_join_1120:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966176;
{
v_4294966176 = term_ctr(CID_SCON, STAT_OFF + 1308);
goto nf_join_1121;
}
nf_join_1121:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1122[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1122, v_4294966177, v_4294966176)) { return 0; }
v_4294966892 = nq_result_1122[0];
goto nf_join_467;
}
nf_join_467:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966892)) {
term_sink(e, v_4294967295);
Term v_3603;
{
v_3603 = term_pak(CID_UNIT, 0);
goto nf_join_468;
}
nf_join_468:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3603);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 1436);
return 1;
} else {
if ((!native_bool(v_4294966892))) {
Term v_3604;
{
v_3604 = term_pak(CID_UNIT, 0);
goto nf_join_469;
}
nf_join_469:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3604);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966825;
{
Term v_4294966182;
{
v_4294966182 = v_4294967295;
goto nf_join_1115;
}
nf_join_1115:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966181;
{
v_4294966181 = term_ctr(CID_SCON, STAT_OFF + 1458);
goto nf_join_1116;
}
nf_join_1116:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1117[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1117, v_4294966182, v_4294966181)) { return 0; }
v_4294966825 = nq_result_1117[0];
goto nf_join_534;
}
nf_join_534:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966825)) {
term_sink(e, v_4294967295);
Term v_3605;
{
v_3605 = term_pak(CID_UNIT, 0);
goto nf_join_535;
}
nf_join_535:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3605);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 1584);
return 1;
} else {
if ((!native_bool(v_4294966825))) {
Term v_3606;
{
v_3606 = term_pak(CID_UNIT, 0);
goto nf_join_536;
}
nf_join_536:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3606);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966758;
{
Term v_4294966187;
{
v_4294966187 = v_4294967295;
goto nf_join_1110;
}
nf_join_1110:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966186;
{
v_4294966186 = term_ctr(CID_SCON, STAT_OFF + 1604);
goto nf_join_1111;
}
nf_join_1111:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1112[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1112, v_4294966187, v_4294966186)) { return 0; }
v_4294966758 = nq_result_1112[0];
goto nf_join_601;
}
nf_join_601:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966758)) {
term_sink(e, v_4294967295);
Term v_3607;
{
v_3607 = term_pak(CID_UNIT, 0);
goto nf_join_602;
}
nf_join_602:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3607);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 1732);
return 1;
} else {
if ((!native_bool(v_4294966758))) {
Term v_3608;
{
v_3608 = term_pak(CID_UNIT, 0);
goto nf_join_603;
}
nf_join_603:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3608);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966691;
{
Term v_4294966192;
{
v_4294966192 = v_4294967295;
goto nf_join_1105;
}
nf_join_1105:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966191;
{
v_4294966191 = term_ctr(CID_SCON, STAT_OFF + 1748);
goto nf_join_1106;
}
nf_join_1106:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1107[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1107, v_4294966192, v_4294966191)) { return 0; }
v_4294966691 = nq_result_1107[0];
goto nf_join_668;
}
nf_join_668:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966691)) {
term_sink(e, v_4294967295);
Term v_3609;
{
v_3609 = term_pak(CID_UNIT, 0);
goto nf_join_669;
}
nf_join_669:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3609);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 1874);
return 1;
} else {
if ((!native_bool(v_4294966691))) {
Term v_3610;
{
v_3610 = term_pak(CID_UNIT, 0);
goto nf_join_670;
}
nf_join_670:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3610);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966624;
{
Term v_4294966197;
{
v_4294966197 = v_4294967295;
goto nf_join_1100;
}
nf_join_1100:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966196;
{
v_4294966196 = term_ctr(CID_SCON, STAT_OFF + 1902);
goto nf_join_1101;
}
nf_join_1101:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1102[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1102, v_4294966197, v_4294966196)) { return 0; }
v_4294966624 = nq_result_1102[0];
goto nf_join_735;
}
nf_join_735:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966624)) {
term_sink(e, v_4294967295);
Term v_3611;
{
v_3611 = term_pak(CID_UNIT, 0);
goto nf_join_736;
}
nf_join_736:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3611);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 2028);
return 1;
} else {
if ((!native_bool(v_4294966624))) {
Term v_3612;
{
v_3612 = term_pak(CID_UNIT, 0);
goto nf_join_737;
}
nf_join_737:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3612);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966557;
{
Term v_4294966202;
{
v_4294966202 = v_4294967295;
goto nf_join_1095;
}
nf_join_1095:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966201;
{
v_4294966201 = term_ctr(CID_SCON, STAT_OFF + 2056);
goto nf_join_1096;
}
nf_join_1096:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1097[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1097, v_4294966202, v_4294966201)) { return 0; }
v_4294966557 = nq_result_1097[0];
goto nf_join_802;
}
nf_join_802:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966557)) {
term_sink(e, v_4294967295);
Term v_3613;
{
v_3613 = term_pak(CID_UNIT, 0);
goto nf_join_803;
}
nf_join_803:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3613);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 2182);
return 1;
} else {
if ((!native_bool(v_4294966557))) {
Term v_3614;
{
v_3614 = term_pak(CID_UNIT, 0);
goto nf_join_804;
}
nf_join_804:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3614);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966490;
{
Term v_4294966207;
{
v_4294966207 = v_4294967295;
goto nf_join_1090;
}
nf_join_1090:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966206;
{
v_4294966206 = term_ctr(CID_SCON, STAT_OFF + 2210);
goto nf_join_1091;
}
nf_join_1091:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1092[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1092, v_4294966207, v_4294966206)) { return 0; }
v_4294966490 = nq_result_1092[0];
goto nf_join_869;
}
nf_join_869:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966490)) {
term_sink(e, v_4294967295);
Term v_3615;
{
v_3615 = term_pak(CID_UNIT, 0);
goto nf_join_870;
}
nf_join_870:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3615);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 2336);
return 1;
} else {
if ((!native_bool(v_4294966490))) {
Term v_3616;
{
v_3616 = term_pak(CID_UNIT, 0);
goto nf_join_871;
}
nf_join_871:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3616);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966423;
{
Term v_4294966212;
{
v_4294966212 = v_4294967295;
goto nf_join_1085;
}
nf_join_1085:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966211;
{
v_4294966211 = term_ctr(CID_SCON, STAT_OFF + 2364);
goto nf_join_1086;
}
nf_join_1086:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1087[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1087, v_4294966212, v_4294966211)) { return 0; }
v_4294966423 = nq_result_1087[0];
goto nf_join_936;
}
nf_join_936:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966423)) {
term_sink(e, v_4294967295);
Term v_3617;
{
v_3617 = term_pak(CID_UNIT, 0);
goto nf_join_937;
}
nf_join_937:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3617);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 2490);
return 1;
} else {
if ((!native_bool(v_4294966423))) {
Term v_3618;
{
v_3618 = term_pak(CID_UNIT, 0);
goto nf_join_938;
}
nf_join_938:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3618);
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294966356;
{
Term v_4294966217;
{
v_4294966217 = v_4294967295;
goto nf_join_1080;
}
nf_join_1080:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966216;
{
v_4294966216 = term_ctr(CID_SCON, STAT_OFF + 2518);
goto nf_join_1081;
}
nf_join_1081:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1082[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1082, v_4294966217, v_4294966216)) { return 0; }
v_4294966356 = nq_result_1082[0];
goto nf_join_1003;
}
nf_join_1003:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966356)) {
term_sink(e, v_4294967295);
Term v_3619;
{
v_3619 = term_pak(CID_UNIT, 0);
goto nf_join_1004;
}
nf_join_1004:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3619);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 2644);
return 1;
} else {
if ((!native_bool(v_4294966356))) {
Term v_3620;
{
v_3620 = term_pak(CID_UNIT, 0);
goto nf_join_1005;
}
nf_join_1005:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3620);
Term v_4294966289;
{
Term v_4294966222;
{
v_4294966222 = v_4294967295;
goto nf_join_1075;
}
nf_join_1075:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294966221;
{
v_4294966221 = term_ctr(CID_SCON, STAT_OFF + 2672);
goto nf_join_1076;
}
nf_join_1076:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_1077[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result_1077, v_4294966222, v_4294966221)) { return 0; }
v_4294966289 = nq_result_1077[0];
goto nf_join_1070;
}
nf_join_1070:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294966289)) {
Term v_3621;
{
v_3621 = term_pak(CID_UNIT, 0);
goto nf_join_1071;
}
nf_join_1071:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3621);
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 2798);
return 1;
} else {
if ((!native_bool(v_4294966289))) {
Term v_3622;
{
v_3622 = term_pak(CID_UNIT, 0);
goto nf_join_1072;
}
nf_join_1072:;
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3622);
nf_out[0] = term_pak(CID_SNIL, 0);
return 1;
} else {
term_sink(e, v_4294966289);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966356);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966423);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966490);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966557);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966624);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966691);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966758);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966825);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966892);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294966959);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967026);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967093);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967160);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967227);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967295);
term_sink(e, v_4294967294);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_99_108_105_95_104_101_108_112_(Env e, bool seq, Term* nf_out) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 3678);
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100__trmc(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967293) == CID_SNIL)) {
if (nf_out[1] != 0) { e.mem[nf_out[1]] = nf_out[4] ? rfc_seal(e, v_4294967292) : v_4294967292; } else { nf_out[0] = v_4294967292; }
return 1;
} else {
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967289) == CID_SCON)) {
Term fields[2];
p102_trmc_keep_cell(e, nf_out, cls_fit(2), ctr_take(e, v_4294967289, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294967285 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294967284 = fields[1];
Term v_4294967283;
{
v_4294967283 = v_4294967285;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
v_4294967282 = v_4294967284;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = v_4294967288;
goto nf_join_17;
}
nf_join_17:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_18 = p102_trmc_take_cell(e, nf_out, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_18 + 0] = v_4294967283;
e.mem[nd_18 + 1] = TERM_HOLE;
#else
e.mem[nd_18 + 0] = rfc_seal(e, v_4294967283);
e.mem[nd_18 + 1] = rfc_seal(e, TERM_HOLE);
#endif
Term ntr_node_19 = term_ctr(CID_SCON, nd_18);
if (nf_out[1] != 0) { e.mem[nf_out[1]] = nf_out[4] ? rfc_seal(e, ntr_node_19) : ntr_node_19; } else { nf_out[0] = ntr_node_19; }
nf_out[1] = term_loc(ntr_node_19) + 1;
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
nf_out[4] = 0;
#else
nf_out[4] = 1;
#endif
{
Term nf_arg_0 = v_4294967282;
Term nf_arg_1 = v_4294967281;
v_4294967295 = nf_arg_0;
v_4294967294 = nf_arg_1;
goto nf_again;
}
} else {
term_sink(e, v_4294967289);
term_sink(e, v_4294967288);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
Term ntr_state[5] = { TERM_HOLE, 0, 0, 0, 0 };
Term ntr_ok = NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100__trmc(e, seq, ntr_state, v_4294967295, v_4294967294);
if (ntr_state[2]) spare_free(e, (Cls)ntr_state[3], (Loc)ntr_state[2]);
if (!ntr_ok) { term_sink(e, ntr_state[0]); return 0; }
nf_out[0] = ntr_state[0];
return 1;
}
NF_INLINE Term NF_FID_73_79_46_100_105_101_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, Term v_4294967294, Term v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
term_sink(e, v_4294967293);
Term v_4294967292;
{
v_4294967292 = v_4294967295;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
v_4294967291 = v_4294967294;
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_7 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_HALT
e.mem[nd_7 + 0] = v_4294967292;
e.mem[nd_7 + 1] = v_4294967291;
#else
e.mem[nd_7 + 0] = rfc_seal(e, v_4294967292);
e.mem[nd_7 + 1] = rfc_seal(e, v_4294967291);
#endif
nf_out[0] = term_ctr(CID_HALT, nd_7);
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_80_97_105_114_46_115_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967294, Term v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
v_4294967294 = (u32)v_4294967294;
#endif
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
v_4294967293 = (u32)v_4294967293;
#endif
term_sink(e, v_4294967294);
nf_out[0] = v_4294967293;
return 1;
}
return 0;
}
#undef NF_INLINE
#undef NF_SCALAR
#endif


// Work
// ====

// A host self-jump is a tail call: as a loop, MachineLICM hoisted eleven
// constants into symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Reply (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#if FID_ENTER >= 4096
// Keep the shared dispatch table out of each segment's LLVM reference graph.
FAR PRESERVE(preserve_most) WlFn wl_target(Fid id) { return wl_tab[id]; }
#undef WL_DYN
#define WL_DYN(F) __attribute__((musttail)) return wl_target(F)(WL_ALL)
#endif
#endif

static Reply work_loop(Env e, Stk sp, Term t, bool seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  Fid fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

#if !DEVICE
  WL_CASE(FID_109_97_105_110_)
  {
    WL_OPEN
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_48_50_55_;
WL_PUSHN(1);
} else {
u64 task_1033 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_50_55_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_50_55_, task_1033);
WL_IDX = 0;
}
WL_JMP(FID_73_79_46_97_114_103_115_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_50_55_)
  {
    Term v_4294966271 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294966271;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_48_50_56_;
WL_PUSHN(2);
} else {
u64 task_1033 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_50_56_, WL_CONT, WL_IDX, 1);
e.mem[task_1033 + 0] = v_4294966271;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_50_56_, task_1033);
WL_IDX = 1;
}
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_48_51_49_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_50_56_)
  {
    WL_POPN(1);
    Term v_4294966271 = STK(0);
    Term v_4294966270 = r0;
    WL_OPEN
u64 cl_1030 = heap_alloc(e, cls_fit(2));
e.mem[cl_1030 + 0] = v_4294966271;
e.mem[cl_1030 + 1] = v_4294966270;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_48_50_57_, cl_1030);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_50_57_)
  {
    Term v_4294966271 = r0;
    Term v_4294966270 = r1;
    Term v_4294966269 = r2;
    WL_OPEN
r0 = v_4294966271;
r1 = v_4294966270;
r2 = v_4294966269;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_51_49_)
  {
    Term v_3588 = r0;
    WL_OPEN
Term v_4294966263 = v_3588;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294966263;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_109_97_105_110_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_73_79_46_98_105_110_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_48_54_48_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_54_48_)
  {
    Term v_4294965238 = r0;
    WL_OPEN
u64 cl_2064 = heap_alloc(e, cls_fit(1));
e.mem[cl_2064 + 0] = v_4294965238;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_48_54_49_, cl_2064);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_54_49_)
  {
    Term v_4294965238 = r0;
    Term v_4294965237 = r1;
    WL_OPEN
u64 cl_2063 = heap_alloc(e, cls_fit(2));
e.mem[cl_2063 + 0] = v_4294965238;
e.mem[cl_2063 + 1] = v_4294965237;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_48_54_50_, cl_2063);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_54_50_)
  {
    Term v_4294965238 = r0;
    Term v_4294965237 = r1;
    Term v_4294965236 = r2;
    WL_OPEN
r0 = v_4294965238;
r1 = v_4294965237;
r2 = v_4294965236;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_)
  {
    Term v_4294965230 = r0;
    Term v_4294965229 = r1;
    Term v_4294965228 = r2;
    WL_OPEN
Term v_4294965227 = v_4294965230;
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294965227;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_48_55_48_;
WL_PUSHN(2);
} else {
u64 task_2078 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_48_55_48_, WL_CONT, WL_IDX, 1);
e.mem[task_2078 + 0] = v_4294965227;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_48_55_48_, task_2078);
WL_IDX = 1;
}
u64 cl_2077 = heap_alloc(e, cls_fit(2));
e.mem[cl_2077 + 0] = v_4294965229;
e.mem[cl_2077 + 1] = v_4294965228;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_48_55_49_, cl_2077);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_55_48_)
  {
    WL_POPN(1);
    Term v_4294965227 = STK(0);
    Term v_4294965226 = r0;
    WL_OPEN
{ Term fn = v_4294965227; Term arg = v_4294965226;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_55_49_)
  {
    Term v_4294965229 = r0;
    Term v_4294965228 = r1;
    Term v_184 = r2;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294965228;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_48_55_52_;
WL_PUSHN(2);
} else {
u64 task_2077 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_48_55_52_, WL_CONT, WL_IDX, 1);
e.mem[task_2077 + 0] = v_4294965228;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_48_55_52_, task_2077);
WL_IDX = 1;
}
Term v_4294965220 = v_4294965229;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294965219 = v_184;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294965220; Term arg = v_4294965219;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_55_52_)
  {
    WL_POPN(1);
    Term v_4294965228 = STK(0);
    Term v_4294965223 = r0;
    WL_OPEN
Term v_4294965222 = v_4294965228;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294965223; Term arg = v_4294965222;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_73_79_46_97_114_103_115_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_48_50_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_48_50_)
  {
    Term v_4294965216 = r0;
    WL_OPEN
u64 nd_3103 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_IO_ARGS
e.mem[nd_3103 + 0] = v_4294965216;
#else
e.mem[nd_3103 + 0] = rfc_seal(e, v_4294965216);
#endif
r0 = term_ctr(CID_IO_ARGS, nd_3103);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_73_79_46_97_114_103_115_)
  {
    Term v_4294964191 = r0;
    WL_OPEN
u64 nd_3105 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_IO_ARGS
e.mem[nd_3105 + 0] = v_4294964191;
#else
e.mem[nd_3105 + 0] = rfc_seal(e, v_4294964191);
#endif
r0 = term_ctr(CID_IO_ARGS, nd_3105);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_109_97_105_110_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_51_49_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_51_49_)
  {
    Term v_4294963165 = r0;
    WL_OPEN
r0 = v_4294963165;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_109_97_105_110_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_109_97_105_110_)
  {
    Term v_4294963163 = r0;
    WL_OPEN
if ((term_aux(v_4294963163) == CID_CON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294963163, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_CON_0
u32
#else
Term
#endif
v_4294963162 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_CON_1
u32
#else
Term
#endif
v_4294963161 = fields[1];
term_sink(e, v_4294963162);
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_52_49_51_54_;
WL_PUSHN(1);
} else {
u64 task_4138 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_49_51_54_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_49_51_54_, task_4138);
WL_IDX = 0;
}
Term v_4294963158 = v_4294963161;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294963158;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_114_115_101_);
} else {
if ((term_aux(v_4294963163) == CID_NIL)) {
Term v_4294963157 = 2ull;
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294963157;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_49_52_49_;
WL_PUSHN(2);
} else {
u64 task_4144 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_49_52_49_, WL_CONT, WL_IDX, 1);
e.mem[task_4144 + 0] = v_4294963157;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_49_52_49_, task_4144);
WL_IDX = 1;
}
WL_JMP(FID_99_108_105_95_104_101_108_112_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294963163;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_49_52_54_;
WL_PUSHN(2);
} else {
u64 task_4147 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_49_52_54_, WL_CONT, WL_IDX, 1);
e.mem[task_4147 + 0] = v_4294963163;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_49_52_54_, task_4147);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_51_54_)
  {
    Term v_4294963160 = r0;
    WL_OPEN
r0 = v_4294963160;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_115_112_97_116_99_104_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_52_49_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294963157 = STK(0);
    Term v_4294963156 = r0;
    WL_OPEN
u64 cl_4143 = heap_alloc(e, cls_fit(2));
e.mem[cl_4143 + 0] = v_4294963157;
e.mem[cl_4143 + 1] = v_4294963156;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_52_50_, cl_4143);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_52_50_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294963157 = r0;
    Term v_4294963156 = r1;
    Term v_4294963155 = r2;
    WL_OPEN
r0 = v_4294963157;
r1 = v_4294963156;
r2 = v_4294963155;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_52_54_)
  {
    WL_POPN(1);
    Term v_4294963163 = STK(0);
    Term v_4294963151 = r0;
    WL_OPEN
Term v_4294963150 = v_4294963163;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294963151; Term arg = v_4294963150;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_100_105_115_112_97_116_99_104_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_55_50_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_55_50_)
  {
    Term v_4294962124 = r0;
    WL_OPEN
r0 = v_4294962124;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_115_112_97_116_99_104_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_115_112_97_116_99_104_)
  {
    Term v_4294962122 = r0;
    WL_OPEN
if ((term_aux(v_4294962122) == CID__CTOR_67_76_73_69_114_114_111_114_)) {
Term fields[1];
if (term_tag(v_4294962122) == TAG_PAK) { fields[0] = term_loc(v_4294962122); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294962122, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_67_76_73_69_114_114_111_114__0
u32
#else
Term
#endif
v_4294962121 = fields[0];
Term v_4294962120 = 2ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962115 = v_4294962121;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962114 = term_ctr(CID_SCON, STAT_OFF + 3680);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962117;
{
Term nf_local_5182[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_5182, v_4294962115, v_4294962114)) { return 0; }
v_4294962117 = nf_local_5182[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(3);
STK(0) = v_4294962120;
STK(1) = v_4294962117;
STK(2) = FID_110_97_116_105_118_101_95_107_95_53_49_56_51_;
WL_PUSHN(3);
} else {
u64 task_5187 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_49_56_51_, WL_CONT, WL_IDX, 1);
e.mem[task_5187 + 0] = v_4294962120;
e.mem[task_5187 + 1] = v_4294962117;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_49_56_51_, task_5187);
WL_IDX = 2;
}
WL_JMP(FID_99_108_105_95_104_101_108_112_);
} else {
if ((term_aux(v_4294962122) == CID__CTOR_67_76_73_72_101_108_112_)) {
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_53_49_57_48_;
WL_PUSHN(1);
} else {
u64 task_5203 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_49_57_48_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_49_57_48_, task_5203);
WL_IDX = 0;
}
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_53_50_48_49_;
WL_PUSHN(1);
} else {
u64 task_5203 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_50_48_49_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_50_48_49_, task_5203);
WL_IDX = 0;
}
WL_JMP(FID_73_79_46_112_114_105_110_116_);
} else {
if ((term_aux(v_4294962122) == CID__CTOR_67_76_73_86_101_114_115_105_111_110_)) {
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_53_50_48_54_;
WL_PUSHN(1);
} else {
u64 task_5218 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_50_48_54_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_50_48_54_, task_5218);
WL_IDX = 0;
}
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_53_50_49_55_;
WL_PUSHN(1);
} else {
u64 task_5218 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_50_49_55_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_50_49_55_, task_5218);
WL_IDX = 0;
}
WL_JMP(FID_73_79_46_112_114_105_110_116_);
} else {
if ((term_aux(v_4294962122) == CID__CTOR_67_76_73_82_101_113_117_101_115_116_)) {
Term fields[3];
spare_free(e, cls_fit(3), ctr_take(e, v_4294962122, 3, fields));
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_67_76_73_82_101_113_117_101_115_116__0
u32
#else
Term
#endif
v_4294962077 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_67_76_73_82_101_113_117_101_115_116__1
u32
#else
Term
#endif
v_4294962076 = fields[1];
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_67_76_73_82_101_113_117_101_115_116__2
u32
#else
Term
#endif
v_4294962075 = fields[2];
Term v_4294962074 = v_4294962077;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962073 = v_4294962076;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962072 = v_4294962075;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294962074;
r1 = v_4294962073;
r2 = v_4294962072;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_113_117_101_115_116_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294962122;
STK(1) = FID_110_97_116_105_118_101_95_107_95_53_50_50_54_;
WL_PUSHN(2);
} else {
u64 task_5227 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_50_50_54_, WL_CONT, WL_IDX, 1);
e.mem[task_5227 + 0] = v_4294962122;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_50_50_54_, task_5227);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_56_51_)
  {
    WL_POPN(2);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294962120 = STK(0);
    Term v_4294962117 = STK(1);
    Term v_4294962116 = r0;
    WL_OPEN
Term v_4294962119;
{
Term nf_local_5184[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_5184, v_4294962117, v_4294962116)) { return 0; }
v_4294962119 = nf_local_5184[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_5186 = heap_alloc(e, cls_fit(2));
e.mem[cl_5186 + 0] = v_4294962120;
e.mem[cl_5186 + 1] = v_4294962119;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_56_53_, cl_5186);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_56_53_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294962120 = r0;
    Term v_4294962119 = r1;
    Term v_4294962118 = r2;
    WL_OPEN
r0 = v_4294962120;
r1 = v_4294962119;
r2 = v_4294962118;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_57_48_)
  {
    Term v_4294962108 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294962108;
STK(1) = FID_110_97_116_105_118_101_95_107_95_53_49_57_49_;
WL_PUSHN(2);
} else {
u64 task_5199 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_49_57_49_, WL_CONT, WL_IDX, 1);
e.mem[task_5199 + 0] = v_4294962108;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_49_57_49_, task_5199);
WL_IDX = 1;
}
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_57_52_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_57_49_)
  {
    WL_POPN(1);
    Term v_4294962108 = STK(0);
    Term v_4294962107 = r0;
    WL_OPEN
u64 cl_5193 = heap_alloc(e, cls_fit(2));
e.mem[cl_5193 + 0] = v_4294962108;
e.mem[cl_5193 + 1] = v_4294962107;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_57_50_, cl_5193);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_57_50_)
  {
    Term v_4294962108 = r0;
    Term v_4294962107 = r1;
    Term v_4294962106 = r2;
    WL_OPEN
r0 = v_4294962108;
r1 = v_4294962107;
r2 = v_4294962106;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_57_52_)
  {
    Term v_3580 = r0;
    WL_OPEN
term_sink(e, v_3580);
Term v_4294962100 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_5198 = heap_alloc(e, cls_fit(1));
e.mem[cl_5198 + 0] = v_4294962100;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_57_55_, cl_5198);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_57_55_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294962100 = r0;
    Term v_4294962099 = r1;
    WL_OPEN
r0 = v_4294962100;
r1 = v_4294962099;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_48_49_)
  {
    Term v_4294962096 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294962096;
STK(1) = FID_110_97_116_105_118_101_95_107_95_53_50_48_50_;
WL_PUSHN(2);
} else {
u64 task_5203 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_50_48_50_, WL_CONT, WL_IDX, 1);
e.mem[task_5203 + 0] = v_4294962096;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_50_48_50_, task_5203);
WL_IDX = 1;
}
WL_JMP(FID_99_108_105_95_104_101_108_112_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_48_50_)
  {
    WL_POPN(1);
    Term v_4294962096 = STK(0);
    Term v_4294962095 = r0;
    WL_OPEN
{ Term fn = v_4294962096; Term arg = v_4294962095;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_48_54_)
  {
    Term v_4294962092 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294962092;
STK(1) = FID_110_97_116_105_118_101_95_107_95_53_50_48_55_;
WL_PUSHN(2);
} else {
u64 task_5215 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_50_48_55_, WL_CONT, WL_IDX, 1);
e.mem[task_5215 + 0] = v_4294962092;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_50_48_55_, task_5215);
WL_IDX = 1;
}
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_50_49_48_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_48_55_)
  {
    WL_POPN(1);
    Term v_4294962092 = STK(0);
    Term v_4294962091 = r0;
    WL_OPEN
u64 cl_5209 = heap_alloc(e, cls_fit(2));
e.mem[cl_5209 + 0] = v_4294962092;
e.mem[cl_5209 + 1] = v_4294962091;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_50_48_56_, cl_5209);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_48_56_)
  {
    Term v_4294962092 = r0;
    Term v_4294962091 = r1;
    Term v_4294962090 = r2;
    WL_OPEN
r0 = v_4294962092;
r1 = v_4294962091;
r2 = v_4294962090;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_49_48_)
  {
    Term v_3581 = r0;
    WL_OPEN
term_sink(e, v_3581);
Term v_4294962084 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_5214 = heap_alloc(e, cls_fit(1));
e.mem[cl_5214 + 0] = v_4294962084;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_50_49_51_, cl_5214);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_49_51_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294962084 = r0;
    Term v_4294962083 = r1;
    WL_OPEN
r0 = v_4294962084;
r1 = v_4294962083;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_49_55_)
  {
    Term v_4294962080 = r0;
    WL_OPEN
Term v_4294962079 = term_ctr(CID_SCON, STAT_OFF + 3786);
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294962080; Term arg = v_4294962079;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_50_50_54_)
  {
    WL_POPN(1);
    Term v_4294962122 = STK(0);
    Term v_4294962071 = r0;
    WL_OPEN
Term v_4294962070 = v_4294962122;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294962071; Term arg = v_4294962070;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_73_79_46_100_105_101_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_54_50_53_52_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_53_52_)
  {
    Term v_4294961044 = r0;
    WL_OPEN
u64 cl_6258 = heap_alloc(e, cls_fit(1));
e.mem[cl_6258 + 0] = v_4294961044;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_54_50_53_53_, cl_6258);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_53_53_)
  {
    Term v_4294961044 = r0;
    Term v_4294961043 = r1;
    WL_OPEN
u64 cl_6257 = heap_alloc(e, cls_fit(2));
e.mem[cl_6257 + 0] = v_4294961044;
e.mem[cl_6257 + 1] = v_4294961043;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_54_50_53_54_, cl_6257);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_53_54_)
  {
    Term v_4294961044 = r0;
    Term v_4294961043 = r1;
    Term v_4294961042 = r2;
    WL_OPEN
r0 = v_4294961044;
r1 = v_4294961043;
r2 = v_4294961042;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294961036 = r0;
    Term v_4294961035 = r1;
    Term v_4294961034 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_73_79_46_100_105_101_(e, seq, nq_result, v_4294961036, v_4294961035, v_4294961034)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
term_sink(e, v_4294961034);
Term v_4294961033 = v_4294961036;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961032 = v_4294961035;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_6264 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_HALT
e.mem[nd_6264 + 0] = v_4294961033;
e.mem[nd_6264 + 1] = v_4294961032;
#else
e.mem[nd_6264 + 0] = rfc_seal(e, v_4294961033);
e.mem[nd_6264 + 1] = rfc_seal(e, v_4294961032);
#endif
r0 = term_ctr(CID_HALT, nd_6264);
WL_RETN(1);
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_97_112_112_101_110_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_55_50_57_49_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_55_50_57_49_)
  {
    Term v_4294960006 = r0;
    WL_OPEN
u64 cl_7293 = heap_alloc(e, cls_fit(1));
e.mem[cl_7293 + 0] = v_4294960006;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_55_50_57_50_, cl_7293);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_55_50_57_50_)
  {
    Term v_4294960006 = r0;
    Term v_4294960005 = r1;
    WL_OPEN
r0 = v_4294960006;
r1 = v_4294960005;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_97_112_112_101_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_97_112_112_101_110_100_)
  {
    Term v_4294960001 = r0;
    Term v_4294960000 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nq_result, v_4294960001, v_4294960000)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294959999 = v_4294960001;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294959998 = v_4294960000;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294959999) == CID_SNIL)) {
r0 = v_4294959998;
WL_RETN(1);
} else {
Term v_4294959997 = v_4294959999;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294959996 = v_4294959998;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294959997) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294959997, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294959995 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294959994 = fields[1];
Term v_4294959993 = v_4294959995;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294959991 = v_4294959994;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294959990 = v_4294959996;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294959992;
{
Term nf_local_7306[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_7306, v_4294959991, v_4294959990)) { return 0; }
v_4294959992 = nf_local_7306[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_7307 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_7307 + 0] = v_4294959993;
e.mem[nd_7307 + 1] = v_4294959992;
#else
e.mem[nd_7307 + 0] = rfc_seal(e, v_4294959993);
e.mem[nd_7307 + 1] = rfc_seal(e, v_4294959992);
#endif
r0 = term_ctr(CID_SCON, nd_7307);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294959996;
STK(1) = FID_110_97_116_105_118_101_95_107_95_55_51_49_48_;
WL_PUSHN(2);
} else {
u64 task_7314 = task_node(e, FID_110_97_116_105_118_101_95_107_95_55_51_49_48_, WL_CONT, WL_IDX, 1);
e.mem[task_7314 + 0] = v_4294959996;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_55_51_49_48_, task_7314);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294959997;
STK(1) = FID_110_97_116_105_118_101_95_107_95_55_51_49_51_;
WL_PUSHN(2);
} else {
u64 task_7314 = task_node(e, FID_110_97_116_105_118_101_95_107_95_55_51_49_51_, WL_CONT, WL_IDX, 1);
e.mem[task_7314 + 0] = v_4294959997;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_55_51_49_51_, task_7314);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_55_51_49_48_)
  {
    WL_POPN(1);
    Term v_4294959996 = STK(0);
    Term v_4294959987 = r0;
    WL_OPEN
Term v_4294959986 = v_4294959996;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294959987; Term arg = v_4294959986;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_55_51_49_51_)
  {
    WL_POPN(1);
    Term v_4294959997 = STK(0);
    Term v_4294959984 = r0;
    WL_OPEN
Term v_4294959983 = v_4294959997;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294959984; Term arg = v_4294959983;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_104_101_108_112_)
  {
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_99_108_105_95_104_101_108_112_(e, seq, nq_result)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
r0 = term_ctr(CID_SCON, STAT_OFF + 3678);
WL_RETN(1);
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_73_79_46_112_114_105_110_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_57_51_54_50_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_57_51_54_50_)
  {
    Term v_4294958957 = r0;
    WL_OPEN
u64 cl_9365 = heap_alloc(e, cls_fit(1));
e.mem[cl_9365 + 0] = v_4294958957;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_57_51_54_51_, cl_9365);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_57_51_54_51_)
  {
    Term v_4294958957 = r0;
    Term v_4294958955 = r1;
    WL_OPEN
u64 nd_9364 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_IO_PRINT
e.mem[nd_9364 + 0] = v_4294958957;
e.mem[nd_9364 + 1] = v_4294958955;
#else
e.mem[nd_9364 + 0] = rfc_seal(e, v_4294958957);
e.mem[nd_9364 + 1] = rfc_seal(e, v_4294958955);
#endif
r0 = term_ctr(CID_IO_PRINT, nd_9364);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_73_79_46_112_114_105_110_116_)
  {
    Term v_4294957929 = r0;
    Term v_4294957928 = r1;
    WL_OPEN
u64 nd_9368 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_IO_PRINT
e.mem[nd_9368 + 0] = v_4294957929;
e.mem[nd_9368 + 1] = v_4294957928;
#else
e.mem[nd_9368 + 0] = rfc_seal(e, v_4294957929);
e.mem[nd_9368 + 1] = rfc_seal(e, v_4294957928);
#endif
r0 = term_ctr(CID_IO_PRINT, nd_9368);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_73_79_46_112_117_114_101_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_48_51_57_53_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_51_57_53_)
  {
    Term v_4294956902 = r0;
    WL_OPEN
u64 cl_10397 = heap_alloc(e, cls_fit(1));
e.mem[cl_10397 + 0] = v_4294956902;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_48_51_57_54_, cl_10397);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_51_57_54_)
  {
    Term v_4294956902 = r0;
    Term v_4294956901 = r1;
    WL_OPEN
r0 = v_4294956902;
r1 = v_4294956901;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_)
  {
    Term v_4294956897 = r0;
    Term v_4294956896 = r1;
    WL_OPEN
Term v_4294956895 = v_4294956896;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294956894 = v_4294956897;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294956895; Term arg = v_4294956894;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_114_101_113_117_101_115_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_57_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_57_)
  {
    Term v_4294955869 = r0;
    WL_OPEN
u64 cl_11433 = heap_alloc(e, cls_fit(1));
e.mem[cl_11433 + 0] = v_4294955869;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_48_, cl_11433);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_48_)
  {
    Term v_4294955869 = r0;
    Term v_4294955868 = r1;
    WL_OPEN
u64 cl_11432 = heap_alloc(e, cls_fit(2));
e.mem[cl_11432 + 0] = v_4294955869;
e.mem[cl_11432 + 1] = v_4294955868;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_49_, cl_11432);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_49_)
  {
    Term v_4294955869 = r0;
    Term v_4294955868 = r1;
    Term v_4294955867 = r2;
    WL_OPEN
r0 = v_4294955869;
r1 = v_4294955868;
r2 = v_4294955867;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_113_117_101_115_116_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_113_117_101_115_116_)
  {
    Term v_4294955861 = r0;
    Term v_4294955860 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294955859 = r2;
    WL_OPEN
term_sink(e, v_4294955859);
if (seq) {
WL_ROOM(3);
STK(0) = v_4294955861;
STK(1) = v_4294955860;
STK(2) = FID_110_97_116_105_118_101_95_107_95_49_49_52_52_48_;
WL_PUSHN(3);
} else {
u64 task_11530 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_52_48_, WL_CONT, WL_IDX, 1);
e.mem[task_11530 + 0] = v_4294955861;
e.mem[task_11530 + 1] = v_4294955860;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_48_, task_11530);
WL_IDX = 2;
}
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_49_53_50_57_;
WL_PUSHN(1);
} else {
u64 task_11530 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_53_50_57_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_53_50_57_, task_11530);
WL_IDX = 0;
}
WL_JMP(FID_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_48_)
  {
    WL_POPN(2);
    Term v_4294955861 = STK(0);
    Term v_4294955860 = STK(1);
    Term v_4294955858 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955858;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_52_49_;
WL_PUSHN(2);
} else {
u64 task_11527 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_52_49_, WL_CONT, WL_IDX, 1);
e.mem[task_11527 + 0] = v_4294955858;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_49_, task_11527);
WL_IDX = 1;
}
u64 cl_11526 = heap_alloc(e, cls_fit(2));
e.mem[cl_11526 + 0] = v_4294955861;
e.mem[cl_11526 + 1] = v_4294955860;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_52_, cl_11526);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_49_)
  {
    WL_POPN(1);
    Term v_4294955858 = STK(0);
    Term v_4294955857 = r0;
    WL_OPEN
u64 cl_11443 = heap_alloc(e, cls_fit(2));
e.mem[cl_11443 + 0] = v_4294955858;
e.mem[cl_11443 + 1] = v_4294955857;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_, cl_11443);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_)
  {
    Term v_4294955858 = r0;
    Term v_4294955857 = r1;
    Term v_4294955856 = r2;
    WL_OPEN
r0 = v_4294955858;
r1 = v_4294955857;
r2 = v_4294955856;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_52_)
  {
    Term v_4294955861 = r0;
    Term v_4294955860 = r1;
    Term v_3570 = r2;
    WL_OPEN
if (seq) {
WL_ROOM(3);
STK(0) = v_4294955861;
STK(1) = v_4294955860;
STK(2) = FID_110_97_116_105_118_101_95_107_95_49_49_52_52_56_;
WL_PUSHN(3);
} else {
u64 task_11526 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_52_56_, WL_CONT, WL_IDX, 1);
e.mem[task_11526 + 0] = v_4294955861;
e.mem[task_11526 + 1] = v_4294955860;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_56_, task_11526);
WL_IDX = 2;
}
Term v_4294955770 = v_3570;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955770;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_115_115_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_56_)
  {
    WL_POPN(2);
    Term v_4294955861 = STK(0);
    Term v_4294955860 = STK(1);
    Term v_4294955850 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955850;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_52_57_;
WL_PUSHN(2);
} else {
u64 task_11525 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_52_57_, WL_CONT, WL_IDX, 1);
e.mem[task_11525 + 0] = v_4294955850;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_57_, task_11525);
WL_IDX = 1;
}
u64 cl_11524 = heap_alloc(e, cls_fit(2));
e.mem[cl_11524 + 0] = v_4294955861;
e.mem[cl_11524 + 1] = v_4294955860;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_50_, cl_11524);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_57_)
  {
    WL_POPN(1);
    Term v_4294955850 = STK(0);
    Term v_4294955849 = r0;
    WL_OPEN
u64 cl_11451 = heap_alloc(e, cls_fit(2));
e.mem[cl_11451 + 0] = v_4294955850;
e.mem[cl_11451 + 1] = v_4294955849;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_48_, cl_11451);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_48_)
  {
    Term v_4294955850 = r0;
    Term v_4294955849 = r1;
    Term v_4294955848 = r2;
    WL_OPEN
r0 = v_4294955850;
r1 = v_4294955849;
r2 = v_4294955848;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_50_)
  {
    Term v_4294955861 = r0;
    Term v_4294955860 = r1;
    Term v_3571 = r2;
    WL_OPEN
if (seq) {
WL_ROOM(3);
STK(0) = v_4294955861;
STK(1) = v_4294955860;
STK(2) = FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_;
WL_PUSHN(3);
} else {
u64 task_11524 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_, WL_CONT, WL_IDX, 1);
e.mem[task_11524 + 0] = v_4294955861;
e.mem[task_11524 + 1] = v_4294955860;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_, task_11524);
WL_IDX = 2;
}
Term v_4294955773 = v_3571;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955772 = term_ctr(CID_SCON, STAT_OFF + 378);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955773;
r1 = v_4294955772;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_97_115_115_101_116_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_)
  {
    WL_POPN(2);
    Term v_4294955861 = STK(0);
    Term v_4294955860 = STK(1);
    Term v_4294955842 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955842;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_53_55_;
WL_PUSHN(2);
} else {
u64 task_11522 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_53_55_, WL_CONT, WL_IDX, 1);
e.mem[task_11522 + 0] = v_4294955842;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_55_, task_11522);
WL_IDX = 1;
}
u64 cl_11521 = heap_alloc(e, cls_fit(2));
e.mem[cl_11521 + 0] = v_4294955861;
e.mem[cl_11521 + 1] = v_4294955860;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_48_, cl_11521);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_55_)
  {
    WL_POPN(1);
    Term v_4294955842 = STK(0);
    Term v_4294955841 = r0;
    WL_OPEN
u64 cl_11459 = heap_alloc(e, cls_fit(2));
e.mem[cl_11459 + 0] = v_4294955842;
e.mem[cl_11459 + 1] = v_4294955841;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_56_, cl_11459);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_56_)
  {
    Term v_4294955842 = r0;
    Term v_4294955841 = r1;
    Term v_4294955840 = r2;
    WL_OPEN
r0 = v_4294955842;
r1 = v_4294955841;
r2 = v_4294955840;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_48_)
  {
    Term v_4294955861 = r0;
    Term v_4294955860 = r1;
    Term v_3572 = r2;
    WL_OPEN
term_sink(e, v_3572);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955860;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_54_52_;
WL_PUSHN(2);
} else {
u64 task_11521 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_54_52_, WL_CONT, WL_IDX, 1);
e.mem[task_11521 + 0] = v_4294955860;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_52_, task_11521);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955861;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_53_50_48_;
WL_PUSHN(2);
} else {
u64 task_11521 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_53_50_48_, WL_CONT, WL_IDX, 1);
e.mem[task_11521 + 0] = v_4294955861;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_53_50_48_, task_11521);
WL_IDX = 1;
}
WL_JMP(FID_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_52_)
  {
    WL_POPN(1);
    Term v_4294955860 = STK(0);
    Term v_4294955834 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955834;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_54_53_;
WL_PUSHN(2);
} else {
u64 task_11518 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_54_53_, WL_CONT, WL_IDX, 1);
e.mem[task_11518 + 0] = v_4294955834;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_53_, task_11518);
WL_IDX = 1;
}
u64 cl_11517 = heap_alloc(e, cls_fit(1));
e.mem[cl_11517 + 0] = v_4294955860;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_56_, cl_11517);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_53_)
  {
    WL_POPN(1);
    Term v_4294955834 = STK(0);
    Term v_4294955833 = r0;
    WL_OPEN
u64 cl_11467 = heap_alloc(e, cls_fit(2));
e.mem[cl_11467 + 0] = v_4294955834;
e.mem[cl_11467 + 1] = v_4294955833;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_54_, cl_11467);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_54_)
  {
    Term v_4294955834 = r0;
    Term v_4294955833 = r1;
    Term v_4294955832 = r2;
    WL_OPEN
r0 = v_4294955834;
r1 = v_4294955833;
r2 = v_4294955832;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_54_56_)
  {
    Term v_4294955860 = r0;
    Term v_3573 = r1;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955860;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_55_50_;
WL_PUSHN(2);
} else {
u64 task_11517 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_55_50_, WL_CONT, WL_IDX, 1);
e.mem[task_11517 + 0] = v_4294955860;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_50_, task_11517);
WL_IDX = 1;
}
Term v_4294955779 = v_3573;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955779;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_115_115_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_50_)
  {
    WL_POPN(1);
    Term v_4294955860 = STK(0);
    Term v_4294955826 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955826;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_55_51_;
WL_PUSHN(2);
} else {
u64 task_11516 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_55_51_, WL_CONT, WL_IDX, 1);
e.mem[task_11516 + 0] = v_4294955826;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_51_, task_11516);
WL_IDX = 1;
}
u64 cl_11515 = heap_alloc(e, cls_fit(1));
e.mem[cl_11515 + 0] = v_4294955860;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_54_, cl_11515);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_51_)
  {
    WL_POPN(1);
    Term v_4294955826 = STK(0);
    Term v_4294955825 = r0;
    WL_OPEN
u64 cl_11475 = heap_alloc(e, cls_fit(2));
e.mem[cl_11475 + 0] = v_4294955826;
e.mem[cl_11475 + 1] = v_4294955825;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_52_, cl_11475);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_52_)
  {
    Term v_4294955826 = r0;
    Term v_4294955825 = r1;
    Term v_4294955824 = r2;
    WL_OPEN
r0 = v_4294955826;
r1 = v_4294955825;
r2 = v_4294955824;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_55_54_)
  {
    Term v_4294955860 = r0;
    Term v_3574 = r1;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955860;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_56_48_;
WL_PUSHN(2);
} else {
u64 task_11515 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_56_48_, WL_CONT, WL_IDX, 1);
e.mem[task_11515 + 0] = v_4294955860;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_48_, task_11515);
WL_IDX = 1;
}
Term v_4294955782 = v_3574;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955781 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955782;
r1 = v_4294955781;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_48_)
  {
    WL_POPN(1);
    Term v_4294955860 = STK(0);
    Term v_4294955818 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955818;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_56_49_;
WL_PUSHN(2);
} else {
u64 task_11513 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_56_49_, WL_CONT, WL_IDX, 1);
e.mem[task_11513 + 0] = v_4294955818;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_49_, task_11513);
WL_IDX = 1;
}
u64 cl_11512 = heap_alloc(e, cls_fit(1));
e.mem[cl_11512 + 0] = v_4294955860;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_52_, cl_11512);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_49_)
  {
    WL_POPN(1);
    Term v_4294955818 = STK(0);
    Term v_4294955817 = r0;
    WL_OPEN
u64 cl_11483 = heap_alloc(e, cls_fit(2));
e.mem[cl_11483 + 0] = v_4294955818;
e.mem[cl_11483 + 1] = v_4294955817;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_50_, cl_11483);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_50_)
  {
    Term v_4294955818 = r0;
    Term v_4294955817 = r1;
    Term v_4294955816 = r2;
    WL_OPEN
r0 = v_4294955818;
r1 = v_4294955817;
r2 = v_4294955816;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_52_)
  {
    Term v_4294955860 = r0;
    Term v_3575 = r1;
    WL_OPEN
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_49_52_56_56_;
WL_PUSHN(1);
} else {
u64 task_11512 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_56_56_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_56_, task_11512);
WL_IDX = 0;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_3575;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_53_48_56_;
WL_PUSHN(2);
} else {
u64 task_11512 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_53_48_56_, WL_CONT, WL_IDX, 1);
e.mem[task_11512 + 0] = v_3575;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_56_, task_11512);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955860;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_53_49_49_;
WL_PUSHN(2);
} else {
u64 task_11512 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_53_49_49_, WL_CONT, WL_IDX, 1);
e.mem[task_11512 + 0] = v_4294955860;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_53_49_49_, task_11512);
WL_IDX = 1;
}
WL_JMP(FID_78_97_116_105_118_101_72_111_115_116_46_112_117_98_108_105_115_104_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_56_)
  {
    Term v_4294955810 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955810;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_56_57_;
WL_PUSHN(2);
} else {
u64 task_11506 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_56_57_, WL_CONT, WL_IDX, 1);
e.mem[task_11506 + 0] = v_4294955810;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_57_, task_11506);
WL_IDX = 1;
}
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_50_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_56_57_)
  {
    WL_POPN(1);
    Term v_4294955810 = STK(0);
    Term v_4294955809 = r0;
    WL_OPEN
u64 cl_11491 = heap_alloc(e, cls_fit(2));
e.mem[cl_11491 + 0] = v_4294955810;
e.mem[cl_11491 + 1] = v_4294955809;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_48_, cl_11491);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_48_)
  {
    Term v_4294955810 = r0;
    Term v_4294955809 = r1;
    Term v_4294955808 = r2;
    WL_OPEN
r0 = v_4294955810;
r1 = v_4294955809;
r2 = v_4294955808;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_50_)
  {
    Term v_3576 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_49_52_57_54_;
WL_PUSHN(1);
} else {
u64 task_11506 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_57_54_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_54_, task_11506);
WL_IDX = 0;
}
Term v_4294955790 = v_3576;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955790;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_115_115_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_54_)
  {
    Term v_4294955802 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955802;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_57_55_;
WL_PUSHN(2);
} else {
u64 task_11505 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_57_55_, WL_CONT, WL_IDX, 1);
e.mem[task_11505 + 0] = v_4294955802;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_55_, task_11505);
WL_IDX = 1;
}
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_48_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_55_)
  {
    WL_POPN(1);
    Term v_4294955802 = STK(0);
    Term v_4294955801 = r0;
    WL_OPEN
u64 cl_11499 = heap_alloc(e, cls_fit(2));
e.mem[cl_11499 + 0] = v_4294955802;
e.mem[cl_11499 + 1] = v_4294955801;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_56_, cl_11499);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_57_56_)
  {
    Term v_4294955802 = r0;
    Term v_4294955801 = r1;
    Term v_4294955800 = r2;
    WL_OPEN
r0 = v_4294955802;
r1 = v_4294955801;
r2 = v_4294955800;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_48_)
  {
    Term v_3577 = r0;
    WL_OPEN
term_sink(e, v_3577);
Term v_4294955794 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_11504 = heap_alloc(e, cls_fit(1));
e.mem[cl_11504 + 0] = v_4294955794;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_51_, cl_11504);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_51_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294955794 = r0;
    Term v_4294955793 = r1;
    WL_OPEN
r0 = v_4294955794;
r1 = v_4294955793;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_53_48_56_)
  {
    WL_POPN(1);
    Term v_3575 = STK(0);
    Term v_4294955789 = r0;
    WL_OPEN
Term v_4294955788 = v_3575;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294955789; Term arg = v_4294955788;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_53_49_49_)
  {
    WL_POPN(1);
    Term v_4294955860 = STK(0);
    Term v_4294955786 = r0;
    WL_OPEN
Term v_4294955785 = v_4294955860;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294955786; Term arg = v_4294955785;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_53_50_48_)
  {
    WL_POPN(1);
    Term v_4294955861 = STK(0);
    Term v_4294955777 = r0;
    WL_OPEN
Term v_4294955776 = v_4294955861;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294955777; Term arg = v_4294955776;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_53_50_57_)
  {
    Term v_4294955768 = r0;
    WL_OPEN
Term v_4294955767 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294955768; Term arg = v_4294955767;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_50_53_53_52_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_50_53_53_52_)
  {
    Term v_4294955765 = r0;
    WL_OPEN
u64 cl_12557 = heap_alloc(e, cls_fit(1));
e.mem[cl_12557 + 0] = v_4294955765;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_50_53_53_53_, cl_12557);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_50_53_53_53_)
  {
    Term v_4294955765 = r0;
    Term v_4294955763 = r1;
    WL_OPEN
u64 nd_12556 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_NATIVEHOST_PATH
e.mem[nd_12556 + 0] = v_4294955765;
e.mem[nd_12556 + 1] = v_4294955763;
#else
e.mem[nd_12556 + 0] = rfc_seal(e, v_4294955765);
e.mem[nd_12556 + 1] = rfc_seal(e, v_4294955763);
#endif
r0 = term_ctr(CID_NATIVEHOST_PATH, nd_12556);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_112_97_116_104_)
  {
    Term v_4294954737 = r0;
    Term v_4294954736 = r1;
    WL_OPEN
u64 nd_12560 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_NATIVEHOST_PATH
e.mem[nd_12560 + 0] = v_4294954737;
e.mem[nd_12560 + 1] = v_4294954736;
#else
e.mem[nd_12560 + 0] = rfc_seal(e, v_4294954737);
e.mem[nd_12560 + 1] = rfc_seal(e, v_4294954736);
#endif
r0 = term_ctr(CID_NATIVEHOST_PATH, nd_12560);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_112_97_115_115_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_51_53_56_54_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_56_54_)
  {
    Term v_4294953710 = r0;
    WL_OPEN
r0 = v_4294953710;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_115_115_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_115_115_)
  {
    Term v_4294953708 = r0;
    WL_OPEN
if ((term_aux(v_4294953708) == CID_DONE)) {
Term fields[1];
if (term_tag(v_4294953708) == TAG_PAK) { fields[0] = term_loc(v_4294953708); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294953708, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID_DONE_0
u32
#else
Term
#endif
v_4294953707 = fields[0];
Term v_4294953706 = v_4294953707;
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_13592 = heap_alloc(e, cls_fit(1));
e.mem[cl_13592 + 0] = v_4294953706;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_51_53_57_49_, cl_13592);
WL_RETN(1);
} else {
if ((term_aux(v_4294953708) == CID_FAIL)) {
Term fields[1];
if (term_tag(v_4294953708) == TAG_PAK) { fields[0] = term_loc(v_4294953708); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294953708, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID_FAIL_0
u32
#else
Term
#endif
v_4294953702 = fields[0];
if ((term_aux(v_4294953702) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294953702, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294953701 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294953700 = fields[1];
term_sink(e, v_4294953701);
Term v_4294953699 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953698 = v_4294953700;
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_13600 = heap_alloc(e, cls_fit(2));
e.mem[cl_13600 + 0] = v_4294953699;
e.mem[cl_13600 + 1] = v_4294953698;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_51_53_57_57_, cl_13600);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953702;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_54_48_51_;
WL_PUSHN(2);
} else {
u64 task_13604 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_54_48_51_, WL_CONT, WL_IDX, 1);
e.mem[task_13604 + 0] = v_4294953702;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_54_48_51_, task_13604);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953708;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_54_48_54_;
WL_PUSHN(2);
} else {
u64 task_13607 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_54_48_54_, WL_CONT, WL_IDX, 1);
e.mem[task_13607 + 0] = v_4294953708;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_54_48_54_, task_13607);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_57_49_)
  {
    Term v_4294953706 = r0;
    Term v_4294953705 = r1;
    WL_OPEN
r0 = v_4294953706;
r1 = v_4294953705;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_57_57_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294953699 = r0;
    Term v_4294953698 = r1;
    Term v_4294953697 = r2;
    WL_OPEN
r0 = v_4294953699;
r1 = v_4294953698;
r2 = v_4294953697;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_54_48_51_)
  {
    WL_POPN(1);
    Term v_4294953702 = STK(0);
    Term v_4294953694 = r0;
    WL_OPEN
Term v_4294953693 = v_4294953702;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953694; Term arg = v_4294953693;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_54_48_54_)
  {
    WL_POPN(1);
    Term v_4294953708 = STK(0);
    Term v_4294953691 = r0;
    WL_OPEN
Term v_4294953690 = v_4294953708;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953691; Term arg = v_4294953690;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_97_115_115_101_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_52_54_51_51_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_54_51_51_)
  {
    Term v_4294952664 = r0;
    WL_OPEN
u64 cl_14635 = heap_alloc(e, cls_fit(1));
e.mem[cl_14635 + 0] = v_4294952664;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_52_54_51_52_, cl_14635);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_54_51_52_)
  {
    Term v_4294952664 = r0;
    Term v_4294952663 = r1;
    WL_OPEN
r0 = v_4294952664;
r1 = v_4294952663;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_97_115_115_101_116_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_97_115_115_101_116_)
  {
    Term v_4294952659 = r0;
    Term v_4294952658 = r1;
    WL_OPEN
v_4294952658 = term_keep(e, v_4294952658);
Term v_4294952657 = v_4294952658;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_3561;
{
Term nf_local_14639[1];
if (!NF_FID_99_108_105_95_100_105_103_101_115_116_(e, seq, nf_local_14639, v_4294952657)) { return 0; }
v_3561 = nf_local_14639[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_3561 = term_keep(e, v_3561);
Term v_4294952591 = v_3561;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952655;
{
Term nf_local_14705[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_local_14705, v_4294952591)) { return 0; }
v_4294952655 = nf_local_14705[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294952655)) {
term_sink(e, v_4294952659);
term_sink(e, v_3561);
Term v_3562;
{
v_3562 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3562);
Term v_4294952589 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952586 = term_ctr(CID_SCON, STAT_OFF + 2842);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952585 = v_4294952658;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952588;
{
Term nf_local_14711[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_14711, v_4294952586, v_4294952585)) { return 0; }
v_4294952588 = nf_local_14711[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_14713 = heap_alloc(e, cls_fit(2));
e.mem[cl_14713 + 0] = v_4294952589;
e.mem[cl_14713 + 1] = v_4294952588;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_52_55_49_50_, cl_14713);
WL_RETN(1);
} else {
if ((!native_bool(v_4294952655))) {
Term v_3563;
{
v_3563 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3563);
Term v_4294952577 = v_4294952659;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952576 = term_ctr(CID_SCON, STAT_OFF + 2858);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952579;
{
Term nf_local_14720[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_14720, v_4294952577, v_4294952576)) { return 0; }
v_4294952579 = nf_local_14720[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952578 = v_4294952658;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952581;
{
Term nf_local_14721[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_14721, v_4294952579, v_4294952578)) { return 0; }
v_4294952581 = nf_local_14721[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952580 = v_3561;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294952581;
r1 = v_4294952580;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_);
} else {
term_sink(e, v_4294952659);
term_sink(e, v_4294952658);
term_sink(e, v_3561);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294952655;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_52_55_50_52_;
WL_PUSHN(2);
} else {
u64 task_14725 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_52_55_50_52_, WL_CONT, WL_IDX, 1);
e.mem[task_14725 + 0] = v_4294952655;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_52_55_50_52_, task_14725);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_55_49_50_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294952589 = r0;
    Term v_4294952588 = r1;
    Term v_4294952587 = r2;
    WL_OPEN
r0 = v_4294952589;
r1 = v_4294952588;
r2 = v_4294952587;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_55_50_52_)
  {
    WL_POPN(1);
    Term v_4294952655 = STK(0);
    Term v_4294952573 = r0;
    WL_OPEN
Term v_4294952572 = v_4294952655;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294952573; Term arg = v_4294952572;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_100_105_103_101_115_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_53_55_53_48_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_53_55_53_48_)
  {
    Term v_4294951546 = r0;
    WL_OPEN
r0 = v_4294951546;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_103_101_115_116_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_100_105_103_101_115_116_)
  {
    Term v_4294951544 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_99_108_105_95_100_105_103_101_115_116_(e, seq, nq_result, v_4294951544)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951479 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951478 = term_ctr(CID_SCON, STAT_OFF + 378);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951543;
{
Term nf_local_15818[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_15818, v_4294951479, v_4294951478)) { return 0; }
v_4294951543 = nf_local_15818[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951543)) {
term_sink(e, v_4294951544);
Term v_3591;
{
v_3591 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3591);
r0 = term_ctr(CID_SCON, STAT_OFF + 506);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951543))) {
Term v_3592;
{
v_3592 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3592);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951412 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951411 = term_ctr(CID_SCON, STAT_OFF + 522);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951476;
{
Term nf_local_15885[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_15885, v_4294951412, v_4294951411)) { return 0; }
v_4294951476 = nf_local_15885[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951476)) {
term_sink(e, v_4294951544);
Term v_3593;
{
v_3593 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3593);
r0 = term_ctr(CID_SCON, STAT_OFF + 650);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951476))) {
Term v_3594;
{
v_3594 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3594);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951345 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951344 = term_ctr(CID_SCON, STAT_OFF + 680);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951409;
{
Term nf_local_15952[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_15952, v_4294951345, v_4294951344)) { return 0; }
v_4294951409 = nf_local_15952[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951409)) {
term_sink(e, v_4294951544);
Term v_3595;
{
v_3595 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3595);
r0 = term_ctr(CID_SCON, STAT_OFF + 806);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951409))) {
Term v_3596;
{
v_3596 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3596);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951278 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951277 = term_ctr(CID_SCON, STAT_OFF + 836);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951342;
{
Term nf_local_16019[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16019, v_4294951278, v_4294951277)) { return 0; }
v_4294951342 = nf_local_16019[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951342)) {
term_sink(e, v_4294951544);
Term v_3597;
{
v_3597 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3597);
r0 = term_ctr(CID_SCON, STAT_OFF + 964);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951342))) {
Term v_3598;
{
v_3598 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3598);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951211 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951210 = term_ctr(CID_SCON, STAT_OFF + 994);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951275;
{
Term nf_local_16086[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16086, v_4294951211, v_4294951210)) { return 0; }
v_4294951275 = nf_local_16086[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951275)) {
term_sink(e, v_4294951544);
Term v_3599;
{
v_3599 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3599);
r0 = term_ctr(CID_SCON, STAT_OFF + 1120);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951275))) {
Term v_3600;
{
v_3600 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3600);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951144 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951143 = term_ctr(CID_SCON, STAT_OFF + 1150);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951208;
{
Term nf_local_16153[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16153, v_4294951144, v_4294951143)) { return 0; }
v_4294951208 = nf_local_16153[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951208)) {
term_sink(e, v_4294951544);
Term v_3601;
{
v_3601 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3601);
r0 = term_ctr(CID_SCON, STAT_OFF + 1278);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951208))) {
Term v_3602;
{
v_3602 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3602);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951077 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951076 = term_ctr(CID_SCON, STAT_OFF + 1308);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951141;
{
Term nf_local_16220[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16220, v_4294951077, v_4294951076)) { return 0; }
v_4294951141 = nf_local_16220[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951141)) {
term_sink(e, v_4294951544);
Term v_3603;
{
v_3603 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3603);
r0 = term_ctr(CID_SCON, STAT_OFF + 1436);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951141))) {
Term v_3604;
{
v_3604 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3604);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294951010 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951009 = term_ctr(CID_SCON, STAT_OFF + 1458);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951074;
{
Term nf_local_16287[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16287, v_4294951010, v_4294951009)) { return 0; }
v_4294951074 = nf_local_16287[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951074)) {
term_sink(e, v_4294951544);
Term v_3605;
{
v_3605 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3605);
r0 = term_ctr(CID_SCON, STAT_OFF + 1584);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951074))) {
Term v_3606;
{
v_3606 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3606);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294950943 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950942 = term_ctr(CID_SCON, STAT_OFF + 1604);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951007;
{
Term nf_local_16354[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16354, v_4294950943, v_4294950942)) { return 0; }
v_4294951007 = nf_local_16354[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294951007)) {
term_sink(e, v_4294951544);
Term v_3607;
{
v_3607 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3607);
r0 = term_ctr(CID_SCON, STAT_OFF + 1732);
WL_RETN(1);
} else {
if ((!native_bool(v_4294951007))) {
Term v_3608;
{
v_3608 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3608);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294950876 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950875 = term_ctr(CID_SCON, STAT_OFF + 1748);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950940;
{
Term nf_local_16421[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16421, v_4294950876, v_4294950875)) { return 0; }
v_4294950940 = nf_local_16421[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294950940)) {
term_sink(e, v_4294951544);
Term v_3609;
{
v_3609 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3609);
r0 = term_ctr(CID_SCON, STAT_OFF + 1874);
WL_RETN(1);
} else {
if ((!native_bool(v_4294950940))) {
Term v_3610;
{
v_3610 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3610);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294950809 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950808 = term_ctr(CID_SCON, STAT_OFF + 1902);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950873;
{
Term nf_local_16488[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16488, v_4294950809, v_4294950808)) { return 0; }
v_4294950873 = nf_local_16488[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294950873)) {
term_sink(e, v_4294951544);
Term v_3611;
{
v_3611 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3611);
r0 = term_ctr(CID_SCON, STAT_OFF + 2028);
WL_RETN(1);
} else {
if ((!native_bool(v_4294950873))) {
Term v_3612;
{
v_3612 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3612);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294950742 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950741 = term_ctr(CID_SCON, STAT_OFF + 2056);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950806;
{
Term nf_local_16555[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16555, v_4294950742, v_4294950741)) { return 0; }
v_4294950806 = nf_local_16555[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294950806)) {
term_sink(e, v_4294951544);
Term v_3613;
{
v_3613 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3613);
r0 = term_ctr(CID_SCON, STAT_OFF + 2182);
WL_RETN(1);
} else {
if ((!native_bool(v_4294950806))) {
Term v_3614;
{
v_3614 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3614);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294950675 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950674 = term_ctr(CID_SCON, STAT_OFF + 2210);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950739;
{
Term nf_local_16622[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16622, v_4294950675, v_4294950674)) { return 0; }
v_4294950739 = nf_local_16622[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294950739)) {
term_sink(e, v_4294951544);
Term v_3615;
{
v_3615 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3615);
r0 = term_ctr(CID_SCON, STAT_OFF + 2336);
WL_RETN(1);
} else {
if ((!native_bool(v_4294950739))) {
Term v_3616;
{
v_3616 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3616);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294950608 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950607 = term_ctr(CID_SCON, STAT_OFF + 2364);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950672;
{
Term nf_local_16689[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16689, v_4294950608, v_4294950607)) { return 0; }
v_4294950672 = nf_local_16689[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294950672)) {
term_sink(e, v_4294951544);
Term v_3617;
{
v_3617 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3617);
r0 = term_ctr(CID_SCON, STAT_OFF + 2490);
WL_RETN(1);
} else {
if ((!native_bool(v_4294950672))) {
Term v_3618;
{
v_3618 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3618);
v_4294951544 = term_keep(e, v_4294951544);
Term v_4294950541 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950540 = term_ctr(CID_SCON, STAT_OFF + 2518);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950605;
{
Term nf_local_16756[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16756, v_4294950541, v_4294950540)) { return 0; }
v_4294950605 = nf_local_16756[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294950605)) {
term_sink(e, v_4294951544);
Term v_3619;
{
v_3619 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3619);
r0 = term_ctr(CID_SCON, STAT_OFF + 2644);
WL_RETN(1);
} else {
if ((!native_bool(v_4294950605))) {
Term v_3620;
{
v_3620 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3620);
Term v_4294950474 = v_4294951544;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950473 = term_ctr(CID_SCON, STAT_OFF + 2672);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294950538;
{
Term nf_local_16823[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_16823, v_4294950474, v_4294950473)) { return 0; }
v_4294950538 = nf_local_16823[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294950538)) {
Term v_3621;
{
v_3621 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3621);
r0 = term_ctr(CID_SCON, STAT_OFF + 2798);
WL_RETN(1);
} else {
if ((!native_bool(v_4294950538))) {
Term v_3622;
{
v_3622 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3622);
r0 = term_pak(CID_SNIL, 0);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294950538;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_50_54_;
WL_PUSHN(2);
} else {
u64 task_16827 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_50_54_, WL_CONT, WL_IDX, 1);
e.mem[task_16827 + 0] = v_4294950538;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_50_54_, task_16827);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294950605;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_50_57_;
WL_PUSHN(2);
} else {
u64 task_16830 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_50_57_, WL_CONT, WL_IDX, 1);
e.mem[task_16830 + 0] = v_4294950605;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_50_57_, task_16830);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294950672;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_51_50_;
WL_PUSHN(2);
} else {
u64 task_16833 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_51_50_, WL_CONT, WL_IDX, 1);
e.mem[task_16833 + 0] = v_4294950672;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_50_, task_16833);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294950739;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_51_53_;
WL_PUSHN(2);
} else {
u64 task_16836 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_51_53_, WL_CONT, WL_IDX, 1);
e.mem[task_16836 + 0] = v_4294950739;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_53_, task_16836);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294950806;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_51_56_;
WL_PUSHN(2);
} else {
u64 task_16839 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_51_56_, WL_CONT, WL_IDX, 1);
e.mem[task_16839 + 0] = v_4294950806;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_56_, task_16839);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294950873;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_52_49_;
WL_PUSHN(2);
} else {
u64 task_16842 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_52_49_, WL_CONT, WL_IDX, 1);
e.mem[task_16842 + 0] = v_4294950873;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_49_, task_16842);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294950940;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_52_52_;
WL_PUSHN(2);
} else {
u64 task_16845 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_52_52_, WL_CONT, WL_IDX, 1);
e.mem[task_16845 + 0] = v_4294950940;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_52_, task_16845);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951007;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_52_55_;
WL_PUSHN(2);
} else {
u64 task_16848 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_52_55_, WL_CONT, WL_IDX, 1);
e.mem[task_16848 + 0] = v_4294951007;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_55_, task_16848);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951074;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_53_48_;
WL_PUSHN(2);
} else {
u64 task_16851 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_53_48_, WL_CONT, WL_IDX, 1);
e.mem[task_16851 + 0] = v_4294951074;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_48_, task_16851);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951141;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_53_51_;
WL_PUSHN(2);
} else {
u64 task_16854 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_53_51_, WL_CONT, WL_IDX, 1);
e.mem[task_16854 + 0] = v_4294951141;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_51_, task_16854);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951208;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_53_54_;
WL_PUSHN(2);
} else {
u64 task_16857 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_53_54_, WL_CONT, WL_IDX, 1);
e.mem[task_16857 + 0] = v_4294951208;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_54_, task_16857);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951275;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_53_57_;
WL_PUSHN(2);
} else {
u64 task_16860 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_53_57_, WL_CONT, WL_IDX, 1);
e.mem[task_16860 + 0] = v_4294951275;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_57_, task_16860);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951342;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_54_50_;
WL_PUSHN(2);
} else {
u64 task_16863 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_54_50_, WL_CONT, WL_IDX, 1);
e.mem[task_16863 + 0] = v_4294951342;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_50_, task_16863);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951409;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_54_53_;
WL_PUSHN(2);
} else {
u64 task_16866 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_54_53_, WL_CONT, WL_IDX, 1);
e.mem[task_16866 + 0] = v_4294951409;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_53_, task_16866);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951476;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_54_56_;
WL_PUSHN(2);
} else {
u64 task_16869 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_54_56_, WL_CONT, WL_IDX, 1);
e.mem[task_16869 + 0] = v_4294951476;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_56_, task_16869);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294951544);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294951543;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_54_56_55_49_;
WL_PUSHN(2);
} else {
u64 task_16872 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_54_56_55_49_, WL_CONT, WL_IDX, 1);
e.mem[task_16872 + 0] = v_4294951543;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_54_56_55_49_, task_16872);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_50_54_)
  {
    WL_POPN(1);
    Term v_4294950538 = STK(0);
    Term v_4294950471 = r0;
    WL_OPEN
Term v_4294950470 = v_4294950538;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950471; Term arg = v_4294950470;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_50_57_)
  {
    WL_POPN(1);
    Term v_4294950605 = STK(0);
    Term v_4294950468 = r0;
    WL_OPEN
Term v_4294950467 = v_4294950605;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950468; Term arg = v_4294950467;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_50_)
  {
    WL_POPN(1);
    Term v_4294950672 = STK(0);
    Term v_4294950465 = r0;
    WL_OPEN
Term v_4294950464 = v_4294950672;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950465; Term arg = v_4294950464;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_53_)
  {
    WL_POPN(1);
    Term v_4294950739 = STK(0);
    Term v_4294950462 = r0;
    WL_OPEN
Term v_4294950461 = v_4294950739;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950462; Term arg = v_4294950461;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_51_56_)
  {
    WL_POPN(1);
    Term v_4294950806 = STK(0);
    Term v_4294950459 = r0;
    WL_OPEN
Term v_4294950458 = v_4294950806;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950459; Term arg = v_4294950458;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_49_)
  {
    WL_POPN(1);
    Term v_4294950873 = STK(0);
    Term v_4294950456 = r0;
    WL_OPEN
Term v_4294950455 = v_4294950873;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950456; Term arg = v_4294950455;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_52_)
  {
    WL_POPN(1);
    Term v_4294950940 = STK(0);
    Term v_4294950453 = r0;
    WL_OPEN
Term v_4294950452 = v_4294950940;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950453; Term arg = v_4294950452;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_52_55_)
  {
    WL_POPN(1);
    Term v_4294951007 = STK(0);
    Term v_4294950450 = r0;
    WL_OPEN
Term v_4294950449 = v_4294951007;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950450; Term arg = v_4294950449;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_48_)
  {
    WL_POPN(1);
    Term v_4294951074 = STK(0);
    Term v_4294950447 = r0;
    WL_OPEN
Term v_4294950446 = v_4294951074;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950447; Term arg = v_4294950446;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_51_)
  {
    WL_POPN(1);
    Term v_4294951141 = STK(0);
    Term v_4294950444 = r0;
    WL_OPEN
Term v_4294950443 = v_4294951141;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950444; Term arg = v_4294950443;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_54_)
  {
    WL_POPN(1);
    Term v_4294951208 = STK(0);
    Term v_4294950441 = r0;
    WL_OPEN
Term v_4294950440 = v_4294951208;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950441; Term arg = v_4294950440;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_53_57_)
  {
    WL_POPN(1);
    Term v_4294951275 = STK(0);
    Term v_4294950438 = r0;
    WL_OPEN
Term v_4294950437 = v_4294951275;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950438; Term arg = v_4294950437;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_50_)
  {
    WL_POPN(1);
    Term v_4294951342 = STK(0);
    Term v_4294950435 = r0;
    WL_OPEN
Term v_4294950434 = v_4294951342;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950435; Term arg = v_4294950434;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_53_)
  {
    WL_POPN(1);
    Term v_4294951409 = STK(0);
    Term v_4294950432 = r0;
    WL_OPEN
Term v_4294950431 = v_4294951409;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950432; Term arg = v_4294950431;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_54_56_)
  {
    WL_POPN(1);
    Term v_4294951476 = STK(0);
    Term v_4294950429 = r0;
    WL_OPEN
Term v_4294950428 = v_4294951476;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950429; Term arg = v_4294950428;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_56_55_49_)
  {
    WL_POPN(1);
    Term v_4294951543 = STK(0);
    Term v_4294950426 = r0;
    WL_OPEN
Term v_4294950425 = v_4294951543;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294950426; Term arg = v_4294950425;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_107_99_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_55_56_57_57_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_56_57_57_)
  {
    Term v_4294949399 = r0;
    WL_OPEN
u64 cl_17903 = heap_alloc(e, cls_fit(1));
e.mem[cl_17903 + 0] = v_4294949399;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_55_57_48_48_, cl_17903);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_57_48_48_)
  {
    Term v_4294949399 = r0;
    Term v_4294949398 = r1;
    WL_OPEN
u64 cl_17902 = heap_alloc(e, cls_fit(2));
e.mem[cl_17902 + 0] = v_4294949399;
e.mem[cl_17902 + 1] = v_4294949398;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_55_57_48_49_, cl_17902);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_57_48_49_)
  {
    Term v_4294949399 = r0;
    Term v_4294949398 = r1;
    Term v_4294949397 = r2;
    WL_OPEN
r0 = v_4294949399;
r1 = v_4294949398;
r2 = v_4294949397;
WL_JMP(FID_36_100_105_114_101_99_116_46_107_99_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_107_99_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294949391 = r0;
    Term v_4294949390 = r1;
    Term v_4294949389 = r2;
    WL_OPEN
Term v_4294949388 = v_4294949391;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294949387 = v_4294949390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294949386 = v_4294949389;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294949388)) {
term_sink(e, v_4294949386);
Term v_4294949385 = v_4294949387;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294949384 = term_pak(CID_UNIT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294949385; Term arg = v_4294949384;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}
} else {
Term v_4294949383 = v_4294949388;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294949382 = v_4294949387;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294949381 = v_4294949386;
if (!seq && err_seen(e.mem)) { return 0; }
if ((!native_bool(v_4294949383))) {
term_sink(e, v_4294949382);
Term v_4294949380 = v_4294949381;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294949379 = term_pak(CID_UNIT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294949380; Term arg = v_4294949379;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294949381;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_55_57_49_57_;
WL_PUSHN(2);
} else {
u64 task_17926 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_55_57_49_57_, WL_CONT, WL_IDX, 1);
e.mem[task_17926 + 0] = v_4294949381;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_55_57_49_57_, task_17926);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294949382;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_55_57_50_50_;
WL_PUSHN(2);
} else {
u64 task_17926 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_55_57_50_50_, WL_CONT, WL_IDX, 1);
e.mem[task_17926 + 0] = v_4294949382;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_55_57_50_50_, task_17926);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294949383;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_55_57_50_53_;
WL_PUSHN(2);
} else {
u64 task_17926 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_55_57_50_53_, WL_CONT, WL_IDX, 1);
e.mem[task_17926 + 0] = v_4294949383;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_55_57_50_53_, task_17926);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_57_49_57_)
  {
    WL_POPN(1);
    Term v_4294949381 = STK(0);
    Term v_4294949378 = r0;
    WL_OPEN
Term v_4294949377 = v_4294949381;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294949378; Term arg = v_4294949377;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_57_50_50_)
  {
    WL_POPN(1);
    Term v_4294949382 = STK(0);
    Term v_4294949375 = r0;
    WL_OPEN
Term v_4294949374 = v_4294949382;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294949375; Term arg = v_4294949374;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_57_50_53_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294949383 = STK(0);
    Term v_4294949372 = r0;
    WL_OPEN
Term v_4294949371 = v_4294949383;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294949372; Term arg = v_4294949371;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_101_113_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_56_57_53_50_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_56_57_53_50_)
  {
    Term v_4294948345 = r0;
    WL_OPEN
u64 cl_18954 = heap_alloc(e, cls_fit(1));
e.mem[cl_18954 + 0] = v_4294948345;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_56_57_53_51_, cl_18954);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_56_57_53_51_)
  {
    Term v_4294948345 = r0;
    Term v_4294948344 = r1;
    WL_OPEN
r0 = v_4294948345;
r1 = v_4294948344;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_101_113_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_101_113_)
  {
    Term v_4294948340 = r0;
    Term v_4294948339 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nq_result, v_4294948340, v_4294948339)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294948337 = v_4294948340;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294948336 = v_4294948339;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294948338;
{
Term nf_local_18960[1];
if (!NF_FID_83_116_114_105_110_103_46_111_114_100_101_114_(e, seq, nf_local_18960, v_4294948337, v_4294948336)) { return 0; }
v_4294948338 = nf_local_18960[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294948338;
WL_JMP(FID_36_100_105_114_101_99_116_46_67_109_112_46_105_115_95_101_113_);
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_67_109_112_46_105_115_95_101_113_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_54_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_54_)
  {
    Term v_4294947310 = r0;
    WL_OPEN
r0 = v_4294947310;
WL_JMP(FID_36_100_105_114_101_99_116_46_67_109_112_46_105_115_95_101_113_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_67_109_112_46_105_115_95_101_113_)
  {
    Term v_4294947308 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_67_109_112_46_105_115_95_101_113_(e, seq, nq_result, v_4294947308)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
if ((term_aux(v_4294947308) == CID_EQ)) {
r0 = 1ull;
WL_RETN(1);
} else {
term_sink(e, v_4294947308);
r0 = 0ull;
WL_RETN(1);
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_111_114_100_101_114_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_49_48_49_52_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_49_48_49_52_)
  {
    Term v_4294946283 = r0;
    WL_OPEN
u64 cl_21016 = heap_alloc(e, cls_fit(1));
e.mem[cl_21016 + 0] = v_4294946283;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_49_48_49_53_, cl_21016);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_49_48_49_53_)
  {
    Term v_4294946283 = r0;
    Term v_4294946282 = r1;
    WL_OPEN
r0 = v_4294946283;
r1 = v_4294946282;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_111_114_100_101_114_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_111_114_100_101_114_)
  {
    Term v_4294946278 = r0;
    Term v_4294946277 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_83_116_114_105_110_103_46_111_114_100_101_114_(e, seq, nq_result, v_4294946278, v_4294946277)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294946275 = v_4294946278;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294946274 = v_4294946277;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294946276;
{
Term nf_local_21022[1];
if (!NF_FID_83_116_114_105_110_103_46_99_109_112_(e, seq, nf_local_21022, v_4294946275, v_4294946274)) { return 0; }
v_4294946276 = nf_local_21022[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294946276;
WL_JMP(FID_36_100_105_114_101_99_116_46_80_97_105_114_46_115_110_100_);
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_80_97_105_114_46_115_110_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_50_48_52_56_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_50_48_52_56_)
  {
    Term v_4294945248 = r0;
    WL_OPEN
r0 = v_4294945248;
WL_JMP(FID_36_100_105_114_101_99_116_46_80_97_105_114_46_115_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_80_97_105_114_46_115_110_100_)
  {
    Term v_4294945246 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_80_97_105_114_46_115_110_100_(e, seq, nq_result, v_4294945246)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
if ((term_aux(v_4294945246) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294945246, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294945245 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294945244 = fields[1];
term_sink(e, v_4294945245);
r0 = v_4294945244;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294945246;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_;
WL_PUSHN(2);
} else {
u64 task_22055 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_, WL_CONT, WL_IDX, 1);
e.mem[task_22055 + 0] = v_4294945246;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_, task_22055);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_)
  {
    WL_POPN(1);
    Term v_4294945246 = STK(0);
    Term v_4294945243 = r0;
    WL_OPEN
Term v_4294945242 = v_4294945246;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294945243; Term arg = v_4294945242;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_99_109_112_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_49_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_49_)
  {
    Term v_4294944216 = r0;
    WL_OPEN
u64 cl_23083 = heap_alloc(e, cls_fit(1));
e.mem[cl_23083 + 0] = v_4294944216;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_50_, cl_23083);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_50_)
  {
    Term v_4294944216 = r0;
    Term v_4294944215 = r1;
    WL_OPEN
r0 = v_4294944216;
r1 = v_4294944215;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_)
  {
    Term v_4294944211 = r0;
    Term v_4294944210 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_83_116_114_105_110_103_46_99_109_112_(e, seq, nq_result, v_4294944211, v_4294944210)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294944209 = v_4294944211;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944208 = v_4294944210;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294944209) == CID_SNIL)) {
if ((term_aux(v_4294944208) == CID_SNIL)) {
r0 = term_ctr(CID_TUPLE, STAT_OFF + 362);
WL_RETN(1);
} else {
if ((term_aux(v_4294944208) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294944208, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294944207 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294944206 = fields[1];
Term v_4294944203 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944201 = v_4294944207;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944200 = v_4294944206;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944202;
{
u64 nd_23096 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_23096 + 0] = v_4294944201;
e.mem[nd_23096 + 1] = v_4294944200;
#else
e.mem[nd_23096 + 0] = rfc_seal(e, v_4294944201);
e.mem[nd_23096 + 1] = rfc_seal(e, v_4294944200);
#endif
v_4294944202 = term_ctr(CID_SCON, nd_23096);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944205;
{
u64 nd_23097 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_23097 + 0] = v_4294944203;
e.mem[nd_23097 + 1] = v_4294944202;
#else
e.mem[nd_23097 + 0] = rfc_seal(e, v_4294944203);
e.mem[nd_23097 + 1] = rfc_seal(e, v_4294944202);
#endif
v_4294944205 = term_ctr(CID_TUPLE, nd_23097);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944204 = term_pak(CID_LT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_23098 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_23098 + 0] = v_4294944205;
e.mem[nd_23098 + 1] = v_4294944204;
#else
e.mem[nd_23098 + 0] = rfc_seal(e, v_4294944205);
e.mem[nd_23098 + 1] = rfc_seal(e, v_4294944204);
#endif
r0 = term_ctr(CID_TUPLE, nd_23098);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294944208;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_51_49_48_49_;
WL_PUSHN(2);
} else {
u64 task_23102 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_51_49_48_49_, WL_CONT, WL_IDX, 1);
e.mem[task_23102 + 0] = v_4294944208;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_51_49_48_49_, task_23102);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
Term v_4294944193 = v_4294944209;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944192 = v_4294944208;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294944193) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294944193, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294944191 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294944190 = fields[1];
if ((term_aux(v_4294944192) == CID_SNIL)) {
Term v_4294944185 = v_4294944191;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944184 = v_4294944190;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944187;
{
u64 nd_23112 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_23112 + 0] = v_4294944185;
e.mem[nd_23112 + 1] = v_4294944184;
#else
e.mem[nd_23112 + 0] = rfc_seal(e, v_4294944185);
e.mem[nd_23112 + 1] = rfc_seal(e, v_4294944184);
#endif
v_4294944187 = term_ctr(CID_SCON, nd_23112);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944186 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944189;
{
u64 nd_23113 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_23113 + 0] = v_4294944187;
e.mem[nd_23113 + 1] = v_4294944186;
#else
e.mem[nd_23113 + 0] = rfc_seal(e, v_4294944187);
e.mem[nd_23113 + 1] = rfc_seal(e, v_4294944186);
#endif
v_4294944189 = term_ctr(CID_TUPLE, nd_23113);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944188 = term_pak(CID_GT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_23114 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_23114 + 0] = v_4294944189;
e.mem[nd_23114 + 1] = v_4294944188;
#else
e.mem[nd_23114 + 0] = rfc_seal(e, v_4294944189);
e.mem[nd_23114 + 1] = rfc_seal(e, v_4294944188);
#endif
r0 = term_ctr(CID_TUPLE, nd_23114);
WL_RETN(1);
} else {
if ((term_aux(v_4294944192) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294944192, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294944180 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294944179 = fields[1];
Term v_4294944178 = v_4294944190;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944177 = v_4294944179;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944175 = v_4294944191;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944174 = v_4294944180;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944176;
{
Term nf_local_23122[1];
if (!NF_FID_67_104_97_114_46_99_109_112_(e, seq, nf_local_23122, v_4294944175, v_4294944174)) { return 0; }
v_4294944176 = nf_local_23122[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294944178;
r1 = v_4294944177;
r2 = v_4294944176;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_102_105_110_);
} else {
term_sink(e, v_4294944191);
term_sink(e, v_4294944190);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294944192;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_51_49_50_53_;
WL_PUSHN(2);
} else {
u64 task_23126 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_51_49_50_53_, WL_CONT, WL_IDX, 1);
e.mem[task_23126 + 0] = v_4294944192;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_51_49_50_53_, task_23126);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294944192;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_51_49_50_56_;
WL_PUSHN(2);
} else {
u64 task_23132 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_51_49_50_56_, WL_CONT, WL_IDX, 1);
e.mem[task_23132 + 0] = v_4294944192;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_51_49_50_56_, task_23132);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294944193;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_51_49_51_49_;
WL_PUSHN(2);
} else {
u64 task_23132 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_51_49_51_49_, WL_CONT, WL_IDX, 1);
e.mem[task_23132 + 0] = v_4294944193;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_51_49_51_49_, task_23132);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_49_48_49_)
  {
    WL_POPN(1);
    Term v_4294944208 = STK(0);
    Term v_4294944196 = r0;
    WL_OPEN
Term v_4294944195 = v_4294944208;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294944196; Term arg = v_4294944195;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_49_50_53_)
  {
    WL_POPN(1);
    Term v_4294944192 = STK(0);
    Term v_4294944172 = r0;
    WL_OPEN
Term v_4294944171 = v_4294944192;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294944172; Term arg = v_4294944171;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_49_50_56_)
  {
    WL_POPN(1);
    Term v_4294944192 = STK(0);
    Term v_4294944169 = r0;
    WL_OPEN
Term v_4294944168 = v_4294944192;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294944169; Term arg = v_4294944168;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_49_51_49_)
  {
    WL_POPN(1);
    Term v_4294944193 = STK(0);
    Term v_4294944166 = r0;
    WL_OPEN
Term v_4294944165 = v_4294944193;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294944166; Term arg = v_4294944165;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_99_109_112_46_102_105_110_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_52_49_53_57_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_49_53_57_)
  {
    Term v_4294943139 = r0;
    WL_OPEN
u64 cl_24163 = heap_alloc(e, cls_fit(1));
e.mem[cl_24163 + 0] = v_4294943139;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_52_49_54_48_, cl_24163);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_49_54_48_)
  {
    Term v_4294943139 = r0;
    Term v_4294943138 = r1;
    WL_OPEN
u64 cl_24162 = heap_alloc(e, cls_fit(2));
e.mem[cl_24162 + 0] = v_4294943139;
e.mem[cl_24162 + 1] = v_4294943138;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_52_49_54_49_, cl_24162);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_49_54_49_)
  {
    Term v_4294943139 = r0;
    Term v_4294943138 = r1;
    Term v_4294943137 = r2;
    WL_OPEN
r0 = v_4294943139;
r1 = v_4294943138;
r2 = v_4294943137;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_102_105_110_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_102_105_110_)
  {
    Term v_4294943131 = r0;
    Term v_4294943130 = r1;
    Term v_4294943129 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_83_116_114_105_110_103_46_99_109_112_46_102_105_110_(e, seq, nq_result, v_4294943131, v_4294943130, v_4294943129)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
if ((term_aux(v_4294943129) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294943129, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294943128 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294943127 = fields[1];
Term v_4294943126 = v_4294943128;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943125 = v_4294943127;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294943126) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294943126, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294943124 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294943123 = fields[1];
if ((term_aux(v_4294943125) == CID_LT)) {
Term v_4294943118 = v_4294943124;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943117 = v_4294943131;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943120;
{
u64 nd_24179 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_24179 + 0] = v_4294943118;
e.mem[nd_24179 + 1] = v_4294943117;
#else
e.mem[nd_24179 + 0] = rfc_seal(e, v_4294943118);
e.mem[nd_24179 + 1] = rfc_seal(e, v_4294943117);
#endif
v_4294943120 = term_ctr(CID_SCON, nd_24179);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943115 = v_4294943123;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943114 = v_4294943130;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943119;
{
u64 nd_24182 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_24182 + 0] = v_4294943115;
e.mem[nd_24182 + 1] = v_4294943114;
#else
e.mem[nd_24182 + 0] = rfc_seal(e, v_4294943115);
e.mem[nd_24182 + 1] = rfc_seal(e, v_4294943114);
#endif
v_4294943119 = term_ctr(CID_SCON, nd_24182);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943122;
{
u64 nd_24183 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_24183 + 0] = v_4294943120;
e.mem[nd_24183 + 1] = v_4294943119;
#else
e.mem[nd_24183 + 0] = rfc_seal(e, v_4294943120);
e.mem[nd_24183 + 1] = rfc_seal(e, v_4294943119);
#endif
v_4294943122 = term_ctr(CID_TUPLE, nd_24183);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943121 = term_pak(CID_LT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_24184 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_24184 + 0] = v_4294943122;
e.mem[nd_24184 + 1] = v_4294943121;
#else
e.mem[nd_24184 + 0] = rfc_seal(e, v_4294943122);
e.mem[nd_24184 + 1] = rfc_seal(e, v_4294943121);
#endif
r0 = term_ctr(CID_TUPLE, nd_24184);
WL_RETN(1);
} else {
if ((term_aux(v_4294943125) == CID_EQ)) {
Term v_4294943110 = v_4294943124;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943109 = v_4294943123;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943107 = v_4294943131;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943106 = v_4294943130;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943108;
{
Term nf_local_24190[1];
if (!NF_FID_83_116_114_105_110_103_46_99_109_112_(e, seq, nf_local_24190, v_4294943107, v_4294943106)) { return 0; }
v_4294943108 = nf_local_24190[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294943110;
r1 = v_4294943109;
r2 = v_4294943108;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_114_101_99_);
} else {
if ((term_aux(v_4294943125) == CID_GT)) {
Term v_4294943100 = v_4294943124;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943099 = v_4294943131;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943102;
{
u64 nd_24197 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_24197 + 0] = v_4294943100;
e.mem[nd_24197 + 1] = v_4294943099;
#else
e.mem[nd_24197 + 0] = rfc_seal(e, v_4294943100);
e.mem[nd_24197 + 1] = rfc_seal(e, v_4294943099);
#endif
v_4294943102 = term_ctr(CID_SCON, nd_24197);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943097 = v_4294943123;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943096 = v_4294943130;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943101;
{
u64 nd_24200 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_24200 + 0] = v_4294943097;
e.mem[nd_24200 + 1] = v_4294943096;
#else
e.mem[nd_24200 + 0] = rfc_seal(e, v_4294943097);
e.mem[nd_24200 + 1] = rfc_seal(e, v_4294943096);
#endif
v_4294943101 = term_ctr(CID_SCON, nd_24200);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943104;
{
u64 nd_24201 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_24201 + 0] = v_4294943102;
e.mem[nd_24201 + 1] = v_4294943101;
#else
e.mem[nd_24201 + 0] = rfc_seal(e, v_4294943102);
e.mem[nd_24201 + 1] = rfc_seal(e, v_4294943101);
#endif
v_4294943104 = term_ctr(CID_TUPLE, nd_24201);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943103 = term_pak(CID_GT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_24202 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_24202 + 0] = v_4294943104;
e.mem[nd_24202 + 1] = v_4294943103;
#else
e.mem[nd_24202 + 0] = rfc_seal(e, v_4294943104);
e.mem[nd_24202 + 1] = rfc_seal(e, v_4294943103);
#endif
r0 = term_ctr(CID_TUPLE, nd_24202);
WL_RETN(1);
} else {
term_sink(e, v_4294943131);
term_sink(e, v_4294943130);
term_sink(e, v_4294943124);
term_sink(e, v_4294943123);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294943125;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_52_50_48_53_;
WL_PUSHN(2);
} else {
u64 task_24206 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_52_50_48_53_, WL_CONT, WL_IDX, 1);
e.mem[task_24206 + 0] = v_4294943125;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_52_50_48_53_, task_24206);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
} else {
term_sink(e, v_4294943131);
term_sink(e, v_4294943130);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294943125;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_52_50_48_56_;
WL_PUSHN(2);
} else {
u64 task_24212 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_52_50_48_56_, WL_CONT, WL_IDX, 1);
e.mem[task_24212 + 0] = v_4294943125;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_52_50_48_56_, task_24212);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294943126;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_52_50_49_49_;
WL_PUSHN(2);
} else {
u64 task_24212 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_52_50_49_49_, WL_CONT, WL_IDX, 1);
e.mem[task_24212 + 0] = v_4294943126;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_52_50_49_49_, task_24212);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294943131);
term_sink(e, v_4294943130);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294943129;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_52_50_49_52_;
WL_PUSHN(2);
} else {
u64 task_24215 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_52_50_49_52_, WL_CONT, WL_IDX, 1);
e.mem[task_24215 + 0] = v_4294943129;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_52_50_49_52_, task_24215);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_50_48_53_)
  {
    WL_POPN(1);
    Term v_4294943125 = STK(0);
    Term v_4294943092 = r0;
    WL_OPEN
Term v_4294943091 = v_4294943125;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294943092; Term arg = v_4294943091;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_50_48_56_)
  {
    WL_POPN(1);
    Term v_4294943125 = STK(0);
    Term v_4294943089 = r0;
    WL_OPEN
Term v_4294943088 = v_4294943125;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294943089; Term arg = v_4294943088;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_50_49_49_)
  {
    WL_POPN(1);
    Term v_4294943126 = STK(0);
    Term v_4294943086 = r0;
    WL_OPEN
Term v_4294943085 = v_4294943126;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294943086; Term arg = v_4294943085;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_50_49_52_)
  {
    WL_POPN(1);
    Term v_4294943129 = STK(0);
    Term v_4294943083 = r0;
    WL_OPEN
Term v_4294943082 = v_4294943129;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294943083; Term arg = v_4294943082;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_99_109_112_46_114_101_99_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_50_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_50_)
  {
    Term v_4294942056 = r0;
    WL_OPEN
u64 cl_25246 = heap_alloc(e, cls_fit(1));
e.mem[cl_25246 + 0] = v_4294942056;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_51_, cl_25246);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_51_)
  {
    Term v_4294942056 = r0;
    Term v_4294942055 = r1;
    WL_OPEN
u64 cl_25245 = heap_alloc(e, cls_fit(2));
e.mem[cl_25245 + 0] = v_4294942056;
e.mem[cl_25245 + 1] = v_4294942055;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_52_, cl_25245);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_50_52_52_)
  {
    Term v_4294942056 = r0;
    Term v_4294942055 = r1;
    Term v_4294942054 = r2;
    WL_OPEN
r0 = v_4294942056;
r1 = v_4294942055;
r2 = v_4294942054;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_114_101_99_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_99_109_112_46_114_101_99_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294942048 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294942047 = r1;
    Term v_4294942046 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_83_116_114_105_110_103_46_99_109_112_46_114_101_99_(e, seq, nq_result, v_4294942048, v_4294942047, v_4294942046)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
if ((term_aux(v_4294942046) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294942046, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294942045 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294942044 = fields[1];
Term v_4294942043 = v_4294942045;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942042 = v_4294942044;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294942043) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294942043, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294942041 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294942040 = fields[1];
Term v_4294942035 = v_4294942048;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942034 = v_4294942041;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942037;
{
u64 nd_25262 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_25262 + 0] = v_4294942035;
e.mem[nd_25262 + 1] = v_4294942034;
#else
e.mem[nd_25262 + 0] = rfc_seal(e, v_4294942035);
e.mem[nd_25262 + 1] = rfc_seal(e, v_4294942034);
#endif
v_4294942037 = term_ctr(CID_SCON, nd_25262);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942032 = v_4294942047;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942031 = v_4294942040;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942036;
{
u64 nd_25265 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_25265 + 0] = v_4294942032;
e.mem[nd_25265 + 1] = v_4294942031;
#else
e.mem[nd_25265 + 0] = rfc_seal(e, v_4294942032);
e.mem[nd_25265 + 1] = rfc_seal(e, v_4294942031);
#endif
v_4294942036 = term_ctr(CID_SCON, nd_25265);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942039;
{
u64 nd_25266 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_25266 + 0] = v_4294942037;
e.mem[nd_25266 + 1] = v_4294942036;
#else
e.mem[nd_25266 + 0] = rfc_seal(e, v_4294942037);
e.mem[nd_25266 + 1] = rfc_seal(e, v_4294942036);
#endif
v_4294942039 = term_ctr(CID_TUPLE, nd_25266);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942038 = v_4294942042;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_25267 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_25267 + 0] = v_4294942039;
e.mem[nd_25267 + 1] = v_4294942038;
#else
e.mem[nd_25267 + 0] = rfc_seal(e, v_4294942039);
e.mem[nd_25267 + 1] = rfc_seal(e, v_4294942038);
#endif
r0 = term_ctr(CID_TUPLE, nd_25267);
WL_RETN(1);
} else {
term_sink(e, v_4294942048);
term_sink(e, v_4294942047);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294942042;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_53_50_55_48_;
WL_PUSHN(2);
} else {
u64 task_25274 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_53_50_55_48_, WL_CONT, WL_IDX, 1);
e.mem[task_25274 + 0] = v_4294942042;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_48_, task_25274);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294942043;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_53_50_55_51_;
WL_PUSHN(2);
} else {
u64 task_25274 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_53_50_55_51_, WL_CONT, WL_IDX, 1);
e.mem[task_25274 + 0] = v_4294942043;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_51_, task_25274);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294942048);
term_sink(e, v_4294942047);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294942046;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_53_50_55_54_;
WL_PUSHN(2);
} else {
u64 task_25277 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_53_50_55_54_, WL_CONT, WL_IDX, 1);
e.mem[task_25277 + 0] = v_4294942046;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_54_, task_25277);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_48_)
  {
    WL_POPN(1);
    Term v_4294942042 = STK(0);
    Term v_4294942027 = r0;
    WL_OPEN
Term v_4294942026 = v_4294942042;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294942027; Term arg = v_4294942026;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_51_)
  {
    WL_POPN(1);
    Term v_4294942043 = STK(0);
    Term v_4294942024 = r0;
    WL_OPEN
Term v_4294942023 = v_4294942043;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294942024; Term arg = v_4294942023;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_50_55_54_)
  {
    WL_POPN(1);
    Term v_4294942046 = STK(0);
    Term v_4294942021 = r0;
    WL_OPEN
Term v_4294942020 = v_4294942046;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294942021; Term arg = v_4294942020;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_67_104_97_114_46_99_109_112_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_54_51_48_51_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_54_51_48_51_)
  {
    Term v_4294940994 = r0;
    WL_OPEN
u64 cl_26305 = heap_alloc(e, cls_fit(1));
e.mem[cl_26305 + 0] = v_4294940994;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_54_51_48_52_, cl_26305);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_54_51_48_52_)
  {
    Term v_4294940994 = r0;
    Term v_4294940993 = r1;
    WL_OPEN
r0 = v_4294940994;
r1 = v_4294940993;
WL_JMP(FID_36_100_105_114_101_99_116_46_67_104_97_114_46_99_109_112_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_67_104_97_114_46_99_109_112_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294940989 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294940988 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_67_104_97_114_46_99_109_112_(e, seq, nq_result, v_4294940989, v_4294940988)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294940987 = v_4294940989;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294940986 = v_4294940988;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294940985 = v_4294940987;
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294940984 = v_4294940986;
v_4294940985 = term_keep(e, v_4294940985);
Term v_4294940979 = v_4294940985;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294940981;
{
v_4294940981 = v_4294940979;
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294940984 = term_keep(e, v_4294940984);
Term v_4294940978 = v_4294940984;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294940980;
{
v_4294940980 = v_4294940978;
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294940983;
{
u64 nd_26318 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_26318 + 0] = v_4294940981;
e.mem[nd_26318 + 1] = v_4294940980;
#else
e.mem[nd_26318 + 0] = rfc_seal(e, v_4294940981);
e.mem[nd_26318 + 1] = rfc_seal(e, v_4294940980);
#endif
v_4294940983 = term_ctr(CID_TUPLE, nd_26318);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294940976 = v_4294940985;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294940975 = v_4294940984;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294940982 = term_pak(((U32_BIN(v_4294940976, >, v_4294940975) + U32_BIN(v_4294940976, >=, v_4294940975))) == 0 ? CID_LT : ((U32_BIN(v_4294940976, >, v_4294940975) + U32_BIN(v_4294940976, >=, v_4294940975))) == 1 ? CID_EQ : CID_GT, 0);
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_26321 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_26321 + 0] = v_4294940983;
e.mem[nd_26321 + 1] = v_4294940982;
#else
e.mem[nd_26321 + 0] = rfc_seal(e, v_4294940983);
e.mem[nd_26321 + 1] = rfc_seal(e, v_4294940982);
#endif
r0 = term_ctr(CID_TUPLE, nd_26321);
WL_RETN(1);
} else {
term_sink(e, v_4294940985);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294940986;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_54_51_50_52_;
WL_PUSHN(2);
} else {
u64 task_26325 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_54_51_50_52_, WL_CONT, WL_IDX, 1);
e.mem[task_26325 + 0] = v_4294940986;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_54_51_50_52_, task_26325);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294940986;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_54_51_50_55_;
WL_PUSHN(2);
} else {
u64 task_26331 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_54_51_50_55_, WL_CONT, WL_IDX, 1);
e.mem[task_26331 + 0] = v_4294940986;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_54_51_50_55_, task_26331);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294940987;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_54_51_51_48_;
WL_PUSHN(2);
} else {
u64 task_26331 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_54_51_51_48_, WL_CONT, WL_IDX, 1);
e.mem[task_26331 + 0] = v_4294940987;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_54_51_51_48_, task_26331);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_54_51_50_52_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294940986 = STK(0);
    Term v_4294940973 = r0;
    WL_OPEN
Term v_4294940972 = v_4294940986;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294940973; Term arg = v_4294940972;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_54_51_50_55_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294940986 = STK(0);
    Term v_4294940970 = r0;
    WL_OPEN
Term v_4294940969 = v_4294940986;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294940970; Term arg = v_4294940969;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_54_51_51_48_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294940987 = STK(0);
    Term v_4294940967 = r0;
    WL_OPEN
Term v_4294940966 = v_4294940987;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294940967; Term arg = v_4294940966;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_99_109_112_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_55_51_53_53_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_55_51_53_53_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_27357 = heap_alloc(e, cls_fit(1));
e.mem[cl_27357 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_55_51_53_54_, cl_27357);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_55_51_53_54_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
Term cmp = (U32_BIN(v_4000000000, >, v_4000000001) + U32_BIN(v_4000000000, >=, v_4000000001));
r0 = term_pak(cmp == 0 ? CID_LT : cmp == 1 ? CID_EQ : CID_GT, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_99_109_112_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939937 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939936 = r1;
    WL_OPEN
Term cmp = (U32_BIN(v_4294939937, >, v_4294939936) + U32_BIN(v_4294939937, >=, v_4294939936));
r0 = term_pak(cmp == 0 ? CID_LT : cmp == 1 ? CID_EQ : CID_GT, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_56_51_56_53_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_56_53_)
  {
    Term v_4294938911 = r0;
    WL_OPEN
r0 = v_4294938911;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_)
  {
    Term v_4294938909 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nq_result, v_4294938909)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
if ((term_aux(v_4294938909) == CID_SNIL)) {
r0 = 1ull;
WL_RETN(1);
} else {
if ((term_aux(v_4294938909) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294938909, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294938908 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294938907 = fields[1];
term_sink(e, v_4294938908);
term_sink(e, v_4294938907);
r0 = 0ull;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294938909;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_57_49_;
WL_PUSHN(2);
} else {
u64 task_28392 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_57_49_, WL_CONT, WL_IDX, 1);
e.mem[task_28392 + 0] = v_4294938909;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_57_49_, task_28392);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_57_49_)
  {
    WL_POPN(1);
    Term v_4294938909 = STK(0);
    Term v_4294938906 = r0;
    WL_OPEN
Term v_4294938905 = v_4294938909;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938906; Term arg = v_4294938905;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_114_101_97_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_57_52_49_56_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_49_56_)
  {
    Term v_4294937879 = r0;
    WL_OPEN
u64 cl_29420 = heap_alloc(e, cls_fit(1));
e.mem[cl_29420 + 0] = v_4294937879;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_57_52_49_57_, cl_29420);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_49_57_)
  {
    Term v_4294937879 = r0;
    Term v_4294937878 = r1;
    WL_OPEN
r0 = v_4294937879;
r1 = v_4294937878;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_)
  {
    Term v_4294937874 = r0;
    Term v_4294937873 = r1;
    WL_OPEN
v_4294937874 = term_keep(e, v_4294937874);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294937874;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_57_52_50_54_;
WL_PUSHN(2);
} else {
u64 task_29443 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_57_52_50_54_, WL_CONT, WL_IDX, 1);
e.mem[task_29443 + 0] = v_4294937874;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_54_, task_29443);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_50_57_52_51_54_;
WL_PUSHN(1);
} else {
u64 task_29443 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_57_52_51_54_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_54_, task_29443);
WL_IDX = 0;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294937873;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_57_52_51_57_;
WL_PUSHN(2);
} else {
u64 task_29443 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_57_52_51_57_, WL_CONT, WL_IDX, 1);
e.mem[task_29443 + 0] = v_4294937873;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_57_, task_29443);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294937874;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_57_52_52_50_;
WL_PUSHN(2);
} else {
u64 task_29443 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_57_52_52_50_, WL_CONT, WL_IDX, 1);
e.mem[task_29443 + 0] = v_4294937874;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_57_52_52_50_, task_29443);
WL_IDX = 1;
}
WL_JMP(FID_78_97_116_105_118_101_72_111_115_116_46_114_101_97_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_54_)
  {
    WL_POPN(1);
    Term v_4294937874 = STK(0);
    Term v_4294937872 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294937872;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_57_52_50_55_;
WL_PUSHN(2);
} else {
u64 task_29434 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_57_52_50_55_, WL_CONT, WL_IDX, 1);
e.mem[task_29434 + 0] = v_4294937872;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_55_, task_29434);
WL_IDX = 1;
}
u64 cl_29433 = heap_alloc(e, cls_fit(1));
e.mem[cl_29433 + 0] = v_4294937874;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_48_, cl_29433);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_55_)
  {
    WL_POPN(1);
    Term v_4294937872 = STK(0);
    Term v_4294937871 = r0;
    WL_OPEN
u64 cl_29429 = heap_alloc(e, cls_fit(2));
e.mem[cl_29429 + 0] = v_4294937872;
e.mem[cl_29429 + 1] = v_4294937871;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_56_, cl_29429);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_50_56_)
  {
    Term v_4294937872 = r0;
    Term v_4294937871 = r1;
    Term v_4294937870 = r2;
    WL_OPEN
r0 = v_4294937872;
r1 = v_4294937871;
r2 = v_4294937870;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_98_105_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_48_)
  {
    Term v_4294937874 = r0;
    Term v_3549 = r1;
    WL_OPEN
Term v_4294937864 = v_3549;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294937863 = v_4294937874;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294937864;
r1 = v_4294937863;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_95_100_111_110_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_54_)
  {
    Term v_4294937861 = r0;
    WL_OPEN
Term v_4294937860 = 16777216ull;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294937861; Term arg = v_4294937860;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_51_57_)
  {
    WL_POPN(1);
    Term v_4294937873 = STK(0);
    Term v_4294937858 = r0;
    WL_OPEN
Term v_4294937857 = v_4294937873;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294937858; Term arg = v_4294937857;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_52_52_50_)
  {
    WL_POPN(1);
    Term v_4294937874 = STK(0);
    Term v_4294937855 = r0;
    WL_OPEN
Term v_4294937854 = v_4294937874;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294937855; Term arg = v_4294937854;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_78_97_116_105_118_101_72_111_115_116_46_114_101_97_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_55_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_55_)
  {
    Term v_4294937852 = r0;
    WL_OPEN
u64 cl_30474 = heap_alloc(e, cls_fit(1));
e.mem[cl_30474 + 0] = v_4294937852;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_56_, cl_30474);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_56_)
  {
    Term v_4294937852 = r0;
    Term v_4294937851 = r1;
    WL_OPEN
u64 cl_30473 = heap_alloc(e, cls_fit(2));
e.mem[cl_30473 + 0] = v_4294937852;
e.mem[cl_30473 + 1] = v_4294937851;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_57_, cl_30473);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_54_57_)
  {
    Term v_4294937852 = r0;
    Term v_4294937851 = r1;
    Term v_4294937850 = r2;
    WL_OPEN
u64 cl_30472 = heap_alloc(e, cls_fit(3));
e.mem[cl_30472 + 0] = v_4294937852;
e.mem[cl_30472 + 1] = v_4294937851;
e.mem[cl_30472 + 2] = v_4294937850;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_52_55_48_, cl_30472);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_55_48_)
  {
    Term v_4294937852 = r0;
    Term v_4294937851 = r1;
    Term v_4294937850 = r2;
    Term v_4294937848 = r3;
    WL_OPEN
u64 nd_30471 = heap_alloc(e, cls_fit(4));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_NATIVEHOST_READ
e.mem[nd_30471 + 0] = v_4294937852;
e.mem[nd_30471 + 1] = v_4294937851;
e.mem[nd_30471 + 2] = v_4294937850;
e.mem[nd_30471 + 3] = v_4294937848;
#else
e.mem[nd_30471 + 0] = rfc_seal(e, v_4294937852);
e.mem[nd_30471 + 1] = rfc_seal(e, v_4294937851);
e.mem[nd_30471 + 2] = rfc_seal(e, v_4294937850);
e.mem[nd_30471 + 3] = rfc_seal(e, v_4294937848);
#endif
r0 = term_ctr(CID_NATIVEHOST_READ, nd_30471);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_114_101_97_100_)
  {
    Term v_4294936820 = r0;
    Term v_4294936819 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294936818 = r2;
    Term v_4294936817 = r3;
    WL_OPEN
u64 nd_30479 = heap_alloc(e, cls_fit(4));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_NATIVEHOST_READ
e.mem[nd_30479 + 0] = v_4294936820;
e.mem[nd_30479 + 1] = v_4294936819;
e.mem[nd_30479 + 2] = v_4294936818;
e.mem[nd_30479 + 3] = v_4294936817;
#else
e.mem[nd_30479 + 0] = rfc_seal(e, v_4294936820);
e.mem[nd_30479 + 1] = rfc_seal(e, v_4294936819);
e.mem[nd_30479 + 2] = rfc_seal(e, v_4294936818);
e.mem[nd_30479 + 3] = rfc_seal(e, v_4294936817);
#endif
r0 = term_ctr(CID_NATIVEHOST_READ, nd_30479);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_114_101_97_100_95_100_111_110_101_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_)
  {
    Term v_4294935791 = r0;
    WL_OPEN
u64 cl_31508 = heap_alloc(e, cls_fit(1));
e.mem[cl_31508 + 0] = v_4294935791;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_55_, cl_31508);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_55_)
  {
    Term v_4294935791 = r0;
    Term v_4294935790 = r1;
    WL_OPEN
r0 = v_4294935791;
r1 = v_4294935790;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_95_100_111_110_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_114_101_97_100_95_100_111_110_101_)
  {
    Term v_4294935786 = r0;
    Term v_4294935785 = r1;
    WL_OPEN
Term v_4294935784 = v_4294935786;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935783 = v_4294935785;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294935784) == CID_DONE)) {
Term fields[1];
if (term_tag(v_4294935784) == TAG_PAK) { fields[0] = term_loc(v_4294935784); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294935784, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID_DONE_0
u32
#else
Term
#endif
v_4294935782 = fields[0];
term_sink(e, v_4294935783);
Term v_4294935781 = v_4294935782;
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_31517 = heap_alloc(e, cls_fit(1));
e.mem[cl_31517 + 0] = v_4294935781;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_54_, cl_31517);
WL_RETN(1);
} else {
Term v_4294935777 = v_4294935784;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935776 = v_4294935783;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294935777) == CID_FAIL)) {
Term fields[1];
if (term_tag(v_4294935777) == TAG_PAK) { fields[0] = term_loc(v_4294935777); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294935777, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID_FAIL_0
u32
#else
Term
#endif
v_4294935775 = fields[0];
Term v_4294935774 = v_4294935775;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935773 = v_4294935776;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294935774) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294935774, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294935772 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294935771 = fields[1];
term_sink(e, v_4294935772);
Term v_4294935770 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935763 = term_ctr(CID_SCON, STAT_OFF + 358);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935762 = v_4294935773;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935765;
{
Term nf_local_31534[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_31534, v_4294935763, v_4294935762)) { return 0; }
v_4294935765 = nf_local_31534[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935764 = term_ctr(CID_SCON, STAT_OFF + 233);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935767;
{
Term nf_local_31535[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_31535, v_4294935765, v_4294935764)) { return 0; }
v_4294935767 = nf_local_31535[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935766 = v_4294935771;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935769;
{
Term nf_local_31536[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_31536, v_4294935767, v_4294935766)) { return 0; }
v_4294935769 = nf_local_31536[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
u64 cl_31538 = heap_alloc(e, cls_fit(2));
e.mem[cl_31538 + 0] = v_4294935770;
e.mem[cl_31538 + 1] = v_4294935769;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_53_51_55_, cl_31538);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935773;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_52_49_;
WL_PUSHN(2);
} else {
u64 task_31545 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_52_49_, WL_CONT, WL_IDX, 1);
e.mem[task_31545 + 0] = v_4294935773;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_49_, task_31545);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935774;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_52_52_;
WL_PUSHN(2);
} else {
u64 task_31545 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_52_52_, WL_CONT, WL_IDX, 1);
e.mem[task_31545 + 0] = v_4294935774;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_52_, task_31545);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935776;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_52_55_;
WL_PUSHN(2);
} else {
u64 task_31551 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_52_55_, WL_CONT, WL_IDX, 1);
e.mem[task_31551 + 0] = v_4294935776;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_55_, task_31551);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935777;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_53_48_;
WL_PUSHN(2);
} else {
u64 task_31551 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_53_48_, WL_CONT, WL_IDX, 1);
e.mem[task_31551 + 0] = v_4294935777;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_53_48_, task_31551);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_54_)
  {
    Term v_4294935781 = r0;
    Term v_4294935780 = r1;
    WL_OPEN
r0 = v_4294935781;
r1 = v_4294935780;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_112_117_114_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_51_55_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294935770 = r0;
    Term v_4294935769 = r1;
    Term v_4294935768 = r2;
    WL_OPEN
r0 = v_4294935770;
r1 = v_4294935769;
r2 = v_4294935768;
WL_JMP(FID_36_100_105_114_101_99_116_46_73_79_46_100_105_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_49_)
  {
    WL_POPN(1);
    Term v_4294935773 = STK(0);
    Term v_4294935756 = r0;
    WL_OPEN
Term v_4294935755 = v_4294935773;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294935756; Term arg = v_4294935755;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_52_)
  {
    WL_POPN(1);
    Term v_4294935774 = STK(0);
    Term v_4294935753 = r0;
    WL_OPEN
Term v_4294935752 = v_4294935774;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294935753; Term arg = v_4294935752;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_52_55_)
  {
    WL_POPN(1);
    Term v_4294935776 = STK(0);
    Term v_4294935750 = r0;
    WL_OPEN
Term v_4294935749 = v_4294935776;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294935750; Term arg = v_4294935749;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_53_48_)
  {
    WL_POPN(1);
    Term v_4294935777 = STK(0);
    Term v_4294935747 = r0;
    WL_OPEN
Term v_4294935746 = v_4294935777;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294935747; Term arg = v_4294935746;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_78_97_116_105_118_101_72_111_115_116_46_112_117_98_108_105_115_104_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_53_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_53_)
  {
    Term v_4294935744 = r0;
    WL_OPEN
u64 cl_32580 = heap_alloc(e, cls_fit(1));
e.mem[cl_32580 + 0] = v_4294935744;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_54_, cl_32580);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_54_)
  {
    Term v_4294935744 = r0;
    Term v_4294935743 = r1;
    WL_OPEN
u64 cl_32579 = heap_alloc(e, cls_fit(2));
e.mem[cl_32579 + 0] = v_4294935744;
e.mem[cl_32579 + 1] = v_4294935743;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_55_, cl_32579);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_50_53_55_55_)
  {
    Term v_4294935744 = r0;
    Term v_4294935743 = r1;
    Term v_4294935741 = r2;
    WL_OPEN
u64 nd_32578 = heap_alloc(e, cls_fit(3));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_NATIVEHOST_PUBLISH
e.mem[nd_32578 + 0] = v_4294935744;
e.mem[nd_32578 + 1] = v_4294935743;
e.mem[nd_32578 + 2] = v_4294935741;
#else
e.mem[nd_32578 + 0] = rfc_seal(e, v_4294935744);
e.mem[nd_32578 + 1] = rfc_seal(e, v_4294935743);
e.mem[nd_32578 + 2] = rfc_seal(e, v_4294935741);
#endif
r0 = term_ctr(CID_NATIVEHOST_PUBLISH, nd_32578);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_78_97_116_105_118_101_72_111_115_116_46_112_117_98_108_105_115_104_)
  {
    Term v_4294934714 = r0;
    Term v_4294934713 = r1;
    Term v_4294934712 = r2;
    WL_OPEN
u64 nd_32584 = heap_alloc(e, cls_fit(3));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_NATIVEHOST_PUBLISH
e.mem[nd_32584 + 0] = v_4294934714;
e.mem[nd_32584 + 1] = v_4294934713;
e.mem[nd_32584 + 2] = v_4294934712;
#else
e.mem[nd_32584 + 0] = rfc_seal(e, v_4294934714);
e.mem[nd_32584 + 1] = rfc_seal(e, v_4294934713);
e.mem[nd_32584 + 2] = rfc_seal(e, v_4294934712);
#endif
r0 = term_ctr(CID_NATIVEHOST_PUBLISH, nd_32584);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_112_97_114_115_101_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_51_54_49_48_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_51_54_49_48_)
  {
    Term v_4294933686 = r0;
    WL_OPEN
r0 = v_4294933686;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_114_115_101_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_112_97_114_115_101_)
  {
    Term v_4294933684 = r0;
    WL_OPEN
if ((term_aux(v_4294933684) == CID_CON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294933684, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_CON_0
u32
#else
Term
#endif
v_4294933683 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_CON_1
u32
#else
Term
#endif
v_4294933682 = fields[1];
if ((term_aux(v_4294933682) == CID_NIL)) {
v_4294933683 = term_keep(e, v_4294933683);
Term v_4294933617 = v_4294933683;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933616 = term_ctr(CID_SCON, STAT_OFF + 338);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933681;
{
Term nf_local_33680[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_33680, v_4294933617, v_4294933616)) { return 0; }
v_4294933681 = nf_local_33680[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294933681)) {
term_sink(e, v_4294933683);
Term v_3488;
{
v_3488 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3488);
r0 = term_pak(CID__CTOR_67_76_73_72_101_108_112_, 0);
WL_RETN(1);
} else {
if ((!native_bool(v_4294933681))) {
Term v_3489;
{
v_3489 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3489);
v_4294933683 = term_keep(e, v_4294933683);
Term v_4294933550 = v_4294933683;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933549 = term_ctr(CID_SCON, STAT_OFF + 350);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933614;
{
Term nf_local_33747[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_33747, v_4294933550, v_4294933549)) { return 0; }
v_4294933614 = nf_local_33747[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294933614)) {
term_sink(e, v_4294933683);
Term v_3490;
{
v_3490 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3490);
r0 = term_pak(CID__CTOR_67_76_73_86_101_114_115_105_111_110_, 0);
WL_RETN(1);
} else {
if ((!native_bool(v_4294933614))) {
Term v_3491;
{
v_3491 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3491);
Term v_4294933542 = v_4294933683;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933541 = term_pak(CID_NIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933547;
{
u64 nd_33755 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_CON
e.mem[nd_33755 + 0] = v_4294933542;
e.mem[nd_33755 + 1] = v_4294933541;
#else
e.mem[nd_33755 + 0] = rfc_seal(e, v_4294933542);
e.mem[nd_33755 + 1] = rfc_seal(e, v_4294933541);
#endif
v_4294933547 = term_ctr(CID_CON, nd_33755);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933546 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933545 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933544 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933543 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294933547;
r1 = v_4294933546;
r2 = v_4294933545;
r3 = v_4294933544;
r4 = v_4294933543;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);
} else {
term_sink(e, v_4294933683);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294933614;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_51_55_53_56_;
WL_PUSHN(2);
} else {
u64 task_33759 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_51_55_53_56_, WL_CONT, WL_IDX, 1);
e.mem[task_33759 + 0] = v_4294933614;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_51_55_53_56_, task_33759);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294933683);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294933681;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_51_55_54_49_;
WL_PUSHN(2);
} else {
u64 task_33762 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_51_55_54_49_, WL_CONT, WL_IDX, 1);
e.mem[task_33762 + 0] = v_4294933681;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_51_55_54_49_, task_33762);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
Term v_4294933528 = v_4294933683;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933527 = v_4294933682;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933533;
{
u64 nd_33769 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_CON
e.mem[nd_33769 + 0] = v_4294933528;
e.mem[nd_33769 + 1] = v_4294933527;
#else
e.mem[nd_33769 + 0] = rfc_seal(e, v_4294933528);
e.mem[nd_33769 + 1] = rfc_seal(e, v_4294933527);
#endif
v_4294933533 = term_ctr(CID_CON, nd_33769);
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933532 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933531 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933530 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933529 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294933533;
r1 = v_4294933532;
r2 = v_4294933531;
r3 = v_4294933530;
r4 = v_4294933529;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);
}
} else {
Term v_4294933525 = v_4294933684;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933524 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933523 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933522 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294933521 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294933525;
r1 = v_4294933524;
r2 = v_4294933523;
r3 = v_4294933522;
r4 = v_4294933521;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_51_55_53_56_)
  {
    WL_POPN(1);
    Term v_4294933614 = STK(0);
    Term v_4294933539 = r0;
    WL_OPEN
Term v_4294933538 = v_4294933614;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294933539; Term arg = v_4294933538;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_51_55_54_49_)
  {
    WL_POPN(1);
    Term v_4294933681 = STK(0);
    Term v_4294933536 = r0;
    WL_OPEN
Term v_4294933535 = v_4294933681;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294933536; Term arg = v_4294933535;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_111_112_116_105_111_110_115_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_52_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_52_)
  {
    Term v_4294932496 = r0;
    WL_OPEN
u64 cl_34812 = heap_alloc(e, cls_fit(1));
e.mem[cl_34812 + 0] = v_4294932496;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_53_, cl_34812);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_53_)
  {
    Term v_4294932496 = r0;
    Term v_4294932495 = r1;
    WL_OPEN
u64 cl_34811 = heap_alloc(e, cls_fit(2));
e.mem[cl_34811 + 0] = v_4294932496;
e.mem[cl_34811 + 1] = v_4294932495;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_54_, cl_34811);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_54_)
  {
    Term v_4294932496 = r0;
    Term v_4294932495 = r1;
    Term v_4294932494 = r2;
    WL_OPEN
u64 cl_34810 = heap_alloc(e, cls_fit(3));
e.mem[cl_34810 + 0] = v_4294932496;
e.mem[cl_34810 + 1] = v_4294932495;
e.mem[cl_34810 + 2] = v_4294932494;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_55_, cl_34810);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_55_)
  {
    Term v_4294932496 = r0;
    Term v_4294932495 = r1;
    Term v_4294932494 = r2;
    Term v_4294932493 = r3;
    WL_OPEN
u64 cl_34809 = heap_alloc(e, cls_fit(4));
e.mem[cl_34809 + 0] = v_4294932496;
e.mem[cl_34809 + 1] = v_4294932495;
e.mem[cl_34809 + 2] = v_4294932494;
e.mem[cl_34809 + 3] = v_4294932493;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_56_, cl_34809);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_56_48_56_)
  {
    Term v_4294932496 = r0;
    Term v_4294932495 = r1;
    Term v_4294932494 = r2;
    Term v_4294932493 = r3;
    Term v_4294932492 = r4;
    WL_OPEN
r0 = v_4294932496;
r1 = v_4294932495;
r2 = v_4294932494;
r3 = v_4294932493;
r4 = v_4294932492;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_)
  {
    Term v_4294932482 = r0;
    Term v_4294932481 = r1;
    Term v_4294932480 = r2;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932479 = r3;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932478 = r4;
    WL_OPEN
Term v_4294932477 = v_4294932482;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932476 = v_4294932481;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932475 = v_4294932480;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932474 = v_4294932479;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932473 = v_4294932478;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294932477) == CID_NIL)) {
term_sink(e, v_4294932473);
v_4294932476 = term_keep(e, v_4294932476);
Term v_4294932406 = v_4294932476;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932408;
{
Term nf_local_34890[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_local_34890, v_4294932406)) { return 0; }
v_4294932408 = nf_local_34890[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294932475 = term_keep(e, v_4294932475);
Term v_4294932404 = v_4294932475;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932407;
{
Term nf_local_34892[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_local_34892, v_4294932404)) { return 0; }
v_4294932407 = nf_local_34892[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932472 = (native_bool(v_4294932408) | native_bool(v_4294932407));
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294932472)) {
term_sink(e, v_4294932476);
term_sink(e, v_4294932475);
term_sink(e, v_4294932474);
Term v_3503;
{
v_3503 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3503);
r0 = term_ctr(CID__CTOR_67_76_73_69_114_114_111_114_, STAT_OFF + 173);
WL_RETN(1);
} else {
if ((!native_bool(v_4294932472))) {
Term v_3504;
{
v_3504 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3504);
Term v_4294932402 = v_4294932476;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932401 = v_4294932475;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932400 = v_4294932474;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_34896 = heap_alloc(e, cls_fit(3));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_67_76_73_82_101_113_117_101_115_116_
e.mem[nd_34896 + 0] = v_4294932402;
e.mem[nd_34896 + 1] = v_4294932401;
e.mem[nd_34896 + 2] = v_4294932400;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_34896 + 0] = v_4294932402;
e.mem[nd_34896 + 1] = v_4294932401;
e.mem[nd_34896 + 2] = v_4294932400;
#else
e.mem[nd_34896 + 0] = rfc_seal(e, v_4294932402);
e.mem[nd_34896 + 1] = rfc_seal(e, v_4294932401);
e.mem[nd_34896 + 2] = rfc_seal(e, v_4294932400);
#endif
#endif
r0 = term_ctr(CID__CTOR_67_76_73_82_101_113_117_101_115_116_, nd_34896);
WL_RETN(1);
} else {
term_sink(e, v_4294932476);
term_sink(e, v_4294932475);
term_sink(e, v_4294932474);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932472;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_52_56_57_57_;
WL_PUSHN(2);
} else {
u64 task_34900 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_52_56_57_57_, WL_CONT, WL_IDX, 1);
e.mem[task_34900 + 0] = v_4294932472;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_52_56_57_57_, task_34900);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
Term v_4294932395 = v_4294932477;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932394 = v_4294932476;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932393 = v_4294932475;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932392 = v_4294932474;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932391 = v_4294932473;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294932395) == CID_CON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294932395, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_CON_0
u32
#else
Term
#endif
v_4294932390 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_CON_1
u32
#else
Term
#endif
v_4294932389 = fields[1];
v_4294932391 = term_keep(e, v_4294932391);
Term v_4294932322 = v_4294932391;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932324;
{
Term nf_local_34974[1];
if (!NF_FID_66_111_111_108_46_110_111_116_(e, seq, nf_local_34974, v_4294932322)) { return 0; }
v_4294932324 = nf_local_34974[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294932390 = term_keep(e, v_4294932390);
Term v_4294932318 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932317 = term_ctr(CID_SCON, STAT_OFF + 176);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932320;
{
Term nf_local_34979[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_34979, v_4294932318, v_4294932317)) { return 0; }
v_4294932320 = nf_local_34979[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294932390 = term_keep(e, v_4294932390);
Term v_4294932315 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932314 = term_ctr(CID_SCON, STAT_OFF + 192);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932319;
{
Term nf_local_34982[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_34982, v_4294932315, v_4294932314)) { return 0; }
v_4294932319 = nf_local_34982[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932323 = (native_bool(v_4294932320) | native_bool(v_4294932319));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932388;
{
Term nf_local_34983[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nf_local_34983, v_4294932324, v_4294932323)) { return 0; }
v_4294932388 = nf_local_34983[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294932388)) {
term_sink(e, v_4294932391);
term_sink(e, v_4294932390);
Term v_3511;
{
v_3511 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3511);
Term v_4294932311 = v_4294932389;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932310 = v_4294932394;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932309 = v_4294932393;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932308 = v_4294932392;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294932311;
r1 = v_4294932310;
r2 = v_4294932309;
r3 = v_4294932308;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_117_116_112_117_116_);
} else {
if ((!native_bool(v_4294932388))) {
Term v_3512;
{
v_3512 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3512);
v_4294932391 = term_keep(e, v_4294932391);
Term v_4294932241 = v_4294932391;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932243;
{
Term nf_local_35055[1];
if (!NF_FID_66_111_111_108_46_110_111_116_(e, seq, nf_local_35055, v_4294932241)) { return 0; }
v_4294932243 = nf_local_35055[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294932390 = term_keep(e, v_4294932390);
Term v_4294932239 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932238 = term_ctr(CID_SCON, STAT_OFF + 196);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932242;
{
Term nf_local_35058[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_35058, v_4294932239, v_4294932238)) { return 0; }
v_4294932242 = nf_local_35058[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932307;
{
Term nf_local_35059[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nf_local_35059, v_4294932243, v_4294932242)) { return 0; }
v_4294932307 = nf_local_35059[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294932307)) {
term_sink(e, v_4294932391);
term_sink(e, v_4294932390);
Term v_3513;
{
v_3513 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3513);
Term v_4294932235 = v_4294932389;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932234 = v_4294932394;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932233 = v_4294932393;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932232 = v_4294932392;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932231 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294932235;
r1 = v_4294932234;
r2 = v_4294932233;
r3 = v_4294932232;
r4 = v_4294932231;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);
} else {
if ((!native_bool(v_4294932307))) {
Term v_3514;
{
v_3514 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3514);
v_4294932391 = term_keep(e, v_4294932391);
Term v_4294932164 = v_4294932391;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932166;
{
Term nf_local_35132[1];
if (!NF_FID_66_111_111_108_46_110_111_116_(e, seq, nf_local_35132, v_4294932164)) { return 0; }
v_4294932166 = nf_local_35132[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294932390 = term_keep(e, v_4294932390);
Term v_4294932162 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932161 = term_ctr(CID_SCON, STAT_OFF + 208);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932165;
{
Term nf_local_35135[1];
if (!NF_FID_83_116_114_105_110_103_46_101_113_(e, seq, nf_local_35135, v_4294932162, v_4294932161)) { return 0; }
v_4294932165 = nf_local_35135[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932230;
{
Term nf_local_35136[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nf_local_35136, v_4294932166, v_4294932165)) { return 0; }
v_4294932230 = nf_local_35136[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294932230)) {
term_sink(e, v_4294932390);
Term v_3515;
{
v_3515 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3515);
Term v_4294932158 = v_4294932392;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294932158)) {
term_sink(e, v_4294932394);
term_sink(e, v_4294932393);
term_sink(e, v_4294932391);
term_sink(e, v_4294932389);
Term v_3516;
{
v_3516 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3516);
r0 = term_ctr(CID__CTOR_67_76_73_69_114_114_111_114_, STAT_OFF + 230);
WL_RETN(1);
} else {
if ((!native_bool(v_4294932158))) {
Term v_3517;
{
v_3517 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3517);
Term v_4294932094 = v_4294932389;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932093 = v_4294932394;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932092 = v_4294932393;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932091 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932090 = v_4294932391;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294932094;
r1 = v_4294932093;
r2 = v_4294932092;
r3 = v_4294932091;
r4 = v_4294932090;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);
} else {
term_sink(e, v_4294932394);
term_sink(e, v_4294932393);
term_sink(e, v_4294932391);
term_sink(e, v_4294932389);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932158;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_50_48_56_;
WL_PUSHN(2);
} else {
u64 task_35209 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_50_48_56_, WL_CONT, WL_IDX, 1);
e.mem[task_35209 + 0] = v_4294932158;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_50_48_56_, task_35209);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
if ((!native_bool(v_4294932230))) {
Term v_3518;
{
v_3518 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3518);
v_4294932391 = term_keep(e, v_4294932391);
Term v_4294932020 = v_4294932391;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932022;
{
Term nf_local_35276[1];
if (!NF_FID_66_111_111_108_46_110_111_116_(e, seq, nf_local_35276, v_4294932020)) { return 0; }
v_4294932022 = nf_local_35276[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294932390 = term_keep(e, v_4294932390);
if (seq) {
WL_ROOM(8);
STK(0) = v_4294932394;
STK(1) = v_4294932393;
STK(2) = v_4294932392;
STK(3) = v_4294932391;
STK(4) = v_4294932390;
STK(5) = v_4294932389;
STK(6) = v_4294932022;
STK(7) = FID_110_97_116_105_118_101_95_107_95_51_53_50_55_55_;
WL_PUSHN(8);
} else {
u64 task_35370 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_50_55_55_, WL_CONT, WL_IDX, 1);
e.mem[task_35370 + 0] = v_4294932394;
e.mem[task_35370 + 1] = v_4294932393;
e.mem[task_35370 + 2] = v_4294932392;
e.mem[task_35370 + 3] = v_4294932391;
e.mem[task_35370 + 4] = v_4294932390;
e.mem[task_35370 + 5] = v_4294932389;
e.mem[task_35370 + 6] = v_4294932022;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_50_55_55_, task_35370);
WL_IDX = 7;
}
Term v_4294931927 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931926 = term_ctr(CID_SCON, STAT_OFF + 194);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294931927;
r1 = v_4294931926;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_);
} else {
term_sink(e, v_4294932394);
term_sink(e, v_4294932393);
term_sink(e, v_4294932392);
term_sink(e, v_4294932391);
term_sink(e, v_4294932390);
term_sink(e, v_4294932389);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932230;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_55_50_;
WL_PUSHN(2);
} else {
u64 task_35373 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_55_50_, WL_CONT, WL_IDX, 1);
e.mem[task_35373 + 0] = v_4294932230;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_50_, task_35373);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294932394);
term_sink(e, v_4294932393);
term_sink(e, v_4294932392);
term_sink(e, v_4294932391);
term_sink(e, v_4294932390);
term_sink(e, v_4294932389);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932307;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_55_53_;
WL_PUSHN(2);
} else {
u64 task_35376 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_55_53_, WL_CONT, WL_IDX, 1);
e.mem[task_35376 + 0] = v_4294932307;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_53_, task_35376);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294932394);
term_sink(e, v_4294932393);
term_sink(e, v_4294932392);
term_sink(e, v_4294932391);
term_sink(e, v_4294932390);
term_sink(e, v_4294932389);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932388;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_55_56_;
WL_PUSHN(2);
} else {
u64 task_35379 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_55_56_, WL_CONT, WL_IDX, 1);
e.mem[task_35379 + 0] = v_4294932388;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_56_, task_35379);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932391;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_56_49_;
WL_PUSHN(2);
} else {
u64 task_35394 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_56_49_, WL_CONT, WL_IDX, 1);
e.mem[task_35394 + 0] = v_4294932391;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_49_, task_35394);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932392;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_56_52_;
WL_PUSHN(2);
} else {
u64 task_35394 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_56_52_, WL_CONT, WL_IDX, 1);
e.mem[task_35394 + 0] = v_4294932392;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_52_, task_35394);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932393;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_56_55_;
WL_PUSHN(2);
} else {
u64 task_35394 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_56_55_, WL_CONT, WL_IDX, 1);
e.mem[task_35394 + 0] = v_4294932393;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_55_, task_35394);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932394;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_57_48_;
WL_PUSHN(2);
} else {
u64 task_35394 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_57_48_, WL_CONT, WL_IDX, 1);
e.mem[task_35394 + 0] = v_4294932394;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_57_48_, task_35394);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932395;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_57_51_;
WL_PUSHN(2);
} else {
u64 task_35394 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_57_51_, WL_CONT, WL_IDX, 1);
e.mem[task_35394 + 0] = v_4294932395;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_57_51_, task_35394);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_56_57_57_)
  {
    WL_POPN(1);
    Term v_4294932472 = STK(0);
    Term v_4294932398 = r0;
    WL_OPEN
Term v_4294932397 = v_4294932472;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294932398; Term arg = v_4294932397;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_50_48_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932158 = STK(0);
    Term v_4294932089 = r0;
    WL_OPEN
Term v_4294932088 = v_4294932158;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294932089; Term arg = v_4294932088;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_50_55_55_)
  {
    WL_POPN(7);
    Term v_4294932394 = STK(0);
    Term v_4294932393 = STK(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932392 = STK(2);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932391 = STK(3);
    Term v_4294932390 = STK(4);
    Term v_4294932389 = STK(5);
    Term v_4294932022 = STK(6);
    Term v_4294932021 = r0;
    WL_OPEN
Term v_4294932086;
{
Term nf_local_35278[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nf_local_35278, v_4294932022, v_4294932021)) { return 0; }
v_4294932086 = nf_local_35278[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294932086)) {
term_sink(e, v_4294932394);
term_sink(e, v_4294932393);
term_sink(e, v_4294932392);
term_sink(e, v_4294932391);
term_sink(e, v_4294932389);
Term v_3519;
{
v_3519 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3519);
Term v_4294932015 = term_ctr(CID_SCON, STAT_OFF + 261);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932014 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932016;
{
Term nf_local_35282[1];
if (!NF_FID_83_116_114_105_110_103_46_97_112_112_101_110_100_(e, seq, nf_local_35282, v_4294932015, v_4294932014)) { return 0; }
v_4294932016 = nf_local_35282[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_35283 = v_4294932016;
Term pk_35283;
#if NATIVE_PACK_CTORS
if ((pf_35283 & ~LOC_MASK) == 0) {
pk_35283 = term_pak(CID__CTOR_67_76_73_69_114_114_111_114_, pf_35283);
} else
#endif
{
u64 nd_35283 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_67_76_73_69_114_114_111_114_
e.mem[nd_35283 + 0] = pf_35283;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_35283 + 0] = pf_35283;
#else
e.mem[nd_35283 + 0] = rfc_seal(e, pf_35283);
#endif
#endif
pk_35283 = term_ctr(CID__CTOR_67_76_73_69_114_114_111_114_, nd_35283);
}
r0 = pk_35283;
WL_RETN(1);
} else {
if ((!native_bool(v_4294932086))) {
Term v_3520;
{
v_3520 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3520);
Term v_4294931945 = v_4294932394;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931947;
{
Term nf_local_35351[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_local_35351, v_4294931945)) { return 0; }
v_4294931947 = nf_local_35351[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
v_4294932390 = term_keep(e, v_4294932390);
Term v_4294931942 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931943;
{
Term nf_local_35354[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_local_35354, v_4294931942)) { return 0; }
v_4294931943 = nf_local_35354[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931946;
{
Term nf_local_35355[1];
if (!NF_FID_66_111_111_108_46_110_111_116_(e, seq, nf_local_35355, v_4294931943)) { return 0; }
v_4294931946 = nf_local_35355[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294932011;
{
Term nf_local_35356[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nf_local_35356, v_4294931947, v_4294931946)) { return 0; }
v_4294932011 = nf_local_35356[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294932011)) {
Term v_3521;
{
v_3521 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3521);
Term v_4294931938 = v_4294932389;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931937 = v_4294932390;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931936 = v_4294932393;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931935 = v_4294932392;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294931934 = v_4294932391;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294931938;
r1 = v_4294931937;
r2 = v_4294931936;
r3 = v_4294931935;
r4 = v_4294931934;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);
} else {
term_sink(e, v_4294932393);
term_sink(e, v_4294932392);
term_sink(e, v_4294932391);
term_sink(e, v_4294932390);
term_sink(e, v_4294932389);
if ((!native_bool(v_4294932011))) {
Term v_3522;
{
v_3522 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3522);
r0 = term_ctr(CID__CTOR_67_76_73_69_114_114_111_114_, STAT_OFF + 327);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932011;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_54_52_;
WL_PUSHN(2);
} else {
u64 task_35365 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_54_52_, WL_CONT, WL_IDX, 1);
e.mem[task_35365 + 0] = v_4294932011;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_54_52_, task_35365);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294932394);
term_sink(e, v_4294932393);
term_sink(e, v_4294932392);
term_sink(e, v_4294932391);
term_sink(e, v_4294932390);
term_sink(e, v_4294932389);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294932086;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_53_51_54_55_;
WL_PUSHN(2);
} else {
u64 task_35368 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_53_51_54_55_, WL_CONT, WL_IDX, 1);
e.mem[task_35368 + 0] = v_4294932086;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_53_51_54_55_, task_35368);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_54_52_)
  {
    WL_POPN(1);
    Term v_4294932011 = STK(0);
    Term v_4294931933 = r0;
    WL_OPEN
Term v_4294931932 = v_4294932011;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931933; Term arg = v_4294931932;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_54_55_)
  {
    WL_POPN(1);
    Term v_4294932086 = STK(0);
    Term v_4294931930 = r0;
    WL_OPEN
Term v_4294931929 = v_4294932086;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931930; Term arg = v_4294931929;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_50_)
  {
    WL_POPN(1);
    Term v_4294932230 = STK(0);
    Term v_4294931925 = r0;
    WL_OPEN
Term v_4294931924 = v_4294932230;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931925; Term arg = v_4294931924;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_53_)
  {
    WL_POPN(1);
    Term v_4294932307 = STK(0);
    Term v_4294931922 = r0;
    WL_OPEN
Term v_4294931921 = v_4294932307;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931922; Term arg = v_4294931921;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_55_56_)
  {
    WL_POPN(1);
    Term v_4294932388 = STK(0);
    Term v_4294931919 = r0;
    WL_OPEN
Term v_4294931918 = v_4294932388;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931919; Term arg = v_4294931918;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_49_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932391 = STK(0);
    Term v_4294931916 = r0;
    WL_OPEN
Term v_4294931915 = v_4294932391;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931916; Term arg = v_4294931915;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_52_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932392 = STK(0);
    Term v_4294931913 = r0;
    WL_OPEN
Term v_4294931912 = v_4294932392;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931913; Term arg = v_4294931912;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_56_55_)
  {
    WL_POPN(1);
    Term v_4294932393 = STK(0);
    Term v_4294931910 = r0;
    WL_OPEN
Term v_4294931909 = v_4294932393;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931910; Term arg = v_4294931909;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_57_48_)
  {
    WL_POPN(1);
    Term v_4294932394 = STK(0);
    Term v_4294931907 = r0;
    WL_OPEN
Term v_4294931906 = v_4294932394;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931907; Term arg = v_4294931906;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_51_57_51_)
  {
    WL_POPN(1);
    Term v_4294932395 = STK(0);
    Term v_4294931904 = r0;
    WL_OPEN
Term v_4294931903 = v_4294932395;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294931904; Term arg = v_4294931903;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_110_97_116_105_118_101_46_66_111_111_108_46_111_114_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_54_52_49_56_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_54_52_49_56_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_36420 = heap_alloc(e, cls_fit(1));
e.mem[cl_36420 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_54_52_49_57_, cl_36420);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_54_52_49_57_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = (native_bool(v_4000000000) | native_bool(v_4000000001));
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_66_111_111_108_46_111_114_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294930874 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294930873 = r1;
    WL_OPEN
r0 = (native_bool(v_4294930874) | native_bool(v_4294930873));
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_66_111_111_108_46_97_110_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_55_52_52_57_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_52_52_57_)
  {
    Term v_4294929848 = r0;
    WL_OPEN
u64 cl_37451 = heap_alloc(e, cls_fit(1));
e.mem[cl_37451 + 0] = v_4294929848;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_55_52_53_48_, cl_37451);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_52_53_48_)
  {
    Term v_4294929848 = r0;
    Term v_4294929847 = r1;
    WL_OPEN
r0 = v_4294929848;
r1 = v_4294929847;
WL_JMP(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294929843 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294929842 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nq_result, v_4294929843, v_4294929842)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294929841 = v_4294929843;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929840 = v_4294929842;
if (!seq && err_seen(e.mem)) { return 0; }
if ((!native_bool(v_4294929841))) {
term_sink(e, v_4294929840);
r0 = 0ull;
WL_RETN(1);
} else {
Term v_4294929839 = v_4294929841;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929838 = v_4294929840;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294929839)) {
r0 = v_4294929838;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294929838;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_55_52_54_48_;
WL_PUSHN(2);
} else {
u64 task_37464 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_55_52_54_48_, WL_CONT, WL_IDX, 1);
e.mem[task_37464 + 0] = v_4294929838;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_55_52_54_48_, task_37464);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294929839;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_55_52_54_51_;
WL_PUSHN(2);
} else {
u64 task_37464 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_55_52_54_51_, WL_CONT, WL_IDX, 1);
e.mem[task_37464 + 0] = v_4294929839;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_55_52_54_51_, task_37464);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_52_54_48_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294929838 = STK(0);
    Term v_4294929837 = r0;
    WL_OPEN
Term v_4294929836 = v_4294929838;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294929837; Term arg = v_4294929836;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_52_54_51_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294929839 = STK(0);
    Term v_4294929834 = r0;
    WL_OPEN
Term v_4294929833 = v_4294929839;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294929834; Term arg = v_4294929833;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_66_111_111_108_46_110_111_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_56_52_56_57_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_56_52_56_57_)
  {
    Term v_4294928807 = r0;
    WL_OPEN
r0 = v_4294928807;
WL_JMP(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_110_111_116_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_110_111_116_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294928805 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_66_111_111_108_46_110_111_116_(e, seq, nq_result, v_4294928805)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
if ((!native_bool(v_4294928805))) {
r0 = 1ull;
WL_RETN(1);
} else {
if (native_bool(v_4294928805)) {
r0 = 0ull;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294928805;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_56_52_57_51_;
WL_PUSHN(2);
} else {
u64 task_38494 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_56_52_57_51_, WL_CONT, WL_IDX, 1);
e.mem[task_38494 + 0] = v_4294928805;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_56_52_57_51_, task_38494);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_56_52_57_51_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294928805 = STK(0);
    Term v_4294928804 = r0;
    WL_OPEN
Term v_4294928803 = v_4294928805;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294928804; Term arg = v_4294928803;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_99_108_105_95_111_117_116_112_117_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_50_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_50_)
  {
    Term v_4294927777 = r0;
    WL_OPEN
u64 cl_39528 = heap_alloc(e, cls_fit(1));
e.mem[cl_39528 + 0] = v_4294927777;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_51_, cl_39528);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_51_)
  {
    Term v_4294927777 = r0;
    Term v_4294927776 = r1;
    WL_OPEN
u64 cl_39527 = heap_alloc(e, cls_fit(2));
e.mem[cl_39527 + 0] = v_4294927777;
e.mem[cl_39527 + 1] = v_4294927776;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_52_, cl_39527);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_52_)
  {
    Term v_4294927777 = r0;
    Term v_4294927776 = r1;
    Term v_4294927775 = r2;
    WL_OPEN
u64 cl_39526 = heap_alloc(e, cls_fit(3));
e.mem[cl_39526 + 0] = v_4294927777;
e.mem[cl_39526 + 1] = v_4294927776;
e.mem[cl_39526 + 2] = v_4294927775;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_53_, cl_39526);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_53_50_53_)
  {
    Term v_4294927777 = r0;
    Term v_4294927776 = r1;
    Term v_4294927775 = r2;
    Term v_4294927774 = r3;
    WL_OPEN
r0 = v_4294927777;
r1 = v_4294927776;
r2 = v_4294927775;
r3 = v_4294927774;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_117_116_112_117_116_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_117_116_112_117_116_)
  {
    Term v_4294927766 = r0;
    Term v_4294927765 = r1;
    Term v_4294927764 = r2;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927763 = r3;
    WL_OPEN
Term v_4294927762 = v_4294927766;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927761 = v_4294927765;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927760 = v_4294927764;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927759 = v_4294927763;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294927762) == CID_CON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294927762, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_CON_0
u32
#else
Term
#endif
v_4294927758 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_CON_1
u32
#else
Term
#endif
v_4294927757 = fields[1];
Term v_4294927691 = v_4294927760;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927692;
{
Term nf_local_39605[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_local_39605, v_4294927691)) { return 0; }
v_4294927692 = nf_local_39605[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927756;
{
Term nf_local_39606[1];
if (!NF_FID_66_111_111_108_46_110_111_116_(e, seq, nf_local_39606, v_4294927692)) { return 0; }
v_4294927756 = nf_local_39606[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294927756)) {
term_sink(e, v_4294927761);
term_sink(e, v_4294927759);
term_sink(e, v_4294927758);
term_sink(e, v_4294927757);
Term v_3532;
{
v_3532 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3532);
r0 = term_ctr(CID__CTOR_67_76_73_69_114_114_111_114_, STAT_OFF + 46);
WL_RETN(1);
} else {
if ((!native_bool(v_4294927756))) {
Term v_3533;
{
v_3533 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3533);
v_4294927758 = term_keep(e, v_4294927758);
Term v_4294927624 = v_4294927758;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927688;
{
Term nf_local_39672[1];
if (!NF_FID_83_116_114_105_110_103_46_105_115_95_101_109_112_116_121_(e, seq, nf_local_39672, v_4294927624)) { return 0; }
v_4294927688 = nf_local_39672[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294927688)) {
term_sink(e, v_4294927761);
term_sink(e, v_4294927759);
term_sink(e, v_4294927758);
term_sink(e, v_4294927757);
Term v_3534;
{
v_3534 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3534);
r0 = term_ctr(CID__CTOR_67_76_73_69_114_114_111_114_, STAT_OFF + 81);
WL_RETN(1);
} else {
if ((!native_bool(v_4294927688))) {
Term v_3535;
{
v_3535 = term_pak(CID_UNIT, 0);
}
if (!seq && err_seen(e.mem)) { return 0; }
term_sink(e, v_3535);
Term v_4294927622 = v_4294927757;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927621 = v_4294927761;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927620 = v_4294927758;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927619 = v_4294927759;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927618 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294927622;
r1 = v_4294927621;
r2 = v_4294927620;
r3 = v_4294927619;
r4 = v_4294927618;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_105_95_111_112_116_105_111_110_115_);
} else {
term_sink(e, v_4294927761);
term_sink(e, v_4294927759);
term_sink(e, v_4294927758);
term_sink(e, v_4294927757);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927688;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_54_56_48_;
WL_PUSHN(2);
} else {
u64 task_39681 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_54_56_48_, WL_CONT, WL_IDX, 1);
e.mem[task_39681 + 0] = v_4294927688;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_54_56_48_, task_39681);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294927761);
term_sink(e, v_4294927759);
term_sink(e, v_4294927758);
term_sink(e, v_4294927757);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927756;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_54_56_51_;
WL_PUSHN(2);
} else {
u64 task_39684 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_54_56_51_, WL_CONT, WL_IDX, 1);
e.mem[task_39684 + 0] = v_4294927756;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_54_56_51_, task_39684);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
Term v_4294927611 = v_4294927762;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927610 = v_4294927761;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927609 = v_4294927760;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927608 = v_4294927759;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294927611) == CID_NIL)) {
term_sink(e, v_4294927610);
term_sink(e, v_4294927609);
term_sink(e, v_4294927608);
r0 = term_ctr(CID__CTOR_67_76_73_69_114_114_111_114_, STAT_OFF + 96);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927608;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_54_57_48_;
WL_PUSHN(2);
} else {
u64 task_39700 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_54_57_48_, WL_CONT, WL_IDX, 1);
e.mem[task_39700 + 0] = v_4294927608;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_48_, task_39700);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927609;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_54_57_51_;
WL_PUSHN(2);
} else {
u64 task_39700 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_54_57_51_, WL_CONT, WL_IDX, 1);
e.mem[task_39700 + 0] = v_4294927609;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_51_, task_39700);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927610;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_54_57_54_;
WL_PUSHN(2);
} else {
u64 task_39700 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_54_57_54_, WL_CONT, WL_IDX, 1);
e.mem[task_39700 + 0] = v_4294927610;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_54_, task_39700);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927611;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_54_57_57_;
WL_PUSHN(2);
} else {
u64 task_39700 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_54_57_57_, WL_CONT, WL_IDX, 1);
e.mem[task_39700 + 0] = v_4294927611;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_57_, task_39700);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_54_56_48_)
  {
    WL_POPN(1);
    Term v_4294927688 = STK(0);
    Term v_4294927617 = r0;
    WL_OPEN
Term v_4294927616 = v_4294927688;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927617; Term arg = v_4294927616;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_54_56_51_)
  {
    WL_POPN(1);
    Term v_4294927756 = STK(0);
    Term v_4294927614 = r0;
    WL_OPEN
Term v_4294927613 = v_4294927756;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927614; Term arg = v_4294927613;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_48_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927608 = STK(0);
    Term v_4294927607 = r0;
    WL_OPEN
Term v_4294927606 = v_4294927608;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927607; Term arg = v_4294927606;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_51_)
  {
    WL_POPN(1);
    Term v_4294927609 = STK(0);
    Term v_4294927604 = r0;
    WL_OPEN
Term v_4294927603 = v_4294927609;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927604; Term arg = v_4294927603;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_54_)
  {
    WL_POPN(1);
    Term v_4294927610 = STK(0);
    Term v_4294927601 = r0;
    WL_OPEN
Term v_4294927600 = v_4294927610;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927601; Term arg = v_4294927600;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_54_57_57_)
  {
    WL_POPN(1);
    Term v_4294927611 = STK(0);
    Term v_4294927598 = r0;
    WL_OPEN
Term v_4294927597 = v_4294927611;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927598; Term arg = v_4294927597;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_48_55_50_54_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_55_50_54_)
  {
    Term v_4294926571 = r0;
    WL_OPEN
u64 cl_40728 = heap_alloc(e, cls_fit(1));
e.mem[cl_40728 + 0] = v_4294926571;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_48_55_50_55_, cl_40728);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_55_50_55_)
  {
    Term v_4294926571 = r0;
    Term v_4294926570 = r1;
    WL_OPEN
r0 = v_4294926571;
r1 = v_4294926570;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_)
  {
    Term v_4294926566 = r0;
    Term v_4294926565 = r1;
    WL_OPEN
Term v_4294926564 = v_4294926566;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294926563 = v_4294926565;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294926564) == CID_SNIL)) {
if ((term_aux(v_4294926563) == CID_SNIL)) {
r0 = 1ull;
WL_RETN(1);
} else {
if ((term_aux(v_4294926563) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294926563, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294926562 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294926561 = fields[1];
term_sink(e, v_4294926562);
term_sink(e, v_4294926561);
r0 = 0ull;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294926563;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_48_55_51_55_;
WL_PUSHN(2);
} else {
u64 task_40738 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_48_55_51_55_, WL_CONT, WL_IDX, 1);
e.mem[task_40738 + 0] = v_4294926563;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_48_55_51_55_, task_40738);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
Term v_4294926557 = v_4294926564;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294926556 = v_4294926563;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294926557) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294926557, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294926555 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294926554 = fields[1];
if ((term_aux(v_4294926556) == CID_SNIL)) {
term_sink(e, v_4294926555);
term_sink(e, v_4294926554);
r0 = 1ull;
WL_RETN(1);
} else {
if ((term_aux(v_4294926556) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294926556, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294926553 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294926552 = fields[1];
Term v_4294926551 = v_4294926554;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294926550 = v_4294926552;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294926548 = v_4294926555;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294926547 = v_4294926553;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294926549;
{
Term nf_local_40749[1];
if (!NF_FID_67_104_97_114_46_105_115_95_101_113_(e, seq, nf_local_40749, v_4294926548, v_4294926547)) { return 0; }
v_4294926549 = nf_local_40749[0];
}
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294926551;
r1 = v_4294926550;
r2 = v_4294926549;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_);
} else {
term_sink(e, v_4294926555);
term_sink(e, v_4294926554);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294926556;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_48_55_53_50_;
WL_PUSHN(2);
} else {
u64 task_40753 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_48_55_53_50_, WL_CONT, WL_IDX, 1);
e.mem[task_40753 + 0] = v_4294926556;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_50_, task_40753);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294926556;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_48_55_53_53_;
WL_PUSHN(2);
} else {
u64 task_40759 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_48_55_53_53_, WL_CONT, WL_IDX, 1);
e.mem[task_40759 + 0] = v_4294926556;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_53_, task_40759);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294926557;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_48_55_53_56_;
WL_PUSHN(2);
} else {
u64 task_40759 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_48_55_53_56_, WL_CONT, WL_IDX, 1);
e.mem[task_40759 + 0] = v_4294926557;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_56_, task_40759);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_55_51_55_)
  {
    WL_POPN(1);
    Term v_4294926563 = STK(0);
    Term v_4294926560 = r0;
    WL_OPEN
Term v_4294926559 = v_4294926563;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294926560; Term arg = v_4294926559;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_50_)
  {
    WL_POPN(1);
    Term v_4294926556 = STK(0);
    Term v_4294926545 = r0;
    WL_OPEN
Term v_4294926544 = v_4294926556;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294926545; Term arg = v_4294926544;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_53_)
  {
    WL_POPN(1);
    Term v_4294926556 = STK(0);
    Term v_4294926542 = r0;
    WL_OPEN
Term v_4294926541 = v_4294926556;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294926542; Term arg = v_4294926541;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_55_53_56_)
  {
    WL_POPN(1);
    Term v_4294926557 = STK(0);
    Term v_4294926539 = r0;
    WL_OPEN
Term v_4294926538 = v_4294926557;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294926539; Term arg = v_4294926538;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_54_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_54_)
  {
    Term v_4294925512 = r0;
    WL_OPEN
u64 cl_41790 = heap_alloc(e, cls_fit(1));
e.mem[cl_41790 + 0] = v_4294925512;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_55_, cl_41790);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_55_)
  {
    Term v_4294925512 = r0;
    Term v_4294925511 = r1;
    WL_OPEN
u64 cl_41789 = heap_alloc(e, cls_fit(2));
e.mem[cl_41789 + 0] = v_4294925512;
e.mem[cl_41789 + 1] = v_4294925511;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_56_, cl_41789);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_55_56_56_)
  {
    Term v_4294925512 = r0;
    Term v_4294925511 = r1;
    Term v_4294925510 = r2;
    WL_OPEN
r0 = v_4294925512;
r1 = v_4294925511;
r2 = v_4294925510;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_46_105_102_)
  {
    Term v_4294925504 = r0;
    Term v_4294925503 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294925502 = r2;
    WL_OPEN
if ((!native_bool(v_4294925502))) {
term_sink(e, v_4294925504);
term_sink(e, v_4294925503);
r0 = 0ull;
WL_RETN(1);
} else {
if (native_bool(v_4294925502)) {
Term v_4294925501 = v_4294925504;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925500 = v_4294925503;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294925501;
r1 = v_4294925500;
WL_JMP(FID_36_100_105_114_101_99_116_46_83_116_114_105_110_103_46_115_116_97_114_116_115_95_119_105_116_104_);
} else {
term_sink(e, v_4294925504);
term_sink(e, v_4294925503);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294925502;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_49_55_57_56_;
WL_PUSHN(2);
} else {
u64 task_41799 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_49_55_57_56_, WL_CONT, WL_IDX, 1);
e.mem[task_41799 + 0] = v_4294925502;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_49_55_57_56_, task_41799);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_55_57_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294925502 = STK(0);
    Term v_4294925499 = r0;
    WL_OPEN
Term v_4294925498 = v_4294925502;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294925499; Term arg = v_4294925498;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_67_104_97_114_46_105_115_95_101_113_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_50_56_50_53_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_56_50_53_)
  {
    Term v_4294924472 = r0;
    WL_OPEN
u64 cl_42827 = heap_alloc(e, cls_fit(1));
e.mem[cl_42827 + 0] = v_4294924472;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_50_56_50_54_, cl_42827);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_56_50_54_)
  {
    Term v_4294924472 = r0;
    Term v_4294924471 = r1;
    WL_OPEN
r0 = v_4294924472;
r1 = v_4294924471;
WL_JMP(FID_36_100_105_114_101_99_116_46_67_104_97_114_46_105_115_95_101_113_);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_67_104_97_114_46_105_115_95_101_113_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924467 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924466 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_67_104_97_114_46_105_115_95_101_113_(e, seq, nq_result, v_4294924467, v_4294924466)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294924465 = v_4294924467;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294924464 = v_4294924466;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294924463 = v_4294924465;
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294924462 = v_4294924464;
Term v_4294924461 = v_4294924463;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294924460 = v_4294924462;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294924461, ==, v_4294924460);
WL_RETN(1);
} else {
term_sink(e, v_4294924463);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294924464;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_50_56_51_56_;
WL_PUSHN(2);
} else {
u64 task_42839 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_50_56_51_56_, WL_CONT, WL_IDX, 1);
e.mem[task_42839 + 0] = v_4294924464;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_50_56_51_56_, task_42839);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294924464;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_50_56_52_49_;
WL_PUSHN(2);
} else {
u64 task_42845 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_50_56_52_49_, WL_CONT, WL_IDX, 1);
e.mem[task_42845 + 0] = v_4294924464;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_50_56_52_49_, task_42845);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294924465;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_50_56_52_52_;
WL_PUSHN(2);
} else {
u64 task_42845 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_50_56_52_52_, WL_CONT, WL_IDX, 1);
e.mem[task_42845 + 0] = v_4294924465;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_50_56_52_52_, task_42845);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
#endif

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_56_51_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924464 = STK(0);
    Term v_4294924459 = r0;
    WL_OPEN
Term v_4294924458 = v_4294924464;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294924459; Term arg = v_4294924458;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_56_52_49_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924464 = STK(0);
    Term v_4294924456 = r0;
    WL_OPEN
Term v_4294924455 = v_4294924464;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294924456; Term arg = v_4294924455;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_56_52_52_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924465 = STK(0);
    Term v_4294924453 = r0;
    WL_OPEN
Term v_4294924452 = v_4294924465;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294924453; Term arg = v_4294924452;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_51_56_54_57_, 0);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_51_56_54_57_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_43871 = heap_alloc(e, cls_fit(1));
e.mem[cl_43871 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_51_56_55_48_, cl_43871);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_51_56_55_48_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, ==, v_4000000001);
WL_RETN(1);

  }}
#endif

#if !DEVICE
  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294923423 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294923422 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294923423, ==, v_4294923422);
WL_RETN(1);

  }}
#endif



// A task enters through its words: a continuation's results ride r0.. and
// its parameters the stack; any other segment's parameters ride r0...
  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    Fid f   = (u32)term_aux(t);
    Loc a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    if (fid_seqk(f)) {
      u32 rw = fid_resw(f);
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    Loc l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(BEND_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    Fid f    = (Fid)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    Loc a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    if (cont != TERM_HOLE && fid_seqk((u32)term_aux(cont))) {
      Fid wf = (u32)term_aux(cont);
      Loc wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing lane skips
// a fork-free one). The host grows a row ring by ring and works a ring
// until it drains; a device lane does both.
INLINE u32 monk_step(Env e, Stk stk, Ring rg, u32 put0, bool seq, u32 base,
  u32 stride, Cur cur) {
  Corpus   H   = e.mem;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Reply r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// TG_HOLD words of threadgroup memory (lane 0's write keeps them) hold
// one group per Apple core: without them bitonic runs 1.35x, kmeans
// 1.19x, matmul 1.13x. A grow pass runs at most CUBE_T rounds, so a group
// that never fills still cuts at a kernel end.

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (Cls c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      Loc head = ALC_AT(e, c);
      Loc tail = head;
      for (u32 i = KEEP(c); --i;) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

// Pass 2, one group: each bank's [top, wr) slides onto rd, CUBE_T entries
// a step (loads, barrier, stores: rd <= top), off the host's pages.
INLINE void bank_pack(Corpus H, u32 lane) {
  for (Cls c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

// One kernel, one pipeline: pass 0 grows the frontier (a task a lane a
// turn, votes between barriers), pass 1 works it (a lane drains its
// ring), pass 2 packs the banks; one call of monk_step, so the program
// compiles once.
#ifdef __METAL_VERSION__
kernel void bend_dev(Corpus H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  threadgroup volatile u64* hold [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(Corpus H, u32 pass) {
  extern __shared__ volatile u64 hold[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  Ring rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  Stk  stk    = (Stk)(H + STAK_OFF + me);
  if (lane == 0) {
    hold[0] = 0;
  }
  GA32 tg_cur, tg_grew, tg_has;
  g32_ini(&tg_cur);
  g32_ini(&tg_grew);
  g32_ini(&tg_has);
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (u32 turn = 0; pass || turn < CUBE_T; turn += 1) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 vote = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        vote = CUBE_T;
      }
      g32_add(&tg_has, vote);
      BAR();
      u32 has = g32_get(&tg_has);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, pass, pass ? rg : row * CUBE_T,
      pass ? 0 : stride, &tg_cur);
    if (!pass) {
      if (ran == 1) {
        g32_add(&tg_grew, 1);
      }
      BARD();
      u32 grew = g32_get(&tg_grew);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// The Linux kit's fill, the Mac's window_msl in the runtime's dialect:
// a ! build carries window_dev in its cubin, a host build walks the
// pixels itself. An Image is a quadtree over 2^k x 2^k: a Qua at level
// i splits its square in four (tl, tr, bl, br), a Qua under the pixels
// follows tl, a Pix is 0xRRGGBB.
#if defined(__linux__) || defined(__CUDACC_RTC__)

INLINE u32 window_pix(Corpus H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    Loc l = term_rfc(t) ? H[term_loc(t)] >> 24 : term_loc(t);
    t = H[l + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef __CUDACC_RTC__
extern "C" __global__ void window_dev(Corpus H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static void row_grow(Env e, Stk stk, u32 base, u32 stride, u32 want) {
  Corpus H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], false, base,
        stride, &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u64   seen = 0;
  for (;;) {
    pthread_mutex_lock(&pool_lock);
    while (atomic_load_explicit(&pool_tick, memory_order_acquire) == seen) {
      pthread_cond_wait(&pool_wake, &pool_lock);
    }
    pthread_mutex_unlock(&pool_lock);
    seen = atomic_load_explicit(&pool_tick, memory_order_acquire);
    Env e = { CORPUS, ALC[1 + (u32)(uintptr_t)arg] };
    for (;;) {
      u32 r = atomic_fetch_add_explicit(&pool_row, 1, memory_order_relaxed);
      if (r >= (pool_grow ? CUBE_G : LANES / LINE)) {
        break;
      }
      if (pool_grow) {
        row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
      } else {
        for (u32 i = 0; i < LINE; i += 1) {
          Ring rg   = r * LINE + i;
          u32  put0 = a32_load(ring_put(e.mem, rg));
          while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
            monk_step(e, stk, rg, put0, true, rg, 0, NULL);
          }
        }
      }
    }
    u32 done = atomic_fetch_add_explicit(&pool_done, 1, memory_order_release);
    if (done + 1 == pool_size) {
      pthread_mutex_lock(&pool_lock);
      pthread_cond_broadcast(&pool_wake);
      pthread_mutex_unlock(&pool_lock);
    }
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 0; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

// The CPUs this process may use: affinity mask under the cgroup quota
static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  int   n = f == NULL ? 0 : fscanf(f, "%ld %ld", a, b);
  if (f != NULL) {
    fclose(f);
  }
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow) {
  pool_grow = grow;
  atomic_store_explicit(&pool_row, 0, memory_order_relaxed);
  atomic_store_explicit(&pool_done, 0, memory_order_relaxed);
  pthread_mutex_lock(&pool_lock);
  atomic_fetch_add_explicit(&pool_tick, 1, memory_order_release);
  pthread_cond_broadcast(&pool_wake);
  while (atomic_load_explicit(&pool_done, memory_order_acquire) < pool_size) {
    pthread_cond_wait(&pool_wake, &pool_lock);
  }
  pthread_mutex_unlock(&pool_lock);
}

// Gpu
// ===

// gpu_make compiles the device program and, given a path, writes it as
// <binary>.gpu (--gpu-build, run by bend -o): Metal's binary archive
// of the pipeline (keyed by the compiled function, so a wrong file
// misses), CUDA's cubin behind a hash of the text. A launch loads it,
// else notes and compiles (Metal's OS cache keeps that pipeline; CUDA
// writes the file).

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_METAL

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    err_fail([[err localizedDescription] UTF8String]);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    err_fail([[err localizedDescription] UTF8String]);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    err_fail([[err localizedDescription] UTF8String]);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      err_fail([[[cb error] localizedDescription] UTF8String]);
    }
  }
}

#elif BEND_CUDA

// the bag from the device: a group of 128 lanes per 64 KB of L2, a power of
// two from 16 to 128 groups. Apple keeps the 128 the bag was tuned on: on an
// M4 (10 cores) 32 groups ran bitonic 1.85 -> 1.29 s, but the light one-pass
// benches 1.25x, their lanes four times fewer.
static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  // one stream, so one hardware queue: the default 8 each cost a channel
  // at context creation and teardown, about half of the startup
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static Corpus gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (Corpus)(uintptr_t)p;
}

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

static void cube_run(Corpus H, bool gpu) {
  for (;;) {
    u32 f = a32_load(a32_at(H, H_CURSOR));
    a32_store(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      // Each worker needs a row; a row has CUBE_T / LINE units.
      if (f < pool_size) {
        row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, pool_size);
      }
      if (f < CUBE) {
        pool_turn(true);
      }
      pool_turn(false);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, a hint then
// a check (MAP_FIXED would replace a neighbour), so one base holds every
// Loc and a run pays for the room it reaches. The banks lie past the pages
// and move up at each step. The GPU maps its whole span once.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(Corpus H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(Corpus H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static Corpus corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  Corpus H   = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  corpus_lay(H, size);
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(Corpus H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Reply r = work_loop(e, io_stk, t, !BANGS
      && (pool_size == 1 || fid_nofk((u32)term_aux(t))));
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        Loc  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, (Cur)0);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

// A handle is its host value, a descriptor or a pointer, packed in one
// word (a pointer split over the aux and loc bits). Its type is a law of
// base, opaque and linear: a program cannot forge, copy or reuse one, so
// nothing stands between the value and the host.
#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

// IoWork ::=
//   | IoWork(hand, made, word, size, data, text, code, call, pack)
typedef struct IoWork {
  intptr_t hand;
  intptr_t made;
  u32      word;
  u64      size;
  char*    data;
  char*    text;
  u32      code;
  IoCall   call;
  IoPack   pack;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

// IoEff ::=
//   | IoEff(run, ask)
typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    bool zero = *p == '0' && p[1] >= '0' && p[1] <= '9';
    if ((p == host || p[-1] == '.') && zero) {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

// The program's arguments (IO.args).
static int    io_argc = 0;
static char** io_argv = NULL;

static void io_eff(u32 cid, Effect run, u32 need) {
  IoEff row = { run, need };
  io_eff_rows[cid] = row;
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

// A computation's activation for its whole life: cont over item is its
// next request; parked, work.word and time are its fd and deadline, evts
// what the fd must be ready for, and work.pack resumes it (io_exec runs
// cont, the request); work leads, so an effect's IoWork* is its activation.
// IoAct ::=
//   | IoAct(work, cont, item, time, evts, next)
typedef struct IoAct {
  IoWork        work;
  Term          cont;
  Term          item;
  u64           time;
  short         evts;
  struct IoAct* next;
} IoAct;

// IoQue ::=
//   | IoQue(head, last)
typedef struct {
  IoAct* head;
  IoAct* last;
} IoQue;

static IoQue io_runs;
static IoQue io_park;
static IoQue io_jobs;

static void io_push(IoQue* q, IoAct* a) {
  a->next = NULL;
  *(q->head == NULL ? &q->head : &q->last->next) = a;
  q->last = a;
}

static IoAct* io_pop(IoQue* q) {
  IoAct* a = q->head;
  q->head  = a->next;
  return a;
}

static void io_spawn(Term m) {
  IoAct* a = io_mem(calloc(1, sizeof(IoAct)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// Parks the effect's activation until fd is ready for evts (POLLIN or
// POLLOUT; 0 for no fd), or until time (a tick; 0 for no deadline),
// whichever comes first; the loop then calls more on its thread, whose
// value readies the activation, or IO_PARK, a re-park.
static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  IoAct* a     = (IoAct*)w;
  a->work.word = (u32)fd;
  a->work.pack = more;
  a->time      = time;
  a->evts      = evts;
  io_push(&io_park, a);
  return IO_PARK;
}

// the deadline a parked activation waits for (0 for none)
static u64 io_wait_time(IoWork* w) {
  return ((IoAct*)w)->time;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

// the edge is UTF-8
static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  Loc l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

// Bytes cross the IO boundary without UTF-8 decoding.
static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

// io_str decodes UTF-8 as WHATWG does: the lead byte sets the count of
// continuation bytes and the range of the second; a byte that breaks the
// sequence (or the end) yields one U+FFFD and is read again as a lead.
static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  Loc  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    Loc  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)

static Term io_box(Env e, u64 cid, Term v) {
  Loc l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_err(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  return io_tup(e, code, io_str(e, s, strlen(s)));
}

static Term io_fail(Env e, u32 code, const char* text) {
  return io_box(e, CID_FAIL, io_err(e, code, text));
}

static lock           io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t io_bell = PTHREAD_COND_INITIALIZER;
static u32            io_busy;
static u32            io_size;
static int            io_wake_fd[2];

static void io_take(Env e) {
  IoAct*  acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoAct*); i += 1) {
      IoAct* a = acts[i];
      a->item  = a->work.pack(e, &a->work);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs.head == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoAct* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->work.call(&a->work);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

// A helper takes the effect's activation: call on its thread, then pack
// on the loop's, whose value readies the activation.
static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, (IoAct*)w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

// Runs the request in cont: the effect takes its fields (the node goes)
// and answers a value, which readies the activation, or IO_PARK, a moved.
static Term io_exec(Env e, IoWork* w) {
  IoAct* a = (IoAct*)w;
  Term   fs[256];
  u32    c = (u32)term_aux(a->cont);
  u32    n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, a->cont, n, fs));
  a->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static void io_wait(Env e) {
  struct pollfd* fds = io_mem(malloc((io_live + 1) * sizeof *fds));
  u32 n    = 1;
  u64 soon = 0;
  int ms   = -1;
  fds[0].fd     = io_wake_fd[0];
  fds[0].events = POLLIN;
  for (IoAct* a = io_park.head; a != NULL; a = a->next) {
    if (a->time != 0) {
      soon = soon == 0 || a->time < soon ? a->time : soon;
    }
    if (a->evts != 0) {
      fds[n].fd     = (int)a->work.word;
      fds[n].events = a->evts;
      n += 1;
    }
  }
  if (soon != 0) {
    u64 now = io_tick();
    u64 gap = soon > now ? (soon - now) / 1000000 + 1 : 0;
    ms = gap > 0x7fffffff ? 0x7fffffff : (int)gap;
  }
  io_sync();
  while (poll(fds, n, ms) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
  }
  if (fds[0].revents != 0) {
    io_take(e);
  }
  u64   now  = io_tick();
  u32   i    = 1;
  IoQue todo = io_park;
  io_park.head = NULL;
  io_park.last = NULL;
  while (todo.head != NULL) {
    IoAct* a   = io_pop(&todo);
    bool   due = (a->evts != 0 && fds[i].revents != 0)
      || (a->time != 0 && a->time <= now);
    i += a->evts != 0;
    if (!due) {
      io_push(&io_park, a);
      continue;
    }
    Term x = a->work.pack(e, &a->work);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(fds);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}

// Show
// ====

#if MAIN_PURE

// A pure main's value, spelled as term_show spells it: d is a node of
// SHOW_DESC (see show_main), w the value's words. A boxed Data reads its
// arm by cid off a Term (packed, or a node), an inline one by tag off
// its words.
static void show_val(Env e, u32 d, const Term* w, char chain);

// char_show: an escape, a \u{hex}, else the code point in UTF-8
static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

// The shortest text that reads back, as a literal: a point before an e
static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_arr(Env e, u32 d, Term t, u32 lo, u32 c) {
  if (c > SHOW_DESC[d + 2]) {
    c -= 1;
    show_arr(e, d, t, lo, c);
    fputs(", ", stdout);
    show_arr(e, d, t, lo + (1u << c), c);
  } else {
    Term v[1u << c];
    for (u32 j = 0; j < 1u << c; j += 1) {
      v[j] = blk_read(e.mem, term_tag(t) == TAG_ARR, term_peek(e, t), lo + j);
    }
    show_val(e, SHOW_DESC[d + 1], v, 0);
  }
}

// chain is the bracket of the [a, b] or (a, b) this value continues, or
// 0: a Con or Nil spells a list, a Tuple a tuple, their tails continue
static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0: printf("%u", (u32)w[0]); break;
    case 1: show_f32((u32)w[0]); break;
    case 2: printf("%llun", (unsigned long long)w[0]); break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        Loc l = term_peek(e, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5: fputs("{==}", stdout); break;
    case 6:
      putchar('[');
      show_arr(e, d, w[0], 0, blk_cls(w[0]));
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 3 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e, t);
      }
      const char* k = SHOW_NAMES[D[a]];
      char o = '{';
      char z = '}';
      if (strcmp(k, "Con") == 0 || strcmp(k, "Nil") == 0) {
        o = '[';
        z = ']';
      } else if (strcmp(k, "Tuple") == 0) {
        o = '(';
        z = ')';
      }
      if (o == '{') {
        printf("%s{", k);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = z;
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 4 + 2 * j];
          w     = w + D[a + 3 + 2 * j];
        } else {
          show_val(e, D[a + 4 + 2 * j], w + D[a + 3 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Current Base additions not yet implemented by this retained scheduler.
// Refuse on actual dispatch, before consuming any payload.
static const char* io_unavailable(u32 cid) {
  switch (cid) {
#ifdef CID_CHAN_TRY_SEND
    case CID_CHAN_TRY_SEND: return "native Chan.try_send is not implemented by the retained IO runtime";
#endif
#ifdef CID_CHAN_TRY_RECV
    case CID_CHAN_TRY_RECV: return "native Chan.try_recv is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_ACCEPT
    case CID_TCP_TRY_ACCEPT: return "native TCP.try_accept is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_SEND
    case CID_TCP_TRY_SEND: return "native TCP.try_send is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_SEND_BYTES
    case CID_TCP_TRY_SEND_BYTES: return "native TCP.try_send_bytes is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_RECV
    case CID_TCP_TRY_RECV: return "native TCP.try_recv is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_RECV_BYTES
    case CID_TCP_TRY_RECV_BYTES: return "native TCP.try_recv_bytes is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_SEND_TO
    case CID_UDP_TRY_SEND_TO: return "native UDP.try_send_to is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_SEND_BYTES_TO
    case CID_UDP_TRY_SEND_BYTES_TO: return "native UDP.try_send_bytes_to is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_RECV_FROM
    case CID_UDP_TRY_RECV_FROM: return "native UDP.try_recv_from is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_RECV_BYTES_FROM
    case CID_UDP_TRY_RECV_BYTES_FROM: return "native UDP.try_recv_bytes_from is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_SEND_BYTES_TO
    case CID_UDP_SEND_BYTES_TO: return "native UDP.send_bytes_to is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_RECV_BYTES_FROM
    case CID_UDP_RECV_BYTES_FROM: return "native UDP.recv_bytes_from is not implemented by the retained IO runtime";
#endif
    default: return "an alien request";
  }
}

// The continuation applied to the item is the next request.
static int io_step(Env e, IoAct* a) {
  // Yield only after a completed effect: the activation owns its next item.
  u64 deadline = io_tick() + 4000000ull;
  for (;;) {
    Loc  ap  = task_node(e, BEND_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(BEND_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    Loc  at  = term_peek(e, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return -1;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      return (int)(u32)e.mem[at];
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail(io_unavailable(c));
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(&a->work, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return -1;
    }
    Term x = io_exec(e, &a->work);
    if (x == IO_PARK) {
      return -1;
    }
    a->item = x;
    if (io_tick() >= deadline) {
      io_push(&io_runs, a);
      return -1;
    }
  }
}

OUTLINE int io_loop(Corpus H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return 0;
#endif
  io_spawn(m);
  for (u32 n = 0;; n += 1) {
    if (io_runs.head == NULL) {
      if (io_live == 0) {
        return 0;
      }
      if (io_park.head == NULL && io_busy == 0) {
        io_sync();
        fprintf(stderr, "bend: deadlock: every computation waits on a"
          " channel\n");
        return 1;
      }
      io_wait(e);
      continue;
    }
    if (io_busy != 0) {
      io_take(e);
    }
    int code = io_step(e, io_pop(&io_runs));
    if (code >= 0) {
      return code;
    }
  }
}

// Chan
// ====

// ChanRow ::=
//   | ChanRow(gen, next, room, size, head, live, shut, ring, wait)
typedef struct {
  u32   gen;
  u32   next;
  u32   room;
  u32   size;
  u32   head;
  u32   live;
  u32   shut;
  Term* ring;
  IoQue wait;
} ChanRow;

// A channel is Data: its handle is copied and may outlive the row, so it
// names the row by index and generation, a freed row waits on a list and
// comes back one generation up, and a stale copy finds no row (closed).
static ChanRow* chan_rows;
static u32      chan_len;
static u32      chan_idle = ~0u;

#define chan_some(e, v) io_box(e, CID_SOME, v)
#define chan_done(e)    io_done(e, term_pak(CID_UNIT, 0))

static Term chan_open(u32 room) {
  u32 i = chan_idle;
  if (i != ~0u) {
    chan_idle = chan_rows[i].next;
  } else {
    if (chan_len == 1u << 24) {
      err_fail("more than 16777216 channels at once");
    }
    if ((chan_len & (chan_len - 1)) == 0) {
      chan_rows = io_mem(realloc(chan_rows,
        (chan_len == 0 ? 1 : 2 * chan_len) * sizeof(ChanRow)));
    }
    i = chan_len;
    chan_len += 1;
    chan_rows[i].gen = 0;
  }
  ChanRow* row = &chan_rows[i];
  row->gen  += 1;
  row->room  = room;
  row->size  = 0;
  row->head  = 0;
  row->live  = 1;
  row->shut  = 0;
  row->ring  = room == 0 ? NULL : io_mem(malloc(room * sizeof(Term)));
  row->wait.head = NULL;
  row->wait.last = NULL;
  return io_hand(((u64)row->gen << 24) | i);
}

static ChanRow* chan_at(Term t) {
  u64      v   = io_hand_v(t);
  u32      i   = (u32)v & 0xFFFFFF;
  ChanRow* row = i < chan_len ? &chan_rows[i] : NULL;
  return row != NULL && row->live && row->gen == (u32)(v >> 24) ? row : NULL;
}

// Parks the effect's activation on row with item: a sent value, or
// TERM_HOLE for a receiver.
static Term chan_park(ChanRow* row, IoWork* w, Term item) {
  IoAct* a = (IoAct*)w;
  a->item  = item;
  io_push(&row->wait, a);
  return IO_PARK;
}

static Term chan_wake(ChanRow* row, Term x) {
  IoAct* a  = io_pop(&row->wait);
  Term item = a->item;
  a->item   = x;
  io_push(&io_runs, a);
  return item;
}

static Term chan_take(Env e, ChanRow* row) {
  Term v = row->ring[row->head];
  row->head = (row->head + 1) % row->room;
  row->size -= 1;
  if (row->wait.head != NULL) {
    Term item = chan_wake(row, chan_done(e));
    row->ring[(row->head + row->size) % row->room] = item;
    row->size += 1;
  }
  return v;
}

static void chan_free(ChanRow* row) {
  free(row->ring);
  row->live = 0;
  row->next = chan_idle;
  chan_idle = (u32)(row - chan_rows);
}

static void chan_shut(Env e, ChanRow* row) {
  row->shut = 1;
  while (row->wait.head != NULL) {
    Term item = row->wait.head->item;
    Term x = item == TERM_HOLE ? term_pak(CID_NONE, 0)
      : io_box(e, CID_FAIL, item);
    chan_wake(row, x);
  }
  if (row->size == 0) {
    chan_free(row);
  }
}

// Foreign C ABI: current helpers coexist with the retained runtime's API.
// This section is host-only; device code and prior runtime calls keep their
// original Env-based helper. Only mem is read by term_peek/rfc_view.
INLINE Loc term_peek_corpus(Corpus H, Term t) {
  Env e = { H, NULL };
  return term_peek(e, t);
}
#define term_peek(H, t) _Generic((H), Env: term_peek, default: term_peek_corpus)((H), (t))
// This runtime permits shared blocks, so always follow its redirect cell.
#define blk_loc(H, t) term_peek((H), (t))

// New foreign sources register immediate effects with two arguments; the
// third argument is retained for existing vendored readiness/timer effects.
static void io_eff_default(u32 cid, Effect run) {
  io_eff(cid, run, 0);
}
#define BEND_IO_EFF_PICK(_1, _2, _3, F, ...) F
#define io_eff(...) BEND_IO_EFF_PICK(__VA_ARGS__, io_eff, io_eff_default, 0)(__VA_ARGS__)

// Requests
// ========

#pragma push_macro("CID_CLIERROR")
#define CID_CLIERROR CID__CTOR_67_76_73_69_114_114_111_114_
#pragma push_macro("CID_CLIHELP")
#define CID_CLIHELP CID__CTOR_67_76_73_72_101_108_112_
#pragma push_macro("CID_CLIVERSION")
#define CID_CLIVERSION CID__CTOR_67_76_73_86_101_114_115_105_111_110_
#pragma push_macro("CID_CLIREQUEST")
#define CID_CLIREQUEST CID__CTOR_67_76_73_82_101_113_117_101_115_116_
// Linux host effects. Compiler policy and expected asset identities stay in Bend.
// read/path: Result<U32 & String, String>; publish: Result<U32 & String, Unit>.
// io_cstr consumes arguments; only the IO loop touches Bend values. Helpers own
// malloc buffers until pack. Read rejects invalid UTF-8 so io_str is lossless.
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  char *path, *hash, *data;
  uint64_t size;
  uint32_t limit;
  const char *error;
} NativeHostWork;

static uint32_t nh_rotr(uint32_t x, unsigned n) {
  return (x >> n) | (x << (32 - n));
}

static void nh_sha_block(uint32_t h[8], const unsigned char *p) {
  static const uint32_t k[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  };
  uint32_t s[64];
  for (unsigned i = 0; i < 16; ++i)
    s[i] = (uint32_t)p[4*i]<<24 | (uint32_t)p[4*i+1]<<16 |
           (uint32_t)p[4*i+2]<<8 | p[4*i+3];
  for (unsigned i = 16; i < 64; ++i) {
    uint32_t x = s[i-15], y = s[i-2];
    s[i] = s[i-16] + (nh_rotr(x,7)^nh_rotr(x,18)^(x>>3)) + s[i-7] +
           (nh_rotr(y,17)^nh_rotr(y,19)^(y>>10));
  }
  uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],v=h[7];
  for (unsigned i = 0; i < 64; ++i) {
    uint32_t t = v + (nh_rotr(e,6)^nh_rotr(e,11)^nh_rotr(e,25)) +
                 ((e&f)^(~e&g)) + k[i] + s[i];
    uint32_t u = (nh_rotr(a,2)^nh_rotr(a,13)^nh_rotr(a,22)) + ((a&b)^(a&c)^(b&c));
    v=g; g=f; f=e; e=d+t; d=c; c=b; b=a; a=t+u;
  }
  h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=v;
}

static void nh_sha256(const char *data, size_t size, char out[65]) {
  uint32_t h[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                   0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
  size_t full = size & ~(size_t)63, rest = size - full;
  for (size_t i = 0; i < full; i += 64) nh_sha_block(h, (const unsigned char *)data+i);
  unsigned char tail[128] = {0};
  memcpy(tail, data+full, rest); tail[rest] = 0x80;
  size_t width = rest < 56 ? 64 : 128;
  uint64_t bits = (uint64_t)size * 8;
  for (unsigned i = 0; i < 8; ++i) tail[width-1-i] = (unsigned char)(bits >> (8*i));
  nh_sha_block(h, tail);
  if (width == 128) nh_sha_block(h, tail+64);
  static const char hex[] = "0123456789abcdef";
  for (unsigned i = 0; i < 64; ++i) out[i] = hex[(h[i/8] >> (28-4*(i%8))) & 15];
  out[64] = 0;
}

static int nh_utf8(const char *text, size_t size) {
  unsigned need=0, lo=0x80, hi=0xbf;
  for (size_t i=0; i<size; ++i) {
    unsigned b=(unsigned char)text[i];
    if (need) { if (b<lo || b>hi) return 0; --need; lo=0x80; hi=0xbf; }
    else if (b>=0x80) {
      if (b<0xc2 || b>0xf4) return 0;
      need=b<0xe0 ? 1 : b<0xf0 ? 2 : 3;
      lo=b==0xe0 ? 0xa0 : b==0xf0 ? 0x90 : 0x80;
      hi=b==0xed ? 0x9f : b==0xf4 ? 0x8f : 0xbf;
    }
  }
  return need==0;
}

static Term nh_pack(Env e, IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  Term result=w->code ? io_fail(e,w->code,x->error) :
    io_done(e,w->word==2 ? term_pak(CID_UNIT,0) : io_str(e,x->data,x->size));
  free(x->path); free(x->hash); free(x->data); free(x);
  return result;
}

static NativeHostWork *nh_begin(Env e, Term path, IoWork *w, uint32_t op) {
  NativeHostWork *x=io_mem(calloc(1,sizeof *x));
  uint64_t size=0;
  x->path=io_cstr(e,path,&size);
  w->data=(char *)x; w->word=op; w->code=io_nul(x->path,size) ? EILSEQ : 0;
  return x;
}

static void nh_read_call(IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  int fd=open(x->path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_NONBLOCK);
  if (fd<0) { w->code=errno; return; }
  struct stat before,after;
  if (fstat(fd,&before)<0) w->code=errno;
  else if (!S_ISREG(before.st_mode)) w->code=EINVAL;
  else if (before.st_size<0 || (uint64_t)before.st_size>x->limit ||
           (uint64_t)before.st_size>=SIZE_MAX) w->code=EFBIG;
  if (!w->code) {
    size_t size=(size_t)before.st_size, at=0;
    x->data=malloc(size+1);
    if (!x->data) w->code=ENOMEM;
    while (!w->code && at<size) {
      size_t count=size-at; if (count>1048576) count=1048576;
      ssize_t n=read(fd,x->data+at,count);
      if (n<0 && errno==EINTR) continue;
      if (n<=0) w->code=n<0 ? errno : EIO; else at+=(size_t)n;
    }
    if (!w->code) {
      char extra; ssize_t n;
      do { n=read(fd,&extra,1); } while (n<0 && errno==EINTR);
      if (n!=0) w->code=n<0 ? errno : EFBIG;
      else if (fstat(fd,&after)<0) w->code=errno;
      else if (before.st_size!=after.st_size ||
        before.st_mtim.tv_sec!=after.st_mtim.tv_sec || before.st_mtim.tv_nsec!=after.st_mtim.tv_nsec ||
        before.st_ctim.tv_sec!=after.st_ctim.tv_sec || before.st_ctim.tv_nsec!=after.st_ctim.tv_nsec) w->code=ESTALE;
      x->size=size; x->data[size]=0;
    }
  }
  if (close(fd)<0 && !w->code) w->code=errno; // Do not retry close on Linux.
  if (!w->code && x->hash[0]) {
    char actual[65]; nh_sha256(x->data,(size_t)x->size,actual);
    if (memcmp(actual,x->hash,64)) { w->code=EBADMSG; x->error="SHA-256 mismatch"; }
  }
  if (!w->code && !nh_utf8(x->data,(size_t)x->size)) w->code=EILSEQ;
}

Term native_host_read_run(Env e, Term *f, IoWork *w) {
  NativeHostWork *x=nh_begin(e,f[0],w,0);
  uint64_t n=0; x->hash=io_cstr(e,f[1],&n); x->limit=(uint32_t)f[2];
  if (n!=0 && n!=64) w->code=EINVAL;
  for (uint64_t i=0; i<n && !w->code; ++i)
    if (!((x->hash[i]>='0' && x->hash[i]<='9') || (x->hash[i]>='a' && x->hash[i]<='f'))) w->code=EINVAL;
  return w->code ? nh_pack(e,w) : io_work(w,nh_read_call,nh_pack);
}

static void nh_path_call(IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  if (x->path[0]) x->data=realpath(x->path,NULL);
  else {
    x->data=malloc(PATH_MAX+1);
    if (!x->data) { w->code=ENOMEM; return; }
    ssize_t n=readlink("/proc/self/exe",x->data,PATH_MAX);
    if (n<0) { w->code=errno; return; }
    if (n==PATH_MAX) { w->code=ENAMETOOLONG; return; }
    x->data[n]=0;
    char *slash=strrchr(x->data,'/');
    if (!slash) { w->code=EINVAL; return; }
    slash[slash==x->data ? 1 : 0]=0;
  }
  if (!x->data) { w->code=errno; return; }
  x->size=strlen(x->data);
  if (!nh_utf8(x->data,(size_t)x->size)) w->code=EILSEQ;
}

Term native_host_path_run(Env e, Term *f, IoWork *w) {
  nh_begin(e,f[0],w,1);
  return w->code ? nh_pack(e,w) : io_work(w,nh_path_call,nh_pack);
}

static void nh_publish_call(IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  char *slash=strrchr(x->path,'/'), *name=slash ? slash+1 : x->path;
  if (!*name) { w->code=EINVAL; return; }
  const char *dir=".";
  if (slash) { *slash=0; dir=slash==x->path ? "/" : x->path; }
  int parent=open(dir,O_RDONLY|O_DIRECTORY|O_CLOEXEC);
  if (parent<0) { w->code=errno; return; }
  int fd=-1; char temp[64]={0};
  for (unsigned attempt=0; attempt<64; ++attempt) {
    uint64_t random; size_t at=0;
    while (at<sizeof random) {
      ssize_t n=getrandom((char *)&random+at,sizeof random-at,0);
      if (n<0 && errno==EINTR) continue;
      if (n<=0) { w->code=n<0 ? errno : EIO; break; } at+=(size_t)n;
    }
    if (w->code) break;
    snprintf(temp,sizeof temp,".bend-native-%ld-%016llx",(long)getpid(),(unsigned long long)random);
    if (strcmp(temp,name)==0) continue;
    fd=openat(parent,temp,O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC,0600);
    if (fd>=0) break;
    if (errno!=EEXIST) { w->code=errno; break; }
  }
  if (fd<0) { if (!w->code) w->code=EEXIST; close(parent); return; }
  struct stat made;
  int known=fstat(fd,&made)==0;
  if (!known) w->code=errno;
  for (uint64_t at=0; !w->code && at<x->size;) {
    size_t count=(size_t)(x->size-at); if (count>1048576) count=1048576;
    ssize_t n=write(fd,x->data+at,count);
    if (n<0 && errno==EINTR) continue;
    if (n<=0) w->code=n<0 ? errno : EIO; else at+=(uint64_t)n;
  }
  if (!w->code && fsync(fd)<0) w->code=errno;
  // Keep the inode, not its mutable directory entry, through writer close.
  char proc[64]; int held=-1, published=0;
  if (!w->code) {
    snprintf(proc,sizeof proc,"/proc/self/fd/%d",fd);
    held=open(proc,O_PATH|O_CLOEXEC);
    if (held<0) w->code=errno;
  }
  if (close(fd)<0 && !w->code) w->code=errno;
  if (!w->code) {
    snprintf(proc,sizeof proc,"/proc/self/fd/%d",held);
    if (linkat(AT_FDCWD,proc,parent,name,AT_SYMLINK_FOLLOW)<0) w->code=errno;
    else published=1;
  }
  if (held>=0 && close(held)<0 && !w->code) w->code=errno;
  struct stat current;
  int cleanup=0;
  if (fstatat(parent,temp,&current,AT_SYMLINK_NOFOLLOW)<0) {
    if (errno!=ENOENT) cleanup=errno;
  } else if (!known || current.st_dev!=made.st_dev || current.st_ino!=made.st_ino) cleanup=ESTALE;
  else if (unlinkat(parent,temp,0)<0) cleanup=errno;
  if (!w->code) w->code=cleanup;
  if (close(parent)<0 && !w->code) w->code=errno;
  if (published && w->code) x->error="output published; temporary cleanup failed";
}

Term native_host_publish_run(Env e, Term *f, IoWork *w) {
  NativeHostWork *x=nh_begin(e,f[0],w,2);
  x->data=io_cstr(e,f[1],&x->size);
  if (x->size>67108864) w->code=EFBIG;
  return w->code ? nh_pack(e,w) : io_work(w,nh_publish_call,nh_pack);
}

static void __attribute__((constructor)) native_host_use(void) {
  io_eff(CID_NATIVEHOST_READ,native_host_read_run);
  io_eff(CID_NATIVEHOST_PATH,native_host_path_run);
  io_eff(CID_NATIVEHOST_PUBLISH,native_host_publish_run);
}

#pragma pop_macro("CID_CLIERROR")
#pragma pop_macro("CID_CLIHELP")
#pragma pop_macro("CID_CLIVERSION")
#pragma pop_macro("CID_CLIREQUEST")

// IO
// ==

void io_print(const char* data, uint64_t len) {
  io_out(stdout, data, len);
  io_out(stdout, "\n", 1);
}

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_print(text, n);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}

// IO
// ==

Term io_args_run(Env e, Term* f, IoWork* w) {
  Term xs = term_pak(CID_NIL, 0);
  for (int i = io_argc; i > 0; i -= 1) {
    const char* a = io_argv[i - 1];
    xs = io_node(e, CID_CON, io_str(e, a, strlen(a)), xs);
  }
  return xs;
}

static void __attribute__((constructor)) io_args_use(void) {
  io_eff(CID_IO_ARGS, io_args_run, 0);
}


// Cli
// ===

static void cli_fail(const char* msg, const char* arg) {
  fprintf(stderr, "bend: %s%s\n", msg, arg != NULL ? arg : "");
  exit(1);
}

// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv + 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        cli_fail("cannot write ", gpu_path());
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || end == NULL || *end != '\0') {
        cli_fail("expected a thread count of 1 or more after --threads", NULL);
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        cli_fail("expected on, off or a size like 4GB after --gpu", NULL);
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    cli_fail("--gpu on, but this binary found no GPU device", NULL);
  }
  Corpus H  = corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem);
  int code  = io_loop(H);
  io_sync();
  return code;
}

#endif
