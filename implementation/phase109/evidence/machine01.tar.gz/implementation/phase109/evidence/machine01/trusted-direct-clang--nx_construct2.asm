
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c80 <nx_construct2>:
  401c80:	push   %r12
  401c82:	mov    %rcx,%rax
  401c85:	push   %rbp
  401c86:	shr    $0x38,%rax
  401c8a:	lea    0x0(,%r9,8),%rbp
  401c92:	push   %rbx
  401c93:	and    $0x7f,%eax
  401c96:	mov    %edx,%ebx
  401c98:	lea    (%rdi,%rbp,1),%r12
  401c9c:	mov    %rcx,%rdx
  401c9f:	sub    $0x20,%rsp
  401ca3:	cmp    $0x2,%rax
  401ca7:	je     401ce0 <nx_construct2+0x60>
  401ca9:	mov    %r8,%rax
  401cac:	mov    %rdx,(%r12)
  401cb0:	lea    0x8(%rbp,%rdi,1),%rbp
  401cb5:	shr    $0x38,%rax
  401cb9:	and    $0x7f,%eax
  401cbc:	cmp    $0x2,%rax
  401cc0:	je     401cf0 <nx_construct2+0x70>
  401cc2:	mov    %rbx,%rax
  401cc5:	mov    %r8,0x0(%rbp)
  401cc9:	add    $0x20,%rsp
  401ccd:	shl    $0x28,%rax
  401cd1:	pop    %rbx
  401cd2:	pop    %rbp
  401cd3:	or     %r9,%rax
  401cd6:	pop    %r12
  401cd8:	bts    $0x39,%rax
  401cdd:	retq   
  401cde:	xchg   %ax,%ax
  401ce0:	test   %rcx,%rcx
  401ce3:	js     401ca9 <nx_construct2+0x29>
  401ce5:	jmpq   401410 <nx_construct2.cold>
  401cea:	nopw   0x0(%rax,%rax,1)
  401cf0:	test   %r8,%r8
  401cf3:	js     401cc2 <nx_construct2+0x42>
  401cf5:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
