000000000041dad0 <p125_rt_ctor2>:
  41dad0:	push   r15
  41dad2:	push   r14
  41dad4:	push   r13
  41dad6:	mov    r13,rdx
  41dad9:	push   r12
  41dadb:	push   rbp
  41dadc:	push   rbx
  41dadd:	mov    ebx,esi
  41dadf:	sub    rsp,0x8
  41dae3:	mov    r12,QWORD PTR [rdi+0x8]
  41dae7:	mov    r14,QWORD PTR [rdi]
  41daea:	mov    rbp,QWORD PTR [r12+0x8]
  41daef:	test   rbp,rbp
  41daf2:	je     40501c <p125_rt_ctor2.cold+0x30>
  41daf8:	lea    rcx,[r14+rbp*8]
  41dafc:	mov    rax,QWORD PTR [rcx]
  41daff:	sub    QWORD PTR [r12+0x108],0x2
  41db08:	mov    QWORD PTR [r12+0x8],rax
  41db0d:	mov    rax,QWORD PTR [rip+0x108fbc]        # 526ad0 <p111_program_active>
  41db14:	mov    rdx,QWORD PTR [r13+0x0]
  41db18:	test   BYTE PTR [rax+0x58],0x8
  41db1c:	je     41db40 <p125_rt_ctor2+0x70>
  41db1e:	mov    rax,QWORD PTR [rax+0x88]
  41db25:	cmp    BYTE PTR [rax+rbx*1],0x0
  41db29:	jne    41db40 <p125_rt_ctor2+0x70>
  41db2b:	mov    QWORD PTR [rcx],rdx
  41db2e:	mov    rax,QWORD PTR [r13+0x8]
  41db32:	mov    QWORD PTR [r14+rbp*8+0x8],rax
  41db37:	jmp    41db74 <p125_rt_ctor2+0xa4>
  41db39:	nop    DWORD PTR [rax+0x0]
  41db40:	mov    rax,rdx
  41db43:	lea    r15,[r14+rbp*8]
  41db47:	shr    rax,0x38
  41db4b:	and    eax,0x7f
  41db4e:	cmp    rax,0x2
  41db52:	je     41dba8 <p125_rt_ctor2+0xd8>
  41db54:	mov    QWORD PTR [r15],rdx
  41db57:	mov    rdx,QWORD PTR [r13+0x8]
  41db5b:	lea    r13,[r14+rbp*8+0x8]
  41db60:	mov    rax,rdx
  41db63:	shr    rax,0x38
  41db67:	and    eax,0x7f
  41db6a:	cmp    rax,0x2
  41db6e:	je     41db98 <p125_rt_ctor2+0xc8>
  41db70:	mov    QWORD PTR [r13+0x0],rdx
  41db74:	mov    rax,rbx
  41db77:	add    rsp,0x8
  41db7b:	shl    rax,0x28
  41db7f:	pop    rbx
  41db80:	or     rax,rbp
  41db83:	pop    rbp
  41db84:	pop    r12
  41db86:	bts    rax,0x39
  41db8b:	pop    r13
  41db8d:	pop    r14
  41db8f:	pop    r15
  41db91:	ret    
  41db92:	nop    WORD PTR [rax+rax*1+0x0]
  41db98:	test   rdx,rdx
  41db9b:	js     41db70 <p125_rt_ctor2+0xa0>
  41db9d:	jmp    404fec <p125_rt_ctor2.cold>
  41dba2:	nop    WORD PTR [rax+rax*1+0x0]
  41dba8:	test   rdx,rdx
  41dbab:	js     41db54 <p125_rt_ctor2+0x84>
  41dbad:	jmp    405004 <p125_rt_ctor2.cold+0x18>
  41dbb2:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  41dbbd:	nop    DWORD PTR [rax]

