
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e10 <nx_list_reverse>:
  401e10:	push   %rbp
  401e11:	push   %r15
  401e13:	push   %r14
  401e15:	push   %r13
  401e17:	push   %r12
  401e19:	push   %rbx
  401e1a:	sub    $0x18,%rsp
  401e1e:	mov    %rdx,%rbp
  401e21:	mov    %rsi,%r12
  401e24:	mov    %rdi,%rbx
  401e27:	callq  404500 <nx_rt_ir_heap>
  401e2c:	mov    %rax,%r15
  401e2f:	mov    %rbx,%rdi
  401e32:	callq  404570 <nx_rt_ir_alc>
  401e37:	mov    %r12,%rsi
  401e3a:	mov    %rax,%rdi
  401e3d:	movabs $0xffffffffff,%r13
  401e47:	mov    %rax,0x8(%rsp)
  401e4c:	jmp    401e70 <nx_list_reverse+0x60>
  401e4e:	xchg   %ax,%ax
  401e50:	mov    %rbx,%rdi
  401e53:	mov    %rbp,%rdx
  401e56:	callq  4038c0 <nx_rt_rebuild2_c1_k0>
  401e5b:	mov    %rax,%rbp
  401e5e:	mov    %rbx,%rdi
  401e61:	xor    %esi,%esi
  401e63:	callq  4031f0 <nx_rt_fast_field>
  401e68:	mov    0x8(%rsp),%rdi
  401e6d:	mov    %rax,%rsi
  401e70:	mov    %rsi,%rax
  401e73:	shr    $0x28,%rax
  401e77:	cmp    $0x1,%ax
  401e7b:	jne    401fcf <nx_list_reverse+0x1bf>
  401e81:	mov    %rsi,%r14
  401e84:	and    %r13,%r14
  401e87:	test   %rsi,%rsi
  401e8a:	js     401eb0 <nx_list_reverse+0xa0>
  401e8c:	cmp    $0x3108180,%r14
  401e93:	jb     401e50 <nx_list_reverse+0x40>
  401e95:	lea    (%r15,%r14,8),%r8
  401e99:	mov    (%r15,%r14,8),%r9
  401e9d:	mov    0x8(%r15,%r14,8),%rsi
  401ea2:	lea    (%r15,%r14,8),%r13
  401ea6:	add    $0x8,%r13
  401eaa:	jmpq   401f2e <nx_list_reverse+0x11e>
  401eaf:	nop
  401eb0:	mov    (%r15,%r14,8),%r12
  401eb4:	mov    %r12d,%eax
  401eb7:	and    $0xffffff,%eax
  401ebc:	cmp    $0x1,%eax
  401ebf:	jne    401e50 <nx_list_reverse+0x40>
  401ec1:	mov    %r12,%rax
  401ec4:	shr    $0x1f,%rax
  401ec8:	cmp    $0x62102,%rax
  401ece:	jbe    401e50 <nx_list_reverse+0x40>
  401ed0:	shr    $0x18,%r12
  401ed4:	lea    (%r15,%r12,8),%r8
  401ed8:	mov    (%r15,%r12,8),%r9
  401edc:	mov    0x8(%r15,%r12,8),%rsi
  401ee1:	lea    (%r15,%r12,8),%r13
  401ee5:	add    $0x8,%r13
  401ee9:	mov    (%rdi),%rax
  401eec:	mov    %rax,(%r15,%r14,8)
  401ef0:	mov    %r14,(%rdi)
  401ef3:	mov    0x100(%rdi),%rax
  401efa:	inc    %rax
  401efd:	mov    %rax,0x100(%rdi)
  401f04:	cmp    $0x8000,%rax
  401f0a:	jb     401f2b <nx_list_reverse+0x11b>
  401f0c:	mov    %rbx,%rdi
  401f0f:	mov    %rsi,%r14
  401f12:	mov    %r9,(%rsp)
  401f16:	callq  401c36 <nx_rt_ir_hand0>
  401f1b:	mov    (%rsp),%r9
  401f1f:	lea    (%r15,%r12,8),%r8
  401f23:	mov    0x8(%rsp),%rdi
  401f28:	mov    %r14,%rsi
  401f2b:	mov    %r12,%r14
  401f2e:	mov    %rbp,%rax
  401f31:	shr    $0x38,%rax
  401f35:	cmp    $0x2,%eax
  401f38:	jne    401fa9 <nx_list_reverse+0x199>
  401f3a:	mov    (%rdi),%rax
  401f3d:	test   %rax,%rax
  401f40:	je     401f56 <nx_list_reverse+0x146>
  401f42:	lea    (%r15,%rax,8),%rcx
  401f46:	mov    (%r15,%rax,8),%rdx
  401f4a:	mov    %rdx,(%rdi)
  401f4d:	decq   0x100(%rdi)
  401f54:	jmp    401f7f <nx_list_reverse+0x16f>
  401f56:	mov    %rbx,%rdi
  401f59:	mov    %rsi,0x10(%rsp)
  401f5e:	mov    %r8,%r12
  401f61:	mov    %r9,(%rsp)
  401f65:	callq  401c25 <nx_rt_ir_alloc0>
  401f6a:	mov    (%rsp),%r9
  401f6e:	mov    %r12,%r8
  401f71:	mov    0x8(%rsp),%rdi
  401f76:	mov    0x10(%rsp),%rsi
  401f7b:	lea    (%r15,%rax,8),%rcx
  401f7f:	mov    %rbp,%rdx
  401f82:	shl    $0x18,%rdx
  401f86:	inc    %rdx
  401f89:	mov    %rdx,(%rcx)
  401f8c:	movabs $0x2ffff0000000000,%rcx
  401f96:	and    %rcx,%rbp
  401f99:	movabs $0x8000000000000000,%rcx
  401fa3:	or     %rcx,%rbp
  401fa6:	or     %rax,%rbp
  401fa9:	mov    %r9,(%r8)
  401fac:	mov    %rbp,0x0(%r13)
  401fb0:	movabs $0x200010000000000,%rax
  401fba:	or     %rax,%r14
  401fbd:	mov    %r14,%rbp
  401fc0:	movabs $0xffffffffff,%r13
  401fca:	jmpq   401e70 <nx_list_reverse+0x60>
  401fcf:	movzwl %ax,%eax
  401fd2:	test   %eax,%eax
  401fd4:	jne    401fe8 <nx_list_reverse+0x1d8>
  401fd6:	mov    %rbp,%rax
  401fd9:	add    $0x18,%rsp
  401fdd:	pop    %rbx
  401fde:	pop    %r12
  401fe0:	pop    %r13
  401fe2:	pop    %r14
  401fe4:	pop    %r15
  401fe6:	pop    %rbp
  401fe7:	retq   
  401fe8:	mov    %rbx,%rdi
  401feb:	mov    $0x1,%esi
  401ff0:	add    $0x18,%rsp
  401ff4:	pop    %rbx
  401ff5:	pop    %r12
  401ff7:	pop    %r13
  401ff9:	pop    %r14
  401ffb:	pop    %r15
  401ffd:	pop    %rbp
  401ffe:	jmpq   4029f0 <nx_rt_fail>

Disassembly of section .fini:
