#!/usr/bin/env python3
"""Root-operated verification/application of five exact cold diagnostic JSON files."""
import argparse,hashlib,json,subprocess
from pathlib import Path
ROOT=Path(__file__).resolve().parents[4]
BASE=Path(__file__).parent
EXPECTED='d28e39b09f6d6b14958fdf9caabe0999829f0704c6e32252a44bd90146985587'

def pin(path):
    path=Path(path);data=path.read_bytes()
    return dict(file=str(path),bytes=len(data),sha256=hashlib.sha256(data).hexdigest())
def authenticate(item):
    if pin(item['file'])!=item:raise ValueError('Changed pinned input: '+item['file'])
def checked(row):
    path=Path(row['planPath']);plan=json.loads(path.read_text())
    authenticate(plan['files'])
    entries=[json.loads(x)for x in Path(plan['files']['file']).read_text().splitlines()]
    actual={x['file']['file']:(x['file']['bytes'],x['file']['sha256'])for x in entries}
    expected={x['file']:(x['bytes'],x['sha256'])for x in row['selectedFiles']}
    if not plan['complete']or plan['policy']!=row['policy']or actual!=expected or len(entries)!=len(expected)or plan['allocatedBytes']!=row['allocatedBytes']:
        raise ValueError('Unexpected verified file selection')
    return pin(path)
def main():
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('action',choices=['verify','check','apply','restore']);args=p.parse_args()
    data=(BASE/'proposal.json').read_bytes()
    if hashlib.sha256(data).hexdigest()!=EXPECTED:raise ValueError('Reviewed proposal changed')
    d=json.loads(data)
    for row in d['roots']:
        authenticate(row['archiveReceipt']);authenticate(row['policy'])
        for identity in row['writersClosed'].values():authenticate(identity)
    if args.action=='verify':
        for row in d['roots']:
            if not Path(row['planPath']).exists():subprocess.run(row['verifyCommand'],cwd=ROOT,check=True)
            row['plan']=checked(row)
        target=BASE/'plan.json'
        if not target.exists():
            with target.open('x')as f:json.dump(dict(d,kind='phase170-verified-cold-diagnostic-json-plan'),f,indent=2);f.write('\n')
    else:
        for row in d['roots']:checked(row)
        if args.action!='check':
            for row in d['roots']:subprocess.run(row[args.action+'Command'],cwd=ROOT,check=True)
    print(json.dumps(dict(complete=True,action=args.action,**d['totals'])))
if __name__=='__main__':main()
