
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	push   %r15
  401c02:	push   %r14
  401c04:	push   %rbx
  401c05:	mov    %rdx,%r14
  401c08:	mov    %rsi,%r15
  401c0b:	mov    %rdi,%rbx
  401c0e:	xchg   %ax,%ax
  401c10:	mov    %rbx,%rdi
  401c13:	mov    %r15,%rsi
  401c16:	callq  402a40 <nx_rt_fast_id>
  401c1b:	cmp    $0x1,%eax
  401c1e:	jne    401c47 <nx_list_reverse+0x47>
  401c20:	mov    %rbx,%rdi
  401c23:	mov    %r15,%rsi
  401c26:	mov    $0x1,%edx
  401c2b:	xor    %ecx,%ecx
  401c2d:	mov    %r14,%r8
  401c30:	callq  402d10 <nx_rt_rebuild2>
  401c35:	mov    %rax,%r14
  401c38:	mov    %rbx,%rdi
  401c3b:	xor    %esi,%esi
  401c3d:	callq  402cf0 <nx_rt_fast_field>
  401c42:	mov    %rax,%r15
  401c45:	jmp    401c10 <nx_list_reverse+0x10>
  401c47:	test   %eax,%eax
  401c49:	jne    401c54 <nx_list_reverse+0x54>
  401c4b:	mov    %r14,%rax
  401c4e:	pop    %rbx
  401c4f:	pop    %r14
  401c51:	pop    %r15
  401c53:	retq   
  401c54:	mov    %rbx,%rdi
  401c57:	mov    $0x1,%esi
  401c5c:	pop    %rbx
  401c5d:	pop    %r14
  401c5f:	pop    %r15
  401c61:	jmpq   402540 <nx_rt_fail>

Disassembly of section .fini:
