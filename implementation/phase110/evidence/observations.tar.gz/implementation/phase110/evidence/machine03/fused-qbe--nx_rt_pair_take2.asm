
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404120 <nx_rt_pair_take2>:
  404120:	movabs $0xffffffffff,%rax
  40412a:	push   %r15
  40412c:	and    %rsi,%rax
  40412f:	push   %r14
  404131:	push   %r13
  404133:	lea    0x0(,%rax,8),%rdx
  40413b:	push   %r12
  40413d:	push   %rbp
  40413e:	mov    (%rdi),%rbp
  404141:	mov    0x8(%rdi),%r14
  404145:	lea    0x0(%rbp,%rdx,1),%rcx
  40414a:	test   %rsi,%rsi
  40414d:	js     4041b0 <nx_rt_pair_take2+0x90>
  40414f:	mov    (%rcx),%r13
  404152:	mov    0x8(%rbp,%rdx,1),%r12
  404157:	cmp    $0x310817f,%rax
  40415d:	ja     404170 <nx_rt_pair_take2+0x50>
  40415f:	pop    %rbp
  404160:	mov    %r13,%rax
  404163:	mov    %r12,%rdx
  404166:	pop    %r12
  404168:	pop    %r13
  40416a:	pop    %r14
  40416c:	pop    %r15
  40416e:	retq   
  40416f:	nop
  404170:	mov    0x8(%r14),%rdx
  404174:	mov    %rdx,0x0(%rbp,%rax,8)
  404179:	mov    0x3d059(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40417f:	mov    %rax,0x8(%r14)
  404183:	mov    0x108(%r14),%rax
  40418a:	add    $0x2,%rax
  40418e:	mov    %rax,0x108(%r14)
  404195:	cmp    %rdx,%rax
  404198:	jae    401be0 <nx_rt_pair_take2.cold>
  40419e:	pop    %rbp
  40419f:	mov    %r13,%rax
  4041a2:	mov    %r12,%rdx
  4041a5:	pop    %r12
  4041a7:	pop    %r13
  4041a9:	pop    %r14
  4041ab:	pop    %r15
  4041ad:	retq   
  4041ae:	xchg   %ax,%ax
  4041b0:	mov    0x4(%rcx),%edx
  4041b3:	mov    (%rcx),%edi
  4041b5:	shl    $0x20,%rdx
  4041b9:	or     %rdi,%rdx
  4041bc:	mov    %rdx,%r15
  4041bf:	and    $0xffffff,%edx
  4041c5:	shr    $0x18,%r15
  4041c9:	lea    0x8(,%r15,8),%rdi
  4041d1:	lea    0x0(%rbp,%rdi,1),%r8
  4041d6:	cmp    $0x1,%rdx
  4041da:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  4041e0:	mov    (%rcx),%edx
  4041e2:	mov    (%r14),%rdx
  4041e5:	mov    -0x8(%rbp,%rdi,1),%r13
  4041ea:	mov    (%r8),%r12
  4041ed:	mov    %rdx,(%rcx)
  4041f0:	mov    0x3cfe2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4041f6:	mov    %rax,(%r14)
  4041f9:	mov    0x100(%r14),%rax
  404200:	add    $0x1,%rax
  404204:	mov    %rax,0x100(%r14)
  40420b:	cmp    %rdx,%rax
  40420e:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  404214:	mov    %r15,%rax
  404217:	jmpq   404157 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
