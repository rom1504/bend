
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402170 <nx_string_reverse>:
  402170:	endbr64 
  402174:	push   %rbp
  402175:	mov    %rsp,%rbp
  402178:	sub    $0x48,%rsp
  40217c:	push   %rbx
  40217d:	push   %r12
  40217f:	push   %r13
  402181:	push   %r14
  402183:	push   %r15
  402185:	mov    %rdx,%rbx
  402188:	mov    %rsi,%r14
  40218b:	mov    %rdi,%r12
  40218e:	callq  4047e0 <nx_rt_ir_heap>
  402193:	mov    %r12,%rdi
  402196:	mov    %rax,%r12
  402199:	mov    %rdi,%r13
  40219c:	callq  404850 <nx_rt_ir_alc>
  4021a1:	mov    %r14,%rsi
  4021a4:	mov    %r13,%rdi
  4021a7:	xchg   %rax,%rbx
  4021a9:	mov    %rax,%r15
  4021ac:	nopl   0x0(%rax)
  4021b0:	mov    %rsi,-0x18(%rbp)
  4021b4:	mov    %rsi,%rax
  4021b7:	shr    $0x28,%rax
  4021bb:	and    $0xffff,%rax
  4021c1:	cmp    $0x2,%rax
  4021c5:	je     4024d4 <nx_string_reverse+0x364>
  4021cb:	cmp    $0x3,%rax
  4021cf:	jne    4024c8 <nx_string_reverse+0x358>
  4021d5:	movabs $0xffffffffff,%rax
  4021df:	mov    %rsi,%r13
  4021e2:	and    %rax,%r13
  4021e5:	mov    %rsi,%r8
  4021e8:	shr    $0x3f,%r8
  4021ec:	mov    %r8,-0x10(%rbp)
  4021f0:	cmp    $0x1,%r8
  4021f4:	je     402214 <nx_string_reverse+0xa4>
  4021f6:	cmp    $0x3108180,%r13
  4021fd:	setb   %al
  402200:	movzbl %al,%eax
  402203:	cmp    $0x0,%eax
  402206:	sete   %al
  402209:	movzbl %al,%eax
  40220c:	mov    %r15,%rdx
  40220f:	mov    %r13,%r15
  402212:	jmp    402267 <nx_string_reverse+0xf7>
  402214:	mov    %r13,%rsi
  402217:	mov    %rdi,%r14
  40221a:	callq  4048c0 <nx_rt_ir_view>
  40221f:	mov    %r15,%rdx
  402222:	mov    %r14,%rdi
  402225:	mov    -0x18(%rbp),%rsi
  402229:	mov    -0x10(%rbp),%r8
  40222d:	mov    %rax,%rcx
  402230:	and    $0xffffff,%rcx
  402237:	cmp    $0x1,%rcx
  40223b:	je     402247 <nx_string_reverse+0xd7>
  40223d:	mov    %r13,%r15
  402240:	mov    $0x0,%eax
  402245:	jmp    402267 <nx_string_reverse+0xf7>
  402247:	mov    %r13,%r15
  40224a:	mov    %rax,%r13
  40224d:	shr    $0x18,%r13
  402251:	cmp    $0x3108180,%r13
  402258:	setb   %al
  40225b:	movzbl %al,%eax
  40225e:	cmp    $0x0,%eax
  402261:	sete   %al
  402264:	movzbl %al,%eax
  402267:	mov    %r13,-0x40(%rbp)
  40226b:	cmp    $0x0,%eax
  40226e:	jne    402299 <nx_string_reverse+0x129>
  402270:	mov    %rdi,%r13
  402273:	callq  404140 <nx_rt_rebuild2_c3_k0>
  402278:	mov    %r13,%rdi
  40227b:	mov    %rax,%r14
  40227e:	mov    $0x0,%esi
  402283:	mov    %rdi,%r13
  402286:	callq  4034d0 <nx_rt_fast_field>
  40228b:	mov    %r14,%rdx
  40228e:	mov    %r13,%rdi
  402291:	mov    %rax,%rsi
  402294:	jmpq   4024c0 <nx_string_reverse+0x350>
  402299:	mov    %r13,%rcx
  40229c:	shl    $0x3,%rcx
  4022a0:	mov    %rcx,-0x20(%rbp)
  4022a4:	mov    %r12,%rax
  4022a7:	add    %rcx,%rax
  4022aa:	mov    %rax,-0x30(%rbp)
  4022ae:	mov    (%r12,%rcx,1),%r14
  4022b2:	mov    0x8(%r12,%rcx,1),%rsi
  4022b7:	mov    %rsi,-0x28(%rbp)
  4022bb:	cmp    $0x1,%r8
  4022bf:	jne    402313 <nx_string_reverse+0x1a3>
  4022c1:	mov    (%rbx),%r8
  4022c4:	mov    %r15,%r9
  4022c7:	shl    $0x3,%r9
  4022cb:	mov    %r8,(%r12,%r9,1)
  4022cf:	mov    %r15,(%rbx)
  4022d2:	mov    %rdx,%r15
  4022d5:	mov    0x100(%rbx),%rdx
  4022dc:	add    $0x1,%rdx
  4022e0:	mov    %rdx,0x100(%rbx)
  4022e7:	cmp    $0x8000,%rdx
  4022ee:	jb     402310 <nx_string_reverse+0x1a0>
  4022f0:	mov    %rdi,%r13
  4022f3:	callq  401c36 <nx_rt_ir_hand0>
  4022f8:	mov    %r15,%rdx
  4022fb:	mov    %r13,%rdi
  4022fe:	mov    -0x40(%rbp),%r13
  402302:	mov    -0x28(%rbp),%rsi
  402306:	mov    -0x30(%rbp),%rax
  40230a:	mov    -0x20(%rbp),%rcx
  40230e:	jmp    402313 <nx_string_reverse+0x1a3>
  402310:	mov    %r15,%rdx
  402313:	mov    %r14,%r8
  402316:	shr    $0x38,%r8
  40231a:	and    $0x7f,%r8
  40231e:	cmp    $0x2,%r8
  402322:	sete   %r8b
  402326:	movzbl %r8b,%r8d
  40232a:	mov    %r14,%r9
  40232d:	shr    $0x3f,%r9
  402331:	cmp    $0x0,%r9
  402335:	sete   %r9b
  402339:	movzbl %r9b,%r9d
  40233d:	test   %r8d,%r9d
  402340:	jne    40234a <nx_string_reverse+0x1da>
  402342:	mov    %rcx,%r15
  402345:	jmpq   4023e0 <nx_string_reverse+0x270>
  40234a:	mov    (%rbx),%r8
  40234d:	cmp    $0x0,%r8
  402351:	je     40237e <nx_string_reverse+0x20e>
  402353:	mov    %r8,%r9
  402356:	shl    $0x3,%r9
  40235a:	mov    (%r12,%r9,1),%r9
  40235e:	mov    %r9,(%rbx)
  402361:	mov    %rdx,%r15
  402364:	mov    0x100(%rbx),%rdx
  40236b:	sub    $0x1,%rdx
  40236f:	mov    %rdx,0x100(%rbx)
  402376:	mov    %r15,%rdx
  402379:	mov    %rcx,%r15
  40237c:	jmp    4023a2 <nx_string_reverse+0x232>
  40237e:	mov    %rdx,%r15
  402381:	mov    %rdi,%r13
  402384:	callq  401c25 <nx_rt_ir_alloc0>
  402389:	mov    %r15,%rdx
  40238c:	mov    %r13,%rdi
  40238f:	mov    %rax,%r8
  402392:	mov    -0x40(%rbp),%r13
  402396:	mov    -0x28(%rbp),%rsi
  40239a:	mov    -0x30(%rbp),%rax
  40239e:	mov    -0x20(%rbp),%r15
  4023a2:	mov    %r8,%r9
  4023a5:	shl    $0x3,%r9
  4023a9:	movabs $0xffffffffff,%rcx
  4023b3:	and    %r14,%rcx
  4023b6:	shl    $0x18,%rcx
  4023ba:	or     $0x1,%rcx
  4023be:	mov    %rcx,(%r12,%r9,1)
  4023c2:	mov    %r14,%rcx
  4023c5:	shr    $0x28,%rcx
  4023c9:	shl    $0x28,%rcx
  4023cd:	movabs $0x8000000000000000,%r9
  4023d7:	or     %r9,%rcx
  4023da:	mov    %rcx,%r14
  4023dd:	or     %r8,%r14
  4023e0:	mov    %r14,%rcx
  4023e3:	mov    %rcx,-0x38(%rbp)
  4023e7:	mov    %rdx,%r8
  4023ea:	shr    $0x38,%r8
  4023ee:	and    $0x7f,%r8
  4023f2:	cmp    $0x2,%r8
  4023f6:	sete   %r8b
  4023fa:	movzbl %r8b,%r8d
  4023fe:	mov    %rdx,%r9
  402401:	shr    $0x3f,%r9
  402405:	cmp    $0x0,%r9
  402409:	sete   %r9b
  40240d:	movzbl %r9b,%r9d
  402411:	test   %r8d,%r9d
  402414:	jne    40241e <nx_string_reverse+0x2ae>
  402416:	mov    %rcx,%r14
  402419:	jmpq   4024a8 <nx_string_reverse+0x338>
  40241e:	mov    %rdx,%r14
  402421:	mov    (%rbx),%rdx
  402424:	cmp    $0x0,%rdx
  402428:	je     40244f <nx_string_reverse+0x2df>
  40242a:	mov    %rdx,%r8
  40242d:	shl    $0x3,%r8
  402431:	mov    (%r12,%r8,1),%r8
  402435:	mov    %r8,(%rbx)
  402438:	mov    0x100(%rbx),%r8
  40243f:	sub    $0x1,%r8
  402443:	mov    %r8,0x100(%rbx)
  40244a:	xchg   %rcx,%r14
  40244d:	jmp    402470 <nx_string_reverse+0x300>
  40244f:	mov    %rdi,%r13
  402452:	callq  401c25 <nx_rt_ir_alloc0>
  402457:	mov    %r14,%rcx
  40245a:	mov    %r13,%rdi
  40245d:	mov    %rax,%rdx
  402460:	mov    -0x38(%rbp),%r14
  402464:	mov    -0x40(%rbp),%r13
  402468:	mov    -0x28(%rbp),%rsi
  40246c:	mov    -0x30(%rbp),%rax
  402470:	mov    %rdx,%r9
  402473:	shl    $0x3,%r9
  402477:	movabs $0xffffffffff,%r8
  402481:	and    %rcx,%r8
  402484:	shl    $0x18,%r8
  402488:	or     $0x1,%r8
  40248c:	mov    %r8,(%r12,%r9,1)
  402490:	shr    $0x28,%rcx
  402494:	shl    $0x28,%rcx
  402498:	movabs $0x8000000000000000,%r8
  4024a2:	or     %r8,%rcx
  4024a5:	or     %rcx,%rdx
  4024a8:	mov    %r14,(%r12,%r15,1)
  4024ac:	mov    %rdx,0x8(%rax)
  4024b0:	movabs $0x200030000000000,%rax
  4024ba:	mov    %r13,%rdx
  4024bd:	or     %rax,%rdx
  4024c0:	mov    %rdx,%r15
  4024c3:	jmpq   4021b0 <nx_string_reverse+0x40>
  4024c8:	mov    $0x1,%esi
  4024cd:	callq  402cd0 <nx_rt_fail>
  4024d2:	jmp    4024d7 <nx_string_reverse+0x367>
  4024d4:	mov    %r15,%rax
  4024d7:	pop    %r15
  4024d9:	pop    %r14
  4024db:	pop    %r13
  4024dd:	pop    %r12
  4024df:	pop    %rbx
  4024e0:	leaveq 
  4024e1:	retq   

Disassembly of section .fini:
