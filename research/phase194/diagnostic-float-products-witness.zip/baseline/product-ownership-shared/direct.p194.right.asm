  40852b:	push   %rbp
  40852c:	mov    %rsp,%rbp
  40852f:	sub    $0x920,%rsp
  408536:	mov    %r12,-0x10(%rbp)
  40853a:	mov    %rbx,-0x8(%rbp)
  40853e:	mov    %r13,-0x18(%rbp)
  408542:	mov    %rdi,%rax
  408545:	mov    %rax,%r12
  408548:	mov    %rsi,%rax
  40854b:	mov    %rax,%rbx
  40854e:	mov    %r12,%rdi
  408551:	mov    %rbx,%rsi
  408554:	movabs $0x0,%rdx
  40855e:	movabs $0x1,%rcx
  408568:	mov    %ecx,%ecx
  40856a:	xor    %eax,%eax
  40856c:	callq  41b9d0 <p118_rt_borrow_scalar_safe>
  408571:	mov    %rax,%rdi
  408574:	cmp    $0x0,%rdi
  40857b:	je     4085b9 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_114_105_103_104_116_+0x8e>
  408581:	mov    %r12,%rdi
  408584:	mov    %rbx,%rsi
  408587:	xor    %eax,%eax
  408589:	callq  408354 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_112_49_57_52_46_114_105_103_104_116_>
  40858e:	mov    %rax,%r13
  408591:	mov    %r12,%rdi
  408594:	mov    %rbx,%rsi
  408597:	xor    %eax,%eax
  408599:	callq  415580 <p111_rt_sink>
  40859e:	mov    %rax,-0x8a0(%rbp)
  4085a5:	mov    %r13,%rax
  4085a8:	mov    -0x10(%rbp),%r12
  4085ac:	mov    -0x8(%rbp),%rbx
  4085b0:	mov    -0x18(%rbp),%r13
  4085b4:	mov    %rbp,%rsp
  4085b7:	pop    %rbp
  4085b8:	retq   
  4085b9:	mov    %r12,%rdi
  4085bc:	mov    %rbx,%rsi
  4085bf:	xor    %eax,%eax
  4085c1:	callq  40827e <p113d_FID_36_112_49_50_56_98_111_114_114_111_119_46_111_119_110_101_100_46_112_49_57_52_46_114_105_103_104_116_>
  4085c6:	mov    %rax,%rdi
  4085c9:	mov    %rdi,%rax
  4085cc:	mov    -0x10(%rbp),%r12
  4085d0:	mov    -0x8(%rbp),%rbx
  4085d4:	mov    -0x18(%rbp),%r13
  4085d8:	mov    %rbp,%rsp
  4085db:	pop    %rbp
  4085dc:	retq   
