// Direct JavaScript backend runtime. Generated output embeds this fragment.
// Ported from bend2/comp.ts NATIVE.JS, RUNTIME and RUNTIME_MAIN, and
// bend2/bend.ts f32_round at fixed upstream commit
// 018751270e800bc222a93dad7f257083ee53a5f7. The reference files stay unchanged.
// No TypeScript compiler/runtime dependency is used by ordinary compilation.
// Number is the internal Nat representation; nat_host handles typed host input.
// Node foreign IO requires the host emitter to provide an ESM require binding.
// Bun/system calls remain lazy, exactly as in the pinned upstream runtime.

function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  // Avoid an intermediate JS array: its cold element-kind transition can
  // canonicalize a Number NaN and discard a payload on only one conversion.
  // Fresh storage keeps nested host coercions independent; the store coerces once.
  const f = new Float32Array(1);
  f[0] = x;
  return new Uint32Array(f.buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}
// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, String(io_sys().strerror(code))) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    for (;;) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io);
        continue;
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

// Direct core names. A named tail call carries all already-evaluated arguments;
// run_tail above retains the upstream unary native-closure protocol unchanged.
const jd_run = run_loop;
const jd_clo = run_clo;
function jd_tail(f, args) {
  return {$: "$JMP", f, x: args};
}


// Direct JavaScript prototype: native functions and live arguments.
function $jd$b2u($a0){for(;;){{const $match1=$a0;if(!$match1){return 0;}else{{const $match2=$match1;return 1;}}}}}
function $jd$sel_46_go($a0,$a1,$a2){for(;;){const $x3433=$a0;const $x3434=$a1;{const $match3=$a2;if($match3){return (
/*JD_USE:3433*/$x3433);}else{{const $match4=$match3;return (
/*JD_USE:3434*/$x3434);}}}}}
function $jd$sel($a0,$a1,$a2){for(;;){const $x3438=$a0;const $x3439=$a1;const $x3440=$a2;return (
/*JD_REF:$jd$sel_46_go*/$jd$sel_46_go((
/*JD_USE:3439*/$x3439),(
/*JD_USE:3440*/$x3440),(((
/*JD_USE:3438*/$x3438) === 0))));}}
function $jd$asr8($a0){for(;;){const $x3442=$a0;{const $ord0=((8 >= 32 ? 0 : ((
/*JD_USE:3442*/$x3442) >>> 8) >>> 0));const $ord1=(
/*JD_REF:$jd$sel*/$jd$sel(((31 >= 32 ? 0 : ((
/*JD_USE:3442*/$x3442) >>> 31) >>> 0)),0,4278190080));return ((($ord0 | $ord1) >>> 0));}}}
function $jd$mit($a0,$a1,$a2,$a3,$a4,$a5,$a6){for(;;){{const $match1=$a0;if($match1===0){const $x3455=$a6;return (
/*JD_USE:3455*/$x3455);}else{const $x3456=($match1-1);const $x3457=$a1;const $x3458=$a2;const $x3459=$a3;const $x3460=$a4;const $x3461=$a5;const $x3462=$a6;{const $let0=(
/*JD_REF:$jd$asr8*/$jd$asr8(((Math.imul((
/*JD_USE:3459*/$x3459), (
/*JD_USE:3459*/$x3459)) >>> 0))));{const $x3463=$let0;{const $let0=(
/*JD_REF:$jd$asr8*/$jd$asr8(((Math.imul((
/*JD_USE:3460*/$x3460), (
/*JD_USE:3460*/$x3460)) >>> 0))));{const $x3464=$let0;{const $ord0=((((
/*JD_USE:3463*/$x3463) + (
/*JD_USE:3464*/$x3464)) >>> 0));const $ord1=(
/*JD_REF:$jd$b2u*/$jd$b2u((($ord0 > 1024))));const $let0=((((
/*JD_USE:3461*/$x3461) | $ord1) >>> 0));{const $x3465=$let0;{const $ord0=((((
/*JD_USE:3463*/$x3463) - (
/*JD_USE:3464*/$x3464)) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3457*/$x3457)) >>> 0));{const $x3466=$let0;{const $ord0=((Math.imul((
/*JD_USE:3459*/$x3459), (
/*JD_USE:3460*/$x3460)) >>> 0));const $ord1=(
/*JD_REF:$jd$asr8*/$jd$asr8(((Math.imul(2, $ord0) >>> 0))));const $let0=((($ord1 + (
/*JD_USE:3458*/$x3458)) >>> 0));{const $x3467=$let0;{const $let0=(
/*JD_REF:$jd$sel*/$jd$sel((
/*JD_USE:3465*/$x3465),(
/*JD_USE:3466*/$x3466),(
/*JD_USE:3459*/$x3459)));{const $x3468=$let0;{const $let0=(
/*JD_REF:$jd$sel*/$jd$sel((
/*JD_USE:3465*/$x3465),(
/*JD_USE:3467*/$x3467),(
/*JD_USE:3460*/$x3460)));{const $x3469=$let0;{const $ord0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3465*/$x3465) === 0))));{
/*JD_REF:$jd$mit*/const $next0=(
/*JD_USE:3456*/$x3456);const $next1=(
/*JD_USE:3457*/$x3457);const $next2=(
/*JD_USE:3458*/$x3458);const $next3=(
/*JD_USE:3468*/$x3468);const $next4=(
/*JD_USE:3469*/$x3469);const $next5=(
/*JD_USE:3465*/$x3465);const $next6=((((
/*JD_USE:3462*/$x3462) + $ord0) >>> 0));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$a4=$next4;$a5=$next5;$a6=$next6;continue;}}}}}}}}}}}}}}}}}}}}
function $jd$pix($a0,$a1){for(;;){const $x3472=$a0;const $x3473=$a1;{const $ord0=((((
/*JD_USE:3472*/$x3472) & 4095) >>> 0));const $ord1=((Math.imul($ord0, 768) >>> 0));const $ord2=((4096 === 0 ? 0 : ($ord1 / 4096) >>> 0));const $let0=((($ord2 - 512) >>> 0));{const $x3474=$let0;{const $ord0=((12 >= 32 ? 0 : ((
/*JD_USE:3472*/$x3472) >>> 12) >>> 0));const $ord1=((Math.imul($ord0, 768) >>> 0));const $ord2=((4096 === 0 ? 0 : ($ord1 / 4096) >>> 0));const $let0=((($ord2 - 384) >>> 0));{const $x3475=$let0;return (
/*JD_REF:$jd$mit*/$jd$mit((
/*JD_USE:3473*/$x3473),(
/*JD_USE:3474*/$x3474),(
/*JD_USE:3475*/$x3475),0,0,0,0));}}}}}}
function $jd$bkt($a0,$a1){for(;;){const $x3478=$a0;const $x3479=$a1;{const $ord0=((Math.imul((
/*JD_USE:3478*/$x3478), 8) >>> 0));const $ord1=(((
/*JD_USE:3479*/$x3479) >>> 0));const $let0=(($ord1 === 0 ? 0 : ($ord0 / $ord1) >>> 0));{const $x3480=$let0;return (
/*JD_REF:$jd$sel*/$jd$sel((
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3480*/$x3480) > 7)))),(
/*JD_USE:3480*/$x3480),7));}}}}
function $jd$hchunk($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9,$a10){for(;;){{const $match1=$a0;if($match1===0){const $x3494=$a3;const $x3495=$a4;const $x3496=$a5;const $x3497=$a6;const $x3498=$a7;const $x3499=$a8;const $x3500=$a9;const $x3501=$a10;return ({$:"Hl",["h0"]:(
/*JD_USE:3494*/$x3494),["h1"]:(
/*JD_USE:3495*/$x3495),["h2"]:(
/*JD_USE:3496*/$x3496),["h3"]:(
/*JD_USE:3497*/$x3497),["h4"]:(
/*JD_USE:3498*/$x3498),["h5"]:(
/*JD_USE:3499*/$x3499),["h6"]:(
/*JD_USE:3500*/$x3500),["h7"]:(
/*JD_USE:3501*/$x3501)});}else{const $x3502=($match1-1);const $x3503=$a1;const $x3504=$a2;const $x3505=$a3;const $x3506=$a4;const $x3507=$a5;const $x3508=$a6;const $x3509=$a7;const $x3510=$a8;const $x3511=$a9;const $x3512=$a10;{const $ord0=(((
/*JD_USE:3502*/$x3502) >>> 0));const $let0=(
/*JD_REF:$jd$pix*/$jd$pix(((((
/*JD_USE:3503*/$x3503) + $ord0) >>> 0)),(
/*JD_USE:3504*/$x3504)));{const $x3513=$let0;{const $let0=(
/*JD_REF:$jd$bkt*/$jd$bkt((
/*JD_USE:3513*/$x3513),(
/*JD_USE:3504*/$x3504)));{const $x3514=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 0))));{const $x3515=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 1))));{const $x3516=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 2))));{const $x3517=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 3))));{const $x3518=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 4))));{const $x3519=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 5))));{const $x3520=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 6))));{const $x3521=$let0;{const $let0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3514*/$x3514) === 7))));{const $x3522=$let0;{
/*JD_REF:$jd$hchunk*/const $next0=(
/*JD_USE:3502*/$x3502);const $next1=(
/*JD_USE:3503*/$x3503);const $next2=(
/*JD_USE:3504*/$x3504);const $next3=((((
/*JD_USE:3505*/$x3505) + (
/*JD_USE:3515*/$x3515)) >>> 0));const $next4=((((
/*JD_USE:3506*/$x3506) + (
/*JD_USE:3516*/$x3516)) >>> 0));const $next5=((((
/*JD_USE:3507*/$x3507) + (
/*JD_USE:3517*/$x3517)) >>> 0));const $next6=((((
/*JD_USE:3508*/$x3508) + (
/*JD_USE:3518*/$x3518)) >>> 0));const $next7=((((
/*JD_USE:3509*/$x3509) + (
/*JD_USE:3519*/$x3519)) >>> 0));const $next8=((((
/*JD_USE:3510*/$x3510) + (
/*JD_USE:3520*/$x3520)) >>> 0));const $next9=((((
/*JD_USE:3511*/$x3511) + (
/*JD_USE:3521*/$x3521)) >>> 0));const $next10=((((
/*JD_USE:3512*/$x3512) + (
/*JD_USE:3522*/$x3522)) >>> 0));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$a4=$next4;$a5=$next5;$a6=$next6;$a7=$next7;$a8=$next8;$a9=$next9;$a10=$next10;continue;}}}}}}}}}}}}}}}}}}}}}}}}}
function $jd$hzip($a0,$a1){for(;;){{const $match1=$a0;const $x3525=$match1["h0"];const $x3526=$match1["h1"];const $x3527=$match1["h2"];const $x3528=$match1["h3"];const $x3529=$match1["h4"];const $x3530=$match1["h5"];const $x3531=$match1["h6"];const $x3532=$match1["h7"];{const $match10=$a1;const $x3533=$match10["h0"];const $x3534=$match10["h1"];const $x3535=$match10["h2"];const $x3536=$match10["h3"];const $x3537=$match10["h4"];const $x3538=$match10["h5"];const $x3539=$match10["h6"];const $x3540=$match10["h7"];return ({$:"Hl",["h0"]:((((
/*JD_USE:3525*/$x3525) + (
/*JD_USE:3533*/$x3533)) >>> 0)),["h1"]:((((
/*JD_USE:3526*/$x3526) + (
/*JD_USE:3534*/$x3534)) >>> 0)),["h2"]:((((
/*JD_USE:3527*/$x3527) + (
/*JD_USE:3535*/$x3535)) >>> 0)),["h3"]:((((
/*JD_USE:3528*/$x3528) + (
/*JD_USE:3536*/$x3536)) >>> 0)),["h4"]:((((
/*JD_USE:3529*/$x3529) + (
/*JD_USE:3537*/$x3537)) >>> 0)),["h5"]:((((
/*JD_USE:3530*/$x3530) + (
/*JD_USE:3538*/$x3538)) >>> 0)),["h6"]:((((
/*JD_USE:3531*/$x3531) + (
/*JD_USE:3539*/$x3539)) >>> 0)),["h7"]:((((
/*JD_USE:3532*/$x3532) + (
/*JD_USE:3540*/$x3540)) >>> 0))});}}}}
function $jd$hfold($a0,$a1,$a2){for(;;){{const $match1=$a0;if($match1===0){const $x3544=$a1;const $x3545=$a2;return (
/*JD_REF:$jd$hchunk*/$jd$hchunk(64,(
/*JD_USE:3544*/$x3544),(
/*JD_USE:3545*/$x3545),0,0,0,0,0,0,0,0));}else{const $x3546=($match1-1);const $x3547=$a1;const $x3548=$a2;{const $let0=(
/*JD_REF:$jd$hfold*/$jd$hfold((
/*JD_USE:3546*/$x3546),(
/*JD_USE:3547*/$x3547),(
/*JD_USE:3548*/$x3548)));const $ord0=(((
/*JD_USE:3546*/$x3546) >= 32 ? 0 : (64 << (
/*JD_USE:3546*/$x3546)) >>> 0));const $let1=(
/*JD_REF:$jd$hfold*/$jd$hfold((
/*JD_USE:3546*/$x3546),((((
/*JD_USE:3547*/$x3547) + $ord0) >>> 0)),(
/*JD_USE:3548*/$x3548)));{const $x3549=$let0;const $x3550=$let1;return (
/*JD_REF:$jd$hzip*/$jd$hzip((
/*JD_USE:3549*/$x3549),(
/*JD_USE:3550*/$x3550)));}}}}}}
function $jd$cdf($a0){for(;;){{const $match1=$a0;const $x3552=$match1["h0"];const $x3553=$match1["h1"];const $x3554=$match1["h2"];const $x3555=$match1["h3"];const $x3556=$match1["h4"];const $x3557=$match1["h5"];const $x3558=$match1["h6"];const $x3559=$match1["h7"];{const $let0=((((
/*JD_USE:3552*/$x3552) + (
/*JD_USE:3553*/$x3553)) >>> 0));{const $x3560=$let0;{const $let0=((((
/*JD_USE:3560*/$x3560) + (
/*JD_USE:3554*/$x3554)) >>> 0));{const $x3561=$let0;{const $let0=((((
/*JD_USE:3561*/$x3561) + (
/*JD_USE:3555*/$x3555)) >>> 0));{const $x3562=$let0;{const $let0=((((
/*JD_USE:3562*/$x3562) + (
/*JD_USE:3556*/$x3556)) >>> 0));{const $x3563=$let0;{const $let0=((((
/*JD_USE:3563*/$x3563) + (
/*JD_USE:3557*/$x3557)) >>> 0));{const $x3564=$let0;{const $let0=((((
/*JD_USE:3564*/$x3564) + (
/*JD_USE:3558*/$x3558)) >>> 0));{const $x3565=$let0;{const $let0=((((
/*JD_USE:3565*/$x3565) + (
/*JD_USE:3559*/$x3559)) >>> 0));{const $x3566=$let0;{const $ord0=((Math.imul((
/*JD_USE:3552*/$x3552), 255) >>> 0));const $ord1=((Math.imul((
/*JD_USE:3560*/$x3560), 255) >>> 0));const $ord2=((Math.imul((
/*JD_USE:3561*/$x3561), 255) >>> 0));const $ord3=((Math.imul((
/*JD_USE:3562*/$x3562), 255) >>> 0));const $ord4=((Math.imul((
/*JD_USE:3563*/$x3563), 255) >>> 0));const $ord5=((Math.imul((
/*JD_USE:3564*/$x3564), 255) >>> 0));const $ord6=((Math.imul((
/*JD_USE:3565*/$x3565), 255) >>> 0));const $ord7=((Math.imul((
/*JD_USE:3566*/$x3566), 255) >>> 0));return ({$:"Lut",["k0"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord0 / (
/*JD_USE:3566*/$x3566)) >>> 0)),["k1"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord1 / (
/*JD_USE:3566*/$x3566)) >>> 0)),["k2"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord2 / (
/*JD_USE:3566*/$x3566)) >>> 0)),["k3"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord3 / (
/*JD_USE:3566*/$x3566)) >>> 0)),["k4"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord4 / (
/*JD_USE:3566*/$x3566)) >>> 0)),["k5"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord5 / (
/*JD_USE:3566*/$x3566)) >>> 0)),["k6"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord6 / (
/*JD_USE:3566*/$x3566)) >>> 0)),["k7"]:(((
/*JD_USE:3566*/$x3566) === 0 ? 0 : ($ord7 / (
/*JD_USE:3566*/$x3566)) >>> 0))});}}}}}}}}}}}}}}}}}}
function $jd$rpix($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9){for(;;){const $x3577=$a0;const $x3578=$a1;const $x3579=$a2;const $x3580=$a3;const $x3581=$a4;const $x3582=$a5;const $x3583=$a6;const $x3584=$a7;const $x3585=$a8;const $x3586=$a9;{const $let0=(
/*JD_REF:$jd$pix*/$jd$pix((
/*JD_USE:3577*/$x3577),(
/*JD_USE:3578*/$x3578)));{const $x3587=$let0;{const $let0=(
/*JD_REF:$jd$bkt*/$jd$bkt((
/*JD_USE:3587*/$x3587),(
/*JD_USE:3578*/$x3578)));{const $x3588=$let0;{const $ord0=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 0))));const $ord1=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 1))));const $ord2=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 2))));const $ord3=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 3))));const $ord4=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 4))));const $ord5=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 5))));const $ord6=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 6))));const $ord7=(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3588*/$x3588) === 7))));const $ord8=((Math.imul($ord6, (
/*JD_USE:3585*/$x3585)) >>> 0));const $ord9=((Math.imul($ord7, (
/*JD_USE:3586*/$x3586)) >>> 0));const $ord10=((Math.imul($ord5, (
/*JD_USE:3584*/$x3584)) >>> 0));const $ord11=((($ord8 + $ord9) >>> 0));const $ord12=((Math.imul($ord4, (
/*JD_USE:3583*/$x3583)) >>> 0));const $ord13=((($ord10 + $ord11) >>> 0));const $ord14=((Math.imul($ord3, (
/*JD_USE:3582*/$x3582)) >>> 0));const $ord15=((($ord12 + $ord13) >>> 0));const $ord16=((Math.imul($ord2, (
/*JD_USE:3581*/$x3581)) >>> 0));const $ord17=((($ord14 + $ord15) >>> 0));const $ord18=((Math.imul($ord1, (
/*JD_USE:3580*/$x3580)) >>> 0));const $ord19=((($ord16 + $ord17) >>> 0));const $ord20=((Math.imul($ord0, (
/*JD_USE:3579*/$x3579)) >>> 0));const $ord21=((($ord18 + $ord19) >>> 0));const $let0=((($ord20 + $ord21) >>> 0));{const $x3589=$let0;{const $ord0=((Math.imul((
/*JD_USE:3577*/$x3577), 2654435761) >>> 0));const $ord1=((($ord0 + 1) >>> 0));const $ord2=((Math.imul((
/*JD_USE:3589*/$x3589), $ord1) >>> 0));return ((($ord2 + (
/*JD_USE:3587*/$x3587)) >>> 0));}}}}}}}}}
function $jd$rcol($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9,$a10){for(;;){{const $match1=$a0;if($match1===0){const $x3601=$a1;const $x3602=$a2;const $x3603=$a3;const $x3604=$a4;const $x3605=$a5;const $x3606=$a6;const $x3607=$a7;const $x3608=$a8;const $x3609=$a9;const $x3610=$a10;return (
/*JD_REF:$jd$rpix*/$jd$rpix((
/*JD_USE:3601*/$x3601),(
/*JD_USE:3602*/$x3602),(
/*JD_USE:3603*/$x3603),(
/*JD_USE:3604*/$x3604),(
/*JD_USE:3605*/$x3605),(
/*JD_USE:3606*/$x3606),(
/*JD_USE:3607*/$x3607),(
/*JD_USE:3608*/$x3608),(
/*JD_USE:3609*/$x3609),(
/*JD_USE:3610*/$x3610)));}else{const $x3611=($match1-1);const $x3612=$a1;const $x3613=$a2;const $x3614=$a3;const $x3615=$a4;const $x3616=$a5;const $x3617=$a6;const $x3618=$a7;const $x3619=$a8;const $x3620=$a9;const $x3621=$a10;{const $let0=(
/*JD_REF:$jd$rcol*/$jd$rcol((
/*JD_USE:3611*/$x3611),(
/*JD_USE:3612*/$x3612),(
/*JD_USE:3613*/$x3613),(
/*JD_USE:3614*/$x3614),(
/*JD_USE:3615*/$x3615),(
/*JD_USE:3616*/$x3616),(
/*JD_USE:3617*/$x3617),(
/*JD_USE:3618*/$x3618),(
/*JD_USE:3619*/$x3619),(
/*JD_USE:3620*/$x3620),(
/*JD_USE:3621*/$x3621)));const $ord0=(((
/*JD_USE:3611*/$x3611) >= 32 ? 0 : (1 << (
/*JD_USE:3611*/$x3611)) >>> 0));const $let1=(
/*JD_REF:$jd$rcol*/$jd$rcol((
/*JD_USE:3611*/$x3611),((((
/*JD_USE:3612*/$x3612) + $ord0) >>> 0)),(
/*JD_USE:3613*/$x3613),(
/*JD_USE:3614*/$x3614),(
/*JD_USE:3615*/$x3615),(
/*JD_USE:3616*/$x3616),(
/*JD_USE:3617*/$x3617),(
/*JD_USE:3618*/$x3618),(
/*JD_USE:3619*/$x3619),(
/*JD_USE:3620*/$x3620),(
/*JD_USE:3621*/$x3621)));{const $x3622=$let0;const $x3623=$let1;return ((((
/*JD_USE:3622*/$x3622) + (
/*JD_USE:3623*/$x3623)) >>> 0));}}}}}}
function $jd$rend_46_mix($a0,$a1,$a2){for(;;){const $x3627=$a0;const $x3628=$a1;{const $match3=$a2;const $x3629=$match3["k0"];const $x3630=$match3["k1"];const $x3631=$match3["k2"];const $x3632=$match3["k3"];const $x3633=$match3["k4"];const $x3634=$match3["k5"];const $x3635=$match3["k6"];const $x3636=$match3["k7"];{const $ord0=((Math.imul((
/*JD_USE:3629*/$x3629), 2654435761) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3630*/$x3630)) >>> 0));{const $x3637=$let0;{const $ord0=((Math.imul((
/*JD_USE:3637*/$x3637), 2654435761) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3631*/$x3631)) >>> 0));{const $x3638=$let0;{const $ord0=((Math.imul((
/*JD_USE:3638*/$x3638), 2654435761) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3632*/$x3632)) >>> 0));{const $x3639=$let0;{const $ord0=((Math.imul((
/*JD_USE:3639*/$x3639), 2654435761) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3633*/$x3633)) >>> 0));{const $x3640=$let0;{const $ord0=((Math.imul((
/*JD_USE:3640*/$x3640), 2654435761) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3634*/$x3634)) >>> 0));{const $x3641=$let0;{const $ord0=((Math.imul((
/*JD_USE:3641*/$x3641), 2654435761) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3635*/$x3635)) >>> 0));{const $x3642=$let0;{const $ord0=((Math.imul((
/*JD_USE:3642*/$x3642), 2654435761) >>> 0));const $let0=((($ord0 + (
/*JD_USE:3636*/$x3636)) >>> 0));{const $x3643=$let0;{const $let0=(
/*JD_REF:$jd$rcol*/$jd$rcol((nat_chk((
/*JD_USE:3627*/$x3627) + 6)),0,(
/*JD_USE:3628*/$x3628),(
/*JD_USE:3629*/$x3629),(
/*JD_USE:3630*/$x3630),(
/*JD_USE:3631*/$x3631),(
/*JD_USE:3632*/$x3632),(
/*JD_USE:3633*/$x3633),(
/*JD_USE:3634*/$x3634),(
/*JD_USE:3635*/$x3635),(
/*JD_USE:3636*/$x3636)));{const $x3644=$let0;{const $ord0=((Math.imul((
/*JD_USE:3643*/$x3643), 2654435761) >>> 0));return ((($ord0 + (
/*JD_USE:3644*/$x3644)) >>> 0));}}}}}}}}}}}}}}}}}}}}
function $jd$rend($a0,$a1){for(;;){const $x3647=$a0;const $x3648=$a1;return (
/*JD_REF:$jd$rend_46_mix*/$jd$rend_46_mix((
/*JD_USE:3647*/$x3647),(
/*JD_USE:3648*/$x3648),(
/*JD_REF:$jd$cdf*/$jd$cdf((
/*JD_REF:$jd$hfold*/$jd$hfold((
/*JD_USE:3647*/$x3647),0,(
/*JD_USE:3648*/$x3648)))))));}}
function $jd$its(){for(;;){return 51;}}
function $jd$bench($a0,$a1){for(;;){const $x3651=$a0;return (
/*JD_REF:$jd$rend*/$jd$rend(((
/*JD_USE:3651*/$x3651)),7));}}

export const backend={kind:"direct-js",representation:"upstream-native",prototype:true,foreign:"upstream-cps"};
export default {
"b2u":run_lib((a0,)=>{const r=(run_loop($jd$b2u((a0),)));(a0);return r;},1),
"sel.go":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$sel_46_go((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"sel":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$sel((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"asr8":run_lib((a0,)=>{const r=(run_loop($jd$asr8((a0),)));(a0);return r;},1),
"mit":run_lib((a0,a1,a2,a3,a4,a5,a6,)=>{const r=(run_loop($jd$mit(nat_host(a0),(a1),(a2),(a3),(a4),(a5),(a6),)));BigInt(a0);(a1);(a2);(a3);(a4);(a5);(a6);return r;},7),
"pix":run_lib((a0,a1,)=>{const r=(run_loop($jd$pix((a0),nat_host(a1),)));(a0);BigInt(a1);return r;},2),
"bkt":run_lib((a0,a1,)=>{const r=(run_loop($jd$bkt((a0),nat_host(a1),)));(a0);BigInt(a1);return r;},2),
"hchunk":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,)=>{const r=(run_loop($jd$hchunk(nat_host(a0),(a1),nat_host(a2),(a3),(a4),(a5),(a6),(a7),(a8),(a9),(a10),)));BigInt(a0);(a1);BigInt(a2);(a3);(a4);(a5);(a6);(a7);(a8);(a9);(a10);return r;},11),
"hzip":run_lib((a0,a1,)=>{const r=(run_loop($jd$hzip((a0),(a1),)));(a0);(a1);return r;},2),
"hfold":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$hfold(nat_host(a0),(a1),nat_host(a2),)));BigInt(a0);(a1);BigInt(a2);return r;},3),
"cdf":run_lib((a0,)=>{const r=(run_loop($jd$cdf((a0),)));(a0);return r;},1),
"rpix":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,)=>{const r=(run_loop($jd$rpix((a0),nat_host(a1),(a2),(a3),(a4),(a5),(a6),(a7),(a8),(a9),)));(a0);BigInt(a1);(a2);(a3);(a4);(a5);(a6);(a7);(a8);(a9);return r;},10),
"rcol":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,)=>{const r=(run_loop($jd$rcol(nat_host(a0),(a1),nat_host(a2),(a3),(a4),(a5),(a6),(a7),(a8),(a9),(a10),)));BigInt(a0);(a1);BigInt(a2);(a3);(a4);(a5);(a6);(a7);(a8);(a9);(a10);return r;},11),
"rend.mix":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$rend_46_mix(nat_host(a0),nat_host(a1),(a2),)));BigInt(a0);BigInt(a1);(a2);return r;},3),
"rend":run_lib((a0,a1,)=>{const r=(run_loop($jd$rend(nat_host(a0),nat_host(a1),)));BigInt(a0);BigInt(a1);return r;},2),
"its":run_lib(()=>{const r=BigInt(run_loop($jd$its()));return r;},0),
"bench":run_lib((a0,a1,)=>{const r=(run_loop($jd$bench((a0),(a1),)));(a0);(a1);return r;},2),
};
