0000000000421c40 <p125_rt_ctor2>:
  421c40:	push   r15
  421c42:	push   r14
  421c44:	push   r13
  421c46:	mov    r13,rdx
  421c49:	push   r12
  421c4b:	push   rbp
  421c4c:	push   rbx
  421c4d:	mov    ebx,esi
  421c4f:	sub    rsp,0x8
  421c53:	mov    r12,QWORD PTR [rdi+0x8]
  421c57:	mov    r14,QWORD PTR [rdi]
  421c5a:	mov    rbp,QWORD PTR [r12+0x8]
  421c5f:	test   rbp,rbp
  421c62:	je     40501c <p125_rt_ctor2.cold+0x30>
  421c68:	lea    rcx,[r14+rbp*8]
  421c6c:	mov    rax,QWORD PTR [rcx]
  421c6f:	sub    QWORD PTR [r12+0x108],0x2
  421c78:	mov    QWORD PTR [r12+0x8],rax
  421c7d:	mov    rax,QWORD PTR [rip+0x10904c]        # 52acd0 <p111_program_active>
  421c84:	mov    rdx,QWORD PTR [r13+0x0]
  421c88:	test   BYTE PTR [rax+0x58],0x8
  421c8c:	je     421cb0 <p125_rt_ctor2+0x70>
  421c8e:	mov    rax,QWORD PTR [rax+0x88]
  421c95:	cmp    BYTE PTR [rax+rbx*1],0x0
  421c99:	jne    421cb0 <p125_rt_ctor2+0x70>
  421c9b:	mov    QWORD PTR [rcx],rdx
  421c9e:	mov    rax,QWORD PTR [r13+0x8]
  421ca2:	mov    QWORD PTR [r14+rbp*8+0x8],rax
  421ca7:	jmp    421ce4 <p125_rt_ctor2+0xa4>
  421ca9:	nop    DWORD PTR [rax+0x0]
  421cb0:	mov    rax,rdx
  421cb3:	lea    r15,[r14+rbp*8]
  421cb7:	shr    rax,0x38
  421cbb:	and    eax,0x7f
  421cbe:	cmp    rax,0x2
  421cc2:	je     421d18 <p125_rt_ctor2+0xd8>
  421cc4:	mov    QWORD PTR [r15],rdx
  421cc7:	mov    rdx,QWORD PTR [r13+0x8]
  421ccb:	lea    r13,[r14+rbp*8+0x8]
  421cd0:	mov    rax,rdx
  421cd3:	shr    rax,0x38
  421cd7:	and    eax,0x7f
  421cda:	cmp    rax,0x2
  421cde:	je     421d08 <p125_rt_ctor2+0xc8>
  421ce0:	mov    QWORD PTR [r13+0x0],rdx
  421ce4:	mov    rax,rbx
  421ce7:	add    rsp,0x8
  421ceb:	shl    rax,0x28
  421cef:	pop    rbx
  421cf0:	or     rax,rbp
  421cf3:	pop    rbp
  421cf4:	pop    r12
  421cf6:	bts    rax,0x39
  421cfb:	pop    r13
  421cfd:	pop    r14
  421cff:	pop    r15
  421d01:	ret    
  421d02:	nop    WORD PTR [rax+rax*1+0x0]
  421d08:	test   rdx,rdx
  421d0b:	js     421ce0 <p125_rt_ctor2+0xa0>
  421d0d:	jmp    404fec <p125_rt_ctor2.cold>
  421d12:	nop    WORD PTR [rax+rax*1+0x0]
  421d18:	test   rdx,rdx
  421d1b:	js     421cc4 <p125_rt_ctor2+0x84>
  421d1d:	jmp    405004 <p125_rt_ctor2.cold+0x18>
  421d22:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  421d2d:	nop    DWORD PTR [rax]

