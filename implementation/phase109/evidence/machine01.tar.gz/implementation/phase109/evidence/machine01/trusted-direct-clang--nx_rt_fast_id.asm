
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402710 <nx_rt_fast_id>:
  402710:	shr    $0x28,%rsi
  402714:	movzwl %si,%eax
  402717:	retq   

Disassembly of section .fini:
