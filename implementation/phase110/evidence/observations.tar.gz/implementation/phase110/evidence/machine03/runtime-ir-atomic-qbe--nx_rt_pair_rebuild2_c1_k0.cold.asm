
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004017a0 <nx_rt_pair_rebuild2_c1_k0.cold>:
  4017a0:	mov    %r14,%rdx
  4017a3:	mov    $0x1,%ecx
  4017a8:	mov    %rbp,%rdi
  4017ab:	mov    %r15,%rsi
  4017ae:	mov    %r8,0x8(%rsp)
  4017b3:	callq  401397 <rfc_wrap>
  4017b8:	mov    0x8(%rsp),%r8
  4017bd:	mov    %rax,%r14
  4017c0:	jmpq   403b91 <nx_rt_pair_rebuild2_c1_k0+0x61>
  4017c5:	mov    %r12,%rdx
  4017c8:	mov    $0x1,%ecx
  4017cd:	mov    %rbp,%rdi
  4017d0:	mov    %r15,%rsi
  4017d3:	callq  401397 <rfc_wrap>
  4017d8:	mov    %rax,%r12
  4017db:	jmpq   403ba9 <nx_rt_pair_rebuild2_c1_k0+0x79>
  4017e0:	mov    $0x1,%edx
  4017e5:	mov    %rbp,%rdi
  4017e8:	mov    %r15,%rsi
  4017eb:	callq  401178 <heap_alloc_miss>
  4017f0:	mov    %rax,%rbx
  4017f3:	lea    0x0(%rbp,%rax,8),%r8
  4017f8:	jmpq   403b81 <nx_rt_pair_rebuild2_c1_k0+0x51>
  4017fd:	xor    %edx,%edx
  4017ff:	mov    %rbp,%rdi
  401802:	mov    %r15,%rsi
  401805:	mov    %rcx,0x8(%rsp)
  40180a:	callq  401100 <heap_hand>
  40180f:	mov    0x8(%rsp),%rcx
  401814:	jmpq   403c87 <nx_rt_pair_rebuild2_c1_k0+0x157>
  401819:	mov    (%rdi),%r14
  40181c:	mov    %rsi,%rdx
  40181f:	mov    %rbp,%rdi
  401822:	mov    %r15,%rsi
  401825:	mov    (%r8),%r13
  401828:	callq  401471 <span_fade.constprop.0>
  40182d:	jmpq   403bf0 <nx_rt_pair_rebuild2_c1_k0+0xc0>

Disassembly of section .fini:
