
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403290 <nx_rt_fast_field>:
  403290:	endbr64 
  403294:	push   %rbp
  403295:	mov    %rsp,%rbp
  403298:	callq  4030e0 <nx_field>
  40329d:	leaveq 
  40329e:	retq   

Disassembly of section .fini:
