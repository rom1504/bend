
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403230 <nx_rt_rebuild2>:
  403230:	push   %r15
  403232:	push   %r14
  403234:	push   %r13
  403236:	mov    %ecx,%r13d
  403239:	push   %r12
  40323b:	mov    %rdi,%r12
  40323e:	push   %rbp
  40323f:	movabs $0xffffffffff,%rbp
  403249:	push   %rbx
  40324a:	and    %rsi,%rbp
  40324d:	mov    %edx,%ebx
  40324f:	lea    0x0(,%rbp,8),%rdx
  403257:	sub    $0x28,%rsp
  40325b:	mov    (%rdi),%r14
  40325e:	mov    0x8(%rdi),%r15
  403262:	lea    (%r14,%rdx,1),%rax
  403266:	test   %rsi,%rsi
  403269:	js     403350 <nx_rt_rebuild2+0x120>
  40326f:	mov    (%rax),%rax
  403272:	mov    %rax,0x10(%rsp)
  403277:	mov    0x8(%r14,%rdx,1),%rax
  40327c:	mov    %rax,0x18(%rsp)
  403281:	cmp    $0x310817f,%rbp
  403288:	jbe    403328 <nx_rt_rebuild2+0xf8>
  40328e:	lea    (%r14,%rbp,8),%r9
  403292:	mov    $0x1,%eax
  403297:	mov    0x10(%rsp,%r13,8),%rdx
  40329c:	movq   $0xffffffffffffffff,0x18(%r12)
  4032a5:	movl   $0x1,0x20(%r12)
  4032ae:	sub    %r13d,%eax
  4032b1:	mov    0x10(%rsp,%rax,8),%rax
  4032b6:	mov    %rax,0x10(%r12)
  4032bb:	mov    %rdx,%rax
  4032be:	shr    $0x38,%rax
  4032c2:	and    $0x7f,%eax
  4032c5:	cmp    $0x2,%rax
  4032c9:	je     403308 <nx_rt_rebuild2+0xd8>
  4032cb:	mov    %r8,%rax
  4032ce:	mov    %rdx,(%r9)
  4032d1:	lea    0x8(%r14,%rbp,8),%r12
  4032d6:	shr    $0x38,%rax
  4032da:	and    $0x7f,%eax
  4032dd:	cmp    $0x2,%rax
  4032e1:	je     403318 <nx_rt_rebuild2+0xe8>
  4032e3:	mov    %rbx,%rax
  4032e6:	mov    %r8,(%r12)
  4032ea:	add    $0x28,%rsp
  4032ee:	shl    $0x28,%rax
  4032f2:	pop    %rbx
  4032f3:	or     %rbp,%rax
  4032f6:	pop    %rbp
  4032f7:	pop    %r12
  4032f9:	bts    $0x39,%rax
  4032fe:	pop    %r13
  403300:	pop    %r14
  403302:	pop    %r15
  403304:	retq   
  403305:	nopl   (%rax)
  403308:	test   %rdx,%rdx
  40330b:	js     4032cb <nx_rt_rebuild2+0x9b>
  40330d:	jmpq   401640 <nx_rt_rebuild2.cold>
  403312:	nopw   0x0(%rax,%rax,1)
  403318:	test   %r8,%r8
  40331b:	js     4032e3 <nx_rt_rebuild2+0xb3>
  40331d:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  403322:	nopw   0x0(%rax,%rax,1)
  403328:	mov    0x8(%r15),%rbp
  40332c:	test   %rbp,%rbp
  40332f:	je     401685 <nx_rt_rebuild2.cold+0x45>
  403335:	lea    (%r14,%rbp,8),%r9
  403339:	mov    (%r9),%rax
  40333c:	subq   $0x2,0x108(%r15)
  403344:	mov    %rax,0x8(%r15)
  403348:	jmpq   403292 <nx_rt_rebuild2+0x62>
  40334d:	nopl   (%rax)
  403350:	mov    0x4(%rax),%edx
  403353:	mov    (%rax),%ecx
  403355:	shl    $0x20,%rdx
  403359:	or     %rcx,%rdx
  40335c:	mov    %rdx,%rcx
  40335f:	and    $0xffffff,%edx
  403365:	shr    $0x18,%rcx
  403369:	lea    0x0(,%rcx,8),%rdi
  403371:	lea    (%r14,%rdi,1),%r9
  403375:	lea    0x8(%r14,%rdi,1),%rdi
  40337a:	cmp    $0x1,%rdx
  40337e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403384:	mov    (%rax),%edx
  403386:	mov    (%r9),%rdx
  403389:	mov    %rdx,0x10(%rsp)
  40338e:	mov    (%rdi),%rdx
  403391:	mov    %rdx,0x18(%rsp)
  403396:	mov    (%r15),%rdx
  403399:	mov    %rdx,(%rax)
  40339c:	mov    0x100(%r15),%rax
  4033a3:	mov    0x3ee2f(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4033a9:	mov    %rbp,(%r15)
  4033ac:	add    $0x1,%rax
  4033b0:	mov    %rax,0x100(%r15)
  4033b7:	cmp    %rdx,%rax
  4033ba:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  4033c0:	mov    %rcx,%rbp
  4033c3:	jmpq   403281 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
