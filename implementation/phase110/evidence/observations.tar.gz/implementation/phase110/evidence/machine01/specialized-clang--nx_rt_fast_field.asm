
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ce0 <nx_rt_fast_field>:
  402ce0:	mov    %esi,%ecx
  402ce2:	mov    $0xfffffffe,%eax
  402ce7:	rol    %cl,%eax
  402ce9:	add    $0x2,%rcx
  402ced:	and    %eax,0x20(%rdi)
  402cf0:	mov    (%rdi,%rcx,8),%rax
  402cf4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402cfc:	retq   

Disassembly of section .fini:
