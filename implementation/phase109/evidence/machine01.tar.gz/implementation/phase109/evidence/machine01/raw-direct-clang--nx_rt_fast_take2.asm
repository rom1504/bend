
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004028c0 <nx_rt_fast_take2>:
  4028c0:	movabs $0xffffffffff,%rax
  4028ca:	push   %r12
  4028cc:	and    %rsi,%rax
  4028cf:	push   %rbp
  4028d0:	push   %rbx
  4028d1:	mov    %rdi,%rbx
  4028d4:	mov    (%rdi),%rdi
  4028d7:	lea    0x0(,%rax,8),%rcx
  4028df:	mov    0x8(%rbx),%rbp
  4028e3:	lea    (%rdi,%rcx,1),%rdx
  4028e7:	test   %rsi,%rsi
  4028ea:	js     402958 <nx_rt_fast_take2+0x98>
  4028ec:	mov    (%rdx),%rdx
  4028ef:	mov    %rdx,0x10(%rbx)
  4028f3:	mov    0x8(%rdi,%rcx,1),%rdx
  4028f8:	mov    %rdx,0x18(%rbx)
  4028fc:	cmp    $0x310817f,%rax
  402902:	ja     402918 <nx_rt_fast_take2+0x58>
  402904:	movl   $0x3,0x20(%rbx)
  40290b:	xor    %eax,%eax
  40290d:	pop    %rbx
  40290e:	pop    %rbp
  40290f:	pop    %r12
  402911:	retq   
  402912:	nopw   0x0(%rax,%rax,1)
  402918:	mov    0x8(%rbp),%rdx
  40291c:	mov    %rdx,(%rdi,%rax,8)
  402920:	mov    0x48b2(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402926:	mov    %rax,0x8(%rbp)
  40292a:	mov    0x108(%rbp),%rax
  402931:	add    $0x2,%rax
  402935:	mov    %rax,0x108(%rbp)
  40293c:	cmp    %rdx,%rax
  40293f:	jae    40160f <nx_rt_fast_take2.cold>
  402945:	movl   $0x3,0x20(%rbx)
  40294c:	xor    %eax,%eax
  40294e:	pop    %rbx
  40294f:	pop    %rbp
  402950:	pop    %r12
  402952:	retq   
  402953:	nopl   0x0(%rax,%rax,1)
  402958:	mov    0x4(%rdx),%ecx
  40295b:	mov    (%rdx),%r8d
  40295e:	shl    $0x20,%rcx
  402962:	or     %r8,%rcx
  402965:	mov    %rcx,%r12
  402968:	and    $0xffffff,%ecx
  40296e:	shr    $0x18,%r12
  402972:	lea    0x0(,%r12,8),%r8
  40297a:	lea    (%rdi,%r8,1),%r9
  40297e:	lea    0x8(%rdi,%r8,1),%r8
  402983:	cmp    $0x1,%rcx
  402987:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  40298d:	mov    (%rdx),%ecx
  40298f:	mov    (%r9),%rcx
  402992:	mov    %rcx,0x10(%rbx)
  402996:	mov    (%r8),%rcx
  402999:	mov    %rcx,0x18(%rbx)
  40299d:	mov    0x0(%rbp),%rcx
  4029a1:	mov    %rcx,(%rdx)
  4029a4:	mov    0x482e(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4029aa:	mov    %rax,0x0(%rbp)
  4029ae:	mov    0x100(%rbp),%rax
  4029b5:	add    $0x1,%rax
  4029b9:	mov    %rax,0x100(%rbp)
  4029c0:	cmp    %rdx,%rax
  4029c3:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  4029c9:	mov    %r12,%rax
  4029cc:	jmpq   4028fc <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
