00000000004182e0 <p125_rt_take3>:
  4182e0:	mov    rax,rsi
  4182e3:	mov    r8,QWORD PTR [rip+0x1087e6]        # 520ad0 <p111_program_active>
  4182ea:	push   r12
  4182ec:	shr    rax,0x28
  4182f0:	push   rbp
  4182f1:	movzx  eax,ax
  4182f4:	push   rbx
  4182f5:	cmp    QWORD PTR [r8+0x18],rax
  4182f9:	ja     418310 <p125_rt_take3+0x30>
  4182fb:	lea    rdi,[rip+0x105d]        # 41935f <_IO_stdin_used+0x35f>
  418302:	call   40e3b0 <err_fail>
  418307:	nop    WORD PTR [rax+rax*1+0x0]
  418310:	mov    rcx,rdx
  418313:	mov    rdx,QWORD PTR [r8+0x80]
  41831a:	cmp    BYTE PTR [rdx+rax*1],0x3
  41831e:	jne    4182fb <p125_rt_take3+0x1b>
  418320:	mov    rax,rsi
  418323:	shr    rax,0x38
  418327:	and    eax,0x7f
  41832a:	cmp    rax,0x2
  41832e:	jne    41846b <p125_rt_take3+0x18b>
  418334:	mov    r9,QWORD PTR [rdi]
  418337:	mov    rbx,rdi
  41833a:	movabs rdi,0xffffffffff
  418344:	and    rdi,rsi
  418347:	test   rsi,rsi
  41834a:	js     4183e0 <p125_rt_take3+0x100>
  418350:	lea    rsi,[r9+rdi*8]
  418354:	xor    eax,eax
  418356:	nop    WORD PTR cs:[rax+rax*1+0x0]
  418360:	mov    rdx,QWORD PTR [rsi+rax*1]
  418364:	mov    QWORD PTR [rcx+rax*1],rdx
  418368:	add    rax,0x8
  41836c:	cmp    rax,0x18
  418370:	jne    418360 <p125_rt_take3+0x80>
  418372:	mov    rax,QWORD PTR [r8+0x40]
  418376:	add    rax,0x7f
  41837a:	and    rax,0xffffffffffffff80
  41837e:	add    rax,0x3108200
  418384:	cmp    rax,rdi
  418387:	jbe    418398 <p125_rt_take3+0xb8>
  418389:	pop    rbx
  41838a:	mov    eax,0x3
  41838f:	pop    rbp
  418390:	pop    r12
  418392:	ret    
  418393:	nop    DWORD PTR [rax+rax*1+0x0]
  418398:	mov    rsi,QWORD PTR [rbx+0x8]
  41839c:	mov    r8,QWORD PTR [rbx]
  41839f:	mov    edx,DWORD PTR [rip+0x1087df]        # 520b84 <KEEP_WORDS>
  4183a5:	mov    rax,QWORD PTR [rsi+0x10]
  4183a9:	mov    QWORD PTR [r8+rdi*8],rax
  4183ad:	mov    rax,QWORD PTR [rsi+0x110]
  4183b4:	mov    QWORD PTR [rsi+0x10],rdi
  4183b8:	add    rax,0x4
  4183bc:	mov    QWORD PTR [rsi+0x110],rax
  4183c3:	cmp    rax,rdx
  4183c6:	jae    40510a <p125_rt_take3.cold+0x37>
  4183cc:	pop    rbx
  4183cd:	mov    eax,0x3
  4183d2:	pop    rbp
  4183d3:	pop    r12
  4183d5:	ret    
  4183d6:	nop    WORD PTR cs:[rax+rax*1+0x0]
  4183e0:	lea    rbp,[r9+rdi*8]
  4183e4:	mov    r11,QWORD PTR [rbx+0x8]
  4183e8:	mov    r12d,DWORD PTR [rbp+0x4]
  4183ec:	mov    r10d,DWORD PTR [rbp+0x0]
  4183f0:	shl    r12,0x20
  4183f4:	or     r12,r10
  4183f7:	and    r10d,0xffffff
  4183fe:	cmp    r10,0x1
  418402:	je     418466 <p125_rt_take3+0x186>
  418404:	shr    r12,0x18
  418408:	xor    eax,eax
  41840a:	lea    r8,[r9+r12*8]
  41840e:	xchg   ax,ax
  418410:	mov    rdx,QWORD PTR [r8+rax*1]
  418414:	mov    QWORD PTR [rcx+rax*1],rdx
  418418:	add    rax,0x8
  41841c:	cmp    rax,0x18
  418420:	jne    418410 <p125_rt_take3+0x130>
  418422:	cmp    r10,0x1
  418426:	jne    4050d3 <p125_rt_take3.cold>
  41842c:	mov    rax,QWORD PTR [r11]
  41842f:	mov    edx,DWORD PTR [rip+0x10874f]        # 520b84 <KEEP_WORDS>
  418435:	mov    QWORD PTR [rbp+0x0],rax
  418439:	mov    rax,QWORD PTR [r11+0x100]
  418440:	mov    QWORD PTR [r11],rdi
  418443:	add    rax,0x1
  418447:	mov    QWORD PTR [r11+0x100],rax
  41844e:	cmp    rax,rdx
  418451:	jae    4050f8 <p125_rt_take3.cold+0x25>
  418457:	mov    r8,QWORD PTR [rip+0x108672]        # 520ad0 <p111_program_active>
  41845e:	mov    rdi,r12
  418461:	jmp    418372 <p125_rt_take3+0x92>
  418466:	mov    eax,DWORD PTR [rbp+0x0]
  418469:	jmp    418404 <p125_rt_take3+0x124>
  41846b:	lea    rdi,[rip+0x1aae]        # 419f20 <_IO_stdin_used+0xf20>
  418472:	call   40e3b0 <err_fail>
  418477:	nop    WORD PTR [rax+rax*1+0x0]

