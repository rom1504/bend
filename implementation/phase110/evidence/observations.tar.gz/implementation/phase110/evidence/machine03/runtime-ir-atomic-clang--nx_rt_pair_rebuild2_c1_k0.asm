
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403a50 <nx_rt_pair_rebuild2_c1_k0>:
  403a50:	push   %r15
  403a52:	push   %r14
  403a54:	push   %r13
  403a56:	push   %r12
  403a58:	mov    %rdx,%r12
  403a5b:	push   %rbp
  403a5c:	push   %rbx
  403a5d:	movabs $0xffffffffff,%rbx
  403a67:	and    %rsi,%rbx
  403a6a:	lea    0x0(,%rbx,8),%rdx
  403a72:	sub    $0x18,%rsp
  403a76:	mov    (%rdi),%rbp
  403a79:	mov    0x8(%rdi),%r15
  403a7d:	lea    0x0(%rbp,%rdx,1),%rax
  403a82:	test   %rsi,%rsi
  403a85:	js     403b40 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  403a8b:	mov    (%rax),%r14
  403a8e:	mov    0x8(%rbp,%rdx,1),%r13
  403a93:	cmp    $0x310817f,%rbx
  403a9a:	jbe    403b10 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  403a9c:	lea    0x0(%rbp,%rbx,8),%r8
  403aa1:	mov    %r14,%rax
  403aa4:	shr    $0x38,%rax
  403aa8:	and    $0x7f,%eax
  403aab:	cmp    $0x2,%rax
  403aaf:	je     403af0 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403ab1:	mov    %r12,%rax
  403ab4:	mov    %r14,(%r8)
  403ab7:	lea    0x8(%rbp,%rbx,8),%r14
  403abc:	shr    $0x38,%rax
  403ac0:	and    $0x7f,%eax
  403ac3:	cmp    $0x2,%rax
  403ac7:	je     403b00 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403ac9:	movabs $0x200010000000000,%rax
  403ad3:	mov    %r12,(%r14)
  403ad6:	mov    %r13,%rdx
  403ad9:	add    $0x18,%rsp
  403add:	or     %rbx,%rax
  403ae0:	pop    %rbx
  403ae1:	pop    %rbp
  403ae2:	pop    %r12
  403ae4:	pop    %r13
  403ae6:	pop    %r14
  403ae8:	pop    %r15
  403aea:	retq   
  403aeb:	nopl   0x0(%rax,%rax,1)
  403af0:	test   %r14,%r14
  403af3:	js     403ab1 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403af5:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  403afa:	nopw   0x0(%rax,%rax,1)
  403b00:	test   %r12,%r12
  403b03:	js     403ac9 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403b05:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  403b0a:	nopw   0x0(%rax,%rax,1)
  403b10:	mov    0x8(%r15),%rbx
  403b14:	test   %rbx,%rbx
  403b17:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  403b1d:	lea    0x0(%rbp,%rbx,8),%r8
  403b22:	mov    (%r8),%rax
  403b25:	subq   $0x2,0x108(%r15)
  403b2d:	mov    %rax,0x8(%r15)
  403b31:	jmpq   403aa1 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403b36:	nopw   %cs:0x0(%rax,%rax,1)
  403b40:	mov    0x4(%rax),%edx
  403b43:	mov    (%rax),%ecx
  403b45:	shl    $0x20,%rdx
  403b49:	or     %rcx,%rdx
  403b4c:	mov    %rdx,%rcx
  403b4f:	and    $0xffffff,%edx
  403b55:	shr    $0x18,%rcx
  403b59:	lea    0x8(,%rcx,8),%rdi
  403b61:	lea    0x0(%rbp,%rdi,1),%r8
  403b66:	lea    -0x8(%rbp,%rdi,1),%rdi
  403b6b:	cmp    $0x1,%rdx
  403b6f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403b75:	mov    (%rax),%edx
  403b77:	mov    (%r15),%rdx
  403b7a:	mov    (%rdi),%r14
  403b7d:	mov    (%r8),%r13
  403b80:	mov    %rdx,(%rax)
  403b83:	mov    0x100(%r15),%rax
  403b8a:	mov    0x3e648(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403b90:	mov    %rbx,(%r15)
  403b93:	add    $0x1,%rax
  403b97:	mov    %rax,0x100(%r15)
  403b9e:	cmp    %rdx,%rax
  403ba1:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403ba7:	mov    %rcx,%rbx
  403baa:	jmpq   403a93 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
