000000000040e966 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>:
  40e966:	push   rbp
  40e967:	mov    rbp,rsp
  40e96a:	sub    rsp,0x1210
  40e971:	mov    QWORD PTR [rbp-0x10],r12
  40e975:	mov    QWORD PTR [rbp-0x8],rbx
  40e979:	mov    QWORD PTR [rbp-0x18],r13
  40e97d:	mov    QWORD PTR [rbp-0x20],r14
  40e981:	mov    rax,rdi
  40e984:	mov    r12,rax
  40e987:	mov    rax,rsi
  40e98a:	mov    rsi,rax
  40e98d:	mov    rax,rdx
  40e990:	mov    r13,rax
  40e993:	mov    rax,rcx
  40e996:	mov    rdi,rax
  40e999:	mov    rax,r8
  40e99c:	mov    rbx,rax
  40e99f:	mov    rax,r9
  40e9a2:	mov    r14,rax
  40e9a5:	mov    r10,rdi
  40e9a8:	test   r10d,r10d
  40e9ab:	je     40ea8f <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x129>
  40e9b1:	cmp    rbx,0x0
  40e9b8:	je     40ea77 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x111>
  40e9be:	sub    rbx,0x1
  40e9c5:	mov    rdi,QWORD PTR [r12+0x10]
  40e9ca:	movabs r11,0xfffffffffffffff8
  40e9d4:	add    rdi,r11
  40e9d7:	mov    QWORD PTR [r12+0x10],rdi
  40e9dc:	mov    rdi,QWORD PTR [r12+0x10]
  40e9e1:	mov    rdi,QWORD PTR [rdi]
  40e9e4:	movabs r11,0x48
  40e9ee:	cmp    rdi,r11
  40e9f1:	jne    40ea46 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0xe0>
  40e9f7:	mov    rdi,QWORD PTR [r12+0x10]
  40e9fc:	movabs r11,0xfffffffffffffff0
  40ea06:	add    rdi,r11
  40ea09:	mov    QWORD PTR [r12+0x10],rdi
  40ea0e:	mov    rdi,QWORD PTR [r12+0x10]
  40ea13:	mov    rsi,QWORD PTR [rdi]
  40ea16:	mov    rdi,QWORD PTR [r12+0x10]
  40ea1b:	mov    rdx,QWORD PTR [rdi+0x8]
  40ea1f:	mov    edi,r14d
  40ea22:	mov    r13,rdi
  40ea25:	imul   r13d,r13d,0xa
  40ea2c:	mov    esi,esi
  40ea2e:	add    r13d,esi
  40ea31:	mov    rsi,rdx
  40ea34:	movabs r10,0x0
  40ea3e:	mov    rdi,r10
  40ea41:	jmp    40e9a5 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3f>
  40ea46:	mov    rdi,r12
  40ea49:	movabs rsi,0x4
  40ea53:	mov    esi,esi
  40ea55:	xor    eax,eax
  40ea57:	call   4185b0 <p111_rt_fail>
  40ea5c:	mov    rdi,rax
  40ea5f:	mov    rax,rdi
  40ea62:	mov    r12,QWORD PTR [rbp-0x10]
  40ea66:	mov    rbx,QWORD PTR [rbp-0x8]
  40ea6a:	mov    r13,QWORD PTR [rbp-0x18]
  40ea6e:	mov    r14,QWORD PTR [rbp-0x20]
  40ea72:	mov    rsp,rbp
  40ea75:	pop    rbp
  40ea76:	ret    
  40ea77:	mov    rax,r14
  40ea7a:	mov    r12,QWORD PTR [rbp-0x10]
  40ea7e:	mov    rbx,QWORD PTR [rbp-0x8]
  40ea82:	mov    r13,QWORD PTR [rbp-0x18]
  40ea86:	mov    r14,QWORD PTR [rbp-0x20]
  40ea8a:	mov    rsp,rbp
  40ea8d:	pop    rbp
  40ea8e:	ret    
  40ea8f:	mov    rdi,rsi
  40ea92:	shr    rdi,0x28
  40ea96:	and    rdi,0xffff
  40ea9d:	movabs r11,0xa4
  40eaa7:	cmp    rdi,r11
  40eaaa:	jne    40eac5 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x15f>
  40eab0:	movabs r10,0x1
  40eaba:	mov    rdi,r10
  40eabd:	mov    r14,r13
  40eac0:	jmp    40e9a5 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3f>
  40eac5:	mov    rdi,rsi
  40eac8:	shr    rdi,0x28
  40eacc:	and    rdi,0xffff
  40ead3:	movabs r11,0xa5
  40eadd:	cmp    rdi,r11
  40eae0:	jne    40ebc5 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x25f>
  40eae6:	mov    r10,r12
  40eae9:	mov    QWORD PTR [rsp+0x18],r10
  40eaee:	mov    r10,rsi
  40eaf1:	mov    QWORD PTR [rsp+0x20],r10
  40eaf6:	lea    r10,[rbp-0x850]
  40eafd:	mov    QWORD PTR [rsp+0x28],r10
  40eb02:	mov    rdi,QWORD PTR [rsp+0x18]
  40eb07:	mov    rsi,QWORD PTR [rsp+0x20]
  40eb0c:	mov    rdx,QWORD PTR [rsp+0x28]
  40eb11:	xor    eax,eax
  40eb13:	call   41de20 <p125_rt_take3>
  40eb18:	mov    QWORD PTR [rbp-0x1158],rax
  40eb1f:	lea    r10,[rbp-0x850]
  40eb26:	mov    rdx,QWORD PTR [r10]
  40eb29:	lea    r10,[rbp-0x850]
  40eb30:	mov    rsi,QWORD PTR [r10+0x8]
  40eb34:	lea    r10,[rbp-0x850]
  40eb3b:	mov    rdi,QWORD PTR [r10+0x10]
  40eb3f:	lea    r10,[rbp-0x850]
  40eb46:	mov    r11,rsi
  40eb49:	mov    QWORD PTR [r10],r11
  40eb4c:	lea    r10,[rbp-0x850]
  40eb53:	mov    r11,rdi
  40eb56:	mov    QWORD PTR [r10+0x8],r11
  40eb5a:	mov    rdi,QWORD PTR [r12+0x10]
  40eb5f:	mov    QWORD PTR [rdi],rsi
  40eb62:	lea    r10,[rbp-0x850]
  40eb69:	mov    rsi,QWORD PTR [r10+0x8]
  40eb6d:	mov    QWORD PTR [rdi+0x8],rsi
  40eb71:	mov    r10,rdi
  40eb74:	movabs r11,0x48
  40eb7e:	mov    QWORD PTR [r10+0x10],r11
  40eb82:	add    rdi,0x18
  40eb89:	mov    QWORD PTR [r12+0x10],rdi
  40eb8e:	add    rbx,0x1
  40eb95:	lea    r10,[rbp-0x850]
  40eb9c:	mov    r11,rdx
  40eb9f:	mov    QWORD PTR [r10],r11
  40eba2:	lea    r10,[rbp-0x850]
  40eba9:	mov    r11,r13
  40ebac:	mov    QWORD PTR [r10+0x8],r11
  40ebb0:	mov    rsi,rdx
  40ebb3:	movabs r10,0x0
  40ebbd:	mov    rdi,r10
  40ebc0:	jmp    40e9a5 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3f>
  40ebc5:	lea    r10,[rbp-0x850]
  40ebcc:	mov    r11,r13
  40ebcf:	mov    QWORD PTR [r10],r11
  40ebd2:	mov    rdi,QWORD PTR [r12+0x10]
  40ebd7:	mov    QWORD PTR [rdi],r13
  40ebda:	mov    r10,rdi
  40ebdd:	movabs r11,0x49
  40ebe7:	mov    QWORD PTR [r10+0x8],r11
  40ebeb:	add    rdi,0x10
  40ebf2:	mov    QWORD PTR [r12+0x10],rdi
  40ebf7:	lea    r10,[rbp-0x850]
  40ebfe:	mov    r11,rsi
  40ec01:	mov    QWORD PTR [r10],r11
  40ec04:	mov    rdi,QWORD PTR [r12+0x10]
  40ec09:	mov    QWORD PTR [rdi],rsi
  40ec0c:	mov    r10,rdi
  40ec0f:	movabs r11,0x4a
  40ec19:	mov    QWORD PTR [r10+0x8],r11
  40ec1d:	mov    r10,rdi
  40ec20:	add    r10,0x10
  40ec27:	mov    QWORD PTR [rbp-0x11a8],r10
  40ec2e:	mov    r10,r12
  40ec31:	mov    r11,QWORD PTR [rbp-0x11a8]
  40ec38:	mov    QWORD PTR [r10+0x10],r11
  40ec3c:	mov    rdi,r12
  40ec3f:	movabs rsi,0x4
  40ec49:	mov    esi,esi
  40ec4b:	xor    eax,eax
  40ec4d:	call   4185b0 <p111_rt_fail>
  40ec52:	mov    QWORD PTR [rbp-0x11b0],rax
  40ec59:	mov    r12,QWORD PTR [rbp-0x10]
  40ec5d:	mov    rbx,QWORD PTR [rbp-0x8]
  40ec61:	mov    r13,QWORD PTR [rbp-0x18]
  40ec65:	mov    r14,QWORD PTR [rbp-0x20]
  40ec69:	mov    rsp,rbp
  40ec6c:	pop    rbp
  40ec6d:	ret    

