
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004036f0 <nx_rt_pair_rebuild2_c1_k0>:
  4036f0:	push   %r15
  4036f2:	push   %r14
  4036f4:	push   %r13
  4036f6:	push   %r12
  4036f8:	mov    %rdx,%r12
  4036fb:	push   %rbp
  4036fc:	push   %rbx
  4036fd:	movabs $0xffffffffff,%rbx
  403707:	and    %rsi,%rbx
  40370a:	lea    0x0(,%rbx,8),%rdx
  403712:	sub    $0x18,%rsp
  403716:	mov    (%rdi),%rbp
  403719:	mov    0x8(%rdi),%r15
  40371d:	lea    0x0(%rbp,%rdx,1),%rax
  403722:	test   %rsi,%rsi
  403725:	js     4037e0 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  40372b:	mov    (%rax),%r14
  40372e:	mov    0x8(%rbp,%rdx,1),%r13
  403733:	cmp    $0x310817f,%rbx
  40373a:	jbe    4037b0 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  40373c:	lea    0x0(%rbp,%rbx,8),%r8
  403741:	mov    %r14,%rax
  403744:	shr    $0x38,%rax
  403748:	and    $0x7f,%eax
  40374b:	cmp    $0x2,%rax
  40374f:	je     403790 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403751:	mov    %r12,%rax
  403754:	mov    %r14,(%r8)
  403757:	lea    0x8(%rbp,%rbx,8),%r14
  40375c:	shr    $0x38,%rax
  403760:	and    $0x7f,%eax
  403763:	cmp    $0x2,%rax
  403767:	je     4037a0 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403769:	movabs $0x200010000000000,%rax
  403773:	mov    %r12,(%r14)
  403776:	mov    %r13,%rdx
  403779:	add    $0x18,%rsp
  40377d:	or     %rbx,%rax
  403780:	pop    %rbx
  403781:	pop    %rbp
  403782:	pop    %r12
  403784:	pop    %r13
  403786:	pop    %r14
  403788:	pop    %r15
  40378a:	retq   
  40378b:	nopl   0x0(%rax,%rax,1)
  403790:	test   %r14,%r14
  403793:	js     403751 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403795:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  40379a:	nopw   0x0(%rax,%rax,1)
  4037a0:	test   %r12,%r12
  4037a3:	js     403769 <nx_rt_pair_rebuild2_c1_k0+0x79>
  4037a5:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  4037aa:	nopw   0x0(%rax,%rax,1)
  4037b0:	mov    0x8(%r15),%rbx
  4037b4:	test   %rbx,%rbx
  4037b7:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  4037bd:	lea    0x0(%rbp,%rbx,8),%r8
  4037c2:	mov    (%r8),%rax
  4037c5:	subq   $0x2,0x108(%r15)
  4037cd:	mov    %rax,0x8(%r15)
  4037d1:	jmpq   403741 <nx_rt_pair_rebuild2_c1_k0+0x51>
  4037d6:	nopw   %cs:0x0(%rax,%rax,1)
  4037e0:	mov    0x4(%rax),%edx
  4037e3:	mov    (%rax),%ecx
  4037e5:	shl    $0x20,%rdx
  4037e9:	or     %rcx,%rdx
  4037ec:	mov    %rdx,%rcx
  4037ef:	and    $0xffffff,%edx
  4037f5:	shr    $0x18,%rcx
  4037f9:	lea    0x8(,%rcx,8),%rdi
  403801:	lea    0x0(%rbp,%rdi,1),%r8
  403806:	lea    -0x8(%rbp,%rdi,1),%rdi
  40380b:	cmp    $0x1,%rdx
  40380f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403815:	mov    (%rax),%edx
  403817:	mov    (%r15),%rdx
  40381a:	mov    (%rdi),%r14
  40381d:	mov    (%r8),%r13
  403820:	mov    %rdx,(%rax)
  403823:	mov    0x100(%r15),%rax
  40382a:	mov    0x3d9a8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403830:	mov    %rbx,(%r15)
  403833:	add    $0x1,%rax
  403837:	mov    %rax,0x100(%r15)
  40383e:	cmp    %rdx,%rax
  403841:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403847:	mov    %rcx,%rbx
  40384a:	jmpq   403733 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
