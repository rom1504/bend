00000000004075e0 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_>:
  4075e0:	endbr64 
  4075e4:	push   rbp
  4075e5:	mov    rbp,rsp
  4075e8:	sub    rsp,0x48
  4075ec:	push   rbx
  4075ed:	push   r12
  4075ef:	push   r13
  4075f1:	push   r14
  4075f3:	push   r15
  4075f5:	mov    r15,r9
  4075f8:	mov    QWORD PTR [rbp-0x10],rsi
  4075fc:	nop    DWORD PTR [rax+0x0]
  407600:	mov    r12,rdx
  407603:	mov    r13,rcx
  407606:	cmp    r12,0x0
  40760a:	je     407909 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x329>
  407610:	cs cs cs mov rax,r8
  407616:	shr    rax,0x28
  40761a:	and    rax,0xffff
  407620:	cmp    rax,0xa4
  407626:	je     4078ea <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x30a>
  40762c:	cmp    rax,0xa5
  407632:	je     40765b <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x7b>
  407634:	mov    esi,0x4
  407639:	mov    rbx,rdi
  40763c:	call   412a70 <p111_rt_fail>
  407641:	mov    rdx,r12
  407644:	mov    rdi,rbx
  407647:	mov    rcx,r13
  40764a:	mov    r8d,0x0
  407650:	mov    r9d,0x0
  407656:	jmp    4078fd <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x31d>
  40765b:	mov    rdx,r12
  40765e:	mov    r12,rdx
  407661:	lea    rdx,[rbp-0x40]
  407665:	mov    rsi,r8
  407668:	mov    rbx,rdi
  40766b:	call   4182e0 <p125_rt_take3>
  407670:	mov    rcx,r13
  407673:	mov    rdx,r12
  407676:	mov    rdi,rbx
  407679:	mov    r8,QWORD PTR [rbp-0x40]
  40767d:	mov    r10,QWORD PTR [rbp-0x38]
  407681:	mov    r14,QWORD PTR [rbp-0x30]
  407685:	mov    r13,rcx
  407688:	mov    ecx,ecx
  40768a:	mov    eax,r10d
  40768d:	cmp    rcx,rax
  407690:	jb     4077c5 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x1e5>
  407696:	mov    QWORD PTR [rbp-0x28],r10
  40769a:	mov    QWORD PTR [rbp-0x20],r8
  40769e:	mov    QWORD PTR [rbp-0x18],0x0
  4076a6:	mov    r12,QWORD PTR [rdi+0x8]
  4076aa:	mov    rax,QWORD PTR [r12+0x10]
  4076af:	cmp    rax,0x0
  4076b3:	jne    4076dd <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0xfd>
  4076b5:	mov    r12,rdx
  4076b8:	lea    rdx,[rbp-0x28]
  4076bc:	mov    esi,0xa6
  4076c1:	mov    rbx,rdi
  4076c4:	call   418210 <p125_rt_ctor3>
  4076c9:	mov    r9,r15
  4076cc:	mov    rcx,r13
  4076cf:	mov    rdx,r12
  4076d2:	mov    rdi,rbx
  4076d5:	mov    r10,rax
  4076d8:	mov    r13,rcx
  4076db:	jmp    407732 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x152>
  4076dd:	mov    rcx,r13
  4076e0:	mov    r9,r15
  4076e3:	mov    rsi,QWORD PTR [rdi]
  4076e6:	mov    rbx,r8
  4076e9:	mov    r8,rax
  4076ec:	shl    r8,0x3
  4076f0:	mov    r13,QWORD PTR [rsi+r8*1]
  4076f4:	mov    r11,QWORD PTR [r12+0x110]
  4076fc:	mov    QWORD PTR [r12+0x10],r13
  407701:	sub    r11,0x4
  407705:	mov    QWORD PTR [r12+0x110],r11
  40770d:	mov    QWORD PTR [rsi+r8*1],r10
  407711:	mov    QWORD PTR [rsi+r8*1+0x8],rbx
  407716:	mov    QWORD PTR [rsi+r8*1+0x10],0x0
  40771f:	mov    r13,rcx
  407722:	movabs rcx,0x200a60000000000
  40772c:	mov    r10,rax
  40772f:	or     r10,rcx
  407732:	mov    QWORD PTR [rbp-0x28],r10
  407736:	mov    QWORD PTR [rbp-0x20],r9
  40773a:	mov    rbx,QWORD PTR [rdi+0x8]
  40773e:	mov    rax,QWORD PTR [rbx+0x8]
  407742:	cmp    rax,0x0
  407746:	jne    407770 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x190>
  407748:	mov    r12,rdx
  40774b:	lea    rdx,[rbp-0x28]
  40774f:	mov    esi,0x12
  407754:	mov    rbx,rdi
  407757:	call   417f90 <p125_rt_ctor2>
  40775c:	mov    r8,r14
  40775f:	mov    rcx,r13
  407762:	mov    rdx,r12
  407765:	mov    rdi,rbx
  407768:	mov    r9,rax
  40776b:	mov    r13,rcx
  40776e:	jmp    4077bd <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x1dd>
  407770:	cs cs cs cs mov rcx,r13
  407777:	mov    r8,r14
  40777a:	mov    rsi,QWORD PTR [rdi]
  40777d:	mov    r15,r9
  407780:	mov    r9,rax
  407783:	shl    r9,0x3
  407787:	mov    r12,QWORD PTR [rsi+r9*1]
  40778b:	mov    r11,QWORD PTR [rbx+0x108]
  407792:	mov    QWORD PTR [rbx+0x8],r12
  407796:	sub    r11,0x2
  40779a:	mov    QWORD PTR [rbx+0x108],r11
  4077a1:	mov    QWORD PTR [rsi+r9*1],r10
  4077a5:	mov    QWORD PTR [rsi+r9*1+0x8],r15
  4077aa:	mov    r13,rcx
  4077ad:	movabs rcx,0x200120000000000
  4077b7:	mov    r9,rax
  4077ba:	or     r9,rcx
  4077bd:	mov    rcx,r13
  4077c0:	jmp    4078fd <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x31d>
  4077c5:	xchg   r8,r14
  4077c8:	mov    QWORD PTR [rbp-0x28],r10
  4077cc:	mov    QWORD PTR [rbp-0x20],r8
  4077d0:	mov    QWORD PTR [rbp-0x18],0x1
  4077d8:	mov    r12,QWORD PTR [rdi+0x8]
  4077dc:	mov    rax,QWORD PTR [r12+0x10]
  4077e1:	cmp    rax,0x0
  4077e5:	jne    40780f <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x22f>
  4077e7:	mov    r12,rdx
  4077ea:	lea    rdx,[rbp-0x28]
  4077ee:	mov    esi,0xa6
  4077f3:	mov    rbx,rdi
  4077f6:	call   418210 <p125_rt_ctor3>
  4077fb:	mov    r9,r15
  4077fe:	mov    rcx,r13
  407801:	mov    rdx,r12
  407804:	mov    rdi,rbx
  407807:	mov    r11,rax
  40780a:	mov    r13,rcx
  40780d:	jmp    407864 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x284>
  40780f:	mov    rcx,r13
  407812:	mov    r9,r15
  407815:	mov    rsi,QWORD PTR [rdi]
  407818:	mov    rbx,r8
  40781b:	mov    r8,rax
  40781e:	shl    r8,0x3
  407822:	mov    r13,QWORD PTR [rsi+r8*1]
  407826:	mov    r11,QWORD PTR [r12+0x110]
  40782e:	mov    QWORD PTR [r12+0x10],r13
  407833:	sub    r11,0x4
  407837:	mov    QWORD PTR [r12+0x110],r11
  40783f:	mov    QWORD PTR [rsi+r8*1],r10
  407843:	mov    QWORD PTR [rsi+r8*1+0x8],rbx
  407848:	mov    QWORD PTR [rsi+r8*1+0x10],0x1
  407851:	mov    r13,rcx
  407854:	movabs rcx,0x200a60000000000
  40785e:	mov    r11,rax
  407861:	or     r11,rcx
  407864:	mov    QWORD PTR [rbp-0x28],r11
  407868:	mov    QWORD PTR [rbp-0x20],r9
  40786c:	mov    r12,QWORD PTR [rdi+0x8]
  407870:	mov    rax,QWORD PTR [r12+0x8]
  407875:	cmp    rax,0x0
  407879:	jne    4078a2 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x2c2>
  40787b:	cs cs mov r12,rdx
  407880:	lea    rdx,[rbp-0x28]
  407884:	mov    esi,0x12
  407889:	mov    rbx,rdi
  40788c:	call   417f90 <p125_rt_ctor2>
  407891:	mov    r8,r14
  407894:	mov    rcx,r13
  407897:	mov    rdx,r12
  40789a:	mov    rdi,rbx
  40789d:	mov    r9,rax
  4078a0:	jmp    4078fd <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x31d>
  4078a2:	mov    rcx,r13
  4078a5:	mov    r8,r14
  4078a8:	mov    rsi,QWORD PTR [rdi]
  4078ab:	mov    r10,rax
  4078ae:	shl    r10,0x3
  4078b2:	mov    r13,QWORD PTR [rsi+r10*1]
  4078b6:	mov    rbx,QWORD PTR [r12+0x108]
  4078be:	mov    QWORD PTR [r12+0x8],r13
  4078c3:	sub    rbx,0x2
  4078c7:	mov    QWORD PTR [r12+0x108],rbx
  4078cf:	mov    QWORD PTR [rsi+r10*1],r11
  4078d3:	mov    QWORD PTR [rsi+r10*1+0x8],r9
  4078d8:	movabs rsi,0x200120000000000
  4078e2:	mov    r9,rax
  4078e5:	or     r9,rsi
  4078e8:	jmp    4078fd <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x31d>
  4078ea:	mov    rdx,r12
  4078ed:	mov    rcx,r13
  4078f0:	mov    r9,r15
  4078f3:	movabs r8,0x100a40000000000
  4078fd:	sub    rdx,0x1
  407901:	mov    r15,r9
  407904:	jmp    407600 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x20>
  407909:	mov    rsi,QWORD PTR [rbp-0x10]
  40790d:	mov    QWORD PTR [rsi],r8
  407910:	mov    QWORD PTR [rsi+0x8],r15
  407914:	mov    eax,0x0
  407919:	pop    r15
  40791b:	pop    r14
  40791d:	pop    r13
  40791f:	pop    r12
  407921:	pop    rbx
  407922:	leave  
  407923:	ret    
  407924:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  40792f:	nop

