
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401d90 <nx_construct2>:
  401d90:	push   %r12
  401d92:	mov    %rcx,%rax
  401d95:	push   %rbp
  401d96:	shr    $0x38,%rax
  401d9a:	lea    0x0(,%r9,8),%rbp
  401da2:	push   %rbx
  401da3:	and    $0x7f,%eax
  401da6:	mov    %edx,%ebx
  401da8:	lea    (%rdi,%rbp,1),%r12
  401dac:	mov    %rcx,%rdx
  401daf:	sub    $0x20,%rsp
  401db3:	cmp    $0x2,%rax
  401db7:	je     401df0 <nx_construct2+0x60>
  401db9:	mov    %r8,%rax
  401dbc:	mov    %rdx,(%r12)
  401dc0:	lea    0x8(%rbp,%rdi,1),%rbp
  401dc5:	shr    $0x38,%rax
  401dc9:	and    $0x7f,%eax
  401dcc:	cmp    $0x2,%rax
  401dd0:	je     401e00 <nx_construct2+0x70>
  401dd2:	mov    %rbx,%rax
  401dd5:	mov    %r8,0x0(%rbp)
  401dd9:	add    $0x20,%rsp
  401ddd:	shl    $0x28,%rax
  401de1:	pop    %rbx
  401de2:	pop    %rbp
  401de3:	or     %r9,%rax
  401de6:	pop    %r12
  401de8:	bts    $0x39,%rax
  401ded:	retq   
  401dee:	xchg   %ax,%ax
  401df0:	test   %rcx,%rcx
  401df3:	js     401db9 <nx_construct2+0x29>
  401df5:	jmpq   401410 <nx_construct2.cold>
  401dfa:	nopw   0x0(%rax,%rax,1)
  401e00:	test   %r8,%r8
  401e03:	js     401dd2 <nx_construct2+0x42>
  401e05:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
