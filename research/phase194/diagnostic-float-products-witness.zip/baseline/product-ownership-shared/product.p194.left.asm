  408971:	push   %rbp
  408972:	mov    %rsp,%rbp
  408975:	sub    $0x8e0,%rsp
  40897c:	mov    %r12,-0x10(%rbp)
  408980:	mov    %rdi,%rax
  408983:	mov    %rax,%r12
  408986:	mov    %rsi,%rax
  408989:	mov    %rax,%rdi
  40898c:	mov    %rdx,%rax
  40898f:	mov    %rax,-0x38(%rbp)
  408993:	mov    %edi,%edi
  408995:	imul   $0x3,%edi,%edi
  40899b:	mov    %rdi,%rax
  40899e:	mov    -0x10(%rbp),%r12
  4089a2:	mov    %rbp,%rsp
  4089a5:	pop    %rbp
  4089a6:	retq   
