
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c50 <nx_string_reverse>:
  401c50:	push   %rbx
  401c51:	mov    %rdx,%rax
  401c54:	mov    %rdi,%rbx
  401c57:	nopw   0x0(%rax,%rax,1)
  401c60:	mov    %rsi,%rcx
  401c63:	shr    $0x28,%rcx
  401c67:	cmp    $0x3,%cx
  401c6b:	jne    401c7d <nx_string_reverse+0x2d>
  401c6d:	mov    %rbx,%rdi
  401c70:	mov    %rax,%rdx
  401c73:	callq  403850 <nx_rt_pair_rebuild2_c3_k0>
  401c78:	mov    %rdx,%rsi
  401c7b:	jmp    401c60 <nx_string_reverse+0x10>
  401c7d:	movzwl %cx,%ecx
  401c80:	cmp    $0x2,%ecx
  401c83:	jne    401c87 <nx_string_reverse+0x37>
  401c85:	pop    %rbx
  401c86:	retq   
  401c87:	mov    %rbx,%rdi
  401c8a:	mov    $0x1,%esi
  401c8f:	pop    %rbx
  401c90:	jmpq   402500 <nx_rt_fail>

Disassembly of section .fini:
