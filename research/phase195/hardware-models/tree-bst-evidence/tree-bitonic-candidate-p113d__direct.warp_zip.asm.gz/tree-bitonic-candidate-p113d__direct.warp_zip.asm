0000000000408309 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>:
  408309:	push   rbp
  40830a:	mov    rbp,rsp
  40830d:	sub    rsp,0x9e0
  408314:	mov    QWORD PTR [rbp-0x10],r12
  408318:	mov    QWORD PTR [rbp-0x8],rbx
  40831c:	mov    QWORD PTR [rbp-0x18],r13
  408320:	mov    QWORD PTR [rbp-0x20],r14
  408324:	mov    rax,rdi
  408327:	mov    r12,rax
  40832a:	mov    rax,rsi
  40832d:	mov    rsi,rax
  408330:	mov    rax,rdx
  408333:	mov    rbx,rax
  408336:	mov    rdi,rsi
  408339:	shr    rdi,0x28
  40833d:	and    rdi,0xffff
  408344:	movabs r11,0xa5
  40834e:	cmp    rdi,r11
  408351:	jne    4085dc <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x2d3>
  408357:	mov    r10,r12
  40835a:	mov    QWORD PTR [rsp+0x18],r10
  40835f:	mov    r10,rsi
  408362:	mov    QWORD PTR [rsp+0x20],r10
  408367:	lea    r10,[rbp-0x840]
  40836e:	mov    QWORD PTR [rsp+0x28],r10
  408373:	mov    rdi,QWORD PTR [rsp+0x18]
  408378:	mov    rsi,QWORD PTR [rsp+0x20]
  40837d:	mov    rdx,QWORD PTR [rsp+0x28]
  408382:	xor    eax,eax
  408384:	call   421d30 <p125_rt_take2>
  408389:	mov    QWORD PTR [rbp-0x8b0],rax
  408390:	lea    r10,[rbp-0x840]
  408397:	mov    r13,QWORD PTR [r10]
  40839a:	lea    r10,[rbp-0x840]
  4083a1:	mov    r14,QWORD PTR [r10+0x8]
  4083a5:	mov    rdi,rbx
  4083a8:	shr    rdi,0x28
  4083ac:	and    rdi,0xffff
  4083b3:	movabs r11,0xa5
  4083bd:	cmp    rdi,r11
  4083c0:	jne    4084c2 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x1b9>
  4083c6:	mov    rdi,r12
  4083c9:	mov    rsi,rbx
  4083cc:	lea    rdx,[rbp-0x840]
  4083d3:	xor    eax,eax
  4083d5:	call   421d30 <p125_rt_take2>
  4083da:	mov    QWORD PTR [rbp-0x8b0],rax
  4083e1:	lea    r10,[rbp-0x840]
  4083e8:	mov    rdi,QWORD PTR [r10]
  4083eb:	lea    r10,[rbp-0x840]
  4083f2:	mov    rbx,QWORD PTR [r10+0x8]
  4083f6:	lea    r10,[rbp-0x840]
  4083fd:	mov    r11,r13
  408400:	mov    QWORD PTR [r10],r11
  408403:	lea    r10,[rbp-0x840]
  40840a:	mov    r11,rdi
  40840d:	mov    QWORD PTR [r10+0x8],r11
  408411:	mov    rdi,r12
  408414:	movabs rsi,0xa5
  40841e:	mov    esi,esi
  408420:	lea    rdx,[rbp-0x840]
  408427:	xor    eax,eax
  408429:	call   421c40 <p125_rt_ctor2>
  40842e:	mov    rdi,rax
  408431:	mov    r13,rdi
  408434:	lea    r10,[rbp-0x840]
  40843b:	mov    r11,r14
  40843e:	mov    QWORD PTR [r10],r11
  408441:	lea    r10,[rbp-0x840]
  408448:	mov    r11,rbx
  40844b:	mov    QWORD PTR [r10+0x8],r11
  40844f:	mov    rdi,r12
  408452:	movabs rsi,0xa5
  40845c:	mov    esi,esi
  40845e:	lea    rdx,[rbp-0x840]
  408465:	xor    eax,eax
  408467:	call   421c40 <p125_rt_ctor2>
  40846c:	mov    rdi,rax
  40846f:	lea    r10,[rbp-0x840]
  408476:	mov    r11,r13
  408479:	mov    QWORD PTR [r10],r11
  40847c:	lea    r10,[rbp-0x840]
  408483:	mov    r11,rdi
  408486:	mov    QWORD PTR [r10+0x8],r11
  40848a:	mov    rdi,r12
  40848d:	movabs rsi,0xa5
  408497:	mov    esi,esi
  408499:	lea    rdx,[rbp-0x840]
  4084a0:	xor    eax,eax
  4084a2:	call   421c40 <p125_rt_ctor2>
  4084a7:	mov    rdi,rax
  4084aa:	mov    rax,rdi
  4084ad:	mov    r12,QWORD PTR [rbp-0x10]
  4084b1:	mov    rbx,QWORD PTR [rbp-0x8]
  4084b5:	mov    r13,QWORD PTR [rbp-0x18]
  4084b9:	mov    r14,QWORD PTR [rbp-0x20]
  4084bd:	mov    rsp,rbp
  4084c0:	pop    rbp
  4084c1:	ret    
  4084c2:	mov    rdi,r12
  4084c5:	mov    rsi,r13
  4084c8:	xor    eax,eax
  4084ca:	call   41bf90 <p111_rt_sink>
  4084cf:	mov    QWORD PTR [rbp-0x8b0],rax
  4084d6:	mov    rdi,r12
  4084d9:	mov    rsi,r14
  4084dc:	xor    eax,eax
  4084de:	call   41bf90 <p111_rt_sink>
  4084e3:	mov    QWORD PTR [rbp-0x8b0],rax
  4084ea:	mov    rdi,rbx
  4084ed:	shr    rdi,0x28
  4084f1:	and    rdi,0xffff
  4084f8:	movabs r11,0xa4
  408502:	cmp    rdi,r11
  408505:	jne    4085a0 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x297>
  40850b:	mov    rdi,rbx
  40850e:	shr    rdi,0x28
  408512:	and    rdi,0x7fffff
  408519:	movabs rsi,0xa4
  408523:	or     rsi,0x10000
  40852a:	cmp    rdi,rsi
  40852d:	jne    408555 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x24c>
  408533:	movabs r11,0xffffffffff
  40853d:	mov    rdi,rbx
  408540:	and    rdi,r11
  408543:	lea    r10,[rbp-0x840]
  40854a:	mov    r11,rdi
  40854d:	mov    QWORD PTR [r10],r11
  408550:	jmp    408570 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x267>
  408555:	mov    rdi,r12
  408558:	mov    rsi,rbx
  40855b:	lea    rdx,[rbp-0x840]
  408562:	xor    eax,eax
  408564:	call   421ab0 <p125_rt_take1>
  408569:	mov    QWORD PTR [rbp-0x8b0],rax
  408570:	lea    r10,[rbp-0x840]
  408577:	mov    r10,QWORD PTR [r10]
  40857a:	mov    QWORD PTR [rbp-0x910],r10
  408581:	movabs rax,0x100a40000000000
  40858b:	mov    r12,QWORD PTR [rbp-0x10]
  40858f:	mov    rbx,QWORD PTR [rbp-0x8]
  408593:	mov    r13,QWORD PTR [rbp-0x18]
  408597:	mov    r14,QWORD PTR [rbp-0x20]
  40859b:	mov    rsp,rbp
  40859e:	pop    rbp
  40859f:	ret    
  4085a0:	mov    rdi,r12
  4085a3:	movabs rsi,0x4
  4085ad:	mov    esi,esi
  4085af:	xor    eax,eax
  4085b1:	call   41c720 <p111_rt_fail>
  4085b6:	mov    QWORD PTR [rbp-0x8b0],rax
  4085bd:	movabs rax,0x0
  4085c7:	mov    r12,QWORD PTR [rbp-0x10]
  4085cb:	mov    rbx,QWORD PTR [rbp-0x8]
  4085cf:	mov    r13,QWORD PTR [rbp-0x18]
  4085d3:	mov    r14,QWORD PTR [rbp-0x20]
  4085d7:	mov    rsp,rbp
  4085da:	pop    rbp
  4085db:	ret    
  4085dc:	mov    rdi,rsi
  4085df:	shr    rdi,0x28
  4085e3:	and    rdi,0xffff
  4085ea:	movabs r11,0xa4
  4085f4:	cmp    rdi,r11
  4085f7:	jne    40882f <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x526>
  4085fd:	mov    rdi,rsi
  408600:	shr    rdi,0x28
  408604:	and    rdi,0x7fffff
  40860b:	movabs rdx,0xa4
  408615:	or     rdx,0x10000
  40861c:	cmp    rdi,rdx
  40861f:	jne    408647 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x33e>
  408625:	movabs r11,0xffffffffff
  40862f:	mov    rdi,rsi
  408632:	and    rdi,r11
  408635:	lea    r10,[rbp-0x840]
  40863c:	mov    r11,rdi
  40863f:	mov    QWORD PTR [r10],r11
  408642:	jmp    408680 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x377>
  408647:	mov    r10,r12
  40864a:	mov    QWORD PTR [rsp+0x18],r10
  40864f:	mov    r10,rsi
  408652:	mov    QWORD PTR [rsp+0x20],r10
  408657:	lea    r10,[rbp-0x840]
  40865e:	mov    QWORD PTR [rsp+0x28],r10
  408663:	mov    rdi,QWORD PTR [rsp+0x18]
  408668:	mov    rsi,QWORD PTR [rsp+0x20]
  40866d:	mov    rdx,QWORD PTR [rsp+0x28]
  408672:	xor    eax,eax
  408674:	call   421ab0 <p125_rt_take1>
  408679:	mov    QWORD PTR [rbp-0x8b0],rax
  408680:	lea    r10,[rbp-0x840]
  408687:	mov    r10,QWORD PTR [r10]
  40868a:	mov    QWORD PTR [rbp-0x940],r10
  408691:	mov    rdi,rbx
  408694:	shr    rdi,0x28
  408698:	and    rdi,0xffff
  40869f:	movabs r11,0xa5
  4086a9:	cmp    rdi,r11
  4086ac:	jne    40873d <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x434>
  4086b2:	mov    rdi,r12
  4086b5:	mov    rsi,rbx
  4086b8:	lea    rdx,[rbp-0x840]
  4086bf:	xor    eax,eax
  4086c1:	call   421d30 <p125_rt_take2>
  4086c6:	mov    QWORD PTR [rbp-0x8b0],rax
  4086cd:	lea    r10,[rbp-0x840]
  4086d4:	mov    rdi,QWORD PTR [r10]
  4086d7:	lea    r10,[rbp-0x840]
  4086de:	mov    rbx,QWORD PTR [r10+0x8]
  4086e2:	mov    r10,r12
  4086e5:	mov    QWORD PTR [rsp+0x10],r10
  4086ea:	mov    r10,rdi
  4086ed:	mov    QWORD PTR [rsp+0x18],r10
  4086f2:	mov    rdi,QWORD PTR [rsp+0x10]
  4086f7:	mov    rsi,QWORD PTR [rsp+0x18]
  4086fc:	xor    eax,eax
  4086fe:	call   41bf90 <p111_rt_sink>
  408703:	mov    QWORD PTR [rbp-0x8b0],rax
  40870a:	mov    rdi,r12
  40870d:	mov    rsi,rbx
  408710:	xor    eax,eax
  408712:	call   41bf90 <p111_rt_sink>
  408717:	mov    QWORD PTR [rbp-0x8b0],rax
  40871e:	movabs rax,0x100a40000000000
  408728:	mov    r12,QWORD PTR [rbp-0x10]
  40872c:	mov    rbx,QWORD PTR [rbp-0x8]
  408730:	mov    r13,QWORD PTR [rbp-0x18]
  408734:	mov    r14,QWORD PTR [rbp-0x20]
  408738:	mov    rsp,rbp
  40873b:	pop    rbp
  40873c:	ret    
  40873d:	mov    rdi,rbx
  408740:	shr    rdi,0x28
  408744:	and    rdi,0xffff
  40874b:	movabs r11,0xa4
  408755:	cmp    rdi,r11
  408758:	jne    4087f3 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x4ea>
  40875e:	mov    rdi,rbx
  408761:	shr    rdi,0x28
  408765:	and    rdi,0x7fffff
  40876c:	movabs rsi,0xa4
  408776:	or     rsi,0x10000
  40877d:	cmp    rdi,rsi
  408780:	jne    4087a8 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x49f>
  408786:	movabs r11,0xffffffffff
  408790:	mov    rdi,rbx
  408793:	and    rdi,r11
  408796:	lea    r10,[rbp-0x840]
  40879d:	mov    r11,rdi
  4087a0:	mov    QWORD PTR [r10],r11
  4087a3:	jmp    4087c3 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x4ba>
  4087a8:	mov    rdi,r12
  4087ab:	mov    rsi,rbx
  4087ae:	lea    rdx,[rbp-0x840]
  4087b5:	xor    eax,eax
  4087b7:	call   421ab0 <p125_rt_take1>
  4087bc:	mov    QWORD PTR [rbp-0x8b0],rax
  4087c3:	lea    r10,[rbp-0x840]
  4087ca:	mov    r10,QWORD PTR [r10]
  4087cd:	mov    QWORD PTR [rbp-0x980],r10
  4087d4:	movabs rax,0x100a40000000000
  4087de:	mov    r12,QWORD PTR [rbp-0x10]
  4087e2:	mov    rbx,QWORD PTR [rbp-0x8]
  4087e6:	mov    r13,QWORD PTR [rbp-0x18]
  4087ea:	mov    r14,QWORD PTR [rbp-0x20]
  4087ee:	mov    rsp,rbp
  4087f1:	pop    rbp
  4087f2:	ret    
  4087f3:	mov    rdi,r12
  4087f6:	movabs rsi,0x4
  408800:	mov    esi,esi
  408802:	xor    eax,eax
  408804:	call   41c720 <p111_rt_fail>
  408809:	mov    QWORD PTR [rbp-0x8b0],rax
  408810:	movabs rax,0x0
  40881a:	mov    r12,QWORD PTR [rbp-0x10]
  40881e:	mov    rbx,QWORD PTR [rbp-0x8]
  408822:	mov    r13,QWORD PTR [rbp-0x18]
  408826:	mov    r14,QWORD PTR [rbp-0x20]
  40882a:	mov    rsp,rbp
  40882d:	pop    rbp
  40882e:	ret    
  40882f:	mov    rdi,r12
  408832:	movabs rsi,0x4
  40883c:	mov    esi,esi
  40883e:	xor    eax,eax
  408840:	call   41c720 <p111_rt_fail>
  408845:	mov    QWORD PTR [rbp-0x8b0],rax
  40884c:	movabs rax,0x0
  408856:	mov    r12,QWORD PTR [rbp-0x10]
  40885a:	mov    rbx,QWORD PTR [rbp-0x8]
  40885e:	mov    r13,QWORD PTR [rbp-0x18]
  408862:	mov    r14,QWORD PTR [rbp-0x20]
  408866:	mov    rsp,rbp
  408869:	pop    rbp
  40886a:	ret    

