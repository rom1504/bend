
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403b30 <nx_rt_pair_rebuild2_c1_k0>:
  403b30:	push   %r15
  403b32:	push   %r14
  403b34:	push   %r13
  403b36:	push   %r12
  403b38:	mov    %rdx,%r12
  403b3b:	push   %rbp
  403b3c:	push   %rbx
  403b3d:	movabs $0xffffffffff,%rbx
  403b47:	and    %rsi,%rbx
  403b4a:	lea    0x0(,%rbx,8),%rdx
  403b52:	sub    $0x18,%rsp
  403b56:	mov    (%rdi),%rbp
  403b59:	mov    0x8(%rdi),%r15
  403b5d:	lea    0x0(%rbp,%rdx,1),%rax
  403b62:	test   %rsi,%rsi
  403b65:	js     403c20 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  403b6b:	mov    (%rax),%r14
  403b6e:	mov    0x8(%rbp,%rdx,1),%r13
  403b73:	cmp    $0x310817f,%rbx
  403b7a:	jbe    403bf0 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  403b7c:	lea    0x0(%rbp,%rbx,8),%r8
  403b81:	mov    %r14,%rax
  403b84:	shr    $0x38,%rax
  403b88:	and    $0x7f,%eax
  403b8b:	cmp    $0x2,%rax
  403b8f:	je     403bd0 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403b91:	mov    %r12,%rax
  403b94:	mov    %r14,(%r8)
  403b97:	lea    0x8(%rbp,%rbx,8),%r14
  403b9c:	shr    $0x38,%rax
  403ba0:	and    $0x7f,%eax
  403ba3:	cmp    $0x2,%rax
  403ba7:	je     403be0 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403ba9:	movabs $0x200010000000000,%rax
  403bb3:	mov    %r12,(%r14)
  403bb6:	mov    %r13,%rdx
  403bb9:	add    $0x18,%rsp
  403bbd:	or     %rbx,%rax
  403bc0:	pop    %rbx
  403bc1:	pop    %rbp
  403bc2:	pop    %r12
  403bc4:	pop    %r13
  403bc6:	pop    %r14
  403bc8:	pop    %r15
  403bca:	retq   
  403bcb:	nopl   0x0(%rax,%rax,1)
  403bd0:	test   %r14,%r14
  403bd3:	js     403b91 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403bd5:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  403bda:	nopw   0x0(%rax,%rax,1)
  403be0:	test   %r12,%r12
  403be3:	js     403ba9 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403be5:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  403bea:	nopw   0x0(%rax,%rax,1)
  403bf0:	mov    0x8(%r15),%rbx
  403bf4:	test   %rbx,%rbx
  403bf7:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  403bfd:	lea    0x0(%rbp,%rbx,8),%r8
  403c02:	mov    (%r8),%rax
  403c05:	subq   $0x2,0x108(%r15)
  403c0d:	mov    %rax,0x8(%r15)
  403c11:	jmpq   403b81 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403c16:	nopw   %cs:0x0(%rax,%rax,1)
  403c20:	mov    0x4(%rax),%edx
  403c23:	mov    (%rax),%ecx
  403c25:	shl    $0x20,%rdx
  403c29:	or     %rcx,%rdx
  403c2c:	mov    %rdx,%rcx
  403c2f:	and    $0xffffff,%edx
  403c35:	shr    $0x18,%rcx
  403c39:	lea    0x8(,%rcx,8),%rdi
  403c41:	lea    0x0(%rbp,%rdi,1),%r8
  403c46:	lea    -0x8(%rbp,%rdi,1),%rdi
  403c4b:	cmp    $0x1,%rdx
  403c4f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403c55:	mov    (%rax),%edx
  403c57:	mov    (%r15),%rdx
  403c5a:	mov    (%rdi),%r14
  403c5d:	mov    (%r8),%r13
  403c60:	mov    %rdx,(%rax)
  403c63:	mov    0x100(%r15),%rax
  403c6a:	mov    0x3e568(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403c70:	mov    %rbx,(%r15)
  403c73:	add    $0x1,%rax
  403c77:	mov    %rax,0x100(%r15)
  403c7e:	cmp    %rdx,%rax
  403c81:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403c87:	mov    %rcx,%rbx
  403c8a:	jmpq   403b73 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
