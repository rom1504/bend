
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402a00 <nx_rt_fast_id>:
  402a00:	shr    $0x28,%rsi
  402a04:	movzwl %si,%eax
  402a07:	retq   

Disassembly of section .fini:
