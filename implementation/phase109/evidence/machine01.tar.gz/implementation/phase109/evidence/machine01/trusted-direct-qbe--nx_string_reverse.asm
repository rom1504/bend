
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401920 <nx_string_reverse>:
  401920:	endbr64 
  401924:	push   %rbp
  401925:	mov    %rsp,%rbp
  401928:	sub    $0x8,%rsp
  40192c:	push   %rbx
  40192d:	push   %r12
  40192f:	push   %r13
  401931:	mov    %rdx,%rax
  401934:	mov    %rax,%rbx
  401937:	nopw   0x0(%rax,%rax,1)
  401940:	mov    %rsi,%r13
  401943:	mov    %rdi,%r12
  401946:	callq  402730 <nx_rt_fast_id>
  40194b:	mov    %r13,%rsi
  40194e:	mov    %r12,%rdi
  401951:	cmp    $0x2,%eax
  401954:	je     4019bc <nx_string_reverse+0x9c>
  401956:	cmp    $0x3,%eax
  401959:	jne    4019b0 <nx_string_reverse+0x90>
  40195b:	mov    %rdi,%r12
  40195e:	callq  4028c0 <nx_rt_fast_take2>
  401963:	mov    %r12,%rdi
  401966:	mov    $0x0,%esi
  40196b:	mov    %rdi,%r12
  40196e:	callq  4029e0 <nx_rt_fast_field>
  401973:	mov    %r12,%rdi
  401976:	mov    %rax,%r13
  401979:	mov    $0x1,%esi
  40197e:	mov    %rdi,%r12
  401981:	callq  4029e0 <nx_rt_fast_field>
  401986:	mov    %r13,%rdx
  401989:	mov    %r12,%rdi
  40198c:	mov    %rax,%rsi
  40198f:	mov    %rbx,%rcx
  401992:	mov    %rsi,%r12
  401995:	mov    $0x3,%esi
  40199a:	mov    %rdi,%rbx
  40199d:	callq  402810 <nx_rt_fast_build2>
  4019a2:	mov    %r12,%rsi
  4019a5:	mov    %rbx,%rdi
  4019a8:	mov    %rax,%rdx
  4019ab:	mov    %rdx,%rbx
  4019ae:	jmp    401940 <nx_string_reverse+0x20>
  4019b0:	mov    $0x1,%esi
  4019b5:	callq  402230 <nx_rt_fail>
  4019ba:	jmp    4019bf <nx_string_reverse+0x9f>
  4019bc:	mov    %rbx,%rax
  4019bf:	pop    %r13
  4019c1:	pop    %r12
  4019c3:	pop    %rbx
  4019c4:	leaveq 
  4019c5:	retq   

Disassembly of section .fini:
