
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402550 <nx_rt_take2>:
  402550:	push   %r13
  402552:	push   %r12
  402554:	sub    $0x8,%rsp
  402558:	cmpb   $0x0,0x4c21(%rip)        # 407180 <nx_active>
  40255f:	je     40256d <nx_rt_take2+0x1d>
  402561:	lea    0x4c38(%rip),%rax        # 4071a0 <nx_context>
  402568:	cmp    %rax,%rdi
  40256b:	je     402580 <nx_rt_take2+0x30>
  40256d:	lea    0x1abf(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402574:	callq  4019f0 <err_fail>
  402579:	nopl   0x0(%rax)
  402580:	mov    0x4c3a(%rip),%eax        # 4071c0 <nx_context+0x20>
  402586:	mov    0x4c13(%rip),%rdi        # 4071a0 <nx_context>
  40258d:	test   %eax,%eax
  40258f:	jne    4026c9 <nx_rt_take2+0x179>
  402595:	mov    %rsi,%r12
  402598:	callq  401b20 <nx_id.isra.0>
  40259d:	and    $0xfffffffd,%eax
  4025a0:	cmp    $0x1,%eax
  4025a3:	jne    4026bd <nx_rt_take2+0x16d>
  4025a9:	mov    0x4bf0(%rip),%rdi        # 4071a0 <nx_context>
  4025b0:	mov    0x4bf1(%rip),%rsi        # 4071a8 <nx_context+0x8>
  4025b7:	movabs $0xffffffffff,%rax
  4025c1:	and    %r12,%rax
  4025c4:	lea    0x0(,%rax,8),%rcx
  4025cc:	lea    (%rdi,%rcx,1),%rdx
  4025d0:	test   %r12,%r12
  4025d3:	js     402640 <nx_rt_take2+0xf0>
  4025d5:	mov    (%rdx),%rdx
  4025d8:	mov    %rdx,0x4bd1(%rip)        # 4071b0 <nx_context+0x10>
  4025df:	mov    0x8(%rdi,%rcx,1),%rdx
  4025e4:	mov    %rdx,0x4bcd(%rip)        # 4071b8 <nx_context+0x18>
  4025eb:	cmp    $0x310817f,%rax
  4025f1:	ja     402610 <nx_rt_take2+0xc0>
  4025f3:	movl   $0x3,0x4bc3(%rip)        # 4071c0 <nx_context+0x20>
  4025fd:	add    $0x8,%rsp
  402601:	xor    %eax,%eax
  402603:	pop    %r12
  402605:	pop    %r13
  402607:	retq   
  402608:	nopl   0x0(%rax,%rax,1)
  402610:	mov    0x8(%rsi),%rdx
  402614:	mov    %rdx,(%rdi,%rax,8)
  402618:	mov    0x4bba(%rip),%edx        # 4071d8 <KEEP_WORDS>
  40261e:	mov    %rax,0x8(%rsi)
  402622:	mov    0x108(%rsi),%rax
  402629:	add    $0x2,%rax
  40262d:	mov    %rax,0x108(%rsi)
  402634:	cmp    %rdx,%rax
  402637:	jb     4025f3 <nx_rt_take2+0xa3>
  402639:	jmpq   401567 <nx_rt_take2.cold>
  40263e:	xchg   %ax,%ax
  402640:	mov    0x4(%rdx),%ecx
  402643:	mov    (%rdx),%r8d
  402646:	shl    $0x20,%rcx
  40264a:	or     %r8,%rcx
  40264d:	mov    %rcx,%r13
  402650:	and    $0xffffff,%ecx
  402656:	shr    $0x18,%r13
  40265a:	lea    0x0(,%r13,8),%r8
  402662:	lea    (%rdi,%r8,1),%r9
  402666:	lea    0x8(%rdi,%r8,1),%r8
  40266b:	cmp    $0x1,%rcx
  40266f:	jne    401582 <nx_rt_take2.cold+0x1b>
  402675:	mov    (%rdx),%ecx
  402677:	mov    (%r9),%rcx
  40267a:	mov    %rcx,0x4b2f(%rip)        # 4071b0 <nx_context+0x10>
  402681:	mov    (%r8),%rcx
  402684:	mov    %rcx,0x4b2d(%rip)        # 4071b8 <nx_context+0x18>
  40268b:	mov    (%rsi),%rcx
  40268e:	mov    %rcx,(%rdx)
  402691:	mov    0x4b41(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402697:	mov    %rax,(%rsi)
  40269a:	mov    0x100(%rsi),%rax
  4026a1:	add    $0x1,%rax
  4026a5:	mov    %rax,0x100(%rsi)
  4026ac:	cmp    %rdx,%rax
  4026af:	jae    401576 <nx_rt_take2.cold+0xf>
  4026b5:	mov    %r13,%rax
  4026b8:	jmpq   4025eb <nx_rt_take2+0x9b>
  4026bd:	lea    0x1c54(%rip),%rdi        # 404318 <_IO_stdin_used+0x318>
  4026c4:	callq  4019f0 <err_fail>
  4026c9:	lea    0x1c20(%rip),%rdi        # 4042f0 <_IO_stdin_used+0x2f0>
  4026d0:	callq  4019f0 <err_fail>

Disassembly of section .fini:
