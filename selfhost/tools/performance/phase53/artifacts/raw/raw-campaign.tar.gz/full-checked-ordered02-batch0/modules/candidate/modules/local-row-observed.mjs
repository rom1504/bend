// Direct JavaScript backend runtime. Generated output embeds this fragment.
// Ported from bend2/comp.ts NATIVE.JS, RUNTIME and RUNTIME_MAIN, and
// bend2/bend.ts f32_round at fixed upstream commit
// 018751270e800bc222a93dad7f257083ee53a5f7. The reference files stay unchanged.
// No TypeScript compiler/runtime dependency is used by ordinary compilation.
// Number is the internal Nat representation; nat_host handles typed host input.
// Node foreign IO requires the host emitter to provide an ESM require binding.
// Bun/system calls remain lazy, exactly as in the pinned upstream runtime.

function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  // Avoid an intermediate JS array: its cold element-kind transition can
  // canonicalize a Number NaN and discard a payload on only one conversion.
  // Fresh storage keeps nested host coercions independent; the store coerces once.
  const f = new Float32Array(1);
  f[0] = x;
  return new Uint32Array(f.buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}
// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, String(io_sys().strerror(code))) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    for (;;) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io);
        continue;
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

// Direct core names. A named tail call carries all already-evaluated arguments;
// run_tail above retains the upstream unary native-closure protocol unchanged.
const jd_run = run_loop;
const jd_clo = run_clo;
function jd_tail(f, args) {
  return {$: "$JMP", f, x: args};
}


// Direct JavaScript prototype: native functions and live arguments.
function $jd$b2u($a0){for(;;){{const $match1=$a0;if(!$match1){return 0;}else{{const $match2=$match1;return 1;}}}}}
function $jd$prng($a0){for(;;){const $x3419=$a0;{const $ord0=((13 >= 32 ? 0 : ((
/*JD_USE:3419*/$x3419) << 13) >>> 0));const $let0=((((
/*JD_USE:3419*/$x3419) ^ $ord0) >>> 0));{const $x3420=$let0;{const $ord0=((17 >= 32 ? 0 : ((
/*JD_USE:3420*/$x3420) >>> 17) >>> 0));const $let0=((((
/*JD_USE:3420*/$x3420) ^ $ord0) >>> 0));{const $x3421=$let0;{const $ord0=((5 >= 32 ? 0 : ((
/*JD_USE:3421*/$x3421) << 5) >>> 0));return ((((
/*JD_USE:3421*/$x3421) ^ $ord0) >>> 0));}}}}}}}
function $jd$umin_46_go($a0,$a1,$a2){for(;;){const $x3425=$a0;const $x3426=$a1;{const $match3=$a2;if($match3){return (
/*JD_USE:3425*/$x3425);}else{{const $match4=$match3;return (
/*JD_USE:3426*/$x3426);}}}}}
function $jd$umin($a0,$a1){for(;;){const $x3429=$a0;const $x3430=$a1;return (
/*JD_REF:$jd$umin_46_go*/$jd$umin_46_go((
/*JD_USE:3429*/$x3429),(
/*JD_USE:3430*/$x3430),(((
/*JD_USE:3429*/$x3429) < (
/*JD_USE:3430*/$x3430)))));}}
function $jd$gen($a0,$a1,$a2,$a3){for(;;){{const $match1=$a0;if($match1===0){const $x3437=$a3;return (
/*JD_USE:3437*/$x3437);}else{const $x3438=($match1-1);const $x3439=$a1;const $x3440=$a2;const $x3441=$a3;{const $let0=(
/*JD_REF:$jd$prng*/$jd$prng((
/*JD_USE:3440*/$x3440)));{const $x3442=$let0;{const $ord0=((((
/*JD_USE:3442*/$x3442) & 3) >>> 0));{
/*JD_REF:$jd$gen*/const $next0=(
/*JD_USE:3438*/$x3438);const $next1=((((
/*JD_USE:3439*/$x3439) + 1) >>> 0));const $next2=(
/*JD_USE:3442*/$x3442);const $next3=(((
/*JD_USE:3441*/$x3441)[(
/*JD_USE:3439*/$x3439) % (
/*JD_USE:3441*/$x3441).length] = $ord0, (
/*JD_USE:3441*/$x3441)));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;continue;}}}}}}}}
function $jd$init($a0,$a1,$a2){for(;;){{const $match1=$a0;if($match1===0){const $x3447=$a2;return (
/*JD_USE:3447*/$x3447);}else{const $x3448=($match1-1);const $x3449=$a1;const $x3450=$a2;{
/*JD_REF:$jd$init*/const $next0=(
/*JD_USE:3448*/$x3448);const $next1=((((
/*JD_USE:3449*/$x3449) + 1) >>> 0));const $next2=(((
/*JD_USE:3450*/$x3450)[(
/*JD_USE:3449*/$x3449) % (
/*JD_USE:3450*/$x3450).length] = (
/*JD_USE:3449*/$x3449), (
/*JD_USE:3450*/$x3450)));$a0=$next0;$a1=$next1;$a2=$next2;continue;}}}}}
function $jd$cell_46_f4($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7){for(;;){const $x3459=$a0;const $x3460=$a1;const $x3461=$a2;const $x3462=$a3;const $x3463=$a4;const $x3464=$a5;const $x3465=$a6;{const $match8=$a7;const $x3466=$match8["fst"];const $x3467=$match8["snd"];{const $let0=(
/*JD_REF:$jd$umin*/$jd$umin((
/*JD_REF:$jd$umin*/$jd$umin(((((
/*JD_USE:3462*/$x3462) + 1) >>> 0)),((((
/*JD_USE:3467*/$x3467) + 1) >>> 0)))),((((
/*JD_USE:3461*/$x3461) + (
/*JD_USE:3460*/$x3460)) >>> 0))));{const $x3468=$let0;{const $ord0=((((
/*JD_USE:3459*/$x3459) + 1) >>> 0));return ({$:"Dp",["a"]:(
/*JD_USE:3463*/$x3463),["b"]:(
/*JD_USE:3464*/$x3464),["prev"]:(
/*JD_USE:3465*/$x3465),["cur"]:(((
/*JD_USE:3466*/$x3466)[$ord0 % (
/*JD_USE:3466*/$x3466).length] = (
/*JD_USE:3468*/$x3468), (
/*JD_USE:3466*/$x3466)))});}}}}}}
function $jd$cell_46_f3($a0,$a1,$a2,$a3,$a4,$a5,$a6){for(;;){const $x3476=$a0;const $x3477=$a1;const $x3478=$a2;const $x3479=$a3;const $x3480=$a4;const $x3481=$a5;{const $match7=$a6;const $x3482=$match7["fst"];const $x3483=$match7["snd"];return (
/*JD_REF:$jd$cell_46_f4*/$jd$cell_46_f4((
/*JD_USE:3476*/$x3476),(
/*JD_USE:3477*/$x3477),(
/*JD_USE:3478*/$x3478),(
/*JD_USE:3483*/$x3483),(
/*JD_USE:3479*/$x3479),(
/*JD_USE:3480*/$x3480),(
/*JD_USE:3482*/$x3482),({$: "Tuple", fst: (
/*JD_USE:3481*/$x3481), snd: (
/*JD_USE:3481*/$x3481)[(
/*JD_USE:3476*/$x3476) % (
/*JD_USE:3481*/$x3481).length]})));}}}
function $jd$cell_46_f2($a0,$a1,$a2,$a3,$a4,$a5){for(;;){const $x3490=$a0;const $x3491=$a1;const $x3492=$a2;const $x3493=$a3;const $x3494=$a4;{const $match6=$a5;const $x3495=$match6["fst"];const $x3496=$match6["snd"];{const $ord0=((((
/*JD_USE:3490*/$x3490) + 1) >>> 0));return (
/*JD_REF:$jd$cell_46_f3*/$jd$cell_46_f3((
/*JD_USE:3490*/$x3490),(
/*JD_USE:3491*/$x3491),(
/*JD_USE:3496*/$x3496),(
/*JD_USE:3492*/$x3492),(
/*JD_USE:3493*/$x3493),(
/*JD_USE:3494*/$x3494),({$: "Tuple", fst: (
/*JD_USE:3495*/$x3495), snd: (
/*JD_USE:3495*/$x3495)[$ord0 % (
/*JD_USE:3495*/$x3495).length]})));}}}}
function $jd$cell_46_f1($a0,$a1,$a2,$a3,$a4,$a5){for(;;){const $x3503=$a0;const $x3504=$a1;const $x3505=$a2;const $x3506=$a3;const $x3507=$a4;{const $match6=$a5;const $x3508=$match6["fst"];const $x3509=$match6["snd"];return (
/*JD_REF:$jd$cell_46_f2*/$jd$cell_46_f2((
/*JD_USE:3503*/$x3503),(
/*JD_REF:$jd$b2u*/$jd$b2u((((
/*JD_USE:3504*/$x3504) !== (
/*JD_USE:3509*/$x3509))))),(
/*JD_USE:3505*/$x3505),(
/*JD_USE:3508*/$x3508),(
/*JD_USE:3507*/$x3507),({$: "Tuple", fst: (
/*JD_USE:3506*/$x3506), snd: (
/*JD_USE:3506*/$x3506)[(
/*JD_USE:3503*/$x3503) % (
/*JD_USE:3506*/$x3506).length]})));}}}
function $jd$cell($a0,$a1,$a2){for(;;){const $x3513=$a0;const $x3514=$a1;{const $match3=$a2;const $x3515=$match3["a"];const $x3516=$match3["b"];const $x3517=$match3["prev"];const $x3518=$match3["cur"];return (
/*JD_REF:$jd$cell_46_f1*/$jd$cell_46_f1((
/*JD_USE:3513*/$x3513),(
/*JD_USE:3514*/$x3514),(
/*JD_USE:3515*/$x3515),(
/*JD_USE:3517*/$x3517),(
/*JD_USE:3518*/$x3518),({$: "Tuple", fst: (
/*JD_USE:3516*/$x3516), snd: (
/*JD_USE:3516*/$x3516)[(
/*JD_USE:3513*/$x3513) % (
/*JD_USE:3516*/$x3516).length]})));}}}
function $jd$row($a0,$a1,$a2,$a3){for(;;){{const $match1=$a0;if($match1===0){{const $match4=$a3;const $x3525=$match4["a"];const $x3526=$match4["b"];const $x3527=$match4["prev"];const $x3528=$match4["cur"];return ({$:"Dp",["a"]:(
/*JD_USE:3525*/$x3525),["b"]:(
/*JD_USE:3526*/$x3526),["prev"]:(
/*JD_USE:3528*/$x3528),["cur"]:(
/*JD_USE:3527*/$x3527)});}}else{const $x3529=($match1-1);const $x3530=$a1;const $x3531=$a2;const $x3532=$a3;{
/*JD_REF:$jd$row*/const $next0=(
/*JD_USE:3529*/$x3529);const $next1=((((
/*JD_USE:3530*/$x3530) + 1) >>> 0));const $next2=(
/*JD_USE:3531*/$x3531);const $next3=(
/*JD_REF:$jd$cell*/$jd$cell((
/*JD_USE:3530*/$x3530),(
/*JD_USE:3531*/$x3531),(
/*JD_USE:3532*/$x3532)));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;continue;}}}}}
function $jd$dp_46_f1($a0,$a1,$a2,$a3,$a4){for(;;){const $x3538=$a0;const $x3539=$a1;const $x3540=$a2;const $x3541=$a3;{const $match5=$a4;const $x3542=$match5["fst"];const $x3543=$match5["snd"];{const $ord0=((((
/*JD_USE:3538*/$x3538) + 1) >>> 0));return (
/*JD_REF:$jd$row*/$jd$row(256,0,(
/*JD_USE:3543*/$x3543),({$:"Dp",["a"]:(
/*JD_USE:3542*/$x3542),["b"]:(
/*JD_USE:3539*/$x3539),["prev"]:(
/*JD_USE:3540*/$x3540),["cur"]:(((
/*JD_USE:3541*/$x3541)[0 % (
/*JD_USE:3541*/$x3541).length] = $ord0, (
/*JD_USE:3541*/$x3541)))})));}}}}
function $jd$dp_46_row($a0,$a1){for(;;){const $x3546=$a0;{const $match2=$a1;const $x3547=$match2["a"];const $x3548=$match2["b"];const $x3549=$match2["prev"];const $x3550=$match2["cur"];return (
/*JD_REF:$jd$dp_46_f1*/$jd$dp_46_f1((
/*JD_USE:3546*/$x3546),(
/*JD_USE:3548*/$x3548),(
/*JD_USE:3549*/$x3549),(
/*JD_USE:3550*/$x3550),({$: "Tuple", fst: (
/*JD_USE:3547*/$x3547), snd: (
/*JD_USE:3547*/$x3547)[(
/*JD_USE:3546*/$x3546) % (
/*JD_USE:3547*/$x3547).length]})));}}}
function $jd$dp($a0,$a1,$a2){for(;;){{const $match1=$a0;if($match1===0){const $x3555=$a2;return (
/*JD_USE:3555*/$x3555);}else{const $x3556=($match1-1);const $x3557=$a1;const $x3558=$a2;{
/*JD_REF:$jd$dp*/const $next0=(
/*JD_USE:3556*/$x3556);const $next1=((((
/*JD_USE:3557*/$x3557) + 1) >>> 0));const $next2=(
/*JD_REF:$jd$dp_46_row*/$jd$dp_46_row((
/*JD_USE:3557*/$x3557),(
/*JD_USE:3558*/$x3558)));$a0=$next0;$a1=$next1;$a2=$next2;continue;}}}}}
function $jd$dist_46_fin($a0){for(;;){{const $match1=$a0;const $x3561=$match1["snd"];return (
/*JD_USE:3561*/$x3561);}}}
function $jd$dist($a0){for(;;){{const $match1=$a0;const $x3565=$match1["prev"];return (
/*JD_REF:$jd$dist_46_fin*/$jd$dist_46_fin(({$: "Tuple", fst: (
/*JD_USE:3565*/$x3565), snd: (
/*JD_USE:3565*/$x3565)[256 % (
/*JD_USE:3565*/$x3565).length]})));}}}
function $jd$pair($a0){for(;;){const $x3568=$a0;{const $ord0=((((
/*JD_USE:3568*/$x3568) + 1) >>> 0));const $let0=((Math.imul($ord0, 2654435761) >>> 0));{const $x3569=$let0;{const $let0=(
/*JD_REF:$jd$gen*/$jd$gen(256,0,(
/*JD_USE:3569*/$x3569),(array_new(8, 0))));{const $x3570=$let0;{const $let0=(
/*JD_REF:$jd$gen*/$jd$gen(256,0,((Math.imul((
/*JD_USE:3569*/$x3569), 340573321) >>> 0)),(array_new(8, 0))));{const $x3571=$let0;{const $let0=(
/*JD_REF:$jd$init*/$jd$init(257,0,(array_new(9, 0))));{const $x3572=$let0;{const $let0=(
/*JD_REF:$jd$dist*/$jd$dist((
/*JD_REF:$jd$dp*/$jd$dp(256,0,({$:"Dp",["a"]:(
/*JD_USE:3570*/$x3570),["b"]:(
/*JD_USE:3571*/$x3571),["prev"]:(
/*JD_USE:3572*/$x3572),["cur"]:(array_new(9, 0))})))));{const $x3573=$let0;{const $ord0=((Math.imul((
/*JD_USE:3573*/$x3573), 2654435761) >>> 0));const $ord1=((((
/*JD_USE:3568*/$x3568) + 1) >>> 0));return ((($ord0 ^ $ord1) >>> 0));}}}}}}}}}}}}}
function $jd$batch($a0,$a1){for(;;){{const $match1=$a0;if($match1===0){const $x3576=$a1;return (
/*JD_REF:$jd$pair*/$jd$pair((
/*JD_USE:3576*/$x3576)));}else{const $x3577=($match1-1);const $x3578=$a1;{const $let0=(
/*JD_REF:$jd$batch*/$jd$batch((
/*JD_USE:3577*/$x3577),(
/*JD_USE:3578*/$x3578)));const $ord0=(((
/*JD_USE:3577*/$x3577) >= 32 ? 0 : (1 << (
/*JD_USE:3577*/$x3577)) >>> 0));const $let1=(
/*JD_REF:$jd$batch*/$jd$batch((
/*JD_USE:3577*/$x3577),((((
/*JD_USE:3578*/$x3578) + $ord0) >>> 0))));{const $x3579=$let0;const $x3580=$let1;return ((((
/*JD_USE:3579*/$x3579) + (
/*JD_USE:3580*/$x3580)) >>> 0));}}}}}}
function $jd$size_46_small(){for(;;){return 2;}}
function $jd$size_46_big(){for(;;){return 15;}}
function $jd$bench($a0,$a1){for(;;){const $x3583=$a0;const $x3584=$a1;return (
/*JD_REF:$jd$batch*/$jd$batch(((
/*JD_USE:3583*/$x3583)),(
/*JD_USE:3584*/$x3584)));}}
function $jd$row_46_probe($a0,$a1){for(;;){const $x3587=$a0;const $x3588=$a1;{const $let0=((
/*JD_USE:3587*/$x3587));{const $x3589=$let0;{const $let0=(
/*JD_REF:$jd$gen*/$jd$gen((
/*JD_USE:3589*/$x3589),0,(
/*JD_USE:3588*/$x3588),(array_new(7, 0))));{const $x3590=$let0;{const $let0=(
/*JD_REF:$jd$gen*/$jd$gen((
/*JD_USE:3589*/$x3589),0,((Math.imul((
/*JD_USE:3588*/$x3588), 340573321) >>> 0)),(array_new(7, 0))));{const $x3591=$let0;{const $ord0=((((
/*JD_USE:3587*/$x3587) + 1) >>> 0));const $let0=(
/*JD_REF:$jd$init*/$jd$init(($ord0),0,(array_new(7, 0))));{const $x3592=$let0;return (
/*JD_REF:$jd$row*/$jd$row((
/*JD_USE:3589*/$x3589),0,((((
/*JD_USE:3588*/$x3588) & 3) >>> 0)),({$:"Dp",["a"]:(
/*JD_USE:3590*/$x3590),["b"]:(
/*JD_USE:3591*/$x3591),["prev"]:(
/*JD_USE:3592*/$x3592),["cur"]:(array_new(7, 0))})));}}}}}}}}}}

export const backend={kind:"direct-js",representation:"upstream-native",prototype:true,foreign:"upstream-cps"};
const $Owned_exports = {
"b2u":run_lib((a0,)=>{const r=(run_loop($jd$b2u((a0),)));(a0);return r;},1),
"prng":run_lib((a0,)=>{const r=(run_loop($jd$prng((a0),)));(a0);return r;},1),
"umin.go":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$umin_46_go((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"umin":run_lib((a0,a1,)=>{const r=(run_loop($jd$umin((a0),(a1),)));(a0);(a1);return r;},2),
"gen":run_lib((a0,a1,a2,a3,)=>{const r=(run_loop($jd$gen(nat_host(a0),(a1),(a2),(a3),)));BigInt(a0);(a1);(a2);(a3);return r;},4),
"init":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$init(nat_host(a0),(a1),(a2),)));BigInt(a0);(a1);(a2);return r;},3),
"cell.f4":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,)=>{const r=(run_loop($jd$cell_46_f4((a0),(a1),(a2),(a3),(a4),(a5),(a6),(a7),)));(a0);(a1);(a2);(a3);(a4);(a5);(a6);(a7);return r;},8),
"cell.f3":run_lib((a0,a1,a2,a3,a4,a5,a6,)=>{const r=(run_loop($jd$cell_46_f3((a0),(a1),(a2),(a3),(a4),(a5),(a6),)));(a0);(a1);(a2);(a3);(a4);(a5);(a6);return r;},7),
"cell.f2":run_lib((a0,a1,a2,a3,a4,a5,)=>{const r=(run_loop($jd$cell_46_f2((a0),(a1),(a2),(a3),(a4),(a5),)));(a0);(a1);(a2);(a3);(a4);(a5);return r;},6),
"cell.f1":run_lib((a0,a1,a2,a3,a4,a5,)=>{const r=(run_loop($jd$cell_46_f1((a0),(a1),(a2),(a3),(a4),(a5),)));(a0);(a1);(a2);(a3);(a4);(a5);return r;},6),
"cell":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$cell((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"row":run_lib((a0,a1,a2,a3,)=>{const r=(run_loop($jd$row(nat_host(a0),(a1),(a2),(a3),)));BigInt(a0);(a1);(a2);(a3);return r;},4),
"dp.f1":run_lib((a0,a1,a2,a3,a4,)=>{const r=(run_loop($jd$dp_46_f1((a0),(a1),(a2),(a3),(a4),)));(a0);(a1);(a2);(a3);(a4);return r;},5),
"dp.row":run_lib((a0,a1,)=>{const r=(run_loop($jd$dp_46_row((a0),(a1),)));(a0);(a1);return r;},2),
"dp":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$dp(nat_host(a0),(a1),(a2),)));BigInt(a0);(a1);(a2);return r;},3),
"dist.fin":run_lib((a0,)=>{const r=(run_loop($jd$dist_46_fin((a0),)));(a0);return r;},1),
"dist":run_lib((a0,)=>{const r=(run_loop($jd$dist((a0),)));(a0);return r;},1),
"pair":run_lib((a0,)=>{const r=(run_loop($jd$pair((a0),)));(a0);return r;},1),
"batch":run_lib((a0,a1,)=>{const r=(run_loop($jd$batch(nat_host(a0),(a1),)));BigInt(a0);(a1);return r;},2),
"size.small":run_lib(()=>{const r=BigInt(run_loop($jd$size_46_small()));return r;},0),
"size.big":run_lib(()=>{const r=BigInt(run_loop($jd$size_46_big()));return r;},0),
"bench":run_lib((a0,a1,)=>{const r=(run_loop($jd$bench((a0),(a1),)));(a0);(a1);return r;},2),
"row.probe":run_lib((a0,a1,)=>{const r=(run_loop($jd$row_46_probe((a0),(a1),)));(a0);(a1);return r;},2),
};

export default {...$Owned_exports,bench:(n,seed)=>{const st=$Owned_exports["row.probe"](n,seed);return JSON.stringify([st.a,st.b,st.prev,st.cur]);}};
