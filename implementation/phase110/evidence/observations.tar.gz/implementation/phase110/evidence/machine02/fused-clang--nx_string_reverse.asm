
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e60 <nx_string_reverse>:
  401e60:	push   %r15
  401e62:	push   %r14
  401e64:	push   %rbx
  401e65:	mov    %rdx,%r14
  401e68:	mov    %rsi,%r15
  401e6b:	mov    %rdi,%rbx
  401e6e:	xchg   %ax,%ax
  401e70:	mov    %rbx,%rdi
  401e73:	mov    %r15,%rsi
  401e76:	callq  402c00 <nx_rt_fast_id>
  401e7b:	cmp    $0x3,%eax
  401e7e:	jne    401ea7 <nx_string_reverse+0x47>
  401e80:	mov    %rbx,%rdi
  401e83:	mov    %r15,%rsi
  401e86:	mov    $0x3,%edx
  401e8b:	xor    %ecx,%ecx
  401e8d:	mov    %r14,%r8
  401e90:	callq  402ed0 <nx_rt_rebuild2>
  401e95:	mov    %rax,%r14
  401e98:	mov    %rbx,%rdi
  401e9b:	xor    %esi,%esi
  401e9d:	callq  402eb0 <nx_rt_fast_field>
  401ea2:	mov    %rax,%r15
  401ea5:	jmp    401e70 <nx_string_reverse+0x10>
  401ea7:	cmp    $0x2,%eax
  401eaa:	jne    401eb5 <nx_string_reverse+0x55>
  401eac:	mov    %r14,%rax
  401eaf:	pop    %rbx
  401eb0:	pop    %r14
  401eb2:	pop    %r15
  401eb4:	retq   
  401eb5:	mov    %rbx,%rdi
  401eb8:	mov    $0x1,%esi
  401ebd:	pop    %rbx
  401ebe:	pop    %r14
  401ec0:	pop    %r15
  401ec2:	jmpq   4026b0 <nx_rt_fail>

Disassembly of section .fini:
