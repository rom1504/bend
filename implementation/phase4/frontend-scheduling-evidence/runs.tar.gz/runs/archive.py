import pathlib,json,hashlib,tarfile,gzip,io,datetime
root=pathlib.Path.cwd(); build=root/'build/phase4/frontend-scheduling'; out=root.parent/'implementation/phase4/frontend-scheduling-evidence';out.mkdir(exist_ok=False)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
files={}
for name in ['snapshot','focused-1','focused-4','serial','parallel','serial-idle','parallel-repeat']:
 for p in sorted((build/name).rglob('*')):
  if p.is_file():files['runs/'+str(p.relative_to(build))]=p
for name in ['config.json','focused.json','focused-comparison.json','comparison-first.json','comparison-repeat.json','archive.py']:
 p=build/name;files['runs/'+name]=p
for p in sorted(build.glob('*-launch.std*')):files['runs/'+p.name]=p
for name in ['frontend-scheduling.mjs','frontend-scheduling-compare.mjs']:
 p=root/'tools/performance/phase4'/name;files['tools/'+name]=p
snapshot=json.loads((build/'snapshot/snapshot.json').read_text());history=pathlib.Path(snapshot['historical']);files['historical/observations.json']=history
inputs=[{'archivePath':name,'source':str(p),'sha256':sha(p),'bytes':p.stat().st_size} for name,p in sorted(files.items())]
archive=out/'runs.tar.gz'
with archive.open('wb') as raw:
 with gzip.GzipFile(filename='',mode='wb',fileobj=raw,mtime=0,compresslevel=6) as gz:
  with tarfile.open(mode='w',fileobj=gz) as tar:
   for r in inputs:
    p=pathlib.Path(r['source']);data=p.read_bytes();assert hashlib.sha256(data).hexdigest()==r['sha256'];item=tarfile.TarInfo(r['archivePath']);item.size=len(data);item.mode=0o644;item.mtime=0;tar.addfile(item,io.BytesIO(data))
for r in inputs:assert sha(pathlib.Path(r['source']))==r['sha256']
attempts=[]
for name in ['serial','parallel','serial-idle','parallel-repeat']:
 p=build/name/'report.json';d=json.loads(p.read_text());assert d['complete'] and d['inputsVerified'] and d['probeCount']==2756
 raw=json.loads(pathlib.Path(d['observations']['file']).read_text())
 attempts.append({'id':name,'report':str(p),'sha256':sha(p),'started':d['execution']['started'],'finished':d['execution']['finished'],'wallMs':d['execution']['wallMs'],'jobs':d['jobs'],'cpus':d['cpus'],'peakSampledLiveRssKiB':d['execution']['resourceObservation']['peakSampledLiveRssKiB'],'observationMsSum':sum(r['ms'] for r in raw['results']),'historyCount':len(d['histories']),'workerStats':d['workerStats'],'summary':d['summary'],'fullConformance':d['fullConformance'],'backgroundCompilerWork':name=='serial'})
serial=next(a for a in attempts if a['id']=='serial-idle');parallel=[a for a in attempts if a['jobs']==4];mean_parallel=sum(a['wallMs'] for a in parallel)/2
manifest={'kind':'phase4-frontend-scheduling-evidence','complete':True,'created':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Exact B1 observations under scheduling changes. One idle-host serial bracketed by two four-core runs; first loaded-host serial retained separately. Not a compiler algorithm speedup or full conformance claim.','attempts':attempts,'primary':{'idleSerialMs':serial['wallMs'],'fourWorkerMs':[a['wallMs'] for a in parallel],'fourWorkerMedianMs':mean_parallel,'wallSpeedRatio':serial['wallMs']/mean_parallel,'wallReductionPercent':100*(1-mean_parallel/serial['wallMs'])},'archive':{'file':archive.name,'sha256':sha(archive),'bytes':archive.stat().st_size},'files':inputs}
(out/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print(json.dumps({'complete':True,'archiveBytes':archive.stat().st_size,'files':len(inputs),'primary':manifest['primary']}))
