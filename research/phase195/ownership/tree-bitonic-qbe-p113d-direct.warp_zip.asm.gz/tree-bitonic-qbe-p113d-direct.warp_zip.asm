
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/tree-bitonic/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000406a70 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>:
  406a70:	endbr64 
  406a74:	cs cs cs cs cs push %rbp
  406a7a:	cs cs cs mov %rsp,%rbp
  406a80:	sub    $0x818,%rsp
  406a87:	push   %rbx
  406a88:	push   %r12
  406a8a:	push   %r13
  406a8c:	push   %r14
  406a8e:	push   %r15
  406a90:	mov    %rdx,%r15
  406a93:	mov    %rsi,%rax
  406a96:	shr    $0x28,%rax
  406a9a:	mov    %rax,%rcx
  406a9d:	and    $0xffff,%rcx
  406aa4:	cmp    $0xa5,%rcx
  406aab:	sete   %dl
  406aae:	movzbl %dl,%edx
  406ab1:	mov    %r15,%r8
  406ab4:	shr    $0x28,%r8
  406ab8:	mov    %r8,%r12
  406abb:	and    $0x7fffff,%r12
  406ac2:	movabs $0xffffffffff,%r9
  406acc:	mov    %r15,%rbx
  406acf:	and    %r9,%rbx
  406ad2:	mov    %rbx,-0x10(%rbp)
  406ad6:	mov    %r8,%r13
  406ad9:	and    $0xffff,%r13
  406ae0:	cmp    $0x0,%edx
  406ae3:	jne    406be5 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x175>
  406ae9:	cmp    $0xa4,%rcx
  406af0:	je     406b06 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x96>
  406af2:	mov    $0x4,%esi
  406af7:	callq  414bf0 <p111_rt_fail>
  406afc:	mov    $0x0,%eax
  406b01:	jmpq   406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406b06:	and    $0x7fffff,%rax
  406b0c:	cmp    $0x100a4,%rax
  406b12:	je     406b2e <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xbe>
  406b14:	lea    -0x810(%rbp),%rdx
  406b1b:	mov    %rsi,%rax
  406b1e:	mov    %rdi,%r14
  406b21:	callq  419f80 <p125_rt_take1>
  406b26:	mov    %r15,%rsi
  406b29:	mov    %r14,%rdi
  406b2c:	jmp    406b48 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xd8>
  406b2e:	mov    %rsi,%rax
  406b31:	mov    %r15,%rsi
  406b34:	movabs $0xffffffffff,%rcx
  406b3e:	and    %rcx,%rax
  406b41:	mov    %rax,-0x810(%rbp)
  406b48:	cmp    $0xa5,%r13
  406b4f:	je     406b9b <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x12b>
  406b51:	cmp    $0xa4,%r13
  406b58:	je     406b6e <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xfe>
  406b5a:	mov    $0x4,%esi
  406b5f:	callq  414bf0 <p111_rt_fail>
  406b64:	mov    $0x0,%eax
  406b69:	jmpq   406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406b6e:	cmp    $0x100a4,%r12
  406b75:	je     406b85 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x115>
  406b77:	lea    -0x810(%rbp),%rdx
  406b7e:	callq  419f80 <p125_rt_take1>
  406b83:	jmp    406b8c <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x11c>
  406b85:	mov    %rbx,-0x810(%rbp)
  406b8c:	movabs $0x100a40000000000,%rax
  406b96:	jmpq   406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406b9b:	cs cs cs lea %cs:-0x810(%rbp),%rdx
  406ba6:	cs mov %rsi,%r14
  406baa:	mov    %rdi,%rbx
  406bad:	callq  41a200 <p125_rt_take2>
  406bb2:	mov    %rbx,%rdi
  406bb5:	mov    -0x810(%rbp),%rsi
  406bbc:	mov    -0x808(%rbp),%r12
  406bc3:	mov    %rdi,%rbx
  406bc6:	callq  414460 <p111_rt_sink>
  406bcb:	mov    %r12,%rsi
  406bce:	mov    %rbx,%rdi
  406bd1:	callq  414460 <p111_rt_sink>
  406bd6:	movabs $0x100a40000000000,%rax
  406be0:	jmpq   406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406be5:	mov    %r15,%r14
  406be8:	lea    -0x810(%rbp),%rdx
  406bef:	mov    %rdi,%rbx
  406bf2:	callq  41a200 <p125_rt_take2>
  406bf7:	mov    %r14,%rsi
  406bfa:	mov    %rbx,%rdi
  406bfd:	mov    -0x810(%rbp),%rbx
  406c04:	mov    -0x808(%rbp),%r14
  406c0b:	cmp    $0xa5,%r13
  406c12:	je     406c8d <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x21d>
  406c14:	mov    %rsi,%r15
  406c17:	mov    %rbx,%rsi
  406c1a:	mov    %rdi,%rbx
  406c1d:	callq  414460 <p111_rt_sink>
  406c22:	mov    %r15,%rsi
  406c25:	mov    %rbx,%rdi
  406c28:	mov    -0x10(%rbp),%rbx
  406c2c:	mov    %rsi,%r15
  406c2f:	mov    %r14,%rsi
  406c32:	mov    %rdi,%r14
  406c35:	callq  414460 <p111_rt_sink>
  406c3a:	mov    %r15,%rsi
  406c3d:	mov    %r14,%rdi
  406c40:	cmp    $0xa4,%r13
  406c47:	je     406c5d <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x1ed>
  406c49:	mov    $0x4,%esi
  406c4e:	callq  414bf0 <p111_rt_fail>
  406c53:	mov    $0x0,%eax
  406c58:	jmpq   406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406c5d:	nopl   (%rax)
  406c60:	cmp    $0x100a4,%r12
  406c67:	je     406c77 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x207>
  406c69:	lea    -0x810(%rbp),%rdx
  406c70:	callq  419f80 <p125_rt_take1>
  406c75:	jmp    406c7e <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x20e>
  406c77:	mov    %rbx,-0x810(%rbp)
  406c7e:	movabs $0x100a40000000000,%rax
  406c88:	jmpq   406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406c8d:	mov    %r14,%r13
  406c90:	lea    -0x810(%rbp),%rdx
  406c97:	mov    %rdi,%r12
  406c9a:	callq  41a200 <p125_rt_take2>
  406c9f:	mov    %r12,%rdi
  406ca2:	mov    -0x810(%rbp),%rcx
  406ca9:	mov    -0x808(%rbp),%r12
  406cb0:	mov    %rbx,-0x810(%rbp)
  406cb7:	mov    %rcx,-0x808(%rbp)
  406cbe:	mov    0x8(%rdi),%r9
  406cc2:	mov    0x8(%r9),%rax
  406cc6:	cmp    $0x0,%rax
  406cca:	jne    406ce8 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x278>
  406ccc:	lea    -0x810(%rbp),%rdx
  406cd3:	mov    $0xa5,%esi
  406cd8:	mov    %rdi,%rbx
  406cdb:	callq  41a110 <p125_rt_ctor2>
  406ce0:	mov    %rbx,%rdi
  406ce3:	mov    %rax,%rbx
  406ce6:	jmp    406d2a <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x2ba>
  406ce8:	cs cs cs mov %cs:(%rdi),%rdx
  406cef:	cs mov %rax,%rsi
  406cf3:	shl    $0x3,%rsi
  406cf7:	mov    (%rdx,%rsi,1),%r10
  406cfb:	mov    0x108(%r9),%r8
  406d02:	mov    %r10,0x8(%r9)
  406d06:	sub    $0x2,%r8
  406d0a:	mov    %r8,0x108(%r9)
  406d11:	mov    %rbx,(%rdx,%rsi,1)
  406d15:	mov    %rcx,0x8(%rdx,%rsi,1)
  406d1a:	movabs $0x200a50000000000,%rcx
  406d24:	mov    %rax,%rbx
  406d27:	or     %rcx,%rbx
  406d2a:	mov    %r13,-0x810(%rbp)
  406d31:	mov    %r12,-0x808(%rbp)
  406d38:	mov    0x8(%rdi),%r8
  406d3c:	mov    0x8(%r8),%rax
  406d40:	cmp    $0x0,%rax
  406d44:	jne    406d62 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x2f2>
  406d46:	lea    -0x810(%rbp),%rdx
  406d4d:	mov    $0xa5,%esi
  406d52:	mov    %rdi,%r12
  406d55:	callq  41a110 <p125_rt_ctor2>
  406d5a:	mov    %r12,%rdi
  406d5d:	mov    %rax,%rcx
  406d60:	jmp    406d9c <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x32c>
  406d62:	mov    (%rdi),%rcx
  406d65:	mov    %rax,%rdx
  406d68:	shl    $0x3,%rdx
  406d6c:	mov    (%rcx,%rdx,1),%r9
  406d70:	mov    0x108(%r8),%rsi
  406d77:	mov    %r9,0x8(%r8)
  406d7b:	sub    $0x2,%rsi
  406d7f:	mov    %rsi,0x108(%r8)
  406d86:	mov    %r13,(%rcx,%rdx,1)
  406d8a:	mov    %r12,0x8(%rcx,%rdx,1)
  406d8f:	movabs $0x200a50000000000,%rcx
  406d99:	or     %rax,%rcx
  406d9c:	mov    %rbx,-0x810(%rbp)
  406da3:	mov    %rcx,-0x808(%rbp)
  406daa:	mov    0x8(%rdi),%r8
  406dae:	mov    0x8(%r8),%rax
  406db2:	cmp    $0x0,%rax
  406db6:	jne    406dcb <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x35b>
  406db8:	lea    -0x810(%rbp),%rdx
  406dbf:	mov    $0xa5,%esi
  406dc4:	callq  41a110 <p125_rt_ctor2>
  406dc9:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406dcb:	mov    (%rdi),%rdx
  406dce:	mov    %rax,%rsi
  406dd1:	shl    $0x3,%rsi
  406dd5:	mov    (%rdx,%rsi,1),%r9
  406dd9:	mov    0x108(%r8),%rdi
  406de0:	mov    %r9,0x8(%r8)
  406de4:	sub    $0x2,%rdi
  406de8:	mov    %rdi,0x108(%r8)
  406def:	mov    %rbx,(%rdx,%rsi,1)
  406df3:	mov    %rcx,0x8(%rdx,%rsi,1)
  406df8:	movabs $0x200a50000000000,%rcx
  406e02:	or     %rcx,%rax
  406e05:	pop    %r15
  406e07:	pop    %r14
  406e09:	pop    %r13
  406e0b:	pop    %r12
  406e0d:	pop    %rbx
  406e0e:	leaveq 
  406e0f:	retq   

Disassembly of section .fini:
