0000000000418210 <p125_rt_ctor3>:
  418210:	push   r15
  418212:	mov    rax,rdi
  418215:	push   r14
  418217:	push   r13
  418219:	push   r12
  41821b:	mov    r12,rdx
  41821e:	push   rbp
  41821f:	push   rbx
  418220:	mov    ebx,esi
  418222:	sub    rsp,0x18
  418226:	mov    r14,QWORD PTR [rax+0x8]
  41822a:	mov    rdi,QWORD PTR [rdi]
  41822d:	mov    r13,QWORD PTR [r14+0x10]
  418231:	test   r13,r13
  418234:	je     405095 <p125_rt_ctor3.cold>
  41823a:	mov    rax,QWORD PTR [rdi+r13*8]
  41823e:	sub    QWORD PTR [r14+0x110],0x4
  418246:	mov    QWORD PTR [r14+0x10],rax
  41824a:	mov    rax,QWORD PTR [rip+0x10887f]        # 520ad0 <p111_program_active>
  418251:	test   BYTE PTR [rax+0x58],0x8
  418255:	je     418264 <p125_rt_ctor3+0x54>
  418257:	mov    rax,QWORD PTR [rax+0x88]
  41825e:	cmp    BYTE PTR [rax+rbx*1],0x0
  418262:	je     4182c0 <p125_rt_ctor3+0xb0>
  418264:	lea    r15,[rdi+r13*8]
  418268:	xor    ebp,ebp
  41826a:	mov    rdx,QWORD PTR [r12+rbp*1]
  41826e:	mov    rax,rdx
  418271:	shr    rax,0x38
  418275:	and    eax,0x7f
  418278:	cmp    rax,0x2
  41827c:	je     4182b0 <p125_rt_ctor3+0xa0>
  41827e:	mov    QWORD PTR [r15+rbp*1],rdx
  418282:	add    rbp,0x8
  418286:	cmp    rbp,0x18
  41828a:	jne    41826a <p125_rt_ctor3+0x5a>
  41828c:	mov    rax,rbx
  41828f:	add    rsp,0x18
  418293:	shl    rax,0x28
  418297:	pop    rbx
  418298:	pop    rbp
  418299:	or     rax,r13
  41829c:	pop    r12
  41829e:	pop    r13
  4182a0:	bts    rax,0x39
  4182a5:	pop    r14
  4182a7:	pop    r15
  4182a9:	ret    
  4182aa:	nop    WORD PTR [rax+rax*1+0x0]
  4182b0:	test   rdx,rdx
  4182b3:	js     41827e <p125_rt_ctor3+0x6e>
  4182b5:	jmp    4050b4 <p125_rt_ctor3.cold+0x1f>
  4182ba:	nop    WORD PTR [rax+rax*1+0x0]
  4182c0:	lea    rcx,[rdi+r13*8]
  4182c4:	xor    eax,eax
  4182c6:	mov    rdx,QWORD PTR [r12+rax*1]
  4182ca:	mov    QWORD PTR [rcx+rax*1],rdx
  4182ce:	add    rax,0x8
  4182d2:	cmp    rax,0x18
  4182d6:	jne    4182c6 <p125_rt_ctor3+0xb6>
  4182d8:	jmp    41828c <p125_rt_ctor3+0x7c>
  4182da:	nop    WORD PTR [rax+rax*1+0x0]

