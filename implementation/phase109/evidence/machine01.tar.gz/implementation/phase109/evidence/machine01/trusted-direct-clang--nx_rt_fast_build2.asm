
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004027f0 <nx_rt_fast_build2>:
  4027f0:	push   %r15
  4027f2:	push   %r14
  4027f4:	push   %r13
  4027f6:	mov    %rdx,%r13
  4027f9:	push   %r12
  4027fb:	mov    %rcx,%r12
  4027fe:	push   %rbp
  4027ff:	push   %rbx
  402800:	mov    %esi,%ebx
  402802:	sub    $0x18,%rsp
  402806:	mov    0x8(%rdi),%r14
  40280a:	mov    (%rdi),%r15
  40280d:	mov    0x8(%r14),%rbp
  402811:	test   %rbp,%rbp
  402814:	je     4015f3 <nx_rt_fast_build2.cold+0x40>
  40281a:	lea    (%r15,%rbp,8),%r8
  40281e:	mov    (%r8),%rax
  402821:	subq   $0x2,0x108(%r14)
  402829:	mov    %rax,0x8(%r14)
  40282d:	mov    %r13,%rax
  402830:	shr    $0x38,%rax
  402834:	and    $0x7f,%eax
  402837:	cmp    $0x2,%rax
  40283b:	je     402880 <nx_rt_fast_build2+0x90>
  40283d:	mov    %r12,%rax
  402840:	mov    %r13,(%r8)
  402843:	lea    0x8(%r15,%rbp,8),%r13
  402848:	shr    $0x38,%rax
  40284c:	and    $0x7f,%eax
  40284f:	cmp    $0x2,%rax
  402853:	je     402890 <nx_rt_fast_build2+0xa0>
  402855:	mov    %rbx,%rax
  402858:	mov    %r12,0x0(%r13)
  40285c:	add    $0x18,%rsp
  402860:	shl    $0x28,%rax
  402864:	pop    %rbx
  402865:	or     %rbp,%rax
  402868:	pop    %rbp
  402869:	pop    %r12
  40286b:	bts    $0x39,%rax
  402870:	pop    %r13
  402872:	pop    %r14
  402874:	pop    %r15
  402876:	retq   
  402877:	nopw   0x0(%rax,%rax,1)
  402880:	test   %r13,%r13
  402883:	js     40283d <nx_rt_fast_build2+0x4d>
  402885:	jmpq   4015b3 <nx_rt_fast_build2.cold>
  40288a:	nopw   0x0(%rax,%rax,1)
  402890:	test   %r12,%r12
  402893:	js     402855 <nx_rt_fast_build2+0x65>
  402895:	jmpq   4015d8 <nx_rt_fast_build2.cold+0x25>

Disassembly of section .fini:
