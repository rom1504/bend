
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004019b0 <heap_alloc>:
  4019b0:	endbr64 
  4019b4:	push   %rbp
  4019b5:	mov    %rsp,%rbp
  4019b8:	sub    $0x10,%rsp
  4019bc:	mov    %edx,%ecx
  4019be:	mov    %rdi,-0x10(%rbp)
  4019c2:	mov    %rsi,-0x8(%rbp)
  4019c6:	mov    -0x8(%rbp),%rsi
  4019ca:	mov    %ecx,%eax
  4019cc:	imul   $0x8,%rax,%rdi
  4019d0:	mov    (%rsi,%rax,8),%rax
  4019d4:	cmp    $0x0,%rax
  4019d8:	jne    4019eb <heap_alloc+0x3b>
  4019da:	mov    %ecx,%edx
  4019dc:	mov    -0x10(%rbp),%rdi
  4019e0:	mov    -0x8(%rbp),%rsi
  4019e4:	callq  401800 <heap_alloc_miss>
  4019e9:	jmp    401a19 <heap_alloc+0x69>
  4019eb:	mov    -0x10(%rbp),%rdx
  4019ef:	mov    (%rdx,%rax,8),%rdx
  4019f3:	mov    %rdx,(%rsi,%rdi,1)
  4019f7:	mov    -0x8(%rbp),%rdx
  4019fb:	mov    %ecx,%esi
  4019fd:	add    $0x20,%esi
  401a00:	mov    %esi,%esi
  401a02:	mov    (%rdx,%rsi,8),%rdi
  401a06:	mov    $0x1,%r8d
  401a0c:	shl    %cl,%r8
  401a0f:	mov    %rdi,%rcx
  401a12:	sub    %r8,%rcx
  401a15:	mov    %rcx,(%rdx,%rsi,8)
  401a19:	leaveq 
  401a1a:	retq   

Disassembly of section .fini:
