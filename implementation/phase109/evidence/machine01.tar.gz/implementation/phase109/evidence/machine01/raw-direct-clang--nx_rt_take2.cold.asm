
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401567 <nx_rt_take2.cold>:
  401567:	mov    $0x1,%edx
  40156c:	callq  401100 <heap_hand>
  401571:	jmpq   4025d3 <nx_rt_take2+0xa3>
  401576:	xor    %edx,%edx
  401578:	callq  401100 <heap_hand>
  40157d:	jmpq   402695 <nx_rt_take2+0x165>
  401582:	mov    (%r9),%rax
  401585:	mov    %r13,%rcx
  401588:	mov    %r12,%rdx
  40158b:	mov    %rax,0x5c1e(%rip)        # 4071b0 <nx_context+0x10>
  401592:	mov    (%r8),%rax
  401595:	mov    %rax,0x5c1c(%rip)        # 4071b8 <nx_context+0x18>
  40159c:	callq  4014c6 <span_fade.constprop.0>
  4015a1:	jmpq   4025d3 <nx_rt_take2+0xa3>

Disassembly of section .fini:
