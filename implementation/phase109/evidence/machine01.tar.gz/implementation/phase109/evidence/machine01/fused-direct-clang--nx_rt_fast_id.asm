
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004026b0 <nx_rt_fast_id>:
  4026b0:	shr    $0x28,%rsi
  4026b4:	movzwl %si,%eax
  4026b7:	retq   

Disassembly of section .fini:
