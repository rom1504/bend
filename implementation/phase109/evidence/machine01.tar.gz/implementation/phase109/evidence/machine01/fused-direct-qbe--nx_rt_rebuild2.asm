
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004029c0 <nx_rt_rebuild2>:
  4029c0:	movabs $0xffffffffff,%r9
  4029ca:	push   %r14
  4029cc:	push   %r13
  4029ce:	and    %rsi,%r9
  4029d1:	mov    %edx,%r13d
  4029d4:	push   %r12
  4029d6:	lea    0x0(,%r9,8),%rdx
  4029de:	push   %rbp
  4029df:	mov    %ecx,%ebp
  4029e1:	push   %rbx
  4029e2:	mov    %rdi,%rbx
  4029e5:	sub    $0x20,%rsp
  4029e9:	mov    (%rdi),%rdi
  4029ec:	mov    0x8(%rbx),%r12
  4029f0:	lea    (%rdi,%rdx,1),%rax
  4029f4:	test   %rsi,%rsi
  4029f7:	js     402a78 <nx_rt_rebuild2+0xb8>
  4029f9:	mov    (%rax),%rax
  4029fc:	mov    %rax,0x10(%rsp)
  402a01:	mov    0x8(%rdi,%rdx,1),%rax
  402a06:	mov    %rax,0x18(%rsp)
  402a0b:	cmp    $0x310817f,%r9
  402a12:	jbe    402a50 <nx_rt_rebuild2+0x90>
  402a14:	mov    $0x1,%eax
  402a19:	mov    0x10(%rsp,%rbp,8),%rcx
  402a1e:	mov    %r13d,%edx
  402a21:	mov    %r12,%rsi
  402a24:	sub    %ebp,%eax
  402a26:	movq   $0xffffffffffffffff,0x18(%rbx)
  402a2e:	mov    0x10(%rsp,%rax,8),%rax
  402a33:	movl   $0x1,0x20(%rbx)
  402a3a:	mov    %rax,0x10(%rbx)
  402a3e:	add    $0x20,%rsp
  402a42:	pop    %rbx
  402a43:	pop    %rbp
  402a44:	pop    %r12
  402a46:	pop    %r13
  402a48:	pop    %r14
  402a4a:	jmpq   401c60 <nx_construct2>
  402a4f:	nop
  402a50:	mov    0x8(%r12),%r9
  402a55:	test   %r9,%r9
  402a58:	je     401651 <nx_rt_rebuild2.cold>
  402a5e:	mov    (%rdi,%r9,8),%rax
  402a62:	subq   $0x2,0x108(%r12)
  402a6b:	mov    %rax,0x8(%r12)
  402a70:	jmp    402a14 <nx_rt_rebuild2+0x54>
  402a72:	nopw   0x0(%rax,%rax,1)
  402a78:	mov    0x4(%rax),%edx
  402a7b:	mov    (%rax),%ecx
  402a7d:	shl    $0x20,%rdx
  402a81:	or     %rcx,%rdx
  402a84:	mov    %rdx,%r14
  402a87:	and    $0xffffff,%edx
  402a8d:	shr    $0x18,%r14
  402a91:	lea    0x0(,%r14,8),%r10
  402a99:	lea    (%rdi,%r10,1),%r11
  402a9d:	lea    0x8(%rdi,%r10,1),%r10
  402aa2:	cmp    $0x1,%rdx
  402aa6:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402aac:	mov    (%rax),%edx
  402aae:	mov    (%r11),%rdx
  402ab1:	mov    %rdx,0x10(%rsp)
  402ab6:	mov    (%r10),%rdx
  402ab9:	mov    %rdx,0x18(%rsp)
  402abe:	mov    (%r12),%rdx
  402ac2:	mov    %rdx,(%rax)
  402ac5:	mov    0x100(%r12),%rax
  402acd:	mov    0x4705(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402ad3:	mov    %r9,(%r12)
  402ad7:	add    $0x1,%rax
  402adb:	mov    %rax,0x100(%r12)
  402ae3:	cmp    %rdx,%rax
  402ae6:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402aec:	mov    %r14,%r9
  402aef:	jmpq   402a0b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
