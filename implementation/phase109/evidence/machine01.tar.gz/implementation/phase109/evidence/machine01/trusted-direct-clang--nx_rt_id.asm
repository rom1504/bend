
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004021d0 <nx_rt_id>:
  4021d0:	cmpb   $0x0,0x4fa9(%rip)        # 407180 <nx_active>
  4021d7:	je     4021e5 <nx_rt_id+0x15>
  4021d9:	lea    0x4fc0(%rip),%rax        # 4071a0 <nx_context>
  4021e0:	cmp    %rax,%rdi
  4021e3:	je     4021f8 <nx_rt_id+0x28>
  4021e5:	push   %rax
  4021e6:	lea    0x1e46(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4021ed:	callq  4019b0 <err_fail>
  4021f2:	nopw   0x0(%rax,%rax,1)
  4021f8:	mov    0x4fa1(%rip),%rdi        # 4071a0 <nx_context>
  4021ff:	jmpq   401ae0 <nx_id.isra.0>

Disassembly of section .fini:
