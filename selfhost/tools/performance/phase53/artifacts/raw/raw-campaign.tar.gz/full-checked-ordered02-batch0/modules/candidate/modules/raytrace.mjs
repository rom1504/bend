// Direct JavaScript backend runtime. Generated output embeds this fragment.
// Ported from bend2/comp.ts NATIVE.JS, RUNTIME and RUNTIME_MAIN, and
// bend2/bend.ts f32_round at fixed upstream commit
// 018751270e800bc222a93dad7f257083ee53a5f7. The reference files stay unchanged.
// No TypeScript compiler/runtime dependency is used by ordinary compilation.
// Number is the internal Nat representation; nat_host handles typed host input.
// Node foreign IO requires the host emitter to provide an ESM require binding.
// Bun/system calls remain lazy, exactly as in the pinned upstream runtime.

function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  // Avoid an intermediate JS array: its cold element-kind transition can
  // canonicalize a Number NaN and discard a payload on only one conversion.
  // Fresh storage keeps nested host coercions independent; the store coerces once.
  const f = new Float32Array(1);
  f[0] = x;
  return new Uint32Array(f.buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}
// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, String(io_sys().strerror(code))) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    for (;;) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io);
        continue;
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

// Direct core names. A named tail call carries all already-evaluated arguments;
// run_tail above retains the upstream unary native-closure protocol unchanged.
const jd_run = run_loop;
const jd_clo = run_clo;
function jd_tail(f, args) {
  return {$: "$JMP", f, x: args};
}


// Direct JavaScript prototype: native functions and live arguments.
function $jd$Hit_46_t($a0){for(;;){{const $match1=$a0;const $x3423=$match1["t"];return (
/*JD_USE:3423*/$x3423);}}}
function $jd$fl($a0,$a1){for(;;){const $x3427=$a0;const $x3428=$a1;{const $ord0=(Math.fround((
/*JD_USE:3427*/$x3427)));const $ord1=(Math.fround((
/*JD_USE:3428*/$x3428)));return (Math.fround($ord0 / $ord1));}}}
function $jd$sphere($a0){for(;;){{const $match1=$a0;if($match1===0){{const $ord0=(Math.fround(0));const $ord1=(Math.fround(10001));return ({$:"Sph",["x"]:(Math.fround(0)),["y"]:(Math.fround($ord0 - $ord1)),["z"]:(Math.fround(5)),["r"]:(Math.fround(10000)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(3,10))});}}else{if($match1===1){return ({$:"Sph",["x"]:(Math.fround(0)),["y"]:(Math.fround(0)),["z"]:(Math.fround(5)),["r"]:(Math.fround(1)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(7,10))});}else{if($match1===2){return ({$:"Sph",["x"]:(Math.fround(2)),["y"]:(
/*JD_REF:$jd$fl*/$jd$fl(5,10)),["z"]:(Math.fround(6)),["r"]:(Math.fround(1)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(4,10))});}else{if($match1===3){{const $ord0=(Math.fround(0));const $ord1=(Math.fround(2));return ({$:"Sph",["x"]:(Math.fround($ord0 - $ord1)),["y"]:(
/*JD_REF:$jd$fl*/$jd$fl(5,10)),["z"]:(Math.fround(6)),["r"]:(Math.fround(1)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(4,10))});}}else{if($match1===4){{const $ord0=(Math.fround(0));const $ord1=(
/*JD_REF:$jd$fl*/$jd$fl(6,10));return ({$:"Sph",["x"]:(Math.fround(1)),["y"]:(Math.fround($ord0 - $ord1)),["z"]:(
/*JD_REF:$jd$fl*/$jd$fl(35,10)),["r"]:(
/*JD_REF:$jd$fl*/$jd$fl(4,10)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(9,10))});}}else{if($match1===5){{const $ord0=(Math.fround(0));const $ord1=(Math.fround(1));const $ord2=(Math.fround(0));const $ord3=(
/*JD_REF:$jd$fl*/$jd$fl(6,10));return ({$:"Sph",["x"]:(Math.fround($ord0 - $ord1)),["y"]:(Math.fround($ord2 - $ord3)),["z"]:(
/*JD_REF:$jd$fl*/$jd$fl(35,10)),["r"]:(
/*JD_REF:$jd$fl*/$jd$fl(4,10)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(9,10))});}}else{if($match1===6){return ({$:"Sph",["x"]:(Math.fround(0)),["y"]:(
/*JD_REF:$jd$fl*/$jd$fl(16,10)),["z"]:(Math.fround(7)),["r"]:(
/*JD_REF:$jd$fl*/$jd$fl(12,10)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(1,10))});}else{if($match1===7){return ({$:"Sph",["x"]:(
/*JD_REF:$jd$fl*/$jd$fl(35,10)),["y"]:(
/*JD_REF:$jd$fl*/$jd$fl(2,10)),["z"]:(Math.fround(8)),["r"]:(Math.fround(1)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(6,10))});}else{{const $ord0=(Math.fround(0));const $ord1=(
/*JD_REF:$jd$fl*/$jd$fl(35,10));return ({$:"Sph",["x"]:(Math.fround($ord0 - $ord1)),["y"]:(
/*JD_REF:$jd$fl*/$jd$fl(2,10)),["z"]:(Math.fround(8)),["r"]:(Math.fround(1)),["kr"]:(
/*JD_REF:$jd$fl*/$jd$fl(6,10))});}}}}}}}}}}}}
function $jd$isect_46_t2($a0,$a1){for(;;){const $x3433=$a0;{const $match2=$a1;if($match2){return (Math.fround(1000000000));}else{{const $match3=$match2;return (
/*JD_USE:3433*/$x3433);}}}}}
function $jd$isect_46_t($a0){for(;;){const $x3435=$a0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,1000));return (
/*JD_REF:$jd$isect_46_t2*/$jd$isect_46_t2((
/*JD_USE:3435*/$x3435),(((
/*JD_USE:3435*/$x3435) < $ord0))));}}}
function $jd$isect_46_go2($a0,$a1,$a2){for(;;){const $x3439=$a0;const $x3440=$a1;{const $match3=$a2;if($match3){return (Math.fround(1000000000));}else{{const $match4=$match3;{const $ord0=(Math.fround(0));const $ord1=(Math.fround($ord0 - (
/*JD_USE:3439*/$x3439)));const $ord2=(Math.fround(Math.sqrt((
/*JD_USE:3440*/$x3440))));return (
/*JD_REF:$jd$isect_46_t*/$jd$isect_46_t((Math.fround($ord1 - $ord2))));}}}}}}
function $jd$isect_46_go($a0,$a1){for(;;){const $x3443=$a0;const $x3444=$a1;{const $ord0=(Math.fround(0));return (
/*JD_REF:$jd$isect_46_go2*/$jd$isect_46_go2((
/*JD_USE:3443*/$x3443),(
/*JD_USE:3444*/$x3444),(((
/*JD_USE:3444*/$x3444) < $ord0))));}}}
function $jd$isect5($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9){for(;;){const $x3455=$a0;const $x3456=$a1;const $x3457=$a2;const $x3458=$a3;const $x3459=$a4;const $x3460=$a5;const $x3461=$a6;const $x3462=$a7;const $x3463=$a8;const $x3464=$a9;{const $let0=(Math.fround((
/*JD_USE:3459*/$x3459) - (
/*JD_USE:3455*/$x3455)));{const $x3465=$let0;{const $let0=(Math.fround((
/*JD_USE:3460*/$x3460) - (
/*JD_USE:3456*/$x3456)));{const $x3466=$let0;{const $let0=(Math.fround((
/*JD_USE:3461*/$x3461) - (
/*JD_USE:3457*/$x3457)));{const $x3467=$let0;{const $ord0=(Math.fround((
/*JD_USE:3465*/$x3465) * (
/*JD_USE:3462*/$x3462)));const $ord1=(Math.fround((
/*JD_USE:3466*/$x3466) * (
/*JD_USE:3463*/$x3463)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround((
/*JD_USE:3467*/$x3467) * (
/*JD_USE:3464*/$x3464)));const $let0=(Math.fround($ord2 + $ord3));{const $x3468=$let0;{const $ord0=(Math.fround((
/*JD_USE:3465*/$x3465) * (
/*JD_USE:3465*/$x3465)));const $ord1=(Math.fround((
/*JD_USE:3466*/$x3466) * (
/*JD_USE:3466*/$x3466)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround((
/*JD_USE:3467*/$x3467) * (
/*JD_USE:3467*/$x3467)));const $ord4=(Math.fround($ord2 + $ord3));const $ord5=(Math.fround((
/*JD_USE:3458*/$x3458) * (
/*JD_USE:3458*/$x3458)));const $ord6=(Math.fround((
/*JD_USE:3468*/$x3468) * (
/*JD_USE:3468*/$x3468)));const $ord7=(Math.fround($ord4 - $ord5));return (
/*JD_REF:$jd$isect_46_go*/$jd$isect_46_go((
/*JD_USE:3468*/$x3468),(Math.fround($ord6 - $ord7))));}}}}}}}}}}}
function $jd$sx($a0){for(;;){{const $match1=$a0;if($match1===0){return (Math.fround(0));}else{if($match1===1){return (Math.fround(0));}else{if($match1===2){return (Math.fround(2));}else{if($match1===3){{const $ord0=(Math.fround(0));const $ord1=(Math.fround(2));return (Math.fround($ord0 - $ord1));}}else{if($match1===4){return (Math.fround(1));}else{if($match1===5){{const $ord0=(Math.fround(0));const $ord1=(Math.fround(1));return (Math.fround($ord0 - $ord1));}}else{if($match1===6){return (Math.fround(0));}else{if($match1===7){return (
/*JD_REF:$jd$fl*/$jd$fl(35,10));}else{{const $ord0=(Math.fround(0));const $ord1=(
/*JD_REF:$jd$fl*/$jd$fl(35,10));return (Math.fround($ord0 - $ord1));}}}}}}}}}}}}
function $jd$sy($a0){for(;;){{const $match1=$a0;if($match1===0){{const $ord0=(Math.fround(0));const $ord1=(Math.fround(10001));return (Math.fround($ord0 - $ord1));}}else{if($match1===1){return (Math.fround(0));}else{if($match1===2){return (
/*JD_REF:$jd$fl*/$jd$fl(5,10));}else{if($match1===3){return (
/*JD_REF:$jd$fl*/$jd$fl(5,10));}else{if($match1===4){{const $ord0=(Math.fround(0));const $ord1=(
/*JD_REF:$jd$fl*/$jd$fl(6,10));return (Math.fround($ord0 - $ord1));}}else{if($match1===5){{const $ord0=(Math.fround(0));const $ord1=(
/*JD_REF:$jd$fl*/$jd$fl(6,10));return (Math.fround($ord0 - $ord1));}}else{if($match1===6){return (
/*JD_REF:$jd$fl*/$jd$fl(16,10));}else{if($match1===7){return (
/*JD_REF:$jd$fl*/$jd$fl(2,10));}else{return (
/*JD_REF:$jd$fl*/$jd$fl(2,10));}}}}}}}}}}}
function $jd$sz($a0){for(;;){{const $match1=$a0;if($match1===0){return (Math.fround(5));}else{if($match1===1){return (Math.fround(5));}else{if($match1===2){return (Math.fround(6));}else{if($match1===3){return (Math.fround(6));}else{if($match1===4){return (
/*JD_REF:$jd$fl*/$jd$fl(35,10));}else{if($match1===5){return (
/*JD_REF:$jd$fl*/$jd$fl(35,10));}else{if($match1===6){return (Math.fround(7));}else{if($match1===7){return (Math.fround(8));}else{return (Math.fround(8));}}}}}}}}}}}
function $jd$sr($a0){for(;;){{const $match1=$a0;if($match1===0){return (Math.fround(10000));}else{if($match1===1){return (Math.fround(1));}else{if($match1===2){return (Math.fround(1));}else{if($match1===3){return (Math.fround(1));}else{if($match1===4){return (
/*JD_REF:$jd$fl*/$jd$fl(4,10));}else{if($match1===5){return (
/*JD_REF:$jd$fl*/$jd$fl(4,10));}else{if($match1===6){return (
/*JD_REF:$jd$fl*/$jd$fl(12,10));}else{if($match1===7){return (Math.fround(1));}else{return (Math.fround(1));}}}}}}}}}}}
function $jd$skr($a0){for(;;){{const $match1=$a0;if($match1===0){return (
/*JD_REF:$jd$fl*/$jd$fl(3,10));}else{if($match1===1){return (
/*JD_REF:$jd$fl*/$jd$fl(7,10));}else{if($match1===2){return (
/*JD_REF:$jd$fl*/$jd$fl(4,10));}else{if($match1===3){return (
/*JD_REF:$jd$fl*/$jd$fl(4,10));}else{if($match1===4){return (
/*JD_REF:$jd$fl*/$jd$fl(9,10));}else{if($match1===5){return (
/*JD_REF:$jd$fl*/$jd$fl(9,10));}else{if($match1===6){return (
/*JD_REF:$jd$fl*/$jd$fl(1,10));}else{if($match1===7){return (
/*JD_REF:$jd$fl*/$jd$fl(6,10));}else{return (
/*JD_REF:$jd$fl*/$jd$fl(6,10));}}}}}}}}}}}
function $jd$nearest($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9,$a10,$a11){for(;;){{const $match1=$a0;if($match1===0){const $x3497=$a7;const $x3498=$a8;const $x3499=$a9;const $x3500=$a10;{const $match12=$a11;if(!$match12){return ({$:"Hit",["ms"]:(((
/*JD_USE:3500*/$x3500) === 9)),["t"]:(
/*JD_USE:3499*/$x3499),["i"]:(
/*JD_USE:3500*/$x3500)});}else{{const $match13=$match12;return ({$:"Hit",["ms"]:(((
/*JD_USE:3498*/$x3498) === 9)),["t"]:(
/*JD_USE:3497*/$x3497),["i"]:(
/*JD_USE:3498*/$x3498)});}}}}else{const $x3501=($match1-1);const $x3502=$a1;const $x3503=$a2;const $x3504=$a3;const $x3505=$a4;const $x3506=$a5;const $x3507=$a6;const $x3508=$a7;const $x3509=$a8;const $x3510=$a9;const $x3511=$a10;{const $match13=$a11;if(!$match13){{const $let0=(
/*JD_REF:$jd$isect5*/$jd$isect5((
/*JD_REF:$jd$sx*/$jd$sx((
/*JD_USE:3501*/$x3501))),(
/*JD_REF:$jd$sy*/$jd$sy((
/*JD_USE:3501*/$x3501))),(
/*JD_REF:$jd$sz*/$jd$sz((
/*JD_USE:3501*/$x3501))),(
/*JD_REF:$jd$sr*/$jd$sr((
/*JD_USE:3501*/$x3501))),(
/*JD_USE:3502*/$x3502),(
/*JD_USE:3503*/$x3503),(
/*JD_USE:3504*/$x3504),(
/*JD_USE:3505*/$x3505),(
/*JD_USE:3506*/$x3506),(
/*JD_USE:3507*/$x3507)));{const $x3512=$let0;{
/*JD_REF:$jd$nearest*/const $next0=(
/*JD_USE:3501*/$x3501);const $next1=(
/*JD_USE:3502*/$x3502);const $next2=(
/*JD_USE:3503*/$x3503);const $next3=(
/*JD_USE:3504*/$x3504);const $next4=(
/*JD_USE:3505*/$x3505);const $next5=(
/*JD_USE:3506*/$x3506);const $next6=(
/*JD_USE:3507*/$x3507);const $next7=(
/*JD_USE:3512*/$x3512);const $next8=(((
/*JD_USE:3501*/$x3501) >>> 0));const $next9=(
/*JD_USE:3510*/$x3510);const $next10=(
/*JD_USE:3511*/$x3511);const $next11=(((
/*JD_USE:3512*/$x3512) < (
/*JD_USE:3510*/$x3510)));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$a4=$next4;$a5=$next5;$a6=$next6;$a7=$next7;$a8=$next8;$a9=$next9;$a10=$next10;$a11=$next11;continue;}}}}else{{const $match14=$match13;{const $let0=(
/*JD_REF:$jd$isect5*/$jd$isect5((
/*JD_REF:$jd$sx*/$jd$sx((
/*JD_USE:3501*/$x3501))),(
/*JD_REF:$jd$sy*/$jd$sy((
/*JD_USE:3501*/$x3501))),(
/*JD_REF:$jd$sz*/$jd$sz((
/*JD_USE:3501*/$x3501))),(
/*JD_REF:$jd$sr*/$jd$sr((
/*JD_USE:3501*/$x3501))),(
/*JD_USE:3502*/$x3502),(
/*JD_USE:3503*/$x3503),(
/*JD_USE:3504*/$x3504),(
/*JD_USE:3505*/$x3505),(
/*JD_USE:3506*/$x3506),(
/*JD_USE:3507*/$x3507)));{const $x3513=$let0;{
/*JD_REF:$jd$nearest*/const $next0=(
/*JD_USE:3501*/$x3501);const $next1=(
/*JD_USE:3502*/$x3502);const $next2=(
/*JD_USE:3503*/$x3503);const $next3=(
/*JD_USE:3504*/$x3504);const $next4=(
/*JD_USE:3505*/$x3505);const $next5=(
/*JD_USE:3506*/$x3506);const $next6=(
/*JD_USE:3507*/$x3507);const $next7=(
/*JD_USE:3513*/$x3513);const $next8=(((
/*JD_USE:3501*/$x3501) >>> 0));const $next9=(
/*JD_USE:3508*/$x3508);const $next10=(
/*JD_USE:3509*/$x3509);const $next11=(((
/*JD_USE:3513*/$x3513) < (
/*JD_USE:3508*/$x3508)));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$a4=$next4;$a5=$next5;$a6=$next6;$a7=$next7;$a8=$next8;$a9=$next9;$a10=$next10;$a11=$next11;continue;}}}}}}}}}}
function $jd$fmax0_46_go($a0,$a1){for(;;){const $x3516=$a0;{const $match2=$a1;if($match2){return (Math.fround(0));}else{{const $match3=$match2;return (
/*JD_USE:3516*/$x3516);}}}}}
function $jd$fmax0($a0){for(;;){const $x3518=$a0;{const $ord0=(Math.fround(0));return (
/*JD_REF:$jd$fmax0_46_go*/$jd$fmax0_46_go((
/*JD_USE:3518*/$x3518),(((
/*JD_USE:3518*/$x3518) < $ord0))));}}}
function $jd$shade($a0,$a1,$a2){for(;;){const $x3522=$a0;const $x3523=$a1;const $x3524=$a2;return (
/*JD_REF:$jd$fmax0_46_go*/$jd$fmax0_46_go((
/*JD_USE:3524*/$x3524),(((
/*JD_USE:3522*/$x3522) < (
/*JD_USE:3523*/$x3523)))));}}
function $jd$clamp01_46_hi_46_go($a0,$a1){for(;;){const $x3527=$a0;{const $match2=$a1;if($match2){return (Math.fround(1));}else{{const $match3=$match2;return (
/*JD_USE:3527*/$x3527);}}}}}
function $jd$clamp01_46_hi($a0){for(;;){const $x3529=$a0;{const $ord0=(Math.fround(1));return (
/*JD_REF:$jd$clamp01_46_hi_46_go*/$jd$clamp01_46_hi_46_go((
/*JD_USE:3529*/$x3529),(($ord0 < (
/*JD_USE:3529*/$x3529)))));}}}
function $jd$clamp01_46_go($a0,$a1){for(;;){const $x3532=$a0;{const $match2=$a1;if($match2){return (Math.fround(0));}else{{const $match3=$match2;return (
/*JD_REF:$jd$clamp01_46_hi*/$jd$clamp01_46_hi((
/*JD_USE:3532*/$x3532)));}}}}}
function $jd$clamp01($a0){for(;;){const $x3534=$a0;{const $ord0=(Math.fround(0));return (
/*JD_REF:$jd$clamp01_46_go*/$jd$clamp01_46_go((
/*JD_USE:3534*/$x3534),(((
/*JD_USE:3534*/$x3534) < $ord0))));}}}
function $jd$nearest_46_t($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9){for(;;){{const $match1=$a0;if($match1===0){const $x3551=$a7;const $x3552=$a8;{const $match10=$a9;if(!$match10){return (
/*JD_USE:3552*/$x3552);}else{{const $match11=$match10;return (
/*JD_USE:3551*/$x3551);}}}}else{const $x3553=($match1-1);const $x3554=$a1;const $x3555=$a2;const $x3556=$a3;const $x3557=$a4;const $x3558=$a5;const $x3559=$a6;const $x3560=$a7;const $x3561=$a8;{const $match11=$a9;if(!$match11){{const $let0=(
/*JD_REF:$jd$isect5*/$jd$isect5((
/*JD_REF:$jd$sx*/$jd$sx((
/*JD_USE:3553*/$x3553))),(
/*JD_REF:$jd$sy*/$jd$sy((
/*JD_USE:3553*/$x3553))),(
/*JD_REF:$jd$sz*/$jd$sz((
/*JD_USE:3553*/$x3553))),(
/*JD_REF:$jd$sr*/$jd$sr((
/*JD_USE:3553*/$x3553))),(
/*JD_USE:3554*/$x3554),(
/*JD_USE:3555*/$x3555),(
/*JD_USE:3556*/$x3556),(
/*JD_USE:3557*/$x3557),(
/*JD_USE:3558*/$x3558),(
/*JD_USE:3559*/$x3559)));{const $x3562=$let0;{
/*JD_REF:$jd$nearest_46_t*/const $next0=(
/*JD_USE:3553*/$x3553);const $next1=(
/*JD_USE:3554*/$x3554);const $next2=(
/*JD_USE:3555*/$x3555);const $next3=(
/*JD_USE:3556*/$x3556);const $next4=(
/*JD_USE:3557*/$x3557);const $next5=(
/*JD_USE:3558*/$x3558);const $next6=(
/*JD_USE:3559*/$x3559);const $next7=(
/*JD_USE:3562*/$x3562);const $next8=(
/*JD_USE:3561*/$x3561);const $next9=(((
/*JD_USE:3562*/$x3562) < (
/*JD_USE:3561*/$x3561)));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$a4=$next4;$a5=$next5;$a6=$next6;$a7=$next7;$a8=$next8;$a9=$next9;continue;}}}}else{{const $match12=$match11;{const $let0=(
/*JD_REF:$jd$isect5*/$jd$isect5((
/*JD_REF:$jd$sx*/$jd$sx((
/*JD_USE:3553*/$x3553))),(
/*JD_REF:$jd$sy*/$jd$sy((
/*JD_USE:3553*/$x3553))),(
/*JD_REF:$jd$sz*/$jd$sz((
/*JD_USE:3553*/$x3553))),(
/*JD_REF:$jd$sr*/$jd$sr((
/*JD_USE:3553*/$x3553))),(
/*JD_USE:3554*/$x3554),(
/*JD_USE:3555*/$x3555),(
/*JD_USE:3556*/$x3556),(
/*JD_USE:3557*/$x3557),(
/*JD_USE:3558*/$x3558),(
/*JD_USE:3559*/$x3559)));{const $x3563=$let0;{
/*JD_REF:$jd$nearest_46_t*/const $next0=(
/*JD_USE:3553*/$x3553);const $next1=(
/*JD_USE:3554*/$x3554);const $next2=(
/*JD_USE:3555*/$x3555);const $next3=(
/*JD_USE:3556*/$x3556);const $next4=(
/*JD_USE:3557*/$x3557);const $next5=(
/*JD_USE:3558*/$x3558);const $next6=(
/*JD_USE:3559*/$x3559);const $next7=(
/*JD_USE:3563*/$x3563);const $next8=(
/*JD_USE:3560*/$x3560);const $next9=(((
/*JD_USE:3563*/$x3563) < (
/*JD_USE:3560*/$x3560)));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$a4=$next4;$a5=$next5;$a6=$next6;$a7=$next7;$a8=$next8;$a9=$next9;continue;}}}}}}}}}}
function $jd$trace($a0,$a1,$a2,$a3,$a4,$a5,$a6,$a7,$a8,$a9){for(;;){{const $match1=$a0;if($match1===0){{const $match2=$a1;{const $match3=$match2["ms"];if($match3){const $x3582=$a8;return (
/*JD_USE:3582*/$x3582);}else{{const $match4=$match3;const $x3584=$match2["t"];const $x3585=$match2["i"];const $x3586=$a2;const $x3587=$a3;const $x3588=$a4;const $x3589=$a5;const $x3590=$a6;const $x3591=$a7;const $x3592=$a8;const $x3593=$a9;{const $let0=((
/*JD_USE:3585*/$x3585));{const $x3594=$let0;{const $let0=(
/*JD_REF:$jd$sr*/$jd$sr((
/*JD_USE:3594*/$x3594)));{const $x3595=$let0;{const $ord0=(Math.fround((
/*JD_USE:3584*/$x3584) * (
/*JD_USE:3589*/$x3589)));const $let0=(Math.fround((
/*JD_USE:3586*/$x3586) + $ord0));{const $x3596=$let0;{const $ord0=(Math.fround((
/*JD_USE:3584*/$x3584) * (
/*JD_USE:3590*/$x3590)));const $let0=(Math.fround((
/*JD_USE:3587*/$x3587) + $ord0));{const $x3597=$let0;{const $ord0=(Math.fround((
/*JD_USE:3584*/$x3584) * (
/*JD_USE:3591*/$x3591)));const $let0=(Math.fround((
/*JD_USE:3588*/$x3588) + $ord0));{const $x3598=$let0;{const $ord0=(
/*JD_REF:$jd$sx*/$jd$sx((
/*JD_USE:3594*/$x3594)));const $ord1=(Math.fround((
/*JD_USE:3596*/$x3596) - $ord0));const $let0=(Math.fround($ord1 / (
/*JD_USE:3595*/$x3595)));{const $x3599=$let0;{const $ord0=(
/*JD_REF:$jd$sy*/$jd$sy((
/*JD_USE:3594*/$x3594)));const $ord1=(Math.fround((
/*JD_USE:3597*/$x3597) - $ord0));const $let0=(Math.fround($ord1 / (
/*JD_USE:3595*/$x3595)));{const $x3600=$let0;{const $ord0=(
/*JD_REF:$jd$sz*/$jd$sz((
/*JD_USE:3594*/$x3594)));const $ord1=(Math.fround((
/*JD_USE:3598*/$x3598) - $ord0));const $let0=(Math.fround($ord1 / (
/*JD_USE:3595*/$x3595)));{const $x3601=$let0;{const $ord0=(Math.fround(0));const $ord1=(Math.fround(3));const $ord2=(Math.fround($ord0 - $ord1));const $let0=(Math.fround($ord2 - (
/*JD_USE:3596*/$x3596)));{const $x3602=$let0;{const $ord0=(Math.fround(8));const $let0=(Math.fround($ord0 - (
/*JD_USE:3597*/$x3597)));{const $x3603=$let0;{const $ord0=(Math.fround(1));const $let0=(Math.fround($ord0 - (
/*JD_USE:3598*/$x3598)));{const $x3604=$let0;{const $ord0=(Math.fround((
/*JD_USE:3602*/$x3602) * (
/*JD_USE:3602*/$x3602)));const $ord1=(Math.fround((
/*JD_USE:3603*/$x3603) * (
/*JD_USE:3603*/$x3603)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround((
/*JD_USE:3604*/$x3604) * (
/*JD_USE:3604*/$x3604)));const $ord4=(Math.fround($ord2 + $ord3));const $let0=(Math.fround(Math.sqrt($ord4)));{const $x3605=$let0;{const $let0=(Math.fround((
/*JD_USE:3602*/$x3602) / (
/*JD_USE:3605*/$x3605)));{const $x3606=$let0;{const $let0=(Math.fround((
/*JD_USE:3603*/$x3603) / (
/*JD_USE:3605*/$x3605)));{const $x3607=$let0;{const $let0=(Math.fround((
/*JD_USE:3604*/$x3604) / (
/*JD_USE:3605*/$x3605)));{const $x3608=$let0;{const $ord0=(Math.fround((
/*JD_USE:3599*/$x3599) * (
/*JD_USE:3606*/$x3606)));const $ord1=(Math.fround((
/*JD_USE:3600*/$x3600) * (
/*JD_USE:3607*/$x3607)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround((
/*JD_USE:3601*/$x3601) * (
/*JD_USE:3608*/$x3608)));const $let0=(
/*JD_REF:$jd$fmax0*/$jd$fmax0((Math.fround($ord2 + $ord3))));{const $x3609=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,1000));const $ord1=(Math.fround($ord0 * (
/*JD_USE:3599*/$x3599)));const $let0=(Math.fround((
/*JD_USE:3596*/$x3596) + $ord1));{const $x3610=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,1000));const $ord1=(Math.fround($ord0 * (
/*JD_USE:3600*/$x3600)));const $let0=(Math.fround((
/*JD_USE:3597*/$x3597) + $ord1));{const $x3611=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,1000));const $ord1=(Math.fround($ord0 * (
/*JD_USE:3601*/$x3601)));const $let0=(Math.fround((
/*JD_USE:3598*/$x3598) + $ord1));{const $x3612=$let0;{const $let0=(
/*JD_REF:$jd$nearest_46_t*/$jd$nearest_46_t(9,(
/*JD_USE:3610*/$x3610),(
/*JD_USE:3611*/$x3611),(
/*JD_USE:3612*/$x3612),(
/*JD_USE:3606*/$x3606),(
/*JD_USE:3607*/$x3607),(
/*JD_USE:3608*/$x3608),(Math.fround(1000000000)),(Math.fround(1000000000)),false));{const $x3613=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(85,100));const $ord1=(
/*JD_REF:$jd$shade*/$jd$shade((
/*JD_USE:3613*/$x3613),(
/*JD_USE:3605*/$x3605),(
/*JD_USE:3609*/$x3609)));const $ord2=(
/*JD_REF:$jd$fl*/$jd$fl(1,10));const $ord3=(Math.fround($ord0 * $ord1));const $ord4=(Math.fround($ord2 + $ord3));const $ord5=(Math.fround((
/*JD_USE:3593*/$x3593) * $ord4));return (Math.fround((
/*JD_USE:3592*/$x3592) + $ord5));}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}else{const $x3614=($match1-1);{const $match3=$a1;{const $match4=$match3["ms"];if($match4){const $x3623=$a8;return (
/*JD_USE:3623*/$x3623);}else{{const $match5=$match4;const $x3625=$match3["t"];const $x3626=$match3["i"];const $x3627=$a2;const $x3628=$a3;const $x3629=$a4;const $x3630=$a5;const $x3631=$a6;const $x3632=$a7;const $x3633=$a8;const $x3634=$a9;{const $let0=((
/*JD_USE:3626*/$x3626));{const $x3635=$let0;{const $let0=(
/*JD_REF:$jd$sr*/$jd$sr((
/*JD_USE:3635*/$x3635)));{const $x3636=$let0;{const $ord0=(Math.fround((
/*JD_USE:3625*/$x3625) * (
/*JD_USE:3630*/$x3630)));const $let0=(Math.fround((
/*JD_USE:3627*/$x3627) + $ord0));{const $x3637=$let0;{const $ord0=(Math.fround((
/*JD_USE:3625*/$x3625) * (
/*JD_USE:3631*/$x3631)));const $let0=(Math.fround((
/*JD_USE:3628*/$x3628) + $ord0));{const $x3638=$let0;{const $ord0=(Math.fround((
/*JD_USE:3625*/$x3625) * (
/*JD_USE:3632*/$x3632)));const $let0=(Math.fround((
/*JD_USE:3629*/$x3629) + $ord0));{const $x3639=$let0;{const $ord0=(
/*JD_REF:$jd$sx*/$jd$sx((
/*JD_USE:3635*/$x3635)));const $ord1=(Math.fround((
/*JD_USE:3637*/$x3637) - $ord0));const $let0=(Math.fround($ord1 / (
/*JD_USE:3636*/$x3636)));{const $x3640=$let0;{const $ord0=(
/*JD_REF:$jd$sy*/$jd$sy((
/*JD_USE:3635*/$x3635)));const $ord1=(Math.fround((
/*JD_USE:3638*/$x3638) - $ord0));const $let0=(Math.fround($ord1 / (
/*JD_USE:3636*/$x3636)));{const $x3641=$let0;{const $ord0=(
/*JD_REF:$jd$sz*/$jd$sz((
/*JD_USE:3635*/$x3635)));const $ord1=(Math.fround((
/*JD_USE:3639*/$x3639) - $ord0));const $let0=(Math.fround($ord1 / (
/*JD_USE:3636*/$x3636)));{const $x3642=$let0;{const $ord0=(Math.fround(0));const $ord1=(Math.fround(3));const $ord2=(Math.fround($ord0 - $ord1));const $let0=(Math.fround($ord2 - (
/*JD_USE:3637*/$x3637)));{const $x3643=$let0;{const $ord0=(Math.fround(8));const $let0=(Math.fround($ord0 - (
/*JD_USE:3638*/$x3638)));{const $x3644=$let0;{const $ord0=(Math.fround(1));const $let0=(Math.fround($ord0 - (
/*JD_USE:3639*/$x3639)));{const $x3645=$let0;{const $ord0=(Math.fround((
/*JD_USE:3643*/$x3643) * (
/*JD_USE:3643*/$x3643)));const $ord1=(Math.fround((
/*JD_USE:3644*/$x3644) * (
/*JD_USE:3644*/$x3644)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround((
/*JD_USE:3645*/$x3645) * (
/*JD_USE:3645*/$x3645)));const $ord4=(Math.fround($ord2 + $ord3));const $let0=(Math.fround(Math.sqrt($ord4)));{const $x3646=$let0;{const $let0=(Math.fround((
/*JD_USE:3643*/$x3643) / (
/*JD_USE:3646*/$x3646)));{const $x3647=$let0;{const $let0=(Math.fround((
/*JD_USE:3644*/$x3644) / (
/*JD_USE:3646*/$x3646)));{const $x3648=$let0;{const $let0=(Math.fround((
/*JD_USE:3645*/$x3645) / (
/*JD_USE:3646*/$x3646)));{const $x3649=$let0;{const $ord0=(Math.fround((
/*JD_USE:3640*/$x3640) * (
/*JD_USE:3647*/$x3647)));const $ord1=(Math.fround((
/*JD_USE:3641*/$x3641) * (
/*JD_USE:3648*/$x3648)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround((
/*JD_USE:3642*/$x3642) * (
/*JD_USE:3649*/$x3649)));const $let0=(
/*JD_REF:$jd$fmax0*/$jd$fmax0((Math.fround($ord2 + $ord3))));{const $x3650=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,1000));const $ord1=(Math.fround($ord0 * (
/*JD_USE:3640*/$x3640)));const $let0=(Math.fround((
/*JD_USE:3637*/$x3637) + $ord1));{const $x3651=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,1000));const $ord1=(Math.fround($ord0 * (
/*JD_USE:3641*/$x3641)));const $let0=(Math.fround((
/*JD_USE:3638*/$x3638) + $ord1));{const $x3652=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,1000));const $ord1=(Math.fround($ord0 * (
/*JD_USE:3642*/$x3642)));const $let0=(Math.fround((
/*JD_USE:3639*/$x3639) + $ord1));{const $x3653=$let0;{const $let0=(
/*JD_REF:$jd$nearest_46_t*/$jd$nearest_46_t(9,(
/*JD_USE:3651*/$x3651),(
/*JD_USE:3652*/$x3652),(
/*JD_USE:3653*/$x3653),(
/*JD_USE:3647*/$x3647),(
/*JD_USE:3648*/$x3648),(
/*JD_USE:3649*/$x3649),(Math.fround(1000000000)),(Math.fround(1000000000)),false));{const $x3654=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(85,100));const $ord1=(
/*JD_REF:$jd$shade*/$jd$shade((
/*JD_USE:3654*/$x3654),(
/*JD_USE:3646*/$x3646),(
/*JD_USE:3650*/$x3650)));const $ord2=(
/*JD_REF:$jd$fl*/$jd$fl(1,10));const $ord3=(Math.fround($ord0 * $ord1));const $let0=(Math.fround($ord2 + $ord3));{const $x3655=$let0;{const $let0=(
/*JD_REF:$jd$skr*/$jd$skr((
/*JD_USE:3635*/$x3635)));{const $x3656=$let0;{const $ord0=(Math.fround((
/*JD_USE:3630*/$x3630) * (
/*JD_USE:3640*/$x3640)));const $ord1=(Math.fround((
/*JD_USE:3631*/$x3631) * (
/*JD_USE:3641*/$x3641)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround((
/*JD_USE:3632*/$x3632) * (
/*JD_USE:3642*/$x3642)));const $ord4=(Math.fround(2));const $ord5=(Math.fround($ord2 + $ord3));const $let0=(Math.fround($ord4 * $ord5));{const $x3657=$let0;{const $ord0=(Math.fround((
/*JD_USE:3657*/$x3657) * (
/*JD_USE:3640*/$x3640)));const $let0=(Math.fround((
/*JD_USE:3630*/$x3630) - $ord0));{const $x3658=$let0;{const $ord0=(Math.fround((
/*JD_USE:3657*/$x3657) * (
/*JD_USE:3641*/$x3641)));const $let0=(Math.fround((
/*JD_USE:3631*/$x3631) - $ord0));{const $x3659=$let0;{const $ord0=(Math.fround((
/*JD_USE:3657*/$x3657) * (
/*JD_USE:3642*/$x3642)));const $let0=(Math.fround((
/*JD_USE:3632*/$x3632) - $ord0));{const $x3660=$let0;{const $let0=(
/*JD_REF:$jd$nearest*/$jd$nearest(9,(
/*JD_USE:3651*/$x3651),(
/*JD_USE:3652*/$x3652),(
/*JD_USE:3653*/$x3653),(
/*JD_USE:3658*/$x3658),(
/*JD_USE:3659*/$x3659),(
/*JD_USE:3660*/$x3660),(Math.fround(1000000000)),9,(Math.fround(1000000000)),9,false));{const $x3661=$let0;{const $ord0=(Math.fround(1));const $ord1=(Math.fround((
/*JD_USE:3634*/$x3634) * (
/*JD_USE:3655*/$x3655)));const $ord2=(Math.fround($ord0 - (
/*JD_USE:3656*/$x3656)));const $ord3=(Math.fround($ord1 * $ord2));{
/*JD_REF:$jd$trace*/const $next0=(
/*JD_USE:3614*/$x3614);const $next1=(
/*JD_USE:3661*/$x3661);const $next2=(
/*JD_USE:3651*/$x3651);const $next3=(
/*JD_USE:3652*/$x3652);const $next4=(
/*JD_USE:3653*/$x3653);const $next5=(
/*JD_USE:3658*/$x3658);const $next6=(
/*JD_USE:3659*/$x3659);const $next7=(
/*JD_USE:3660*/$x3660);const $next8=(Math.fround((
/*JD_USE:3633*/$x3633) + $ord3));const $next9=(Math.fround((
/*JD_USE:3634*/$x3634) * (
/*JD_USE:3656*/$x3656)));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$a4=$next4;$a5=$next5;$a6=$next6;$a7=$next7;$a8=$next8;$a9=$next9;continue;}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}}
function $jd$subray($a0,$a1){for(;;){const $x3675=$a0;const $x3676=$a1;{const $ord0=(Math.fround((
/*JD_USE:3675*/$x3675) * (
/*JD_USE:3675*/$x3675)));const $ord1=(Math.fround((
/*JD_USE:3676*/$x3676) * (
/*JD_USE:3676*/$x3676)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(Math.fround(1));const $ord4=(Math.fround($ord2 + $ord3));const $let0=(Math.fround(Math.sqrt($ord4)));{const $x3677=$let0;{const $let0=(Math.fround((
/*JD_USE:3675*/$x3675) / (
/*JD_USE:3677*/$x3677)));{const $x3678=$let0;{const $let0=(Math.fround((
/*JD_USE:3676*/$x3676) / (
/*JD_USE:3677*/$x3677)));{const $x3679=$let0;{const $ord0=(Math.fround(1));const $let0=(Math.fround($ord0 / (
/*JD_USE:3677*/$x3677)));{const $x3680=$let0;{const $let0=(
/*JD_REF:$jd$nearest*/$jd$nearest(9,(Math.fround(0)),(Math.fround(0)),(Math.fround(0)),(
/*JD_USE:3678*/$x3678),(
/*JD_USE:3679*/$x3679),(
/*JD_USE:3680*/$x3680),(Math.fround(1000000000)),9,(Math.fround(1000000000)),9,false));{const $x3681=$let0;return (
/*JD_REF:$jd$trace*/$jd$trace(4,(
/*JD_USE:3681*/$x3681),(Math.fround(0)),(Math.fround(0)),(Math.fround(0)),(
/*JD_USE:3678*/$x3678),(
/*JD_USE:3679*/$x3679),(
/*JD_USE:3680*/$x3680),(Math.fround(0)),(Math.fround(1))));}}}}}}}}}}}}
function $jd$pixel($a0,$a1,$a2,$a3){for(;;){const $x3686=$a0;const $x3687=$a1;const $x3688=$a2;const $x3689=$a3;{const $let0=(Math.fround((
/*JD_USE:3686*/$x3686)));{const $x3690=$let0;{const $let0=(Math.fround((
/*JD_USE:3687*/$x3687)));{const $x3691=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,4));const $ord1=(Math.fround((
/*JD_USE:3690*/$x3690) + $ord0));const $ord2=(Math.fround($ord1 - (
/*JD_USE:3688*/$x3688)));const $ord3=(
/*JD_REF:$jd$fl*/$jd$fl(1,4));const $ord4=(Math.fround((
/*JD_USE:3691*/$x3691) + $ord3));const $ord5=(Math.fround((
/*JD_USE:3689*/$x3689) - $ord4));const $let0=(
/*JD_REF:$jd$subray*/$jd$subray((Math.fround($ord2 / (
/*JD_USE:3688*/$x3688))),(Math.fround($ord5 / (
/*JD_USE:3688*/$x3688)))));{const $x3692=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(3,4));const $ord1=(Math.fround((
/*JD_USE:3690*/$x3690) + $ord0));const $ord2=(Math.fround($ord1 - (
/*JD_USE:3688*/$x3688)));const $ord3=(
/*JD_REF:$jd$fl*/$jd$fl(1,4));const $ord4=(Math.fround((
/*JD_USE:3691*/$x3691) + $ord3));const $ord5=(Math.fround((
/*JD_USE:3689*/$x3689) - $ord4));const $let0=(
/*JD_REF:$jd$subray*/$jd$subray((Math.fround($ord2 / (
/*JD_USE:3688*/$x3688))),(Math.fround($ord5 / (
/*JD_USE:3688*/$x3688)))));{const $x3693=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(1,4));const $ord1=(Math.fround((
/*JD_USE:3690*/$x3690) + $ord0));const $ord2=(Math.fround($ord1 - (
/*JD_USE:3688*/$x3688)));const $ord3=(
/*JD_REF:$jd$fl*/$jd$fl(3,4));const $ord4=(Math.fround((
/*JD_USE:3691*/$x3691) + $ord3));const $ord5=(Math.fround((
/*JD_USE:3689*/$x3689) - $ord4));const $let0=(
/*JD_REF:$jd$subray*/$jd$subray((Math.fround($ord2 / (
/*JD_USE:3688*/$x3688))),(Math.fround($ord5 / (
/*JD_USE:3688*/$x3688)))));{const $x3694=$let0;{const $ord0=(
/*JD_REF:$jd$fl*/$jd$fl(3,4));const $ord1=(Math.fround((
/*JD_USE:3690*/$x3690) + $ord0));const $ord2=(Math.fround($ord1 - (
/*JD_USE:3688*/$x3688)));const $ord3=(
/*JD_REF:$jd$fl*/$jd$fl(3,4));const $ord4=(Math.fround((
/*JD_USE:3691*/$x3691) + $ord3));const $ord5=(Math.fround((
/*JD_USE:3689*/$x3689) - $ord4));const $let0=(
/*JD_REF:$jd$subray*/$jd$subray((Math.fround($ord2 / (
/*JD_USE:3688*/$x3688))),(Math.fround($ord5 / (
/*JD_USE:3688*/$x3688)))));{const $x3695=$let0;{const $ord0=(Math.fround((
/*JD_USE:3692*/$x3692) + (
/*JD_USE:3693*/$x3693)));const $ord1=(Math.fround((
/*JD_USE:3694*/$x3694) + (
/*JD_USE:3695*/$x3695)));const $ord2=(Math.fround($ord0 + $ord1));const $ord3=(
/*JD_REF:$jd$fl*/$jd$fl(1,4));const $ord4=(Math.fround(255));const $ord5=(
/*JD_REF:$jd$clamp01*/$jd$clamp01((Math.fround($ord2 * $ord3))));const $ord6=(Math.fround($ord4 * $ord5));return (($ord6 >= 1 && $ord6 < 4294967296 ? Math.floor($ord6) : 0));}}}}}}}}}}}}}}}
function $jd$colf_46_px_46_go($a0,$a1,$a2,$a3,$a4){for(;;){{const $match1=$a0;if(!$match1){return 0;}else{{const $match2=$match1;const $x3705=$a1;const $x3706=$a2;const $x3707=$a3;const $x3708=$a4;return (
/*JD_REF:$jd$pixel*/$jd$pixel((
/*JD_USE:3705*/$x3705),(
/*JD_USE:3706*/$x3706),(
/*JD_USE:3707*/$x3707),(
/*JD_USE:3708*/$x3708)));}}}}}
function $jd$colf_46_px($a0,$a1,$a2,$a3,$a4){for(;;){const $x3714=$a0;const $x3715=$a1;const $x3716=$a2;const $x3717=$a3;const $x3718=$a4;return (
/*JD_REF:$jd$colf_46_px_46_go*/$jd$colf_46_px_46_go((((
/*JD_USE:3714*/$x3714) < (
/*JD_USE:3716*/$x3716))),(
/*JD_USE:3714*/$x3714),(
/*JD_USE:3715*/$x3715),(
/*JD_USE:3717*/$x3717),(
/*JD_USE:3718*/$x3718)));}}
function $jd$colf($a0,$a1,$a2,$a3,$a4,$a5){for(;;){{const $match1=$a0;if($match1===0){const $x3725=$a1;const $x3726=$a2;const $x3727=$a3;const $x3728=$a4;const $x3729=$a5;{const $ord0=((Math.imul((
/*JD_USE:3725*/$x3725), 2654435761) >>> 0));return (
/*JD_REF:$jd$colf_46_px*/$jd$colf_46_px(((($ord0 & 16383) >>> 0)),(
/*JD_USE:3726*/$x3726),(
/*JD_USE:3727*/$x3727),(
/*JD_USE:3728*/$x3728),(
/*JD_USE:3729*/$x3729)));}}else{const $x3730=($match1-1);const $x3731=$a1;const $x3732=$a2;const $x3733=$a3;const $x3734=$a4;const $x3735=$a5;{const $let0=(
/*JD_REF:$jd$colf*/$jd$colf((
/*JD_USE:3730*/$x3730),(
/*JD_USE:3731*/$x3731),(
/*JD_USE:3732*/$x3732),(
/*JD_USE:3733*/$x3733),(
/*JD_USE:3734*/$x3734),(
/*JD_USE:3735*/$x3735)));const $ord0=(((
/*JD_USE:3730*/$x3730) >= 32 ? 0 : (1 << (
/*JD_USE:3730*/$x3730)) >>> 0));const $let1=(
/*JD_REF:$jd$colf*/$jd$colf((
/*JD_USE:3730*/$x3730),((((
/*JD_USE:3731*/$x3731) + $ord0) >>> 0)),(
/*JD_USE:3732*/$x3732),(
/*JD_USE:3733*/$x3733),(
/*JD_USE:3734*/$x3734),(
/*JD_USE:3735*/$x3735)));{const $x3736=$let0;const $x3737=$let1;return ((((
/*JD_USE:3736*/$x3736) + (
/*JD_USE:3737*/$x3737)) >>> 0));}}}}}}
function $jd$rowf($a0,$a1,$a2,$a3,$a4,$a5){for(;;){{const $match1=$a0;if($match1===0){const $x3744=$a1;const $x3745=$a2;const $x3746=$a3;const $x3747=$a4;const $x3748=$a5;{const $ord0=((Math.imul((
/*JD_USE:3744*/$x3744), 1588635697) >>> 0));return (
/*JD_REF:$jd$colf*/$jd$colf(14,0,((($ord0 & (
/*JD_USE:3745*/$x3745)) >>> 0)),(
/*JD_USE:3746*/$x3746),(
/*JD_USE:3747*/$x3747),(
/*JD_USE:3748*/$x3748)));}}else{const $x3749=($match1-1);const $x3750=$a1;const $x3751=$a2;const $x3752=$a3;const $x3753=$a4;const $x3754=$a5;{const $let0=(
/*JD_REF:$jd$rowf*/$jd$rowf((
/*JD_USE:3749*/$x3749),(
/*JD_USE:3750*/$x3750),(
/*JD_USE:3751*/$x3751),(
/*JD_USE:3752*/$x3752),(
/*JD_USE:3753*/$x3753),(
/*JD_USE:3754*/$x3754)));const $ord0=(((
/*JD_USE:3749*/$x3749) >= 32 ? 0 : (1 << (
/*JD_USE:3749*/$x3749)) >>> 0));const $let1=(
/*JD_REF:$jd$rowf*/$jd$rowf((
/*JD_USE:3749*/$x3749),((((
/*JD_USE:3750*/$x3750) + $ord0) >>> 0)),(
/*JD_USE:3751*/$x3751),(
/*JD_USE:3752*/$x3752),(
/*JD_USE:3753*/$x3753),(
/*JD_USE:3754*/$x3754)));{const $x3755=$let0;const $x3756=$let1;return ((((
/*JD_USE:3755*/$x3755) + (
/*JD_USE:3756*/$x3756)) >>> 0));}}}}}}
function $jd$rows(){for(;;){return 12;}}
function $jd$width(){for(;;){return 6000;}}
function $jd$bench($a0,$a1){for(;;){const $x3764=$a0;{const $let0=(6);{const $x3766=$let0;{const $ord0=((2 === 0 ? 0 : ((
/*JD_USE:3764*/$x3764) / 2) >>> 0));const $let0=(Math.fround($ord0));{const $x3767=$let0;{const $ord0=(((
/*JD_USE:3766*/$x3766) >= 32 ? 0 : (1 << (
/*JD_USE:3766*/$x3766)) >>> 0));const $ord1=((2 === 0 ? 0 : ($ord0 / 2) >>> 0));const $let0=(Math.fround($ord1));{const $x3768=$let0;{const $ord0=(((
/*JD_USE:3766*/$x3766) >= 32 ? 0 : (1 << (
/*JD_USE:3766*/$x3766)) >>> 0));const $let0=((($ord0 - 1) >>> 0));{const $x3769=$let0;return (
/*JD_REF:$jd$rowf*/$jd$rowf((
/*JD_USE:3766*/$x3766),0,(
/*JD_USE:3769*/$x3769),(
/*JD_USE:3764*/$x3764),(
/*JD_USE:3767*/$x3767),(
/*JD_USE:3768*/$x3768)));}}}}}}}}}}

export const backend={kind:"direct-js",representation:"upstream-native",prototype:true,foreign:"upstream-cps"};
export default {
"Hit.t":run_lib((a0,)=>{const r=(run_loop($jd$Hit_46_t((a0),)));(a0);return r;},1),
"fl":run_lib((a0,a1,)=>{const r=(run_loop($jd$fl((a0),(a1),)));(a0);(a1);return r;},2),
"sphere":run_lib((a0,)=>{const r=(run_loop($jd$sphere(nat_host(a0),)));BigInt(a0);return r;},1),
"isect.t2":run_lib((a0,a1,)=>{const r=(run_loop($jd$isect_46_t2((a0),(a1),)));(a0);(a1);return r;},2),
"isect.t":run_lib((a0,)=>{const r=(run_loop($jd$isect_46_t((a0),)));(a0);return r;},1),
"isect.go2":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$isect_46_go2((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"isect.go":run_lib((a0,a1,)=>{const r=(run_loop($jd$isect_46_go((a0),(a1),)));(a0);(a1);return r;},2),
"isect5":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,)=>{const r=(run_loop($jd$isect5((a0),(a1),(a2),(a3),(a4),(a5),(a6),(a7),(a8),(a9),)));(a0);(a1);(a2);(a3);(a4);(a5);(a6);(a7);(a8);(a9);return r;},10),
"sx":run_lib((a0,)=>{const r=(run_loop($jd$sx(nat_host(a0),)));BigInt(a0);return r;},1),
"sy":run_lib((a0,)=>{const r=(run_loop($jd$sy(nat_host(a0),)));BigInt(a0);return r;},1),
"sz":run_lib((a0,)=>{const r=(run_loop($jd$sz(nat_host(a0),)));BigInt(a0);return r;},1),
"sr":run_lib((a0,)=>{const r=(run_loop($jd$sr(nat_host(a0),)));BigInt(a0);return r;},1),
"skr":run_lib((a0,)=>{const r=(run_loop($jd$skr(nat_host(a0),)));BigInt(a0);return r;},1),
"nearest":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,)=>{const r=(run_loop($jd$nearest(nat_host(a0),(a1),(a2),(a3),(a4),(a5),(a6),(a7),(a8),(a9),(a10),(a11),)));BigInt(a0);(a1);(a2);(a3);(a4);(a5);(a6);(a7);(a8);(a9);(a10);(a11);return r;},12),
"fmax0.go":run_lib((a0,a1,)=>{const r=(run_loop($jd$fmax0_46_go((a0),(a1),)));(a0);(a1);return r;},2),
"fmax0":run_lib((a0,)=>{const r=(run_loop($jd$fmax0((a0),)));(a0);return r;},1),
"shade":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$shade((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"clamp01.hi.go":run_lib((a0,a1,)=>{const r=(run_loop($jd$clamp01_46_hi_46_go((a0),(a1),)));(a0);(a1);return r;},2),
"clamp01.hi":run_lib((a0,)=>{const r=(run_loop($jd$clamp01_46_hi((a0),)));(a0);return r;},1),
"clamp01.go":run_lib((a0,a1,)=>{const r=(run_loop($jd$clamp01_46_go((a0),(a1),)));(a0);(a1);return r;},2),
"clamp01":run_lib((a0,)=>{const r=(run_loop($jd$clamp01((a0),)));(a0);return r;},1),
"nearest.t":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,)=>{const r=(run_loop($jd$nearest_46_t(nat_host(a0),(a1),(a2),(a3),(a4),(a5),(a6),(a7),(a8),(a9),)));BigInt(a0);(a1);(a2);(a3);(a4);(a5);(a6);(a7);(a8);(a9);return r;},10),
"trace":run_lib((a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,)=>{const r=(run_loop($jd$trace(nat_host(a0),(a1),(a2),(a3),(a4),(a5),(a6),(a7),(a8),(a9),)));BigInt(a0);(a1);(a2);(a3);(a4);(a5);(a6);(a7);(a8);(a9);return r;},10),
"subray":run_lib((a0,a1,)=>{const r=(run_loop($jd$subray((a0),(a1),)));(a0);(a1);return r;},2),
"pixel":run_lib((a0,a1,a2,a3,)=>{const r=(run_loop($jd$pixel((a0),(a1),(a2),(a3),)));(a0);(a1);(a2);(a3);return r;},4),
"colf.px.go":run_lib((a0,a1,a2,a3,a4,)=>{const r=(run_loop($jd$colf_46_px_46_go((a0),(a1),(a2),(a3),(a4),)));(a0);(a1);(a2);(a3);(a4);return r;},5),
"colf.px":run_lib((a0,a1,a2,a3,a4,)=>{const r=(run_loop($jd$colf_46_px((a0),(a1),(a2),(a3),(a4),)));(a0);(a1);(a2);(a3);(a4);return r;},5),
"colf":run_lib((a0,a1,a2,a3,a4,a5,)=>{const r=(run_loop($jd$colf(nat_host(a0),(a1),(a2),(a3),(a4),(a5),)));BigInt(a0);(a1);(a2);(a3);(a4);(a5);return r;},6),
"rowf":run_lib((a0,a1,a2,a3,a4,a5,)=>{const r=(run_loop($jd$rowf(nat_host(a0),(a1),(a2),(a3),(a4),(a5),)));BigInt(a0);(a1);(a2);(a3);(a4);(a5);return r;},6),
"rows":run_lib(()=>{const r=BigInt(run_loop($jd$rows()));return r;},0),
"width":run_lib(()=>{const r=(run_loop($jd$width()));return r;},0),
"bench":run_lib((a0,a1,)=>{const r=(run_loop($jd$bench((a0),(a1),)));(a0);(a1);return r;},2),
};
