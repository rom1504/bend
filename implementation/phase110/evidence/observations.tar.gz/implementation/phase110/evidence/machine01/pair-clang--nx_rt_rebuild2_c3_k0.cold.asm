
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040188c <nx_rt_rebuild2_c3_k0.cold>:
  40188c:	mov    $0x1,%edx
  401891:	mov    %r8,0x18(%rsp)
  401896:	mov    %rdi,0x10(%rsp)
  40189b:	mov    %rsi,0x8(%rsp)
  4018a0:	callq  401178 <heap_alloc_miss>
  4018a5:	mov    0x8(%rsp),%rsi
  4018aa:	mov    0x10(%rsp),%rdi
  4018af:	mov    0x18(%rsp),%r8
  4018b4:	mov    %rax,%r9
  4018b7:	jmpq   403789 <nx_rt_rebuild2_c3_k0+0x49>
  4018bc:	xor    %edx,%edx
  4018be:	mov    %r8,0x8(%rsp)
  4018c3:	callq  401100 <heap_hand>
  4018c8:	mov    0x8(%rsp),%r8
  4018cd:	jmpq   403846 <nx_rt_rebuild2_c3_k0+0x106>
  4018d2:	mov    %r13,%rcx
  4018d5:	mov    %r10,%rdx
  4018d8:	mov    %r8,0x18(%rsp)
  4018dd:	mov    0x0(%rbp),%r12
  4018e1:	mov    %rdi,0x10(%rsp)
  4018e6:	mov    (%r11),%rbp
  4018e9:	mov    %rsi,0x8(%rsp)
  4018ee:	callq  4014c6 <span_fade.constprop.0>
  4018f3:	mov    0x8(%rsp),%rsi
  4018f8:	mov    0x10(%rsp),%rdi
  4018fd:	mov    0x18(%rsp),%r8
  401902:	jmpq   4037b8 <nx_rt_rebuild2_c3_k0+0x78>

Disassembly of section .fini:
