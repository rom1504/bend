
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040196c <nx_rt_rebuild2_c3_k0.cold>:
  40196c:	mov    %r14,%rdx
  40196f:	mov    $0x1,%ecx
  401974:	mov    %r13,%rdi
  401977:	mov    %r15,%rsi
  40197a:	mov    %r8,(%rsp)
  40197e:	callq  401397 <rfc_wrap>
  401983:	mov    (%rsp),%r8
  401987:	mov    %rax,%r14
  40198a:	jmpq   403bfb <nx_rt_rebuild2_c3_k0+0x7b>
  40198f:	mov    %r12,%rdx
  401992:	mov    $0x1,%ecx
  401997:	mov    %r13,%rdi
  40199a:	mov    %r15,%rsi
  40199d:	callq  401397 <rfc_wrap>
  4019a2:	mov    %rax,%r12
  4019a5:	jmpq   403c13 <nx_rt_rebuild2_c3_k0+0x93>
  4019aa:	mov    $0x1,%edx
  4019af:	mov    %r13,%rdi
  4019b2:	mov    %r15,%rsi
  4019b5:	mov    %r9,(%rsp)
  4019b9:	callq  401178 <heap_alloc_miss>
  4019be:	mov    (%rsp),%r9
  4019c2:	mov    %rax,%rbx
  4019c5:	lea    0x0(%r13,%rax,8),%r8
  4019ca:	jmpq   403bd8 <nx_rt_rebuild2_c3_k0+0x58>
  4019cf:	xor    %edx,%edx
  4019d1:	mov    %r13,%rdi
  4019d4:	mov    %r15,%rsi
  4019d7:	mov    %rcx,0x8(%rsp)
  4019dc:	mov    %r9,(%rsp)
  4019e0:	callq  401100 <heap_hand>
  4019e5:	mov    (%rsp),%r9
  4019e9:	mov    0x8(%rsp),%rcx
  4019ee:	jmpq   403ce7 <nx_rt_rebuild2_c3_k0+0x167>
  4019f3:	mov    (%r8),%r9
  4019f6:	mov    (%rdi),%r14
  4019f9:	mov    %rsi,%rdx
  4019fc:	mov    %r13,%rdi
  4019ff:	mov    %r15,%rsi
  401a02:	mov    %r9,(%rsp)
  401a06:	callq  401471 <span_fade.constprop.0>
  401a0b:	mov    (%rsp),%r9
  401a0f:	jmpq   403c58 <nx_rt_rebuild2_c3_k0+0xd8>

Disassembly of section .fini:
