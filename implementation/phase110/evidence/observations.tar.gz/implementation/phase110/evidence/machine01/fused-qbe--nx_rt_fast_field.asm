
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d30 <nx_rt_fast_field>:
  402d30:	mov    %esi,%ecx
  402d32:	mov    $0xfffffffe,%eax
  402d37:	rol    %cl,%eax
  402d39:	add    $0x2,%rcx
  402d3d:	and    %eax,0x20(%rdi)
  402d40:	mov    (%rdi,%rcx,8),%rax
  402d44:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402d4c:	retq   

Disassembly of section .fini:
