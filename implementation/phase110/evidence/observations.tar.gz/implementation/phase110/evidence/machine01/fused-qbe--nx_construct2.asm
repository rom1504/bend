
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401ff0 <nx_construct2>:
  401ff0:	push   %r12
  401ff2:	mov    %rcx,%rax
  401ff5:	push   %rbp
  401ff6:	shr    $0x38,%rax
  401ffa:	lea    0x0(,%r9,8),%rbp
  402002:	push   %rbx
  402003:	and    $0x7f,%eax
  402006:	mov    %edx,%ebx
  402008:	lea    (%rdi,%rbp,1),%r12
  40200c:	mov    %rcx,%rdx
  40200f:	sub    $0x20,%rsp
  402013:	cmp    $0x2,%rax
  402017:	je     402050 <nx_construct2+0x60>
  402019:	mov    %r8,%rax
  40201c:	mov    %rdx,(%r12)
  402020:	lea    0x8(%rbp,%rdi,1),%rbp
  402025:	shr    $0x38,%rax
  402029:	and    $0x7f,%eax
  40202c:	cmp    $0x2,%rax
  402030:	je     402060 <nx_construct2+0x70>
  402032:	mov    %rbx,%rax
  402035:	mov    %r8,0x0(%rbp)
  402039:	add    $0x20,%rsp
  40203d:	shl    $0x28,%rax
  402041:	pop    %rbx
  402042:	pop    %rbp
  402043:	or     %r9,%rax
  402046:	pop    %r12
  402048:	bts    $0x39,%rax
  40204d:	retq   
  40204e:	xchg   %ax,%ax
  402050:	test   %rcx,%rcx
  402053:	js     402019 <nx_construct2+0x29>
  402055:	jmpq   401410 <nx_construct2.cold>
  40205a:	nopw   0x0(%rax,%rax,1)
  402060:	test   %r8,%r8
  402063:	js     402032 <nx_construct2+0x42>
  402065:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
