
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402170 <nx_rt_id>:
  402170:	cmpb   $0x0,0x5009(%rip)        # 407180 <nx_active>
  402177:	je     402185 <nx_rt_id+0x15>
  402179:	lea    0x5020(%rip),%rax        # 4071a0 <nx_context>
  402180:	cmp    %rax,%rdi
  402183:	je     402198 <nx_rt_id+0x28>
  402185:	push   %rax
  402186:	lea    0x1ea6(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  40218d:	callq  401950 <err_fail>
  402192:	nopw   0x0(%rax,%rax,1)
  402198:	mov    0x5001(%rip),%rdi        # 4071a0 <nx_context>
  40219f:	jmpq   401a80 <nx_id.isra.0>

Disassembly of section .fini:
