
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e10 <nx_list_reverse>:
  401e10:	endbr64 
  401e14:	push   %rbp
  401e15:	mov    %rsp,%rbp
  401e18:	sub    $0x8,%rsp
  401e1c:	push   %rbx
  401e1d:	push   %r12
  401e1f:	push   %r13
  401e21:	mov    %rdx,%rax
  401e24:	mov    %rax,%r13
  401e27:	nopw   0x0(%rax,%rax,1)
  401e30:	mov    %rsi,%r12
  401e33:	mov    %rdi,%rbx
  401e36:	callq  402c60 <nx_rt_fast_id>
  401e3b:	mov    %r13,%rdx
  401e3e:	mov    %r12,%rsi
  401e41:	mov    %rbx,%rdi
  401e44:	cmp    $0x0,%eax
  401e47:	je     401e90 <nx_list_reverse+0x80>
  401e49:	cmp    $0x1,%eax
  401e4c:	jne    401e84 <nx_list_reverse+0x74>
  401e4e:	mov    %rdx,%r8
  401e51:	mov    $0x0,%ecx
  401e56:	mov    $0x1,%edx
  401e5b:	mov    %rdi,%rbx
  401e5e:	callq  402f30 <nx_rt_rebuild2>
  401e63:	mov    %rbx,%rdi
  401e66:	mov    %rax,%r12
  401e69:	mov    $0x0,%esi
  401e6e:	mov    %rdi,%rbx
  401e71:	callq  402f10 <nx_rt_fast_field>
  401e76:	mov    %r12,%rdx
  401e79:	mov    %rbx,%rdi
  401e7c:	mov    %rax,%rsi
  401e7f:	mov    %rdx,%r13
  401e82:	jmp    401e30 <nx_list_reverse+0x20>
  401e84:	mov    $0x1,%esi
  401e89:	callq  402710 <nx_rt_fail>
  401e8e:	jmp    401e93 <nx_list_reverse+0x83>
  401e90:	mov    %rdx,%rax
  401e93:	pop    %r13
  401e95:	pop    %r12
  401e97:	pop    %rbx
  401e98:	leaveq 
  401e99:	retq   

Disassembly of section .fini:
