// Direct JavaScript backend runtime. Generated output embeds this fragment.
// Ported from bend2/comp.ts NATIVE.JS, RUNTIME and RUNTIME_MAIN, and
// bend2/bend.ts f32_round at fixed upstream commit
// 018751270e800bc222a93dad7f257083ee53a5f7. The reference files stay unchanged.
// No TypeScript compiler/runtime dependency is used by ordinary compilation.
// Number is the internal Nat representation; nat_host handles typed host input.
// Node foreign IO requires the host emitter to provide an ESM require binding.
// Bun/system calls remain lazy, exactly as in the pinned upstream runtime.

function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s) {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s);
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}
// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}

// Cli
// ===

let cli_args = [];

function cli(argv) {
  cli_args.push(argv[0]);
  for (let i = 1; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--bend-help") {
      io_out(1, io_bytes("usage: " + argv[0] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// show_val prints a pure main's value as term_show does (see show_main);
// chain is the bracket it continues, or 0. show_chr escapes as char_show.

function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    || (c >= 0xD800 && c <= 0xDFFF) || c > 0x10FFFF
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 4 + 2 * D[a + 2]) {}
    const o = "{[("[D[a + 3]];
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 5 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + "}])"[D[a + 3]] : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

// Apple arm64 passes variadic fcntl flags on the stack, so io_sys
// binds fcntl there with the flags as the ninth fixed argument. A
// parked effect waits for fd (a write when out) or until at
// (performance.now()), either one undefined when unused; io_wake
// resumes k with the value of more, and undefined parks it again. The
// waits stay in deadline order, as io_park does in C.

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const sel = mac ? "select$DARWIN_EXTSN" : "select";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I recvfrom:ipUipp>I close:i>i setsockopt:iiipu>i"
        + " " + sel + ":ipppp>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      }))).symbols;
    const fcntl = (fd, cmd, arg) => vari
      ? lib.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib, fcntl, select: lib[sel],
      ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

function io_fail(code) {
  return { $: "Fail",
    error: io_tup(code >>> 0, String(io_sys().strerror(code))) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst, snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  return new TextDecoder("utf-8", { ignoreBOM: true }).decode(b.subarray(0, n));
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8 in
// either direction; io_unlist answers null if a value is past 255.
function io_list(b, n) {
  let xs = { $: "Nil" };
  while (n > 0) {
    xs = { $: "Con", head: b[--n], tail: xs };
  }
  return xs;
}

function io_unlist(xs) {
  const b = [];
  for (; xs.$ === "Con"; xs = xs.tail) {
    b.push(xs.head);
  }
  return b.some((x) => x > 255) ? null : Uint8Array.from(b);
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun, arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io) {
  const soon = io.waits[0]?.at ?? Infinity;
  const ms = soon === Infinity ? -1
    : Math.max(0, Math.ceil(soon - performance.now()));
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const top = fds.reduce((m, w) => Math.max(m, w.fd), 0);
  const len = (top >> 6 << 3) + 8;
  const set = new Uint8Array(2 * len);
  const at = (w) => (w.out ? len : 0) + (w.fd >> 3);
  for (const w of fds) {
    set[at(w)] |= 1 << (w.fd & 7);
  }
  const tv = new BigInt64Array([BigInt(ms / 1000 | 0),
    BigInt(ms % 1000 * 1000)]);
  const sys = io_sys();
  if (sys.select(top + 1, sys.ptr(set), sys.ptr(set, len), null,
    ms < 0 ? null : sys.ptr(tv)) < 0) {
    if (sys.errno() !== 4) {
      throw "bend: the poller failed";
    }
    set.fill(0);
  }
  const now = performance.now();
  io.waits = io.waits.filter((w) => {
    const ready = w.at <= now || w.fd !== undefined
      && set[at(w)] & 1 << (w.fd & 7);
    if (ready) {
      io_push(io_wake, w, false);
    }
    return !ready;
  });
}

function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

function io_park_on(fd, out, k, more, at) {
  const ws = globalThis.BEND_IO.waits;
  const i = ws.findLastIndex((w) => (w.at ?? Infinity) <= (at ?? Infinity));
  ws.splice(i + 1, 0, { fd, out, k, more, at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    for (;;) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io);
        continue;
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      while (op !== undefined) {
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        if (need.time || need.read) {
          const more = () => op.run(...op.args, op.kont);
          io_park_on(need.read ? op.args[0] : undefined, false, op.kont, more,
            need.read ? undefined : performance.now() + Number(op.args[0]));
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

// Direct core names. A named tail call carries all already-evaluated arguments;
// run_tail above retains the upstream unary native-closure protocol unchanged.
const jd_run = run_loop;
const jd_clo = run_clo;
function jd_tail(f, args) {
  return {$: "$JMP", f, x: args};
}


// Direct JavaScript prototype: native functions and live arguments.
function $jd$Bool_46_and($a0,$a1){for(;;){{const $match1=$a0;if(!$match1){return false;}else{{const $match2=$match1;const $x367=$a1;return (
/*JD_USE:367*/$x367);}}}}}
function $jd$Maybe_46_default($a0,$a1){for(;;){const $x529=null;const $x530=null;{const $match3=$a0;if($match3.$==="None"){const $x531=$a1;return (
/*JD_USE:531*/$x531);}else{{const $match4=$match3;const $x532=$match4["value"];return (
/*JD_USE:532*/$x532);}}}}}
function $jd$U32_46_add($a0,$a1){return (($a0 + $a1) >>> 0);}
function $jd$U32_46_is_95_eq($a0,$a1){return ($a0 === $a1);}
function $jd$U32_46_to_95_nat($a0){return $a0;}
function $jd$String_46_append($a0,$a1){return ($a0 + $a1);}
function $jd$U32_46_show_46_fin($a0,$a1,$a2,$a3){let $pc=0;for(;;)switch($pc){case 0:{const $x1892=$a0;const $x1893=$a1;const $x1894=$a2;{const $match4=$a3;if($match4){return (
/*JD_USE:1893*/$x1893);}else{{const $match5=$match4;{
/*JD_REF:$jd$U32_46_show_46_go*/const $next0=(
/*JD_USE:1892*/$x1892);const $next1=((10 === 0 ? 0 : ((
/*JD_USE:1894*/$x1894) / 10) >>> 0));const $next2=(char_new((
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add(48,((10 === 0 ? (
/*JD_USE:1894*/$x1894) : (
/*JD_USE:1894*/$x1894) % 10)))))+(
/*JD_USE:1893*/$x1893));$a0=$next0;$a1=$next1;$a2=$next2;$pc=1;continue;}}}}}case 1:{{const $match1=$a0;if($match1===0){const $x1899=$a2;return (
/*JD_USE:1899*/$x1899);}else{const $x1900=($match1-1);const $x1901=$a1;const $x1902=$a2;{
/*JD_REF:$jd$U32_46_show_46_fin*/const $next0=(
/*JD_USE:1900*/$x1900);const $next1=(
/*JD_USE:1902*/$x1902);const $next2=(
/*JD_USE:1901*/$x1901);const $next3=(((
/*JD_USE:1901*/$x1901) === 0));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$pc=0;continue;}}}}}}
function $jd$U32_46_show_46_go($a0,$a1,$a2,$a3){let $pc=1;for(;;)switch($pc){case 0:{const $x1892=$a0;const $x1893=$a1;const $x1894=$a2;{const $match4=$a3;if($match4){return (
/*JD_USE:1893*/$x1893);}else{{const $match5=$match4;{
/*JD_REF:$jd$U32_46_show_46_go*/const $next0=(
/*JD_USE:1892*/$x1892);const $next1=((10 === 0 ? 0 : ((
/*JD_USE:1894*/$x1894) / 10) >>> 0));const $next2=(char_new((
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add(48,((10 === 0 ? (
/*JD_USE:1894*/$x1894) : (
/*JD_USE:1894*/$x1894) % 10)))))+(
/*JD_USE:1893*/$x1893));$a0=$next0;$a1=$next1;$a2=$next2;$pc=1;continue;}}}}}case 1:{{const $match1=$a0;if($match1===0){const $x1899=$a2;return (
/*JD_USE:1899*/$x1899);}else{const $x1900=($match1-1);const $x1901=$a1;const $x1902=$a2;{
/*JD_REF:$jd$U32_46_show_46_fin*/const $next0=(
/*JD_USE:1900*/$x1900);const $next1=(
/*JD_USE:1902*/$x1902);const $next2=(
/*JD_USE:1901*/$x1901);const $next3=(((
/*JD_USE:1901*/$x1901) === 0));$a0=$next0;$a1=$next1;$a2=$next2;$a3=$next3;$pc=0;continue;}}}}}}
function $jd$U32_46_show_46_if($a0,$a1){for(;;){const $x1905=$a0;{const $match2=$a1;if($match2){return ("0"+"");}else{{const $match3=$match2;return (
/*JD_REF:$jd$U32_46_show_46_go*/$jd$U32_46_show_46_go(10,(
/*JD_USE:1905*/$x1905),""));}}}}}
function $jd$U32_46_show($a0){for(;;){const $x1907=$a0;{const $let0=(
/*JD_USE:1907*/$x1907);{const $x1908=$let0;return (
/*JD_REF:$jd$U32_46_show_46_if*/$jd$U32_46_show_46_if((
/*JD_USE:1908*/$x1908),(((
/*JD_USE:1908*/$x1908) === 0))));}}}}
function $jd$bu($a0){for(;;){{const $match1=$a0;if(!$match1){return 0;}else{{const $match2=$match1;return 1;}}}}}
function $jd$seq_95_($a0,$a1){for(;;){{const $match1=$a0;if($match1===""){{const $match2=$a1;if($match2===""){return true;}else{{const $match3=$match2;return false;}}}}else{{const $match2=$match1;{const $match3=($match2.codePointAt(0)>0xFFFF?$match2.slice(0,2):$match2[0]);const $x3422=($match2.codePointAt(0)>0xFFFF?$match2.slice(2):$match2.slice(1));{const $match6=$a1;if($match6===""){return false;}else{{const $match7=$match6;{const $match8=($match7.codePointAt(0)>0xFFFF?$match7.slice(0,2):$match7[0]);const $x3424=($match7.codePointAt(0)>0xFFFF?$match7.slice(2):$match7.slice(1));return (
/*JD_REF:$jd$Bool_46_and*/$jd$Bool_46_and((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_USE:3421*/$match3.codePointAt(0)),(
/*JD_USE:3423*/$match8.codePointAt(0)))),(
/*JD_REF:$jd$seq_95_*/$jd$seq_95_((
/*JD_USE:3422*/$x3422),(
/*JD_USE:3424*/$x3424)))));}}}}}}}}}}
function $jd$starts($a0,$a1){for(;;){{const $match1=$a0;if($match1===""){return true;}else{{const $match2=$match1;{const $match3=($match2.codePointAt(0)>0xFFFF?$match2.slice(0,2):$match2[0]);const $x3433=($match2.codePointAt(0)>0xFFFF?$match2.slice(2):$match2.slice(1));{const $match6=$a1;if($match6===""){return false;}else{{const $match7=$match6;{const $match8=($match7.codePointAt(0)>0xFFFF?$match7.slice(0,2):$match7[0]);const $x3435=($match7.codePointAt(0)>0xFFFF?$match7.slice(2):$match7.slice(1));return (
/*JD_REF:$jd$Bool_46_and*/$jd$Bool_46_and((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_USE:3432*/$match3.codePointAt(0)),(
/*JD_USE:3434*/$match8.codePointAt(0)))),(
/*JD_REF:$jd$starts*/$jd$starts((
/*JD_USE:3433*/$x3433),(
/*JD_USE:3435*/$x3435)))));}}}}}}}}}}
function $jd$sfind_46_nil($a0){for(;;){{const $match1=$a0;if($match1){return ({$:"Some",["value"]:0});}else{{const $match2=$match1;return ({$:"None"});}}}}}
function $jd$sfind_46_bump($a0){for(;;){{const $match1=$a0;if($match1.$==="None"){return ({$:"None"});}else{{const $match2=$match1;const $x3444=$match2["value"];return ({$:"Some",["value"]:((((
/*JD_USE:3444*/$x3444) + 1) >>> 0))});}}}}}
function $jd$sfind_46_pick($a0,$a1){for(;;){const $x3449=$a0;{const $match2=$a1;if($match2){return ({$:"Some",["value"]:0});}else{{const $match3=$match2;return (
/*JD_REF:$jd$sfind_46_bump*/$jd$sfind_46_bump((
/*JD_USE:3449*/$x3449)));}}}}}
function $jd$sfind($a0,$a1){for(;;){const $x3452=$a0;{const $match2=$a1;if($match2===""){return (
/*JD_REF:$jd$sfind_46_nil*/$jd$sfind_46_nil((
/*JD_REF:$jd$starts*/$jd$starts((
/*JD_USE:3452*/$x3452),""))));}else{{const $match3=$match2;const $x3453=($match3.codePointAt(0)>0xFFFF?$match3.slice(0,2):$match3[0]);const $x3454=($match3.codePointAt(0)>0xFFFF?$match3.slice(2):$match3.slice(1));{const $let0=(
/*JD_USE:3454*/$x3454);{const $x3455=$let0;return (
/*JD_REF:$jd$sfind_46_pick*/$jd$sfind_46_pick((
/*JD_REF:$jd$sfind*/$jd$sfind((
/*JD_USE:3452*/$x3452),(
/*JD_USE:3455*/$x3455))),(
/*JD_REF:$jd$starts*/$jd$starts((
/*JD_USE:3452*/$x3452),((
/*JD_USE:3453*/$x3453)+(
/*JD_USE:3455*/$x3455))))));}}}}}}}
function $jd$stake($a0,$a1){for(;;){{const $match1=$a0;if($match1===0){return "";}else{const $x3461=($match1-1);{const $match3=$a1;if($match3===""){return "";}else{{const $match4=$match3;const $x3462=($match4.codePointAt(0)>0xFFFF?$match4.slice(0,2):$match4[0]);const $x3463=($match4.codePointAt(0)>0xFFFF?$match4.slice(2):$match4.slice(1));return ((
/*JD_USE:3462*/$x3462)+(
/*JD_REF:$jd$stake*/$jd$stake((
/*JD_USE:3461*/$x3461),(
/*JD_USE:3463*/$x3463))));}}}}}}}
function $jd$sdrop($a0,$a1){for(;;){{const $match1=$a0;if($match1===0){const $x3468=$a1;return (
/*JD_USE:3468*/$x3468);}else{const $x3469=($match1-1);{const $match3=$a1;if($match3===""){return "";}else{{const $match4=$match3;const $x3471=($match4.codePointAt(0)>0xFFFF?$match4.slice(2):$match4.slice(1));{
/*JD_REF:$jd$sdrop*/const $next0=(
/*JD_USE:3469*/$x3469);const $next1=(
/*JD_USE:3471*/$x3471);$a0=$next0;$a1=$next1;continue;}}}}}}}}
function $jd$ssplit_46_push($a0,$a1){for(;;){const $x3476=$a0;{const $match2=$a1;if($match2.$==="Nil"){return ({$:"Con",["head"]:((
/*JD_USE:3476*/$x3476)+""),["tail"]:({$:"Nil"})});}else{{const $match3=$match2;const $x3477=$match3["head"];const $x3478=$match3["tail"];return ({$:"Con",["head"]:((
/*JD_USE:3476*/$x3476)+(
/*JD_USE:3477*/$x3477)),["tail"]:(
/*JD_USE:3478*/$x3478)});}}}}}
function $jd$ssplit_46_pick($a0,$a1,$a2){for(;;){const $x3487=$a0;const $x3488=$a1;{const $match3=$a2;if($match3){return ({$:"Con",["head"]:"",["tail"]:(
/*JD_USE:3488*/$x3488)});}else{{const $match4=$match3;return (
/*JD_REF:$jd$ssplit_46_push*/$jd$ssplit_46_push(char_new((
/*JD_USE:3487*/$x3487)),(
/*JD_USE:3488*/$x3488)));}}}}}
function $jd$ssplit($a0,$a1){for(;;){const $x3491=$a0;{const $match2=$a1;if($match2===""){return ({$:"Con",["head"]:"",["tail"]:({$:"Nil"})});}else{{const $match3=$match2;{const $match4=($match3.codePointAt(0)>0xFFFF?$match3.slice(0,2):$match3[0]);const $x3493=($match3.codePointAt(0)>0xFFFF?$match3.slice(2):$match3.slice(1));{const $let0=(
/*JD_USE:3492*/$match4.codePointAt(0));{const $x3494=$let0;return (
/*JD_REF:$jd$ssplit_46_pick*/$jd$ssplit_46_pick((
/*JD_USE:3494*/$x3494),(
/*JD_REF:$jd$ssplit*/$jd$ssplit((
/*JD_USE:3491*/$x3491),(
/*JD_USE:3493*/$x3493))),(((
/*JD_USE:3494*/$x3494) === (
/*JD_USE:3491*/$x3491)))));}}}}}}}}
function $jd$sjoin_46_go($a0,$a1,$a2){for(;;){const $x3501=$a0;{const $match2=$a1;if($match2.$==="Nil"){const $x3502=$a2;return (
/*JD_USE:3502*/$x3502);}else{{const $match3=$match2;const $x3503=$match3["head"];const $x3504=$match3["tail"];const $x3505=$a2;return (
/*JD_REF:$jd$String_46_append*/$jd$String_46_append((
/*JD_USE:3505*/$x3505),(
/*JD_REF:$jd$String_46_append*/$jd$String_46_append((
/*JD_USE:3501*/$x3501),(
/*JD_REF:$jd$sjoin_46_go*/$jd$sjoin_46_go((
/*JD_USE:3501*/$x3501),(
/*JD_USE:3504*/$x3504),(
/*JD_USE:3503*/$x3503)))))));}}}}}
function $jd$sjoin($a0,$a1){for(;;){const $x3510=$a0;{const $match2=$a1;if($match2.$==="Nil"){return "";}else{{const $match3=$match2;const $x3511=$match3["head"];const $x3512=$match3["tail"];return (
/*JD_REF:$jd$sjoin_46_go*/$jd$sjoin_46_go((
/*JD_USE:3510*/$x3510),(
/*JD_USE:3512*/$x3512),(
/*JD_USE:3511*/$x3511)));}}}}}
function $jd$replace1($a0,$a1,$a2,$a3){for(;;){const $x3521=$a0;const $x3522=$a1;const $x3523=$a2;const $x3524=$a3;return (
/*JD_REF:$jd$String_46_append*/$jd$String_46_append((
/*JD_REF:$jd$stake*/$jd$stake(((
/*JD_USE:3522*/$x3522)),(
/*JD_USE:3521*/$x3521))),(
/*JD_REF:$jd$String_46_append*/$jd$String_46_append((
/*JD_USE:3524*/$x3524),(
/*JD_REF:$jd$sdrop*/$jd$sdrop((
/*JD_REF:$jd$U32_46_to_95_nat*/$jd$U32_46_to_95_nat(((((
/*JD_USE:3522*/$x3522) + (
/*JD_USE:3523*/$x3523)) >>> 0)))),(
/*JD_USE:3521*/$x3521)))))));}}
function $jd$occurs_46_step($a0,$a1,$a2){for(;;){const $x3534=$a0;const $x3535=$a1;{const $match3=$a2;if($match3.$==="Some"){const $x3536=$match3["value"];return ({$:"Tuple",["fst"]:((((
/*JD_USE:3535*/$x3535) + 1) >>> 0)),["snd"]:({$:"Tuple",["fst"]:(
/*JD_REF:$jd$sdrop*/$jd$sdrop((
/*JD_REF:$jd$U32_46_to_95_nat*/$jd$U32_46_to_95_nat(((((
/*JD_USE:3536*/$x3536) + 1) >>> 0)))),(
/*JD_USE:3534*/$x3534))),["snd"]:true})});}else{{const $match4=$match3;return ({$:"Tuple",["fst"]:(
/*JD_USE:3535*/$x3535),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:3534*/$x3534),["snd"]:false})});}}}}}
function $jd$occurs_46_go($a0,$a1,$a2){for(;;){{const $match1=$a0;if($match1===0){const $x3544=$a2;return (
/*JD_USE:3544*/$x3544);}else{const $x3545=($match1-1);const $x3546=$a1;{const $match4=$a2;const $x3547=$match4["fst"];{const $match6=$match4["snd"];const $x3548=$match6["fst"];{const $match8=$match6["snd"];if($match8){{const $let0=(
/*JD_USE:3548*/$x3548);{const $x3549=$let0;{
/*JD_REF:$jd$occurs_46_go*/const $next0=(
/*JD_USE:3545*/$x3545);const $next1=(
/*JD_USE:3546*/$x3546);const $next2=(
/*JD_REF:$jd$occurs_46_step*/$jd$occurs_46_step((
/*JD_USE:3549*/$x3549),(
/*JD_USE:3547*/$x3547),(
/*JD_REF:$jd$sfind*/$jd$sfind((
/*JD_USE:3546*/$x3546),(
/*JD_USE:3549*/$x3549)))));$a0=$next0;$a1=$next1;$a2=$next2;continue;}}}}else{{const $match9=$match8;{
/*JD_REF:$jd$occurs_46_go*/const $next0=(
/*JD_USE:3545*/$x3545);const $next1=(
/*JD_USE:3546*/$x3546);const $next2=({$:"Tuple",["fst"]:(
/*JD_USE:3547*/$x3547),["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:3548*/$x3548),["snd"]:false})});$a0=$next0;$a1=$next1;$a2=$next2;continue;}}}}}}}}}}
function $jd$occurs_46_fin($a0){for(;;){{const $match1=$a0;const $x3552=$match1["fst"];{const $match3=$match1["snd"];{const $match5=$match3["snd"];if($match5){return 99;}else{{const $match6=$match5;return (
/*JD_USE:3552*/$x3552);}}}}}}}
function $jd$occurs($a0,$a1,$a2){for(;;){const $x3557=$a0;const $x3558=$a1;const $x3559=$a2;return (
/*JD_REF:$jd$occurs_46_fin*/$jd$occurs_46_fin((
/*JD_REF:$jd$occurs_46_go*/$jd$occurs_46_go((
/*JD_USE:3557*/$x3557),(
/*JD_USE:3558*/$x3558),({$:"Tuple",["fst"]:0,["snd"]:({$:"Tuple",["fst"]:(
/*JD_USE:3559*/$x3559),["snd"]:true})})))));}}
function $jd$main_46_out(){for(;;){{const $let0=(
/*JD_REF:$jd$bu*/$jd$bu((
/*JD_REF:$jd$seq_95_*/$jd$seq_95_((
/*JD_REF:$jd$replace1*/$jd$replace1("banana",(
/*JD_REF:$jd$Maybe_46_default*/$jd$Maybe_46_default((
/*JD_REF:$jd$sfind*/$jd$sfind("an","banana")),99)),2,"X")),"bXana"))));{const $x3560=$let0;{const $let0=(
/*JD_REF:$jd$bu*/$jd$bu((
/*JD_REF:$jd$seq_95_*/$jd$seq_95_((
/*JD_REF:$jd$sjoin*/$jd$sjoin("-",(
/*JD_REF:$jd$ssplit*/$jd$ssplit(44,"a,b,c")))),"a-b-c"))));{const $x3561=$let0;{const $let0=(
/*JD_REF:$jd$bu*/$jd$bu((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_REF:$jd$occurs*/$jd$occurs(5,"an","banana")),2))));{const $x3562=$let0;{const $let0=(
/*JD_REF:$jd$bu*/$jd$bu((
/*JD_REF:$jd$U32_46_is_95_eq*/$jd$U32_46_is_95_eq((
/*JD_REF:$jd$occurs*/$jd$occurs(5,"zz","banana")),0))));{const $x3563=$let0;return (
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add((
/*JD_REF:$jd$U32_46_add*/$jd$U32_46_add(((((
/*JD_USE:3560*/$x3560) + (
/*JD_USE:3561*/$x3561)) >>> 0)),(
/*JD_USE:3562*/$x3562))),(
/*JD_USE:3563*/$x3563)));}}}}}}}}}}
function $jd$p37_46_text_46_repeat($a0,$a1){for(;;){{const $match1=$a0;if($match1===0){return "";}else{const $x3567=($match1-1);const $x3568=$a1;return (
/*JD_REF:$jd$String_46_append*/$jd$String_46_append((
/*JD_USE:3568*/$x3568),(
/*JD_REF:$jd$p37_46_text_46_repeat*/$jd$p37_46_text_46_repeat((
/*JD_USE:3567*/$x3567),(
/*JD_USE:3568*/$x3568)))));}}}}
function $jd$bench($a0,$a1){for(;;){const $x3571=$a0;const $x3572=$a1;{const $let0=(
/*JD_REF:$jd$p37_46_text_46_repeat*/$jd$p37_46_text_46_repeat(((
/*JD_USE:3571*/$x3571)),(
/*JD_REF:$jd$String_46_append*/$jd$String_46_append("α,β,🍎,中,",(
/*JD_REF:$jd$String_46_append*/$jd$String_46_append((
/*JD_REF:$jd$U32_46_show*/$jd$U32_46_show((
/*JD_USE:3572*/$x3572))),","))))));{const $x3573=$let0;return (
/*JD_REF:$jd$sjoin*/$jd$sjoin("|",(
/*JD_REF:$jd$ssplit*/$jd$ssplit(44,(
/*JD_USE:3573*/$x3573)))));}}}}

export const backend={kind:"direct-js",representation:"upstream-native",prototype:true,foreign:"upstream-cps"};
export default {
"bu":run_lib((a0,)=>{const r=(run_loop($jd$bu((a0),)));(a0);return r;},1),
"seq_":run_lib((a0,a1,)=>{const r=(run_loop($jd$seq_95_((a0),(a1),)));(a0);(a1);return r;},2),
"starts":run_lib((a0,a1,)=>{const r=(run_loop($jd$starts((a0),(a1),)));(a0);(a1);return r;},2),
"sfind.nil":run_lib((a0,)=>{const r=(run_loop($jd$sfind_46_nil((a0),)));(a0);return r;},1),
"sfind.bump":run_lib((a0,)=>{const r=(run_loop($jd$sfind_46_bump((a0),)));(a0);return r;},1),
"sfind.pick":run_lib((a0,a1,)=>{const r=(run_loop($jd$sfind_46_pick((a0),(a1),)));(a0);(a1);return r;},2),
"sfind":run_lib((a0,a1,)=>{const r=(run_loop($jd$sfind((a0),(a1),)));(a0);(a1);return r;},2),
"stake":run_lib((a0,a1,)=>{const r=(run_loop($jd$stake(nat_host(a0),(a1),)));BigInt(a0);(a1);return r;},2),
"sdrop":run_lib((a0,a1,)=>{const r=(run_loop($jd$sdrop(nat_host(a0),(a1),)));BigInt(a0);(a1);return r;},2),
"ssplit.push":run_lib((a0,a1,)=>{const r=(run_loop($jd$ssplit_46_push((a0),(a1),)));(a0);(a1);return r;},2),
"ssplit.pick":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$ssplit_46_pick((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"ssplit":run_lib((a0,a1,)=>{const r=(run_loop($jd$ssplit((a0),(a1),)));(a0);(a1);return r;},2),
"sjoin.go":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$sjoin_46_go((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"sjoin":run_lib((a0,a1,)=>{const r=(run_loop($jd$sjoin((a0),(a1),)));(a0);(a1);return r;},2),
"replace1":run_lib((a0,a1,a2,a3,)=>{const r=(run_loop($jd$replace1((a0),(a1),(a2),(a3),)));(a0);(a1);(a2);(a3);return r;},4),
"occurs.step":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$occurs_46_step((a0),(a1),(a2),)));(a0);(a1);(a2);return r;},3),
"occurs.go":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$occurs_46_go(nat_host(a0),(a1),(a2),)));BigInt(a0);(a1);(a2);return r;},3),
"occurs.fin":run_lib((a0,)=>{const r=(run_loop($jd$occurs_46_fin((a0),)));(a0);return r;},1),
"occurs":run_lib((a0,a1,a2,)=>{const r=(run_loop($jd$occurs(nat_host(a0),(a1),(a2),)));BigInt(a0);(a1);(a2);return r;},3),
"main.out":run_lib(()=>{const r=(run_loop($jd$main_46_out()));return r;},0),
"p37.text.repeat":run_lib((a0,a1,)=>{const r=(run_loop($jd$p37_46_text_46_repeat(nat_host(a0),(a1),)));BigInt(a0);(a1);return r;},2),
"bench":run_lib((a0,a1,)=>{const r=(run_loop($jd$bench((a0),(a1),)));(a0);(a1);return r;},2),
};
