
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004026c0 <nx_rt_field>:
  4026c0:	sub    $0x8,%rsp
  4026c4:	cmpb   $0x0,0x4ab5(%rip)        # 407180 <nx_active>
  4026cb:	je     4026d9 <nx_rt_field+0x19>
  4026cd:	lea    0x4acc(%rip),%rdx        # 4071a0 <nx_context>
  4026d4:	cmp    %rdx,%rdi
  4026d7:	je     4026e8 <nx_rt_field+0x28>
  4026d9:	lea    0x1953(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4026e0:	callq  4019d0 <err_fail>
  4026e5:	nopl   (%rax)
  4026e8:	mov    %esi,%ecx
  4026ea:	cmp    $0x1,%ecx
  4026ed:	jbe    402700 <nx_rt_field+0x40>
  4026ef:	lea    0x1c52(%rip),%rdi        # 404348 <_IO_stdin_used+0x348>
  4026f6:	callq  4019d0 <err_fail>
  4026fb:	nopl   0x0(%rax,%rax,1)
  402700:	mov    $0x1,%eax
  402705:	mov    0x4ab5(%rip),%esi        # 4071c0 <nx_context+0x20>
  40270b:	shl    %cl,%eax
  40270d:	test   %eax,%esi
  40270f:	je     4026ef <nx_rt_field+0x2f>
  402711:	not    %eax
  402713:	add    $0x2,%rcx
  402717:	and    %esi,%eax
  402719:	mov    %eax,0x4aa1(%rip)        # 4071c0 <nx_context+0x20>
  40271f:	mov    (%rdx,%rcx,8),%rax
  402723:	movq   $0xffffffffffffffff,(%rdx,%rcx,8)
  40272b:	add    $0x8,%rsp
  40272f:	retq   

Disassembly of section .fini:
