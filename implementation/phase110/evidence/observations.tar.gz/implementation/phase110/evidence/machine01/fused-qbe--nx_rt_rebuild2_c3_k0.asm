
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004037c0 <nx_rt_rebuild2_c3_k0>:
  4037c0:	push   %r13
  4037c2:	mov    %rsi,%r10
  4037c5:	mov    %rdx,%r8
  4037c8:	movabs $0xffffffffff,%r9
  4037d2:	push   %r12
  4037d4:	and    %r10,%r9
  4037d7:	push   %rbp
  4037d8:	lea    0x0(,%r9,8),%rax
  4037e0:	push   %rbx
  4037e1:	mov    %rdi,%rbx
  4037e4:	sub    $0x28,%rsp
  4037e8:	mov    (%rdi),%rdi
  4037eb:	mov    0x8(%rbx),%rsi
  4037ef:	lea    (%rdi,%rax,1),%rdx
  4037f3:	test   %r10,%r10
  4037f6:	js     403860 <nx_rt_rebuild2_c3_k0+0xa0>
  4037f8:	mov    (%rdx),%r12
  4037fb:	mov    0x8(%rdi,%rax,1),%rbp
  403800:	cmp    $0x310817f,%r9
  403807:	jbe    403838 <nx_rt_rebuild2_c3_k0+0x78>
  403809:	mov    %rbp,0x10(%rbx)
  40380d:	mov    %r12,%rcx
  403810:	mov    $0x3,%edx
  403815:	movq   $0xffffffffffffffff,0x18(%rbx)
  40381d:	movl   $0x1,0x20(%rbx)
  403824:	add    $0x28,%rsp
  403828:	pop    %rbx
  403829:	pop    %rbp
  40382a:	pop    %r12
  40382c:	pop    %r13
  40382e:	jmpq   401ff0 <nx_construct2>
  403833:	nopl   0x0(%rax,%rax,1)
  403838:	mov    0x8(%rsi),%r9
  40383c:	test   %r9,%r9
  40383f:	je     40188c <nx_rt_rebuild2_c3_k0.cold>
  403845:	mov    (%rdi,%r9,8),%rax
  403849:	subq   $0x2,0x108(%rsi)
  403851:	mov    %rax,0x8(%rsi)
  403855:	jmp    403809 <nx_rt_rebuild2_c3_k0+0x49>
  403857:	nopw   0x0(%rax,%rax,1)
  403860:	mov    0x4(%rdx),%eax
  403863:	mov    (%rdx),%ecx
  403865:	shl    $0x20,%rax
  403869:	or     %rcx,%rax
  40386c:	mov    %rax,%r13
  40386f:	and    $0xffffff,%eax
  403874:	shr    $0x18,%r13
  403878:	lea    0x0(,%r13,8),%r11
  403880:	lea    (%rdi,%r11,1),%rbp
  403884:	lea    0x8(%rdi,%r11,1),%r11
  403889:	cmp    $0x1,%rax
  40388d:	jne    4018d2 <nx_rt_rebuild2_c3_k0.cold+0x46>
  403893:	mov    (%rdx),%eax
  403895:	mov    (%rsi),%rax
  403898:	mov    0x0(%rbp),%r12
  40389c:	mov    (%r11),%rbp
  40389f:	mov    %rax,(%rdx)
  4038a2:	mov    0x100(%rsi),%rax
  4038a9:	mov    0x3d929(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4038af:	mov    %r9,(%rsi)
  4038b2:	add    $0x1,%rax
  4038b6:	mov    %rax,0x100(%rsi)
  4038bd:	cmp    %rdx,%rax
  4038c0:	jae    4018bc <nx_rt_rebuild2_c3_k0.cold+0x30>
  4038c6:	mov    %r13,%r9
  4038c9:	jmpq   403800 <nx_rt_rebuild2_c3_k0+0x40>

Disassembly of section .fini:
