
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004046a0 <nx_rt_pair_take2>:
  4046a0:	movabs $0xffffffffff,%rax
  4046aa:	push   %r15
  4046ac:	and    %rsi,%rax
  4046af:	push   %r14
  4046b1:	push   %r13
  4046b3:	lea    0x0(,%rax,8),%rdx
  4046bb:	push   %r12
  4046bd:	push   %rbp
  4046be:	mov    (%rdi),%rbp
  4046c1:	mov    0x8(%rdi),%r14
  4046c5:	lea    0x0(%rbp,%rdx,1),%rcx
  4046ca:	test   %rsi,%rsi
  4046cd:	js     404730 <nx_rt_pair_take2+0x90>
  4046cf:	mov    (%rcx),%r13
  4046d2:	mov    0x8(%rbp,%rdx,1),%r12
  4046d7:	cmp    $0x310817f,%rax
  4046dd:	ja     4046f0 <nx_rt_pair_take2+0x50>
  4046df:	pop    %rbp
  4046e0:	mov    %r13,%rax
  4046e3:	mov    %r12,%rdx
  4046e6:	pop    %r12
  4046e8:	pop    %r13
  4046ea:	pop    %r14
  4046ec:	pop    %r15
  4046ee:	retq   
  4046ef:	nop
  4046f0:	mov    0x8(%r14),%rdx
  4046f4:	mov    %rdx,0x0(%rbp,%rax,8)
  4046f9:	mov    0x3dad9(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4046ff:	mov    %rax,0x8(%r14)
  404703:	mov    0x108(%r14),%rax
  40470a:	add    $0x2,%rax
  40470e:	mov    %rax,0x108(%r14)
  404715:	cmp    %rdx,%rax
  404718:	jae    401be0 <nx_rt_pair_take2.cold>
  40471e:	pop    %rbp
  40471f:	mov    %r13,%rax
  404722:	mov    %r12,%rdx
  404725:	pop    %r12
  404727:	pop    %r13
  404729:	pop    %r14
  40472b:	pop    %r15
  40472d:	retq   
  40472e:	xchg   %ax,%ax
  404730:	mov    0x4(%rcx),%edx
  404733:	mov    (%rcx),%edi
  404735:	shl    $0x20,%rdx
  404739:	or     %rdi,%rdx
  40473c:	mov    %rdx,%r15
  40473f:	and    $0xffffff,%edx
  404745:	shr    $0x18,%r15
  404749:	lea    0x8(,%r15,8),%rdi
  404751:	lea    0x0(%rbp,%rdi,1),%r8
  404756:	cmp    $0x1,%rdx
  40475a:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  404760:	mov    (%rcx),%edx
  404762:	mov    (%r14),%rdx
  404765:	mov    -0x8(%rbp,%rdi,1),%r13
  40476a:	mov    (%r8),%r12
  40476d:	mov    %rdx,(%rcx)
  404770:	mov    0x3da62(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404776:	mov    %rax,(%r14)
  404779:	mov    0x100(%r14),%rax
  404780:	add    $0x1,%rax
  404784:	mov    %rax,0x100(%r14)
  40478b:	cmp    %rdx,%rax
  40478e:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  404794:	mov    %r15,%rax
  404797:	jmpq   4046d7 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
