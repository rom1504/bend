
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403c80 <nx_string_reverse>:
  403c80:	endbr64 
  403c84:	push   %rbp
  403c85:	mov    %rsp,%rbp
  403c88:	sub    $0x20,%rsp
  403c8c:	push   %rbx
  403c8d:	push   %r12
  403c8f:	mov    %rdx,%r12
  403c92:	mov    %rsi,%rbx
  403c95:	callq  402900 <nx_env>
  403c9a:	mov    %r12,%r9
  403c9d:	mov    %rbx,%r8
  403ca0:	mov    %rax,%rcx
  403ca3:	mov    %rdx,%rax
  403ca6:	mov    %rcx,-0x18(%rbp)
  403caa:	mov    %rax,-0x10(%rbp)
  403cae:	lea    -0x8(%rbp),%rcx
  403cb2:	mov    $0x1,%edx
  403cb7:	mov    -0x18(%rbp),%rdi
  403cbb:	mov    -0x10(%rbp),%rsi
  403cbf:	callq  403aa0 <NF_FID_83_116_114_105_110_103_46_114_101_118_101_114_115_101_46_103_111_>
  403cc4:	cmp    $0x1,%rax
  403cc8:	sete   %dil
  403ccc:	movzbl %dil,%edi
  403cd0:	lea    0x4b4e(%rip),%rsi        # 408825 <ERR_TEXT+0x49d>
  403cd7:	callq  4028e0 <nx_require>
  403cdc:	mov    -0x8(%rbp),%rax
  403ce0:	pop    %r12
  403ce2:	pop    %rbx
  403ce3:	leaveq 
  403ce4:	retq   

Disassembly of section .fini:
