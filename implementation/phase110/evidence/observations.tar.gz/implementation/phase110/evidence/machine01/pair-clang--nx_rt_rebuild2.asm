
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402cd0 <nx_rt_rebuild2>:
  402cd0:	movabs $0xffffffffff,%r9
  402cda:	push   %r14
  402cdc:	push   %r13
  402cde:	and    %rsi,%r9
  402ce1:	mov    %edx,%r13d
  402ce4:	push   %r12
  402ce6:	lea    0x0(,%r9,8),%rdx
  402cee:	push   %rbp
  402cef:	mov    %ecx,%ebp
  402cf1:	push   %rbx
  402cf2:	mov    %rdi,%rbx
  402cf5:	sub    $0x20,%rsp
  402cf9:	mov    (%rdi),%rdi
  402cfc:	mov    0x8(%rbx),%r12
  402d00:	lea    (%rdi,%rdx,1),%rax
  402d04:	test   %rsi,%rsi
  402d07:	js     402d88 <nx_rt_rebuild2+0xb8>
  402d09:	mov    (%rax),%rax
  402d0c:	mov    %rax,0x10(%rsp)
  402d11:	mov    0x8(%rdi,%rdx,1),%rax
  402d16:	mov    %rax,0x18(%rsp)
  402d1b:	cmp    $0x310817f,%r9
  402d22:	jbe    402d60 <nx_rt_rebuild2+0x90>
  402d24:	mov    $0x1,%eax
  402d29:	mov    0x10(%rsp,%rbp,8),%rcx
  402d2e:	mov    %r13d,%edx
  402d31:	mov    %r12,%rsi
  402d34:	sub    %ebp,%eax
  402d36:	movq   $0xffffffffffffffff,0x18(%rbx)
  402d3e:	mov    0x10(%rsp,%rax,8),%rax
  402d43:	movl   $0x1,0x20(%rbx)
  402d4a:	mov    %rax,0x10(%rbx)
  402d4e:	add    $0x20,%rsp
  402d52:	pop    %rbx
  402d53:	pop    %rbp
  402d54:	pop    %r12
  402d56:	pop    %r13
  402d58:	pop    %r14
  402d5a:	jmpq   401f70 <nx_construct2>
  402d5f:	nop
  402d60:	mov    0x8(%r12),%r9
  402d65:	test   %r9,%r9
  402d68:	je     401651 <nx_rt_rebuild2.cold>
  402d6e:	mov    (%rdi,%r9,8),%rax
  402d72:	subq   $0x2,0x108(%r12)
  402d7b:	mov    %rax,0x8(%r12)
  402d80:	jmp    402d24 <nx_rt_rebuild2+0x54>
  402d82:	nopw   0x0(%rax,%rax,1)
  402d88:	mov    0x4(%rax),%edx
  402d8b:	mov    (%rax),%ecx
  402d8d:	shl    $0x20,%rdx
  402d91:	or     %rcx,%rdx
  402d94:	mov    %rdx,%r14
  402d97:	and    $0xffffff,%edx
  402d9d:	shr    $0x18,%r14
  402da1:	lea    0x0(,%r14,8),%r10
  402da9:	lea    (%rdi,%r10,1),%r11
  402dad:	lea    0x8(%rdi,%r10,1),%r10
  402db2:	cmp    $0x1,%rdx
  402db6:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402dbc:	mov    (%rax),%edx
  402dbe:	mov    (%r11),%rdx
  402dc1:	mov    %rdx,0x10(%rsp)
  402dc6:	mov    (%r10),%rdx
  402dc9:	mov    %rdx,0x18(%rsp)
  402dce:	mov    (%r12),%rdx
  402dd2:	mov    %rdx,(%rax)
  402dd5:	mov    0x100(%r12),%rax
  402ddd:	mov    0x3e3f5(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402de3:	mov    %r9,(%r12)
  402de7:	add    $0x1,%rax
  402deb:	mov    %rax,0x100(%r12)
  402df3:	cmp    %rdx,%rax
  402df6:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402dfc:	mov    %r14,%r9
  402dff:	jmpq   402d1b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
