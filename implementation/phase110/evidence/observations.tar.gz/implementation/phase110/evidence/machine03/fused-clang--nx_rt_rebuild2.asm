
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ef0 <nx_rt_rebuild2>:
  402ef0:	push   %r15
  402ef2:	push   %r14
  402ef4:	push   %r13
  402ef6:	mov    %ecx,%r13d
  402ef9:	push   %r12
  402efb:	mov    %rdi,%r12
  402efe:	push   %rbp
  402eff:	movabs $0xffffffffff,%rbp
  402f09:	push   %rbx
  402f0a:	and    %rsi,%rbp
  402f0d:	mov    %edx,%ebx
  402f0f:	lea    0x0(,%rbp,8),%rdx
  402f17:	sub    $0x28,%rsp
  402f1b:	mov    (%rdi),%r14
  402f1e:	mov    0x8(%rdi),%r15
  402f22:	lea    (%r14,%rdx,1),%rax
  402f26:	test   %rsi,%rsi
  402f29:	js     403010 <nx_rt_rebuild2+0x120>
  402f2f:	mov    (%rax),%rax
  402f32:	mov    %rax,0x10(%rsp)
  402f37:	mov    0x8(%r14,%rdx,1),%rax
  402f3c:	mov    %rax,0x18(%rsp)
  402f41:	cmp    $0x310817f,%rbp
  402f48:	jbe    402fe8 <nx_rt_rebuild2+0xf8>
  402f4e:	lea    (%r14,%rbp,8),%r9
  402f52:	mov    $0x1,%eax
  402f57:	mov    0x10(%rsp,%r13,8),%rdx
  402f5c:	movq   $0xffffffffffffffff,0x18(%r12)
  402f65:	movl   $0x1,0x20(%r12)
  402f6e:	sub    %r13d,%eax
  402f71:	mov    0x10(%rsp,%rax,8),%rax
  402f76:	mov    %rax,0x10(%r12)
  402f7b:	mov    %rdx,%rax
  402f7e:	shr    $0x38,%rax
  402f82:	and    $0x7f,%eax
  402f85:	cmp    $0x2,%rax
  402f89:	je     402fc8 <nx_rt_rebuild2+0xd8>
  402f8b:	mov    %r8,%rax
  402f8e:	mov    %rdx,(%r9)
  402f91:	lea    0x8(%r14,%rbp,8),%r12
  402f96:	shr    $0x38,%rax
  402f9a:	and    $0x7f,%eax
  402f9d:	cmp    $0x2,%rax
  402fa1:	je     402fd8 <nx_rt_rebuild2+0xe8>
  402fa3:	mov    %rbx,%rax
  402fa6:	mov    %r8,(%r12)
  402faa:	add    $0x28,%rsp
  402fae:	shl    $0x28,%rax
  402fb2:	pop    %rbx
  402fb3:	or     %rbp,%rax
  402fb6:	pop    %rbp
  402fb7:	pop    %r12
  402fb9:	bts    $0x39,%rax
  402fbe:	pop    %r13
  402fc0:	pop    %r14
  402fc2:	pop    %r15
  402fc4:	retq   
  402fc5:	nopl   (%rax)
  402fc8:	test   %rdx,%rdx
  402fcb:	js     402f8b <nx_rt_rebuild2+0x9b>
  402fcd:	jmpq   401640 <nx_rt_rebuild2.cold>
  402fd2:	nopw   0x0(%rax,%rax,1)
  402fd8:	test   %r8,%r8
  402fdb:	js     402fa3 <nx_rt_rebuild2+0xb3>
  402fdd:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  402fe2:	nopw   0x0(%rax,%rax,1)
  402fe8:	mov    0x8(%r15),%rbp
  402fec:	test   %rbp,%rbp
  402fef:	je     401685 <nx_rt_rebuild2.cold+0x45>
  402ff5:	lea    (%r14,%rbp,8),%r9
  402ff9:	mov    (%r9),%rax
  402ffc:	subq   $0x2,0x108(%r15)
  403004:	mov    %rax,0x8(%r15)
  403008:	jmpq   402f52 <nx_rt_rebuild2+0x62>
  40300d:	nopl   (%rax)
  403010:	mov    0x4(%rax),%edx
  403013:	mov    (%rax),%ecx
  403015:	shl    $0x20,%rdx
  403019:	or     %rcx,%rdx
  40301c:	mov    %rdx,%rcx
  40301f:	and    $0xffffff,%edx
  403025:	shr    $0x18,%rcx
  403029:	lea    0x0(,%rcx,8),%rdi
  403031:	lea    (%r14,%rdi,1),%r9
  403035:	lea    0x8(%r14,%rdi,1),%rdi
  40303a:	cmp    $0x1,%rdx
  40303e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403044:	mov    (%rax),%edx
  403046:	mov    (%r9),%rdx
  403049:	mov    %rdx,0x10(%rsp)
  40304e:	mov    (%rdi),%rdx
  403051:	mov    %rdx,0x18(%rsp)
  403056:	mov    (%r15),%rdx
  403059:	mov    %rdx,(%rax)
  40305c:	mov    0x100(%r15),%rax
  403063:	mov    0x3e16f(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403069:	mov    %rbp,(%r15)
  40306c:	add    $0x1,%rax
  403070:	mov    %rax,0x100(%r15)
  403077:	cmp    %rdx,%rax
  40307a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  403080:	mov    %rcx,%rbp
  403083:	jmpq   402f41 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
