
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401930 <nx_string_reverse>:
  401930:	endbr64 
  401934:	push   %rbp
  401935:	mov    %rsp,%rbp
  401938:	sub    $0x8,%rsp
  40193c:	push   %rbx
  40193d:	push   %r12
  40193f:	push   %r13
  401941:	mov    %rdx,%rax
  401944:	mov    %rax,%rbx
  401947:	nopw   0x0(%rax,%rax,1)
  401950:	mov    %rsi,%r13
  401953:	mov    %rdi,%r12
  401956:	callq  402210 <nx_rt_id>
  40195b:	mov    %r13,%rsi
  40195e:	mov    %r12,%rdi
  401961:	cmp    $0x2,%eax
  401964:	je     4019e0 <nx_string_reverse+0xb0>
  401966:	mov    %rsi,%r13
  401969:	mov    %rdi,%r12
  40196c:	callq  402210 <nx_rt_id>
  401971:	mov    %r13,%rsi
  401974:	mov    %r12,%rdi
  401977:	cmp    $0x3,%eax
  40197a:	jne    4019d4 <nx_string_reverse+0xa4>
  40197c:	mov    %rdi,%r12
  40197f:	callq  402550 <nx_rt_take2>
  401984:	mov    %r12,%rdi
  401987:	mov    $0x0,%esi
  40198c:	mov    %rdi,%r12
  40198f:	callq  4026e0 <nx_rt_field>
  401994:	mov    %r12,%rdi
  401997:	mov    %rax,%r13
  40199a:	mov    $0x1,%esi
  40199f:	mov    %rdi,%r12
  4019a2:	callq  4026e0 <nx_rt_field>
  4019a7:	mov    %r13,%rdx
  4019aa:	mov    %r12,%rdi
  4019ad:	mov    %rax,%rsi
  4019b0:	mov    %rbx,%rcx
  4019b3:	mov    %rsi,%r12
  4019b6:	mov    $0x3,%esi
  4019bb:	mov    %rdi,%rbx
  4019be:	callq  4024c0 <nx_rt_build2>
  4019c3:	mov    %r12,%rsi
  4019c6:	mov    %rbx,%rdi
  4019c9:	mov    %rax,%rdx
  4019cc:	mov    %rdx,%rbx
  4019cf:	jmpq   401950 <nx_string_reverse+0x20>
  4019d4:	mov    $0x1,%esi
  4019d9:	callq  402250 <nx_rt_fail>
  4019de:	jmp    4019e3 <nx_string_reverse+0xb3>
  4019e0:	mov    %rbx,%rax
  4019e3:	pop    %r13
  4019e5:	pop    %r12
  4019e7:	pop    %rbx
  4019e8:	leaveq 
  4019e9:	retq   

Disassembly of section .fini:
