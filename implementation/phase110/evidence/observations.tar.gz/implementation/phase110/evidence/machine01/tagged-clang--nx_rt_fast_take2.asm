
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402bd0 <nx_rt_fast_take2>:
  402bd0:	movabs $0xffffffffff,%rax
  402bda:	push   %r12
  402bdc:	and    %rsi,%rax
  402bdf:	push   %rbp
  402be0:	push   %rbx
  402be1:	mov    %rdi,%rbx
  402be4:	mov    (%rdi),%rdi
  402be7:	lea    0x0(,%rax,8),%rcx
  402bef:	mov    0x8(%rbx),%rbp
  402bf3:	lea    (%rdi,%rcx,1),%rdx
  402bf7:	test   %rsi,%rsi
  402bfa:	js     402c68 <nx_rt_fast_take2+0x98>
  402bfc:	mov    (%rdx),%rdx
  402bff:	mov    %rdx,0x10(%rbx)
  402c03:	mov    0x8(%rdi,%rcx,1),%rdx
  402c08:	mov    %rdx,0x18(%rbx)
  402c0c:	cmp    $0x310817f,%rax
  402c12:	ja     402c28 <nx_rt_fast_take2+0x58>
  402c14:	movl   $0x3,0x20(%rbx)
  402c1b:	xor    %eax,%eax
  402c1d:	pop    %rbx
  402c1e:	pop    %rbp
  402c1f:	pop    %r12
  402c21:	retq   
  402c22:	nopw   0x0(%rax,%rax,1)
  402c28:	mov    0x8(%rbp),%rdx
  402c2c:	mov    %rdx,(%rdi,%rax,8)
  402c30:	mov    0x3e5a2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402c36:	mov    %rax,0x8(%rbp)
  402c3a:	mov    0x108(%rbp),%rax
  402c41:	add    $0x2,%rax
  402c45:	mov    %rax,0x108(%rbp)
  402c4c:	cmp    %rdx,%rax
  402c4f:	jae    40160f <nx_rt_fast_take2.cold>
  402c55:	movl   $0x3,0x20(%rbx)
  402c5c:	xor    %eax,%eax
  402c5e:	pop    %rbx
  402c5f:	pop    %rbp
  402c60:	pop    %r12
  402c62:	retq   
  402c63:	nopl   0x0(%rax,%rax,1)
  402c68:	mov    0x4(%rdx),%ecx
  402c6b:	mov    (%rdx),%r8d
  402c6e:	shl    $0x20,%rcx
  402c72:	or     %r8,%rcx
  402c75:	mov    %rcx,%r12
  402c78:	and    $0xffffff,%ecx
  402c7e:	shr    $0x18,%r12
  402c82:	lea    0x0(,%r12,8),%r8
  402c8a:	lea    (%rdi,%r8,1),%r9
  402c8e:	lea    0x8(%rdi,%r8,1),%r8
  402c93:	cmp    $0x1,%rcx
  402c97:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  402c9d:	mov    (%rdx),%ecx
  402c9f:	mov    (%r9),%rcx
  402ca2:	mov    %rcx,0x10(%rbx)
  402ca6:	mov    (%r8),%rcx
  402ca9:	mov    %rcx,0x18(%rbx)
  402cad:	mov    0x0(%rbp),%rcx
  402cb1:	mov    %rcx,(%rdx)
  402cb4:	mov    0x3e51e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402cba:	mov    %rax,0x0(%rbp)
  402cbe:	mov    0x100(%rbp),%rax
  402cc5:	add    $0x1,%rax
  402cc9:	mov    %rax,0x100(%rbp)
  402cd0:	cmp    %rdx,%rax
  402cd3:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402cd9:	mov    %r12,%rax
  402cdc:	jmpq   402c0c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
