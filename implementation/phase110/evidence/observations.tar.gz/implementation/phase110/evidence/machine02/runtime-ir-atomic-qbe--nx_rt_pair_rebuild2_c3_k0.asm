
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004042b0 <nx_rt_pair_rebuild2_c3_k0>:
  4042b0:	push   %r15
  4042b2:	push   %r14
  4042b4:	push   %r13
  4042b6:	push   %r12
  4042b8:	mov    %rdx,%r12
  4042bb:	push   %rbp
  4042bc:	push   %rbx
  4042bd:	movabs $0xffffffffff,%rbx
  4042c7:	and    %rsi,%rbx
  4042ca:	lea    0x0(,%rbx,8),%rdx
  4042d2:	sub    $0x18,%rsp
  4042d6:	mov    (%rdi),%rbp
  4042d9:	mov    0x8(%rdi),%r15
  4042dd:	lea    0x0(%rbp,%rdx,1),%rax
  4042e2:	test   %rsi,%rsi
  4042e5:	js     4043a0 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  4042eb:	mov    (%rax),%r14
  4042ee:	mov    0x8(%rbp,%rdx,1),%r13
  4042f3:	cmp    $0x310817f,%rbx
  4042fa:	jbe    404370 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  4042fc:	lea    0x0(%rbp,%rbx,8),%r8
  404301:	mov    %r14,%rax
  404304:	shr    $0x38,%rax
  404308:	and    $0x7f,%eax
  40430b:	cmp    $0x2,%rax
  40430f:	je     404350 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  404311:	mov    %r12,%rax
  404314:	mov    %r14,(%r8)
  404317:	lea    0x8(%rbp,%rbx,8),%r14
  40431c:	shr    $0x38,%rax
  404320:	and    $0x7f,%eax
  404323:	cmp    $0x2,%rax
  404327:	je     404360 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  404329:	movabs $0x200030000000000,%rax
  404333:	mov    %r12,(%r14)
  404336:	mov    %r13,%rdx
  404339:	add    $0x18,%rsp
  40433d:	or     %rbx,%rax
  404340:	pop    %rbx
  404341:	pop    %rbp
  404342:	pop    %r12
  404344:	pop    %r13
  404346:	pop    %r14
  404348:	pop    %r15
  40434a:	retq   
  40434b:	nopl   0x0(%rax,%rax,1)
  404350:	test   %r14,%r14
  404353:	js     404311 <nx_rt_pair_rebuild2_c3_k0+0x61>
  404355:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  40435a:	nopw   0x0(%rax,%rax,1)
  404360:	test   %r12,%r12
  404363:	js     404329 <nx_rt_pair_rebuild2_c3_k0+0x79>
  404365:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  40436a:	nopw   0x0(%rax,%rax,1)
  404370:	mov    0x8(%r15),%rbx
  404374:	test   %rbx,%rbx
  404377:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  40437d:	lea    0x0(%rbp,%rbx,8),%r8
  404382:	mov    (%r8),%rax
  404385:	subq   $0x2,0x108(%r15)
  40438d:	mov    %rax,0x8(%r15)
  404391:	jmpq   404301 <nx_rt_pair_rebuild2_c3_k0+0x51>
  404396:	nopw   %cs:0x0(%rax,%rax,1)
  4043a0:	mov    0x4(%rax),%edx
  4043a3:	mov    (%rax),%ecx
  4043a5:	shl    $0x20,%rdx
  4043a9:	or     %rcx,%rdx
  4043ac:	mov    %rdx,%rcx
  4043af:	and    $0xffffff,%edx
  4043b5:	shr    $0x18,%rcx
  4043b9:	lea    0x8(,%rcx,8),%rdi
  4043c1:	lea    0x0(%rbp,%rdi,1),%r8
  4043c6:	lea    -0x8(%rbp,%rdi,1),%rdi
  4043cb:	cmp    $0x1,%rdx
  4043cf:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  4043d5:	mov    (%rax),%edx
  4043d7:	mov    (%r15),%rdx
  4043da:	mov    (%rdi),%r14
  4043dd:	mov    (%r8),%r13
  4043e0:	mov    %rdx,(%rax)
  4043e3:	mov    0x100(%r15),%rax
  4043ea:	mov    0x3dde8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4043f0:	mov    %rbx,(%r15)
  4043f3:	add    $0x1,%rax
  4043f7:	mov    %rax,0x100(%r15)
  4043fe:	cmp    %rdx,%rax
  404401:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  404407:	mov    %rcx,%rbx
  40440a:	jmpq   4042f3 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
