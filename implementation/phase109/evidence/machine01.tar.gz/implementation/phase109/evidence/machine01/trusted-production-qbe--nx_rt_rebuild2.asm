
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004032a0 <nx_rt_rebuild2>:
  4032a0:	endbr64 
  4032a4:	push   %rbp
  4032a5:	mov    %rsp,%rbp
  4032a8:	sub    $0x20,%rsp
  4032ac:	push   %rbx
  4032ad:	push   %r12
  4032af:	push   %r13
  4032b1:	push   %r14
  4032b3:	mov    %edx,%r12d
  4032b6:	mov    %rsi,%rdx
  4032b9:	mov    (%rdi),%rax
  4032bc:	mov    %rax,-0x20(%rbp)
  4032c0:	mov    0x8(%rdi),%rax
  4032c4:	mov    %rax,-0x18(%rbp)
  4032c8:	mov    %r8,%r14
  4032cb:	lea    -0x10(%rbp),%r8
  4032cf:	mov    %ecx,%r13d
  4032d2:	mov    $0x2,%ecx
  4032d7:	mov    %rdi,%rbx
  4032da:	mov    -0x20(%rbp),%rdi
  4032de:	mov    -0x18(%rbp),%rsi
  4032e2:	callq  402390 <ctr_take>
  4032e7:	mov    %rbx,%rdi
  4032ea:	mov    %rax,%r9
  4032ed:	cmp    $0x3108180,%r9
  4032f4:	jae    403329 <nx_rt_rebuild2+0x89>
  4032f6:	mov    %rdi,%rbx
  4032f9:	mov    $0x2,%edi
  4032fe:	callq  4015a0 <cls_fit>
  403303:	mov    %rbx,%rdi
  403306:	mov    %eax,%edx
  403308:	mov    %rdi,%rbx
  40330b:	mov    -0x20(%rbp),%rdi
  40330f:	mov    -0x18(%rbp),%rsi
  403313:	callq  4019b0 <heap_alloc>
  403318:	mov    %r14,%r8
  40331b:	mov    %r13d,%ecx
  40331e:	mov    %r12d,%edx
  403321:	mov    %rbx,%rdi
  403324:	mov    %rax,%r9
  403327:	jmp    403332 <nx_rt_rebuild2+0x92>
  403329:	mov    %r14,%r8
  40332c:	mov    %r13d,%ecx
  40332f:	mov    %r12d,%edx
  403332:	mov    $0x1,%eax
  403337:	sub    %ecx,%eax
  403339:	mov    %eax,%eax
  40333b:	mov    -0x10(%rbp,%rax,8),%rax
  403340:	mov    %rax,0x10(%rdi)
  403344:	movq   $0xffffffffffffffff,0x18(%rdi)
  40334c:	movl   $0x1,0x20(%rdi)
  403353:	mov    %ecx,%eax
  403355:	mov    -0x10(%rbp,%rax,8),%rcx
  40335a:	mov    -0x20(%rbp),%rdi
  40335e:	mov    -0x18(%rbp),%rsi
  403362:	callq  402e80 <nx_construct2>
  403367:	pop    %r14
  403369:	pop    %r13
  40336b:	pop    %r12
  40336d:	pop    %rbx
  40336e:	leaveq 
  40336f:	retq   

Disassembly of section .fini:
