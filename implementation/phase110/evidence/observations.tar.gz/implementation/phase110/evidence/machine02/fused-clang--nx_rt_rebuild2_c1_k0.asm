
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403580 <nx_rt_rebuild2_c1_k0>:
  403580:	push   %r15
  403582:	push   %r14
  403584:	push   %r13
  403586:	push   %r12
  403588:	mov    %rdx,%r12
  40358b:	push   %rbp
  40358c:	mov    %rdi,%rbp
  40358f:	push   %rbx
  403590:	movabs $0xffffffffff,%rbx
  40359a:	and    %rsi,%rbx
  40359d:	lea    0x0(,%rbx,8),%rdx
  4035a5:	sub    $0x18,%rsp
  4035a9:	mov    (%rdi),%r13
  4035ac:	mov    0x8(%rdi),%r15
  4035b0:	lea    0x0(%r13,%rdx,1),%rax
  4035b5:	test   %rsi,%rsi
  4035b8:	js     403680 <nx_rt_rebuild2_c1_k0+0x100>
  4035be:	mov    (%rax),%r14
  4035c1:	mov    0x8(%r13,%rdx,1),%r9
  4035c6:	cmp    $0x310817f,%rbx
  4035cd:	jbe    403658 <nx_rt_rebuild2_c1_k0+0xd8>
  4035d3:	lea    0x0(%r13,%rbx,8),%r8
  4035d8:	mov    %r14,%rax
  4035db:	mov    %r9,0x10(%rbp)
  4035df:	shr    $0x38,%rax
  4035e3:	movq   $0xffffffffffffffff,0x18(%rbp)
  4035eb:	and    $0x7f,%eax
  4035ee:	movl   $0x1,0x20(%rbp)
  4035f5:	cmp    $0x2,%rax
  4035f9:	je     403638 <nx_rt_rebuild2_c1_k0+0xb8>
  4035fb:	mov    %r12,%rax
  4035fe:	mov    %r14,(%r8)
  403601:	lea    0x8(%r13,%rbx,8),%rbp
  403606:	shr    $0x38,%rax
  40360a:	and    $0x7f,%eax
  40360d:	cmp    $0x2,%rax
  403611:	je     403648 <nx_rt_rebuild2_c1_k0+0xc8>
  403613:	movabs $0x200010000000000,%rax
  40361d:	mov    %r12,0x0(%rbp)
  403621:	add    $0x18,%rsp
  403625:	or     %rbx,%rax
  403628:	pop    %rbx
  403629:	pop    %rbp
  40362a:	pop    %r12
  40362c:	pop    %r13
  40362e:	pop    %r14
  403630:	pop    %r15
  403632:	retq   
  403633:	nopl   0x0(%rax,%rax,1)
  403638:	test   %r14,%r14
  40363b:	js     4035fb <nx_rt_rebuild2_c1_k0+0x7b>
  40363d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403642:	nopw   0x0(%rax,%rax,1)
  403648:	test   %r12,%r12
  40364b:	js     403613 <nx_rt_rebuild2_c1_k0+0x93>
  40364d:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403652:	nopw   0x0(%rax,%rax,1)
  403658:	mov    0x8(%r15),%rbx
  40365c:	test   %rbx,%rbx
  40365f:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  403665:	lea    0x0(%r13,%rbx,8),%r8
  40366a:	mov    (%r8),%rax
  40366d:	subq   $0x2,0x108(%r15)
  403675:	mov    %rax,0x8(%r15)
  403679:	jmpq   4035d8 <nx_rt_rebuild2_c1_k0+0x58>
  40367e:	xchg   %ax,%ax
  403680:	mov    0x4(%rax),%edx
  403683:	mov    (%rax),%ecx
  403685:	shl    $0x20,%rdx
  403689:	or     %rcx,%rdx
  40368c:	mov    %rdx,%rcx
  40368f:	and    $0xffffff,%edx
  403695:	shr    $0x18,%rcx
  403699:	lea    0x8(,%rcx,8),%rdi
  4036a1:	lea    0x0(%r13,%rdi,1),%r8
  4036a6:	lea    -0x8(%r13,%rdi,1),%rdi
  4036ab:	cmp    $0x1,%rdx
  4036af:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  4036b5:	mov    (%rax),%edx
  4036b7:	mov    (%r15),%rdx
  4036ba:	mov    (%rdi),%r14
  4036bd:	mov    (%r8),%r9
  4036c0:	mov    %rdx,(%rax)
  4036c3:	mov    0x100(%r15),%rax
  4036ca:	mov    0x3db08(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4036d0:	mov    %rbx,(%r15)
  4036d3:	add    $0x1,%rax
  4036d7:	mov    %rax,0x100(%r15)
  4036de:	cmp    %rdx,%rax
  4036e1:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  4036e7:	mov    %rcx,%rbx
  4036ea:	jmpq   4035c6 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
