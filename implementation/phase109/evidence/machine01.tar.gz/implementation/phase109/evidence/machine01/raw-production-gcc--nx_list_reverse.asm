
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403140 <nx_list_reverse>:
  403140:	push   %r15
  403142:	lea    0x5057(%rip),%rax        # 4081a0 <nx_context>
  403149:	push   %r14
  40314b:	push   %r13
  40314d:	push   %r12
  40314f:	push   %rbp
  403150:	push   %rbx
  403151:	sub    $0x18,%rsp
  403155:	cmp    %rdi,%rax
  403158:	jne    403163 <nx_list_reverse+0x23>
  40315a:	cmpb   $0x0,0x501f(%rip)        # 408180 <nx_active>
  403161:	jne    403170 <nx_list_reverse+0x30>
  403163:	lea    0x1ec9(%rip),%rdi        # 405033 <_IO_stdin_used+0x33>
  40316a:	callq  401ac0 <err_fail>
  40316f:	nop
  403170:	mov    %rsi,%rax
  403173:	mov    0x5026(%rip),%rdi        # 4081a0 <nx_context>
  40317a:	mov    %rsi,%r12
  40317d:	mov    %rdx,%r13
  403180:	shr    $0x28,%rax
  403184:	mov    0x501d(%rip),%rbp        # 4081a8 <nx_context+0x8>
  40318b:	and    $0xffff,%eax
  403190:	je     403335 <nx_list_reverse+0x1f5>
  403196:	cmp    $0x1,%rax
  40319a:	jne    403347 <nx_list_reverse+0x207>
  4031a0:	movabs $0xffffffffff,%r8
  4031aa:	movabs $0x200010000000000,%r14
  4031b4:	jmp    403201 <nx_list_reverse+0xc1>
  4031b6:	nopw   %cs:0x0(%rax,%rax,1)
  4031c0:	mov    %r13,%rax
  4031c3:	mov    %r9,(%r15)
  4031c6:	lea    0x8(%rdi,%rbx,8),%r15
  4031cb:	shr    $0x38,%rax
  4031cf:	and    $0x7f,%eax
  4031d2:	cmp    $0x2,%rax
  4031d6:	je     403280 <nx_list_reverse+0x140>
  4031dc:	mov    %r12,%rax
  4031df:	or     %r14,%rbx
  4031e2:	mov    %r13,(%r15)
  4031e5:	shr    $0x28,%rax
  4031e9:	mov    %rbx,%r13
  4031ec:	and    $0xffff,%eax
  4031f1:	je     403335 <nx_list_reverse+0x1f5>
  4031f7:	cmp    $0x1,%rax
  4031fb:	jne    403347 <nx_list_reverse+0x207>
  403201:	mov    %r12,%rax
  403204:	and    %r8,%rax
  403207:	lea    0x0(,%rax,8),%rcx
  40320f:	lea    (%rdi,%rcx,1),%rdx
  403213:	test   %r12,%r12
  403216:	js     4032c8 <nx_list_reverse+0x188>
  40321c:	mov    (%rdx),%r9
  40321f:	mov    0x8(%rdi,%rcx,1),%r12
  403224:	mov    0x8(%rbp),%rbx
  403228:	cmp    $0x310817f,%rax
  40322e:	ja     403290 <nx_list_reverse+0x150>
  403230:	test   %rbx,%rbx
  403233:	je     40179f <nx_list_reverse.cold+0xdb>
  403239:	mov    0x108(%rbp),%rax
  403240:	lea    (%rdi,%rbx,8),%r15
  403244:	lea    -0x2(%rax),%rdx
  403248:	mov    (%r15),%rax
  40324b:	mov    %rdx,0x108(%rbp)
  403252:	mov    %rax,0x8(%rbp)
  403256:	mov    %r9,%rax
  403259:	shr    $0x38,%rax
  40325d:	and    $0x7f,%eax
  403260:	cmp    $0x2,%rax
  403264:	jne    4031c0 <nx_list_reverse+0x80>
  40326a:	test   %r9,%r9
  40326d:	js     4031c0 <nx_list_reverse+0x80>
  403273:	jmpq   401775 <nx_list_reverse.cold+0xb1>
  403278:	nopl   0x0(%rax,%rax,1)
  403280:	test   %r13,%r13
  403283:	js     4031dc <nx_list_reverse+0x9c>
  403289:	jmpq   40174b <nx_list_reverse.cold+0x87>
  40328e:	xchg   %ax,%ax
  403290:	lea    (%rdi,%rax,8),%r15
  403294:	mov    0x4f3e(%rip),%esi        # 4081d8 <KEEP_WORDS>
  40329a:	mov    %rbx,(%r15)
  40329d:	mov    0x108(%rbp),%rdx
  4032a4:	mov    %rax,0x8(%rbp)
  4032a8:	lea    0x2(%rdx),%rcx
  4032ac:	mov    %rcx,0x108(%rbp)
  4032b3:	cmp    %rsi,%rcx
  4032b6:	jae    401723 <nx_list_reverse.cold+0x5f>
  4032bc:	mov    %rax,%rbx
  4032bf:	jmp    403248 <nx_list_reverse+0x108>
  4032c1:	nopl   0x0(%rax)
  4032c8:	mov    0x4(%rdx),%ecx
  4032cb:	mov    (%rdx),%esi
  4032cd:	shl    $0x20,%rcx
  4032d1:	or     %rsi,%rcx
  4032d4:	mov    %rcx,%rbx
  4032d7:	and    $0xffffff,%ecx
  4032dd:	shr    $0x18,%rbx
  4032e1:	lea    0x8(,%rbx,8),%rsi
  4032e9:	lea    (%rdi,%rsi,1),%r10
  4032ed:	cmp    $0x1,%rcx
  4032f1:	jne    4016c4 <nx_list_reverse.cold>
  4032f7:	mov    (%rdx),%ecx
  4032f9:	mov    0x0(%rbp),%rcx
  4032fd:	mov    -0x8(%rdi,%rsi,1),%r9
  403302:	mov    (%r10),%r12
  403305:	mov    %rcx,(%rdx)
  403308:	mov    0x4eca(%rip),%edx        # 4081d8 <KEEP_WORDS>
  40330e:	mov    %rax,0x0(%rbp)
  403312:	mov    0x100(%rbp),%rax
  403319:	add    $0x1,%rax
  40331d:	mov    %rax,0x100(%rbp)
  403324:	cmp    %rdx,%rax
  403327:	jae    401702 <nx_list_reverse.cold+0x3e>
  40332d:	mov    %rbx,%rax
  403330:	jmpq   403224 <nx_list_reverse+0xe4>
  403335:	add    $0x18,%rsp
  403339:	mov    %r13,%rax
  40333c:	pop    %rbx
  40333d:	pop    %rbp
  40333e:	pop    %r12
  403340:	pop    %r13
  403342:	pop    %r14
  403344:	pop    %r15
  403346:	retq   
  403347:	mov    %r12,%rax
  40334a:	shr    $0x38,%rax
  40334e:	test   $0x7e,%al
  403350:	je     403378 <nx_list_reverse+0x238>
  403352:	cmp    $0xffffffffffffffff,%r12
  403356:	je     403378 <nx_list_reverse+0x238>
  403358:	movabs $0xffffffffff,%rax
  403362:	and    %r12,%rax
  403365:	cmp    $0x310817f,%rax
  40336b:	jbe    403378 <nx_list_reverse+0x238>
  40336d:	mov    %r12,%rdx
  403370:	mov    %rbp,%rsi
  403373:	callq  401e10 <term_drop>
  403378:	mov    %r13,%rax
  40337b:	shr    $0x38,%rax
  40337f:	test   $0x7e,%al
  403381:	je     4033a9 <nx_list_reverse+0x269>
  403383:	cmp    $0xffffffffffffffff,%r13
  403387:	je     4033a9 <nx_list_reverse+0x269>
  403389:	movabs $0xffffffffff,%rax
  403393:	and    %r13,%rax
  403396:	cmp    $0x310817f,%rax
  40339c:	jbe    4033a9 <nx_list_reverse+0x269>
  40339e:	mov    %r13,%rdx
  4033a1:	mov    %rbp,%rsi
  4033a4:	callq  401e10 <term_drop>
  4033a9:	lea    0x2108(%rip),%rdi        # 4054b8 <_IO_stdin_used+0x4b8>
  4033b0:	callq  401ac0 <err_fail>

Disassembly of section .fini:
