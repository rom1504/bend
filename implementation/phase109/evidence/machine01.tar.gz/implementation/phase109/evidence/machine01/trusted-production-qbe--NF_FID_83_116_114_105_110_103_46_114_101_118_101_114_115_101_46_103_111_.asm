
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403aa0 <NF_FID_83_116_114_105_110_103_46_114_101_118_101_114_115_101_46_103_111_>:
  403aa0:	endbr64 
  403aa4:	push   %rbp
  403aa5:	mov    %rsp,%rbp
  403aa8:	sub    $0x28,%rsp
  403aac:	push   %rbx
  403aad:	push   %r12
  403aaf:	push   %r13
  403ab1:	push   %r14
  403ab3:	push   %r15
  403ab5:	mov    %r9,%r15
  403ab8:	mov    %r8,%rdx
  403abb:	mov    %rcx,%r12
  403abe:	mov    %rdi,-0x20(%rbp)
  403ac2:	mov    %rsi,-0x18(%rbp)
  403ac6:	mov    %rdx,%r13
  403ac9:	mov    $0x0,%ebx
  403ace:	xchg   %ax,%ax
  403ad0:	add    $0x1,%ebx
  403ad3:	mov    %r13,%rdi
  403ad6:	callq  401b30 <term_aux>
  403adb:	cmp    $0x2,%rax
  403adf:	je     403bf5 <NF_FID_83_116_114_105_110_103_46_114_101_118_101_114_115_101_46_103_111_+0x155>
  403ae5:	mov    %r13,%rdi
  403ae8:	callq  401b30 <term_aux>
  403aed:	cmp    $0x3,%rax
  403af1:	jne    403bc0 <NF_FID_83_116_114_105_110_103_46_114_101_118_101_114_115_101_46_103_111_+0x120>
  403af7:	mov    $0x2,%edi
  403afc:	callq  4015a0 <cls_fit>
  403b01:	mov    %r13,%r8
  403b04:	mov    %r12,%rcx
  403b07:	mov    %eax,%edx
  403b09:	mov    %r8,%r14
  403b0c:	lea    -0x10(%rbp),%r8
  403b10:	mov    %rcx,%r13
  403b13:	mov    $0x2,%ecx
  403b18:	mov    %edx,%r12d
  403b1b:	mov    %r14,%rdx
  403b1e:	mov    -0x20(%rbp),%rdi
  403b22:	mov    -0x18(%rbp),%rsi
  403b26:	callq  402390 <ctr_take>
  403b2b:	mov    %r12d,%edx
  403b2e:	mov    %rax,%rcx
  403b31:	mov    -0x20(%rbp),%rdi
  403b35:	mov    -0x18(%rbp),%rsi
  403b39:	callq  401aa0 <spare_free>
  403b3e:	mov    -0x10(%rbp),%r12
  403b42:	mov    -0x8(%rbp),%r14
  403b46:	mov    $0x2,%edi
  403b4b:	callq  4015a0 <cls_fit>
  403b50:	mov    %eax,%edx
  403b52:	mov    -0x20(%rbp),%rdi
  403b56:	mov    -0x18(%rbp),%rsi
  403b5a:	callq  4019b0 <heap_alloc>
  403b5f:	mov    %r12,%rdx
  403b62:	mov    %rax,%r12
  403b65:	mov    -0x20(%rbp),%rdi
  403b69:	mov    -0x18(%rbp),%rsi
  403b6d:	callq  401c60 <rfc_seal>
  403b72:	mov    %r15,%r9
  403b75:	mov    %r13,%rcx
  403b78:	mov    %rcx,%r13
  403b7b:	mov    -0x20(%rbp),%rcx
  403b7f:	mov    %rax,(%rcx,%r12,8)
  403b83:	mov    %r9,%rdx
  403b86:	mov    -0x20(%rbp),%rdi
  403b8a:	mov    -0x18(%rbp),%rsi
  403b8e:	callq  401c60 <rfc_seal>
  403b93:	mov    %r14,%r8
  403b96:	mov    %r13,%rcx
  403b99:	mov    -0x20(%rbp),%rdx
  403b9d:	mov    %rax,0x8(%rdx,%r12,8)
  403ba2:	movabs $0x200030000000000,%rax
  403bac:	mov    %r12,%r9
  403baf:	or     %rax,%r9
  403bb2:	mov    %rcx,%r12
  403bb5:	mov    %r8,%r13
  403bb8:	mov    %r9,%r15
  403bbb:	jmpq   403ad0 <NF_FID_83_116_114_105_110_103_46_114_101_118_101_114_115_101_46_103_111_+0x30>
  403bc0:	mov    %r13,%rdx
  403bc3:	mov    -0x20(%rbp),%rdi
  403bc7:	mov    -0x18(%rbp),%rsi
  403bcb:	callq  402280 <term_sink>
  403bd0:	mov    %r15,%rdx
  403bd3:	mov    -0x20(%rbp),%rdi
  403bd7:	mov    -0x18(%rbp),%rsi
  403bdb:	callq  402280 <term_sink>
  403be0:	mov    -0x20(%rbp),%rdi
  403be4:	mov    $0x4,%esi
  403be9:	callq  401450 <err_post>
  403bee:	mov    $0x0,%eax
  403bf3:	jmp    403bfe <NF_FID_83_116_114_105_110_103_46_114_101_118_101_114_115_101_46_103_111_+0x15e>
  403bf5:	mov    %r15,(%r12)
  403bf9:	mov    $0x1,%eax
  403bfe:	pop    %r15
  403c00:	pop    %r14
  403c02:	pop    %r13
  403c04:	pop    %r12
  403c06:	pop    %rbx
  403c07:	leaveq 
  403c08:	retq   

Disassembly of section .fini:
