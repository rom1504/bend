
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/coverage-record-aggregation-256/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000406ef2 <p113d_FID_36_112_114_111_100_117_99_116_46_77_97_112_46_98_105_116_46_103_111_>:
  406ef2:	push   %rbp
  406ef3:	mov    %rsp,%rbp
  406ef6:	sub    $0x930,%rsp
  406efd:	mov    %r12,-0x10(%rbp)
  406f01:	mov    %rbx,-0x8(%rbp)
  406f05:	mov    %rdi,%rax
  406f08:	mov    %rax,%r12
  406f0b:	mov    %rsi,%rax
  406f0e:	mov    %rax,-0x30(%rbp)
  406f12:	mov    %rdx,%rax
  406f15:	mov    %rax,%rbx
  406f18:	mov    %rcx,%rax
  406f1b:	mov    %rax,%rdi
  406f1e:	mov    %r8,%rax
  406f21:	mov    %rax,%rsi
  406f24:	mov    %r12,%r10
  406f27:	mov    %r10,0x20(%rsp)
  406f2c:	mov    %rbx,%r10
  406f2f:	mov    %r10,0x28(%rsp)
  406f34:	mov    %rdi,%r10
  406f37:	mov    %r10,0x30(%rsp)
  406f3c:	mov    %rsi,%r10
  406f3f:	mov    %r10,0x38(%rsp)
  406f44:	mov    0x20(%rsp),%rdi
  406f49:	mov    0x28(%rsp),%rsi
  406f4e:	mov    0x30(%rsp),%rdx
  406f53:	mov    0x38(%rsp),%rcx
  406f58:	xor    %eax,%eax
  406f5a:	callq  406a94 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>
  406f5f:	mov    %rax,%rdi
  406f62:	mov    %rbx,%r10
  406f65:	mov    -0x30(%rbp),%r11
  406f69:	mov    %r10,(%r11)
  406f6c:	mov    %rdi,%r10
  406f6f:	mov    -0x30(%rbp),%r11
  406f73:	mov    %r10,0x8(%r11)
  406f77:	xor    %eax,%eax
  406f79:	mov    -0x10(%rbp),%r12
  406f7d:	mov    -0x8(%rbp),%rbx
  406f81:	mov    %rbp,%rsp
  406f84:	pop    %rbp
  406f85:	retq   

Disassembly of section .fini:
