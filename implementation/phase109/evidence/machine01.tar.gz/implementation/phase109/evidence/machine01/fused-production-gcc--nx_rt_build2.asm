
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402590 <nx_rt_build2>:
  402590:	cmpb   $0x0,0x5be9(%rip)        # 408180 <nx_active>
  402597:	push   %r14
  402599:	push   %r13
  40259b:	push   %r12
  40259d:	push   %rbp
  40259e:	push   %rbx
  40259f:	je     4025ad <nx_rt_build2+0x1d>
  4025a1:	lea    0x5bf8(%rip),%rax        # 4081a0 <nx_context>
  4025a8:	cmp    %rax,%rdi
  4025ab:	je     4025c0 <nx_rt_build2+0x30>
  4025ad:	lea    0x2a7f(%rip),%rdi        # 405033 <_IO_stdin_used+0x33>
  4025b4:	callq  401ac0 <err_fail>
  4025b9:	nopl   0x0(%rax)
  4025c0:	mov    0x5bd9(%rip),%r14        # 4081a0 <nx_context>
  4025c7:	mov    %esi,%r12d
  4025ca:	mov    %rdx,%r13
  4025cd:	mov    %rcx,%rbx
  4025d0:	mov    0x5bd1(%rip),%rbp        # 4081a8 <nx_context+0x8>
  4025d7:	mov    %r14,%rdi
  4025da:	callq  401cf0 <nx_fields.isra.0>
  4025df:	mov    0x8(%rbp),%r9
  4025e3:	test   %r9,%r9
  4025e6:	je     402614 <nx_rt_build2+0x84>
  4025e8:	mov    (%r14,%r9,8),%rax
  4025ec:	subq   $0x2,0x108(%rbp)
  4025f4:	mov    %rax,0x8(%rbp)
  4025f8:	mov    %rbx,%r8
  4025fb:	mov    %r13,%rcx
  4025fe:	pop    %rbx
  4025ff:	mov    %r12d,%edx
  402602:	mov    %r14,%rdi
  402605:	mov    %rbp,%rsi
  402608:	pop    %rbp
  402609:	pop    %r12
  40260b:	pop    %r13
  40260d:	pop    %r14
  40260f:	jmpq   401d90 <nx_construct2>
  402614:	jmpq   40154f <nx_rt_build2.cold>

Disassembly of section .fini:
