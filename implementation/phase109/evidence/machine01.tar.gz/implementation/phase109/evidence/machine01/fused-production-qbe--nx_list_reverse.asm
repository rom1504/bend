
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403c10 <nx_list_reverse>:
  403c10:	endbr64 
  403c14:	push   %rbp
  403c15:	mov    %rsp,%rbp
  403c18:	sub    $0x20,%rsp
  403c1c:	push   %rbx
  403c1d:	push   %r12
  403c1f:	mov    %rdx,%r12
  403c22:	mov    %rsi,%rbx
  403c25:	callq  402900 <nx_env>
  403c2a:	mov    %r12,%r9
  403c2d:	mov    %rbx,%r8
  403c30:	mov    %rax,%rcx
  403c33:	mov    %rdx,%rax
  403c36:	mov    %rcx,-0x18(%rbp)
  403c3a:	mov    %rax,-0x10(%rbp)
  403c3e:	lea    -0x8(%rbp),%rcx
  403c42:	mov    $0x1,%edx
  403c47:	mov    -0x18(%rbp),%rdi
  403c4b:	mov    -0x10(%rbp),%rsi
  403c4f:	callq  403930 <NF_FID_110_116_95_114_101_118_101_114_115_101_>
  403c54:	cmp    $0x1,%rax
  403c58:	sete   %dil
  403c5c:	movzbl %dil,%edi
  403c60:	lea    0x4ba0(%rip),%rsi        # 408807 <ERR_TEXT+0x47f>
  403c67:	callq  4028e0 <nx_require>
  403c6c:	mov    -0x8(%rbp),%rax
  403c70:	pop    %r12
  403c72:	pop    %rbx
  403c73:	leaveq 
  403c74:	retq   

Disassembly of section .fini:
