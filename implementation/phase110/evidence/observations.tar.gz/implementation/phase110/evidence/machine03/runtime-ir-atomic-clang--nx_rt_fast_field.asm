
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403210 <nx_rt_fast_field>:
  403210:	mov    %esi,%ecx
  403212:	mov    $0xfffffffe,%eax
  403217:	rol    %cl,%eax
  403219:	add    $0x2,%rcx
  40321d:	and    %eax,0x20(%rdi)
  403220:	mov    (%rdi,%rcx,8),%rax
  403224:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  40322c:	retq   

Disassembly of section .fini:
