
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004015a0 <cls_fit>:
  4015a0:	endbr64 
  4015a4:	push   %rbp
  4015a5:	mov    %rsp,%rbp
  4015a8:	cmp    $0x1,%edi
  4015ab:	ja     4015b4 <cls_fit+0x14>
  4015ad:	mov    $0x0,%eax
  4015b2:	jmp    4015c1 <cls_fit+0x21>
  4015b4:	sub    $0x1,%edi
  4015b7:	callq  403d90 <bend_qbe_clz32>
  4015bc:	neg    %eax
  4015be:	add    $0x20,%eax
  4015c1:	leaveq 
  4015c2:	retq   

Disassembly of section .fini:
