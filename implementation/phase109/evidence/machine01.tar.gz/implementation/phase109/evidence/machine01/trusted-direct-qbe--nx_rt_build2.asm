
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004024a0 <nx_rt_build2>:
  4024a0:	cmpb   $0x0,0x4cd9(%rip)        # 407180 <nx_active>
  4024a7:	push   %r14
  4024a9:	push   %r13
  4024ab:	push   %r12
  4024ad:	push   %rbp
  4024ae:	push   %rbx
  4024af:	je     4024bd <nx_rt_build2+0x1d>
  4024b1:	lea    0x4ce8(%rip),%rax        # 4071a0 <nx_context>
  4024b8:	cmp    %rax,%rdi
  4024bb:	je     4024d0 <nx_rt_build2+0x30>
  4024bd:	lea    0x1b6f(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4024c4:	callq  4019d0 <err_fail>
  4024c9:	nopl   0x0(%rax)
  4024d0:	mov    0x4cc9(%rip),%r14        # 4071a0 <nx_context>
  4024d7:	mov    %esi,%r12d
  4024da:	mov    %rdx,%r13
  4024dd:	mov    %rcx,%rbx
  4024e0:	mov    0x4cc1(%rip),%rbp        # 4071a8 <nx_context+0x8>
  4024e7:	mov    %r14,%rdi
  4024ea:	callq  401c00 <nx_fields.isra.0>
  4024ef:	mov    0x8(%rbp),%r9
  4024f3:	test   %r9,%r9
  4024f6:	je     402524 <nx_rt_build2+0x84>
  4024f8:	mov    (%r14,%r9,8),%rax
  4024fc:	subq   $0x2,0x108(%rbp)
  402504:	mov    %rax,0x8(%rbp)
  402508:	mov    %rbx,%r8
  40250b:	mov    %r13,%rcx
  40250e:	pop    %rbx
  40250f:	mov    %r12d,%edx
  402512:	mov    %r14,%rdi
  402515:	mov    %rbp,%rsi
  402518:	pop    %rbp
  402519:	pop    %r12
  40251b:	pop    %r13
  40251d:	pop    %r14
  40251f:	jmpq   401ca0 <nx_construct2>
  402524:	jmpq   40154f <nx_rt_build2.cold>

Disassembly of section .fini:
