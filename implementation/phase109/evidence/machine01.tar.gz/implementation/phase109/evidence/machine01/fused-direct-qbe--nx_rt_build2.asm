
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402460 <nx_rt_build2>:
  402460:	cmpb   $0x0,0x4d19(%rip)        # 407180 <nx_active>
  402467:	push   %r14
  402469:	push   %r13
  40246b:	push   %r12
  40246d:	push   %rbp
  40246e:	push   %rbx
  40246f:	je     40247d <nx_rt_build2+0x1d>
  402471:	lea    0x4d28(%rip),%rax        # 4071a0 <nx_context>
  402478:	cmp    %rax,%rdi
  40247b:	je     402490 <nx_rt_build2+0x30>
  40247d:	lea    0x1baf(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402484:	callq  401990 <err_fail>
  402489:	nopl   0x0(%rax)
  402490:	mov    0x4d09(%rip),%r14        # 4071a0 <nx_context>
  402497:	mov    %esi,%r12d
  40249a:	mov    %rdx,%r13
  40249d:	mov    %rcx,%rbx
  4024a0:	mov    0x4d01(%rip),%rbp        # 4071a8 <nx_context+0x8>
  4024a7:	mov    %r14,%rdi
  4024aa:	callq  401bc0 <nx_fields.isra.0>
  4024af:	mov    0x8(%rbp),%r9
  4024b3:	test   %r9,%r9
  4024b6:	je     4024e4 <nx_rt_build2+0x84>
  4024b8:	mov    (%r14,%r9,8),%rax
  4024bc:	subq   $0x2,0x108(%rbp)
  4024c4:	mov    %rax,0x8(%rbp)
  4024c8:	mov    %rbx,%r8
  4024cb:	mov    %r13,%rcx
  4024ce:	pop    %rbx
  4024cf:	mov    %r12d,%edx
  4024d2:	mov    %r14,%rdi
  4024d5:	mov    %rbp,%rsi
  4024d8:	pop    %rbp
  4024d9:	pop    %r12
  4024db:	pop    %r13
  4024dd:	pop    %r14
  4024df:	jmpq   401c60 <nx_construct2>
  4024e4:	jmpq   40154f <nx_rt_build2.cold>

Disassembly of section .fini:
