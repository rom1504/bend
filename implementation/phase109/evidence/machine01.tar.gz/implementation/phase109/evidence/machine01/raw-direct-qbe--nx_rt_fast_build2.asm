
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402830 <nx_rt_fast_build2>:
  402830:	push   %r15
  402832:	push   %r14
  402834:	push   %r13
  402836:	mov    %rdx,%r13
  402839:	push   %r12
  40283b:	mov    %rcx,%r12
  40283e:	push   %rbp
  40283f:	push   %rbx
  402840:	mov    %esi,%ebx
  402842:	sub    $0x18,%rsp
  402846:	mov    0x8(%rdi),%r14
  40284a:	mov    (%rdi),%r15
  40284d:	mov    0x8(%r14),%rbp
  402851:	test   %rbp,%rbp
  402854:	je     4015f3 <nx_rt_fast_build2.cold+0x40>
  40285a:	lea    (%r15,%rbp,8),%r8
  40285e:	mov    (%r8),%rax
  402861:	subq   $0x2,0x108(%r14)
  402869:	mov    %rax,0x8(%r14)
  40286d:	mov    %r13,%rax
  402870:	shr    $0x38,%rax
  402874:	and    $0x7f,%eax
  402877:	cmp    $0x2,%rax
  40287b:	je     4028c0 <nx_rt_fast_build2+0x90>
  40287d:	mov    %r12,%rax
  402880:	mov    %r13,(%r8)
  402883:	lea    0x8(%r15,%rbp,8),%r13
  402888:	shr    $0x38,%rax
  40288c:	and    $0x7f,%eax
  40288f:	cmp    $0x2,%rax
  402893:	je     4028d0 <nx_rt_fast_build2+0xa0>
  402895:	mov    %rbx,%rax
  402898:	mov    %r12,0x0(%r13)
  40289c:	add    $0x18,%rsp
  4028a0:	shl    $0x28,%rax
  4028a4:	pop    %rbx
  4028a5:	or     %rbp,%rax
  4028a8:	pop    %rbp
  4028a9:	pop    %r12
  4028ab:	bts    $0x39,%rax
  4028b0:	pop    %r13
  4028b2:	pop    %r14
  4028b4:	pop    %r15
  4028b6:	retq   
  4028b7:	nopw   0x0(%rax,%rax,1)
  4028c0:	test   %r13,%r13
  4028c3:	js     40287d <nx_rt_fast_build2+0x4d>
  4028c5:	jmpq   4015b3 <nx_rt_fast_build2.cold>
  4028ca:	nopw   0x0(%rax,%rax,1)
  4028d0:	test   %r12,%r12
  4028d3:	js     402895 <nx_rt_fast_build2+0x65>
  4028d5:	jmpq   4015d8 <nx_rt_fast_build2.cold+0x25>

Disassembly of section .fini:
