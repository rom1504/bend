
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401fa0 <nx_construct2>:
  401fa0:	push   %r12
  401fa2:	mov    %rcx,%rax
  401fa5:	push   %rbp
  401fa6:	shr    $0x38,%rax
  401faa:	lea    0x0(,%r9,8),%rbp
  401fb2:	push   %rbx
  401fb3:	and    $0x7f,%eax
  401fb6:	mov    %edx,%ebx
  401fb8:	lea    (%rdi,%rbp,1),%r12
  401fbc:	mov    %rcx,%rdx
  401fbf:	sub    $0x20,%rsp
  401fc3:	cmp    $0x2,%rax
  401fc7:	je     402000 <nx_construct2+0x60>
  401fc9:	mov    %r8,%rax
  401fcc:	mov    %rdx,(%r12)
  401fd0:	lea    0x8(%rbp,%rdi,1),%rbp
  401fd5:	shr    $0x38,%rax
  401fd9:	and    $0x7f,%eax
  401fdc:	cmp    $0x2,%rax
  401fe0:	je     402010 <nx_construct2+0x70>
  401fe2:	mov    %rbx,%rax
  401fe5:	mov    %r8,0x0(%rbp)
  401fe9:	add    $0x20,%rsp
  401fed:	shl    $0x28,%rax
  401ff1:	pop    %rbx
  401ff2:	pop    %rbp
  401ff3:	or     %r9,%rax
  401ff6:	pop    %r12
  401ff8:	bts    $0x39,%rax
  401ffd:	retq   
  401ffe:	xchg   %ax,%ax
  402000:	test   %rcx,%rcx
  402003:	js     401fc9 <nx_construct2+0x29>
  402005:	jmpq   401410 <nx_construct2.cold>
  40200a:	nopw   0x0(%rax,%rax,1)
  402010:	test   %r8,%r8
  402013:	js     401fe2 <nx_construct2+0x42>
  402015:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
