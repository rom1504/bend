# All-source diagnostic classification

All 23 sources. Diagnostic one-observation clocks/profiles remain separate from clean medians. Family flags describe observed self frames, not causal operations, absence proofs or gains; shared SCC names remain shared. Full population/failed cases must be assessed before selecting a subset.

| Source | Source B | B2 / TS module B | B2 / TS stage total ms | Largest coarse excess (ms) | B2 / TS sampled MB |
| --- | ---: | ---: | ---: | --- | ---: |
| test-map-set-ops | 5266 | 132866 / 69178 | 2689.7 / 896.4 | Reach + code generation: 1103.6 | 1238.7 / 126.0 |
| test-evening-program | 2152 | 99795 / 62658 | 2208.4 / 935.2 | Reach + code generation: 674.5 | 884.7 / 120.5 |
| raytrace-active | 14680 | 52082 / 29926 | 2134.6 / 820.0 | Check + completion: 552.9 | 997.0 / 110.9 |
| raytrace | 14223 | 50830 / 28974 | 2123.0 / 837.4 | Check + completion: 519.4 | 1018.8 / 111.3 |
| record-aggregation | 1651 | 82645 / 48905 | 2015.0 / 765.5 | Reach + code generation: 567.6 | 774.6 / 100.0 |
| map-churn | 1703 | 83422 / 46419 | 1962.8 / 768.9 | Reach + code generation: 531.0 | 745.8 / 97.2 |
| test-morning-program | 3077 | 83112 / 48892 | 1938.0 / 806.7 | Check + completion: 477.7 | 767.9 / 104.7 |
| list-pipeline | 3249 | 71824 / 40351 | 1893.5 / 758.2 | Check + completion: 479.9 | 678.7 / 92.5 |
| mandelbrot-grid | 7395 | 34843 / 17412 | 1871.2 / 676.7 | Check + completion: 524.7 | 477.3 / 78.0 |
| unicode-text | 5277 | 28570 / 15109 | 1831.9 / 724.1 | Check + completion: 519.3 | 249.5 / 70.5 |
| mandelbrot | 6576 | 32152 / 15442 | 1805.6 / 667.0 | Check + completion: 487.8 | 453.7 / 75.3 |
| local-row | 6245 | 26543 / 12457 | 1643.1 / 655.2 | Check + completion: 474.7 | 255.0 / 68.7 |
| lexer | 7134 | 28426 / 14110 | 1638.2 / 645.7 | Check + completion: 479.1 | 236.9 / 69.9 |
| symreg | 5406 | 27254 / 12815 | 1629.5 / 631.0 | Check + completion: 485.1 | 248.4 / 67.1 |
| editdist | 5874 | 25614 / 11907 | 1624.3 / 643.5 | Check + completion: 482.8 | 251.4 / 71.5 |
| expression | 1522 | 16771 / 5977 | 1563.7 / 650.9 | Check + completion: 543.9 | 197.0 / 56.1 |
| tree-bitonic | 4633 | 23386 / 10593 | 1559.4 / 621.7 | Check + completion: 471.9 | 221.2 / 66.8 |
| test-rle-roundtrip | 2743 | 19976 / 8728 | 1508.2 / 621.7 | Check + completion: 485.8 | 210.6 / 62.4 |
| bst | 3051 | 20983 / 9080 | 1508.1 / 627.8 | Check + completion: 473.2 | 218.0 / 64.6 |
| scalar-region | 1496 | 17811 / 6552 | 1464.7 / 612.9 | Check + completion: 476.3 | 214.1 / 58.9 |
| closures | 1392 | 16130 / 5416 | 1348.0 / 603.5 | Check + completion: 485.0 | 182.2 / 57.1 |
| local-fold | 768 | 15742 / 5191 | 1308.2 / 604.6 | Check + completion: 476.5 | 193.3 / 56.7 |
| numeric-recurrence | 556 | 14917 / 4699 | 1241.8 / 596.8 | Check + completion: 472.9 | 179.8 / 58.2 |
