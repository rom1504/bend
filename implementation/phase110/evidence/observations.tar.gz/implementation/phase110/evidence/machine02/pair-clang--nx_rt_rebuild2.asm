
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402e90 <nx_rt_rebuild2>:
  402e90:	push   %r15
  402e92:	push   %r14
  402e94:	push   %r13
  402e96:	mov    %ecx,%r13d
  402e99:	push   %r12
  402e9b:	mov    %rdi,%r12
  402e9e:	push   %rbp
  402e9f:	movabs $0xffffffffff,%rbp
  402ea9:	push   %rbx
  402eaa:	and    %rsi,%rbp
  402ead:	mov    %edx,%ebx
  402eaf:	lea    0x0(,%rbp,8),%rdx
  402eb7:	sub    $0x28,%rsp
  402ebb:	mov    (%rdi),%r14
  402ebe:	mov    0x8(%rdi),%r15
  402ec2:	lea    (%r14,%rdx,1),%rax
  402ec6:	test   %rsi,%rsi
  402ec9:	js     402fb0 <nx_rt_rebuild2+0x120>
  402ecf:	mov    (%rax),%rax
  402ed2:	mov    %rax,0x10(%rsp)
  402ed7:	mov    0x8(%r14,%rdx,1),%rax
  402edc:	mov    %rax,0x18(%rsp)
  402ee1:	cmp    $0x310817f,%rbp
  402ee8:	jbe    402f88 <nx_rt_rebuild2+0xf8>
  402eee:	lea    (%r14,%rbp,8),%r9
  402ef2:	mov    $0x1,%eax
  402ef7:	mov    0x10(%rsp,%r13,8),%rdx
  402efc:	movq   $0xffffffffffffffff,0x18(%r12)
  402f05:	movl   $0x1,0x20(%r12)
  402f0e:	sub    %r13d,%eax
  402f11:	mov    0x10(%rsp,%rax,8),%rax
  402f16:	mov    %rax,0x10(%r12)
  402f1b:	mov    %rdx,%rax
  402f1e:	shr    $0x38,%rax
  402f22:	and    $0x7f,%eax
  402f25:	cmp    $0x2,%rax
  402f29:	je     402f68 <nx_rt_rebuild2+0xd8>
  402f2b:	mov    %r8,%rax
  402f2e:	mov    %rdx,(%r9)
  402f31:	lea    0x8(%r14,%rbp,8),%r12
  402f36:	shr    $0x38,%rax
  402f3a:	and    $0x7f,%eax
  402f3d:	cmp    $0x2,%rax
  402f41:	je     402f78 <nx_rt_rebuild2+0xe8>
  402f43:	mov    %rbx,%rax
  402f46:	mov    %r8,(%r12)
  402f4a:	add    $0x28,%rsp
  402f4e:	shl    $0x28,%rax
  402f52:	pop    %rbx
  402f53:	or     %rbp,%rax
  402f56:	pop    %rbp
  402f57:	pop    %r12
  402f59:	bts    $0x39,%rax
  402f5e:	pop    %r13
  402f60:	pop    %r14
  402f62:	pop    %r15
  402f64:	retq   
  402f65:	nopl   (%rax)
  402f68:	test   %rdx,%rdx
  402f6b:	js     402f2b <nx_rt_rebuild2+0x9b>
  402f6d:	jmpq   401640 <nx_rt_rebuild2.cold>
  402f72:	nopw   0x0(%rax,%rax,1)
  402f78:	test   %r8,%r8
  402f7b:	js     402f43 <nx_rt_rebuild2+0xb3>
  402f7d:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  402f82:	nopw   0x0(%rax,%rax,1)
  402f88:	mov    0x8(%r15),%rbp
  402f8c:	test   %rbp,%rbp
  402f8f:	je     401685 <nx_rt_rebuild2.cold+0x45>
  402f95:	lea    (%r14,%rbp,8),%r9
  402f99:	mov    (%r9),%rax
  402f9c:	subq   $0x2,0x108(%r15)
  402fa4:	mov    %rax,0x8(%r15)
  402fa8:	jmpq   402ef2 <nx_rt_rebuild2+0x62>
  402fad:	nopl   (%rax)
  402fb0:	mov    0x4(%rax),%edx
  402fb3:	mov    (%rax),%ecx
  402fb5:	shl    $0x20,%rdx
  402fb9:	or     %rcx,%rdx
  402fbc:	mov    %rdx,%rcx
  402fbf:	and    $0xffffff,%edx
  402fc5:	shr    $0x18,%rcx
  402fc9:	lea    0x0(,%rcx,8),%rdi
  402fd1:	lea    (%r14,%rdi,1),%r9
  402fd5:	lea    0x8(%r14,%rdi,1),%rdi
  402fda:	cmp    $0x1,%rdx
  402fde:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  402fe4:	mov    (%rax),%edx
  402fe6:	mov    (%r9),%rdx
  402fe9:	mov    %rdx,0x10(%rsp)
  402fee:	mov    (%rdi),%rdx
  402ff1:	mov    %rdx,0x18(%rsp)
  402ff6:	mov    (%r15),%rdx
  402ff9:	mov    %rdx,(%rax)
  402ffc:	mov    0x100(%r15),%rax
  403003:	mov    0x3e1cf(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403009:	mov    %rbp,(%r15)
  40300c:	add    $0x1,%rax
  403010:	mov    %rax,0x100(%r15)
  403017:	cmp    %rdx,%rax
  40301a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  403020:	mov    %rcx,%rbp
  403023:	jmpq   402ee1 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
