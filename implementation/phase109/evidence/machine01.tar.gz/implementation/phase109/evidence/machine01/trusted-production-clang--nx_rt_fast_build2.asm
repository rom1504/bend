
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402140 <nx_rt_fast_build2>:
  402140:	push   %rbx
  402141:	mov    %esi,%eax
  402143:	mov    %rdi,%rsi
  402146:	mov    (%rdi),%rdi
  402149:	mov    0x8(%rsi),%rsi
  40214d:	mov    0x8(%rsi),%r8
  402151:	test   %r8,%r8
  402154:	je     4021a4 <nx_rt_fast_build2+0x64>
  402156:	mov    (%rdi,%r8,8),%r9
  40215a:	mov    %r9,0x8(%rsi)
  40215e:	addq   $0xfffffffffffffffe,0x108(%rsi)
  402166:	movabs $0xff00000000000000,%r9
  402170:	mov    %rdx,%r10
  402173:	shr    $0x38,%r10
  402177:	cmp    $0x2,%r10d
  40217b:	je     4021bf <nx_rt_fast_build2+0x7f>
  40217d:	mov    %rdx,(%rdi,%r8,8)
  402181:	and    %rcx,%r9
  402184:	movabs $0x200000000000000,%r10
  40218e:	cmp    %r10,%r9
  402191:	je     4021da <nx_rt_fast_build2+0x9a>
  402193:	mov    %rcx,0x8(%rdi,%r8,8)
  402198:	shl    $0x28,%rax
  40219c:	or     %r10,%rax
  40219f:	or     %r8,%rax
  4021a2:	pop    %rbx
  4021a3:	retq   
  4021a4:	mov    %rdx,%r8
  4021a7:	mov    $0x1,%edx
  4021ac:	mov    %rax,%r9
  4021af:	callq  401279 <heap_alloc_miss>
  4021b4:	mov    %r8,%rdx
  4021b7:	mov    %rax,%r8
  4021ba:	mov    %r9,%rax
  4021bd:	jmp    402166 <nx_rt_fast_build2+0x26>
  4021bf:	mov    %rcx,%rbx
  4021c2:	mov    $0x1,%ecx
  4021c7:	mov    %rax,%r10
  4021ca:	callq  401168 <rfc_wrap>
  4021cf:	mov    %rbx,%rcx
  4021d2:	mov    %rax,%rdx
  4021d5:	mov    %r10,%rax
  4021d8:	jmp    40217d <nx_rt_fast_build2+0x3d>
  4021da:	mov    %rcx,%rdx
  4021dd:	mov    $0x1,%ecx
  4021e2:	mov    %rax,%r9
  4021e5:	callq  401168 <rfc_wrap>
  4021ea:	mov    %rax,%rcx
  4021ed:	mov    %r9,%rax
  4021f0:	jmp    402193 <nx_rt_fast_build2+0x53>

Disassembly of section .fini:
