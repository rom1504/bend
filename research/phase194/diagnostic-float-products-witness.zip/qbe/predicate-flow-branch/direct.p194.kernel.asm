  406a90:	endbr64 
  406a94:	push   %rbp
  406a95:	mov    %rsp,%rbp
  406a98:	mov    %rcx,%rax
  406a9b:	mov    %rax,%rcx
  406a9e:	xchg   %ax,%ax
  406aa0:	cmp    $0x0,%rsi
  406aa4:	je     406ad1 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x41>
  406aa6:	mov    %edx,%eax
  406aa8:	mov    %rcx,%rdx
  406aab:	and    $0x7,%rdx
  406aaf:	mov    %ecx,%ecx
  406ab1:	cmp    $0x3,%rdx
  406ab5:	jb     406abc <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x2c>
  406ab7:	xor    %rax,%rcx
  406aba:	jmp    406ac6 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x36>
  406abc:	imul   $0x3,%ecx,%ecx
  406abf:	mov    %ecx,%ecx
  406ac1:	add    $0x1,%ecx
  406ac4:	mov    %ecx,%ecx
  406ac6:	sub    $0x1,%rsi
  406aca:	add    $0x1,%eax
  406acd:	mov    %eax,%edx
  406acf:	jmp    406aa0 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x10>
  406ad1:	mov    %rcx,%rax
  406ad4:	leaveq 
  406ad5:	retq   
  406ad6:	nopw   %cs:0x0(%rax,%rax,1)
