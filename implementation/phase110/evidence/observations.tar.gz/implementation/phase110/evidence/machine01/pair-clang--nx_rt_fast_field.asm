
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402cb0 <nx_rt_fast_field>:
  402cb0:	mov    %esi,%ecx
  402cb2:	mov    $0xfffffffe,%eax
  402cb7:	rol    %cl,%eax
  402cb9:	add    $0x2,%rcx
  402cbd:	and    %eax,0x20(%rdi)
  402cc0:	mov    (%rdi,%rcx,8),%rax
  402cc4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402ccc:	retq   

Disassembly of section .fini:
