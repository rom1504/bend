
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004036e0 <nx_rt_pair_rebuild2_c1_k0>:
  4036e0:	push   %r15
  4036e2:	push   %r14
  4036e4:	push   %r13
  4036e6:	push   %r12
  4036e8:	mov    %rdx,%r12
  4036eb:	push   %rbp
  4036ec:	push   %rbx
  4036ed:	movabs $0xffffffffff,%rbx
  4036f7:	and    %rsi,%rbx
  4036fa:	lea    0x0(,%rbx,8),%rdx
  403702:	sub    $0x18,%rsp
  403706:	mov    (%rdi),%rbp
  403709:	mov    0x8(%rdi),%r15
  40370d:	lea    0x0(%rbp,%rdx,1),%rax
  403712:	test   %rsi,%rsi
  403715:	js     4037d0 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  40371b:	mov    (%rax),%r14
  40371e:	mov    0x8(%rbp,%rdx,1),%r13
  403723:	cmp    $0x310817f,%rbx
  40372a:	jbe    4037a0 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  40372c:	lea    0x0(%rbp,%rbx,8),%r8
  403731:	mov    %r14,%rax
  403734:	shr    $0x38,%rax
  403738:	and    $0x7f,%eax
  40373b:	cmp    $0x2,%rax
  40373f:	je     403780 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403741:	mov    %r12,%rax
  403744:	mov    %r14,(%r8)
  403747:	lea    0x8(%rbp,%rbx,8),%r14
  40374c:	shr    $0x38,%rax
  403750:	and    $0x7f,%eax
  403753:	cmp    $0x2,%rax
  403757:	je     403790 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403759:	movabs $0x200010000000000,%rax
  403763:	mov    %r12,(%r14)
  403766:	mov    %r13,%rdx
  403769:	add    $0x18,%rsp
  40376d:	or     %rbx,%rax
  403770:	pop    %rbx
  403771:	pop    %rbp
  403772:	pop    %r12
  403774:	pop    %r13
  403776:	pop    %r14
  403778:	pop    %r15
  40377a:	retq   
  40377b:	nopl   0x0(%rax,%rax,1)
  403780:	test   %r14,%r14
  403783:	js     403741 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403785:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  40378a:	nopw   0x0(%rax,%rax,1)
  403790:	test   %r12,%r12
  403793:	js     403759 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403795:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  40379a:	nopw   0x0(%rax,%rax,1)
  4037a0:	mov    0x8(%r15),%rbx
  4037a4:	test   %rbx,%rbx
  4037a7:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  4037ad:	lea    0x0(%rbp,%rbx,8),%r8
  4037b2:	mov    (%r8),%rax
  4037b5:	subq   $0x2,0x108(%r15)
  4037bd:	mov    %rax,0x8(%r15)
  4037c1:	jmpq   403731 <nx_rt_pair_rebuild2_c1_k0+0x51>
  4037c6:	nopw   %cs:0x0(%rax,%rax,1)
  4037d0:	mov    0x4(%rax),%edx
  4037d3:	mov    (%rax),%ecx
  4037d5:	shl    $0x20,%rdx
  4037d9:	or     %rcx,%rdx
  4037dc:	mov    %rdx,%rcx
  4037df:	and    $0xffffff,%edx
  4037e5:	shr    $0x18,%rcx
  4037e9:	lea    0x8(,%rcx,8),%rdi
  4037f1:	lea    0x0(%rbp,%rdi,1),%r8
  4037f6:	lea    -0x8(%rbp,%rdi,1),%rdi
  4037fb:	cmp    $0x1,%rdx
  4037ff:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403805:	mov    (%rax),%edx
  403807:	mov    (%r15),%rdx
  40380a:	mov    (%rdi),%r14
  40380d:	mov    (%r8),%r13
  403810:	mov    %rdx,(%rax)
  403813:	mov    0x100(%r15),%rax
  40381a:	mov    0x3d9b8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403820:	mov    %rbx,(%r15)
  403823:	add    $0x1,%rax
  403827:	mov    %rax,0x100(%r15)
  40382e:	cmp    %rdx,%rax
  403831:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403837:	mov    %rcx,%rbx
  40383a:	jmpq   403723 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
