0000000000409232 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_>:
  409232:	push   rbp
  409233:	mov    rbp,rsp
  409236:	sub    rsp,0x960
  40923d:	mov    QWORD PTR [rbp-0x10],r12
  409241:	mov    QWORD PTR [rbp-0x8],rbx
  409245:	mov    QWORD PTR [rbp-0x18],r13
  409249:	mov    QWORD PTR [rbp-0x20],r14
  40924d:	mov    rax,rdi
  409250:	mov    r12,rax
  409253:	mov    rax,rsi
  409256:	mov    rsi,rax
  409259:	mov    rax,rdx
  40925c:	mov    rbx,rax
  40925f:	mov    rdi,rsi
  409262:	shr    rdi,0x28
  409266:	and    rdi,0xffff
  40926d:	movabs r11,0x11
  409277:	cmp    rdi,r11
  40927a:	sete   dil
  40927e:	movzx  edi,dil
  409282:	mov    r10,rdi
  409285:	test   r10d,r10d
  409288:	je     4092a6 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x74>
  40928e:	mov    rax,rbx
  409291:	mov    r12,QWORD PTR [rbp-0x10]
  409295:	mov    rbx,QWORD PTR [rbp-0x8]
  409299:	mov    r13,QWORD PTR [rbp-0x18]
  40929d:	mov    r14,QWORD PTR [rbp-0x20]
  4092a1:	mov    rsp,rbp
  4092a4:	pop    rbp
  4092a5:	ret    
  4092a6:	mov    rdi,rsi
  4092a9:	shr    rdi,0x28
  4092ad:	and    rdi,0xffff
  4092b4:	movabs r11,0x12
  4092be:	cmp    rdi,r11
  4092c1:	sete   dil
  4092c5:	movzx  edi,dil
  4092c9:	mov    r10,rdi
  4092cc:	test   r10d,r10d
  4092cf:	je     409589 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x357>
  4092d5:	mov    r10,r12
  4092d8:	mov    QWORD PTR [rsp+0x18],r10
  4092dd:	mov    r10,rsi
  4092e0:	mov    QWORD PTR [rsp+0x20],r10
  4092e5:	lea    r10,[rbp-0x840]
  4092ec:	mov    QWORD PTR [rsp+0x28],r10
  4092f1:	mov    rdi,QWORD PTR [rsp+0x18]
  4092f6:	mov    rsi,QWORD PTR [rsp+0x20]
  4092fb:	mov    rdx,QWORD PTR [rsp+0x28]
  409300:	xor    eax,eax
  409302:	call   41dbc0 <p125_rt_take2>
  409307:	mov    QWORD PTR [rbp-0x8b0],rax
  40930e:	lea    r10,[rbp-0x840]
  409315:	mov    rsi,QWORD PTR [r10]
  409318:	lea    r10,[rbp-0x840]
  40931f:	mov    r14,QWORD PTR [r10+0x8]
  409323:	mov    rdi,rsi
  409326:	shr    rdi,0x28
  40932a:	and    rdi,0xffff
  409331:	movabs r11,0xa6
  40933b:	cmp    rdi,r11
  40933e:	sete   dil
  409342:	movzx  edi,dil
  409346:	mov    r10,rdi
  409349:	test   r10d,r10d
  40934c:	je     40954d <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x31b>
  409352:	mov    r10,r12
  409355:	mov    QWORD PTR [rsp+0x18],r10
  40935a:	mov    r10,rsi
  40935d:	mov    QWORD PTR [rsp+0x20],r10
  409362:	lea    r10,[rbp-0x840]
  409369:	mov    QWORD PTR [rsp+0x28],r10
  40936e:	mov    rdi,QWORD PTR [rsp+0x18]
  409373:	mov    rsi,QWORD PTR [rsp+0x20]
  409378:	mov    rdx,QWORD PTR [rsp+0x28]
  40937d:	xor    eax,eax
  40937f:	call   41de20 <p125_rt_take3>
  409384:	mov    QWORD PTR [rbp-0x8b0],rax
  40938b:	lea    r10,[rbp-0x840]
  409392:	mov    r13,QWORD PTR [r10]
  409395:	lea    r10,[rbp-0x840]
  40939c:	mov    rdx,QWORD PTR [r10+0x8]
  4093a0:	lea    r10,[rbp-0x840]
  4093a7:	mov    rsi,QWORD PTR [r10+0x10]
  4093ab:	mov    r9,rsi
  4093ae:	cmp    r9,0x1
  4093b5:	sete   r9b
  4093b9:	movzx  r9d,r9b
  4093bd:	mov    rdi,rsi
  4093c0:	shr    rdi,0x28
  4093c4:	and    rdi,0x7fffff
  4093cb:	movabs r8,0x2
  4093d5:	or     r8,0x10000
  4093dc:	cmp    rdi,r8
  4093df:	sete   dil
  4093e3:	movzx  edi,dil
  4093e7:	or     edi,r9d
  4093ea:	mov    r10,rdi
  4093ed:	test   r10d,r10d
  4093f0:	je     409447 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x215>
  4093f6:	lea    r10,[rbp-0x840]
  4093fd:	mov    r11,rbx
  409400:	mov    QWORD PTR [r10],r11
  409403:	lea    r10,[rbp-0x840]
  40940a:	mov    r11,r13
  40940d:	mov    QWORD PTR [r10+0x8],r11
  409411:	lea    r10,[rbp-0x840]
  409418:	mov    r11,rdx
  40941b:	mov    QWORD PTR [r10+0x10],r11
  40941f:	mov    rdi,r12
  409422:	movabs rsi,0xa5
  40942c:	mov    esi,esi
  40942e:	lea    rdx,[rbp-0x840]
  409435:	xor    eax,eax
  409437:	call   41dd50 <p125_rt_ctor3>
  40943c:	mov    rbx,rax
  40943f:	mov    rsi,r14
  409442:	jmp    40925f <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2d>
  409447:	mov    r9,rsi
  40944a:	cmp    r9,0x1
  409451:	sete   r9b
  409455:	movzx  r9d,r9b
  409459:	mov    rdi,rsi
  40945c:	shr    rdi,0x28
  409460:	and    rdi,0x7fffff
  409467:	movabs r8,0x2
  409471:	or     r8,0x10000
  409478:	cmp    rdi,r8
  40947b:	sete   dil
  40947f:	movzx  edi,dil
  409483:	or     edi,r9d
  409486:	xor    edi,0x1
  40948c:	mov    r10,rdi
  40948f:	test   r10d,r10d
  409492:	je     4094e9 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2b7>
  409498:	lea    r10,[rbp-0x840]
  40949f:	mov    r11,rdx
  4094a2:	mov    QWORD PTR [r10],r11
  4094a5:	lea    r10,[rbp-0x840]
  4094ac:	mov    r11,r13
  4094af:	mov    QWORD PTR [r10+0x8],r11
  4094b3:	lea    r10,[rbp-0x840]
  4094ba:	mov    r11,rbx
  4094bd:	mov    QWORD PTR [r10+0x10],r11
  4094c1:	mov    rdi,r12
  4094c4:	movabs rsi,0xa5
  4094ce:	mov    esi,esi
  4094d0:	lea    rdx,[rbp-0x840]
  4094d7:	xor    eax,eax
  4094d9:	call   41dd50 <p125_rt_ctor3>
  4094de:	mov    rbx,rax
  4094e1:	mov    rsi,r14
  4094e4:	jmp    40925f <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x2d>
  4094e9:	mov    r10,r12
  4094ec:	mov    QWORD PTR [rsp+0x10],r10
  4094f1:	mov    r10,rdx
  4094f4:	mov    QWORD PTR [rsp+0x18],r10
  4094f9:	mov    rdi,QWORD PTR [rsp+0x10]
  4094fe:	mov    rsi,QWORD PTR [rsp+0x18]
  409503:	xor    eax,eax
  409505:	call   417e20 <p111_rt_sink>
  40950a:	mov    QWORD PTR [rbp-0x8b0],rax
  409511:	mov    rdi,r12
  409514:	movabs rsi,0x4
  40951e:	mov    esi,esi
  409520:	xor    eax,eax
  409522:	call   4185b0 <p111_rt_fail>
  409527:	mov    QWORD PTR [rbp-0x8b0],rax
  40952e:	movabs rax,0x0
  409538:	mov    r12,QWORD PTR [rbp-0x10]
  40953c:	mov    rbx,QWORD PTR [rbp-0x8]
  409540:	mov    r13,QWORD PTR [rbp-0x18]
  409544:	mov    r14,QWORD PTR [rbp-0x20]
  409548:	mov    rsp,rbp
  40954b:	pop    rbp
  40954c:	ret    
  40954d:	mov    rdi,r12
  409550:	movabs rsi,0x4
  40955a:	mov    esi,esi
  40955c:	xor    eax,eax
  40955e:	call   4185b0 <p111_rt_fail>
  409563:	mov    QWORD PTR [rbp-0x8b0],rax
  40956a:	movabs rax,0x0
  409574:	mov    r12,QWORD PTR [rbp-0x10]
  409578:	mov    rbx,QWORD PTR [rbp-0x8]
  40957c:	mov    r13,QWORD PTR [rbp-0x18]
  409580:	mov    r14,QWORD PTR [rbp-0x20]
  409584:	mov    rsp,rbp
  409587:	pop    rbp
  409588:	ret    
  409589:	mov    rdi,r12
  40958c:	movabs rsi,0x4
  409596:	mov    esi,esi
  409598:	xor    eax,eax
  40959a:	call   4185b0 <p111_rt_fail>
  40959f:	mov    QWORD PTR [rbp-0x8b0],rax
  4095a6:	movabs rax,0x0
  4095b0:	mov    r12,QWORD PTR [rbp-0x10]
  4095b4:	mov    rbx,QWORD PTR [rbp-0x8]
  4095b8:	mov    r13,QWORD PTR [rbp-0x18]
  4095bc:	mov    r14,QWORD PTR [rbp-0x20]
  4095c0:	mov    rsp,rbp
  4095c3:	pop    rbp
  4095c4:	ret    

