
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/coverage-record-aggregation-256/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000041bc30 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_>:
  41bc30:	endbr64 
  41bc34:	cs cs cs cs push %rbp
  41bc39:	mov    %rsp,%rbp
  41bc3c:	sub    $0x38a8,%rsp
  41bc43:	push   %rbx
  41bc44:	push   %r12
  41bc46:	push   %r13
  41bc48:	push   %r14
  41bc4a:	push   %r15
  41bc4c:	mov    0x28(%rdi),%rsi
  41bc50:	mov    0x30(%rdi),%r12
  41bc54:	mov    %rsi,%rax
  41bc57:	shr    $0x28,%rax
  41bc5b:	and    $0xffff,%rax
  41bc61:	cmp    $0x2d,%rax
  41bc65:	sete   %al
  41bc68:	movzbl %al,%eax
  41bc6b:	mov    %r12,%rcx
  41bc6e:	shr    $0x28,%rcx
  41bc72:	mov    %rcx,%rbx
  41bc75:	and    $0xffff,%rbx
  41bc7c:	mov    %rbx,-0x80(%rbp)
  41bc80:	cmp    $0x0,%eax
  41bc83:	jne    41bdb6 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x186>
  41bc89:	cmp    $0x8,%rbx
  41bc8d:	je     41bcca <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x9a>
  41bc8f:	mov    %rdi,%rbx
  41bc92:	callq  42aec0 <p111_rt_sink>
  41bc97:	mov    %r12,%rsi
  41bc9a:	mov    %rbx,%rdi
  41bc9d:	mov    %rsi,-0x38a0(%rbp)
  41bca4:	mov    0x10(%rdi),%rax
  41bca8:	mov    %rsi,(%rax)
  41bcab:	movq   $0x17f,0x8(%rax)
  41bcb3:	add    $0x10,%rax
  41bcb7:	mov    %rax,0x10(%rdi)
  41bcbb:	mov    $0x4,%esi
  41bcc0:	callq  42b650 <p111_rt_fail>
  41bcc5:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41bcca:	xchg   %r12,%rsi
  41bccd:	lea    -0x38a0(%rbp),%rdx
  41bcd4:	mov    %rsi,%r15
  41bcd7:	mov    %rdi,%rbx
  41bcda:	callq  430c60 <p125_rt_take2>
  41bcdf:	mov    %r12,%rsi
  41bce2:	mov    %rbx,%rdi
  41bce5:	mov    -0x38a0(%rbp),%rbx
  41bcec:	mov    %rsi,%r13
  41bcef:	mov    -0x3898(%rbp),%rsi
  41bcf6:	mov    %rdi,%r12
  41bcf9:	callq  42aec0 <p111_rt_sink>
  41bcfe:	mov    %r13,%rsi
  41bd01:	mov    %r12,%rdi
  41bd04:	mov    %rbx,-0x38a0(%rbp)
  41bd0b:	movabs $0x1000b0000000000,%rax
  41bd15:	mov    %rax,-0x3898(%rbp)
  41bd1c:	lea    -0x38a0(%rbp),%rdx
  41bd23:	mov    %rsi,%r12
  41bd26:	mov    $0x8,%esi
  41bd2b:	mov    %rdi,%rbx
  41bd2e:	callq  430b70 <p125_rt_ctor2>
  41bd33:	mov    %r12,%rsi
  41bd36:	mov    %rbx,%rdi
  41bd39:	mov    %rsi,-0x38a0(%rbp)
  41bd40:	mov    %rax,-0x3898(%rbp)
  41bd47:	lea    -0x38a0(%rbp),%rdx
  41bd4e:	mov    $0x8,%esi
  41bd53:	mov    %rdi,%rbx
  41bd56:	callq  430b70 <p125_rt_ctor2>
  41bd5b:	mov    %rbx,%rdi
  41bd5e:	mov    %rax,-0x38a0(%rbp)
  41bd65:	mov    0x1dea4(%rip),%rcx        # 439c10 <p111_program+0x58>
  41bd6c:	test   $0x4,%rcx
  41bd73:	jne    41bd8b <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15b>
  41bd75:	mov    $0x1,%edx
  41bd7a:	lea    -0x38a0(%rbp),%rsi
  41bd81:	callq  42b4e0 <p111_rt_return>
  41bd86:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41bd8b:	mov    %rax,0x28(%rdi)
  41bd8f:	movl   $0x1,0x1c(%rdi)
  41bd96:	mov    0x10(%rdi),%rax
  41bd9a:	mov    %rax,%rcx
  41bd9d:	add    $0xfffffffffffffff8,%rcx
  41bda1:	mov    %rcx,0x10(%rdi)
  41bda5:	mov    -0x8(%rax),%rax
  41bda9:	mov    %eax,0x20(%rdi)
  41bdac:	mov    $0x0,%eax
  41bdb1:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41bdb6:	mov    %r12,%r15
  41bdb9:	mov    %rbx,%r12
  41bdbc:	lea    -0x38a0(%rbp),%rdx
  41bdc3:	mov    %rdi,%rbx
  41bdc6:	callq  430ec0 <p125_rt_take3>
  41bdcb:	mov    %rbx,%rdi
  41bdce:	mov    -0x38a0(%rbp),%rbx
  41bdd5:	mov    -0x3898(%rbp),%rsi
  41bddc:	mov    -0x3890(%rbp),%r14
  41bde3:	mov    %rsi,%rax
  41bde6:	shr    $0x28,%rax
  41bdea:	and    $0xffff,%rax
  41bdf0:	cmp    $0x2b,%rax
  41bdf4:	sete   %dl
  41bdf7:	movzbl %dl,%edx
  41bdfa:	mov    %rax,%rcx
  41bdfd:	mov    %r14,%rax
  41be00:	shr    $0x28,%rax
  41be04:	and    $0xffff,%rax
  41be0a:	mov    %rax,-0x58(%rbp)
  41be0e:	cmp    $0x0,%edx
  41be11:	jne    41da70 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e40>
  41be17:	mov    %rcx,%rax
  41be1a:	nopw   0x0(%rax,%rax,1)
  41be20:	cmp    $0x2c,%rax
  41be24:	je     41ccc5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1095>
  41be2a:	cmp    $0x2d,%rax
  41be2e:	je     41bead <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x27d>
  41be30:	mov    %rsi,%r12
  41be33:	mov    %rbx,%rsi
  41be36:	mov    %rdi,%rbx
  41be39:	callq  42aec0 <p111_rt_sink>
  41be3e:	mov    %r12,%rsi
  41be41:	mov    %rbx,%rdi
  41be44:	mov    %r15,-0x38a0(%rbp)
  41be4b:	mov    0x10(%rdi),%rax
  41be4f:	mov    %r15,(%rax)
  41be52:	movq   $0x17c,0x8(%rax)
  41be5a:	add    $0x10,%rax
  41be5e:	mov    %rax,0x10(%rdi)
  41be62:	mov    %r14,-0x38a0(%rbp)
  41be69:	mov    0x10(%rdi),%rax
  41be6d:	mov    %r14,(%rax)
  41be70:	movq   $0x17d,0x8(%rax)
  41be78:	add    $0x10,%rax
  41be7c:	mov    %rax,0x10(%rdi)
  41be80:	mov    %rsi,-0x38a0(%rbp)
  41be87:	mov    0x10(%rdi),%rax
  41be8b:	mov    %rsi,(%rax)
  41be8e:	movq   $0x17e,0x8(%rax)
  41be96:	add    $0x10,%rax
  41be9a:	mov    %rax,0x10(%rdi)
  41be9e:	mov    $0x4,%esi
  41bea3:	callq  42b650 <p111_rt_fail>
  41bea8:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41bead:	lea    -0x38a0(%rbp),%rdx
  41beb4:	mov    %rdi,%r13
  41beb7:	callq  430ec0 <p125_rt_take3>
  41bebc:	mov    %r14,%rsi
  41bebf:	mov    %r13,%rdi
  41bec2:	mov    -0x58(%rbp),%rax
  41bec6:	mov    %rsi,%r14
  41bec9:	mov    -0x38a0(%rbp),%rsi
  41bed0:	mov    %r12,%rcx
  41bed3:	mov    -0x3898(%rbp),%r12
  41beda:	mov    -0x3890(%rbp),%r13
  41bee1:	mov    %r13,-0x30(%rbp)
  41bee5:	cmp    $0x2b,%rax
  41bee9:	je     41c912 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xce2>
  41beef:	cmp    $0x2c,%rax
  41bef3:	je     41c455 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x825>
  41bef9:	nopl   0x0(%rax)
  41bf00:	cmp    $0x2d,%rax
  41bf04:	je     41bfa5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x375>
  41bf0a:	cs cs mov %rsi,%r13
  41bf0f:	mov    %rbx,%rsi
  41bf12:	mov    %rdi,%rbx
  41bf15:	callq  42aec0 <p111_rt_sink>
  41bf1a:	mov    %r13,%rsi
  41bf1d:	mov    %rbx,%rdi
  41bf20:	mov    -0x30(%rbp),%rbx
  41bf24:	mov    %rdi,%r13
  41bf27:	callq  42aec0 <p111_rt_sink>
  41bf2c:	mov    %r14,%rsi
  41bf2f:	mov    %r13,%rdi
  41bf32:	mov    %rsi,%r13
  41bf35:	mov    %r12,%rsi
  41bf38:	mov    %rdi,%r12
  41bf3b:	callq  42aec0 <p111_rt_sink>
  41bf40:	mov    %r13,%rsi
  41bf43:	mov    %r12,%rdi
  41bf46:	mov    %rsi,%r12
  41bf49:	mov    %rbx,%rsi
  41bf4c:	mov    %rdi,%rbx
  41bf4f:	callq  42aec0 <p111_rt_sink>
  41bf54:	mov    %r12,%rsi
  41bf57:	mov    %rbx,%rdi
  41bf5a:	mov    %r15,-0x38a0(%rbp)
  41bf61:	mov    0x10(%rdi),%rax
  41bf65:	mov    %r15,(%rax)
  41bf68:	movq   $0x17a,0x8(%rax)
  41bf70:	add    $0x10,%rax
  41bf74:	mov    %rax,0x10(%rdi)
  41bf78:	mov    %rsi,-0x38a0(%rbp)
  41bf7f:	mov    0x10(%rdi),%rax
  41bf83:	mov    %rsi,(%rax)
  41bf86:	movq   $0x17b,0x8(%rax)
  41bf8e:	add    $0x10,%rax
  41bf92:	mov    %rax,0x10(%rdi)
  41bf96:	mov    $0x4,%esi
  41bf9b:	callq  42b650 <p111_rt_fail>
  41bfa0:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41bfa5:	mov    %r12,%r13
  41bfa8:	xchg   %rsi,%r14
  41bfab:	lea    -0x38a0(%rbp),%rdx
  41bfb2:	mov    %rdi,%r12
  41bfb5:	callq  430ec0 <p125_rt_take3>
  41bfba:	mov    %r14,%rsi
  41bfbd:	mov    %r12,%rdi
  41bfc0:	mov    %rbx,%r12
  41bfc3:	mov    -0x30(%rbp),%rbx
  41bfc7:	mov    -0x80(%rbp),%r14
  41bfcb:	mov    -0x38a0(%rbp),%rax
  41bfd2:	mov    %rax,-0x10(%rbp)
  41bfd6:	mov    -0x3898(%rbp),%rax
  41bfdd:	mov    %rax,-0x18(%rbp)
  41bfe1:	mov    -0x3890(%rbp),%rax
  41bfe8:	mov    %rax,-0x20(%rbp)
  41bfec:	cmp    $0x8,%r14
  41bff0:	je     41c0be <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x48e>
  41bff6:	mov    %rsi,%r14
  41bff9:	mov    %r12,%rsi
  41bffc:	mov    %rdi,%r12
  41bfff:	callq  42aec0 <p111_rt_sink>
  41c004:	mov    %r14,%rsi
  41c007:	mov    %r12,%rdi
  41c00a:	mov    %rbx,%r12
  41c00d:	mov    -0x10(%rbp),%rbx
  41c011:	mov    %rdi,%r14
  41c014:	callq  42aec0 <p111_rt_sink>
  41c019:	mov    %r15,%rsi
  41c01c:	mov    %r14,%rdi
  41c01f:	mov    -0x18(%rbp),%r15
  41c023:	mov    %rsi,%r14
  41c026:	mov    %r13,%rsi
  41c029:	mov    %rdi,%r13
  41c02c:	callq  42aec0 <p111_rt_sink>
  41c031:	mov    %r14,%rsi
  41c034:	mov    %r13,%rdi
  41c037:	mov    -0x20(%rbp),%r14
  41c03b:	mov    %rsi,%r13
  41c03e:	mov    %r12,%rsi
  41c041:	mov    %rdi,%r12
  41c044:	callq  42aec0 <p111_rt_sink>
  41c049:	mov    %r13,%rsi
  41c04c:	mov    %r12,%rdi
  41c04f:	mov    %rbx,%rax
  41c052:	mov    %rsi,%r12
  41c055:	mov    %rax,%rsi
  41c058:	mov    %rdi,%rbx
  41c05b:	callq  42aec0 <p111_rt_sink>
  41c060:	mov    %r12,%rsi
  41c063:	mov    %rbx,%rdi
  41c066:	mov    %rsi,%r12
  41c069:	mov    %r15,%rsi
  41c06c:	mov    %rdi,%rbx
  41c06f:	callq  42aec0 <p111_rt_sink>
  41c074:	mov    %r14,%rcx
  41c077:	mov    %r12,%rsi
  41c07a:	mov    %rbx,%rdi
  41c07d:	mov    %rsi,%r12
  41c080:	mov    %rcx,%rsi
  41c083:	mov    %rdi,%rbx
  41c086:	callq  42aec0 <p111_rt_sink>
  41c08b:	mov    %r12,%rsi
  41c08e:	mov    %rbx,%rdi
  41c091:	mov    %rsi,-0x38a0(%rbp)
  41c098:	mov    0x10(%rdi),%rax
  41c09c:	mov    %rsi,(%rax)
  41c09f:	movq   $0x179,0x8(%rax)
  41c0a7:	add    $0x10,%rax
  41c0ab:	mov    %rax,0x10(%rdi)
  41c0af:	mov    $0x4,%esi
  41c0b4:	callq  42b650 <p111_rt_fail>
  41c0b9:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c0be:	mov    %r12,%r14
  41c0c1:	mov    %r13,%r12
  41c0c4:	xchg   %rsi,%r15
  41c0c7:	lea    -0x38a0(%rbp),%rdx
  41c0ce:	mov    %rdi,%r13
  41c0d1:	callq  430c60 <p125_rt_take2>
  41c0d6:	mov    %r15,%rsi
  41c0d9:	mov    %r13,%rdi
  41c0dc:	mov    -0x20(%rbp),%rcx
  41c0e0:	mov    -0x18(%rbp),%r15
  41c0e4:	mov    -0x10(%rbp),%rax
  41c0e8:	mov    -0x38a0(%rbp),%r13
  41c0ef:	mov    %r13,-0x28(%rbp)
  41c0f3:	mov    %rbx,%r13
  41c0f6:	mov    -0x3898(%rbp),%rbx
  41c0fd:	cmp    $0x1,%rbx
  41c101:	sete   %dl
  41c104:	movzbl %dl,%edx
  41c107:	mov    %rbx,%r8
  41c10a:	shr    $0x28,%r8
  41c10e:	and    $0x7fffff,%r8
  41c115:	cmp    $0x10002,%r8
  41c11c:	sete   %r8b
  41c120:	movzbl %r8b,%r8d
  41c124:	mov    %edx,%r9d
  41c127:	or     %r8d,%r9d
  41c12a:	xor    $0x1,%r9d
  41c12e:	jne    41c333 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x703>
  41c134:	or     %r8d,%edx
  41c137:	jne    41c205 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x5d5>
  41c13d:	mov    %rsi,%r15
  41c140:	mov    %r14,%rsi
  41c143:	mov    %rdi,%r14
  41c146:	callq  42aec0 <p111_rt_sink>
  41c14b:	mov    %r15,%rsi
  41c14e:	mov    %r14,%rdi
  41c151:	mov    %r12,%r14
  41c154:	mov    -0x10(%rbp),%r12
  41c158:	mov    %rdi,%r15
  41c15b:	callq  42aec0 <p111_rt_sink>
  41c160:	mov    %r15,%rdi
  41c163:	mov    %r14,%rax
  41c166:	mov    -0x18(%rbp),%r15
  41c16a:	mov    %rax,%rsi
  41c16d:	mov    %rdi,%r14
  41c170:	callq  42aec0 <p111_rt_sink>
  41c175:	mov    %r14,%rdi
  41c178:	mov    -0x20(%rbp),%r14
  41c17c:	mov    %r13,%rsi
  41c17f:	mov    %rdi,%r13
  41c182:	callq  42aec0 <p111_rt_sink>
  41c187:	mov    %r13,%rdi
  41c18a:	mov    %r12,%rax
  41c18d:	mov    -0x28(%rbp),%rsi
  41c191:	mov    %rsi,%r13
  41c194:	mov    %rax,%rsi
  41c197:	mov    %rdi,%r12
  41c19a:	callq  42aec0 <p111_rt_sink>
  41c19f:	mov    %r13,%rsi
  41c1a2:	mov    %r12,%rdi
  41c1a5:	mov    %rsi,%r13
  41c1a8:	mov    %r15,%rsi
  41c1ab:	mov    %rdi,%r12
  41c1ae:	callq  42aec0 <p111_rt_sink>
  41c1b3:	mov    %r13,%rsi
  41c1b6:	mov    %r12,%rdi
  41c1b9:	mov    %rsi,%r13
  41c1bc:	mov    %r14,%rsi
  41c1bf:	mov    %rdi,%r12
  41c1c2:	callq  42aec0 <p111_rt_sink>
  41c1c7:	mov    %r13,%rsi
  41c1ca:	mov    %r12,%rdi
  41c1cd:	mov    %rdi,%r12
  41c1d0:	callq  42aec0 <p111_rt_sink>
  41c1d5:	mov    %r12,%rdi
  41c1d8:	mov    %rbx,-0x38a0(%rbp)
  41c1df:	mov    0x10(%rdi),%rax
  41c1e3:	mov    %rbx,(%rax)
  41c1e6:	movq   $0x178,0x8(%rax)
  41c1ee:	add    $0x10,%rax
  41c1f2:	mov    %rax,0x10(%rdi)
  41c1f6:	mov    $0x4,%esi
  41c1fb:	callq  42b650 <p111_rt_fail>
  41c200:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c205:	mov    %rax,%rbx
  41c208:	mov    %r12,%rax
  41c20b:	mov    %r13,%r12
  41c20e:	mov    %r14,%r13
  41c211:	mov    %rcx,%r14
  41c214:	mov    %rsi,-0x38a0(%rbp)
  41c21b:	mov    %rax,-0x3898(%rbp)
  41c222:	mov    %r12,-0x3890(%rbp)
  41c229:	lea    -0x38a0(%rbp),%rdx
  41c230:	mov    $0x2d,%esi
  41c235:	mov    %rdi,%r12
  41c238:	callq  430df0 <p125_rt_ctor3>
  41c23d:	mov    %r12,%rdi
  41c240:	mov    %rax,%rcx
  41c243:	mov    %rbx,%rax
  41c246:	mov    -0x28(%rbp),%rsi
  41c24a:	mov    %r13,-0x38a0(%rbp)
  41c251:	mov    %rcx,-0x3898(%rbp)
  41c258:	mov    0x10(%rdi),%rcx
  41c25c:	mov    %r13,(%rcx)
  41c25f:	mov    -0x3898(%rbp),%rdx
  41c266:	mov    %rdx,0x8(%rcx)
  41c26a:	movq   $0x176,0x10(%rcx)
  41c272:	add    $0x18,%rcx
  41c276:	mov    %rcx,0x10(%rdi)
  41c27a:	mov    %rsi,%r12
  41c27d:	mov    %rax,%rsi
  41c280:	mov    %rdi,%rbx
  41c283:	callq  42ae30 <p111_rt_keep>
  41c288:	mov    %r12,%rsi
  41c28b:	mov    %rbx,%rdi
  41c28e:	mov    %rax,%rdx
  41c291:	mov    %rdx,-0x38a0(%rbp)
  41c298:	mov    %r15,-0x3898(%rbp)
  41c29f:	mov    %r14,-0x3890(%rbp)
  41c2a6:	mov    %rdx,%r13
  41c2a9:	lea    -0x38a0(%rbp),%rdx
  41c2b0:	mov    %rsi,%r12
  41c2b3:	mov    $0x2d,%esi
  41c2b8:	mov    %rdi,%rbx
  41c2bb:	callq  430df0 <p125_rt_ctor3>
  41c2c0:	mov    %r13,%rdx
  41c2c3:	mov    %r12,%rsi
  41c2c6:	mov    %rbx,%rdi
  41c2c9:	mov    %rax,%rbx
  41c2cc:	mov    %rsi,%r14
  41c2cf:	mov    %rdi,%r12
  41c2d2:	callq  405380 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  41c2d7:	mov    %r12,%rdi
  41c2da:	mov    %rbx,-0x8a0(%rbp)
  41c2e1:	mov    %rax,-0x898(%rbp)
  41c2e8:	mov    0x1d921(%rip),%rcx        # 439c10 <p111_program+0x58>
  41c2ef:	test   $0x4,%rcx
  41c2f6:	jne    41c313 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x6e3>
  41c2f8:	mov    $0x2,%ecx
  41c2fd:	lea    -0x8a0(%rbp),%rdx
  41c304:	mov    $0x157,%esi
  41c309:	callq  42b480 <p111_rt_jump>
  41c30e:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c313:	mov    %rbx,0x28(%rdi)
  41c317:	mov    %rax,0x30(%rdi)
  41c31b:	movl   $0x0,0x1c(%rdi)
  41c322:	movl   $0x157,0x20(%rdi)
  41c329:	mov    $0x0,%eax
  41c32e:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c333:	mov    %r13,%rbx
  41c336:	mov    %r14,%r13
  41c339:	mov    %rcx,%r14
  41c33c:	mov    %rax,-0x38a0(%rbp)
  41c343:	mov    %r15,-0x3898(%rbp)
  41c34a:	mov    %r14,-0x3890(%rbp)
  41c351:	lea    -0x38a0(%rbp),%rdx
  41c358:	mov    %rsi,%r15
  41c35b:	mov    $0x2d,%esi
  41c360:	mov    %rdi,%r14
  41c363:	callq  430df0 <p125_rt_ctor3>
  41c368:	mov    %r15,%rsi
  41c36b:	mov    %r14,%rdi
  41c36e:	mov    -0x28(%rbp),%r14
  41c372:	mov    %r13,-0x38a0(%rbp)
  41c379:	mov    %rax,-0x3898(%rbp)
  41c380:	mov    0x10(%rdi),%rax
  41c384:	mov    %r13,(%rax)
  41c387:	mov    -0x3898(%rbp),%rcx
  41c38e:	mov    %rcx,0x8(%rax)
  41c392:	movq   $0x174,0x10(%rax)
  41c39a:	add    $0x18,%rax
  41c39e:	mov    %rax,0x10(%rdi)
  41c3a2:	mov    %rsi,%r15
  41c3a5:	mov    %rdi,%r13
  41c3a8:	callq  42ae30 <p111_rt_keep>
  41c3ad:	mov    %r14,%rsi
  41c3b0:	mov    %r13,%rdi
  41c3b3:	mov    %rax,%rdx
  41c3b6:	mov    %rdx,-0x38a0(%rbp)
  41c3bd:	mov    %r12,-0x3898(%rbp)
  41c3c4:	mov    %rbx,-0x3890(%rbp)
  41c3cb:	mov    %rdx,%r13
  41c3ce:	lea    -0x38a0(%rbp),%rdx
  41c3d5:	mov    %rsi,%r12
  41c3d8:	mov    $0x2d,%esi
  41c3dd:	mov    %rdi,%rbx
  41c3e0:	callq  430df0 <p125_rt_ctor3>
  41c3e5:	mov    %r13,%rdx
  41c3e8:	mov    %r12,%rsi
  41c3eb:	mov    %rbx,%rdi
  41c3ee:	mov    %rax,%rbx
  41c3f1:	mov    %rdi,%r12
  41c3f4:	callq  405380 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  41c3f9:	mov    %r12,%rdi
  41c3fc:	mov    %rbx,-0x10a0(%rbp)
  41c403:	mov    %rax,-0x1098(%rbp)
  41c40a:	mov    0x1d7ff(%rip),%rcx        # 439c10 <p111_program+0x58>
  41c411:	test   $0x4,%rcx
  41c418:	jne    41c435 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x805>
  41c41a:	mov    $0x2,%ecx
  41c41f:	lea    -0x10a0(%rbp),%rdx
  41c426:	mov    $0x157,%esi
  41c42b:	callq  42b480 <p111_rt_jump>
  41c430:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c435:	mov    %rbx,0x28(%rdi)
  41c439:	mov    %rax,0x30(%rdi)
  41c43d:	movl   $0x0,0x1c(%rdi)
  41c444:	movl   $0x157,0x20(%rdi)
  41c44b:	mov    $0x0,%eax
  41c450:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c455:	xchg   %rsi,%r15
  41c458:	xchg   %r14,%rsi
  41c45b:	lea    -0x38a0(%rbp),%rdx
  41c462:	mov    %rdi,%r13
  41c465:	callq  430c60 <p125_rt_take2>
  41c46a:	mov    %r15,%rsi
  41c46d:	mov    %r13,%rdi
  41c470:	mov    %rbx,%r13
  41c473:	mov    -0x30(%rbp),%rbx
  41c477:	mov    -0x80(%rbp),%r15
  41c47b:	mov    -0x38a0(%rbp),%rax
  41c482:	mov    %rax,-0x38(%rbp)
  41c486:	mov    -0x3898(%rbp),%rax
  41c48d:	mov    %rax,-0x40(%rbp)
  41c491:	cmp    $0x8,%r15
  41c495:	je     41c545 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x915>
  41c49b:	mov    %rsi,%r15
  41c49e:	mov    %r13,%rsi
  41c4a1:	mov    %rdi,%r13
  41c4a4:	callq  42aec0 <p111_rt_sink>
  41c4a9:	mov    %r15,%rsi
  41c4ac:	mov    %r13,%rdi
  41c4af:	mov    -0x38(%rbp),%r15
  41c4b3:	mov    %rdi,%r13
  41c4b6:	callq  42aec0 <p111_rt_sink>
  41c4bb:	mov    %r14,%rsi
  41c4be:	mov    %r13,%rdi
  41c4c1:	mov    -0x40(%rbp),%r14
  41c4c5:	mov    %rsi,%r13
  41c4c8:	mov    %r12,%rsi
  41c4cb:	mov    %rdi,%r12
  41c4ce:	callq  42aec0 <p111_rt_sink>
  41c4d3:	mov    %r13,%rsi
  41c4d6:	mov    %r12,%rdi
  41c4d9:	mov    %rsi,%r12
  41c4dc:	mov    %rbx,%rsi
  41c4df:	mov    %rdi,%rbx
  41c4e2:	callq  42aec0 <p111_rt_sink>
  41c4e7:	mov    %r12,%rsi
  41c4ea:	mov    %rbx,%rdi
  41c4ed:	mov    %rsi,%r12
  41c4f0:	mov    %r15,%rsi
  41c4f3:	mov    %rdi,%rbx
  41c4f6:	callq  42aec0 <p111_rt_sink>
  41c4fb:	mov    %r12,%rsi
  41c4fe:	mov    %rbx,%rdi
  41c501:	mov    %r14,%rax
  41c504:	mov    %rsi,%r12
  41c507:	mov    %rax,%rsi
  41c50a:	mov    %rdi,%rbx
  41c50d:	callq  42aec0 <p111_rt_sink>
  41c512:	mov    %r12,%rsi
  41c515:	mov    %rbx,%rdi
  41c518:	mov    %rsi,-0x38a0(%rbp)
  41c51f:	mov    0x10(%rdi),%rax
  41c523:	mov    %rsi,(%rax)
  41c526:	movq   $0x173,0x8(%rax)
  41c52e:	add    $0x10,%rax
  41c532:	mov    %rax,0x10(%rdi)
  41c536:	mov    $0x4,%esi
  41c53b:	callq  42b650 <p111_rt_fail>
  41c540:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c545:	mov    %rsi,%r15
  41c548:	mov    %r14,%rsi
  41c54b:	mov    %r13,%r14
  41c54e:	lea    -0x38a0(%rbp),%rdx
  41c555:	mov    %rdi,%r13
  41c558:	callq  430c60 <p125_rt_take2>
  41c55d:	mov    %r15,%rsi
  41c560:	mov    %r13,%rdi
  41c563:	mov    -0x40(%rbp),%rax
  41c567:	mov    -0x38(%rbp),%r15
  41c56b:	mov    -0x38a0(%rbp),%rcx
  41c572:	mov    %rcx,-0x48(%rbp)
  41c576:	mov    %rbx,%r13
  41c579:	mov    -0x3898(%rbp),%rbx
  41c580:	cmp    $0x1,%rbx
  41c584:	sete   %dl
  41c587:	movzbl %dl,%edx
  41c58a:	mov    %rbx,%r8
  41c58d:	shr    $0x28,%r8
  41c591:	and    $0x7fffff,%r8
  41c598:	cmp    $0x10002,%r8
  41c59f:	sete   %r8b
  41c5a3:	movzbl %r8b,%r8d
  41c5a7:	mov    %edx,%r9d
  41c5aa:	or     %r8d,%r9d
  41c5ad:	xor    $0x1,%r9d
  41c5b1:	jne    41c7fa <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xbca>
  41c5b7:	or     %r8d,%edx
  41c5ba:	nopw   0x0(%rax,%rax,1)
  41c5c0:	jne    41c679 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xa49>
  41c5c6:	mov    %rsi,%r15
  41c5c9:	mov    %r14,%rsi
  41c5cc:	mov    %rdi,%r14
  41c5cf:	callq  42aec0 <p111_rt_sink>
  41c5d4:	mov    %r15,%rsi
  41c5d7:	mov    %r14,%rdi
  41c5da:	mov    %r12,%r15
  41c5dd:	mov    -0x38(%rbp),%r12
  41c5e1:	mov    %rsi,%rax
  41c5e4:	mov    %rdi,%r14
  41c5e7:	callq  42aec0 <p111_rt_sink>
  41c5ec:	mov    %r14,%rdi
  41c5ef:	mov    -0x40(%rbp),%r14
  41c5f3:	mov    %r15,%rsi
  41c5f6:	mov    %rdi,%r15
  41c5f9:	callq  42aec0 <p111_rt_sink>
  41c5fe:	mov    %r15,%rdi
  41c601:	mov    -0x48(%rbp),%rsi
  41c605:	mov    %rsi,%r15
  41c608:	mov    %r13,%rsi
  41c60b:	mov    %rdi,%r13
  41c60e:	callq  42aec0 <p111_rt_sink>
  41c613:	mov    %r15,%rsi
  41c616:	mov    %r13,%rdi
  41c619:	mov    %rsi,%r13
  41c61c:	mov    %r12,%rsi
  41c61f:	mov    %rdi,%r12
  41c622:	callq  42aec0 <p111_rt_sink>
  41c627:	mov    %r13,%rsi
  41c62a:	mov    %r12,%rdi
  41c62d:	mov    %rsi,%r13
  41c630:	mov    %r14,%rsi
  41c633:	mov    %rdi,%r12
  41c636:	callq  42aec0 <p111_rt_sink>
  41c63b:	mov    %r13,%rsi
  41c63e:	mov    %r12,%rdi
  41c641:	mov    %rdi,%r12
  41c644:	callq  42aec0 <p111_rt_sink>
  41c649:	mov    %r12,%rdi
  41c64c:	mov    %rbx,-0x38a0(%rbp)
  41c653:	mov    0x10(%rdi),%rax
  41c657:	mov    %rbx,(%rax)
  41c65a:	movq   $0x172,0x8(%rax)
  41c662:	add    $0x10,%rax
  41c666:	mov    %rax,0x10(%rdi)
  41c66a:	mov    $0x4,%esi
  41c66f:	callq  42b650 <p111_rt_fail>
  41c674:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c679:	mov    %r13,%rbx
  41c67c:	xchg   %r15,%r12
  41c67f:	mov    %r14,%r13
  41c682:	mov    %rax,%r14
  41c685:	mov    %rsi,%rax
  41c688:	mov    %rcx,%rsi
  41c68b:	mov    %rax,-0x38a0(%rbp)
  41c692:	mov    %r15,-0x3898(%rbp)
  41c699:	mov    %rbx,-0x3890(%rbp)
  41c6a0:	lea    -0x38a0(%rbp),%rdx
  41c6a7:	mov    %rsi,%r15
  41c6aa:	mov    $0x2d,%esi
  41c6af:	mov    %rdi,%rbx
  41c6b2:	callq  430df0 <p125_rt_ctor3>
  41c6b7:	mov    %r15,%rsi
  41c6ba:	mov    %rbx,%rdi
  41c6bd:	mov    %rax,%rbx
  41c6c0:	mov    %rsi,%r15
  41c6c3:	mov    %r12,%rsi
  41c6c6:	mov    %rdi,%r12
  41c6c9:	callq  42ae30 <p111_rt_keep>
  41c6ce:	mov    %r15,%rsi
  41c6d1:	mov    %r12,%rdi
  41c6d4:	mov    %rax,%r12
  41c6d7:	mov    %r12,-0x38a0(%rbp)
  41c6de:	mov    %r14,-0x3898(%rbp)
  41c6e5:	lea    -0x38a0(%rbp),%rdx
  41c6ec:	mov    %rsi,%r15
  41c6ef:	mov    $0x2c,%esi
  41c6f4:	mov    %rdi,%r14
  41c6f7:	callq  430b70 <p125_rt_ctor2>
  41c6fc:	mov    %r15,%rsi
  41c6ff:	mov    %r14,%rdi
  41c702:	mov    %r13,-0x38a0(%rbp)
  41c709:	mov    %rbx,-0x3898(%rbp)
  41c710:	mov    %rax,-0x3890(%rbp)
  41c717:	lea    -0x38a0(%rbp),%rdx
  41c71e:	mov    %rsi,%r13
  41c721:	mov    $0x2d,%esi
  41c726:	mov    %rdi,%rbx
  41c729:	callq  430df0 <p125_rt_ctor3>
  41c72e:	mov    %r13,%rsi
  41c731:	mov    %rbx,%rdi
  41c734:	mov    %rax,%rbx
  41c737:	mov    %r12,-0x38a0(%rbp)
  41c73e:	lea    -0x38a0(%rbp),%rdx
  41c745:	mov    %rsi,%r14
  41c748:	mov    $0xc,%esi
  41c74d:	mov    %rdi,%r12
  41c750:	callq  430940 <p125_rt_ctor1>
  41c755:	mov    %r12,%rdi
  41c758:	mov    %r14,-0x38a0(%rbp)
  41c75f:	mov    %rax,-0x3898(%rbp)
  41c766:	lea    -0x38a0(%rbp),%rdx
  41c76d:	mov    $0x8,%esi
  41c772:	mov    %rdi,%r12
  41c775:	callq  430b70 <p125_rt_ctor2>
  41c77a:	mov    %r12,%rdi
  41c77d:	mov    %rbx,-0x38a0(%rbp)
  41c784:	mov    %rax,-0x3898(%rbp)
  41c78b:	lea    -0x38a0(%rbp),%rdx
  41c792:	mov    $0x8,%esi
  41c797:	mov    %rdi,%rbx
  41c79a:	callq  430b70 <p125_rt_ctor2>
  41c79f:	mov    %rbx,%rdi
  41c7a2:	mov    %rax,-0x38a0(%rbp)
  41c7a9:	mov    0x1d460(%rip),%rcx        # 439c10 <p111_program+0x58>
  41c7b0:	test   $0x4,%rcx
  41c7b7:	jne    41c7cf <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xb9f>
  41c7b9:	mov    $0x1,%edx
  41c7be:	lea    -0x38a0(%rbp),%rsi
  41c7c5:	callq  42b4e0 <p111_rt_return>
  41c7ca:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c7cf:	mov    %rax,0x28(%rdi)
  41c7d3:	movl   $0x1,0x1c(%rdi)
  41c7da:	mov    0x10(%rdi),%rax
  41c7de:	mov    %rax,%rcx
  41c7e1:	add    $0xfffffffffffffff8,%rcx
  41c7e5:	mov    %rcx,0x10(%rdi)
  41c7e9:	mov    -0x8(%rax),%rax
  41c7ed:	mov    %eax,0x20(%rdi)
  41c7f0:	mov    $0x0,%eax
  41c7f5:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c7fa:	mov    %r13,%rbx
  41c7fd:	mov    %r14,%r13
  41c800:	mov    %rax,%r14
  41c803:	mov    %r15,-0x38a0(%rbp)
  41c80a:	mov    %r14,-0x3898(%rbp)
  41c811:	lea    -0x38a0(%rbp),%rdx
  41c818:	mov    %rsi,%r15
  41c81b:	mov    $0x2c,%esi
  41c820:	mov    %rdi,%r14
  41c823:	callq  430b70 <p125_rt_ctor2>
  41c828:	mov    %r15,%rsi
  41c82b:	mov    %r14,%rdi
  41c82e:	mov    -0x48(%rbp),%r14
  41c832:	mov    %r13,-0x38a0(%rbp)
  41c839:	mov    %rax,-0x3898(%rbp)
  41c840:	mov    0x10(%rdi),%rax
  41c844:	mov    %r13,(%rax)
  41c847:	mov    -0x3898(%rbp),%rcx
  41c84e:	mov    %rcx,0x8(%rax)
  41c852:	movq   $0x170,0x10(%rax)
  41c85a:	add    $0x18,%rax
  41c85e:	mov    %rax,0x10(%rdi)
  41c862:	mov    %rdi,%r13
  41c865:	callq  42ae30 <p111_rt_keep>
  41c86a:	mov    %r14,%rsi
  41c86d:	mov    %r13,%rdi
  41c870:	mov    %rax,%rdx
  41c873:	mov    %rdx,-0x38a0(%rbp)
  41c87a:	mov    %r12,-0x3898(%rbp)
  41c881:	mov    %rbx,-0x3890(%rbp)
  41c888:	mov    %rdx,%r13
  41c88b:	lea    -0x38a0(%rbp),%rdx
  41c892:	mov    %rsi,%r12
  41c895:	mov    $0x2d,%esi
  41c89a:	mov    %rdi,%rbx
  41c89d:	callq  430df0 <p125_rt_ctor3>
  41c8a2:	mov    %r13,%rdx
  41c8a5:	mov    %r12,%rsi
  41c8a8:	mov    %rbx,%rdi
  41c8ab:	mov    %rax,%rbx
  41c8ae:	mov    %rdi,%r12
  41c8b1:	callq  405380 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  41c8b6:	mov    %r12,%rdi
  41c8b9:	mov    %rbx,-0x18a0(%rbp)
  41c8c0:	mov    %rax,-0x1898(%rbp)
  41c8c7:	mov    0x1d342(%rip),%rcx        # 439c10 <p111_program+0x58>
  41c8ce:	test   $0x4,%rcx
  41c8d5:	jne    41c8f2 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xcc2>
  41c8d7:	mov    $0x2,%ecx
  41c8dc:	lea    -0x18a0(%rbp),%rdx
  41c8e3:	mov    $0x157,%esi
  41c8e8:	callq  42b480 <p111_rt_jump>
  41c8ed:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c8f2:	mov    %rbx,0x28(%rdi)
  41c8f6:	mov    %rax,0x30(%rdi)
  41c8fa:	movl   $0x0,0x1c(%rdi)
  41c901:	movl   $0x157,0x20(%rdi)
  41c908:	mov    $0x0,%eax
  41c90d:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c912:	cs cs cs cs xchg %r13,%rbx
  41c919:	cs mov %r15,%r14
  41c91d:	mov    %rcx,%r15
  41c920:	cmp    $0x8,%r15
  41c924:	je     41c9a5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xd75>
  41c926:	cs cs cs cs mov %rsi,%r15
  41c92d:	cs mov %r13,%rsi
  41c931:	mov    %rdi,%r13
  41c934:	callq  42aec0 <p111_rt_sink>
  41c939:	mov    %r15,%rsi
  41c93c:	mov    %r13,%rdi
  41c93f:	mov    %rsi,%r15
  41c942:	mov    %rdi,%r13
  41c945:	callq  42aec0 <p111_rt_sink>
  41c94a:	mov    %r14,%rsi
  41c94d:	mov    %r13,%rdi
  41c950:	mov    %rsi,%r13
  41c953:	mov    %r12,%rsi
  41c956:	mov    %rdi,%r12
  41c959:	callq  42aec0 <p111_rt_sink>
  41c95e:	mov    %r13,%rsi
  41c961:	mov    %r12,%rdi
  41c964:	mov    %rsi,%r12
  41c967:	mov    %rbx,%rsi
  41c96a:	mov    %rdi,%rbx
  41c96d:	callq  42aec0 <p111_rt_sink>
  41c972:	mov    %r12,%rsi
  41c975:	mov    %rbx,%rdi
  41c978:	mov    %rsi,-0x38a0(%rbp)
  41c97f:	mov    0x10(%rdi),%rax
  41c983:	mov    %rsi,(%rax)
  41c986:	movq   $0x16f,0x8(%rax)
  41c98e:	add    $0x10,%rax
  41c992:	mov    %rax,0x10(%rdi)
  41c996:	mov    $0x4,%esi
  41c99b:	callq  42b650 <p111_rt_fail>
  41c9a0:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41c9a5:	mov    %rsi,%r15
  41c9a8:	mov    %r14,%rsi
  41c9ab:	mov    %r13,%r14
  41c9ae:	mov    %r12,%r13
  41c9b1:	lea    -0x38a0(%rbp),%rdx
  41c9b8:	mov    %rdi,%r12
  41c9bb:	callq  430c60 <p125_rt_take2>
  41c9c0:	mov    %r15,%rsi
  41c9c3:	mov    %r12,%rdi
  41c9c6:	mov    -0x38a0(%rbp),%r15
  41c9cd:	mov    %r15,-0x50(%rbp)
  41c9d1:	mov    %rbx,%r12
  41c9d4:	mov    -0x3898(%rbp),%rbx
  41c9db:	cmp    $0x1,%rbx
  41c9df:	sete   %al
  41c9e2:	movzbl %al,%eax
  41c9e5:	mov    %rbx,%rcx
  41c9e8:	shr    $0x28,%rcx
  41c9ec:	and    $0x7fffff,%rcx
  41c9f3:	cmp    $0x10002,%rcx
  41c9fa:	sete   %cl
  41c9fd:	movzbl %cl,%ecx
  41ca00:	mov    %eax,%edx
  41ca02:	or     %ecx,%edx
  41ca04:	xor    $0x1,%edx
  41ca07:	jne    41cbca <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf9a>
  41ca0d:	or     %ecx,%eax
  41ca0f:	jne    41ca9e <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xe6e>
  41ca15:	mov    %rsi,%r15
  41ca18:	mov    %r14,%rsi
  41ca1b:	mov    %rdi,%r14
  41ca1e:	callq  42aec0 <p111_rt_sink>
  41ca23:	mov    %r15,%rsi
  41ca26:	mov    %r14,%rdi
  41ca29:	mov    -0x50(%rbp),%r15
  41ca2d:	mov    %rsi,%r14
  41ca30:	mov    %rdi,%r14
  41ca33:	callq  42aec0 <p111_rt_sink>
  41ca38:	mov    %r15,%rsi
  41ca3b:	mov    %r14,%rdi
  41ca3e:	mov    %rsi,%r14
  41ca41:	mov    %r13,%rsi
  41ca44:	mov    %rdi,%r13
  41ca47:	callq  42aec0 <p111_rt_sink>
  41ca4c:	mov    %r14,%rsi
  41ca4f:	mov    %r13,%rdi
  41ca52:	mov    %rsi,%r13
  41ca55:	mov    %r12,%rsi
  41ca58:	mov    %rdi,%r12
  41ca5b:	callq  42aec0 <p111_rt_sink>
  41ca60:	mov    %r13,%rsi
  41ca63:	mov    %r12,%rdi
  41ca66:	mov    %rdi,%r12
  41ca69:	callq  42aec0 <p111_rt_sink>
  41ca6e:	mov    %r12,%rdi
  41ca71:	mov    %rbx,-0x38a0(%rbp)
  41ca78:	mov    0x10(%rdi),%rax
  41ca7c:	mov    %rbx,(%rax)
  41ca7f:	movq   $0x16e,0x8(%rax)
  41ca87:	add    $0x10,%rax
  41ca8b:	mov    %rax,0x10(%rdi)
  41ca8f:	mov    $0x4,%esi
  41ca94:	callq  42b650 <p111_rt_fail>
  41ca99:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41ca9e:	cs cs cs mov %r12,%rbx
  41caa4:	mov    %r13,%r12
  41caa7:	mov    %r14,%r13
  41caaa:	mov    %rsi,%r14
  41caad:	mov    %r15,%rsi
  41cab0:	mov    %r14,-0x38a0(%rbp)
  41cab7:	mov    %r12,-0x3898(%rbp)
  41cabe:	mov    %rbx,-0x3890(%rbp)
  41cac5:	lea    -0x38a0(%rbp),%rdx
  41cacc:	mov    %rsi,%r12
  41cacf:	mov    $0x2d,%esi
  41cad4:	mov    %rdi,%rbx
  41cad7:	callq  430df0 <p125_rt_ctor3>
  41cadc:	mov    %r12,%rsi
  41cadf:	mov    %rbx,%rdi
  41cae2:	mov    %r13,-0x38a0(%rbp)
  41cae9:	mov    %rax,-0x3898(%rbp)
  41caf0:	movabs $0x1002b0000000000,%rax
  41cafa:	mov    %rax,-0x3890(%rbp)
  41cb01:	lea    -0x38a0(%rbp),%rdx
  41cb08:	mov    %rsi,%r14
  41cb0b:	mov    $0x2d,%esi
  41cb10:	mov    %rdi,%rbx
  41cb13:	callq  430df0 <p125_rt_ctor3>
  41cb18:	mov    %rbx,%rdi
  41cb1b:	mov    %rax,%rbx
  41cb1e:	mov    %r14,-0x38a0(%rbp)
  41cb25:	movabs $0x1000b0000000000,%rax
  41cb2f:	mov    %rax,-0x3898(%rbp)
  41cb36:	lea    -0x38a0(%rbp),%rdx
  41cb3d:	mov    $0x8,%esi
  41cb42:	mov    %rdi,%r12
  41cb45:	callq  430b70 <p125_rt_ctor2>
  41cb4a:	mov    %r12,%rdi
  41cb4d:	mov    %rbx,-0x38a0(%rbp)
  41cb54:	mov    %rax,-0x3898(%rbp)
  41cb5b:	lea    -0x38a0(%rbp),%rdx
  41cb62:	mov    $0x8,%esi
  41cb67:	mov    %rdi,%rbx
  41cb6a:	callq  430b70 <p125_rt_ctor2>
  41cb6f:	mov    %rbx,%rdi
  41cb72:	mov    %rax,-0x38a0(%rbp)
  41cb79:	mov    0x1d090(%rip),%rcx        # 439c10 <p111_program+0x58>
  41cb80:	test   $0x4,%rcx
  41cb87:	jne    41cb9f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0xf6f>
  41cb89:	mov    $0x1,%edx
  41cb8e:	lea    -0x38a0(%rbp),%rsi
  41cb95:	callq  42b4e0 <p111_rt_return>
  41cb9a:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41cb9f:	mov    %rax,0x28(%rdi)
  41cba3:	movl   $0x1,0x1c(%rdi)
  41cbaa:	mov    0x10(%rdi),%rax
  41cbae:	mov    %rax,%rcx
  41cbb1:	add    $0xfffffffffffffff8,%rcx
  41cbb5:	mov    %rcx,0x10(%rdi)
  41cbb9:	mov    -0x8(%rax),%rax
  41cbbd:	mov    %eax,0x20(%rdi)
  41cbc0:	mov    $0x0,%eax
  41cbc5:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41cbca:	cs cs cs cs mov %r12,%rbx
  41cbd1:	mov    %r13,%r12
  41cbd4:	mov    %r14,%r13
  41cbd7:	mov    %r15,%r14
  41cbda:	mov    %r13,-0x38a0(%rbp)
  41cbe1:	movabs $0x1002b0000000000,%rax
  41cbeb:	mov    %rax,-0x3898(%rbp)
  41cbf2:	mov    0x10(%rdi),%rax
  41cbf6:	mov    %r13,(%rax)
  41cbf9:	mov    -0x3898(%rbp),%rcx
  41cc00:	mov    %rcx,0x8(%rax)
  41cc04:	movq   $0x16c,0x10(%rax)
  41cc0c:	add    $0x18,%rax
  41cc10:	mov    %rax,0x10(%rdi)
  41cc14:	mov    %rdi,%r13
  41cc17:	callq  42ae30 <p111_rt_keep>
  41cc1c:	mov    %r14,%rsi
  41cc1f:	mov    %r13,%rdi
  41cc22:	mov    %rax,%rdx
  41cc25:	mov    %rdx,-0x38a0(%rbp)
  41cc2c:	mov    %r12,-0x3898(%rbp)
  41cc33:	mov    %rbx,-0x3890(%rbp)
  41cc3a:	mov    %rdx,%r13
  41cc3d:	lea    -0x38a0(%rbp),%rdx
  41cc44:	mov    %rsi,%r12
  41cc47:	mov    $0x2d,%esi
  41cc4c:	mov    %rdi,%rbx
  41cc4f:	callq  430df0 <p125_rt_ctor3>
  41cc54:	mov    %r13,%rdx
  41cc57:	mov    %r12,%rsi
  41cc5a:	mov    %rbx,%rdi
  41cc5d:	mov    %rax,%rbx
  41cc60:	mov    %rdi,%r12
  41cc63:	callq  405380 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  41cc68:	mov    %r12,%rdi
  41cc6b:	mov    %rbx,-0x20a0(%rbp)
  41cc72:	mov    %rax,-0x2098(%rbp)
  41cc79:	mov    0x1cf90(%rip),%rcx        # 439c10 <p111_program+0x58>
  41cc80:	test   $0x4,%rcx
  41cc87:	jne    41cca5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1075>
  41cc89:	cs mov $0x2,%ecx
  41cc8f:	lea    -0x20a0(%rbp),%rdx
  41cc96:	mov    $0x157,%esi
  41cc9b:	callq  42b480 <p111_rt_jump>
  41cca0:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41cca5:	mov    %rbx,0x28(%rdi)
  41cca9:	mov    %rax,0x30(%rdi)
  41ccad:	movl   $0x0,0x1c(%rdi)
  41ccb4:	movl   $0x157,0x20(%rdi)
  41ccbb:	mov    $0x0,%eax
  41ccc0:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41ccc5:	mov    %r12,%r13
  41ccc8:	lea    -0x38a0(%rbp),%rdx
  41cccf:	mov    %rdi,%r12
  41ccd2:	callq  430c60 <p125_rt_take2>
  41ccd7:	mov    %r14,%rsi
  41ccda:	mov    %r12,%rdi
  41ccdd:	mov    -0x58(%rbp),%rax
  41cce1:	mov    %rsi,%r12
  41cce4:	mov    -0x38a0(%rbp),%rsi
  41cceb:	mov    -0x3898(%rbp),%r14
  41ccf2:	cmp    $0x2b,%rax
  41ccf6:	je     41d6f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ac4>
  41ccfc:	nopl   0x0(%rax)
  41cd00:	cmp    $0x2c,%rax
  41cd04:	je     41d23d <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x160d>
  41cd0a:	cmp    $0x2d,%rax
  41cd0e:	je     41cd98 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1168>
  41cd14:	mov    %rsi,%r13
  41cd17:	mov    %rbx,%rsi
  41cd1a:	mov    %rdi,%rbx
  41cd1d:	callq  42aec0 <p111_rt_sink>
  41cd22:	mov    %r13,%rsi
  41cd25:	mov    %rbx,%rdi
  41cd28:	mov    %rsi,%r13
  41cd2b:	mov    %rdi,%rbx
  41cd2e:	callq  42aec0 <p111_rt_sink>
  41cd33:	mov    %r12,%rsi
  41cd36:	mov    %rbx,%rdi
  41cd39:	mov    %rsi,%r12
  41cd3c:	mov    %r14,%rsi
  41cd3f:	mov    %rdi,%rbx
  41cd42:	callq  42aec0 <p111_rt_sink>
  41cd47:	mov    %r12,%rsi
  41cd4a:	mov    %rbx,%rdi
  41cd4d:	mov    %r15,-0x38a0(%rbp)
  41cd54:	mov    0x10(%rdi),%rax
  41cd58:	mov    %r15,(%rax)
  41cd5b:	movq   $0x16a,0x8(%rax)
  41cd63:	add    $0x10,%rax
  41cd67:	mov    %rax,0x10(%rdi)
  41cd6b:	mov    %rsi,-0x38a0(%rbp)
  41cd72:	mov    0x10(%rdi),%rax
  41cd76:	mov    %rsi,(%rax)
  41cd79:	movq   $0x16b,0x8(%rax)
  41cd81:	add    $0x10,%rax
  41cd85:	mov    %rax,0x10(%rdi)
  41cd89:	mov    $0x4,%esi
  41cd8e:	callq  42b650 <p111_rt_fail>
  41cd93:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41cd98:	cs cs cs cs mov %rsi,%r13
  41cd9f:	cs cs cs cs mov %r12,%rsi
  41cda6:	lea    %cs:-0x38a0(%rbp),%rdx
  41cdae:	mov    %rdi,%r12
  41cdb1:	callq  430ec0 <p125_rt_take3>
  41cdb6:	mov    %r13,%rsi
  41cdb9:	mov    %r12,%rdi
  41cdbc:	mov    -0x80(%rbp),%r13
  41cdc0:	mov    %r14,%r12
  41cdc3:	mov    -0x38a0(%rbp),%r14
  41cdca:	mov    -0x3898(%rbp),%rax
  41cdd1:	mov    %rax,-0x60(%rbp)
  41cdd5:	mov    -0x3890(%rbp),%rax
  41cddc:	mov    %rax,-0x68(%rbp)
  41cde0:	cmp    $0x8,%r13
  41cde4:	je     41ce97 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1267>
  41cdea:	mov    %rsi,%r13
  41cded:	mov    %rbx,%rsi
  41cdf0:	mov    %rdi,%rbx
  41cdf3:	callq  42aec0 <p111_rt_sink>
  41cdf8:	mov    %r13,%rsi
  41cdfb:	mov    %rbx,%rdi
  41cdfe:	mov    -0x60(%rbp),%rbx
  41ce02:	mov    %rdi,%r13
  41ce05:	callq  42aec0 <p111_rt_sink>
  41ce0a:	mov    %r15,%rsi
  41ce0d:	mov    %r13,%rdi
  41ce10:	mov    -0x68(%rbp),%r15
  41ce14:	mov    %rsi,%r13
  41ce17:	mov    %r12,%rsi
  41ce1a:	mov    %rdi,%r12
  41ce1d:	callq  42aec0 <p111_rt_sink>
  41ce22:	mov    %r14,%rcx
  41ce25:	mov    %r13,%rsi
  41ce28:	mov    %r12,%rdi
  41ce2b:	mov    %rsi,%r13
  41ce2e:	mov    %rcx,%rsi
  41ce31:	mov    %rdi,%r12
  41ce34:	callq  42aec0 <p111_rt_sink>
  41ce39:	mov    %r13,%rsi
  41ce3c:	mov    %r12,%rdi
  41ce3f:	mov    %rbx,%rax
  41ce42:	mov    %rsi,%r12
  41ce45:	mov    %rax,%rsi
  41ce48:	mov    %rdi,%rbx
  41ce4b:	callq  42aec0 <p111_rt_sink>
  41ce50:	mov    %r12,%rsi
  41ce53:	mov    %rbx,%rdi
  41ce56:	mov    %rsi,%r12
  41ce59:	mov    %r15,%rsi
  41ce5c:	mov    %rdi,%rbx
  41ce5f:	callq  42aec0 <p111_rt_sink>
  41ce64:	mov    %r12,%rsi
  41ce67:	mov    %rbx,%rdi
  41ce6a:	mov    %rsi,-0x38a0(%rbp)
  41ce71:	mov    0x10(%rdi),%rax
  41ce75:	mov    %rsi,(%rax)
  41ce78:	movq   $0x169,0x8(%rax)
  41ce80:	add    $0x10,%rax
  41ce84:	mov    %rax,0x10(%rdi)
  41ce88:	mov    $0x4,%esi
  41ce8d:	callq  42b650 <p111_rt_fail>
  41ce92:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41ce97:	xchg   %r14,%r15
  41ce9a:	xchg   %rsi,%r14
  41ce9d:	lea    -0x38a0(%rbp),%rdx
  41cea4:	mov    %rsi,%r13
  41cea7:	mov    %rdi,%r13
  41ceaa:	callq  430c60 <p125_rt_take2>
  41ceaf:	mov    %r15,%rcx
  41ceb2:	mov    %r14,%rsi
  41ceb5:	mov    %r13,%rdi
  41ceb8:	mov    -0x68(%rbp),%r15
  41cebc:	mov    -0x60(%rbp),%rax
  41cec0:	mov    -0x38a0(%rbp),%r13
  41cec7:	mov    %r13,-0x78(%rbp)
  41cecb:	mov    %rbx,%r13
  41cece:	mov    -0x3898(%rbp),%rbx
  41ced5:	cmp    $0x1,%rbx
  41ced9:	mov    %rcx,%r14
  41cedc:	sete   %cl
  41cedf:	movzbl %cl,%ecx
  41cee2:	mov    %rbx,%rdx
  41cee5:	shr    $0x28,%rdx
  41cee9:	and    $0x7fffff,%rdx
  41cef0:	cmp    $0x10002,%rdx
  41cef7:	sete   %dl
  41cefa:	movzbl %dl,%edx
  41cefd:	mov    %ecx,%r8d
  41cf00:	or     %edx,%r8d
  41cf03:	xor    $0x1,%r8d
  41cf07:	jne    41d0d4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x14a4>
  41cf0d:	or     %edx,%ecx
  41cf0f:	jne    41cfb9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1389>
  41cf15:	mov    %rsi,%r15
  41cf18:	mov    %r13,%rsi
  41cf1b:	mov    %rdi,%r13
  41cf1e:	callq  42aec0 <p111_rt_sink>
  41cf23:	mov    %r15,%rsi
  41cf26:	mov    %r13,%rdi
  41cf29:	mov    -0x60(%rbp),%r13
  41cf2d:	mov    %rdi,%r15
  41cf30:	callq  42aec0 <p111_rt_sink>
  41cf35:	mov    %r15,%rdi
  41cf38:	mov    -0x68(%rbp),%r15
  41cf3c:	mov    %r12,%rsi
  41cf3f:	mov    %rdi,%r12
  41cf42:	callq  42aec0 <p111_rt_sink>
  41cf47:	mov    %r14,%rcx
  41cf4a:	mov    %r12,%rdi
  41cf4d:	mov    -0x78(%rbp),%r12
  41cf51:	mov    %rcx,%rsi
  41cf54:	mov    %rdi,%r14
  41cf57:	callq  42aec0 <p111_rt_sink>
  41cf5c:	mov    %r14,%rdi
  41cf5f:	mov    %r13,%rax
  41cf62:	mov    %rax,%rsi
  41cf65:	mov    %rdi,%r13
  41cf68:	callq  42aec0 <p111_rt_sink>
  41cf6d:	mov    %r13,%rdi
  41cf70:	mov    %r15,%rsi
  41cf73:	mov    %rdi,%r13
  41cf76:	callq  42aec0 <p111_rt_sink>
  41cf7b:	mov    %r13,%rdi
  41cf7e:	mov    %r12,%rsi
  41cf81:	mov    %rdi,%r12
  41cf84:	callq  42aec0 <p111_rt_sink>
  41cf89:	mov    %r12,%rdi
  41cf8c:	mov    %rbx,-0x38a0(%rbp)
  41cf93:	mov    0x10(%rdi),%rax
  41cf97:	mov    %rbx,(%rax)
  41cf9a:	movq   $0x168,0x8(%rax)
  41cfa2:	add    $0x10,%rax
  41cfa6:	mov    %rax,0x10(%rdi)
  41cfaa:	mov    $0x4,%esi
  41cfaf:	callq  42b650 <p111_rt_fail>
  41cfb4:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41cfb9:	mov    %rax,%rbx
  41cfbc:	xchg   %r14,%r13
  41cfbf:	mov    %rsi,-0x38a0(%rbp)
  41cfc6:	mov    %r12,-0x3898(%rbp)
  41cfcd:	lea    -0x38a0(%rbp),%rdx
  41cfd4:	mov    $0x2c,%esi
  41cfd9:	mov    %rdi,%r12
  41cfdc:	callq  430b70 <p125_rt_ctor2>
  41cfe1:	mov    %r13,%rcx
  41cfe4:	mov    %r12,%rdi
  41cfe7:	mov    %rax,%rdx
  41cfea:	mov    %rbx,%rax
  41cfed:	mov    -0x78(%rbp),%r12
  41cff1:	mov    %r14,-0x38a0(%rbp)
  41cff8:	mov    %rdx,-0x3898(%rbp)
  41cfff:	mov    %rax,%rbx
  41d002:	mov    0x10(%rdi),%rax
  41d006:	mov    %r14,(%rax)
  41d009:	mov    %rcx,%r13
  41d00c:	mov    -0x3898(%rbp),%rcx
  41d013:	mov    %rcx,0x8(%rax)
  41d017:	movq   $0x166,0x10(%rax)
  41d01f:	add    $0x18,%rax
  41d023:	mov    %rax,0x10(%rdi)
  41d027:	mov    %r13,%rsi
  41d02a:	mov    %rdi,%r13
  41d02d:	callq  42ae30 <p111_rt_keep>
  41d032:	mov    %r13,%rdi
  41d035:	mov    %rax,%rdx
  41d038:	mov    %rdx,-0x38a0(%rbp)
  41d03f:	mov    %rbx,-0x3898(%rbp)
  41d046:	mov    %r15,-0x3890(%rbp)
  41d04d:	mov    %rdx,%r13
  41d050:	lea    -0x38a0(%rbp),%rdx
  41d057:	mov    $0x2d,%esi
  41d05c:	mov    %rdi,%rbx
  41d05f:	callq  430df0 <p125_rt_ctor3>
  41d064:	mov    %r13,%rdx
  41d067:	mov    %rbx,%rdi
  41d06a:	mov    %rax,%rbx
  41d06d:	mov    %r12,%rsi
  41d070:	mov    %rdi,%r12
  41d073:	callq  405380 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  41d078:	mov    %r12,%rdi
  41d07b:	mov    %rbx,-0x28a0(%rbp)
  41d082:	mov    %rax,-0x2898(%rbp)
  41d089:	mov    0x1cb80(%rip),%rcx        # 439c10 <p111_program+0x58>
  41d090:	test   $0x4,%rcx
  41d097:	jne    41d0b4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1484>
  41d099:	mov    $0x2,%ecx
  41d09e:	lea    -0x28a0(%rbp),%rdx
  41d0a5:	mov    $0x157,%esi
  41d0aa:	callq  42b480 <p111_rt_jump>
  41d0af:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d0b4:	mov    %rbx,0x28(%rdi)
  41d0b8:	mov    %rax,0x30(%rdi)
  41d0bc:	movl   $0x0,0x1c(%rdi)
  41d0c3:	movl   $0x157,0x20(%rdi)
  41d0ca:	mov    $0x0,%eax
  41d0cf:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d0d4:	mov    %rax,%rbx
  41d0d7:	xchg   %r14,%r13
  41d0da:	mov    %rsi,%r15
  41d0dd:	mov    %rdi,%r15
  41d0e0:	callq  42ae30 <p111_rt_keep>
  41d0e5:	mov    %r15,%rdi
  41d0e8:	mov    -0x68(%rbp),%r15
  41d0ec:	mov    %rax,-0x70(%rbp)
  41d0f0:	mov    %rax,-0x38a0(%rbp)
  41d0f7:	mov    %r12,-0x3898(%rbp)
  41d0fe:	lea    -0x38a0(%rbp),%rdx
  41d105:	mov    $0x2c,%esi
  41d10a:	mov    %rdi,%r12
  41d10d:	callq  430b70 <p125_rt_ctor2>
  41d112:	mov    %r13,%rcx
  41d115:	mov    %r12,%rdi
  41d118:	xchg   %rax,%rbx
  41d11a:	mov    -0x78(%rbp),%r12
  41d11e:	mov    -0x70(%rbp),%r13
  41d122:	mov    %rcx,-0x38a0(%rbp)
  41d129:	mov    %rax,-0x3898(%rbp)
  41d130:	mov    %r15,-0x3890(%rbp)
  41d137:	lea    -0x38a0(%rbp),%rdx
  41d13e:	mov    $0x2d,%esi
  41d143:	mov    %rdi,%r15
  41d146:	callq  430df0 <p125_rt_ctor3>
  41d14b:	mov    %r15,%rdi
  41d14e:	mov    %r14,-0x38a0(%rbp)
  41d155:	mov    %rbx,-0x3898(%rbp)
  41d15c:	mov    %rax,-0x3890(%rbp)
  41d163:	lea    -0x38a0(%rbp),%rdx
  41d16a:	mov    $0x2d,%esi
  41d16f:	mov    %rdi,%rbx
  41d172:	callq  430df0 <p125_rt_ctor3>
  41d177:	mov    %rbx,%rdi
  41d17a:	mov    %rax,%rbx
  41d17d:	mov    %r13,-0x38a0(%rbp)
  41d184:	lea    -0x38a0(%rbp),%rdx
  41d18b:	mov    $0xc,%esi
  41d190:	mov    %rdi,%r13
  41d193:	callq  430940 <p125_rt_ctor1>
  41d198:	mov    %r13,%rdi
  41d19b:	mov    %r12,-0x38a0(%rbp)
  41d1a2:	mov    %rax,-0x3898(%rbp)
  41d1a9:	lea    -0x38a0(%rbp),%rdx
  41d1b0:	mov    $0x8,%esi
  41d1b5:	mov    %rdi,%r12
  41d1b8:	callq  430b70 <p125_rt_ctor2>
  41d1bd:	mov    %r12,%rdi
  41d1c0:	mov    %rbx,-0x38a0(%rbp)
  41d1c7:	mov    %rax,-0x3898(%rbp)
  41d1ce:	lea    -0x38a0(%rbp),%rdx
  41d1d5:	mov    $0x8,%esi
  41d1da:	mov    %rdi,%rbx
  41d1dd:	callq  430b70 <p125_rt_ctor2>
  41d1e2:	mov    %rbx,%rdi
  41d1e5:	mov    %rax,-0x38a0(%rbp)
  41d1ec:	mov    0x1ca1d(%rip),%rcx        # 439c10 <p111_program+0x58>
  41d1f3:	test   $0x4,%rcx
  41d1fa:	jne    41d212 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x15e2>
  41d1fc:	mov    $0x1,%edx
  41d201:	lea    -0x38a0(%rbp),%rsi
  41d208:	callq  42b4e0 <p111_rt_return>
  41d20d:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d212:	mov    %rax,0x28(%rdi)
  41d216:	movl   $0x1,0x1c(%rdi)
  41d21d:	mov    0x10(%rdi),%rax
  41d221:	mov    %rax,%rcx
  41d224:	add    $0xfffffffffffffff8,%rcx
  41d228:	mov    %rcx,0x10(%rdi)
  41d22c:	mov    -0x8(%rax),%rax
  41d230:	mov    %eax,0x20(%rdi)
  41d233:	mov    $0x0,%eax
  41d238:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d23d:	cs cs cs cs mov %r15,%r13
  41d244:	cs cs mov %rsi,%r15
  41d249:	mov    %r12,%rsi
  41d24c:	mov    %rbx,%r12
  41d24f:	lea    -0x38a0(%rbp),%rdx
  41d256:	mov    %rdi,%rbx
  41d259:	callq  430c60 <p125_rt_take2>
  41d25e:	mov    %r15,%rsi
  41d261:	mov    %rbx,%rdi
  41d264:	mov    -0x80(%rbp),%r15
  41d268:	mov    -0x38a0(%rbp),%rax
  41d26f:	mov    %rax,%rbx
  41d272:	mov    -0x3898(%rbp),%rax
  41d279:	mov    %rax,-0x88(%rbp)
  41d280:	cmp    $0x8,%r15
  41d284:	je     41d31f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x16ef>
  41d28a:	mov    %rsi,%r15
  41d28d:	mov    %r12,%rsi
  41d290:	mov    %rdi,%r12
  41d293:	callq  42aec0 <p111_rt_sink>
  41d298:	mov    %r15,%rsi
  41d29b:	mov    %r12,%rdi
  41d29e:	mov    -0x88(%rbp),%r15
  41d2a5:	mov    %rdi,%r12
  41d2a8:	callq  42aec0 <p111_rt_sink>
  41d2ad:	mov    %r13,%rsi
  41d2b0:	mov    %r12,%rdi
  41d2b3:	mov    %rsi,%r13
  41d2b6:	mov    %r14,%rsi
  41d2b9:	mov    %rdi,%r12
  41d2bc:	callq  42aec0 <p111_rt_sink>
  41d2c1:	mov    %r13,%rsi
  41d2c4:	mov    %r12,%rdi
  41d2c7:	mov    %rbx,%rax
  41d2ca:	mov    %rsi,%r12
  41d2cd:	mov    %rax,%rsi
  41d2d0:	mov    %rdi,%rbx
  41d2d3:	callq  42aec0 <p111_rt_sink>
  41d2d8:	mov    %r12,%rsi
  41d2db:	mov    %rbx,%rdi
  41d2de:	mov    %rsi,%r12
  41d2e1:	mov    %r15,%rsi
  41d2e4:	mov    %rdi,%rbx
  41d2e7:	callq  42aec0 <p111_rt_sink>
  41d2ec:	mov    %r12,%rsi
  41d2ef:	mov    %rbx,%rdi
  41d2f2:	mov    %rsi,-0x38a0(%rbp)
  41d2f9:	mov    0x10(%rdi),%rax
  41d2fd:	mov    %rsi,(%rax)
  41d300:	movq   $0x165,0x8(%rax)
  41d308:	add    $0x10,%rax
  41d30c:	mov    %rax,0x10(%rdi)
  41d310:	mov    $0x4,%esi
  41d315:	callq  42b650 <p111_rt_fail>
  41d31a:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d31f:	mov    %rsi,%r15
  41d322:	xchg   %rbx,%r12
  41d325:	mov    %r13,%rsi
  41d328:	lea    -0x38a0(%rbp),%rdx
  41d32f:	mov    %rdi,%r13
  41d332:	callq  430c60 <p125_rt_take2>
  41d337:	mov    %r15,%rsi
  41d33a:	mov    %r13,%rdi
  41d33d:	mov    %r12,%rax
  41d340:	mov    -0x88(%rbp),%r15
  41d347:	mov    %rax,%r13
  41d34a:	mov    -0x38a0(%rbp),%rax
  41d351:	mov    %rax,-0x90(%rbp)
  41d358:	mov    %rbx,%r12
  41d35b:	mov    -0x3898(%rbp),%rbx
  41d362:	cmp    $0x1,%rbx
  41d366:	sete   %cl
  41d369:	movzbl %cl,%ecx
  41d36c:	mov    %rbx,%rdx
  41d36f:	shr    $0x28,%rdx
  41d373:	and    $0x7fffff,%rdx
  41d37a:	cmp    $0x10002,%rdx
  41d381:	sete   %dl
  41d384:	movzbl %dl,%edx
  41d387:	mov    %ecx,%r8d
  41d38a:	or     %edx,%r8d
  41d38d:	xor    $0x1,%r8d
  41d391:	jne    41d590 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1960>
  41d397:	or     %edx,%ecx
  41d399:	jne    41d434 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1804>
  41d39f:	mov    %rsi,%r15
  41d3a2:	mov    %r12,%rsi
  41d3a5:	mov    %rdi,%r12
  41d3a8:	callq  42aec0 <p111_rt_sink>
  41d3ad:	mov    %r15,%rsi
  41d3b0:	mov    %r12,%rdi
  41d3b3:	mov    -0x88(%rbp),%r15
  41d3ba:	mov    %rdi,%r12
  41d3bd:	callq  42aec0 <p111_rt_sink>
  41d3c2:	mov    %r12,%rdi
  41d3c5:	mov    -0x90(%rbp),%r12
  41d3cc:	mov    %r14,%rsi
  41d3cf:	mov    %rdi,%r14
  41d3d2:	callq  42aec0 <p111_rt_sink>
  41d3d7:	mov    %r14,%rdi
  41d3da:	mov    %r13,%rax
  41d3dd:	mov    %rax,%rsi
  41d3e0:	mov    %rdi,%r13
  41d3e3:	callq  42aec0 <p111_rt_sink>
  41d3e8:	mov    %r13,%rdi
  41d3eb:	mov    %r15,%rsi
  41d3ee:	mov    %rdi,%r13
  41d3f1:	callq  42aec0 <p111_rt_sink>
  41d3f6:	mov    %r13,%rdi
  41d3f9:	mov    %r12,%rsi
  41d3fc:	mov    %rdi,%r12
  41d3ff:	callq  42aec0 <p111_rt_sink>
  41d404:	mov    %r12,%rdi
  41d407:	mov    %rbx,-0x38a0(%rbp)
  41d40e:	mov    0x10(%rdi),%rax
  41d412:	mov    %rbx,(%rax)
  41d415:	movq   $0x164,0x8(%rax)
  41d41d:	add    $0x10,%rax
  41d421:	mov    %rax,0x10(%rdi)
  41d425:	mov    $0x4,%esi
  41d42a:	callq  42b650 <p111_rt_fail>
  41d42f:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d434:	mov    %r13,%rbx
  41d437:	mov    %r14,%r13
  41d43a:	mov    %r12,%r14
  41d43d:	mov    %rax,%r12
  41d440:	mov    %rsi,-0x38a0(%rbp)
  41d447:	mov    %r13,-0x3898(%rbp)
  41d44e:	lea    -0x38a0(%rbp),%rdx
  41d455:	mov    $0x2c,%esi
  41d45a:	mov    %rdi,%r13
  41d45d:	callq  430b70 <p125_rt_ctor2>
  41d462:	mov    %r13,%rdi
  41d465:	xchg   %rax,%rbx
  41d467:	mov    %rax,%rsi
  41d46a:	mov    %rdi,%r13
  41d46d:	callq  42ae30 <p111_rt_keep>
  41d472:	mov    %r13,%rdi
  41d475:	mov    %rax,%r13
  41d478:	mov    %r13,-0x38a0(%rbp)
  41d47f:	mov    %r15,-0x3898(%rbp)
  41d486:	lea    -0x38a0(%rbp),%rdx
  41d48d:	mov    $0x2c,%esi
  41d492:	mov    %rdi,%r15
  41d495:	callq  430b70 <p125_rt_ctor2>
  41d49a:	mov    %r15,%rdi
  41d49d:	mov    %r14,-0x38a0(%rbp)
  41d4a4:	mov    %rbx,-0x3898(%rbp)
  41d4ab:	mov    %rax,-0x3890(%rbp)
  41d4b2:	lea    -0x38a0(%rbp),%rdx
  41d4b9:	mov    $0x2d,%esi
  41d4be:	mov    %rdi,%rbx
  41d4c1:	callq  430df0 <p125_rt_ctor3>
  41d4c6:	mov    %rbx,%rdi
  41d4c9:	mov    %rax,%rbx
  41d4cc:	mov    %r13,-0x38a0(%rbp)
  41d4d3:	lea    -0x38a0(%rbp),%rdx
  41d4da:	mov    $0xc,%esi
  41d4df:	mov    %rdi,%r13
  41d4e2:	callq  430940 <p125_rt_ctor1>
  41d4e7:	mov    %r13,%rdi
  41d4ea:	mov    %r12,-0x38a0(%rbp)
  41d4f1:	mov    %rax,-0x3898(%rbp)
  41d4f8:	lea    -0x38a0(%rbp),%rdx
  41d4ff:	mov    $0x8,%esi
  41d504:	mov    %rdi,%r12
  41d507:	callq  430b70 <p125_rt_ctor2>
  41d50c:	mov    %r12,%rdi
  41d50f:	mov    %rbx,-0x38a0(%rbp)
  41d516:	mov    %rax,-0x3898(%rbp)
  41d51d:	lea    -0x38a0(%rbp),%rdx
  41d524:	mov    $0x8,%esi
  41d529:	mov    %rdi,%rbx
  41d52c:	callq  430b70 <p125_rt_ctor2>
  41d531:	mov    %rbx,%rdi
  41d534:	mov    %rax,-0x38a0(%rbp)
  41d53b:	mov    0x1c6ce(%rip),%rcx        # 439c10 <p111_program+0x58>
  41d542:	test   $0x4,%rcx
  41d549:	jne    41d565 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1935>
  41d54b:	cs cs cs cs mov $0x1,%edx
  41d554:	lea    -0x38a0(%rbp),%rsi
  41d55b:	callq  42b4e0 <p111_rt_return>
  41d560:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d565:	mov    %rax,0x28(%rdi)
  41d569:	movl   $0x1,0x1c(%rdi)
  41d570:	mov    0x10(%rdi),%rax
  41d574:	mov    %rax,%rcx
  41d577:	add    $0xfffffffffffffff8,%rcx
  41d57b:	mov    %rcx,0x10(%rdi)
  41d57f:	mov    -0x8(%rax),%rax
  41d583:	mov    %eax,0x20(%rdi)
  41d586:	mov    $0x0,%eax
  41d58b:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d590:	mov    %r13,%rbx
  41d593:	mov    %r14,%r13
  41d596:	mov    %r12,%r14
  41d599:	mov    %rdi,%r12
  41d59c:	callq  42ae30 <p111_rt_keep>
  41d5a1:	mov    %r12,%rdi
  41d5a4:	mov    -0x90(%rbp),%r12
  41d5ab:	mov    %rax,-0x98(%rbp)
  41d5b2:	mov    %rax,-0x38a0(%rbp)
  41d5b9:	mov    %r13,-0x3898(%rbp)
  41d5c0:	lea    -0x38a0(%rbp),%rdx
  41d5c7:	mov    $0x2c,%esi
  41d5cc:	mov    %rdi,%r13
  41d5cf:	callq  430b70 <p125_rt_ctor2>
  41d5d4:	mov    %r13,%rdi
  41d5d7:	xchg   %rax,%rbx
  41d5d9:	mov    -0x98(%rbp),%r13
  41d5e0:	mov    %rax,-0x38a0(%rbp)
  41d5e7:	mov    %r15,-0x3898(%rbp)
  41d5ee:	lea    -0x38a0(%rbp),%rdx
  41d5f5:	mov    $0x2c,%esi
  41d5fa:	mov    %rdi,%r15
  41d5fd:	callq  430b70 <p125_rt_ctor2>
  41d602:	mov    %r15,%rdi
  41d605:	mov    %r14,-0x38a0(%rbp)
  41d60c:	mov    %rbx,-0x3898(%rbp)
  41d613:	mov    %rax,-0x3890(%rbp)
  41d61a:	lea    -0x38a0(%rbp),%rdx
  41d621:	mov    $0x2d,%esi
  41d626:	mov    %rdi,%rbx
  41d629:	callq  430df0 <p125_rt_ctor3>
  41d62e:	mov    %rbx,%rdi
  41d631:	mov    %rax,%rbx
  41d634:	mov    %r13,-0x38a0(%rbp)
  41d63b:	lea    -0x38a0(%rbp),%rdx
  41d642:	mov    $0xc,%esi
  41d647:	mov    %rdi,%r13
  41d64a:	callq  430940 <p125_rt_ctor1>
  41d64f:	mov    %r13,%rdi
  41d652:	mov    %r12,-0x38a0(%rbp)
  41d659:	mov    %rax,-0x3898(%rbp)
  41d660:	lea    -0x38a0(%rbp),%rdx
  41d667:	mov    $0x8,%esi
  41d66c:	mov    %rdi,%r12
  41d66f:	callq  430b70 <p125_rt_ctor2>
  41d674:	mov    %r12,%rdi
  41d677:	mov    %rbx,-0x38a0(%rbp)
  41d67e:	mov    %rax,-0x3898(%rbp)
  41d685:	lea    -0x38a0(%rbp),%rdx
  41d68c:	mov    $0x8,%esi
  41d691:	mov    %rdi,%rbx
  41d694:	callq  430b70 <p125_rt_ctor2>
  41d699:	mov    %rbx,%rdi
  41d69c:	mov    %rax,-0x38a0(%rbp)
  41d6a3:	mov    0x1c566(%rip),%rcx        # 439c10 <p111_program+0x58>
  41d6aa:	test   $0x4,%rcx
  41d6b1:	jne    41d6c9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1a99>
  41d6b3:	mov    $0x1,%edx
  41d6b8:	lea    -0x38a0(%rbp),%rsi
  41d6bf:	callq  42b4e0 <p111_rt_return>
  41d6c4:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d6c9:	mov    %rax,0x28(%rdi)
  41d6cd:	movl   $0x1,0x1c(%rdi)
  41d6d4:	mov    0x10(%rdi),%rax
  41d6d8:	mov    %rax,%rcx
  41d6db:	add    $0xfffffffffffffff8,%rcx
  41d6df:	mov    %rcx,0x10(%rdi)
  41d6e3:	mov    -0x8(%rax),%rax
  41d6e7:	mov    %eax,0x20(%rdi)
  41d6ea:	mov    $0x0,%eax
  41d6ef:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d6f4:	mov    %r15,%r12
  41d6f7:	cmp    $0x8,%r13
  41d6fb:	je     41d765 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1b35>
  41d6fd:	cs cs mov %rsi,%r13
  41d702:	mov    %rbx,%rsi
  41d705:	mov    %rdi,%rbx
  41d708:	callq  42aec0 <p111_rt_sink>
  41d70d:	mov    %r13,%rsi
  41d710:	mov    %rbx,%rdi
  41d713:	mov    %rsi,%r13
  41d716:	mov    %rdi,%rbx
  41d719:	callq  42aec0 <p111_rt_sink>
  41d71e:	mov    %r12,%rsi
  41d721:	mov    %rbx,%rdi
  41d724:	mov    %rsi,%r12
  41d727:	mov    %r14,%rsi
  41d72a:	mov    %rdi,%rbx
  41d72d:	callq  42aec0 <p111_rt_sink>
  41d732:	mov    %r12,%rsi
  41d735:	mov    %rbx,%rdi
  41d738:	mov    %rsi,-0x38a0(%rbp)
  41d73f:	mov    0x10(%rdi),%rax
  41d743:	mov    %rsi,(%rax)
  41d746:	movq   $0x163,0x8(%rax)
  41d74e:	add    $0x10,%rax
  41d752:	mov    %rax,0x10(%rdi)
  41d756:	mov    $0x4,%esi
  41d75b:	callq  42b650 <p111_rt_fail>
  41d760:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d765:	cs cs cs mov %rsi,%r13
  41d76b:	mov    %r12,%rsi
  41d76e:	lea    -0x38a0(%rbp),%rdx
  41d775:	mov    %rdi,%r12
  41d778:	callq  430c60 <p125_rt_take2>
  41d77d:	mov    %r13,%rsi
  41d780:	mov    %r12,%rdi
  41d783:	mov    -0x38a0(%rbp),%r12
  41d78a:	mov    %rbx,%r13
  41d78d:	mov    -0x3898(%rbp),%rbx
  41d794:	cmp    $0x1,%rbx
  41d798:	sete   %al
  41d79b:	movzbl %al,%eax
  41d79e:	mov    %rbx,%rcx
  41d7a1:	shr    $0x28,%rcx
  41d7a5:	and    $0x7fffff,%rcx
  41d7ac:	cmp    $0x10002,%rcx
  41d7b3:	sete   %cl
  41d7b6:	movzbl %cl,%ecx
  41d7b9:	mov    %eax,%edx
  41d7bb:	or     %ecx,%edx
  41d7bd:	xor    $0x1,%edx
  41d7c0:	jne    41d93f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1d0f>
  41d7c6:	or     %ecx,%eax
  41d7c8:	jne    41d832 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1c02>
  41d7ca:	mov    %rsi,%r15
  41d7cd:	mov    %r13,%rsi
  41d7d0:	mov    %rdi,%r13
  41d7d3:	callq  42aec0 <p111_rt_sink>
  41d7d8:	mov    %r15,%rsi
  41d7db:	mov    %r13,%rdi
  41d7de:	mov    %rdi,%r13
  41d7e1:	callq  42aec0 <p111_rt_sink>
  41d7e6:	mov    %r13,%rdi
  41d7e9:	mov    %r14,%rsi
  41d7ec:	mov    %rdi,%r13
  41d7ef:	callq  42aec0 <p111_rt_sink>
  41d7f4:	mov    %r13,%rdi
  41d7f7:	mov    %r12,%rsi
  41d7fa:	mov    %rdi,%r12
  41d7fd:	callq  42aec0 <p111_rt_sink>
  41d802:	mov    %r12,%rdi
  41d805:	mov    %rbx,-0x38a0(%rbp)
  41d80c:	mov    0x10(%rdi),%rax
  41d810:	mov    %rbx,(%rax)
  41d813:	movq   $0x162,0x8(%rax)
  41d81b:	add    $0x10,%rax
  41d81f:	mov    %rax,0x10(%rdi)
  41d823:	mov    $0x4,%esi
  41d828:	callq  42b650 <p111_rt_fail>
  41d82d:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d832:	mov    %r13,%rbx
  41d835:	mov    %rsi,-0x38a0(%rbp)
  41d83c:	mov    %r14,-0x3898(%rbp)
  41d843:	lea    -0x38a0(%rbp),%rdx
  41d84a:	mov    $0x2c,%esi
  41d84f:	mov    %rdi,%r13
  41d852:	callq  430b70 <p125_rt_ctor2>
  41d857:	mov    %r13,%rdi
  41d85a:	mov    %rbx,-0x38a0(%rbp)
  41d861:	mov    %rax,-0x3898(%rbp)
  41d868:	movabs $0x1002b0000000000,%rax
  41d872:	mov    %rax,-0x3890(%rbp)
  41d879:	lea    -0x38a0(%rbp),%rdx
  41d880:	mov    $0x2d,%esi
  41d885:	mov    %rdi,%rbx
  41d888:	callq  430df0 <p125_rt_ctor3>
  41d88d:	mov    %rbx,%rdi
  41d890:	mov    %rax,%rbx
  41d893:	mov    %r12,-0x38a0(%rbp)
  41d89a:	movabs $0x1000b0000000000,%rax
  41d8a4:	mov    %rax,-0x3898(%rbp)
  41d8ab:	lea    -0x38a0(%rbp),%rdx
  41d8b2:	mov    $0x8,%esi
  41d8b7:	mov    %rdi,%r12
  41d8ba:	callq  430b70 <p125_rt_ctor2>
  41d8bf:	mov    %r12,%rdi
  41d8c2:	mov    %rbx,-0x38a0(%rbp)
  41d8c9:	mov    %rax,-0x3898(%rbp)
  41d8d0:	lea    -0x38a0(%rbp),%rdx
  41d8d7:	mov    $0x8,%esi
  41d8dc:	mov    %rdi,%rbx
  41d8df:	callq  430b70 <p125_rt_ctor2>
  41d8e4:	mov    %rbx,%rdi
  41d8e7:	mov    %rax,-0x38a0(%rbp)
  41d8ee:	mov    0x1c31b(%rip),%rcx        # 439c10 <p111_program+0x58>
  41d8f5:	test   $0x4,%rcx
  41d8fc:	jne    41d914 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ce4>
  41d8fe:	mov    $0x1,%edx
  41d903:	lea    -0x38a0(%rbp),%rsi
  41d90a:	callq  42b4e0 <p111_rt_return>
  41d90f:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d914:	mov    %rax,0x28(%rdi)
  41d918:	movl   $0x1,0x1c(%rdi)
  41d91f:	mov    0x10(%rdi),%rax
  41d923:	mov    %rax,%rcx
  41d926:	add    $0xfffffffffffffff8,%rcx
  41d92a:	mov    %rcx,0x10(%rdi)
  41d92e:	mov    -0x8(%rax),%rax
  41d932:	mov    %eax,0x20(%rdi)
  41d935:	mov    $0x0,%eax
  41d93a:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41d93f:	mov    %r13,%rbx
  41d942:	mov    %rdi,%r13
  41d945:	callq  42ae30 <p111_rt_keep>
  41d94a:	mov    %r13,%rdi
  41d94d:	mov    %rax,%r13
  41d950:	mov    %r13,-0x38a0(%rbp)
  41d957:	mov    %r14,-0x3898(%rbp)
  41d95e:	lea    -0x38a0(%rbp),%rdx
  41d965:	mov    $0x2c,%esi
  41d96a:	mov    %rdi,%r14
  41d96d:	callq  430b70 <p125_rt_ctor2>
  41d972:	mov    %r14,%rdi
  41d975:	mov    %rbx,-0x38a0(%rbp)
  41d97c:	mov    %rax,-0x3898(%rbp)
  41d983:	movabs $0x1002b0000000000,%rax
  41d98d:	mov    %rax,-0x3890(%rbp)
  41d994:	lea    -0x38a0(%rbp),%rdx
  41d99b:	mov    $0x2d,%esi
  41d9a0:	mov    %rdi,%rbx
  41d9a3:	callq  430df0 <p125_rt_ctor3>
  41d9a8:	mov    %rbx,%rdi
  41d9ab:	mov    %rax,%rbx
  41d9ae:	mov    %r13,-0x38a0(%rbp)
  41d9b5:	lea    -0x38a0(%rbp),%rdx
  41d9bc:	mov    $0xc,%esi
  41d9c1:	mov    %rdi,%r13
  41d9c4:	callq  430940 <p125_rt_ctor1>
  41d9c9:	mov    %r13,%rdi
  41d9cc:	mov    %r12,-0x38a0(%rbp)
  41d9d3:	mov    %rax,-0x3898(%rbp)
  41d9da:	lea    -0x38a0(%rbp),%rdx
  41d9e1:	mov    $0x8,%esi
  41d9e6:	mov    %rdi,%r12
  41d9e9:	callq  430b70 <p125_rt_ctor2>
  41d9ee:	mov    %r12,%rdi
  41d9f1:	mov    %rbx,-0x38a0(%rbp)
  41d9f8:	mov    %rax,-0x3898(%rbp)
  41d9ff:	lea    -0x38a0(%rbp),%rdx
  41da06:	mov    $0x8,%esi
  41da0b:	mov    %rdi,%rbx
  41da0e:	callq  430b70 <p125_rt_ctor2>
  41da13:	mov    %rbx,%rdi
  41da16:	mov    %rax,-0x38a0(%rbp)
  41da1d:	mov    0x1c1ec(%rip),%rcx        # 439c10 <p111_program+0x58>
  41da24:	test   $0x4,%rcx
  41da2b:	jne    41da45 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1e15>
  41da2d:	cs cs mov $0x1,%edx
  41da34:	lea    -0x38a0(%rbp),%rsi
  41da3b:	callq  42b4e0 <p111_rt_return>
  41da40:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41da45:	mov    %rax,0x28(%rdi)
  41da49:	movl   $0x1,0x1c(%rdi)
  41da50:	mov    0x10(%rdi),%rax
  41da54:	mov    %rax,%rcx
  41da57:	add    $0xfffffffffffffff8,%rcx
  41da5b:	mov    %rcx,0x10(%rdi)
  41da5f:	mov    -0x8(%rax),%rax
  41da63:	mov    %eax,0x20(%rdi)
  41da66:	mov    $0x0,%eax
  41da6b:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41da70:	mov    %r14,%rsi
  41da73:	mov    %r15,%r14
  41da76:	nopw   %cs:0x0(%rax,%rax,1)
  41da80:	cmp    $0x2b,%rax
  41da84:	je     41e225 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x25f5>
  41da8a:	cmp    $0x2c,%rax
  41da8e:	je     41de8a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x225a>
  41da94:	cmp    $0x2d,%rax
  41da98:	je     41daf9 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1ec9>
  41da9a:	mov    %rsi,%r12
  41da9d:	mov    %rbx,%rsi
  41daa0:	mov    %rdi,%rbx
  41daa3:	callq  42aec0 <p111_rt_sink>
  41daa8:	mov    %r12,%rsi
  41daab:	mov    %rbx,%rdi
  41daae:	mov    %r14,-0x38a0(%rbp)
  41dab5:	mov    0x10(%rdi),%rax
  41dab9:	mov    %r14,(%rax)
  41dabc:	movq   $0x160,0x8(%rax)
  41dac4:	add    $0x10,%rax
  41dac8:	mov    %rax,0x10(%rdi)
  41dacc:	mov    %rsi,-0x38a0(%rbp)
  41dad3:	mov    0x10(%rdi),%rax
  41dad7:	mov    %rsi,(%rax)
  41dada:	movq   $0x161,0x8(%rax)
  41dae2:	add    $0x10,%rax
  41dae6:	mov    %rax,0x10(%rdi)
  41daea:	mov    $0x4,%esi
  41daef:	callq  42b650 <p111_rt_fail>
  41daf4:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41daf9:	lea    -0x38a0(%rbp),%rdx
  41db00:	mov    %rdi,%r13
  41db03:	callq  430ec0 <p125_rt_take3>
  41db08:	mov    %r14,%rsi
  41db0b:	mov    %r13,%rdi
  41db0e:	mov    -0x38a0(%rbp),%r15
  41db15:	mov    -0x3898(%rbp),%r14
  41db1c:	mov    -0x3890(%rbp),%r13
  41db23:	cmp    $0x8,%r12
  41db27:	je     41dba6 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x1f76>
  41db29:	mov    %rsi,%r12
  41db2c:	mov    %rbx,%rsi
  41db2f:	mov    %rdi,%rbx
  41db32:	callq  42aec0 <p111_rt_sink>
  41db37:	mov    %r12,%rsi
  41db3a:	mov    %rbx,%rdi
  41db3d:	mov    %rsi,%r12
  41db40:	mov    %r15,%rsi
  41db43:	mov    %rdi,%rbx
  41db46:	callq  42aec0 <p111_rt_sink>
  41db4b:	mov    %r12,%rsi
  41db4e:	mov    %rbx,%rdi
  41db51:	mov    %rsi,%r12
  41db54:	mov    %r14,%rsi
  41db57:	mov    %rdi,%rbx
  41db5a:	callq  42aec0 <p111_rt_sink>
  41db5f:	mov    %r12,%rsi
  41db62:	mov    %rbx,%rdi
  41db65:	mov    %rsi,%r12
  41db68:	mov    %r13,%rsi
  41db6b:	mov    %rdi,%rbx
  41db6e:	callq  42aec0 <p111_rt_sink>
  41db73:	mov    %r12,%rsi
  41db76:	mov    %rbx,%rdi
  41db79:	mov    %rsi,-0x38a0(%rbp)
  41db80:	mov    0x10(%rdi),%rax
  41db84:	mov    %rsi,(%rax)
  41db87:	movq   $0x15f,0x8(%rax)
  41db8f:	add    $0x10,%rax
  41db93:	mov    %rax,0x10(%rdi)
  41db97:	mov    $0x4,%esi
  41db9c:	callq  42b650 <p111_rt_fail>
  41dba1:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41dba6:	cs cs cs lea %cs:-0x38a0(%rbp),%rdx
  41dbb1:	mov    %rdi,%r12
  41dbb4:	callq  430c60 <p125_rt_take2>
  41dbb9:	mov    %r12,%rdi
  41dbbc:	mov    -0x38a0(%rbp),%rax
  41dbc3:	mov    %rax,-0xa0(%rbp)
  41dbca:	mov    %rbx,%r12
  41dbcd:	mov    -0x3898(%rbp),%rbx
  41dbd4:	cmp    $0x1,%rbx
  41dbd8:	sete   %cl
  41dbdb:	movzbl %cl,%ecx
  41dbde:	mov    %rbx,%rdx
  41dbe1:	shr    $0x28,%rdx
  41dbe5:	and    $0x7fffff,%rdx
  41dbec:	cmp    $0x10002,%rdx
  41dbf3:	sete   %dl
  41dbf6:	movzbl %dl,%edx
  41dbf9:	mov    %ecx,%esi
  41dbfb:	or     %edx,%esi
  41dbfd:	xor    $0x1,%esi
  41dc00:	jne    41dd72 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2142>
  41dc06:	or     %edx,%ecx
  41dc08:	jne    41dc85 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2055>
  41dc0a:	cs mov %r12,%rsi
  41dc0e:	mov    %rdi,%r12
  41dc11:	callq  42aec0 <p111_rt_sink>
  41dc16:	mov    %r12,%rdi
  41dc19:	mov    -0xa0(%rbp),%r12
  41dc20:	mov    %r15,%rsi
  41dc23:	mov    %rdi,%r15
  41dc26:	callq  42aec0 <p111_rt_sink>
  41dc2b:	mov    %r15,%rdi
  41dc2e:	mov    %r14,%rsi
  41dc31:	mov    %rdi,%r14
  41dc34:	callq  42aec0 <p111_rt_sink>
  41dc39:	mov    %r14,%rdi
  41dc3c:	mov    %r13,%rsi
  41dc3f:	mov    %rdi,%r13
  41dc42:	callq  42aec0 <p111_rt_sink>
  41dc47:	mov    %r13,%rdi
  41dc4a:	mov    %r12,%rsi
  41dc4d:	mov    %rdi,%r12
  41dc50:	callq  42aec0 <p111_rt_sink>
  41dc55:	mov    %r12,%rdi
  41dc58:	mov    %rbx,-0x38a0(%rbp)
  41dc5f:	mov    0x10(%rdi),%rax
  41dc63:	mov    %rbx,(%rax)
  41dc66:	movq   $0x15e,0x8(%rax)
  41dc6e:	add    $0x10,%rax
  41dc72:	mov    %rax,0x10(%rdi)
  41dc76:	mov    $0x4,%esi
  41dc7b:	callq  42b650 <p111_rt_fail>
  41dc80:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41dc85:	mov    %r12,%rbx
  41dc88:	mov    %rax,%r12
  41dc8b:	mov    %rbx,-0x38a0(%rbp)
  41dc92:	movabs $0x1002b0000000000,%rax
  41dc9c:	mov    %rax,-0x3898(%rbp)
  41dca3:	mov    0x10(%rdi),%rax
  41dca7:	mov    %rbx,(%rax)
  41dcaa:	mov    -0x3898(%rbp),%rcx
  41dcb1:	mov    %rcx,0x8(%rax)
  41dcb5:	movq   $0x15c,0x10(%rax)
  41dcbd:	add    $0x18,%rax
  41dcc1:	mov    %rax,0x10(%rdi)
  41dcc5:	mov    %r15,%rsi
  41dcc8:	mov    %rdi,%rbx
  41dccb:	callq  42ae30 <p111_rt_keep>
  41dcd0:	mov    %rbx,%rdi
  41dcd3:	mov    %rax,%rdx
  41dcd6:	mov    %rdx,-0x38a0(%rbp)
  41dcdd:	mov    %r14,-0x3898(%rbp)
  41dce4:	mov    %r13,-0x3890(%rbp)
  41dceb:	mov    %rdx,%r13
  41dcee:	lea    -0x38a0(%rbp),%rdx
  41dcf5:	mov    $0x2d,%esi
  41dcfa:	mov    %rdi,%rbx
  41dcfd:	callq  430df0 <p125_rt_ctor3>
  41dd02:	mov    %r13,%rdx
  41dd05:	mov    %rbx,%rdi
  41dd08:	mov    %rax,%rbx
  41dd0b:	mov    %r12,%rsi
  41dd0e:	mov    %rdi,%r12
  41dd11:	callq  405380 <p112w_FID_36_100_105_114_101_99_116_46_77_97_112_46_98_105_116_>
  41dd16:	mov    %r12,%rdi
  41dd19:	mov    %rbx,-0x30a0(%rbp)
  41dd20:	mov    %rax,-0x3098(%rbp)
  41dd27:	mov    0x1bee2(%rip),%rcx        # 439c10 <p111_program+0x58>
  41dd2e:	test   $0x4,%rcx
  41dd35:	jne    41dd52 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x2122>
  41dd37:	mov    $0x2,%ecx
  41dd3c:	lea    -0x30a0(%rbp),%rdx
  41dd43:	mov    $0x157,%esi
  41dd48:	callq  42b480 <p111_rt_jump>
  41dd4d:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41dd52:	mov    %rbx,0x28(%rdi)
  41dd56:	mov    %rax,0x30(%rdi)
  41dd5a:	movl   $0x0,0x1c(%rdi)
  41dd61:	movl   $0x157,0x20(%rdi)
  41dd68:	mov    $0x0,%eax
  41dd6d:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41dd72:	cs mov %r12,%rbx
  41dd76:	mov    %rax,%r12
  41dd79:	mov    %r15,-0x38a0(%rbp)
  41dd80:	mov    %r14,-0x3898(%rbp)
  41dd87:	mov    %r13,-0x3890(%rbp)
  41dd8e:	lea    -0x38a0(%rbp),%rdx
  41dd95:	mov    $0x2d,%esi
  41dd9a:	mov    %rdi,%r13
  41dd9d:	callq  430df0 <p125_rt_ctor3>
  41dda2:	mov    %r13,%rdi
  41dda5:	mov    %rbx,-0x38a0(%rbp)
  41ddac:	movabs $0x1002b0000000000,%rcx
  41ddb6:	mov    %rcx,-0x3898(%rbp)
  41ddbd:	mov    %rax,-0x3890(%rbp)
  41ddc4:	lea    -0x38a0(%rbp),%rdx
  41ddcb:	mov    $0x2d,%esi
  41ddd0:	mov    %rdi,%rbx
  41ddd3:	callq  430df0 <p125_rt_ctor3>
  41ddd8:	mov    %rbx,%rdi
  41dddb:	mov    %rax,%rbx
  41ddde:	mov    %r12,-0x38a0(%rbp)
  41dde5:	movabs $0x1000b0000000000,%rax
  41ddef:	mov    %rax,-0x3898(%rbp)
  41ddf6:	lea    -0x38a0(%rbp),%rdx
  41ddfd:	mov    $0x8,%esi
  41de02:	mov    %rdi,%r12
  41de05:	callq  430b70 <p125_rt_ctor2>
  41de0a:	mov    %r12,%rdi
  41de0d:	mov    %rbx,-0x38a0(%rbp)
  41de14:	mov    %rax,-0x3898(%rbp)
  41de1b:	lea    -0x38a0(%rbp),%rdx
  41de22:	mov    $0x8,%esi
  41de27:	mov    %rdi,%rbx
  41de2a:	callq  430b70 <p125_rt_ctor2>
  41de2f:	mov    %rbx,%rdi
  41de32:	mov    %rax,-0x38a0(%rbp)
  41de39:	mov    0x1bdd0(%rip),%rcx        # 439c10 <p111_program+0x58>
  41de40:	test   $0x4,%rcx
  41de47:	jne    41de5f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x222f>
  41de49:	mov    $0x1,%edx
  41de4e:	lea    -0x38a0(%rbp),%rsi
  41de55:	callq  42b4e0 <p111_rt_return>
  41de5a:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41de5f:	mov    %rax,0x28(%rdi)
  41de63:	movl   $0x1,0x1c(%rdi)
  41de6a:	mov    0x10(%rdi),%rax
  41de6e:	mov    %rax,%rcx
  41de71:	add    $0xfffffffffffffff8,%rcx
  41de75:	mov    %rcx,0x10(%rdi)
  41de79:	mov    -0x8(%rax),%rax
  41de7d:	mov    %eax,0x20(%rdi)
  41de80:	mov    $0x0,%eax
  41de85:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41de8a:	lea    -0x38a0(%rbp),%rdx
  41de91:	mov    %rdi,%r13
  41de94:	callq  430c60 <p125_rt_take2>
  41de99:	mov    %r14,%rsi
  41de9c:	mov    %r13,%rdi
  41de9f:	mov    -0x38a0(%rbp),%r14
  41dea6:	mov    %r14,%r13
  41dea9:	mov    -0x3898(%rbp),%r14
  41deb0:	cmp    $0x8,%r12
  41deb4:	je     41df1f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x22ef>
  41deb6:	mov    %rsi,%r12
  41deb9:	mov    %rbx,%rsi
  41debc:	mov    %rdi,%rbx
  41debf:	callq  42aec0 <p111_rt_sink>
  41dec4:	mov    %r12,%rsi
  41dec7:	mov    %rbx,%rdi
  41deca:	mov    %rsi,%r12
  41decd:	mov    %r13,%rsi
  41ded0:	mov    %rdi,%rbx
  41ded3:	callq  42aec0 <p111_rt_sink>
  41ded8:	mov    %r12,%rsi
  41dedb:	mov    %rbx,%rdi
  41dede:	mov    %rsi,%r12
  41dee1:	mov    %r14,%rsi
  41dee4:	mov    %rdi,%rbx
  41dee7:	callq  42aec0 <p111_rt_sink>
  41deec:	mov    %r12,%rsi
  41deef:	mov    %rbx,%rdi
  41def2:	mov    %rsi,-0x38a0(%rbp)
  41def9:	mov    0x10(%rdi),%rax
  41defd:	mov    %rsi,(%rax)
  41df00:	movq   $0x15b,0x8(%rax)
  41df08:	add    $0x10,%rax
  41df0c:	mov    %rax,0x10(%rdi)
  41df10:	mov    $0x4,%esi
  41df15:	callq  42b650 <p111_rt_fail>
  41df1a:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41df1f:	lea    -0x38a0(%rbp),%rdx
  41df26:	mov    %rdi,%r12
  41df29:	callq  430c60 <p125_rt_take2>
  41df2e:	mov    %r12,%rdi
  41df31:	mov    -0x38a0(%rbp),%r12
  41df38:	mov    %rbx,%r15
  41df3b:	mov    -0x3898(%rbp),%rbx
  41df42:	cmp    $0x1,%rbx
  41df46:	sete   %al
  41df49:	movzbl %al,%eax
  41df4c:	mov    %rbx,%rcx
  41df4f:	shr    $0x28,%rcx
  41df53:	and    $0x7fffff,%rcx
  41df5a:	cmp    $0x10002,%rcx
  41df61:	sete   %cl
  41df64:	movzbl %cl,%ecx
  41df67:	mov    %eax,%edx
  41df69:	or     %ecx,%edx
  41df6b:	xor    $0x1,%edx
  41df6e:	jne    41e110 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x24e0>
  41df74:	or     %ecx,%eax
  41df76:	jne    41dfdd <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x23ad>
  41df78:	mov    %r15,%rsi
  41df7b:	mov    %rdi,%r15
  41df7e:	callq  42aec0 <p111_rt_sink>
  41df83:	mov    %r15,%rdi
  41df86:	mov    %r13,%rsi
  41df89:	mov    %rdi,%r13
  41df8c:	callq  42aec0 <p111_rt_sink>
  41df91:	mov    %r13,%rdi
  41df94:	mov    %r14,%rsi
  41df97:	mov    %rdi,%r13
  41df9a:	callq  42aec0 <p111_rt_sink>
  41df9f:	mov    %r13,%rdi
  41dfa2:	mov    %r12,%rsi
  41dfa5:	mov    %rdi,%r12
  41dfa8:	callq  42aec0 <p111_rt_sink>
  41dfad:	mov    %r12,%rdi
  41dfb0:	mov    %rbx,-0x38a0(%rbp)
  41dfb7:	mov    0x10(%rdi),%rax
  41dfbb:	mov    %rbx,(%rax)
  41dfbe:	movq   $0x15a,0x8(%rax)
  41dfc6:	add    $0x10,%rax
  41dfca:	mov    %rax,0x10(%rdi)
  41dfce:	mov    $0x4,%esi
  41dfd3:	callq  42b650 <p111_rt_fail>
  41dfd8:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41dfdd:	mov    %r15,%rbx
  41dfe0:	mov    %r13,%rsi
  41dfe3:	mov    %rdi,%r13
  41dfe6:	callq  42ae30 <p111_rt_keep>
  41dfeb:	mov    %r13,%rdi
  41dfee:	mov    %rax,%r13
  41dff1:	mov    %r13,-0x38a0(%rbp)
  41dff8:	mov    %r14,-0x3898(%rbp)
  41dfff:	lea    -0x38a0(%rbp),%rdx
  41e006:	mov    $0x2c,%esi
  41e00b:	mov    %rdi,%r14
  41e00e:	callq  430b70 <p125_rt_ctor2>
  41e013:	mov    %r14,%rdi
  41e016:	mov    %rbx,-0x38a0(%rbp)
  41e01d:	movabs $0x1002b0000000000,%rcx
  41e027:	mov    %rcx,-0x3898(%rbp)
  41e02e:	mov    %rax,-0x3890(%rbp)
  41e035:	lea    -0x38a0(%rbp),%rdx
  41e03c:	mov    $0x2d,%esi
  41e041:	mov    %rdi,%rbx
  41e044:	callq  430df0 <p125_rt_ctor3>
  41e049:	mov    %rbx,%rdi
  41e04c:	mov    %rax,%rbx
  41e04f:	mov    %r13,-0x38a0(%rbp)
  41e056:	lea    -0x38a0(%rbp),%rdx
  41e05d:	mov    $0xc,%esi
  41e062:	mov    %rdi,%r13
  41e065:	callq  430940 <p125_rt_ctor1>
  41e06a:	mov    %r13,%rdi
  41e06d:	mov    %r12,-0x38a0(%rbp)
  41e074:	mov    %rax,-0x3898(%rbp)
  41e07b:	lea    -0x38a0(%rbp),%rdx
  41e082:	mov    $0x8,%esi
  41e087:	mov    %rdi,%r12
  41e08a:	callq  430b70 <p125_rt_ctor2>
  41e08f:	mov    %r12,%rdi
  41e092:	mov    %rbx,-0x38a0(%rbp)
  41e099:	mov    %rax,-0x3898(%rbp)
  41e0a0:	lea    -0x38a0(%rbp),%rdx
  41e0a7:	mov    $0x8,%esi
  41e0ac:	mov    %rdi,%rbx
  41e0af:	callq  430b70 <p125_rt_ctor2>
  41e0b4:	mov    %rbx,%rdi
  41e0b7:	mov    %rax,-0x38a0(%rbp)
  41e0be:	mov    0x1bb4b(%rip),%rcx        # 439c10 <p111_program+0x58>
  41e0c5:	test   $0x4,%rcx
  41e0cc:	jne    41e0e5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x24b5>
  41e0ce:	cs mov $0x1,%edx
  41e0d4:	lea    -0x38a0(%rbp),%rsi
  41e0db:	callq  42b4e0 <p111_rt_return>
  41e0e0:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e0e5:	mov    %rax,0x28(%rdi)
  41e0e9:	movl   $0x1,0x1c(%rdi)
  41e0f0:	mov    0x10(%rdi),%rax
  41e0f4:	mov    %rax,%rcx
  41e0f7:	add    $0xfffffffffffffff8,%rcx
  41e0fb:	mov    %rcx,0x10(%rdi)
  41e0ff:	mov    -0x8(%rax),%rax
  41e103:	mov    %eax,0x20(%rdi)
  41e106:	mov    $0x0,%eax
  41e10b:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e110:	xchg   %r14,%r13
  41e113:	mov    %r15,%rbx
  41e116:	mov    %r14,-0x38a0(%rbp)
  41e11d:	mov    %r13,-0x3898(%rbp)
  41e124:	lea    -0x38a0(%rbp),%rdx
  41e12b:	mov    $0x2c,%esi
  41e130:	mov    %rdi,%r13
  41e133:	callq  430b70 <p125_rt_ctor2>
  41e138:	mov    %r13,%rdi
  41e13b:	mov    %rbx,-0x38a0(%rbp)
  41e142:	movabs $0x1002b0000000000,%rcx
  41e14c:	mov    %rcx,-0x3898(%rbp)
  41e153:	mov    %rax,-0x3890(%rbp)
  41e15a:	lea    -0x38a0(%rbp),%rdx
  41e161:	mov    $0x2d,%esi
  41e166:	mov    %rdi,%rbx
  41e169:	callq  430df0 <p125_rt_ctor3>
  41e16e:	mov    %rbx,%rdi
  41e171:	mov    %rax,%rbx
  41e174:	mov    %r12,-0x38a0(%rbp)
  41e17b:	movabs $0x1000b0000000000,%rax
  41e185:	mov    %rax,-0x3898(%rbp)
  41e18c:	lea    -0x38a0(%rbp),%rdx
  41e193:	mov    $0x8,%esi
  41e198:	mov    %rdi,%r12
  41e19b:	callq  430b70 <p125_rt_ctor2>
  41e1a0:	mov    %r12,%rdi
  41e1a3:	mov    %rbx,-0x38a0(%rbp)
  41e1aa:	mov    %rax,-0x3898(%rbp)
  41e1b1:	lea    -0x38a0(%rbp),%rdx
  41e1b8:	mov    $0x8,%esi
  41e1bd:	mov    %rdi,%rbx
  41e1c0:	callq  430b70 <p125_rt_ctor2>
  41e1c5:	mov    %rbx,%rdi
  41e1c8:	mov    %rax,-0x38a0(%rbp)
  41e1cf:	mov    0x1ba3a(%rip),%rcx        # 439c10 <p111_program+0x58>
  41e1d6:	test   $0x4,%rcx
  41e1dd:	jne    41e1f5 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x25c5>
  41e1df:	mov    $0x1,%edx
  41e1e4:	lea    -0x38a0(%rbp),%rsi
  41e1eb:	callq  42b4e0 <p111_rt_return>
  41e1f0:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e1f5:	cs cs cs mov %rax,%cs:0x28(%rdi)
  41e1fd:	movl   $0x1,%cs:0x1c(%rdi)
  41e205:	mov    0x10(%rdi),%rax
  41e209:	mov    %rax,%rcx
  41e20c:	add    $0xfffffffffffffff8,%rcx
  41e210:	mov    %rcx,0x10(%rdi)
  41e214:	mov    -0x8(%rax),%rax
  41e218:	mov    %eax,0x20(%rdi)
  41e21b:	mov    $0x0,%eax
  41e220:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e225:	mov    %r14,%rsi
  41e228:	cmp    $0x8,%r12
  41e22c:	je     41e26f <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x263f>
  41e22e:	mov    %rsi,%r12
  41e231:	mov    %rbx,%rsi
  41e234:	mov    %rdi,%rbx
  41e237:	callq  42aec0 <p111_rt_sink>
  41e23c:	mov    %r12,%rsi
  41e23f:	mov    %rbx,%rdi
  41e242:	mov    %rsi,-0x38a0(%rbp)
  41e249:	mov    0x10(%rdi),%rax
  41e24d:	mov    %rsi,(%rax)
  41e250:	movq   $0x159,0x8(%rax)
  41e258:	add    $0x10,%rax
  41e25c:	mov    %rax,0x10(%rdi)
  41e260:	mov    $0x4,%esi
  41e265:	callq  42b650 <p111_rt_fail>
  41e26a:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e26f:	cs lea %cs:-0x38a0(%rbp),%rdx
  41e278:	mov    %rdi,%r12
  41e27b:	callq  430c60 <p125_rt_take2>
  41e280:	mov    %r12,%rdi
  41e283:	mov    -0x38a0(%rbp),%r12
  41e28a:	mov    %rbx,%r13
  41e28d:	mov    -0x3898(%rbp),%rbx
  41e294:	cmp    $0x1,%rbx
  41e298:	sete   %al
  41e29b:	movzbl %al,%eax
  41e29e:	mov    %rbx,%rcx
  41e2a1:	shr    $0x28,%rcx
  41e2a5:	and    $0x7fffff,%rcx
  41e2ac:	cmp    $0x10002,%rcx
  41e2b3:	sete   %cl
  41e2b6:	movzbl %cl,%ecx
  41e2b9:	mov    %eax,%edx
  41e2bb:	or     %ecx,%edx
  41e2bd:	xor    $0x1,%edx
  41e2c0:	jne    41e40a <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x27da>
  41e2c6:	or     %ecx,%eax
  41e2c8:	jne    41e313 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x26e3>
  41e2ca:	mov    %r13,%rsi
  41e2cd:	mov    %rdi,%r13
  41e2d0:	callq  42aec0 <p111_rt_sink>
  41e2d5:	mov    %r13,%rdi
  41e2d8:	mov    %r12,%rsi
  41e2db:	mov    %rdi,%r12
  41e2de:	callq  42aec0 <p111_rt_sink>
  41e2e3:	mov    %r12,%rdi
  41e2e6:	mov    %rbx,-0x38a0(%rbp)
  41e2ed:	mov    0x10(%rdi),%rax
  41e2f1:	mov    %rbx,(%rax)
  41e2f4:	movq   $0x158,0x8(%rax)
  41e2fc:	add    $0x10,%rax
  41e300:	mov    %rax,0x10(%rdi)
  41e304:	mov    $0x4,%esi
  41e309:	callq  42b650 <p111_rt_fail>
  41e30e:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e313:	cs cs cs cs mov %r13,%rbx
  41e31a:	mov    %rbx,%cs:-0x38a0(%rbp)
  41e322:	movabs $0x1002b0000000000,%rax
  41e32c:	mov    %rax,-0x3898(%rbp)
  41e333:	movabs $0x1002b0000000000,%rax
  41e33d:	mov    %rax,-0x3890(%rbp)
  41e344:	lea    -0x38a0(%rbp),%rdx
  41e34b:	mov    $0x2d,%esi
  41e350:	mov    %rdi,%rbx
  41e353:	callq  430df0 <p125_rt_ctor3>
  41e358:	mov    %rbx,%rdi
  41e35b:	mov    %rax,%rbx
  41e35e:	mov    %r12,-0x38a0(%rbp)
  41e365:	movabs $0x1000b0000000000,%rax
  41e36f:	mov    %rax,-0x3898(%rbp)
  41e376:	lea    -0x38a0(%rbp),%rdx
  41e37d:	mov    $0x8,%esi
  41e382:	mov    %rdi,%r12
  41e385:	callq  430b70 <p125_rt_ctor2>
  41e38a:	mov    %r12,%rdi
  41e38d:	mov    %rbx,-0x38a0(%rbp)
  41e394:	mov    %rax,-0x3898(%rbp)
  41e39b:	lea    -0x38a0(%rbp),%rdx
  41e3a2:	mov    $0x8,%esi
  41e3a7:	mov    %rdi,%rbx
  41e3aa:	callq  430b70 <p125_rt_ctor2>
  41e3af:	mov    %rbx,%rdi
  41e3b2:	mov    %rax,-0x38a0(%rbp)
  41e3b9:	mov    0x1b850(%rip),%rcx        # 439c10 <p111_program+0x58>
  41e3c0:	test   $0x4,%rcx
  41e3c7:	jne    41e3df <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x27af>
  41e3c9:	mov    $0x1,%edx
  41e3ce:	lea    -0x38a0(%rbp),%rsi
  41e3d5:	callq  42b4e0 <p111_rt_return>
  41e3da:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e3df:	mov    %rax,0x28(%rdi)
  41e3e3:	movl   $0x1,0x1c(%rdi)
  41e3ea:	mov    0x10(%rdi),%rax
  41e3ee:	mov    %rax,%rcx
  41e3f1:	add    $0xfffffffffffffff8,%rcx
  41e3f5:	mov    %rcx,0x10(%rdi)
  41e3f9:	mov    -0x8(%rax),%rax
  41e3fd:	mov    %eax,0x20(%rdi)
  41e400:	mov    $0x0,%eax
  41e405:	jmpq   41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e40a:	mov    %r13,%rbx
  41e40d:	mov    %rbx,-0x38a0(%rbp)
  41e414:	movabs $0x1002b0000000000,%rax
  41e41e:	mov    %rax,-0x3898(%rbp)
  41e425:	movabs $0x1002b0000000000,%rax
  41e42f:	mov    %rax,-0x3890(%rbp)
  41e436:	lea    -0x38a0(%rbp),%rdx
  41e43d:	mov    $0x2d,%esi
  41e442:	mov    %rdi,%rbx
  41e445:	callq  430df0 <p125_rt_ctor3>
  41e44a:	mov    %rbx,%rdi
  41e44d:	mov    %rax,%rbx
  41e450:	mov    %r12,-0x38a0(%rbp)
  41e457:	movabs $0x1000b0000000000,%rax
  41e461:	mov    %rax,-0x3898(%rbp)
  41e468:	lea    -0x38a0(%rbp),%rdx
  41e46f:	mov    $0x8,%esi
  41e474:	mov    %rdi,%r12
  41e477:	callq  430b70 <p125_rt_ctor2>
  41e47c:	mov    %r12,%rdi
  41e47f:	mov    %rbx,-0x38a0(%rbp)
  41e486:	mov    %rax,-0x3898(%rbp)
  41e48d:	lea    -0x38a0(%rbp),%rdx
  41e494:	mov    $0x8,%esi
  41e499:	mov    %rdi,%rbx
  41e49c:	callq  430b70 <p125_rt_ctor2>
  41e4a1:	mov    %rbx,%rdi
  41e4a4:	mov    %rax,-0x38a0(%rbp)
  41e4ab:	mov    0x1b75e(%rip),%rcx        # 439c10 <p111_program+0x58>
  41e4b2:	test   $0x4,%rcx
  41e4b9:	jne    41e4ce <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x289e>
  41e4bb:	mov    $0x1,%edx
  41e4c0:	lea    -0x38a0(%rbp),%rsi
  41e4c7:	callq  42b4e0 <p111_rt_return>
  41e4cc:	jmp    41e4f4 <p111_FID_36_100_105_114_101_99_116_46_77_97_112_46_115_101_101_107_46_103_111_+0x28c4>
  41e4ce:	mov    %rax,0x28(%rdi)
  41e4d2:	movl   $0x1,0x1c(%rdi)
  41e4d9:	mov    0x10(%rdi),%rax
  41e4dd:	mov    %rax,%rcx
  41e4e0:	add    $0xfffffffffffffff8,%rcx
  41e4e4:	mov    %rcx,0x10(%rdi)
  41e4e8:	mov    -0x8(%rax),%rax
  41e4ec:	mov    %eax,0x20(%rdi)
  41e4ef:	mov    $0x0,%eax
  41e4f4:	pop    %r15
  41e4f6:	pop    %r14
  41e4f8:	pop    %r13
  41e4fa:	pop    %r12
  41e4fc:	pop    %rbx
  41e4fd:	leaveq 
  41e4fe:	retq   

Disassembly of section .fini:
