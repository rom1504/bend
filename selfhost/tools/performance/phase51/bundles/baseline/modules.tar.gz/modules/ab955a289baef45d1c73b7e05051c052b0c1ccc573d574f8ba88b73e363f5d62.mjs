function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $bu$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $seq_$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return true;
    } else {
      return false;
    }
  } else {
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_2 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return false;
    } else {
      const _t_3 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      const _x_0 = _t_1.codePointAt(0);
      const _x_1 = _t_3.codePointAt(0);
      return $Bool$and$((_x_0 === _x_1), ($seq_$(_t_2, _t2_0)));
    }
  }
}

function $starts$(_p_0, _s_0) {
  if (_p_0 === "") {
    return true;
  } else {
    const _t_0 = (_p_0.codePointAt(0) > 0xFFFF ? _p_0.slice(0, 2) : _p_0[0]);
    const _t_1 = (_p_0.codePointAt(0) > 0xFFFF ? _p_0.slice(2) : _p_0.slice(1));
    if (_s_0 === "") {
      return false;
    } else {
      const _t_2 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
      const _t2_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
      const _x_0 = _t_0.codePointAt(0);
      const _x_1 = _t_2.codePointAt(0);
      return $Bool$and$((_x_0 === _x_1), ($starts$(_t_1, _t2_0)));
    }
  }
}

function $sfind$(_p_0, _s_0) {
  if (_s_0 === "") {
    return $sfind$nil$(($starts$(_p_0, "")));
  } else {
    const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
    const _t0_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
    const _t_0 = _t0_0;
    return $sfind$pick$(($sfind$(_p_0, _t_0)), ($starts$(_p_0, (_h_0 + _t_0))));
  }
}

function $sfind$nil$(_z_0) {
  if (_z_0) {
    return {$: "Some", "value": 0};
  } else {
    return {$: "None"};
  }
}

function $sfind$bump$(_o_0) {
  if (_o_0.$ === "None") {
    return {$: "None"};
  } else {
    const _i_0 = _o_0["value"];
    return {$: "Some", "value": ((_i_0 + 1) >>> 0)};
  }
}

function $sfind$pick$(_rec_0, _z_0) {
  if (_z_0) {
    return {$: "Some", "value": 0};
  } else {
    return $sfind$bump$(_rec_0);
  }
}

function $stake$(_n_0, _s_0) {
  if (_n_0 === 0) {
    return "";
  } else {
    const _p_0 = (_n_0 - 1);
    if (_s_0 === "") {
      return "";
    } else {
      const _h_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
      const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
      return (_h_0 + ($stake$(_p_0, _t_0)));
    }
  }
}

function $sdrop$($0, $1) {
  for (;;) {
    {
      const _n_0 = $0;
      const _s_0 = $1;
      if (_n_0 === 0) {
        return _s_0;
      } else {
        const _p_0 = (_n_0 - 1);
        if (_s_0 === "") {
          return "";
        } else {
          const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
          $0 = _p_0;
          $1 = _t_0;
          continue;
        }
      }
    }
  }
}

function $ssplit$push$(_c_0, _ps_0) {
  if (_ps_0.$ === "Nil") {
    return {$: "Con", "head": (_c_0 + ""), "tail": {$: "Nil"}};
  } else {
    const _h_0 = _ps_0["head"];
    const _t_0 = _ps_0["tail"];
    return {$: "Con", "head": (_c_0 + _h_0), "tail": _t_0};
  }
}

function $ssplit$(_sep_0, _s_0) {
  if (_s_0 === "") {
    return {$: "Con", "head": "", "tail": {$: "Nil"}};
  } else {
    const _t_0 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(0, 2) : _s_0[0]);
    const _t_1 = (_s_0.codePointAt(0) > 0xFFFF ? _s_0.slice(2) : _s_0.slice(1));
    const _x_0 = _t_0.codePointAt(0);
    return $ssplit$pick$(_x_0, ($ssplit$(_sep_0, _t_1)), (_x_0 === _sep_0));
  }
}

function $ssplit$pick$(_x_0, _rec_0, _z_0) {
  if (_z_0) {
    return {$: "Con", "head": "", "tail": _rec_0};
  } else {
    return $ssplit$push$(char_new(_x_0), _rec_0);
  }
}

function $sjoin$go$(_sep_0, _t_0, _h_0) {
  if (_t_0.$ === "Nil") {
    return _h_0;
  } else {
    const _h2_0 = _t_0["head"];
    const _t2_0 = _t_0["tail"];
    const _x_0 = ($sjoin$go$(_sep_0, _t2_0, _h2_0));
    const _x_1 = (_sep_0 + _x_0);
    return (_h_0 + _x_1);
  }
}

function $sjoin$(_sep_0, _xs_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return $sjoin$go$(_sep_0, _t_0, _h_0);
  }
}

function $replace1$(_s_0, _at_0, _n_0, _w_0) {
  const _x_0 = ((_at_0 + _n_0) >>> 0);
  const _x_1 = ($sdrop$(_x_0, _s_0));
  const _x_2 = ($stake$(_at_0, _s_0));
  const _x_3 = (_w_0 + _x_1);
  return (_x_2 + _x_3);
}

function $occurs$(_fuel_0, _p_0, _s_0) {
  return $occurs$fin$(($occurs$go$(_fuel_0, _p_0, {$: "Tuple", "fst": 0, "snd": {$: "Tuple", "fst": _s_0, "snd": true}})));
}

function $occurs$step$(_s_0, _acc_0, _o_0) {
  if (_o_0.$ === "Some") {
    const _i_0 = _o_0["value"];
    const _x_0 = ((_i_0 + 1) >>> 0);
    return {$: "Tuple", "fst": ((_acc_0 + 1) >>> 0), "snd": {$: "Tuple", "fst": ($sdrop$(_x_0, _s_0)), "snd": true}};
  } else {
    return {$: "Tuple", "fst": _acc_0, "snd": {$: "Tuple", "fst": _s_0, "snd": false}};
  }
}

function $occurs$go$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _p_0 = $1;
      const _st_0 = $2;
      if (_fuel_0 === 0) {
        return _st_0;
      } else {
        const _f_0 = (_fuel_0 - 1);
        const _acc_0 = _st_0["fst"];
        const _t_0 = _st_0["snd"];
        const _s0_0 = _t_0["fst"];
        const _t_1 = _t_0["snd"];
        if (_t_1) {
          const _s_0 = _s0_0;
          $0 = _f_0;
          $1 = _p_0;
          $2 = ($occurs$step$(_s_0, _acc_0, ($sfind$(_p_0, _s_0))));
          continue;
        } else {
          $0 = _f_0;
          $1 = _p_0;
          $2 = {$: "Tuple", "fst": _acc_0, "snd": {$: "Tuple", "fst": _s0_0, "snd": false}};
          continue;
        }
      }
    }
  }
}

function $occurs$fin$(_st_0) {
  const _acc_0 = _st_0["fst"];
  const _t_0 = _st_0["snd"];
  const _t_1 = _t_0["snd"];
  if (_t_1) {
    return 99;
  } else {
    return _acc_0;
  }
}

function $main$out$() {
  const _b0_0 = ($bu$(($seq_$(($replace1$("banana", ($Maybe$default$(($sfind$("an", "banana")), 99)), 2, "X")), "bXana"))));
  const _b1_0 = ($bu$(($seq_$(($sjoin$("-", ($ssplit$(44, "a,b,c")))), "a-b-c"))));
  const _x_0 = ($occurs$(5, "an", "banana"));
  const _b2_0 = ($bu$((_x_0 === 2)));
  const _x_1 = ($occurs$(5, "zz", "banana"));
  const _b3_0 = ($bu$((_x_1 === 0)));
  const _x_2 = ((_b0_0 + _b1_0) >>> 0);
  const _x_3 = ((_x_2 + _b2_0) >>> 0);
  return ((_x_3 + _b3_0) >>> 0);
}

function $p37$text$repeat$(_n_0, _block_0) {
  if (_n_0 === 0) {
    return "";
  } else {
    const _p_0 = (_n_0 - 1);
    const _x_0 = ($p37$text$repeat$(_p_0, _block_0));
    return (_block_0 + _x_0);
  }
}

function $bench$(_size_0, _seed_0) {
  const _x_0 = ($U32$show$(_seed_0));
  const _x_1 = (_x_0 + ",");
  const _text_0 = ($p37$text$repeat$(_size_0, ("α,β,🍎,中," + _x_1)));
  return $sjoin$("|", ($ssplit$(44, _text_0)));
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $Maybe$default$(_m_0, _d_0) {
  if (_m_0.$ === "None") {
    return _d_0;
  } else {
    const _x_0 = _m_0["value"];
    return _x_0;
  }
}

function $U32$show$(_a_0) {
  const _b_0 = _a_0;
  return $U32$show$if$(_b_0, (_b_0 === 0));
}

function $U32$show$if$(_a_0, _z_0) {
  if (_z_0) {
    return "0";
  } else {
    return $U32$show$go$(10, _a_0, "");
  }
}

function $U32$show$go$($0, $1, $2, $3) {
  let $pc = 0;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}

function $U32$show$fin$($0, $1, $2, $3) {
  let $pc = 1;
  for (;;) switch ($pc) {
    case 0: {
      const _f_0 = $0;
      const _n_0 = $1;
      const _acc_0 = $2;
      if (_f_0 === 0) {
        return _acc_0;
      } else {
        const _g_0 = (_f_0 - 1);
        $0 = _g_0;
        $1 = _acc_0;
        $2 = _n_0;
        $3 = (_n_0 === 0);
        $pc = 1; continue;
      }
    }
    case 1: {
      const _g_0 = $0;
      const _acc_0 = $1;
      const _n_0 = $2;
      const _z_0 = $3;
      if (_z_0) {
        return _acc_0;
      } else {
        const _x_0 = (10 === 0 ? _n_0 : _n_0 % 10);
        $0 = _g_0;
        $1 = (10 === 0 ? 0 : (_n_0 / 10) >>> 0);
        $2 = (char_new(((48 + _x_0) >>> 0)) + _acc_0);
        $pc = 0; continue;
      }
    }
  }
}
export default {
  "bu": run_lib((a0) => { const r = (run_loop($bu$((a0)))); (a0); return r; }, 1),
  "seq_": run_lib((a0, a1) => { const r = (run_loop($seq_$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "starts": run_lib((a0, a1) => { const r = (run_loop($starts$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "sfind": run_lib((a0, a1) => { const r = (run_loop($sfind$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "sfind.nil": run_lib((a0) => { const r = (run_loop($sfind$nil$((a0)))); (a0); return r; }, 1),
  "sfind.bump": run_lib((a0) => { const r = (run_loop($sfind$bump$((a0)))); (a0); return r; }, 1),
  "sfind.pick": run_lib((a0, a1) => { const r = (run_loop($sfind$pick$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "stake": run_lib((a0, a1) => { const r = (run_loop($stake$(nat_host(a0), (a1)))); BigInt(a0); (a1); return r; }, 2),
  "sdrop": run_lib((a0, a1) => { const r = (run_loop($sdrop$(nat_host(a0), (a1)))); BigInt(a0); (a1); return r; }, 2),
  "ssplit.push": run_lib((a0, a1) => { const r = (run_loop($ssplit$push$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "ssplit": run_lib((a0, a1) => { const r = (run_loop($ssplit$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "ssplit.pick": run_lib((a0, a1, a2) => { const r = (run_loop($ssplit$pick$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "sjoin.go": run_lib((a0, a1, a2) => { const r = (run_loop($sjoin$go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "sjoin": run_lib((a0, a1) => { const r = (run_loop($sjoin$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "replace1": run_lib((a0, a1, a2, a3) => { const r = (run_loop($replace1$((a0), (a1), (a2), (a3)))); (a0); (a1); (a2); (a3); return r; }, 4),
  "occurs": run_lib((a0, a1, a2) => { const r = (run_loop($occurs$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "occurs.step": run_lib((a0, a1, a2) => { const r = (run_loop($occurs$step$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "occurs.go": run_lib((a0, a1, a2) => { const r = (run_loop($occurs$go$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "occurs.fin": run_lib((a0) => { const r = (run_loop($occurs$fin$((a0)))); (a0); return r; }, 1),
  "main.out": run_lib(() => { const r = (run_loop($main$out$()));  return r; }, 0),
  "p37.text.repeat": run_lib((a0, a1) => { const r = (run_loop($p37$text$repeat$(nat_host(a0), (a1)))); BigInt(a0); (a1); return r; }, 2),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
};
