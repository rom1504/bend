
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/coverage-map-churn-128/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000406ef3 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>:
  406ef3:	push   %rbp
  406ef4:	mov    %rsp,%rbp
  406ef7:	sub    $0xa30,%rsp
  406efe:	mov    %r12,-0x10(%rbp)
  406f02:	mov    %rbx,-0x8(%rbp)
  406f06:	mov    %r13,-0x18(%rbp)
  406f0a:	mov    %r14,-0x20(%rbp)
  406f0e:	mov    %rdi,%rax
  406f11:	mov    %rax,%r12
  406f14:	mov    %rsi,%rax
  406f17:	mov    %rax,%rdi
  406f1a:	mov    %rdx,%rax
  406f1d:	mov    %rax,%rbx
  406f20:	mov    %rcx,%rax
  406f23:	mov    %rax,%r13
  406f26:	mov    %rdi,%rsi
  406f29:	shr    $0x28,%rsi
  406f2d:	and    $0xffff,%rsi
  406f34:	movabs $0x18,%r11
  406f3e:	cmp    %r11,%rsi
  406f41:	jne    406f8b <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x98>
  406f47:	mov    %r12,%rdi
  406f4a:	movabs $0x1,%rsi
  406f54:	mov    %esi,%esi
  406f56:	lea    -0x840(%rbp),%rdx
  406f5d:	movabs $0x0,%rcx
  406f67:	mov    %ecx,%ecx
  406f69:	xor    %eax,%eax
  406f6b:	callq  44bbc0 <p111_rt_special_ctor>
  406f70:	mov    %rax,%rdi
  406f73:	mov    %rdi,%rax
  406f76:	mov    -0x10(%rbp),%r12
  406f7a:	mov    -0x8(%rbp),%rbx
  406f7e:	mov    -0x18(%rbp),%r13
  406f82:	mov    -0x20(%rbp),%r14
  406f86:	mov    %rbp,%rsp
  406f89:	pop    %rbp
  406f8a:	retq   
  406f8b:	mov    %rdi,%rsi
  406f8e:	shr    $0x28,%rsi
  406f92:	and    $0xffff,%rsi
  406f99:	movabs $0x19,%r11
  406fa3:	cmp    %r11,%rsi
  406fa6:	jne    407261 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x36e>
  406fac:	mov    %rdi,%rsi
  406faf:	shr    $0x38,%rsi
  406fb3:	and    $0x7f,%rsi
  406fba:	mov    %rsi,%rdx
  406fbd:	cmp    $0x2,%rdx
  406fc4:	sete   %dl
  406fc7:	movzbl %dl,%edx
  406fca:	mov    %rdi,%rsi
  406fcd:	shr    $0x28,%rsi
  406fd1:	and    $0xffff,%rsi
  406fd8:	movabs $0x19,%r11
  406fe2:	cmp    %r11,%rsi
  406fe5:	sete   %sil
  406fe9:	movzbl %sil,%esi
  406fed:	and    %edx,%esi
  406fef:	mov    %rsi,%r10
  406ff2:	test   %r10d,%r10d
  406ff5:	je     407072 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x17f>
  406ffb:	mov    (%r12),%rsi
  406fff:	movabs $0xffffffffff,%r11
  407009:	mov    %rdi,%rdx
  40700c:	and    %r11,%rdx
  40700f:	shr    $0x3f,%rdi
  407013:	cmp    $0x0,%rdi
  40701a:	je     40703b <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x148>
  407020:	mov    (%rsi,%rdx,8),%r8d
  407024:	mov    0x4(%rsi,%rdx,8),%edi
  407028:	shl    $0x20,%rdi
  40702c:	or     %r8,%rdi
  40702f:	mov    %rdi,%rdx
  407032:	shr    $0x18,%rdx
  407036:	jmpq   40703b <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x148>
  40703b:	mov    %rdx,%rdi
  40703e:	shl    $0x3,%rdi
  407042:	mov    %rdi,%r11
  407045:	mov    %rsi,%rdi
  407048:	add    %r11,%rdi
  40704b:	mov    (%rdi),%rsi
  40704e:	lea    -0x840(%rbp),%r10
  407055:	mov    %rsi,%r11
  407058:	mov    %r11,(%r10)
  40705b:	mov    0x8(%rdi),%rdi
  40705f:	lea    -0x840(%rbp),%r10
  407066:	mov    %rdi,%r11
  407069:	mov    %r11,0x8(%r10)
  40706d:	jmpq   4070d9 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1e6>
  407072:	mov    %r12,%r10
  407075:	mov    %r10,0x28(%rsp)
  40707a:	mov    %rdi,%r10
  40707d:	mov    %r10,0x30(%rsp)
  407082:	lea    -0x840(%rbp),%r10
  407089:	mov    %r10,0x38(%rsp)
  40708e:	movabs $0x19,%r10
  407098:	mov    %r10d,%r10d
  40709b:	mov    %r10,0x40(%rsp)
  4070a0:	movabs $0x2,%r10
  4070aa:	mov    %r10d,%r10d
  4070ad:	mov    %r10,0x48(%rsp)
  4070b2:	mov    0x28(%rsp),%rdi
  4070b7:	mov    0x30(%rsp),%rsi
  4070bc:	mov    0x38(%rsp),%rdx
  4070c1:	mov    0x40(%rsp),%rcx
  4070c6:	mov    0x48(%rsp),%r8
  4070cb:	xor    %eax,%eax
  4070cd:	callq  44f250 <p118_rt_borrow_fields>
  4070d2:	mov    %rax,-0x968(%rbp)
  4070d9:	lea    -0x840(%rbp),%r10
  4070e0:	mov    (%r10),%r14
  4070e3:	lea    -0x840(%rbp),%r10
  4070ea:	mov    0x8(%r10),%rdi
  4070ee:	cmp    $0x0,%rbx
  4070f5:	jne    407255 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x362>
  4070fb:	cmp    %r14,%r14
  4070fe:	jne    407219 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x326>
  407104:	cmp    $0x0,%r13
  40710b:	jne    407155 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x262>
  407111:	mov    %r12,%rdi
  407114:	movabs $0x2,%rsi
  40711e:	mov    %esi,%esi
  407120:	lea    -0x840(%rbp),%rdx
  407127:	movabs $0x0,%rcx
  407131:	mov    %ecx,%ecx
  407133:	xor    %eax,%eax
  407135:	callq  44bbc0 <p111_rt_special_ctor>
  40713a:	mov    %rax,%rdi
  40713d:	mov    %rdi,%rax
  407140:	mov    -0x10(%rbp),%r12
  407144:	mov    -0x8(%rbp),%rbx
  407148:	mov    -0x18(%rbp),%r13
  40714c:	mov    -0x20(%rbp),%r14
  407150:	mov    %rbp,%rsp
  407153:	pop    %rbp
  407154:	retq   
  407155:	mov    %r13,%rdi
  407158:	sub    $0x1,%rdi
  40715f:	lea    -0x840(%rbp),%r10
  407166:	movabs $0x1f,%r11
  407170:	mov    %r11,(%r10)
  407173:	lea    -0x840(%rbp),%r10
  40717a:	mov    %rdi,%r11
  40717d:	mov    %r11,0x8(%r10)
  407181:	mov    %r12,%rdi
  407184:	movabs $0x3f,%rsi
  40718e:	mov    %esi,%esi
  407190:	lea    -0x840(%rbp),%rdx
  407197:	movabs $0x2,%rcx
  4071a1:	mov    %ecx,%ecx
  4071a3:	xor    %eax,%eax
  4071a5:	callq  44a9e0 <p111_rt_op>
  4071aa:	mov    %rax,%rdi
  4071ad:	mov    %r14d,%r14d
  4071b0:	mov    %rdi,%rsi
  4071b3:	cmp    $0x20,%rdi
  4071ba:	setb   %dil
  4071be:	movzbl %dil,%edi
  4071c2:	mov    %rdi,%r10
  4071c5:	test   %r10d,%r10d
  4071c8:	je     4071e1 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x2ee>
  4071ce:	mov    %rsi,%r11
  4071d1:	mov    %r14,%rdi
  4071d4:	mov    %r11d,%ecx
  4071d7:	shr    %cl,%rdi
  4071da:	mov    %edi,%edi
  4071dc:	jmpq   4071eb <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x2f8>
  4071e1:	movabs $0x0,%rdi
  4071eb:	and    $0x1,%rdi
  4071f2:	cmp    $0x0,%rdi
  4071f9:	setne  %dil
  4071fd:	movzbl %dil,%edi
  407201:	mov    %rdi,%rax
  407204:	mov    -0x10(%rbp),%r12
  407208:	mov    -0x8(%rbp),%rbx
  40720c:	mov    -0x18(%rbp),%r13
  407210:	mov    -0x20(%rbp),%r14
  407214:	mov    %rbp,%rsp
  407217:	pop    %rbp
  407218:	retq   
  407219:	mov    %r12,%rdi
  40721c:	movabs $0x4,%rsi
  407226:	mov    %esi,%esi
  407228:	xor    %eax,%eax
  40722a:	callq  44a9c0 <p111_rt_fail>
  40722f:	mov    %rax,-0x9a0(%rbp)
  407236:	movabs $0x0,%rax
  407240:	mov    -0x10(%rbp),%r12
  407244:	mov    -0x8(%rbp),%rbx
  407248:	mov    -0x18(%rbp),%r13
  40724c:	mov    -0x20(%rbp),%r14
  407250:	mov    %rbp,%rsp
  407253:	pop    %rbp
  407254:	retq   
  407255:	sub    $0x1,%rbx
  40725c:	jmpq   406f26 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x33>
  407261:	mov    %r12,%rdi
  407264:	movabs $0x4,%rsi
  40726e:	mov    %esi,%esi
  407270:	xor    %eax,%eax
  407272:	callq  44a9c0 <p111_rt_fail>
  407277:	mov    %rax,-0x9a0(%rbp)
  40727e:	movabs $0x0,%rax
  407288:	mov    -0x10(%rbp),%r12
  40728c:	mov    -0x8(%rbp),%rbx
  407290:	mov    -0x18(%rbp),%r13
  407294:	mov    -0x20(%rbp),%r14
  407298:	mov    %rbp,%rsp
  40729b:	pop    %rbp
  40729c:	retq   

Disassembly of section .fini:
