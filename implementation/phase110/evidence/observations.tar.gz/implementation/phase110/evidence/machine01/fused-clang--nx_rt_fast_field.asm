
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402cf0 <nx_rt_fast_field>:
  402cf0:	mov    %esi,%ecx
  402cf2:	mov    $0xfffffffe,%eax
  402cf7:	rol    %cl,%eax
  402cf9:	add    $0x2,%rcx
  402cfd:	and    %eax,0x20(%rdi)
  402d00:	mov    (%rdi,%rcx,8),%rax
  402d04:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402d0c:	retq   

Disassembly of section .fini:
