
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403210 <nx_rt_fast_build2>:
  403210:	endbr64 
  403214:	push   %rbp
  403215:	mov    %rsp,%rbp
  403218:	sub    $0x18,%rsp
  40321c:	push   %rbx
  40321d:	push   %r12
  40321f:	push   %r13
  403221:	mov    %rcx,%r13
  403224:	mov    %rdx,%r12
  403227:	mov    %esi,%ebx
  403229:	mov    (%rdi),%rax
  40322c:	mov    %rax,-0x10(%rbp)
  403230:	mov    0x8(%rdi),%rax
  403234:	mov    %rax,-0x8(%rbp)
  403238:	mov    $0x2,%edi
  40323d:	callq  4015a0 <cls_fit>
  403242:	mov    %eax,%edx
  403244:	mov    -0x10(%rbp),%rdi
  403248:	mov    -0x8(%rbp),%rsi
  40324c:	callq  4019b0 <heap_alloc>
  403251:	mov    %r13,%r8
  403254:	mov    %r12,%rcx
  403257:	mov    %ebx,%edx
  403259:	mov    %rax,%r9
  40325c:	mov    -0x10(%rbp),%rdi
  403260:	mov    -0x8(%rbp),%rsi
  403264:	callq  402e80 <nx_construct2>
  403269:	pop    %r13
  40326b:	pop    %r12
  40326d:	pop    %rbx
  40326e:	leaveq 
  40326f:	retq   

Disassembly of section .fini:
