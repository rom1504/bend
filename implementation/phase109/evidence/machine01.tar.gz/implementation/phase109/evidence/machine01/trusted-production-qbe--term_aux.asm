
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401b30 <term_aux>:
  401b30:	endbr64 
  401b34:	mov    %rdi,%rax
  401b37:	shr    $0x28,%rax
  401b3b:	and    $0xffff,%rax
  401b41:	retq   

Disassembly of section .fini:
