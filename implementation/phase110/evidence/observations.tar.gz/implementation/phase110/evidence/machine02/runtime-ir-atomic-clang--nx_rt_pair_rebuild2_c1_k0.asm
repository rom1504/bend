
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403b90 <nx_rt_pair_rebuild2_c1_k0>:
  403b90:	push   %r15
  403b92:	push   %r14
  403b94:	push   %r13
  403b96:	push   %r12
  403b98:	mov    %rdx,%r12
  403b9b:	push   %rbp
  403b9c:	push   %rbx
  403b9d:	movabs $0xffffffffff,%rbx
  403ba7:	and    %rsi,%rbx
  403baa:	lea    0x0(,%rbx,8),%rdx
  403bb2:	sub    $0x18,%rsp
  403bb6:	mov    (%rdi),%rbp
  403bb9:	mov    0x8(%rdi),%r15
  403bbd:	lea    0x0(%rbp,%rdx,1),%rax
  403bc2:	test   %rsi,%rsi
  403bc5:	js     403c80 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  403bcb:	mov    (%rax),%r14
  403bce:	mov    0x8(%rbp,%rdx,1),%r13
  403bd3:	cmp    $0x310817f,%rbx
  403bda:	jbe    403c50 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  403bdc:	lea    0x0(%rbp,%rbx,8),%r8
  403be1:	mov    %r14,%rax
  403be4:	shr    $0x38,%rax
  403be8:	and    $0x7f,%eax
  403beb:	cmp    $0x2,%rax
  403bef:	je     403c30 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403bf1:	mov    %r12,%rax
  403bf4:	mov    %r14,(%r8)
  403bf7:	lea    0x8(%rbp,%rbx,8),%r14
  403bfc:	shr    $0x38,%rax
  403c00:	and    $0x7f,%eax
  403c03:	cmp    $0x2,%rax
  403c07:	je     403c40 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403c09:	movabs $0x200010000000000,%rax
  403c13:	mov    %r12,(%r14)
  403c16:	mov    %r13,%rdx
  403c19:	add    $0x18,%rsp
  403c1d:	or     %rbx,%rax
  403c20:	pop    %rbx
  403c21:	pop    %rbp
  403c22:	pop    %r12
  403c24:	pop    %r13
  403c26:	pop    %r14
  403c28:	pop    %r15
  403c2a:	retq   
  403c2b:	nopl   0x0(%rax,%rax,1)
  403c30:	test   %r14,%r14
  403c33:	js     403bf1 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403c35:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  403c3a:	nopw   0x0(%rax,%rax,1)
  403c40:	test   %r12,%r12
  403c43:	js     403c09 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403c45:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  403c4a:	nopw   0x0(%rax,%rax,1)
  403c50:	mov    0x8(%r15),%rbx
  403c54:	test   %rbx,%rbx
  403c57:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  403c5d:	lea    0x0(%rbp,%rbx,8),%r8
  403c62:	mov    (%r8),%rax
  403c65:	subq   $0x2,0x108(%r15)
  403c6d:	mov    %rax,0x8(%r15)
  403c71:	jmpq   403be1 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403c76:	nopw   %cs:0x0(%rax,%rax,1)
  403c80:	mov    0x4(%rax),%edx
  403c83:	mov    (%rax),%ecx
  403c85:	shl    $0x20,%rdx
  403c89:	or     %rcx,%rdx
  403c8c:	mov    %rdx,%rcx
  403c8f:	and    $0xffffff,%edx
  403c95:	shr    $0x18,%rcx
  403c99:	lea    0x8(,%rcx,8),%rdi
  403ca1:	lea    0x0(%rbp,%rdi,1),%r8
  403ca6:	lea    -0x8(%rbp,%rdi,1),%rdi
  403cab:	cmp    $0x1,%rdx
  403caf:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403cb5:	mov    (%rax),%edx
  403cb7:	mov    (%r15),%rdx
  403cba:	mov    (%rdi),%r14
  403cbd:	mov    (%r8),%r13
  403cc0:	mov    %rdx,(%rax)
  403cc3:	mov    0x100(%r15),%rax
  403cca:	mov    0x3e508(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403cd0:	mov    %rbx,(%r15)
  403cd3:	add    $0x1,%rax
  403cd7:	mov    %rax,0x100(%r15)
  403cde:	cmp    %rdx,%rax
  403ce1:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403ce7:	mov    %rcx,%rbx
  403cea:	jmpq   403bd3 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
