function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $b2u$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $sel$go$(_x_0, _y_0, _z_0) {
  if (_z_0) {
    return _x_0;
  } else {
    return _y_0;
  }
}

function $sel$(_t_0, _x_0, _y_0) {
  return $sel$go$(_x_0, _y_0, (_t_0 === 0));
}

function $asr8$(_v_0) {
  const _x_0 = (8 >= 32 ? 0 : (_v_0 >>> 8) >>> 0);
  const _x_1 = ($sel$((31 >= 32 ? 0 : (_v_0 >>> 31) >>> 0), 0, 4278190080));
  return ((_x_0 | _x_1) >>> 0);
}

function $mit$($0, $1, $2, $3, $4, $5, $6) {
  for (;;) {
    {
      const _n_0 = $0;
      const _cr_0 = $1;
      const _ci_0 = $2;
      const _zr_0 = $3;
      const _zi_0 = $4;
      const _esc_0 = $5;
      const _it_0 = $6;
      if (_n_0 === 0) {
        return _it_0;
      } else {
        const _p_0 = (_n_0 - 1);
        const _r2_0 = ($asr8$((Math.imul(_zr_0, _zr_0) >>> 0)));
        const _i2_0 = ($asr8$((Math.imul(_zi_0, _zi_0) >>> 0)));
        const _x_0 = ((_r2_0 + _i2_0) >>> 0);
        const _x_1 = ($b2u$((_x_0 > 1024)));
        const _e2_0 = ((_esc_0 | _x_1) >>> 0);
        const _x_2 = ((_r2_0 - _i2_0) >>> 0);
        const _nzr_0 = ((_x_2 + _cr_0) >>> 0);
        const _x_3 = (Math.imul(_zr_0, _zi_0) >>> 0);
        const _x_4 = ($asr8$((Math.imul(2, _x_3) >>> 0)));
        const _nzi_0 = ((_x_4 + _ci_0) >>> 0);
        const _sr_0 = ($sel$(_e2_0, _nzr_0, _zr_0));
        const _si_0 = ($sel$(_e2_0, _nzi_0, _zi_0));
        const _x_5 = ($b2u$((_e2_0 === 0)));
        $0 = _p_0;
        $1 = _cr_0;
        $2 = _ci_0;
        $3 = _sr_0;
        $4 = _si_0;
        $5 = _e2_0;
        $6 = ((_it_0 + _x_5) >>> 0);
        continue;
      }
    }
  }
}

function $pix$(_id_0, _tn_0) {
  const _x_0 = ((_id_0 & 4095) >>> 0);
  const _x_1 = (Math.imul(_x_0, 768) >>> 0);
  const _x_2 = (4096 === 0 ? 0 : (_x_1 / 4096) >>> 0);
  const _cr_0 = ((_x_2 - 512) >>> 0);
  const _x_3 = (12 >= 32 ? 0 : (_id_0 >>> 12) >>> 0);
  const _x_4 = (Math.imul(_x_3, 768) >>> 0);
  const _x_5 = (4096 === 0 ? 0 : (_x_4 / 4096) >>> 0);
  const _ci_0 = ((_x_5 - 384) >>> 0);
  return $mit$(_tn_0, _cr_0, _ci_0, 0, 0, 0, 0);
}

function $bkt$(_it_0, _tn_0) {
  const _x_0 = (Math.imul(_it_0, 8) >>> 0);
  const _x_1 = (_tn_0 >>> 0);
  const _bq_0 = (_x_1 === 0 ? 0 : (_x_0 / _x_1) >>> 0);
  return $sel$(($b2u$((_bq_0 > 7))), _bq_0, 7);
}

function $hchunk$($0, $1, $2, $3, $4, $5, $6, $7, $8, $9, $10) {
  for (;;) {
    {
      const _j_0 = $0;
      const _i_0 = $1;
      const _tn_0 = $2;
      const _h0_0 = $3;
      const _h1_0 = $4;
      const _h2_0 = $5;
      const _h3_0 = $6;
      const _h4_0 = $7;
      const _h5_0 = $8;
      const _h6_0 = $9;
      const _h7_0 = $10;
      if (_j_0 === 0) {
        return {$: "Hl", "h0": _h0_0, "h1": _h1_0, "h2": _h2_0, "h3": _h3_0, "h4": _h4_0, "h5": _h5_0, "h6": _h6_0, "h7": _h7_0};
      } else {
        const _p_0 = (_j_0 - 1);
        const _x_0 = (_p_0 >>> 0);
        const _it_0 = ($pix$(((_i_0 + _x_0) >>> 0), _tn_0));
        const _bk_0 = ($bkt$(_it_0, _tn_0));
        const _m0_0 = ($b2u$((_bk_0 === 0)));
        const _m1_0 = ($b2u$((_bk_0 === 1)));
        const _m2_0 = ($b2u$((_bk_0 === 2)));
        const _m3_0 = ($b2u$((_bk_0 === 3)));
        const _m4_0 = ($b2u$((_bk_0 === 4)));
        const _m5_0 = ($b2u$((_bk_0 === 5)));
        const _m6_0 = ($b2u$((_bk_0 === 6)));
        const _m7_0 = ($b2u$((_bk_0 === 7)));
        $0 = _p_0;
        $1 = _i_0;
        $2 = _tn_0;
        $3 = ((_h0_0 + _m0_0) >>> 0);
        $4 = ((_h1_0 + _m1_0) >>> 0);
        $5 = ((_h2_0 + _m2_0) >>> 0);
        $6 = ((_h3_0 + _m3_0) >>> 0);
        $7 = ((_h4_0 + _m4_0) >>> 0);
        $8 = ((_h5_0 + _m5_0) >>> 0);
        $9 = ((_h6_0 + _m6_0) >>> 0);
        $10 = ((_h7_0 + _m7_0) >>> 0);
        continue;
      }
    }
  }
}

function $hzip$(_a_0, _b_0) {
  const _a0_0 = _a_0["h0"];
  const _a1_0 = _a_0["h1"];
  const _a2_0 = _a_0["h2"];
  const _a3_0 = _a_0["h3"];
  const _a4_0 = _a_0["h4"];
  const _a5_0 = _a_0["h5"];
  const _a6_0 = _a_0["h6"];
  const _a7_0 = _a_0["h7"];
  const _b0_0 = _b_0["h0"];
  const _b1_0 = _b_0["h1"];
  const _b2_0 = _b_0["h2"];
  const _b3_0 = _b_0["h3"];
  const _b4_0 = _b_0["h4"];
  const _b5_0 = _b_0["h5"];
  const _b6_0 = _b_0["h6"];
  const _b7_0 = _b_0["h7"];
  return {$: "Hl", "h0": ((_a0_0 + _b0_0) >>> 0), "h1": ((_a1_0 + _b1_0) >>> 0), "h2": ((_a2_0 + _b2_0) >>> 0), "h3": ((_a3_0 + _b3_0) >>> 0), "h4": ((_a4_0 + _b4_0) >>> 0), "h5": ((_a5_0 + _b5_0) >>> 0), "h6": ((_a6_0 + _b6_0) >>> 0), "h7": ((_a7_0 + _b7_0) >>> 0)};
}

function $hfold$(_d_0, _i_0, _tn_0) {
  if (_d_0 === 0) {
    return $hchunk$(64, _i_0, _tn_0, 0, 0, 0, 0, 0, 0, 0, 0);
  } else {
    const _p_0 = (_d_0 - 1);
    const _a_0 = ($hfold$(_p_0, _i_0, _tn_0));
    const _x_0 = (_p_0 >= 32 ? 0 : (64 << _p_0) >>> 0);
    const _b_0 = ($hfold$(_p_0, ((_i_0 + _x_0) >>> 0), _tn_0));
    return $hzip$(_a_0, _b_0);
  }
}

function $cdf$(_h_0) {
  const _h0_0 = _h_0["h0"];
  const _h1_0 = _h_0["h1"];
  const _h2_0 = _h_0["h2"];
  const _h3_0 = _h_0["h3"];
  const _h4_0 = _h_0["h4"];
  const _h5_0 = _h_0["h5"];
  const _h6_0 = _h_0["h6"];
  const _h7_0 = _h_0["h7"];
  const _c1_0 = ((_h0_0 + _h1_0) >>> 0);
  const _c2_0 = ((_c1_0 + _h2_0) >>> 0);
  const _c3_0 = ((_c2_0 + _h3_0) >>> 0);
  const _c4_0 = ((_c3_0 + _h4_0) >>> 0);
  const _c5_0 = ((_c4_0 + _h5_0) >>> 0);
  const _c6_0 = ((_c5_0 + _h6_0) >>> 0);
  const _c7_0 = ((_c6_0 + _h7_0) >>> 0);
  const _x_0 = (Math.imul(_h0_0, 255) >>> 0);
  const _x_1 = (Math.imul(_c1_0, 255) >>> 0);
  const _x_2 = (Math.imul(_c2_0, 255) >>> 0);
  const _x_3 = (Math.imul(_c3_0, 255) >>> 0);
  const _x_4 = (Math.imul(_c4_0, 255) >>> 0);
  const _x_5 = (Math.imul(_c5_0, 255) >>> 0);
  const _x_6 = (Math.imul(_c6_0, 255) >>> 0);
  const _x_7 = (Math.imul(_c7_0, 255) >>> 0);
  return {$: "Lut", "k0": (_c7_0 === 0 ? 0 : (_x_0 / _c7_0) >>> 0), "k1": (_c7_0 === 0 ? 0 : (_x_1 / _c7_0) >>> 0), "k2": (_c7_0 === 0 ? 0 : (_x_2 / _c7_0) >>> 0), "k3": (_c7_0 === 0 ? 0 : (_x_3 / _c7_0) >>> 0), "k4": (_c7_0 === 0 ? 0 : (_x_4 / _c7_0) >>> 0), "k5": (_c7_0 === 0 ? 0 : (_x_5 / _c7_0) >>> 0), "k6": (_c7_0 === 0 ? 0 : (_x_6 / _c7_0) >>> 0), "k7": (_c7_0 === 0 ? 0 : (_x_7 / _c7_0) >>> 0)};
}

function $rpix$(_i_0, _tn_0, _k0_0, _k1_0, _k2_0, _k3_0, _k4_0, _k5_0, _k6_0, _k7_0) {
  const _it_0 = ($pix$(_i_0, _tn_0));
  const _bk_0 = ($bkt$(_it_0, _tn_0));
  const _x_0 = ($b2u$((_bk_0 === 0)));
  const _x_1 = ($b2u$((_bk_0 === 1)));
  const _x_2 = ($b2u$((_bk_0 === 2)));
  const _x_3 = ($b2u$((_bk_0 === 3)));
  const _x_4 = ($b2u$((_bk_0 === 4)));
  const _x_5 = ($b2u$((_bk_0 === 5)));
  const _x_6 = ($b2u$((_bk_0 === 6)));
  const _x_7 = ($b2u$((_bk_0 === 7)));
  const _x_8 = (Math.imul(_x_6, _k6_0) >>> 0);
  const _x_9 = (Math.imul(_x_7, _k7_0) >>> 0);
  const _x_10 = (Math.imul(_x_5, _k5_0) >>> 0);
  const _x_11 = ((_x_8 + _x_9) >>> 0);
  const _x_12 = (Math.imul(_x_4, _k4_0) >>> 0);
  const _x_13 = ((_x_10 + _x_11) >>> 0);
  const _x_14 = (Math.imul(_x_3, _k3_0) >>> 0);
  const _x_15 = ((_x_12 + _x_13) >>> 0);
  const _x_16 = (Math.imul(_x_2, _k2_0) >>> 0);
  const _x_17 = ((_x_14 + _x_15) >>> 0);
  const _x_18 = (Math.imul(_x_1, _k1_0) >>> 0);
  const _x_19 = ((_x_16 + _x_17) >>> 0);
  const _x_20 = (Math.imul(_x_0, _k0_0) >>> 0);
  const _x_21 = ((_x_18 + _x_19) >>> 0);
  const _col_0 = ((_x_20 + _x_21) >>> 0);
  const _x_22 = (Math.imul(_i_0, 2654435761) >>> 0);
  const _x_23 = ((_x_22 + 1) >>> 0);
  const _x_24 = (Math.imul(_col_0, _x_23) >>> 0);
  return ((_x_24 + _it_0) >>> 0);
}

function $rcol$(_d_0, _i_0, _tn_0, _k0_0, _k1_0, _k2_0, _k3_0, _k4_0, _k5_0, _k6_0, _k7_0) {
  if (_d_0 === 0) {
    return $rpix$(_i_0, _tn_0, _k0_0, _k1_0, _k2_0, _k3_0, _k4_0, _k5_0, _k6_0, _k7_0);
  } else {
    const _p_0 = (_d_0 - 1);
    const _a_0 = ($rcol$(_p_0, _i_0, _tn_0, _k0_0, _k1_0, _k2_0, _k3_0, _k4_0, _k5_0, _k6_0, _k7_0));
    const _x_0 = (_p_0 >= 32 ? 0 : (1 << _p_0) >>> 0);
    const _b_0 = ($rcol$(_p_0, ((_i_0 + _x_0) >>> 0), _tn_0, _k0_0, _k1_0, _k2_0, _k3_0, _k4_0, _k5_0, _k6_0, _k7_0));
    return ((_a_0 + _b_0) >>> 0);
  }
}

function $rend$mix$(_hd_0, _tn_0, _lut_0) {
  const _l0_0 = _lut_0["k0"];
  const _l1_0 = _lut_0["k1"];
  const _l2_0 = _lut_0["k2"];
  const _l3_0 = _lut_0["k3"];
  const _l4_0 = _lut_0["k4"];
  const _l5_0 = _lut_0["k5"];
  const _l6_0 = _lut_0["k6"];
  const _l7_0 = _lut_0["k7"];
  const _x_0 = (Math.imul(_l0_0, 2654435761) >>> 0);
  const _m1_0 = ((_x_0 + _l1_0) >>> 0);
  const _x_1 = (Math.imul(_m1_0, 2654435761) >>> 0);
  const _m2_0 = ((_x_1 + _l2_0) >>> 0);
  const _x_2 = (Math.imul(_m2_0, 2654435761) >>> 0);
  const _m3_0 = ((_x_2 + _l3_0) >>> 0);
  const _x_3 = (Math.imul(_m3_0, 2654435761) >>> 0);
  const _m4_0 = ((_x_3 + _l4_0) >>> 0);
  const _x_4 = (Math.imul(_m4_0, 2654435761) >>> 0);
  const _m5_0 = ((_x_4 + _l5_0) >>> 0);
  const _x_5 = (Math.imul(_m5_0, 2654435761) >>> 0);
  const _m6_0 = ((_x_5 + _l6_0) >>> 0);
  const _x_6 = (Math.imul(_m6_0, 2654435761) >>> 0);
  const _m7_0 = ((_x_6 + _l7_0) >>> 0);
  const _r_0 = ($rcol$(nat_chk(_hd_0 + 6), 0, _tn_0, _l0_0, _l1_0, _l2_0, _l3_0, _l4_0, _l5_0, _l6_0, _l7_0));
  const _x_7 = (Math.imul(_m7_0, 2654435761) >>> 0);
  return ((_x_7 + _r_0) >>> 0);
}

function $rend$(_hd_0, _tn_0) {
  return $rend$mix$(_hd_0, _tn_0, ($cdf$(($hfold$(_hd_0, 0, _tn_0)))));
}

function $its$() {
  return 51;
}

function $bench$(_size_0, _seed_0) {
  return $rend$(_size_0, 7);
}
export default {
  "b2u": run_lib((a0) => { const r = (run_loop($b2u$((a0)))); (a0); return r; }, 1),
  "sel.go": run_lib((a0, a1, a2) => { const r = (run_loop($sel$go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "sel": run_lib((a0, a1, a2) => { const r = (run_loop($sel$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "asr8": run_lib((a0) => { const r = (run_loop($asr8$((a0)))); (a0); return r; }, 1),
  "mit": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($mit$(nat_host(a0), (a1), (a2), (a3), (a4), (a5), (a6)))); BigInt(a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "pix": run_lib((a0, a1) => { const r = (run_loop($pix$((a0), nat_host(a1)))); (a0); BigInt(a1); return r; }, 2),
  "bkt": run_lib((a0, a1) => { const r = (run_loop($bkt$((a0), nat_host(a1)))); (a0); BigInt(a1); return r; }, 2),
  "hchunk": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10) => { const r = (run_loop($hchunk$(nat_host(a0), (a1), nat_host(a2), (a3), (a4), (a5), (a6), (a7), (a8), (a9), (a10)))); BigInt(a0); (a1); BigInt(a2); (a3); (a4); (a5); (a6); (a7); (a8); (a9); (a10); return r; }, 11),
  "hzip": run_lib((a0, a1) => { const r = (run_loop($hzip$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "hfold": run_lib((a0, a1, a2) => { const r = (run_loop($hfold$(nat_host(a0), (a1), nat_host(a2)))); BigInt(a0); (a1); BigInt(a2); return r; }, 3),
  "cdf": run_lib((a0) => { const r = (run_loop($cdf$((a0)))); (a0); return r; }, 1),
  "rpix": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9) => { const r = (run_loop($rpix$((a0), nat_host(a1), (a2), (a3), (a4), (a5), (a6), (a7), (a8), (a9)))); (a0); BigInt(a1); (a2); (a3); (a4); (a5); (a6); (a7); (a8); (a9); return r; }, 10),
  "rcol": run_lib((a0, a1, a2, a3, a4, a5, a6, a7, a8, a9, a10) => { const r = (run_loop($rcol$(nat_host(a0), (a1), nat_host(a2), (a3), (a4), (a5), (a6), (a7), (a8), (a9), (a10)))); BigInt(a0); (a1); BigInt(a2); (a3); (a4); (a5); (a6); (a7); (a8); (a9); (a10); return r; }, 11),
  "rend.mix": run_lib((a0, a1, a2) => { const r = (run_loop($rend$mix$(nat_host(a0), nat_host(a1), (a2)))); BigInt(a0); BigInt(a1); (a2); return r; }, 3),
  "rend": run_lib((a0, a1) => { const r = (run_loop($rend$(nat_host(a0), nat_host(a1)))); BigInt(a0); BigInt(a1); return r; }, 2),
  "its": run_lib(() => { const r = BigInt(run_loop($its$()));  return r; }, 0),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
};
