
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402f10 <nx_rt_rebuild2>:
  402f10:	push   %r15
  402f12:	push   %r14
  402f14:	push   %r13
  402f16:	mov    %ecx,%r13d
  402f19:	push   %r12
  402f1b:	mov    %rdi,%r12
  402f1e:	push   %rbp
  402f1f:	movabs $0xffffffffff,%rbp
  402f29:	push   %rbx
  402f2a:	and    %rsi,%rbp
  402f2d:	mov    %edx,%ebx
  402f2f:	lea    0x0(,%rbp,8),%rdx
  402f37:	sub    $0x28,%rsp
  402f3b:	mov    (%rdi),%r14
  402f3e:	mov    0x8(%rdi),%r15
  402f42:	lea    (%r14,%rdx,1),%rax
  402f46:	test   %rsi,%rsi
  402f49:	js     403030 <nx_rt_rebuild2+0x120>
  402f4f:	mov    (%rax),%rax
  402f52:	mov    %rax,0x10(%rsp)
  402f57:	mov    0x8(%r14,%rdx,1),%rax
  402f5c:	mov    %rax,0x18(%rsp)
  402f61:	cmp    $0x310817f,%rbp
  402f68:	jbe    403008 <nx_rt_rebuild2+0xf8>
  402f6e:	lea    (%r14,%rbp,8),%r9
  402f72:	mov    $0x1,%eax
  402f77:	mov    0x10(%rsp,%r13,8),%rdx
  402f7c:	movq   $0xffffffffffffffff,0x18(%r12)
  402f85:	movl   $0x1,0x20(%r12)
  402f8e:	sub    %r13d,%eax
  402f91:	mov    0x10(%rsp,%rax,8),%rax
  402f96:	mov    %rax,0x10(%r12)
  402f9b:	mov    %rdx,%rax
  402f9e:	shr    $0x38,%rax
  402fa2:	and    $0x7f,%eax
  402fa5:	cmp    $0x2,%rax
  402fa9:	je     402fe8 <nx_rt_rebuild2+0xd8>
  402fab:	mov    %r8,%rax
  402fae:	mov    %rdx,(%r9)
  402fb1:	lea    0x8(%r14,%rbp,8),%r12
  402fb6:	shr    $0x38,%rax
  402fba:	and    $0x7f,%eax
  402fbd:	cmp    $0x2,%rax
  402fc1:	je     402ff8 <nx_rt_rebuild2+0xe8>
  402fc3:	mov    %rbx,%rax
  402fc6:	mov    %r8,(%r12)
  402fca:	add    $0x28,%rsp
  402fce:	shl    $0x28,%rax
  402fd2:	pop    %rbx
  402fd3:	or     %rbp,%rax
  402fd6:	pop    %rbp
  402fd7:	pop    %r12
  402fd9:	bts    $0x39,%rax
  402fde:	pop    %r13
  402fe0:	pop    %r14
  402fe2:	pop    %r15
  402fe4:	retq   
  402fe5:	nopl   (%rax)
  402fe8:	test   %rdx,%rdx
  402feb:	js     402fab <nx_rt_rebuild2+0x9b>
  402fed:	jmpq   401640 <nx_rt_rebuild2.cold>
  402ff2:	nopw   0x0(%rax,%rax,1)
  402ff8:	test   %r8,%r8
  402ffb:	js     402fc3 <nx_rt_rebuild2+0xb3>
  402ffd:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  403002:	nopw   0x0(%rax,%rax,1)
  403008:	mov    0x8(%r15),%rbp
  40300c:	test   %rbp,%rbp
  40300f:	je     401685 <nx_rt_rebuild2.cold+0x45>
  403015:	lea    (%r14,%rbp,8),%r9
  403019:	mov    (%r9),%rax
  40301c:	subq   $0x2,0x108(%r15)
  403024:	mov    %rax,0x8(%r15)
  403028:	jmpq   402f72 <nx_rt_rebuild2+0x62>
  40302d:	nopl   (%rax)
  403030:	mov    0x4(%rax),%edx
  403033:	mov    (%rax),%ecx
  403035:	shl    $0x20,%rdx
  403039:	or     %rcx,%rdx
  40303c:	mov    %rdx,%rcx
  40303f:	and    $0xffffff,%edx
  403045:	shr    $0x18,%rcx
  403049:	lea    0x0(,%rcx,8),%rdi
  403051:	lea    (%r14,%rdi,1),%r9
  403055:	lea    0x8(%r14,%rdi,1),%rdi
  40305a:	cmp    $0x1,%rdx
  40305e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403064:	mov    (%rax),%edx
  403066:	mov    (%r9),%rdx
  403069:	mov    %rdx,0x10(%rsp)
  40306e:	mov    (%rdi),%rdx
  403071:	mov    %rdx,0x18(%rsp)
  403076:	mov    (%r15),%rdx
  403079:	mov    %rdx,(%rax)
  40307c:	mov    0x100(%r15),%rax
  403083:	mov    0x3e14f(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403089:	mov    %rbp,(%r15)
  40308c:	add    $0x1,%rax
  403090:	mov    %rax,0x100(%r15)
  403097:	cmp    %rdx,%rax
  40309a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  4030a0:	mov    %rcx,%rbp
  4030a3:	jmpq   402f61 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
