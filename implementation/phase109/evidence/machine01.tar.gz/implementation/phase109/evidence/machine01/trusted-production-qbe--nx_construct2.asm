
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402e80 <nx_construct2>:
  402e80:	endbr64 
  402e84:	push   %rbp
  402e85:	mov    %rsp,%rbp
  402e88:	sub    $0x18,%rsp
  402e8c:	push   %rbx
  402e8d:	push   %r12
  402e8f:	push   %r13
  402e91:	mov    %r9,%r12
  402e94:	mov    %r8,%r13
  402e97:	mov    %edx,%ebx
  402e99:	mov    %rcx,%rdx
  402e9c:	mov    %rdi,-0x10(%rbp)
  402ea0:	mov    %rsi,-0x8(%rbp)
  402ea4:	mov    -0x10(%rbp),%rdi
  402ea8:	mov    -0x8(%rbp),%rsi
  402eac:	callq  401c60 <rfc_seal>
  402eb1:	mov    %r13,%rdx
  402eb4:	mov    -0x10(%rbp),%rcx
  402eb8:	mov    %rax,(%rcx,%r12,8)
  402ebc:	mov    -0x10(%rbp),%rdi
  402ec0:	mov    -0x8(%rbp),%rsi
  402ec4:	callq  401c60 <rfc_seal>
  402ec9:	mov    %r12,%r9
  402ecc:	mov    %ebx,%edx
  402ece:	mov    -0x10(%rbp),%rcx
  402ed2:	mov    %rax,0x8(%rcx,%r9,8)
  402ed7:	mov    %edx,%eax
  402ed9:	shl    $0x28,%rax
  402edd:	movabs $0x200000000000000,%rcx
  402ee7:	or     %rcx,%rax
  402eea:	or     %r9,%rax
  402eed:	pop    %r13
  402eef:	pop    %r12
  402ef1:	pop    %rbx
  402ef2:	leaveq 
  402ef3:	retq   

Disassembly of section .fini:
