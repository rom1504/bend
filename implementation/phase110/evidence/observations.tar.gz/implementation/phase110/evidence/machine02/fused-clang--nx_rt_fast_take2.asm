
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d90 <nx_rt_fast_take2>:
  402d90:	movabs $0xffffffffff,%rax
  402d9a:	push   %r12
  402d9c:	and    %rsi,%rax
  402d9f:	push   %rbp
  402da0:	push   %rbx
  402da1:	mov    %rdi,%rbx
  402da4:	mov    (%rdi),%rdi
  402da7:	lea    0x0(,%rax,8),%rcx
  402daf:	mov    0x8(%rbx),%rbp
  402db3:	lea    (%rdi,%rcx,1),%rdx
  402db7:	test   %rsi,%rsi
  402dba:	js     402e28 <nx_rt_fast_take2+0x98>
  402dbc:	mov    (%rdx),%rdx
  402dbf:	mov    %rdx,0x10(%rbx)
  402dc3:	mov    0x8(%rdi,%rcx,1),%rdx
  402dc8:	mov    %rdx,0x18(%rbx)
  402dcc:	cmp    $0x310817f,%rax
  402dd2:	ja     402de8 <nx_rt_fast_take2+0x58>
  402dd4:	movl   $0x3,0x20(%rbx)
  402ddb:	xor    %eax,%eax
  402ddd:	pop    %rbx
  402dde:	pop    %rbp
  402ddf:	pop    %r12
  402de1:	retq   
  402de2:	nopw   0x0(%rax,%rax,1)
  402de8:	mov    0x8(%rbp),%rdx
  402dec:	mov    %rdx,(%rdi,%rax,8)
  402df0:	mov    0x3e3e2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402df6:	mov    %rax,0x8(%rbp)
  402dfa:	mov    0x108(%rbp),%rax
  402e01:	add    $0x2,%rax
  402e05:	mov    %rax,0x108(%rbp)
  402e0c:	cmp    %rdx,%rax
  402e0f:	jae    4015fe <nx_rt_fast_take2.cold>
  402e15:	movl   $0x3,0x20(%rbx)
  402e1c:	xor    %eax,%eax
  402e1e:	pop    %rbx
  402e1f:	pop    %rbp
  402e20:	pop    %r12
  402e22:	retq   
  402e23:	nopl   0x0(%rax,%rax,1)
  402e28:	mov    0x4(%rdx),%ecx
  402e2b:	mov    (%rdx),%r8d
  402e2e:	shl    $0x20,%rcx
  402e32:	or     %r8,%rcx
  402e35:	mov    %rcx,%r12
  402e38:	and    $0xffffff,%ecx
  402e3e:	shr    $0x18,%r12
  402e42:	lea    0x0(,%r12,8),%r8
  402e4a:	lea    (%rdi,%r8,1),%r9
  402e4e:	lea    0x8(%rdi,%r8,1),%r8
  402e53:	cmp    $0x1,%rcx
  402e57:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  402e5d:	mov    (%rdx),%ecx
  402e5f:	mov    (%r9),%rcx
  402e62:	mov    %rcx,0x10(%rbx)
  402e66:	mov    (%r8),%rcx
  402e69:	mov    %rcx,0x18(%rbx)
  402e6d:	mov    0x0(%rbp),%rcx
  402e71:	mov    %rcx,(%rdx)
  402e74:	mov    0x3e35e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e7a:	mov    %rax,0x0(%rbp)
  402e7e:	mov    0x100(%rbp),%rax
  402e85:	add    $0x1,%rax
  402e89:	mov    %rax,0x100(%rbp)
  402e90:	cmp    %rdx,%rax
  402e93:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  402e99:	mov    %r12,%rax
  402e9c:	jmpq   402dcc <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
