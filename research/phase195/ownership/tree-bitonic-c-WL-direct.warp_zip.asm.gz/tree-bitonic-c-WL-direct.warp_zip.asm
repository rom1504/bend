
/home/ai/bend2/build/publish/bend/selfhost/build/phase184/bend-products01/tree-bitonic/bend-c/program:     file format elf64-x86-64


Disassembly of section .text:

000000000000dfa0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>:
    dfa0:	push   %rbp
    dfa1:	sub    $0x20,%rsp
    dfa5:	mov    %r15d,%ebp
    dfa8:	movabs $0xffffffff80,%r11
    dfb2:	mov    %rsi,%rax
    dfb5:	shr    $0x28,%rax
    dfb9:	movzwl %ax,%eax
    dfbc:	cmp    $0xa4,%eax
    dfc1:	je     dffb <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x5b>
    dfc3:	cmp    $0xa5,%eax
    dfc8:	jne    e994 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x9f4>
    dfce:	lea    0x7f(%r11),%rbx
    dfd2:	mov    %rsi,%rax
    dfd5:	and    %rbx,%rax
    dfd8:	test   %rsi,%rsi
    dfdb:	js     e043 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa3>
    dfdd:	mov    (%r12,%rax,8),%r9
    dfe1:	mov    0x8(%r12,%rax,8),%rdi
    dfe6:	mov    %rax,%rcx
    dfe9:	cmp    $0x3108180,%rcx
    dff0:	jae    e0b7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x117>
    dff6:	jmpq   e0ee <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x14e>
    dffb:	movabs $0x7f00000000000000,%r9
    e005:	mov    %rsi,%rax
    e008:	and    %r9,%rax
    e00b:	movabs $0x100000000000000,%r10
    e015:	cmp    %r10,%rax
    e018:	je     e2e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x346>
    e01e:	lea    0x7f(%r11),%rax
    e022:	and    %rsi,%rax
    e025:	test   %rsi,%rsi
    e028:	js     e248 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x2a8>
    e02e:	mov    %rax,%rcx
    e031:	cmp    $0x3108180,%rcx
    e038:	jae    e2b0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x310>
    e03e:	jmpq   e2e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x346>
    e043:	mov    0x4(%r12,%rax,8),%ecx
    e048:	mov    (%r12,%rax,8),%edi
    e04c:	mov    %edi,%r8d
    e04f:	and    $0xffffff,%r8d
    e056:	cmp    $0x1,%r8d
    e05a:	jne    e75e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x7be>
    e060:	mov    (%r12,%rax,8),%esi
    e064:	shl    $0x20,%rcx
    e068:	or     %rdi,%rcx
    e06b:	shr    $0x18,%rcx
    e06f:	mov    (%r12,%rcx,8),%r9
    e073:	mov    0x8(%r12,%rcx,8),%rdi
    e078:	mov    0x0(%r13),%rsi
    e07c:	mov    %rsi,(%r12,%rax,8)
    e080:	mov    %rax,0x0(%r13)
    e084:	mov    0x100(%r13),%rax
    e08b:	inc    %rax
    e08e:	mov    %rax,0x100(%r13)
    e095:	cmpb   $0x1,0x10b7f4(%rip)        # 119890 <KEEP_WORDS>
    e09c:	jne    e79d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x7fd>
    e0a2:	cmp    $0x8000,%rax
    e0a8:	jae    e79d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x7fd>
    e0ae:	cmp    $0x3108180,%rcx
    e0b5:	jb     e0ee <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x14e>
    e0b7:	mov    0x8(%r13),%rax
    e0bb:	mov    %rax,(%r12,%rcx,8)
    e0bf:	mov    %rcx,0x8(%r13)
    e0c3:	mov    0x108(%r13),%rax
    e0ca:	add    $0x2,%rax
    e0ce:	mov    %rax,0x108(%r13)
    e0d5:	cmpb   $0x1,0x10b7b4(%rip)        # 119890 <KEEP_WORDS>
    e0dc:	jne    e737 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x797>
    e0e2:	cmp    $0x8000,%rax
    e0e8:	jae    e737 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x797>
    e0ee:	mov    %rdx,%rax
    e0f1:	shr    $0x28,%rax
    e0f5:	movzwl %ax,%r15d
    e0f9:	cmp    $0xa5,%r15
    e100:	jne    e132 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x192>
    e102:	mov    %r14,%r15
    e105:	and    %rdx,%rbx
    e108:	mov    %ebp,%r14d
    e10b:	test   %rdx,%rdx
    e10e:	js     e36b <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x3cb>
    e114:	mov    (%r12,%rbx,8),%rbp
    e118:	mov    0x8(%r12,%rbx,8),%r10
    e11d:	mov    %rbx,%rcx
    e120:	cmp    $0x3108180,%rcx
    e127:	jae    e3dc <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x43c>
    e12d:	jmpq   e413 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x473>
    e132:	movabs $0x7e00000000000000,%rsi
    e13c:	test   %rsi,%r9
    e13f:	sete   %al
    e142:	cmp    $0xffffffffffffffff,%r9
    e146:	sete   %cl
    e149:	or     %al,%cl
    e14b:	mov    %r9,%rax
    e14e:	and    %r11,%rax
    e151:	cmp    $0x3108180,%rax
    e157:	setb   %al
    e15a:	or     %cl,%al
    e15c:	mov    %r14,0x10(%rsp)
    e161:	mov    %ebp,0xc(%rsp)
    e165:	jne    e19e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x1fe>
    e167:	mov    %rdi,0x18(%rsp)
    e16c:	mov    %r12,%rdi
    e16f:	mov    %r13,%rsi
    e172:	mov    %rdx,%rbp
    e175:	mov    %r9,%rdx
    e178:	mov    %r11,%r14
    e17b:	callq  7810 <term_drop>
    e180:	movabs $0x7e00000000000000,%rsi
    e18a:	mov    0x18(%rsp),%rdi
    e18f:	mov    %r14,%r11
    e192:	mov    %rbp,%rdx
    e195:	mov    0xc(%rsp),%ebp
    e199:	mov    0x10(%rsp),%r14
    e19e:	test   %rsi,%rdi
    e1a1:	sete   %al
    e1a4:	cmp    $0xffffffffffffffff,%rdi
    e1a8:	sete   %cl
    e1ab:	or     %al,%cl
    e1ad:	mov    %rdi,%rax
    e1b0:	and    %r11,%rax
    e1b3:	cmp    $0x3108180,%rax
    e1b9:	setb   %al
    e1bc:	or     %cl,%al
    e1be:	jne    e1f0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x250>
    e1c0:	mov    %rdi,%rax
    e1c3:	mov    %r12,%rdi
    e1c6:	mov    %r13,%rsi
    e1c9:	mov    %rdx,%rbp
    e1cc:	mov    %rax,%rdx
    e1cf:	mov    %r11,%r14
    e1d2:	callq  7810 <term_drop>
    e1d7:	movabs $0x7e00000000000000,%rsi
    e1e1:	mov    %r14,%r11
    e1e4:	mov    %rbp,%rdx
    e1e7:	mov    0xc(%rsp),%ebp
    e1eb:	mov    0x10(%rsp),%r14
    e1f0:	cmp    $0xa4,%r15d
    e1f7:	jne    ea0e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa6e>
    e1fd:	movabs $0x100a40000000000,%rsi
    e207:	movabs $0x7f00000000000000,%rax
    e211:	and    %rdx,%rax
    e214:	movabs $0x100000000000000,%rcx
    e21e:	cmp    %rcx,%rax
    e221:	je     e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e227:	and    %rdx,%rbx
    e22a:	test   %rdx,%rdx
    e22d:	js     e61a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x67a>
    e233:	mov    %rbx,%rcx
    e236:	cmp    $0x3108180,%rcx
    e23d:	jae    e682 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x6e2>
    e243:	jmpq   e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e248:	mov    0x4(%r12,%rax,8),%ecx
    e24d:	mov    (%r12,%rax,8),%edi
    e251:	mov    %edi,%ebx
    e253:	and    $0xffffff,%ebx
    e259:	cmp    $0x1,%ebx
    e25c:	jne    e837 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x897>
    e262:	mov    (%r12,%rax,8),%esi
    e266:	shl    $0x20,%rcx
    e26a:	or     %rdi,%rcx
    e26d:	shr    $0x18,%rcx
    e271:	mov    0x0(%r13),%rsi
    e275:	mov    %rsi,(%r12,%rax,8)
    e279:	mov    %rax,0x0(%r13)
    e27d:	mov    0x100(%r13),%rax
    e284:	inc    %rax
    e287:	mov    %rax,0x100(%r13)
    e28e:	cmpb   $0x1,0x10b5fb(%rip)        # 119890 <KEEP_WORDS>
    e295:	jne    e8f4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x954>
    e29b:	cmp    $0x8000,%rax
    e2a1:	jae    e8f4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x954>
    e2a7:	cmp    $0x3108180,%rcx
    e2ae:	jb     e2e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x346>
    e2b0:	mov    0x0(%r13),%rax
    e2b4:	mov    %rax,(%r12,%rcx,8)
    e2b8:	mov    %rcx,0x0(%r13)
    e2bc:	mov    0x100(%r13),%rax
    e2c3:	inc    %rax
    e2c6:	mov    %rax,0x100(%r13)
    e2cd:	cmpb   $0x1,0x10b5bc(%rip)        # 119890 <KEEP_WORDS>
    e2d4:	jne    e7ce <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x82e>
    e2da:	cmp    $0x8000,%rax
    e2e0:	jae    e7ce <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x82e>
    e2e6:	mov    %rdx,%rax
    e2e9:	shr    $0x28,%rax
    e2ed:	movzwl %ax,%eax
    e2f0:	cmp    $0xa4,%eax
    e2f5:	je     e330 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x390>
    e2f7:	cmp    $0xa5,%eax
    e2fc:	jne    e9ff <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa5f>
    e302:	lea    0x7f(%r11),%rax
    e306:	and    %rdx,%rax
    e309:	test   %rdx,%rdx
    e30c:	js     e4a3 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x503>
    e312:	mov    (%r12,%rax,8),%rdx
    e316:	mov    0x8(%r12,%rax,8),%r10
    e31b:	mov    %rax,%rcx
    e31e:	cmp    $0x3108180,%rcx
    e325:	jae    e514 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x574>
    e32b:	jmpq   e54b <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x5ab>
    e330:	movabs $0x100a40000000000,%rsi
    e33a:	and    %rdx,%r9
    e33d:	cmp    %r10,%r9
    e340:	je     e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e346:	add    $0x7f,%r11
    e34a:	and    %rdx,%r11
    e34d:	test   %rdx,%rdx
    e350:	js     e5e3 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x643>
    e356:	mov    %r11,%rcx
    e359:	cmp    $0x3108180,%rcx
    e360:	jae    e682 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x6e2>
    e366:	jmpq   e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e36b:	mov    0x4(%r12,%rbx,8),%ecx
    e370:	mov    (%r12,%rbx,8),%eax
    e374:	mov    %eax,%esi
    e376:	and    $0xffffff,%esi
    e37c:	cmp    $0x1,%esi
    e37f:	jne    e86a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x8ca>
    e385:	mov    (%r12,%rbx,8),%edx
    e389:	shl    $0x20,%rcx
    e38d:	or     %rax,%rcx
    e390:	shr    $0x18,%rcx
    e394:	mov    (%r12,%rcx,8),%rbp
    e398:	mov    0x8(%r12,%rcx,8),%r10
    e39d:	mov    0x0(%r13),%rax
    e3a1:	mov    %rax,(%r12,%rbx,8)
    e3a5:	mov    %rbx,0x0(%r13)
    e3a9:	mov    0x100(%r13),%rax
    e3b0:	inc    %rax
    e3b3:	mov    %rax,0x100(%r13)
    e3ba:	cmpb   $0x1,0x10b4cf(%rip)        # 119890 <KEEP_WORDS>
    e3c1:	jne    e91f <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x97f>
    e3c7:	cmp    $0x8000,%rax
    e3cd:	jae    e91f <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x97f>
    e3d3:	cmp    $0x3108180,%rcx
    e3da:	jb     e413 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x473>
    e3dc:	mov    0x8(%r13),%rax
    e3e0:	mov    %rax,(%r12,%rcx,8)
    e3e4:	mov    %rcx,0x8(%r13)
    e3e8:	mov    0x108(%r13),%rax
    e3ef:	add    $0x2,%rax
    e3f3:	mov    %rax,0x108(%r13)
    e3fa:	cmpb   $0x1,0x10b48f(%rip)        # 119890 <KEEP_WORDS>
    e401:	jne    e7ec <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x84c>
    e407:	cmp    $0x8000,%rax
    e40d:	jae    e7ec <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x84c>
    e413:	mov    0x8(%r13),%rcx
    e417:	test   %rcx,%rcx
    e41a:	je     e6da <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x73a>
    e420:	mov    (%r12,%rcx,8),%rax
    e424:	mov    %rax,0x8(%r13)
    e428:	addq   $0xfffffffffffffffe,0x108(%r13)
    e430:	movabs $0x200a50000000000,%rsi
    e43a:	mov    %r9,(%r12,%rcx,8)
    e43e:	mov    %rbp,0x8(%r12,%rcx,8)
    e443:	mov    0x8(%r13),%r8
    e447:	test   %r8,%r8
    e44a:	je     e6f8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x758>
    e450:	mov    (%r12,%r8,8),%rax
    e454:	mov    %rax,0x8(%r13)
    e458:	addq   $0xfffffffffffffffe,0x108(%r13)
    e460:	mov    %r14d,%ebp
    e463:	or     %rsi,%rcx
    e466:	mov    %rdi,(%r12,%r8,8)
    e46a:	mov    %r10,0x8(%r12,%r8,8)
    e46f:	or     %rsi,%r8
    e472:	mov    0x8(%r13),%rax
    e476:	test   %rax,%rax
    e479:	mov    %r15,%r14
    e47c:	je     e71c <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x77c>
    e482:	mov    (%r12,%rax,8),%rdx
    e486:	mov    %rdx,0x8(%r13)
    e48a:	addq   $0xfffffffffffffffe,0x108(%r13)
    e492:	mov    %rcx,(%r12,%rax,8)
    e496:	mov    %r8,0x8(%r12,%rax,8)
    e49b:	or     %rax,%rsi
    e49e:	jmpq   e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e4a3:	mov    0x4(%r12,%rax,8),%ecx
    e4a8:	mov    (%r12,%rax,8),%esi
    e4ac:	mov    %esi,%edi
    e4ae:	and    $0xffffff,%edi
    e4b4:	cmp    $0x1,%edi
    e4b7:	jne    e89a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x8fa>
    e4bd:	mov    (%r12,%rax,8),%edx
    e4c1:	shl    $0x20,%rcx
    e4c5:	or     %rsi,%rcx
    e4c8:	shr    $0x18,%rcx
    e4cc:	mov    (%r12,%rcx,8),%rdx
    e4d0:	mov    0x8(%r12,%rcx,8),%r10
    e4d5:	mov    0x0(%r13),%rsi
    e4d9:	mov    %rsi,(%r12,%rax,8)
    e4dd:	mov    %rax,0x0(%r13)
    e4e1:	mov    0x100(%r13),%rax
    e4e8:	inc    %rax
    e4eb:	mov    %rax,0x100(%r13)
    e4f2:	cmpb   $0x1,0x10b397(%rip)        # 119890 <KEEP_WORDS>
    e4f9:	jne    e944 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x9a4>
    e4ff:	cmp    $0x8000,%rax
    e505:	jae    e944 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x9a4>
    e50b:	cmp    $0x3108180,%rcx
    e512:	jb     e54b <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x5ab>
    e514:	mov    0x8(%r13),%rax
    e518:	mov    %rax,(%r12,%rcx,8)
    e51c:	mov    %rcx,0x8(%r13)
    e520:	mov    0x108(%r13),%rax
    e527:	add    $0x2,%rax
    e52b:	mov    %rax,0x108(%r13)
    e532:	cmpb   $0x1,0x10b357(%rip)        # 119890 <KEEP_WORDS>
    e539:	jne    e804 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x864>
    e53f:	cmp    $0x8000,%rax
    e545:	jae    e804 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x864>
    e54b:	movabs $0x7e00000000000000,%rdi
    e555:	test   %rdi,%rdx
    e558:	sete   %al
    e55b:	cmp    $0xffffffffffffffff,%rdx
    e55f:	sete   %cl
    e562:	or     %al,%cl
    e564:	mov    %rdx,%rax
    e567:	and    %r11,%rax
    e56a:	cmp    $0x3108180,%rax
    e570:	setb   %al
    e573:	or     %cl,%al
    e575:	jne    e59c <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x5fc>
    e577:	mov    %r12,%rdi
    e57a:	mov    %r13,%rsi
    e57d:	mov    %ebp,%ebx
    e57f:	mov    %r11,%rbp
    e582:	mov    %r10,%r15
    e585:	callq  7810 <term_drop>
    e58a:	movabs $0x7e00000000000000,%rdi
    e594:	mov    %r15,%r10
    e597:	mov    %rbp,%r11
    e59a:	mov    %ebx,%ebp
    e59c:	movabs $0x100a40000000000,%rsi
    e5a6:	test   %rdi,%r10
    e5a9:	sete   %al
    e5ac:	cmp    $0xffffffffffffffff,%r10
    e5b0:	sete   %cl
    e5b3:	or     %al,%cl
    e5b5:	and    %r10,%r11
    e5b8:	cmp    $0x3108180,%r11
    e5bf:	setb   %al
    e5c2:	or     %cl,%al
    e5c4:	jne    e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e5ca:	mov    %r12,%rdi
    e5cd:	mov    %rsi,%r15
    e5d0:	mov    %r13,%rsi
    e5d3:	mov    %r10,%rdx
    e5d6:	callq  7810 <term_drop>
    e5db:	mov    %r15,%rsi
    e5de:	jmpq   e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e5e3:	mov    0x4(%r12,%r11,8),%ecx
    e5e8:	mov    (%r12,%r11,8),%eax
    e5ec:	mov    %eax,%edi
    e5ee:	and    $0xffffff,%edi
    e5f4:	cmp    $0x1,%edi
    e5f7:	jne    e8cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x92d>
    e5fd:	mov    (%r12,%r11,8),%edx
    e601:	shl    $0x20,%rcx
    e605:	or     %rax,%rcx
    e608:	shr    $0x18,%rcx
    e60c:	mov    0x0(%r13),%rax
    e610:	mov    %rax,(%r12,%r11,8)
    e614:	mov    %r11,0x0(%r13)
    e618:	jmp    e64f <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x6af>
    e61a:	mov    0x4(%r12,%rbx,8),%ecx
    e61f:	mov    (%r12,%rbx,8),%eax
    e623:	mov    %eax,%edi
    e625:	and    $0xffffff,%edi
    e62b:	cmp    $0x1,%edi
    e62e:	jne    e8cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x92d>
    e634:	mov    (%r12,%rbx,8),%edx
    e638:	shl    $0x20,%rcx
    e63c:	or     %rax,%rcx
    e63f:	shr    $0x18,%rcx
    e643:	mov    0x0(%r13),%rax
    e647:	mov    %rax,(%r12,%rbx,8)
    e64b:	mov    %rbx,0x0(%r13)
    e64f:	mov    0x100(%r13),%rax
    e656:	inc    %rax
    e659:	mov    %rax,0x100(%r13)
    e660:	cmpb   $0x1,0x10b229(%rip)        # 119890 <KEEP_WORDS>
    e667:	jne    e96f <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x9cf>
    e66d:	cmp    $0x8000,%rax
    e673:	jae    e96f <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x9cf>
    e679:	cmp    $0x3108180,%rcx
    e680:	jb     e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e682:	mov    0x0(%r13),%rax
    e686:	mov    %rax,(%r12,%rcx,8)
    e68a:	mov    %rcx,0x0(%r13)
    e68e:	mov    0x100(%r13),%rax
    e695:	inc    %rax
    e698:	mov    %rax,0x100(%r13)
    e69f:	cmpb   $0x1,0x10b1ea(%rip)        # 119890 <KEEP_WORDS>
    e6a6:	jne    e822 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x882>
    e6ac:	cmp    $0x8000,%rax
    e6b2:	jae    e822 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x882>
    e6b8:	mov    -0x8(%r14),%eax
    e6bc:	add    $0xfffffffffffffff8,%r14
    e6c0:	lea    0x9749(%rip),%rcx        # 17e10 <wl_tab>
    e6c7:	mov    (%rcx,%rax,8),%rax
    e6cb:	mov    %ebp,%r15d
    e6ce:	mov    $0x1,%edi
    e6d3:	add    $0x20,%rsp
    e6d7:	pop    %rbp
    e6d8:	jmpq   *%rax
    e6da:	mov    %rdi,%rcx
    e6dd:	mov    %r12,%rdi
    e6e0:	mov    %r13,%rsi
    e6e3:	mov    $0x1,%edx
    e6e8:	callq  159a8 <heap_alloc_miss>
    e6ed:	mov    %rcx,%rdi
    e6f0:	mov    %rax,%rcx
    e6f3:	jmpq   e430 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x490>
    e6f8:	mov    %rdi,%r9
    e6fb:	mov    %r12,%rdi
    e6fe:	mov    %rsi,%r8
    e701:	mov    %r13,%rsi
    e704:	mov    $0x1,%edx
    e709:	callq  159a8 <heap_alloc_miss>
    e70e:	mov    %r9,%rdi
    e711:	mov    %r8,%rsi
    e714:	mov    %rax,%r8
    e717:	jmpq   e460 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x4c0>
    e71c:	mov    %r12,%rdi
    e71f:	mov    %rsi,%r9
    e722:	mov    %r13,%rsi
    e725:	mov    $0x1,%edx
    e72a:	callq  159a8 <heap_alloc_miss>
    e72f:	mov    %r9,%rsi
    e732:	jmpq   e492 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x4f2>
    e737:	mov    %rdi,%r8
    e73a:	mov    %r12,%rdi
    e73d:	mov    %r13,%rsi
    e740:	mov    %rdx,%rax
    e743:	mov    $0x1,%edx
    e748:	mov    %r11,%rcx
    e74b:	callq  15881 <heap_hand>
    e750:	mov    %r8,%rdi
    e753:	mov    %rcx,%r11
    e756:	mov    %rax,%rdx
    e759:	jmpq   e0ee <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x14e>
    e75e:	shl    $0x20,%rcx
    e762:	or     %rdi,%rcx
    e765:	shr    $0x18,%rcx
    e769:	mov    (%r12,%rcx,8),%r9
    e76d:	mov    0x8(%r12,%rcx,8),%r15
    e772:	mov    %r12,%rdi
    e775:	mov    %rsi,%rax
    e778:	mov    %r13,%rsi
    e77b:	mov    %rdx,%r10
    e77e:	mov    %rax,%rdx
    e781:	mov    $0x2,%r8d
    e787:	mov    %r11,%rax
    e78a:	callq  15912 <span_fade>
    e78f:	mov    %r15,%rdi
    e792:	mov    %rax,%r11
    e795:	mov    %r10,%rdx
    e798:	jmpq   e0ee <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x14e>
    e79d:	mov    %rdi,%r10
    e7a0:	mov    %r12,%rdi
    e7a3:	mov    %r13,%rsi
    e7a6:	mov    %rdx,%rax
    e7a9:	xor    %edx,%edx
    e7ab:	mov    %r11,%r8
    e7ae:	callq  15881 <heap_hand>
    e7b3:	mov    %r10,%rdi
    e7b6:	mov    %r8,%r11
    e7b9:	mov    %rax,%rdx
    e7bc:	cmp    $0x3108180,%rcx
    e7c3:	jae    e0b7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x117>
    e7c9:	jmpq   e0ee <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x14e>
    e7ce:	mov    %r12,%rdi
    e7d1:	mov    %r13,%rsi
    e7d4:	mov    %rdx,%rax
    e7d7:	xor    %edx,%edx
    e7d9:	mov    %r11,%rcx
    e7dc:	callq  15881 <heap_hand>
    e7e1:	mov    %rcx,%r11
    e7e4:	mov    %rax,%rdx
    e7e7:	jmpq   e2e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x346>
    e7ec:	mov    %rdi,%rax
    e7ef:	mov    %r12,%rdi
    e7f2:	mov    %r13,%rsi
    e7f5:	mov    $0x1,%edx
    e7fa:	callq  15881 <heap_hand>
    e7ff:	jmpq   e892 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x8f2>
    e804:	mov    %r12,%rdi
    e807:	mov    %r13,%rsi
    e80a:	mov    %rdx,%rax
    e80d:	mov    $0x1,%edx
    e812:	mov    %r11,%rcx
    e815:	callq  15881 <heap_hand>
    e81a:	mov    %rcx,%r11
    e81d:	jmpq   e8c5 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x925>
    e822:	mov    %r12,%rdi
    e825:	mov    %rsi,%rax
    e828:	mov    %r13,%rsi
    e82b:	xor    %edx,%edx
    e82d:	callq  15881 <heap_hand>
    e832:	jmpq   e8ec <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x94c>
    e837:	shl    $0x20,%rcx
    e83b:	or     %rdi,%rcx
    e83e:	shr    $0x18,%rcx
    e842:	mov    %r12,%rdi
    e845:	mov    %rsi,%rax
    e848:	mov    %r13,%rsi
    e84b:	mov    %rdx,%rbx
    e84e:	mov    %rax,%rdx
    e851:	mov    $0x1,%r8d
    e857:	mov    %r11,%rax
    e85a:	callq  15912 <span_fade>
    e85f:	mov    %rax,%r11
    e862:	mov    %rbx,%rdx
    e865:	jmpq   e2e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x346>
    e86a:	shl    $0x20,%rcx
    e86e:	or     %rax,%rcx
    e871:	shr    $0x18,%rcx
    e875:	mov    (%r12,%rcx,8),%rbp
    e879:	mov    0x8(%r12,%rcx,8),%r10
    e87e:	mov    %rdi,%rax
    e881:	mov    %r12,%rdi
    e884:	mov    %r13,%rsi
    e887:	mov    $0x2,%r8d
    e88d:	callq  15912 <span_fade>
    e892:	mov    %rax,%rdi
    e895:	jmpq   e413 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x473>
    e89a:	shl    $0x20,%rcx
    e89e:	or     %rsi,%rcx
    e8a1:	shr    $0x18,%rcx
    e8a5:	mov    (%r12,%rcx,8),%rax
    e8a9:	mov    0x8(%r12,%rcx,8),%r10
    e8ae:	mov    %r12,%rdi
    e8b1:	mov    %r13,%rsi
    e8b4:	mov    $0x2,%r8d
    e8ba:	mov    %r11,%r9
    e8bd:	callq  15912 <span_fade>
    e8c2:	mov    %r9,%r11
    e8c5:	mov    %rax,%rdx
    e8c8:	jmpq   e54b <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x5ab>
    e8cd:	shl    $0x20,%rcx
    e8d1:	or     %rax,%rcx
    e8d4:	shr    $0x18,%rcx
    e8d8:	mov    %r12,%rdi
    e8db:	mov    %rsi,%rax
    e8de:	mov    %r13,%rsi
    e8e1:	mov    $0x1,%r8d
    e8e7:	callq  15912 <span_fade>
    e8ec:	mov    %rax,%rsi
    e8ef:	jmpq   e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e8f4:	mov    %r12,%rdi
    e8f7:	mov    %r13,%rsi
    e8fa:	mov    %rdx,%rax
    e8fd:	xor    %edx,%edx
    e8ff:	mov    %r11,%r8
    e902:	callq  15881 <heap_hand>
    e907:	mov    %r8,%r11
    e90a:	mov    %rax,%rdx
    e90d:	cmp    $0x3108180,%rcx
    e914:	jae    e2b0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x310>
    e91a:	jmpq   e2e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x346>
    e91f:	mov    %rdi,%rax
    e922:	mov    %r12,%rdi
    e925:	mov    %r13,%rsi
    e928:	xor    %edx,%edx
    e92a:	callq  15881 <heap_hand>
    e92f:	mov    %rax,%rdi
    e932:	cmp    $0x3108180,%rcx
    e939:	jae    e3dc <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x43c>
    e93f:	jmpq   e413 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x473>
    e944:	mov    %r12,%rdi
    e947:	mov    %r13,%rsi
    e94a:	mov    %rdx,%rax
    e94d:	xor    %edx,%edx
    e94f:	mov    %r11,%r8
    e952:	callq  15881 <heap_hand>
    e957:	mov    %r8,%r11
    e95a:	mov    %rax,%rdx
    e95d:	cmp    $0x3108180,%rcx
    e964:	jae    e514 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x574>
    e96a:	jmpq   e54b <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x5ab>
    e96f:	mov    %r12,%rdi
    e972:	mov    %rsi,%rax
    e975:	mov    %r13,%rsi
    e978:	xor    %edx,%edx
    e97a:	callq  15881 <heap_hand>
    e97f:	mov    %rax,%rsi
    e982:	cmp    $0x3108180,%rcx
    e989:	jae    e682 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x6e2>
    e98f:	jmpq   e6b8 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x718>
    e994:	mov    %rdx,%rbx
    e997:	movabs $0x7e00000000000000,%r15
    e9a1:	test   %r15,%rsi
    e9a4:	sete   %al
    e9a7:	cmp    $0xffffffffffffffff,%rsi
    e9ab:	sete   %cl
    e9ae:	or     %al,%cl
    e9b0:	mov    %rsi,%rax
    e9b3:	mov    %r11,%r14
    e9b6:	and    %r11,%rax
    e9b9:	cmp    $0x3108180,%rax
    e9bf:	setb   %al
    e9c2:	or     %cl,%al
    e9c4:	jne    e9d4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa34>
    e9c6:	mov    %rsi,%rdx
    e9c9:	mov    %r12,%rdi
    e9cc:	mov    %r13,%rsi
    e9cf:	callq  7810 <term_drop>
    e9d4:	test   %r15,%rbx
    e9d7:	sete   %cl
    e9da:	cmp    $0xffffffffffffffff,%rbx
    e9de:	sete   %dl
    e9e1:	or     %cl,%dl
    e9e3:	and    %rbx,%r14
    e9e6:	cmp    $0x3108180,%r14
    e9ed:	setb   %al
    e9f0:	or     %dl,%al
    e9f2:	jne    ea3f <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa9f>
    e9f4:	mov    %r12,%rdi
    e9f7:	mov    %r13,%rsi
    e9fa:	mov    %rbx,%rdx
    e9fd:	jmp    ea3a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa9a>
    e9ff:	movabs $0x7e00000000000000,%rax
    ea09:	test   %rax,%rdx
    ea0c:	jmp    ea11 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa71>
    ea0e:	test   %rsi,%rdx
    ea11:	sete   %al
    ea14:	cmp    $0xffffffffffffffff,%rdx
    ea18:	sete   %cl
    ea1b:	or     %al,%cl
    ea1d:	mov    %rdx,%rax
    ea20:	and    %rdx,%r11
    ea23:	cmp    $0x3108180,%r11
    ea2a:	setb   %dl
    ea2d:	or     %cl,%dl
    ea2f:	jne    ea3f <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xa9f>
    ea31:	mov    %r12,%rdi
    ea34:	mov    %r13,%rsi
    ea37:	mov    %rax,%rdx
    ea3a:	callq  7810 <term_drop>
    ea3f:	lea    -0xbe96(%rip),%rdi        # 2bb0 <FID_RESW_T+0x350>
    ea46:	callq  15820 <err_fail>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
