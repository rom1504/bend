
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402200 <nx_rt_fast_take2>:
  402200:	push   %rax
  402201:	callq  401ea0 <nx_take2>
  402206:	xor    %eax,%eax
  402208:	pop    %rcx
  402209:	retq   

Disassembly of section .fini:
