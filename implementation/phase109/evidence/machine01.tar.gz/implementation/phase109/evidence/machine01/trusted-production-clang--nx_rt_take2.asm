
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e30 <nx_rt_take2>:
  401e30:	push   %rbx
  401e31:	lea    0x5350(%rip),%rax        # 407188 <nx_context>
  401e38:	cmp    %rax,%rdi
  401e3b:	jne    401e75 <nx_rt_take2+0x45>
  401e3d:	testb  $0x1,0x533c(%rip)        # 407180 <nx_active>
  401e44:	je     401e75 <nx_rt_take2+0x45>
  401e46:	cmpl   $0x0,0x535b(%rip)        # 4071a8 <nx_context+0x20>
  401e4d:	jne    401e81 <nx_rt_take2+0x51>
  401e4f:	mov    %rsi,%rbx
  401e52:	mov    0x532f(%rip),%rdi        # 407188 <nx_context>
  401e59:	callq  4019b0 <nx_id>
  401e5e:	test   $0x1,%al
  401e60:	je     401e8d <nx_rt_take2+0x5d>
  401e62:	lea    0x531f(%rip),%rdi        # 407188 <nx_context>
  401e69:	mov    %rbx,%rsi
  401e6c:	callq  401ea0 <nx_take2>
  401e71:	xor    %eax,%eax
  401e73:	pop    %rbx
  401e74:	retq   
  401e75:	lea    0x2498(%rip),%rdi        # 404314 <_IO_stdin_used+0x314>
  401e7c:	callq  401130 <err_fail>
  401e81:	lea    0x220b(%rip),%rdi        # 404093 <_IO_stdin_used+0x93>
  401e88:	callq  401130 <err_fail>
  401e8d:	lea    0x2226(%rip),%rdi        # 4040ba <_IO_stdin_used+0xba>
  401e94:	callq  401130 <err_fail>

Disassembly of section .fini:
