
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401a14 <nx_rt_pair_rebuild2_c3_k0.cold>:
  401a14:	mov    %r14,%rdx
  401a17:	mov    $0x1,%ecx
  401a1c:	mov    %rbp,%rdi
  401a1f:	mov    %r15,%rsi
  401a22:	mov    %r8,0x8(%rsp)
  401a27:	callq  401397 <rfc_wrap>
  401a2c:	mov    0x8(%rsp),%r8
  401a31:	mov    %rax,%r14
  401a34:	jmpq   403cb1 <nx_rt_pair_rebuild2_c3_k0+0x61>
  401a39:	mov    %r12,%rdx
  401a3c:	mov    $0x1,%ecx
  401a41:	mov    %rbp,%rdi
  401a44:	mov    %r15,%rsi
  401a47:	callq  401397 <rfc_wrap>
  401a4c:	mov    %rax,%r12
  401a4f:	jmpq   403cc9 <nx_rt_pair_rebuild2_c3_k0+0x79>
  401a54:	mov    $0x1,%edx
  401a59:	mov    %rbp,%rdi
  401a5c:	mov    %r15,%rsi
  401a5f:	callq  401178 <heap_alloc_miss>
  401a64:	mov    %rax,%rbx
  401a67:	lea    0x0(%rbp,%rax,8),%r8
  401a6c:	jmpq   403ca1 <nx_rt_pair_rebuild2_c3_k0+0x51>
  401a71:	xor    %edx,%edx
  401a73:	mov    %rbp,%rdi
  401a76:	mov    %r15,%rsi
  401a79:	mov    %rcx,0x8(%rsp)
  401a7e:	callq  401100 <heap_hand>
  401a83:	mov    0x8(%rsp),%rcx
  401a88:	jmpq   403da7 <nx_rt_pair_rebuild2_c3_k0+0x157>
  401a8d:	mov    (%rdi),%r14
  401a90:	mov    %rsi,%rdx
  401a93:	mov    %rbp,%rdi
  401a96:	mov    %r15,%rsi
  401a99:	mov    (%r8),%r13
  401a9c:	callq  401471 <span_fade.constprop.0>
  401aa1:	jmpq   403d10 <nx_rt_pair_rebuild2_c3_k0+0xc0>

Disassembly of section .fini:
