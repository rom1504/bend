  406fb0:	endbr64 
  406fb4:	push   %rbp
  406fb5:	mov    %rsp,%rbp
  406fb8:	mov    %esi,%eax
  406fba:	mov    %edx,%ecx
  406fbc:	add    %ecx,%eax
  406fbe:	mov    %eax,%edx
  406fc0:	callq  406f30 <p113d_FID_36_112_114_111_100_117_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_>
  406fc5:	leaveq 
  406fc6:	retq   
  406fc7:	nopw   0x0(%rax,%rax,1)
