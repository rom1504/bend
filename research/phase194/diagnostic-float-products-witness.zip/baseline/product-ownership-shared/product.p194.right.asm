  4085dd:	push   %rbp
  4085de:	mov    %rsp,%rbp
  4085e1:	sub    $0x8e0,%rsp
  4085e8:	mov    %r12,-0x10(%rbp)
  4085ec:	mov    %rdi,%rax
  4085ef:	mov    %rax,%r12
  4085f2:	mov    %rsi,%rax
  4085f5:	mov    %rax,-0x30(%rbp)
  4085f9:	mov    %rdx,%rax
  4085fc:	mov    %rax,%rdi
  4085ff:	mov    %edi,%edi
  408601:	xor    $0x7,%rdi
  408608:	mov    %rdi,%rax
  40860b:	mov    -0x10(%rbp),%r12
  40860f:	mov    %rbp,%rsp
  408612:	pop    %rbp
  408613:	retq   
