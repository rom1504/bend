0000000000417f90 <p125_rt_ctor2>:
  417f90:	push   r15
  417f92:	push   r14
  417f94:	push   r13
  417f96:	mov    r13,rdx
  417f99:	push   r12
  417f9b:	push   rbp
  417f9c:	push   rbx
  417f9d:	mov    ebx,esi
  417f9f:	sub    rsp,0x8
  417fa3:	mov    r12,QWORD PTR [rdi+0x8]
  417fa7:	mov    r14,QWORD PTR [rdi]
  417faa:	mov    rbp,QWORD PTR [r12+0x8]
  417faf:	test   rbp,rbp
  417fb2:	je     40502c <p125_rt_ctor2.cold+0x30>
  417fb8:	lea    rcx,[r14+rbp*8]
  417fbc:	mov    rax,QWORD PTR [rcx]
  417fbf:	sub    QWORD PTR [r12+0x108],0x2
  417fc8:	mov    QWORD PTR [r12+0x8],rax
  417fcd:	mov    rax,QWORD PTR [rip+0x108afc]        # 520ad0 <p111_program_active>
  417fd4:	mov    rdx,QWORD PTR [r13+0x0]
  417fd8:	test   BYTE PTR [rax+0x58],0x8
  417fdc:	je     418000 <p125_rt_ctor2+0x70>
  417fde:	mov    rax,QWORD PTR [rax+0x88]
  417fe5:	cmp    BYTE PTR [rax+rbx*1],0x0
  417fe9:	jne    418000 <p125_rt_ctor2+0x70>
  417feb:	mov    QWORD PTR [rcx],rdx
  417fee:	mov    rax,QWORD PTR [r13+0x8]
  417ff2:	mov    QWORD PTR [r14+rbp*8+0x8],rax
  417ff7:	jmp    418034 <p125_rt_ctor2+0xa4>
  417ff9:	nop    DWORD PTR [rax+0x0]
  418000:	mov    rax,rdx
  418003:	lea    r15,[r14+rbp*8]
  418007:	shr    rax,0x38
  41800b:	and    eax,0x7f
  41800e:	cmp    rax,0x2
  418012:	je     418068 <p125_rt_ctor2+0xd8>
  418014:	mov    QWORD PTR [r15],rdx
  418017:	mov    rdx,QWORD PTR [r13+0x8]
  41801b:	lea    r13,[r14+rbp*8+0x8]
  418020:	mov    rax,rdx
  418023:	shr    rax,0x38
  418027:	and    eax,0x7f
  41802a:	cmp    rax,0x2
  41802e:	je     418058 <p125_rt_ctor2+0xc8>
  418030:	mov    QWORD PTR [r13+0x0],rdx
  418034:	mov    rax,rbx
  418037:	add    rsp,0x8
  41803b:	shl    rax,0x28
  41803f:	pop    rbx
  418040:	or     rax,rbp
  418043:	pop    rbp
  418044:	pop    r12
  418046:	bts    rax,0x39
  41804b:	pop    r13
  41804d:	pop    r14
  41804f:	pop    r15
  418051:	ret    
  418052:	nop    WORD PTR [rax+rax*1+0x0]
  418058:	test   rdx,rdx
  41805b:	js     418030 <p125_rt_ctor2+0xa0>
  41805d:	jmp    404ffc <p125_rt_ctor2.cold>
  418062:	nop    WORD PTR [rax+rax*1+0x0]
  418068:	test   rdx,rdx
  41806b:	js     418014 <p125_rt_ctor2+0x84>
  41806d:	jmp    405014 <p125_rt_ctor2.cold+0x18>
  418072:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  41807d:	nop    DWORD PTR [rax]

