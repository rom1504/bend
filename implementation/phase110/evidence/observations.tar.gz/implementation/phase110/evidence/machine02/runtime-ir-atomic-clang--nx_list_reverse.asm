
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	push   %rbp
  401df1:	push   %r15
  401df3:	push   %r14
  401df5:	push   %r13
  401df7:	push   %r12
  401df9:	push   %rbx
  401dfa:	sub    $0x18,%rsp
  401dfe:	mov    %rdx,%r14
  401e01:	mov    %rsi,%r13
  401e04:	mov    %rdi,%rbx
  401e07:	callq  404660 <nx_rt_ir_heap>
  401e0c:	mov    %rax,(%rsp)
  401e10:	mov    %rbx,%rdi
  401e13:	callq  4046d0 <nx_rt_ir_alc>
  401e18:	mov    %rax,%r12
  401e1b:	mov    %rbx,0x10(%rsp)
  401e20:	jmp    401e51 <nx_list_reverse+0x61>
  401e22:	data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  401e30:	mov    %rbx,%rdi
  401e33:	mov    %r13,%rsi
  401e36:	mov    %r14,%rdx
  401e39:	callq  403a20 <nx_rt_rebuild2_c1_k0>
  401e3e:	mov    %rax,%r14
  401e41:	mov    %rbx,%rdi
  401e44:	xor    %esi,%esi
  401e46:	callq  403350 <nx_rt_fast_field>
  401e4b:	mov    %rax,%r13
  401e4e:	mov    %r15,%r12
  401e51:	mov    %r13,%rax
  401e54:	shr    $0x28,%rax
  401e58:	cmp    $0x1,%ax
  401e5c:	jne    402078 <nx_list_reverse+0x288>
  401e62:	mov    %r12,%r15
  401e65:	mov    %r13,%rbp
  401e68:	movabs $0xffffffffff,%rax
  401e72:	and    %rax,%rbp
  401e75:	test   %r13,%r13
  401e78:	js     401eb0 <nx_list_reverse+0xc0>
  401e7a:	cmp    $0x3108180,%rbp
  401e81:	jb     401e30 <nx_list_reverse+0x40>
  401e83:	mov    (%rsp),%rax
  401e87:	lea    (%rax,%rbp,8),%rsi
  401e8b:	mov    (%rax,%rbp,8),%rbx
  401e8f:	mov    0x8(%rax,%rbp,8),%r13
  401e94:	lea    (%rax,%rbp,8),%rdi
  401e98:	add    $0x8,%rdi
  401e9c:	jmpq   401f39 <nx_list_reverse+0x149>
  401ea1:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  401eb0:	mov    %rbx,%rdi
  401eb3:	mov    %rbp,%rsi
  401eb6:	callq  404740 <nx_rt_ir_view>
  401ebb:	mov    %rax,%r12
  401ebe:	and    $0xffffff,%eax
  401ec3:	cmp    $0x1,%eax
  401ec6:	jne    401e30 <nx_list_reverse+0x40>
  401ecc:	mov    %r12,%rax
  401ecf:	shr    $0x1f,%rax
  401ed3:	cmp    $0x62102,%rax
  401ed9:	jbe    401e30 <nx_list_reverse+0x40>
  401edf:	shr    $0x18,%r12
  401ee3:	mov    (%rsp),%rdx
  401ee7:	lea    (%rdx,%r12,8),%rsi
  401eeb:	mov    (%rdx,%r12,8),%rbx
  401eef:	mov    0x8(%rdx,%r12,8),%r13
  401ef4:	lea    0x8(%rdx,%r12,8),%rdi
  401ef9:	mov    (%r15),%rax
  401efc:	mov    %rax,(%rdx,%rbp,8)
  401f00:	mov    %rbp,(%r15)
  401f03:	mov    0x100(%r15),%rax
  401f0a:	inc    %rax
  401f0d:	mov    %rax,0x100(%r15)
  401f14:	cmp    $0x8000,%rax
  401f1a:	jb     401f36 <nx_list_reverse+0x146>
  401f1c:	mov    %rdi,0x8(%rsp)
  401f21:	mov    0x10(%rsp),%rdi
  401f26:	mov    %rsi,%rbp
  401f29:	callq  401c36 <nx_rt_ir_hand0>
  401f2e:	mov    0x8(%rsp),%rdi
  401f33:	mov    %rbp,%rsi
  401f36:	mov    %r12,%rbp
  401f39:	mov    %rbx,%rax
  401f3c:	movabs $0xff00000000000000,%rcx
  401f46:	and    %rcx,%rax
  401f49:	movabs $0x200000000000000,%rcx
  401f53:	cmp    %rcx,%rax
  401f56:	mov    %r15,%r12
  401f59:	jne    401fca <nx_list_reverse+0x1da>
  401f5b:	mov    (%r12),%rax
  401f5f:	test   %rax,%rax
  401f62:	je     401f7e <nx_list_reverse+0x18e>
  401f64:	mov    (%rsp),%rdx
  401f68:	lea    (%rdx,%rax,8),%rcx
  401f6c:	mov    (%rdx,%rax,8),%rdx
  401f70:	mov    %rdx,(%r12)
  401f74:	decq   0x100(%r12)
  401f7c:	jmp    401fa0 <nx_list_reverse+0x1b0>
  401f7e:	mov    %rdi,0x8(%rsp)
  401f83:	mov    0x10(%rsp),%rdi
  401f88:	mov    %rsi,%r15
  401f8b:	callq  401c25 <nx_rt_ir_alloc0>
  401f90:	mov    0x8(%rsp),%rdi
  401f95:	mov    %r15,%rsi
  401f98:	mov    (%rsp),%rcx
  401f9c:	lea    (%rcx,%rax,8),%rcx
  401fa0:	mov    %rbx,%rdx
  401fa3:	shl    $0x18,%rdx
  401fa7:	inc    %rdx
  401faa:	mov    %rdx,(%rcx)
  401fad:	movabs $0x2ffff0000000000,%rcx
  401fb7:	and    %rcx,%rbx
  401fba:	movabs $0x8000000000000000,%rcx
  401fc4:	or     %rcx,%rax
  401fc7:	or     %rax,%rbx
  401fca:	mov    %r14,%rax
  401fcd:	movabs $0xff00000000000000,%rcx
  401fd7:	and    %rcx,%rax
  401fda:	movabs $0x200000000000000,%rcx
  401fe4:	cmp    %rcx,%rax
  401fe7:	jne    402058 <nx_list_reverse+0x268>
  401fe9:	mov    (%r12),%rax
  401fed:	test   %rax,%rax
  401ff0:	je     40200c <nx_list_reverse+0x21c>
  401ff2:	mov    (%rsp),%rdx
  401ff6:	lea    (%rdx,%rax,8),%rcx
  401ffa:	mov    (%rdx,%rax,8),%rdx
  401ffe:	mov    %rdx,(%r12)
  402002:	decq   0x100(%r12)
  40200a:	jmp    40202e <nx_list_reverse+0x23e>
  40200c:	mov    %rdi,0x8(%rsp)
  402011:	mov    0x10(%rsp),%rdi
  402016:	mov    %rsi,%r15
  402019:	callq  401c25 <nx_rt_ir_alloc0>
  40201e:	mov    0x8(%rsp),%rdi
  402023:	mov    %r15,%rsi
  402026:	mov    (%rsp),%rcx
  40202a:	lea    (%rcx,%rax,8),%rcx
  40202e:	mov    %r14,%rdx
  402031:	shl    $0x18,%rdx
  402035:	inc    %rdx
  402038:	mov    %rdx,(%rcx)
  40203b:	movabs $0x2ffff0000000000,%rcx
  402045:	and    %rcx,%r14
  402048:	movabs $0x8000000000000000,%rcx
  402052:	or     %rcx,%r14
  402055:	or     %rax,%r14
  402058:	mov    %rbx,(%rsi)
  40205b:	mov    %r14,(%rdi)
  40205e:	movabs $0x200010000000000,%rax
  402068:	or     %rax,%rbp
  40206b:	mov    %rbp,%r14
  40206e:	mov    0x10(%rsp),%rbx
  402073:	jmpq   401e51 <nx_list_reverse+0x61>
  402078:	movzwl %ax,%eax
  40207b:	test   %eax,%eax
  40207d:	jne    402091 <nx_list_reverse+0x2a1>
  40207f:	mov    %r14,%rax
  402082:	add    $0x18,%rsp
  402086:	pop    %rbx
  402087:	pop    %r12
  402089:	pop    %r13
  40208b:	pop    %r14
  40208d:	pop    %r15
  40208f:	pop    %rbp
  402090:	retq   
  402091:	mov    %rbx,%rdi
  402094:	mov    $0x1,%esi
  402099:	add    $0x18,%rsp
  40209d:	pop    %rbx
  40209e:	pop    %r12
  4020a0:	pop    %r13
  4020a2:	pop    %r14
  4020a4:	pop    %r15
  4020a6:	pop    %rbp
  4020a7:	jmpq   402b50 <nx_rt_fail>

Disassembly of section .fini:
