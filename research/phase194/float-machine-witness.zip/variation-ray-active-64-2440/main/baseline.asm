  41c2d5:	lea    0x1162c(%rip),%rdx        # 42d908 <p111_program>
  41c2dc:	jmpq   422a90 <p111_rt_main>
  41c2e1:	nopw   %cs:0x0(%rax,%rax,1)
  41c2eb:	nopl   0x0(%rax,%rax,1)
