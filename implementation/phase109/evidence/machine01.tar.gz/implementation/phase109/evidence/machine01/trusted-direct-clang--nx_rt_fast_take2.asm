
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004028a0 <nx_rt_fast_take2>:
  4028a0:	movabs $0xffffffffff,%rax
  4028aa:	push   %r12
  4028ac:	and    %rsi,%rax
  4028af:	push   %rbp
  4028b0:	push   %rbx
  4028b1:	mov    %rdi,%rbx
  4028b4:	mov    (%rdi),%rdi
  4028b7:	lea    0x0(,%rax,8),%rcx
  4028bf:	mov    0x8(%rbx),%rbp
  4028c3:	lea    (%rdi,%rcx,1),%rdx
  4028c7:	test   %rsi,%rsi
  4028ca:	js     402938 <nx_rt_fast_take2+0x98>
  4028cc:	mov    (%rdx),%rdx
  4028cf:	mov    %rdx,0x10(%rbx)
  4028d3:	mov    0x8(%rdi,%rcx,1),%rdx
  4028d8:	mov    %rdx,0x18(%rbx)
  4028dc:	cmp    $0x310817f,%rax
  4028e2:	ja     4028f8 <nx_rt_fast_take2+0x58>
  4028e4:	movl   $0x3,0x20(%rbx)
  4028eb:	xor    %eax,%eax
  4028ed:	pop    %rbx
  4028ee:	pop    %rbp
  4028ef:	pop    %r12
  4028f1:	retq   
  4028f2:	nopw   0x0(%rax,%rax,1)
  4028f8:	mov    0x8(%rbp),%rdx
  4028fc:	mov    %rdx,(%rdi,%rax,8)
  402900:	mov    0x48d2(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402906:	mov    %rax,0x8(%rbp)
  40290a:	mov    0x108(%rbp),%rax
  402911:	add    $0x2,%rax
  402915:	mov    %rax,0x108(%rbp)
  40291c:	cmp    %rdx,%rax
  40291f:	jae    40160f <nx_rt_fast_take2.cold>
  402925:	movl   $0x3,0x20(%rbx)
  40292c:	xor    %eax,%eax
  40292e:	pop    %rbx
  40292f:	pop    %rbp
  402930:	pop    %r12
  402932:	retq   
  402933:	nopl   0x0(%rax,%rax,1)
  402938:	mov    0x4(%rdx),%ecx
  40293b:	mov    (%rdx),%r8d
  40293e:	shl    $0x20,%rcx
  402942:	or     %r8,%rcx
  402945:	mov    %rcx,%r12
  402948:	and    $0xffffff,%ecx
  40294e:	shr    $0x18,%r12
  402952:	lea    0x0(,%r12,8),%r8
  40295a:	lea    (%rdi,%r8,1),%r9
  40295e:	lea    0x8(%rdi,%r8,1),%r8
  402963:	cmp    $0x1,%rcx
  402967:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  40296d:	mov    (%rdx),%ecx
  40296f:	mov    (%r9),%rcx
  402972:	mov    %rcx,0x10(%rbx)
  402976:	mov    (%r8),%rcx
  402979:	mov    %rcx,0x18(%rbx)
  40297d:	mov    0x0(%rbp),%rcx
  402981:	mov    %rcx,(%rdx)
  402984:	mov    0x484e(%rip),%edx        # 4071d8 <KEEP_WORDS>
  40298a:	mov    %rax,0x0(%rbp)
  40298e:	mov    0x100(%rbp),%rax
  402995:	add    $0x1,%rax
  402999:	mov    %rax,0x100(%rbp)
  4029a0:	cmp    %rdx,%rax
  4029a3:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  4029a9:	mov    %r12,%rax
  4029ac:	jmpq   4028dc <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
