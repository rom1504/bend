
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403490 <nx_rt_fast_field>:
  403490:	mov    %esi,%ecx
  403492:	mov    $0xfffffffe,%eax
  403497:	rol    %cl,%eax
  403499:	add    $0x2,%rcx
  40349d:	and    %eax,0x20(%rdi)
  4034a0:	mov    (%rdi,%rcx,8),%rax
  4034a4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  4034ac:	retq   

Disassembly of section .fini:
