
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004031d0 <nx_rt_fast_take2>:
  4031d0:	movabs $0xffffffffff,%rax
  4031da:	push   %r12
  4031dc:	and    %rsi,%rax
  4031df:	push   %rbp
  4031e0:	push   %rbx
  4031e1:	mov    %rdi,%rbx
  4031e4:	mov    (%rdi),%rdi
  4031e7:	lea    0x0(,%rax,8),%rcx
  4031ef:	mov    0x8(%rbx),%rbp
  4031f3:	lea    (%rdi,%rcx,1),%rdx
  4031f7:	test   %rsi,%rsi
  4031fa:	js     403268 <nx_rt_fast_take2+0x98>
  4031fc:	mov    (%rdx),%rdx
  4031ff:	mov    %rdx,0x10(%rbx)
  403203:	mov    0x8(%rdi,%rcx,1),%rdx
  403208:	mov    %rdx,0x18(%rbx)
  40320c:	cmp    $0x310817f,%rax
  403212:	ja     403228 <nx_rt_fast_take2+0x58>
  403214:	movl   $0x3,0x20(%rbx)
  40321b:	xor    %eax,%eax
  40321d:	pop    %rbx
  40321e:	pop    %rbp
  40321f:	pop    %r12
  403221:	retq   
  403222:	nopw   0x0(%rax,%rax,1)
  403228:	mov    0x8(%rbp),%rdx
  40322c:	mov    %rdx,(%rdi,%rax,8)
  403230:	mov    0x3efa2(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403236:	mov    %rax,0x8(%rbp)
  40323a:	mov    0x108(%rbp),%rax
  403241:	add    $0x2,%rax
  403245:	mov    %rax,0x108(%rbp)
  40324c:	cmp    %rdx,%rax
  40324f:	jae    4015fe <nx_rt_fast_take2.cold>
  403255:	movl   $0x3,0x20(%rbx)
  40325c:	xor    %eax,%eax
  40325e:	pop    %rbx
  40325f:	pop    %rbp
  403260:	pop    %r12
  403262:	retq   
  403263:	nopl   0x0(%rax,%rax,1)
  403268:	mov    0x4(%rdx),%ecx
  40326b:	mov    (%rdx),%r8d
  40326e:	shl    $0x20,%rcx
  403272:	or     %r8,%rcx
  403275:	mov    %rcx,%r12
  403278:	and    $0xffffff,%ecx
  40327e:	shr    $0x18,%r12
  403282:	lea    0x0(,%r12,8),%r8
  40328a:	lea    (%rdi,%r8,1),%r9
  40328e:	lea    0x8(%rdi,%r8,1),%r8
  403293:	cmp    $0x1,%rcx
  403297:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  40329d:	mov    (%rdx),%ecx
  40329f:	mov    (%r9),%rcx
  4032a2:	mov    %rcx,0x10(%rbx)
  4032a6:	mov    (%r8),%rcx
  4032a9:	mov    %rcx,0x18(%rbx)
  4032ad:	mov    0x0(%rbp),%rcx
  4032b1:	mov    %rcx,(%rdx)
  4032b4:	mov    0x3ef1e(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4032ba:	mov    %rax,0x0(%rbp)
  4032be:	mov    0x100(%rbp),%rax
  4032c5:	add    $0x1,%rax
  4032c9:	mov    %rax,0x100(%rbp)
  4032d0:	cmp    %rdx,%rax
  4032d3:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  4032d9:	mov    %r12,%rax
  4032dc:	jmpq   40320c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
