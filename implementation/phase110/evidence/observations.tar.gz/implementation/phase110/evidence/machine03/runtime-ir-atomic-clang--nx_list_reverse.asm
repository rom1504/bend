
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e10 <nx_list_reverse>:
  401e10:	push   %rbp
  401e11:	push   %r15
  401e13:	push   %r14
  401e15:	push   %r13
  401e17:	push   %r12
  401e19:	push   %rbx
  401e1a:	sub    $0x18,%rsp
  401e1e:	mov    %rdx,%r14
  401e21:	mov    %rsi,%r13
  401e24:	mov    %rdi,%rbx
  401e27:	callq  404520 <nx_rt_ir_heap>
  401e2c:	mov    %rax,%r15
  401e2f:	mov    %rbx,%rdi
  401e32:	callq  404590 <nx_rt_ir_alc>
  401e37:	mov    %rax,%rsi
  401e3a:	mov    %rax,0x8(%rsp)
  401e3f:	jmp    401e73 <nx_list_reverse+0x63>
  401e41:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  401e50:	mov    %rbx,%rdi
  401e53:	mov    %r13,%rsi
  401e56:	mov    %r14,%rdx
  401e59:	callq  4038e0 <nx_rt_rebuild2_c1_k0>
  401e5e:	mov    %rax,%r14
  401e61:	mov    %rbx,%rdi
  401e64:	xor    %esi,%esi
  401e66:	callq  403210 <nx_rt_fast_field>
  401e6b:	mov    0x8(%rsp),%rsi
  401e70:	mov    %rax,%r13
  401e73:	mov    %r13,%rax
  401e76:	shr    $0x28,%rax
  401e7a:	cmp    $0x1,%ax
  401e7e:	jne    401fe4 <nx_list_reverse+0x1d4>
  401e84:	mov    %r13,%rbp
  401e87:	movabs $0xffffffffff,%rax
  401e91:	and    %rax,%rbp
  401e94:	test   %r13,%r13
  401e97:	js     401ec0 <nx_list_reverse+0xb0>
  401e99:	cmp    $0x3108180,%rbp
  401ea0:	jb     401e50 <nx_list_reverse+0x40>
  401ea2:	lea    (%r15,%rbp,8),%r12
  401ea6:	mov    (%r15,%rbp,8),%rdi
  401eaa:	mov    0x8(%r15,%rbp,8),%r13
  401eaf:	lea    (%r15,%rbp,8),%r8
  401eb3:	add    $0x8,%r8
  401eb7:	jmpq   401f53 <nx_list_reverse+0x143>
  401ebc:	nopl   0x0(%rax)
  401ec0:	mov    %rbx,%rdi
  401ec3:	mov    %rbp,%rsi
  401ec6:	callq  404600 <nx_rt_ir_view>
  401ecb:	mov    0x8(%rsp),%rsi
  401ed0:	mov    %rax,%r12
  401ed3:	and    $0xffffff,%eax
  401ed8:	cmp    $0x1,%eax
  401edb:	jne    401e50 <nx_list_reverse+0x40>
  401ee1:	mov    %r12,%rax
  401ee4:	shr    $0x1f,%rax
  401ee8:	cmp    $0x62102,%rax
  401eee:	jbe    401e50 <nx_list_reverse+0x40>
  401ef4:	shr    $0x18,%r12
  401ef8:	lea    (%r15,%r12,8),%rax
  401efc:	mov    %rax,(%rsp)
  401f00:	mov    (%r15,%r12,8),%rdi
  401f04:	mov    0x8(%r15,%r12,8),%r13
  401f09:	lea    0x8(%r15,%r12,8),%r8
  401f0e:	mov    (%rsi),%rax
  401f11:	mov    %rax,(%r15,%rbp,8)
  401f15:	mov    %rbp,(%rsi)
  401f18:	mov    0x100(%rsi),%rax
  401f1f:	inc    %rax
  401f22:	mov    %rax,0x100(%rsi)
  401f29:	cmp    $0x8000,%rax
  401f2f:	jb     401f4c <nx_list_reverse+0x13c>
  401f31:	mov    %rdi,%rbp
  401f34:	mov    %rbx,%rdi
  401f37:	callq  401c36 <nx_rt_ir_hand0>
  401f3c:	lea    (%r15,%r12,8),%r8
  401f40:	add    $0x8,%r8
  401f44:	mov    %rbp,%rdi
  401f47:	mov    0x8(%rsp),%rsi
  401f4c:	mov    %r12,%rbp
  401f4f:	mov    (%rsp),%r12
  401f53:	mov    %r14,%rax
  401f56:	shr    $0x38,%rax
  401f5a:	cmp    $0x2,%eax
  401f5d:	jne    401fc8 <nx_list_reverse+0x1b8>
  401f5f:	mov    (%rsi),%rax
  401f62:	test   %rax,%rax
  401f65:	je     401f7b <nx_list_reverse+0x16b>
  401f67:	lea    (%r15,%rax,8),%rcx
  401f6b:	mov    (%r15,%rax,8),%rdx
  401f6f:	mov    %rdx,(%rsi)
  401f72:	decq   0x100(%rsi)
  401f79:	jmp    401f9e <nx_list_reverse+0x18e>
  401f7b:	mov    %rdi,(%rsp)
  401f7f:	mov    %rbx,%rdi
  401f82:	mov    %r8,0x10(%rsp)
  401f87:	callq  401c25 <nx_rt_ir_alloc0>
  401f8c:	mov    0x10(%rsp),%r8
  401f91:	mov    (%rsp),%rdi
  401f95:	mov    0x8(%rsp),%rsi
  401f9a:	lea    (%r15,%rax,8),%rcx
  401f9e:	mov    %r14,%rdx
  401fa1:	shl    $0x18,%rdx
  401fa5:	inc    %rdx
  401fa8:	mov    %rdx,(%rcx)
  401fab:	movabs $0x2ffff0000000000,%rcx
  401fb5:	and    %rcx,%r14
  401fb8:	movabs $0x8000000000000000,%rcx
  401fc2:	or     %rcx,%r14
  401fc5:	or     %rax,%r14
  401fc8:	mov    %rdi,(%r12)
  401fcc:	mov    %r14,(%r8)
  401fcf:	movabs $0x200010000000000,%rax
  401fd9:	or     %rax,%rbp
  401fdc:	mov    %rbp,%r14
  401fdf:	jmpq   401e73 <nx_list_reverse+0x63>
  401fe4:	movzwl %ax,%eax
  401fe7:	test   %eax,%eax
  401fe9:	jne    401ffd <nx_list_reverse+0x1ed>
  401feb:	mov    %r14,%rax
  401fee:	add    $0x18,%rsp
  401ff2:	pop    %rbx
  401ff3:	pop    %r12
  401ff5:	pop    %r13
  401ff7:	pop    %r14
  401ff9:	pop    %r15
  401ffb:	pop    %rbp
  401ffc:	retq   
  401ffd:	mov    %rbx,%rdi
  402000:	mov    $0x1,%esi
  402005:	add    $0x18,%rsp
  402009:	pop    %rbx
  40200a:	pop    %r12
  40200c:	pop    %r13
  40200e:	pop    %r14
  402010:	pop    %r15
  402012:	pop    %rbp
  402013:	jmpq   402a10 <nx_rt_fail>

Disassembly of section .fini:
