
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402960 <nx_rt_fast_field>:
  402960:	mov    %esi,%ecx
  402962:	mov    $0xfffffffe,%eax
  402967:	rol    %cl,%eax
  402969:	add    $0x2,%rcx
  40296d:	and    %eax,0x20(%rdi)
  402970:	mov    (%rdi,%rcx,8),%rax
  402974:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  40297c:	retq   

Disassembly of section .fini:
