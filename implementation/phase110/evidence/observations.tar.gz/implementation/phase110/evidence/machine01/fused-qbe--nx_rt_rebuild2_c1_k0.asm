
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004033a0 <nx_rt_rebuild2_c1_k0>:
  4033a0:	push   %r13
  4033a2:	mov    %rsi,%r10
  4033a5:	mov    %rdx,%r8
  4033a8:	movabs $0xffffffffff,%r9
  4033b2:	push   %r12
  4033b4:	and    %r10,%r9
  4033b7:	push   %rbp
  4033b8:	lea    0x0(,%r9,8),%rax
  4033c0:	push   %rbx
  4033c1:	mov    %rdi,%rbx
  4033c4:	sub    $0x28,%rsp
  4033c8:	mov    (%rdi),%rdi
  4033cb:	mov    0x8(%rbx),%rsi
  4033cf:	lea    (%rdi,%rax,1),%rdx
  4033d3:	test   %r10,%r10
  4033d6:	js     403440 <nx_rt_rebuild2_c1_k0+0xa0>
  4033d8:	mov    (%rdx),%r12
  4033db:	mov    0x8(%rdi,%rax,1),%rbp
  4033e0:	cmp    $0x310817f,%r9
  4033e7:	jbe    403418 <nx_rt_rebuild2_c1_k0+0x78>
  4033e9:	mov    %rbp,0x10(%rbx)
  4033ed:	mov    %r12,%rcx
  4033f0:	mov    $0x1,%edx
  4033f5:	movq   $0xffffffffffffffff,0x18(%rbx)
  4033fd:	movl   $0x1,0x20(%rbx)
  403404:	add    $0x28,%rsp
  403408:	pop    %rbx
  403409:	pop    %rbp
  40340a:	pop    %r12
  40340c:	pop    %r13
  40340e:	jmpq   401ff0 <nx_construct2>
  403413:	nopl   0x0(%rax,%rax,1)
  403418:	mov    0x8(%rsi),%r9
  40341c:	test   %r9,%r9
  40341f:	je     4016c4 <nx_rt_rebuild2_c1_k0.cold>
  403425:	mov    (%rdi,%r9,8),%rax
  403429:	subq   $0x2,0x108(%rsi)
  403431:	mov    %rax,0x8(%rsi)
  403435:	jmp    4033e9 <nx_rt_rebuild2_c1_k0+0x49>
  403437:	nopw   0x0(%rax,%rax,1)
  403440:	mov    0x4(%rdx),%eax
  403443:	mov    (%rdx),%ecx
  403445:	shl    $0x20,%rax
  403449:	or     %rcx,%rax
  40344c:	mov    %rax,%r13
  40344f:	and    $0xffffff,%eax
  403454:	shr    $0x18,%r13
  403458:	lea    0x0(,%r13,8),%r11
  403460:	lea    (%rdi,%r11,1),%rbp
  403464:	lea    0x8(%rdi,%r11,1),%r11
  403469:	cmp    $0x1,%rax
  40346d:	jne    40170a <nx_rt_rebuild2_c1_k0.cold+0x46>
  403473:	mov    (%rdx),%eax
  403475:	mov    (%rsi),%rax
  403478:	mov    0x0(%rbp),%r12
  40347c:	mov    (%r11),%rbp
  40347f:	mov    %rax,(%rdx)
  403482:	mov    0x100(%rsi),%rax
  403489:	mov    0x3dd49(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40348f:	mov    %r9,(%rsi)
  403492:	add    $0x1,%rax
  403496:	mov    %rax,0x100(%rsi)
  40349d:	cmp    %rdx,%rax
  4034a0:	jae    4016f4 <nx_rt_rebuild2_c1_k0.cold+0x30>
  4034a6:	mov    %r13,%r9
  4034a9:	jmpq   4033e0 <nx_rt_rebuild2_c1_k0+0x40>

Disassembly of section .fini:
