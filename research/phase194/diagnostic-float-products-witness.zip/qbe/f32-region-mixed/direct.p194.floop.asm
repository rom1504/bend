  406a30:	endbr64 
  406a34:	push   %rbp
  406a35:	mov    %rsp,%rbp
  406a38:	mov    %rdx,%rax
  406a3b:	mov    %rax,%rdx
  406a3e:	xchg   %ax,%ax
  406a40:	cmp    $0x0,%rsi
  406a44:	je     406ab7 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x87>
  406a46:	movq   %rdx,%xmm1
  406a4b:	movss  %xmm1,%xmm0
  406a4f:	addss  0xf5b1(%rip),%xmm0        # 416008 <_IO_stdin_used+0x8>
  406a57:	mulss  0xf5a5(%rip),%xmm0        # 416004 <_IO_stdin_used+0x4>
  406a5f:	subss  %xmm1,%xmm0
  406a63:	mulss  0xf5a9(%rip),%xmm0        # 416014 <_IO_stdin_used+0x14>
  406a6b:	ucomiss 0xf59e(%rip),%xmm0        # 416010 <_IO_stdin_used+0x10>
  406a72:	setae  %al
  406a75:	movzbl %al,%eax
  406a78:	movss  0xf58c(%rip),%xmm1        # 41600c <_IO_stdin_used+0xc>
  406a80:	ucomiss %xmm0,%xmm1
  406a83:	seta   %cl
  406a86:	movzbl %cl,%ecx
  406a89:	test   %eax,%ecx
  406a8b:	cvttss2si %xmm0,%rax
  406a90:	mov    %eax,%eax
  406a92:	mov    $0x0,%ecx
  406a97:	cmove  %rcx,%rax
  406a9b:	mov    %eax,%eax
  406a9d:	cvtsi2ss %rax,%xmm0
  406aa2:	mulss  0xf55e(%rip),%xmm0        # 416008 <_IO_stdin_used+0x8>
  406aaa:	movq   %xmm0,%rax
  406aaf:	mov    %eax,%edx
  406ab1:	sub    $0x1,%rsi
  406ab5:	jmp    406a40 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x10>
  406ab7:	mov    %rdx,%rax
  406aba:	leaveq 
  406abb:	retq   
  406abc:	nopl   0x0(%rax)
