
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004034b0 <nx_rt_rebuild2>:
  4034b0:	push   %r15
  4034b2:	push   %r14
  4034b4:	push   %r13
  4034b6:	mov    %ecx,%r13d
  4034b9:	push   %r12
  4034bb:	mov    %rdi,%r12
  4034be:	push   %rbp
  4034bf:	movabs $0xffffffffff,%rbp
  4034c9:	push   %rbx
  4034ca:	and    %rsi,%rbp
  4034cd:	mov    %edx,%ebx
  4034cf:	lea    0x0(,%rbp,8),%rdx
  4034d7:	sub    $0x28,%rsp
  4034db:	mov    (%rdi),%r14
  4034de:	mov    0x8(%rdi),%r15
  4034e2:	lea    (%r14,%rdx,1),%rax
  4034e6:	test   %rsi,%rsi
  4034e9:	js     4035d0 <nx_rt_rebuild2+0x120>
  4034ef:	mov    (%rax),%rax
  4034f2:	mov    %rax,0x10(%rsp)
  4034f7:	mov    0x8(%r14,%rdx,1),%rax
  4034fc:	mov    %rax,0x18(%rsp)
  403501:	cmp    $0x310817f,%rbp
  403508:	jbe    4035a8 <nx_rt_rebuild2+0xf8>
  40350e:	lea    (%r14,%rbp,8),%r9
  403512:	mov    $0x1,%eax
  403517:	mov    0x10(%rsp,%r13,8),%rdx
  40351c:	movq   $0xffffffffffffffff,0x18(%r12)
  403525:	movl   $0x1,0x20(%r12)
  40352e:	sub    %r13d,%eax
  403531:	mov    0x10(%rsp,%rax,8),%rax
  403536:	mov    %rax,0x10(%r12)
  40353b:	mov    %rdx,%rax
  40353e:	shr    $0x38,%rax
  403542:	and    $0x7f,%eax
  403545:	cmp    $0x2,%rax
  403549:	je     403588 <nx_rt_rebuild2+0xd8>
  40354b:	mov    %r8,%rax
  40354e:	mov    %rdx,(%r9)
  403551:	lea    0x8(%r14,%rbp,8),%r12
  403556:	shr    $0x38,%rax
  40355a:	and    $0x7f,%eax
  40355d:	cmp    $0x2,%rax
  403561:	je     403598 <nx_rt_rebuild2+0xe8>
  403563:	mov    %rbx,%rax
  403566:	mov    %r8,(%r12)
  40356a:	add    $0x28,%rsp
  40356e:	shl    $0x28,%rax
  403572:	pop    %rbx
  403573:	or     %rbp,%rax
  403576:	pop    %rbp
  403577:	pop    %r12
  403579:	bts    $0x39,%rax
  40357e:	pop    %r13
  403580:	pop    %r14
  403582:	pop    %r15
  403584:	retq   
  403585:	nopl   (%rax)
  403588:	test   %rdx,%rdx
  40358b:	js     40354b <nx_rt_rebuild2+0x9b>
  40358d:	jmpq   401640 <nx_rt_rebuild2.cold>
  403592:	nopw   0x0(%rax,%rax,1)
  403598:	test   %r8,%r8
  40359b:	js     403563 <nx_rt_rebuild2+0xb3>
  40359d:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  4035a2:	nopw   0x0(%rax,%rax,1)
  4035a8:	mov    0x8(%r15),%rbp
  4035ac:	test   %rbp,%rbp
  4035af:	je     401685 <nx_rt_rebuild2.cold+0x45>
  4035b5:	lea    (%r14,%rbp,8),%r9
  4035b9:	mov    (%r9),%rax
  4035bc:	subq   $0x2,0x108(%r15)
  4035c4:	mov    %rax,0x8(%r15)
  4035c8:	jmpq   403512 <nx_rt_rebuild2+0x62>
  4035cd:	nopl   (%rax)
  4035d0:	mov    0x4(%rax),%edx
  4035d3:	mov    (%rax),%ecx
  4035d5:	shl    $0x20,%rdx
  4035d9:	or     %rcx,%rdx
  4035dc:	mov    %rdx,%rcx
  4035df:	and    $0xffffff,%edx
  4035e5:	shr    $0x18,%rcx
  4035e9:	lea    0x0(,%rcx,8),%rdi
  4035f1:	lea    (%r14,%rdi,1),%r9
  4035f5:	lea    0x8(%r14,%rdi,1),%rdi
  4035fa:	cmp    $0x1,%rdx
  4035fe:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403604:	mov    (%rax),%edx
  403606:	mov    (%r9),%rdx
  403609:	mov    %rdx,0x10(%rsp)
  40360e:	mov    (%rdi),%rdx
  403611:	mov    %rdx,0x18(%rsp)
  403616:	mov    (%r15),%rdx
  403619:	mov    %rdx,(%rax)
  40361c:	mov    0x100(%r15),%rax
  403623:	mov    0x3ebaf(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403629:	mov    %rbp,(%r15)
  40362c:	add    $0x1,%rax
  403630:	mov    %rax,0x100(%r15)
  403637:	cmp    %rdx,%rax
  40363a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  403640:	mov    %rcx,%rbp
  403643:	jmpq   403501 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
