  4084ab:	push   %rbp
  4084ac:	mov    %rsp,%rbp
  4084af:	sub    $0x910,%rsp
  4084b6:	mov    %r12,-0x10(%rbp)
  4084ba:	mov    %rdi,%rax
  4084bd:	mov    %rax,%r12
  4084c0:	mov    %rsi,%rax
  4084c3:	mov    %rax,%rdi
  4084c6:	mov    %rdx,%rax
  4084c9:	mov    %rax,%rdx
  4084cc:	mov    %edi,%esi
  4084ce:	and    $0x7,%rsi
  4084d5:	cmp    $0x3,%rsi
  4084dc:	setb   %sil
  4084e0:	movzbl %sil,%esi
  4084e4:	mov    %esi,%esi
  4084e6:	mov    %rsi,%r10
  4084e9:	test   %r10d,%r10d
  4084ec:	je     408505 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x5a>
  4084f2:	mov    %edi,%edi
  4084f4:	imul   $0x3,%edi,%edi
  4084fa:	add    $0x1,%edi
  408500:	jmpq   40850c <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_+0x61>
  408505:	mov    %edi,%edi
  408507:	mov    %edx,%edx
  408509:	xor    %rdx,%rdi
  40850c:	mov    %rdi,%rax
  40850f:	mov    -0x10(%rbp),%r12
  408513:	mov    %rbp,%rsp
  408516:	pop    %rbp
  408517:	retq   
