#!/usr/bin/env python3
"""Data-only portable baseline packaging and explicit current label derivation."""
import copy, gzip, hashlib, json, shutil, sys, tarfile
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3]
TOOLS=ROOT/'selfhost/tools/performance'
sys.path.insert(0,str(TOOLS/'programs'))
from run import load_bundle
from support import save

def identity(p):
 p=Path(p).resolve();h=hashlib.sha256()
 with p.open('rb') as f:
  for b in iter(lambda:f.read(2**20),b''):h.update(b)
 return dict(path=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
inputs={}
def keep(p,want=None):
 p=Path(p).resolve();got=identity(p)
 if want:
  assert got['sha256']==want['sha256'],p
  assert 'bytes' not in want or got['bytes']==want['bytes'],p
 assert str(p) not in inputs or inputs[str(p)]==got
 inputs[str(p)]=got;return got

def rel(p,root):
 d=identity(p);d['path']=Path(p).relative_to(root).as_posix();return d

catalogfile=TOOLS/'phase37/catalog.json';catalog=json.loads(catalogfile.read_text());catalogid=keep(catalogfile)
assert len(catalog['cases'])==45 and len({x['source']['sha256'] for x in catalog['cases']})==23
assert catalog['upstreamCommit']=='018751270e800bc222a93dad7f257083ee53a5f7'
origin=ROOT/'selfhost/build/phase45/control01/manifest.json';old=json.loads(origin.read_text());keep(origin)
loaded=[];bundle=load_bundle(origin,catalog,catalogid['sha256'],catalog['cases'],['baseline','typescript'],loaded)
for item in loaded:keep(item['path'],item)
for p in [__file__,TOOLS/'programs/run.py',TOOLS/'programs/support.py']:keep(p)
assert bundle['roles']['baseline']['compiler']['api']['sha256']=='0d3325425139c59ac81c4f1bca19fa09e9f977062aa3b202c0ef1c8c7b56b0ea'
assert bundle['roles']['baseline']['compiler']['kind']=='checked-development-attempt'
assert bundle['roles']['typescript']['compiler']['kind']=='checked-pinned-typescript'
for role in bundle['roles'].values():assert role['compiler']['upstreamCommit']==catalog['upstreamCommit']
oldprovenance=origin.parent/old['provenance']['path'];keep(oldprovenance,old['provenance'])
assert json.loads(oldprovenance.read_text())['complete'] is True
out=TOOLS/'phase45/baseline';assert not out.exists();out.mkdir()
files={};entries={};total=0

def add(name,file):
 global total
 assert not Path(name).is_absolute() and '..' not in Path(name).parts
 p=Path(file);assert p.is_file() and not p.is_symlink();item=keep(p)
 assert item['bytes']<=64*1024**2 and name not in files
 total+=item['bytes'];assert total<=512*1024**2 and len(files)<4096
 files[name]=p;entries[name]=dict(path=name,bytes=item['bytes'],sha256=item['sha256'])

for p in sorted(origin.parent.rglob('*')):
 assert not p.is_symlink()
 if p.is_file():add('acquisition/control01/'+p.relative_to(origin.parent).as_posix(),p)
add('consumed/package-portable17b.py',__file__)
roles=copy.deepcopy(bundle['roles']);roles['baseline']['label']='Phase44 checked04 saved outputs (retained Phase45 control; no new compilation)'
roles['typescript']['label']='Pinned upstream TypeScript 018751270e800bc222a93dad7f257083ee53a5f7 (retained checked outputs)'
cases=[]
for case in catalog['cases']:
 row=dict(id=case['id'],sourceSha256=case['source']['sha256'],point=case['point'],modules={})
 for role in roles:
  item=bundle['points'][case['id']][role];name='acquisition/control01/'+item['path'];entry=entries[name]
  assert entry['sha256']==item['sha256'] and entry['bytes']==item['bytes'];row['modules'][role]=entry
 cases.append(row)
provenance=dict(kind='phase45-retained-phase44-typescript-control',complete=True,producer=keep(__file__),originalManifest=keep(origin),originalProvenance=keep(oldprovenance),
 scope='Exact control01 Phase44 checked04 and pinned TypeScript outputs, archived without source changes or target/compiler execution. Relative runtime paths; absolute receipt paths are historical provenance.',
 compilerRoles=roles,cases=45,runtimeModules=48,inputs=list(inputs.values()))
save(out/'provenance.json',provenance);add('provenance.json',out/'provenance.json')
archive=out/'programs.tar.gz'
with archive.open('xb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz:
 with tarfile.open(fileobj=gz,mode='w|') as tar:
  for name,p in sorted(files.items()):
   info=tarfile.TarInfo(name);info.size=entries[name]['bytes'];info.mode=0o644;info.mtime=0;info.uid=info.gid=0;info.uname=info.gname=''
   with p.open('rb') as f:tar.addfile(info,f)
seen=set();opened=0
with tarfile.open(archive,'r|gz') as tar:
 for member in tar:
  assert member.isfile() and member.name in entries and member.name not in seen
  entry=entries[member.name];assert member.size==entry['bytes'];h=hashlib.sha256()
  with tar.extractfile(member) as f:
   for data in iter(lambda:f.read(2**20),b''):h.update(data)
  assert h.hexdigest()==entry['sha256'];seen.add(member.name);opened+=member.size
assert seen==set(entries) and opened==total
save(out/'manifest.json',dict(kind='bend-program-bundle',schemaVersion=1,complete=True,upstreamCommit=catalog['upstreamCommit'],catalogSha256=catalogid['sha256'],roles=roles,cases=cases,
 archive=rel(archive,out),provenance=rel(out/'provenance.json',out),preservation=dict(members=len(entries),uncompressedBytes=total,reopenedVerified=True,byteExact=True)))
load_bundle(out/'manifest.json',catalog,catalogid['sha256'],catalog['cases'],['baseline','typescript'],[])
# Preserve the maintained freezer's complete manifest before changing its legacy label.
current=TOOLS/'phase45/current';currentfile=current/'manifest.json';original=keep(currentfile);currentdata=json.loads(currentfile.read_text())
assert currentdata['roles']['candidate']['compiler']['api']['sha256']=='f9e383e3672a642b05fba3ed48605b9b093734bdf630bfb63ff9e85906b557d8'
preserved=current/'freeze-candidate-manifest.json';assert not preserved.exists();shutil.copyfile(currentfile,preserved);assert identity(preserved)['sha256']==original['sha256']
currentdata['roles']['candidate']['label']='Phase45 worker17b checked experimental candidate (final qualification pending; frozen actual acquisition)'
derivation=dict(kind='phase45-portable-candidate-label-derivation',complete=True,producer=keep(__file__),originalManifest=rel(preserved,current),
 scope='Only the role label changes from the maintained Phase44 freezer default. Compiler identities, all45 cases, archive and provenance bytes are unchanged. Checked development checkpoint; no promotion or fresh execution claim.',
 sourceApi=currentdata['roles']['candidate']['compiler']['api']['sha256'],originalLabel=json.loads(preserved.read_text())['roles']['candidate']['label'],newLabel=currentdata['roles']['candidate']['label'])
save(current/'label-derivation.json',derivation);currentdata['labelDerivation']=rel(current/'label-derivation.json',current)
save(currentfile,currentdata)
check=copy.deepcopy(currentdata);check.pop('labelDerivation');check['roles']['candidate']['label']=derivation['originalLabel'];assert check==json.loads(preserved.read_text())
load_bundle(currentfile,catalog,catalogid['sha256'],catalog['cases'],['candidate'],[])
for file,item in inputs.items():
 if file!=str(currentfile):assert identity(file)==item,'Input changed: '+file
receipt=dict(kind='phase45-portable-bundle-packaging',complete=True,**{'pass':True},generatedProgramsExecuted=False,compilerExecuted=False,
 producer=identity(__file__),catalog=catalogid,baseline=dict(manifest=identity(out/'manifest.json'),archive=identity(archive),provenance=identity(out/'provenance.json'),cases=45,runtimeModules=48,members=len(entries),byteExact=True,reopenedVerified=True),
 candidate=dict(manifest=identity(currentfile),archive=identity(current/'programs.tar.gz'),provenance=identity(current/'provenance.json'),preservedFreezerManifest=identity(preserved),labelDerivation=identity(current/'label-derivation.json'),cases=45,runtimeModules=len({x['modules']['candidate']['sha256'] for x in currentdata['cases']}),members=currentdata['preservation']['members'],byteExact=True,reopenedVerified=True),inputs=list(inputs.values()))
receiptfile=ROOT/'selfhost/build/phase45/portable-bundles17b.json';assert not receiptfile.exists();save(receiptfile,receipt)
print(json.dumps(dict(complete=True,**{'pass':True},baseline=receipt['baseline'],candidate=receipt['candidate'],receipt=identity(receiptfile))))
