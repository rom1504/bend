
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403040 <nx_rt_fast_id>:
  403040:	shr    $0x28,%rsi
  403044:	movzwl %si,%eax
  403047:	retq   

Disassembly of section .fini:
