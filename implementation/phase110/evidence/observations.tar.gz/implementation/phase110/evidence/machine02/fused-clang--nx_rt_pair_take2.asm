
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004040c0 <nx_rt_pair_take2>:
  4040c0:	movabs $0xffffffffff,%rax
  4040ca:	push   %r15
  4040cc:	and    %rsi,%rax
  4040cf:	push   %r14
  4040d1:	push   %r13
  4040d3:	lea    0x0(,%rax,8),%rdx
  4040db:	push   %r12
  4040dd:	push   %rbp
  4040de:	mov    (%rdi),%rbp
  4040e1:	mov    0x8(%rdi),%r14
  4040e5:	lea    0x0(%rbp,%rdx,1),%rcx
  4040ea:	test   %rsi,%rsi
  4040ed:	js     404150 <nx_rt_pair_take2+0x90>
  4040ef:	mov    (%rcx),%r13
  4040f2:	mov    0x8(%rbp,%rdx,1),%r12
  4040f7:	cmp    $0x310817f,%rax
  4040fd:	ja     404110 <nx_rt_pair_take2+0x50>
  4040ff:	pop    %rbp
  404100:	mov    %r13,%rax
  404103:	mov    %r12,%rdx
  404106:	pop    %r12
  404108:	pop    %r13
  40410a:	pop    %r14
  40410c:	pop    %r15
  40410e:	retq   
  40410f:	nop
  404110:	mov    0x8(%r14),%rdx
  404114:	mov    %rdx,0x0(%rbp,%rax,8)
  404119:	mov    0x3d0b9(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40411f:	mov    %rax,0x8(%r14)
  404123:	mov    0x108(%r14),%rax
  40412a:	add    $0x2,%rax
  40412e:	mov    %rax,0x108(%r14)
  404135:	cmp    %rdx,%rax
  404138:	jae    401be0 <nx_rt_pair_take2.cold>
  40413e:	pop    %rbp
  40413f:	mov    %r13,%rax
  404142:	mov    %r12,%rdx
  404145:	pop    %r12
  404147:	pop    %r13
  404149:	pop    %r14
  40414b:	pop    %r15
  40414d:	retq   
  40414e:	xchg   %ax,%ax
  404150:	mov    0x4(%rcx),%edx
  404153:	mov    (%rcx),%edi
  404155:	shl    $0x20,%rdx
  404159:	or     %rdi,%rdx
  40415c:	mov    %rdx,%r15
  40415f:	and    $0xffffff,%edx
  404165:	shr    $0x18,%r15
  404169:	lea    0x8(,%r15,8),%rdi
  404171:	lea    0x0(%rbp,%rdi,1),%r8
  404176:	cmp    $0x1,%rdx
  40417a:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  404180:	mov    (%rcx),%edx
  404182:	mov    (%r14),%rdx
  404185:	mov    -0x8(%rbp,%rdi,1),%r13
  40418a:	mov    (%r8),%r12
  40418d:	mov    %rdx,(%rcx)
  404190:	mov    0x3d042(%rip),%edx        # 4411d8 <KEEP_WORDS>
  404196:	mov    %rax,(%r14)
  404199:	mov    0x100(%r14),%rax
  4041a0:	add    $0x1,%rax
  4041a4:	mov    %rax,0x100(%r14)
  4041ab:	cmp    %rdx,%rax
  4041ae:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  4041b4:	mov    %r15,%rax
  4041b7:	jmpq   4040f7 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
