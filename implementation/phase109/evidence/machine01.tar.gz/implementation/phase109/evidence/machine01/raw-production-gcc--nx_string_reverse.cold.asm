
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004017d4 <nx_string_reverse.cold>:
  4017d4:	mov    -0x8(%r12,%rsi,1),%r10
  4017d9:	mov    (%rdi),%r15
  4017dc:	mov    %rbx,%rcx
  4017df:	mov    %r13,%rdx
  4017e2:	mov    %r12,%rdi
  4017e5:	mov    %rbp,%rsi
  4017e8:	mov    %r10,0x8(%rsp)
  4017ed:	mov    %r15,%r13
  4017f0:	callq  4014c6 <span_fade.constprop.0>
  4017f5:	mov    0x8(%rbp),%rbx
  4017f9:	mov    0x8(%rsp),%r10
  4017fe:	movabs $0xffffffffff,%r9
  401808:	movabs $0x200030000000000,%r8
  401812:	jmpq   4034b2 <nx_string_reverse+0xf2>
  401817:	xor    %edx,%edx
  401819:	mov    %r12,%rdi
  40181c:	mov    %rbp,%rsi
  40181f:	mov    %r10,0x8(%rsp)
  401824:	callq  401100 <heap_hand>
  401829:	mov    0x8(%rsp),%r10
  40182e:	movabs $0xffffffffff,%r9
  401838:	movabs $0x200030000000000,%r8
  401842:	jmpq   4035ad <nx_string_reverse+0x1ed>
  401847:	mov    $0x1,%edx
  40184c:	mov    %r12,%rdi
  40184f:	mov    %rbp,%rsi
  401852:	mov    %r10,0x8(%rsp)
  401857:	callq  401100 <heap_hand>
  40185c:	mov    0x8(%rbp),%rbx
  401860:	mov    0x8(%rsp),%r10
  401865:	movabs $0xffffffffff,%r9
  40186f:	movabs $0x200030000000000,%r8
  401879:	jmpq   4034b2 <nx_string_reverse+0xf2>
  40187e:	mov    %r14,%rdx
  401881:	mov    $0x1,%ecx
  401886:	mov    %r12,%rdi
  401889:	mov    %rbp,%rsi
  40188c:	callq  401397 <rfc_wrap>
  401891:	movabs $0xffffffffff,%r9
  40189b:	movabs $0x200030000000000,%r8
  4018a5:	mov    %rax,%r14
  4018a8:	jmpq   40345c <nx_string_reverse+0x9c>
  4018ad:	mov    %r10,%rdx
  4018b0:	mov    $0x1,%ecx
  4018b5:	mov    %r12,%rdi
  4018b8:	mov    %rbp,%rsi
  4018bb:	callq  401397 <rfc_wrap>
  4018c0:	movabs $0xffffffffff,%r9
  4018ca:	movabs $0x200030000000000,%r8
  4018d4:	mov    %rax,%r10
  4018d7:	jmpq   403440 <nx_string_reverse+0x80>
  4018dc:	mov    $0x1,%edx
  4018e1:	mov    %r12,%rdi
  4018e4:	mov    %rbp,%rsi
  4018e7:	mov    %r10,0x8(%rsp)
  4018ec:	callq  401178 <heap_alloc_miss>
  4018f1:	mov    0x8(%rsp),%r10
  4018f6:	movabs $0xffffffffff,%r9
  401900:	movabs $0x200030000000000,%r8
  40190a:	mov    %rax,%rbx
  40190d:	lea    (%r12,%rax,8),%r15
  401911:	jmpq   4034d8 <nx_string_reverse+0x118>

Disassembly of section .fini:
