  4083c5:	push   %rbp
  4083c6:	mov    %rsp,%rbp
  4083c9:	sub    $0x910,%rsp
  4083d0:	mov    %r12,-0x10(%rbp)
  4083d4:	mov    %rdi,%rax
  4083d7:	mov    %rax,%r12
  4083da:	mov    %rsi,%rax
  4083dd:	mov    %rax,%rdi
  4083e0:	mov    %rdx,%rax
  4083e3:	mov    %rax,%rsi
  4083e6:	mov    %rdi,%rdx
  4083e9:	cmp    $0x0,%rdx
  4083f0:	sete   %dl
  4083f3:	movzbl %dl,%edx
  4083f6:	mov    %rdx,%r10
  4083f9:	test   %r10d,%r10d
  4083fc:	je     40840e <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x49>
  408402:	mov    %rsi,%rax
  408405:	mov    -0x10(%rbp),%r12
  408409:	mov    %rbp,%rsp
  40840c:	pop    %rbp
  40840d:	retq   
  40840e:	mov    %rdi,%rdx
  408411:	cmp    $0x0,%rdx
  408418:	setne  %dl
  40841b:	movzbl %dl,%edx
  40841e:	mov    %rdx,%r10
  408421:	test   %r10d,%r10d
  408424:	je     408485 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0xc0>
  40842a:	mov    %rdi,%rdx
  40842d:	sub    $0x1,%rdx
  408434:	movabs $0x3e800000,%r10
  40843e:	movd   %r10d,%xmm1
  408443:	movd   %esi,%xmm0
  408447:	addss  %xmm1,%xmm0
  40844b:	movd   %xmm0,%edi
  40844f:	movabs $0x40000000,%r10
  408459:	movd   %r10d,%xmm1
  40845e:	movd   %edi,%xmm0
  408462:	mulss  %xmm1,%xmm0
  408466:	movd   %xmm0,%edi
  40846a:	movd   %esi,%xmm1
  40846e:	movd   %edi,%xmm0
  408472:	subss  %xmm1,%xmm0
  408476:	movd   %xmm0,%edi
  40847a:	mov    %rdi,%rsi
  40847d:	mov    %rdx,%rdi
  408480:	jmpq   4083e6 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x21>
  408485:	mov    %r12,%rdi
  408488:	movabs $0x4,%rsi
  408492:	mov    %esi,%esi
  408494:	xor    %eax,%eax
  408496:	callq  415340 <p111_rt_fail>
  40849b:	mov    %rax,-0x8b8(%rbp)
  4084a2:	movabs $0x0,%rax
  4084ac:	mov    -0x10(%rbp),%r12
  4084b0:	mov    %rbp,%rsp
  4084b3:	pop    %rbp
  4084b4:	retq   
