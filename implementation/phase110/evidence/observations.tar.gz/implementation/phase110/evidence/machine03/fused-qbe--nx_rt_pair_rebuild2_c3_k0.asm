
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403cf0 <nx_rt_pair_rebuild2_c3_k0>:
  403cf0:	push   %r15
  403cf2:	push   %r14
  403cf4:	push   %r13
  403cf6:	push   %r12
  403cf8:	mov    %rdx,%r12
  403cfb:	push   %rbp
  403cfc:	push   %rbx
  403cfd:	movabs $0xffffffffff,%rbx
  403d07:	and    %rsi,%rbx
  403d0a:	lea    0x0(,%rbx,8),%rdx
  403d12:	sub    $0x18,%rsp
  403d16:	mov    (%rdi),%rbp
  403d19:	mov    0x8(%rdi),%r15
  403d1d:	lea    0x0(%rbp,%rdx,1),%rax
  403d22:	test   %rsi,%rsi
  403d25:	js     403de0 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  403d2b:	mov    (%rax),%r14
  403d2e:	mov    0x8(%rbp,%rdx,1),%r13
  403d33:	cmp    $0x310817f,%rbx
  403d3a:	jbe    403db0 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  403d3c:	lea    0x0(%rbp,%rbx,8),%r8
  403d41:	mov    %r14,%rax
  403d44:	shr    $0x38,%rax
  403d48:	and    $0x7f,%eax
  403d4b:	cmp    $0x2,%rax
  403d4f:	je     403d90 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  403d51:	mov    %r12,%rax
  403d54:	mov    %r14,(%r8)
  403d57:	lea    0x8(%rbp,%rbx,8),%r14
  403d5c:	shr    $0x38,%rax
  403d60:	and    $0x7f,%eax
  403d63:	cmp    $0x2,%rax
  403d67:	je     403da0 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  403d69:	movabs $0x200030000000000,%rax
  403d73:	mov    %r12,(%r14)
  403d76:	mov    %r13,%rdx
  403d79:	add    $0x18,%rsp
  403d7d:	or     %rbx,%rax
  403d80:	pop    %rbx
  403d81:	pop    %rbp
  403d82:	pop    %r12
  403d84:	pop    %r13
  403d86:	pop    %r14
  403d88:	pop    %r15
  403d8a:	retq   
  403d8b:	nopl   0x0(%rax,%rax,1)
  403d90:	test   %r14,%r14
  403d93:	js     403d51 <nx_rt_pair_rebuild2_c3_k0+0x61>
  403d95:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  403d9a:	nopw   0x0(%rax,%rax,1)
  403da0:	test   %r12,%r12
  403da3:	js     403d69 <nx_rt_pair_rebuild2_c3_k0+0x79>
  403da5:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  403daa:	nopw   0x0(%rax,%rax,1)
  403db0:	mov    0x8(%r15),%rbx
  403db4:	test   %rbx,%rbx
  403db7:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  403dbd:	lea    0x0(%rbp,%rbx,8),%r8
  403dc2:	mov    (%r8),%rax
  403dc5:	subq   $0x2,0x108(%r15)
  403dcd:	mov    %rax,0x8(%r15)
  403dd1:	jmpq   403d41 <nx_rt_pair_rebuild2_c3_k0+0x51>
  403dd6:	nopw   %cs:0x0(%rax,%rax,1)
  403de0:	mov    0x4(%rax),%edx
  403de3:	mov    (%rax),%ecx
  403de5:	shl    $0x20,%rdx
  403de9:	or     %rcx,%rdx
  403dec:	mov    %rdx,%rcx
  403def:	and    $0xffffff,%edx
  403df5:	shr    $0x18,%rcx
  403df9:	lea    0x8(,%rcx,8),%rdi
  403e01:	lea    0x0(%rbp,%rdi,1),%r8
  403e06:	lea    -0x8(%rbp,%rdi,1),%rdi
  403e0b:	cmp    $0x1,%rdx
  403e0f:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  403e15:	mov    (%rax),%edx
  403e17:	mov    (%r15),%rdx
  403e1a:	mov    (%rdi),%r14
  403e1d:	mov    (%r8),%r13
  403e20:	mov    %rdx,(%rax)
  403e23:	mov    0x100(%r15),%rax
  403e2a:	mov    0x3d3a8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403e30:	mov    %rbx,(%r15)
  403e33:	add    $0x1,%rax
  403e37:	mov    %rax,0x100(%r15)
  403e3e:	cmp    %rdx,%rax
  403e41:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  403e47:	mov    %rcx,%rbx
  403e4a:	jmpq   403d33 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
