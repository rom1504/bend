
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c60 <rfc_seal>:
  401c60:	endbr64 
  401c64:	push   %rbp
  401c65:	mov    %rsp,%rbp
  401c68:	sub    $0x18,%rsp
  401c6c:	push   %rbx
  401c6d:	mov    %rdx,%rbx
  401c70:	mov    %rdi,-0x10(%rbp)
  401c74:	mov    %rsi,-0x8(%rbp)
  401c78:	mov    %rbx,%rdi
  401c7b:	callq  401b00 <term_tag>
  401c80:	cmp    $0x2,%rax
  401c84:	jne    401cb2 <rfc_seal+0x52>
  401c86:	mov    %rbx,%rdi
  401c89:	callq  401b10 <term_rfc>
  401c8e:	mov    %eax,%ecx
  401c90:	mov    %rbx,%rax
  401c93:	movzbl %cl,%ecx
  401c96:	cmp    $0x0,%ecx
  401c99:	jne    401cb5 <rfc_seal+0x55>
  401c9b:	mov    $0x1,%ecx
  401ca0:	mov    %rax,%rdx
  401ca3:	mov    -0x10(%rbp),%rdi
  401ca7:	mov    -0x8(%rbp),%rsi
  401cab:	callq  401bb0 <rfc_wrap>
  401cb0:	jmp    401cb5 <rfc_seal+0x55>
  401cb2:	mov    %rbx,%rax
  401cb5:	pop    %rbx
  401cb6:	leaveq 
  401cb7:	retq   

Disassembly of section .fini:
