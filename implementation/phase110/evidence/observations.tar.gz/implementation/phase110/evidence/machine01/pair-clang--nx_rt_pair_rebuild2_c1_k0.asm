
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403430 <nx_rt_pair_rebuild2_c1_k0>:
  403430:	push   %r14
  403432:	mov    %rsi,%r10
  403435:	mov    %rdx,%r8
  403438:	movabs $0xffffffffff,%r9
  403442:	push   %r13
  403444:	and    %r10,%r9
  403447:	push   %r12
  403449:	lea    0x0(,%r9,8),%rax
  403451:	push   %rbp
  403452:	sub    $0x18,%rsp
  403456:	mov    (%rdi),%rbp
  403459:	mov    0x8(%rdi),%rsi
  40345d:	lea    0x0(%rbp,%rax,1),%rdx
  403462:	test   %r10,%r10
  403465:	js     4034c0 <nx_rt_pair_rebuild2_c1_k0+0x90>
  403467:	mov    (%rdx),%r13
  40346a:	mov    0x8(%rbp,%rax,1),%r12
  40346f:	cmp    $0x310817f,%r9
  403476:	jbe    4034a0 <nx_rt_pair_rebuild2_c1_k0+0x70>
  403478:	mov    %r13,%rcx
  40347b:	mov    $0x1,%edx
  403480:	mov    %rbp,%rdi
  403483:	callq  401f70 <nx_construct2>
  403488:	add    $0x18,%rsp
  40348c:	mov    %r12,%rdx
  40348f:	pop    %rbp
  403490:	pop    %r12
  403492:	pop    %r13
  403494:	pop    %r14
  403496:	retq   
  403497:	nopw   0x0(%rax,%rax,1)
  4034a0:	mov    0x8(%rsi),%r9
  4034a4:	test   %r9,%r9
  4034a7:	je     40173f <nx_rt_pair_rebuild2_c1_k0.cold>
  4034ad:	mov    0x0(%rbp,%r9,8),%rax
  4034b2:	subq   $0x2,0x108(%rsi)
  4034ba:	mov    %rax,0x8(%rsi)
  4034be:	jmp    403478 <nx_rt_pair_rebuild2_c1_k0+0x48>
  4034c0:	mov    0x4(%rdx),%eax
  4034c3:	mov    (%rdx),%ecx
  4034c5:	shl    $0x20,%rax
  4034c9:	or     %rcx,%rax
  4034cc:	mov    %rax,%r14
  4034cf:	and    $0xffffff,%eax
  4034d4:	shr    $0x18,%r14
  4034d8:	lea    0x0(,%r14,8),%rcx
  4034e0:	lea    0x8(%rbp,%rcx,1),%rdi
  4034e5:	add    %rbp,%rcx
  4034e8:	cmp    $0x1,%rax
  4034ec:	jne    40177d <nx_rt_pair_rebuild2_c1_k0.cold+0x3e>
  4034f2:	mov    (%rdx),%eax
  4034f4:	mov    (%rsi),%rax
  4034f7:	mov    (%rcx),%r13
  4034fa:	mov    (%rdi),%r12
  4034fd:	mov    %rax,(%rdx)
  403500:	mov    0x100(%rsi),%rax
  403507:	mov    0x3dccb(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40350d:	mov    %r9,(%rsi)
  403510:	add    $0x1,%rax
  403514:	mov    %rax,0x100(%rsi)
  40351b:	cmp    %rdx,%rax
  40351e:	jae    401766 <nx_rt_pair_rebuild2_c1_k0.cold+0x27>
  403524:	mov    %r14,%r9
  403527:	jmpq   40346f <nx_rt_pair_rebuild2_c1_k0+0x3f>

Disassembly of section .fini:
