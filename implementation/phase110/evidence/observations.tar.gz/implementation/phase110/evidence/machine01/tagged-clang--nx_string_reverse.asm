
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c70 <nx_string_reverse>:
  401c70:	push   %r14
  401c72:	push   %rbx
  401c73:	push   %rax
  401c74:	mov    %rdx,%r14
  401c77:	mov    %rdi,%rbx
  401c7a:	nopw   0x0(%rax,%rax,1)
  401c80:	mov    %rsi,%rax
  401c83:	shr    $0x28,%rax
  401c87:	cmp    $0x3,%ax
  401c8b:	jne    401cb1 <nx_string_reverse+0x41>
  401c8d:	mov    %rbx,%rdi
  401c90:	mov    $0x3,%edx
  401c95:	xor    %ecx,%ecx
  401c97:	mov    %r14,%r8
  401c9a:	callq  402d10 <nx_rt_rebuild2>
  401c9f:	mov    %rax,%r14
  401ca2:	mov    %rbx,%rdi
  401ca5:	xor    %esi,%esi
  401ca7:	callq  402cf0 <nx_rt_fast_field>
  401cac:	mov    %rax,%rsi
  401caf:	jmp    401c80 <nx_string_reverse+0x10>
  401cb1:	movzwl %ax,%eax
  401cb4:	cmp    $0x2,%eax
  401cb7:	jne    401cc4 <nx_string_reverse+0x54>
  401cb9:	mov    %r14,%rax
  401cbc:	add    $0x8,%rsp
  401cc0:	pop    %rbx
  401cc1:	pop    %r14
  401cc3:	retq   
  401cc4:	mov    %rbx,%rdi
  401cc7:	mov    $0x1,%esi
  401ccc:	add    $0x8,%rsp
  401cd0:	pop    %rbx
  401cd1:	pop    %r14
  401cd3:	jmpq   402540 <nx_rt_fail>

Disassembly of section .fini:
