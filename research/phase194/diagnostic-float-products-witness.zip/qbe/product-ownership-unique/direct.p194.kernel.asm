  406c00:	endbr64 
  406c04:	push   %rbp
  406c05:	mov    %rsp,%rbp
  406c08:	mov    %rcx,%rax
  406c0b:	mov    %rax,%rcx
  406c0e:	xchg   %ax,%ax
  406c10:	cmp    $0x0,%rsi
  406c14:	je     406c3b <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x3b>
  406c16:	sub    $0x1,%rsi
  406c1a:	mov    %rcx,%rax
  406c1d:	mov    %edx,%ecx
  406c1f:	mov    %ecx,%edx
  406c21:	add    $0x1,%edx
  406c24:	mov    %edx,%edx
  406c26:	mov    %eax,%eax
  406c28:	add    %eax,%ecx
  406c2a:	mov    %ecx,%ecx
  406c2c:	imul   $0x3,%eax,%eax
  406c2f:	mov    %eax,%eax
  406c31:	xor    $0x7,%rcx
  406c35:	add    %ecx,%eax
  406c37:	mov    %eax,%ecx
  406c39:	jmp    406c10 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x10>
  406c3b:	mov    %rcx,%rax
  406c3e:	leaveq 
  406c3f:	retq   
