
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403ae0 <nx_rt_rebuild2_c3_k0>:
  403ae0:	push   %r15
  403ae2:	push   %r14
  403ae4:	push   %r13
  403ae6:	push   %r12
  403ae8:	mov    %rdx,%r12
  403aeb:	push   %rbp
  403aec:	mov    %rdi,%rbp
  403aef:	push   %rbx
  403af0:	movabs $0xffffffffff,%rbx
  403afa:	and    %rsi,%rbx
  403afd:	lea    0x0(,%rbx,8),%rdx
  403b05:	sub    $0x18,%rsp
  403b09:	mov    (%rdi),%r13
  403b0c:	mov    0x8(%rdi),%r15
  403b10:	lea    0x0(%r13,%rdx,1),%rax
  403b15:	test   %rsi,%rsi
  403b18:	js     403be0 <nx_rt_rebuild2_c3_k0+0x100>
  403b1e:	mov    (%rax),%r14
  403b21:	mov    0x8(%r13,%rdx,1),%r9
  403b26:	cmp    $0x310817f,%rbx
  403b2d:	jbe    403bb8 <nx_rt_rebuild2_c3_k0+0xd8>
  403b33:	lea    0x0(%r13,%rbx,8),%r8
  403b38:	mov    %r14,%rax
  403b3b:	mov    %r9,0x10(%rbp)
  403b3f:	shr    $0x38,%rax
  403b43:	movq   $0xffffffffffffffff,0x18(%rbp)
  403b4b:	and    $0x7f,%eax
  403b4e:	movl   $0x1,0x20(%rbp)
  403b55:	cmp    $0x2,%rax
  403b59:	je     403b98 <nx_rt_rebuild2_c3_k0+0xb8>
  403b5b:	mov    %r12,%rax
  403b5e:	mov    %r14,(%r8)
  403b61:	lea    0x8(%r13,%rbx,8),%rbp
  403b66:	shr    $0x38,%rax
  403b6a:	and    $0x7f,%eax
  403b6d:	cmp    $0x2,%rax
  403b71:	je     403ba8 <nx_rt_rebuild2_c3_k0+0xc8>
  403b73:	movabs $0x200030000000000,%rax
  403b7d:	mov    %r12,0x0(%rbp)
  403b81:	add    $0x18,%rsp
  403b85:	or     %rbx,%rax
  403b88:	pop    %rbx
  403b89:	pop    %rbp
  403b8a:	pop    %r12
  403b8c:	pop    %r13
  403b8e:	pop    %r14
  403b90:	pop    %r15
  403b92:	retq   
  403b93:	nopl   0x0(%rax,%rax,1)
  403b98:	test   %r14,%r14
  403b9b:	js     403b5b <nx_rt_rebuild2_c3_k0+0x7b>
  403b9d:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  403ba2:	nopw   0x0(%rax,%rax,1)
  403ba8:	test   %r12,%r12
  403bab:	js     403b73 <nx_rt_rebuild2_c3_k0+0x93>
  403bad:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  403bb2:	nopw   0x0(%rax,%rax,1)
  403bb8:	mov    0x8(%r15),%rbx
  403bbc:	test   %rbx,%rbx
  403bbf:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  403bc5:	lea    0x0(%r13,%rbx,8),%r8
  403bca:	mov    (%r8),%rax
  403bcd:	subq   $0x2,0x108(%r15)
  403bd5:	mov    %rax,0x8(%r15)
  403bd9:	jmpq   403b38 <nx_rt_rebuild2_c3_k0+0x58>
  403bde:	xchg   %ax,%ax
  403be0:	mov    0x4(%rax),%edx
  403be3:	mov    (%rax),%ecx
  403be5:	shl    $0x20,%rdx
  403be9:	or     %rcx,%rdx
  403bec:	mov    %rdx,%rcx
  403bef:	and    $0xffffff,%edx
  403bf5:	shr    $0x18,%rcx
  403bf9:	lea    0x8(,%rcx,8),%rdi
  403c01:	lea    0x0(%r13,%rdi,1),%r8
  403c06:	lea    -0x8(%r13,%rdi,1),%rdi
  403c0b:	cmp    $0x1,%rdx
  403c0f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  403c15:	mov    (%rax),%edx
  403c17:	mov    (%r15),%rdx
  403c1a:	mov    (%rdi),%r14
  403c1d:	mov    (%r8),%r9
  403c20:	mov    %rdx,(%rax)
  403c23:	mov    0x100(%r15),%rax
  403c2a:	mov    0x3d5a8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403c30:	mov    %rbx,(%r15)
  403c33:	add    $0x1,%rax
  403c37:	mov    %rax,0x100(%r15)
  403c3e:	cmp    %rdx,%rax
  403c41:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  403c47:	mov    %rcx,%rbx
  403c4a:	jmpq   403b26 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
