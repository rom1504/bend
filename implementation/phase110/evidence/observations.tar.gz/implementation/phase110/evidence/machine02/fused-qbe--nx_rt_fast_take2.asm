
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402dd0 <nx_rt_fast_take2>:
  402dd0:	movabs $0xffffffffff,%rax
  402dda:	push   %r12
  402ddc:	and    %rsi,%rax
  402ddf:	push   %rbp
  402de0:	push   %rbx
  402de1:	mov    %rdi,%rbx
  402de4:	mov    (%rdi),%rdi
  402de7:	lea    0x0(,%rax,8),%rcx
  402def:	mov    0x8(%rbx),%rbp
  402df3:	lea    (%rdi,%rcx,1),%rdx
  402df7:	test   %rsi,%rsi
  402dfa:	js     402e68 <nx_rt_fast_take2+0x98>
  402dfc:	mov    (%rdx),%rdx
  402dff:	mov    %rdx,0x10(%rbx)
  402e03:	mov    0x8(%rdi,%rcx,1),%rdx
  402e08:	mov    %rdx,0x18(%rbx)
  402e0c:	cmp    $0x310817f,%rax
  402e12:	ja     402e28 <nx_rt_fast_take2+0x58>
  402e14:	movl   $0x3,0x20(%rbx)
  402e1b:	xor    %eax,%eax
  402e1d:	pop    %rbx
  402e1e:	pop    %rbp
  402e1f:	pop    %r12
  402e21:	retq   
  402e22:	nopw   0x0(%rax,%rax,1)
  402e28:	mov    0x8(%rbp),%rdx
  402e2c:	mov    %rdx,(%rdi,%rax,8)
  402e30:	mov    0x3e3a2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e36:	mov    %rax,0x8(%rbp)
  402e3a:	mov    0x108(%rbp),%rax
  402e41:	add    $0x2,%rax
  402e45:	mov    %rax,0x108(%rbp)
  402e4c:	cmp    %rdx,%rax
  402e4f:	jae    4015fe <nx_rt_fast_take2.cold>
  402e55:	movl   $0x3,0x20(%rbx)
  402e5c:	xor    %eax,%eax
  402e5e:	pop    %rbx
  402e5f:	pop    %rbp
  402e60:	pop    %r12
  402e62:	retq   
  402e63:	nopl   0x0(%rax,%rax,1)
  402e68:	mov    0x4(%rdx),%ecx
  402e6b:	mov    (%rdx),%r8d
  402e6e:	shl    $0x20,%rcx
  402e72:	or     %r8,%rcx
  402e75:	mov    %rcx,%r12
  402e78:	and    $0xffffff,%ecx
  402e7e:	shr    $0x18,%r12
  402e82:	lea    0x0(,%r12,8),%r8
  402e8a:	lea    (%rdi,%r8,1),%r9
  402e8e:	lea    0x8(%rdi,%r8,1),%r8
  402e93:	cmp    $0x1,%rcx
  402e97:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  402e9d:	mov    (%rdx),%ecx
  402e9f:	mov    (%r9),%rcx
  402ea2:	mov    %rcx,0x10(%rbx)
  402ea6:	mov    (%r8),%rcx
  402ea9:	mov    %rcx,0x18(%rbx)
  402ead:	mov    0x0(%rbp),%rcx
  402eb1:	mov    %rcx,(%rdx)
  402eb4:	mov    0x3e31e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402eba:	mov    %rax,0x0(%rbp)
  402ebe:	mov    0x100(%rbp),%rax
  402ec5:	add    $0x1,%rax
  402ec9:	mov    %rax,0x100(%rbp)
  402ed0:	cmp    %rdx,%rax
  402ed3:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  402ed9:	mov    %r12,%rax
  402edc:	jmpq   402e0c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
