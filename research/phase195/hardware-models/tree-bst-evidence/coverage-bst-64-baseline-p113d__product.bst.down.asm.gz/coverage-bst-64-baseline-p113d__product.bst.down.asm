0000000000408f6f <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_>:
  408f6f:	push   rbp
  408f70:	mov    rbp,rsp
  408f73:	sub    rsp,0x9e0
  408f7a:	mov    QWORD PTR [rbp-0x10],r12
  408f7e:	mov    QWORD PTR [rbp-0x8],rbx
  408f82:	mov    QWORD PTR [rbp-0x18],r13
  408f86:	mov    QWORD PTR [rbp-0x20],r14
  408f8a:	mov    QWORD PTR [rbp-0x28],r15
  408f8e:	mov    rax,rdi
  408f91:	mov    r12,rax
  408f94:	mov    rax,rsi
  408f97:	mov    QWORD PTR [rbp-0x30],rax
  408f9b:	mov    rax,rdx
  408f9e:	mov    rdi,rax
  408fa1:	mov    rax,rcx
  408fa4:	mov    r15,rax
  408fa7:	mov    rax,r8
  408faa:	mov    rsi,rax
  408fad:	mov    rax,r9
  408fb0:	mov    rbx,rax
  408fb3:	cmp    rdi,0x0
  408fba:	jne    408ff0 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x81>
  408fc0:	mov    r10,rsi
  408fc3:	mov    r11,QWORD PTR [rbp-0x30]
  408fc7:	mov    QWORD PTR [r11],r10
  408fca:	mov    r10,rbx
  408fcd:	mov    r11,QWORD PTR [rbp-0x30]
  408fd1:	mov    QWORD PTR [r11+0x8],r10
  408fd5:	xor    eax,eax
  408fd7:	mov    r12,QWORD PTR [rbp-0x10]
  408fdb:	mov    rbx,QWORD PTR [rbp-0x8]
  408fdf:	mov    r13,QWORD PTR [rbp-0x18]
  408fe3:	mov    r14,QWORD PTR [rbp-0x20]
  408fe7:	mov    r15,QWORD PTR [rbp-0x28]
  408feb:	mov    rsp,rbp
  408fee:	pop    rbp
  408fef:	ret    
  408ff0:	mov    r10,rdi
  408ff3:	sub    r10,0x1
  408ffa:	mov    QWORD PTR [rbp-0x8d0],r10
  409001:	mov    rdi,rsi
  409004:	shr    rdi,0x28
  409008:	and    rdi,0xffff
  40900f:	movabs r11,0xa4
  409019:	cmp    rdi,r11
  40901c:	jne    409031 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0xc2>
  409022:	movabs r13,0x100a40000000000
  40902c:	jmp    409220 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x2b1>
  409031:	mov    rdi,rsi
  409034:	shr    rdi,0x28
  409038:	and    rdi,0xffff
  40903f:	movabs r11,0xa5
  409049:	cmp    rdi,r11
  40904c:	jne    4091ef <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x280>
  409052:	mov    r10,r12
  409055:	mov    QWORD PTR [rsp+0x18],r10
  40905a:	mov    r10,rsi
  40905d:	mov    QWORD PTR [rsp+0x20],r10
  409062:	lea    r10,[rbp-0x8e8]
  409069:	mov    QWORD PTR [rsp+0x28],r10
  40906e:	mov    rdi,QWORD PTR [rsp+0x18]
  409073:	mov    rsi,QWORD PTR [rsp+0x20]
  409078:	mov    rdx,QWORD PTR [rsp+0x28]
  40907d:	xor    eax,eax
  40907f:	call   41de20 <p125_rt_take3>
  409084:	mov    QWORD PTR [rbp-0x910],rax
  40908b:	lea    r10,[rbp-0x8e8]
  409092:	mov    r14,QWORD PTR [r10]
  409095:	lea    r10,[rbp-0x8e8]
  40909c:	mov    rdi,QWORD PTR [r10+0x8]
  4090a0:	lea    r10,[rbp-0x8e8]
  4090a7:	mov    r13,QWORD PTR [r10+0x10]
  4090ab:	mov    esi,r15d
  4090ae:	mov    edx,edi
  4090b0:	cmp    rsi,rdx
  4090b3:	setb   sil
  4090b7:	movzx  esi,sil
  4090bb:	mov    esi,esi
  4090bd:	mov    r10,rsi
  4090c0:	test   r10d,r10d
  4090c3:	je     40915c <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x1ed>
  4090c9:	lea    r10,[rbp-0x958]
  4090d0:	mov    r11,rdi
  4090d3:	mov    QWORD PTR [r10],r11
  4090d6:	lea    r10,[rbp-0x958]
  4090dd:	mov    r11,r13
  4090e0:	mov    QWORD PTR [r10+0x8],r11
  4090e4:	lea    r10,[rbp-0x958]
  4090eb:	movabs r11,0x1
  4090f5:	mov    QWORD PTR [r10+0x10],r11
  4090f9:	mov    rdi,r12
  4090fc:	movabs rsi,0xa6
  409106:	mov    esi,esi
  409108:	lea    rdx,[rbp-0x958]
  40910f:	xor    eax,eax
  409111:	call   41dd50 <p125_rt_ctor3>
  409116:	mov    rdi,rax
  409119:	lea    r10,[rbp-0x958]
  409120:	mov    r11,rdi
  409123:	mov    QWORD PTR [r10],r11
  409126:	lea    r10,[rbp-0x958]
  40912d:	mov    r11,rbx
  409130:	mov    QWORD PTR [r10+0x8],r11
  409134:	mov    rdi,r12
  409137:	movabs rsi,0x12
  409141:	mov    esi,esi
  409143:	lea    rdx,[rbp-0x958]
  40914a:	xor    eax,eax
  40914c:	call   41dad0 <p125_rt_ctor2>
  409151:	mov    rdi,rax
  409154:	mov    r13,r14
  409157:	jmp    4091e7 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x278>
  40915c:	lea    r10,[rbp-0x958]
  409163:	mov    r11,rdi
  409166:	mov    QWORD PTR [r10],r11
  409169:	lea    r10,[rbp-0x958]
  409170:	mov    r11,r14
  409173:	mov    QWORD PTR [r10+0x8],r11
  409177:	lea    r10,[rbp-0x958]
  40917e:	movabs r11,0x0
  409188:	mov    QWORD PTR [r10+0x10],r11
  40918c:	mov    rdi,r12
  40918f:	movabs rsi,0xa6
  409199:	mov    esi,esi
  40919b:	lea    rdx,[rbp-0x958]
  4091a2:	xor    eax,eax
  4091a4:	call   41dd50 <p125_rt_ctor3>
  4091a9:	mov    rdi,rax
  4091ac:	lea    r10,[rbp-0x958]
  4091b3:	mov    r11,rdi
  4091b6:	mov    QWORD PTR [r10],r11
  4091b9:	lea    r10,[rbp-0x958]
  4091c0:	mov    r11,rbx
  4091c3:	mov    QWORD PTR [r10+0x8],r11
  4091c7:	mov    rdi,r12
  4091ca:	movabs rsi,0x12
  4091d4:	mov    esi,esi
  4091d6:	lea    rdx,[rbp-0x958]
  4091dd:	xor    eax,eax
  4091df:	call   41dad0 <p125_rt_ctor2>
  4091e4:	mov    rdi,rax
  4091e7:	mov    rbx,rdi
  4091ea:	jmp    409220 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x2b1>
  4091ef:	mov    rdi,r12
  4091f2:	movabs rsi,0x4
  4091fc:	mov    esi,esi
  4091fe:	xor    eax,eax
  409200:	call   4185b0 <p111_rt_fail>
  409205:	mov    QWORD PTR [rbp-0x910],rax
  40920c:	movabs r13,0x0
  409216:	movabs rbx,0x0
  409220:	mov    r10,QWORD PTR [rbp-0x8d0]
  409227:	mov    rdi,r10
  40922a:	mov    rsi,r13
  40922d:	jmp    408fb3 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_100_111_119_110_+0x44>

