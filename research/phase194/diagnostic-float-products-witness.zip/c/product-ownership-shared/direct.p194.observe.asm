    9b90:	push   %rax
    9b91:	mov    %rsi,%rax
    9b94:	movabs $0xffffffffff,%r9
    9b9e:	mov    %rsi,%rcx
    9ba1:	test   %rsi,%rsi
    9ba4:	js     9bd1 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x41>
    9ba6:	shr    $0x39,%rcx
    9baa:	je     9bed <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x5d>
    9bac:	lea    -0x7f(%r9),%rcx
    9bb0:	and    %rax,%rcx
    9bb3:	cmp    $0x3108180,%rcx
    9bba:	jb     9bed <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x5d>
    9bbc:	mov    %r12,%rdi
    9bbf:	mov    %r13,%rsi
    9bc2:	mov    %rax,%rdx
    9bc5:	mov    $0x2,%ecx
    9bca:	callq  1184e <rfc_wrap>
    9bcf:	jmp    9bed <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x5d>
    9bd1:	and    %r9,%rcx
    9bd4:	mov    $0x1,%edx
    9bd9:	lock xadd %edx,(%r12,%rcx,8)
    9bdf:	not    %edx
    9be1:	test   $0xfffffe,%edx
    9be7:	je     9ea8 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x318>
    9bed:	movabs $0xffff0000000000,%rcx
    9bf7:	and    %rax,%rcx
    9bfa:	movabs $0xa40000000000,%rdx
    9c04:	cmp    %rdx,%rcx
    9c07:	jne    9e69 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x2d9>
    9c0d:	mov    %rax,%rdx
    9c10:	and    %r9,%rdx
    9c13:	test   %rax,%rax
    9c16:	js     9c2d <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x9d>
    9c18:	mov    (%r12,%rdx,8),%r10
    9c1c:	mov    %rdx,%rcx
    9c1f:	cmp    $0x3108180,%rcx
    9c26:	jae    9c9a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x10a>
    9c28:	jmpq   9cca <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x13a>
    9c2d:	mov    0x4(%r12,%rdx,8),%ecx
    9c32:	mov    (%r12,%rdx,8),%esi
    9c36:	mov    %esi,%edi
    9c38:	and    $0xffffff,%edi
    9c3e:	cmp    $0x1,%edi
    9c41:	jne    9cfe <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x16e>
    9c47:	mov    (%r12,%rdx,8),%edi
    9c4b:	shl    $0x20,%rcx
    9c4f:	or     %rsi,%rcx
    9c52:	shr    $0x18,%rcx
    9c56:	mov    (%r12,%rcx,8),%r10
    9c5a:	mov    0x0(%r13),%rsi
    9c5e:	mov    %rsi,(%r12,%rdx,8)
    9c62:	mov    %rdx,0x0(%r13)
    9c66:	mov    0x100(%r13),%rdx
    9c6d:	inc    %rdx
    9c70:	mov    %rdx,0x100(%r13)
    9c77:	cmpb   $0x1,0x10b592(%rip)        # 115210 <KEEP_WORDS>
    9c7e:	jne    9e4a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x2ba>
    9c84:	cmp    $0x8000,%rdx
    9c8b:	jae    9e4a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x2ba>
    9c91:	cmp    $0x3108180,%rcx
    9c98:	jb     9cca <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x13a>
    9c9a:	mov    0x8(%r13),%rdx
    9c9e:	mov    %rdx,(%r12,%rcx,8)
    9ca2:	mov    %rcx,0x8(%r13)
    9ca6:	mov    0x108(%r13),%rcx
    9cad:	add    $0x2,%rcx
    9cb1:	mov    %rcx,0x108(%r13)
    9cb8:	cmpb   $0x1,0x10b551(%rip)        # 115210 <KEEP_WORDS>
    9cbf:	jne    9cec <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x15c>
    9cc1:	cmp    $0x8000,%rcx
    9cc8:	jae    9cec <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x15c>
    9cca:	test   %rax,%rax
    9ccd:	js     9d21 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x191>
    9ccf:	and    %r9,%rax
    9cd2:	mov    0x8(%r12,%rax,8),%rsi
    9cd7:	mov    %rax,%rcx
    9cda:	cmp    $0x3108180,%rcx
    9ce1:	jae    9d91 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x201>
    9ce7:	jmpq   9dc0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x230>
    9cec:	mov    %r12,%rdi
    9cef:	mov    %r13,%rsi
    9cf2:	mov    $0x1,%edx
    9cf7:	callq  11421 <heap_hand>
    9cfc:	jmp    9cca <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x13a>
    9cfe:	shl    $0x20,%rcx
    9d02:	or     %rsi,%rcx
    9d05:	shr    $0x18,%rcx
    9d09:	mov    (%r12,%rcx,8),%r10
    9d0d:	mov    %r12,%rdi
    9d10:	mov    %r13,%rsi
    9d13:	mov    %rax,%rdx
    9d16:	mov    $0x2,%r8d
    9d1c:	callq  114b2 <span_fade>
    9d21:	and    %rax,%r9
    9d24:	mov    0x4(%r12,%r9,8),%ecx
    9d29:	mov    (%r12,%r9,8),%edx
    9d2d:	mov    %edx,%esi
    9d2f:	and    $0xffffff,%esi
    9d35:	cmp    $0x1,%esi
    9d38:	jne    9dfc <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x26c>
    9d3e:	mov    (%r12,%r9,8),%eax
    9d42:	shl    $0x20,%rcx
    9d46:	or     %rdx,%rcx
    9d49:	shr    $0x18,%rcx
    9d4d:	mov    0x8(%r12,%rcx,8),%rsi
    9d52:	mov    0x0(%r13),%rax
    9d56:	mov    %rax,(%r12,%r9,8)
    9d5a:	mov    %r9,0x0(%r13)
    9d5e:	mov    0x100(%r13),%rax
    9d65:	inc    %rax
    9d68:	mov    %rax,0x100(%r13)
    9d6f:	cmpb   $0x1,0x10b49a(%rip)        # 115210 <KEEP_WORDS>
    9d76:	jne    9e25 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x295>
    9d7c:	cmp    $0x8000,%rax
    9d82:	jae    9e25 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x295>
    9d88:	cmp    $0x3108180,%rcx
    9d8f:	jb     9dc0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x230>
    9d91:	mov    0x8(%r13),%rax
    9d95:	mov    %rax,(%r12,%rcx,8)
    9d99:	mov    %rcx,0x8(%r13)
    9d9d:	mov    0x108(%r13),%rax
    9da4:	add    $0x2,%rax
    9da8:	mov    %rax,0x108(%r13)
    9daf:	cmpb   $0x1,0x10b45a(%rip)        # 115210 <KEEP_WORDS>
    9db6:	jne    9de4 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x254>
    9db8:	cmp    $0x8000,%rax
    9dbe:	jae    9de4 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x254>
    9dc0:	lea    (%r10,%r10,2),%eax
    9dc4:	xor    $0x7,%esi
    9dc7:	add    %eax,%esi
    9dc9:	mov    -0x8(%r14),%eax
    9dcd:	add    $0xfffffffffffffff8,%r14
    9dd1:	lea    0x9bd8(%rip),%rcx        # 139b0 <wl_tab>
    9dd8:	mov    (%rcx,%rax,8),%rax
    9ddc:	mov    $0x1,%edi
    9de1:	pop    %rcx
    9de2:	jmpq   *%rax
    9de4:	mov    %r12,%rdi
    9de7:	mov    %rsi,%rax
    9dea:	mov    %r13,%rsi
    9ded:	mov    $0x1,%edx
    9df2:	callq  11421 <heap_hand>
    9df7:	mov    %rax,%rsi
    9dfa:	jmp    9dc0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x230>
    9dfc:	shl    $0x20,%rcx
    9e00:	or     %rdx,%rcx
    9e03:	shr    $0x18,%rcx
    9e07:	mov    0x8(%r12,%rcx,8),%r9
    9e0c:	mov    %r12,%rdi
    9e0f:	mov    %r13,%rsi
    9e12:	mov    %rax,%rdx
    9e15:	mov    $0x2,%r8d
    9e1b:	callq  114b2 <span_fade>
    9e20:	mov    %r9,%rsi
    9e23:	jmp    9dc0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x230>
    9e25:	mov    %r12,%rdi
    9e28:	mov    %rsi,%rax
    9e2b:	mov    %r13,%rsi
    9e2e:	xor    %edx,%edx
    9e30:	callq  11421 <heap_hand>
    9e35:	mov    %rax,%rsi
    9e38:	cmp    $0x3108180,%rcx
    9e3f:	jae    9d91 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x201>
    9e45:	jmpq   9dc0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x230>
    9e4a:	mov    %r12,%rdi
    9e4d:	mov    %r13,%rsi
    9e50:	xor    %edx,%edx
    9e52:	callq  11421 <heap_hand>
    9e57:	cmp    $0x3108180,%rcx
    9e5e:	jae    9c9a <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x10a>
    9e64:	jmpq   9cca <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x13a>
    9e69:	cmp    $0xffffffffffffffff,%rax
    9e6d:	je     9e9c <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x30c>
    9e6f:	movabs $0x7e00000000000000,%rcx
    9e79:	and    %rax,%rcx
    9e7c:	je     9e9c <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x30c>
    9e7e:	add    $0xffffffffffffff81,%r9
    9e82:	and    %rax,%r9
    9e85:	cmp    $0x3108180,%r9
    9e8c:	jb     9e9c <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x30c>
    9e8e:	mov    %r12,%rdi
    9e91:	mov    %r13,%rsi
    9e94:	mov    %rax,%rdx
    9e97:	callq  6ac0 <term_drop>
    9e9c:	lea    -0x7993(%rip),%rdi        # 2510 <FID_RESW_T+0x310>
    9ea3:	callq  113c0 <err_fail>
    9ea8:	lea    -0x73d6(%rip),%rdi        # 2ad9 <FID_RESW_T+0x8d9>
    9eaf:	callq  113c0 <err_fail>
    9eb4:	data16 data16 nopw %cs:0x0(%rax,%rax,1)
