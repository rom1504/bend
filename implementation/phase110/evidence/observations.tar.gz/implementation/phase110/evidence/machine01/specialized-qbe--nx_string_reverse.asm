
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c80 <nx_string_reverse>:
  401c80:	endbr64 
  401c84:	push   %rbp
  401c85:	mov    %rsp,%rbp
  401c88:	push   %rbx
  401c89:	push   %r12
  401c8b:	mov    %rdx,%rax
  401c8e:	mov    %rax,%rdx
  401c91:	data16 nopw %cs:0x0(%rax,%rax,1)
  401c9c:	nopl   0x0(%rax)
  401ca0:	mov    %rsi,%rax
  401ca3:	shr    $0x28,%rax
  401ca7:	and    $0xffff,%rax
  401cad:	cmp    $0x2,%rax
  401cb1:	je     401ceb <nx_string_reverse+0x6b>
  401cb3:	cmp    $0x3,%rax
  401cb7:	jne    401cdf <nx_string_reverse+0x5f>
  401cb9:	mov    %rdi,%rbx
  401cbc:	callq  4037a0 <nx_rt_rebuild2_c3_k0>
  401cc1:	mov    %rbx,%rdi
  401cc4:	mov    %rax,%r12
  401cc7:	mov    $0x0,%esi
  401ccc:	mov    %rdi,%rbx
  401ccf:	callq  402d10 <nx_rt_fast_field>
  401cd4:	mov    %r12,%rdx
  401cd7:	mov    %rbx,%rdi
  401cda:	mov    %rax,%rsi
  401cdd:	jmp    401ca0 <nx_string_reverse+0x20>
  401cdf:	mov    $0x1,%esi
  401ce4:	callq  402560 <nx_rt_fail>
  401ce9:	jmp    401cee <nx_string_reverse+0x6e>
  401ceb:	mov    %rdx,%rax
  401cee:	pop    %r12
  401cf0:	pop    %rbx
  401cf1:	leaveq 
  401cf2:	retq   

Disassembly of section .fini:
