
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402620 <nx_rt_take2>:
  402620:	push   %r13
  402622:	push   %r12
  402624:	sub    $0x8,%rsp
  402628:	cmpb   $0x0,0x5b51(%rip)        # 408180 <nx_active>
  40262f:	je     40263d <nx_rt_take2+0x1d>
  402631:	lea    0x5b68(%rip),%rax        # 4081a0 <nx_context>
  402638:	cmp    %rax,%rdi
  40263b:	je     402650 <nx_rt_take2+0x30>
  40263d:	lea    0x29ef(%rip),%rdi        # 405033 <_IO_stdin_used+0x33>
  402644:	callq  401ac0 <err_fail>
  402649:	nopl   0x0(%rax)
  402650:	mov    0x5b6a(%rip),%eax        # 4081c0 <nx_context+0x20>
  402656:	mov    0x5b43(%rip),%rdi        # 4081a0 <nx_context>
  40265d:	test   %eax,%eax
  40265f:	jne    402799 <nx_rt_take2+0x179>
  402665:	mov    %rsi,%r12
  402668:	callq  401bf0 <nx_id.isra.0>
  40266d:	and    $0xfffffffd,%eax
  402670:	cmp    $0x1,%eax
  402673:	jne    40278d <nx_rt_take2+0x16d>
  402679:	mov    0x5b20(%rip),%rdi        # 4081a0 <nx_context>
  402680:	mov    0x5b21(%rip),%rsi        # 4081a8 <nx_context+0x8>
  402687:	movabs $0xffffffffff,%rax
  402691:	and    %r12,%rax
  402694:	lea    0x0(,%rax,8),%rcx
  40269c:	lea    (%rdi,%rcx,1),%rdx
  4026a0:	test   %r12,%r12
  4026a3:	js     402710 <nx_rt_take2+0xf0>
  4026a5:	mov    (%rdx),%rdx
  4026a8:	mov    %rdx,0x5b01(%rip)        # 4081b0 <nx_context+0x10>
  4026af:	mov    0x8(%rdi,%rcx,1),%rdx
  4026b4:	mov    %rdx,0x5afd(%rip)        # 4081b8 <nx_context+0x18>
  4026bb:	cmp    $0x310817f,%rax
  4026c1:	ja     4026e0 <nx_rt_take2+0xc0>
  4026c3:	movl   $0x3,0x5af3(%rip)        # 4081c0 <nx_context+0x20>
  4026cd:	add    $0x8,%rsp
  4026d1:	xor    %eax,%eax
  4026d3:	pop    %r12
  4026d5:	pop    %r13
  4026d7:	retq   
  4026d8:	nopl   0x0(%rax,%rax,1)
  4026e0:	mov    0x8(%rsi),%rdx
  4026e4:	mov    %rdx,(%rdi,%rax,8)
  4026e8:	mov    0x5aea(%rip),%edx        # 4081d8 <KEEP_WORDS>
  4026ee:	mov    %rax,0x8(%rsi)
  4026f2:	mov    0x108(%rsi),%rax
  4026f9:	add    $0x2,%rax
  4026fd:	mov    %rax,0x108(%rsi)
  402704:	cmp    %rdx,%rax
  402707:	jb     4026c3 <nx_rt_take2+0xa3>
  402709:	jmpq   401567 <nx_rt_take2.cold>
  40270e:	xchg   %ax,%ax
  402710:	mov    0x4(%rdx),%ecx
  402713:	mov    (%rdx),%r8d
  402716:	shl    $0x20,%rcx
  40271a:	or     %r8,%rcx
  40271d:	mov    %rcx,%r13
  402720:	and    $0xffffff,%ecx
  402726:	shr    $0x18,%r13
  40272a:	lea    0x0(,%r13,8),%r8
  402732:	lea    (%rdi,%r8,1),%r9
  402736:	lea    0x8(%rdi,%r8,1),%r8
  40273b:	cmp    $0x1,%rcx
  40273f:	jne    401582 <nx_rt_take2.cold+0x1b>
  402745:	mov    (%rdx),%ecx
  402747:	mov    (%r9),%rcx
  40274a:	mov    %rcx,0x5a5f(%rip)        # 4081b0 <nx_context+0x10>
  402751:	mov    (%r8),%rcx
  402754:	mov    %rcx,0x5a5d(%rip)        # 4081b8 <nx_context+0x18>
  40275b:	mov    (%rsi),%rcx
  40275e:	mov    %rcx,(%rdx)
  402761:	mov    0x5a71(%rip),%edx        # 4081d8 <KEEP_WORDS>
  402767:	mov    %rax,(%rsi)
  40276a:	mov    0x100(%rsi),%rax
  402771:	add    $0x1,%rax
  402775:	mov    %rax,0x100(%rsi)
  40277c:	cmp    %rdx,%rax
  40277f:	jae    401576 <nx_rt_take2.cold+0xf>
  402785:	mov    %r13,%rax
  402788:	jmpq   4026bb <nx_rt_take2+0x9b>
  40278d:	lea    0x2b84(%rip),%rdi        # 405318 <_IO_stdin_used+0x318>
  402794:	callq  401ac0 <err_fail>
  402799:	lea    0x2b50(%rip),%rdi        # 4052f0 <_IO_stdin_used+0x2f0>
  4027a0:	callq  401ac0 <err_fail>

Disassembly of section .fini:
