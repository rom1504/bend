
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402900 <nx_rt_fast_build2>:
  402900:	push   %r15
  402902:	push   %r14
  402904:	push   %r13
  402906:	mov    %rdx,%r13
  402909:	push   %r12
  40290b:	mov    %rcx,%r12
  40290e:	push   %rbp
  40290f:	push   %rbx
  402910:	mov    %esi,%ebx
  402912:	sub    $0x18,%rsp
  402916:	mov    0x8(%rdi),%r14
  40291a:	mov    (%rdi),%r15
  40291d:	mov    0x8(%r14),%rbp
  402921:	test   %rbp,%rbp
  402924:	je     4015f3 <nx_rt_fast_build2.cold+0x40>
  40292a:	lea    (%r15,%rbp,8),%r8
  40292e:	mov    (%r8),%rax
  402931:	subq   $0x2,0x108(%r14)
  402939:	mov    %rax,0x8(%r14)
  40293d:	mov    %r13,%rax
  402940:	shr    $0x38,%rax
  402944:	and    $0x7f,%eax
  402947:	cmp    $0x2,%rax
  40294b:	je     402990 <nx_rt_fast_build2+0x90>
  40294d:	mov    %r12,%rax
  402950:	mov    %r13,(%r8)
  402953:	lea    0x8(%r15,%rbp,8),%r13
  402958:	shr    $0x38,%rax
  40295c:	and    $0x7f,%eax
  40295f:	cmp    $0x2,%rax
  402963:	je     4029a0 <nx_rt_fast_build2+0xa0>
  402965:	mov    %rbx,%rax
  402968:	mov    %r12,0x0(%r13)
  40296c:	add    $0x18,%rsp
  402970:	shl    $0x28,%rax
  402974:	pop    %rbx
  402975:	or     %rbp,%rax
  402978:	pop    %rbp
  402979:	pop    %r12
  40297b:	bts    $0x39,%rax
  402980:	pop    %r13
  402982:	pop    %r14
  402984:	pop    %r15
  402986:	retq   
  402987:	nopw   0x0(%rax,%rax,1)
  402990:	test   %r13,%r13
  402993:	js     40294d <nx_rt_fast_build2+0x4d>
  402995:	jmpq   4015b3 <nx_rt_fast_build2.cold>
  40299a:	nopw   0x0(%rax,%rax,1)
  4029a0:	test   %r12,%r12
  4029a3:	js     402965 <nx_rt_fast_build2+0x65>
  4029a5:	jmpq   4015d8 <nx_rt_fast_build2.cold+0x25>

Disassembly of section .fini:
