
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004030d0 <nx_rt_fast_take2>:
  4030d0:	movabs $0xffffffffff,%rax
  4030da:	push   %r12
  4030dc:	and    %rsi,%rax
  4030df:	push   %rbp
  4030e0:	push   %rbx
  4030e1:	mov    %rdi,%rbx
  4030e4:	mov    (%rdi),%rdi
  4030e7:	lea    0x0(,%rax,8),%rcx
  4030ef:	mov    0x8(%rbx),%rbp
  4030f3:	lea    (%rdi,%rcx,1),%rdx
  4030f7:	test   %rsi,%rsi
  4030fa:	js     403168 <nx_rt_fast_take2+0x98>
  4030fc:	mov    (%rdx),%rdx
  4030ff:	mov    %rdx,0x10(%rbx)
  403103:	mov    0x8(%rdi,%rcx,1),%rdx
  403108:	mov    %rdx,0x18(%rbx)
  40310c:	cmp    $0x310817f,%rax
  403112:	ja     403128 <nx_rt_fast_take2+0x58>
  403114:	movl   $0x3,0x20(%rbx)
  40311b:	xor    %eax,%eax
  40311d:	pop    %rbx
  40311e:	pop    %rbp
  40311f:	pop    %r12
  403121:	retq   
  403122:	nopw   0x0(%rax,%rax,1)
  403128:	mov    0x8(%rbp),%rdx
  40312c:	mov    %rdx,(%rdi,%rax,8)
  403130:	mov    0x3f0a2(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403136:	mov    %rax,0x8(%rbp)
  40313a:	mov    0x108(%rbp),%rax
  403141:	add    $0x2,%rax
  403145:	mov    %rax,0x108(%rbp)
  40314c:	cmp    %rdx,%rax
  40314f:	jae    4015fe <nx_rt_fast_take2.cold>
  403155:	movl   $0x3,0x20(%rbx)
  40315c:	xor    %eax,%eax
  40315e:	pop    %rbx
  40315f:	pop    %rbp
  403160:	pop    %r12
  403162:	retq   
  403163:	nopl   0x0(%rax,%rax,1)
  403168:	mov    0x4(%rdx),%ecx
  40316b:	mov    (%rdx),%r8d
  40316e:	shl    $0x20,%rcx
  403172:	or     %r8,%rcx
  403175:	mov    %rcx,%r12
  403178:	and    $0xffffff,%ecx
  40317e:	shr    $0x18,%r12
  403182:	lea    0x0(,%r12,8),%r8
  40318a:	lea    (%rdi,%r8,1),%r9
  40318e:	lea    0x8(%rdi,%r8,1),%r8
  403193:	cmp    $0x1,%rcx
  403197:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  40319d:	mov    (%rdx),%ecx
  40319f:	mov    (%r9),%rcx
  4031a2:	mov    %rcx,0x10(%rbx)
  4031a6:	mov    (%r8),%rcx
  4031a9:	mov    %rcx,0x18(%rbx)
  4031ad:	mov    0x0(%rbp),%rcx
  4031b1:	mov    %rcx,(%rdx)
  4031b4:	mov    0x3f01e(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4031ba:	mov    %rax,0x0(%rbp)
  4031be:	mov    0x100(%rbp),%rax
  4031c5:	add    $0x1,%rax
  4031c9:	mov    %rax,0x100(%rbp)
  4031d0:	cmp    %rdx,%rax
  4031d3:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  4031d9:	mov    %r12,%rax
  4031dc:	jmpq   40310c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
