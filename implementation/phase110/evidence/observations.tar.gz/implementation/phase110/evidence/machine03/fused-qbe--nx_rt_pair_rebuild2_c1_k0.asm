
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403750 <nx_rt_pair_rebuild2_c1_k0>:
  403750:	push   %r15
  403752:	push   %r14
  403754:	push   %r13
  403756:	push   %r12
  403758:	mov    %rdx,%r12
  40375b:	push   %rbp
  40375c:	push   %rbx
  40375d:	movabs $0xffffffffff,%rbx
  403767:	and    %rsi,%rbx
  40376a:	lea    0x0(,%rbx,8),%rdx
  403772:	sub    $0x18,%rsp
  403776:	mov    (%rdi),%rbp
  403779:	mov    0x8(%rdi),%r15
  40377d:	lea    0x0(%rbp,%rdx,1),%rax
  403782:	test   %rsi,%rsi
  403785:	js     403840 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  40378b:	mov    (%rax),%r14
  40378e:	mov    0x8(%rbp,%rdx,1),%r13
  403793:	cmp    $0x310817f,%rbx
  40379a:	jbe    403810 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  40379c:	lea    0x0(%rbp,%rbx,8),%r8
  4037a1:	mov    %r14,%rax
  4037a4:	shr    $0x38,%rax
  4037a8:	and    $0x7f,%eax
  4037ab:	cmp    $0x2,%rax
  4037af:	je     4037f0 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  4037b1:	mov    %r12,%rax
  4037b4:	mov    %r14,(%r8)
  4037b7:	lea    0x8(%rbp,%rbx,8),%r14
  4037bc:	shr    $0x38,%rax
  4037c0:	and    $0x7f,%eax
  4037c3:	cmp    $0x2,%rax
  4037c7:	je     403800 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  4037c9:	movabs $0x200010000000000,%rax
  4037d3:	mov    %r12,(%r14)
  4037d6:	mov    %r13,%rdx
  4037d9:	add    $0x18,%rsp
  4037dd:	or     %rbx,%rax
  4037e0:	pop    %rbx
  4037e1:	pop    %rbp
  4037e2:	pop    %r12
  4037e4:	pop    %r13
  4037e6:	pop    %r14
  4037e8:	pop    %r15
  4037ea:	retq   
  4037eb:	nopl   0x0(%rax,%rax,1)
  4037f0:	test   %r14,%r14
  4037f3:	js     4037b1 <nx_rt_pair_rebuild2_c1_k0+0x61>
  4037f5:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  4037fa:	nopw   0x0(%rax,%rax,1)
  403800:	test   %r12,%r12
  403803:	js     4037c9 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403805:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  40380a:	nopw   0x0(%rax,%rax,1)
  403810:	mov    0x8(%r15),%rbx
  403814:	test   %rbx,%rbx
  403817:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  40381d:	lea    0x0(%rbp,%rbx,8),%r8
  403822:	mov    (%r8),%rax
  403825:	subq   $0x2,0x108(%r15)
  40382d:	mov    %rax,0x8(%r15)
  403831:	jmpq   4037a1 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403836:	nopw   %cs:0x0(%rax,%rax,1)
  403840:	mov    0x4(%rax),%edx
  403843:	mov    (%rax),%ecx
  403845:	shl    $0x20,%rdx
  403849:	or     %rcx,%rdx
  40384c:	mov    %rdx,%rcx
  40384f:	and    $0xffffff,%edx
  403855:	shr    $0x18,%rcx
  403859:	lea    0x8(,%rcx,8),%rdi
  403861:	lea    0x0(%rbp,%rdi,1),%r8
  403866:	lea    -0x8(%rbp,%rdi,1),%rdi
  40386b:	cmp    $0x1,%rdx
  40386f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403875:	mov    (%rax),%edx
  403877:	mov    (%r15),%rdx
  40387a:	mov    (%rdi),%r14
  40387d:	mov    (%r8),%r13
  403880:	mov    %rdx,(%rax)
  403883:	mov    0x100(%r15),%rax
  40388a:	mov    0x3d948(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403890:	mov    %rbx,(%r15)
  403893:	add    $0x1,%rax
  403897:	mov    %rax,0x100(%r15)
  40389e:	cmp    %rdx,%rax
  4038a1:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  4038a7:	mov    %rcx,%rbx
  4038aa:	jmpq   403793 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
