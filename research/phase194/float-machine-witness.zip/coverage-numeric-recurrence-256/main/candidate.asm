  4108cd:	lea    0x1202c(%rip),%rdx        # 422900 <p111_program>
  4108d4:	jmpq   417080 <p111_rt_main>
  4108d9:	nopl   0x0(%rax)
