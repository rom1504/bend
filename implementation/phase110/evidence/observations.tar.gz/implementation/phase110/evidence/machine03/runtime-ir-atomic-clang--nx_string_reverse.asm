
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402020 <nx_string_reverse>:
  402020:	push   %rbp
  402021:	push   %r15
  402023:	push   %r14
  402025:	push   %r13
  402027:	push   %r12
  402029:	push   %rbx
  40202a:	sub    $0x18,%rsp
  40202e:	mov    %rdx,%r14
  402031:	mov    %rsi,%r13
  402034:	mov    %rdi,%rbx
  402037:	callq  404520 <nx_rt_ir_heap>
  40203c:	mov    %rax,%r15
  40203f:	mov    %rbx,%rdi
  402042:	callq  404590 <nx_rt_ir_alc>
  402047:	mov    %rax,%rsi
  40204a:	mov    %rax,0x8(%rsp)
  40204f:	jmp    402083 <nx_string_reverse+0x63>
  402051:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  402060:	mov    %rbx,%rdi
  402063:	mov    %r13,%rsi
  402066:	mov    %r14,%rdx
  402069:	callq  403e80 <nx_rt_rebuild2_c3_k0>
  40206e:	mov    %rax,%r14
  402071:	mov    %rbx,%rdi
  402074:	xor    %esi,%esi
  402076:	callq  403210 <nx_rt_fast_field>
  40207b:	mov    0x8(%rsp),%rsi
  402080:	mov    %rax,%r13
  402083:	mov    %r13,%rax
  402086:	shr    $0x28,%rax
  40208a:	cmp    $0x3,%ax
  40208e:	jne    4021f4 <nx_string_reverse+0x1d4>
  402094:	mov    %r13,%rbp
  402097:	movabs $0xffffffffff,%rax
  4020a1:	and    %rax,%rbp
  4020a4:	test   %r13,%r13
  4020a7:	js     4020d0 <nx_string_reverse+0xb0>
  4020a9:	cmp    $0x3108180,%rbp
  4020b0:	jb     402060 <nx_string_reverse+0x40>
  4020b2:	lea    (%r15,%rbp,8),%r12
  4020b6:	mov    (%r15,%rbp,8),%rdi
  4020ba:	mov    0x8(%r15,%rbp,8),%r13
  4020bf:	lea    (%r15,%rbp,8),%r8
  4020c3:	add    $0x8,%r8
  4020c7:	jmpq   402163 <nx_string_reverse+0x143>
  4020cc:	nopl   0x0(%rax)
  4020d0:	mov    %rbx,%rdi
  4020d3:	mov    %rbp,%rsi
  4020d6:	callq  404600 <nx_rt_ir_view>
  4020db:	mov    0x8(%rsp),%rsi
  4020e0:	mov    %rax,%r12
  4020e3:	and    $0xffffff,%eax
  4020e8:	cmp    $0x1,%eax
  4020eb:	jne    402060 <nx_string_reverse+0x40>
  4020f1:	mov    %r12,%rax
  4020f4:	shr    $0x1f,%rax
  4020f8:	cmp    $0x62102,%rax
  4020fe:	jbe    402060 <nx_string_reverse+0x40>
  402104:	shr    $0x18,%r12
  402108:	lea    (%r15,%r12,8),%rax
  40210c:	mov    %rax,(%rsp)
  402110:	mov    (%r15,%r12,8),%rdi
  402114:	mov    0x8(%r15,%r12,8),%r13
  402119:	lea    0x8(%r15,%r12,8),%r8
  40211e:	mov    (%rsi),%rax
  402121:	mov    %rax,(%r15,%rbp,8)
  402125:	mov    %rbp,(%rsi)
  402128:	mov    0x100(%rsi),%rax
  40212f:	inc    %rax
  402132:	mov    %rax,0x100(%rsi)
  402139:	cmp    $0x8000,%rax
  40213f:	jb     40215c <nx_string_reverse+0x13c>
  402141:	mov    %rdi,%rbp
  402144:	mov    %rbx,%rdi
  402147:	callq  401c36 <nx_rt_ir_hand0>
  40214c:	lea    (%r15,%r12,8),%r8
  402150:	add    $0x8,%r8
  402154:	mov    %rbp,%rdi
  402157:	mov    0x8(%rsp),%rsi
  40215c:	mov    %r12,%rbp
  40215f:	mov    (%rsp),%r12
  402163:	mov    %r14,%rax
  402166:	shr    $0x38,%rax
  40216a:	cmp    $0x2,%eax
  40216d:	jne    4021d8 <nx_string_reverse+0x1b8>
  40216f:	mov    (%rsi),%rax
  402172:	test   %rax,%rax
  402175:	je     40218b <nx_string_reverse+0x16b>
  402177:	lea    (%r15,%rax,8),%rcx
  40217b:	mov    (%r15,%rax,8),%rdx
  40217f:	mov    %rdx,(%rsi)
  402182:	decq   0x100(%rsi)
  402189:	jmp    4021ae <nx_string_reverse+0x18e>
  40218b:	mov    %rdi,(%rsp)
  40218f:	mov    %rbx,%rdi
  402192:	mov    %r8,0x10(%rsp)
  402197:	callq  401c25 <nx_rt_ir_alloc0>
  40219c:	mov    0x10(%rsp),%r8
  4021a1:	mov    (%rsp),%rdi
  4021a5:	mov    0x8(%rsp),%rsi
  4021aa:	lea    (%r15,%rax,8),%rcx
  4021ae:	mov    %r14,%rdx
  4021b1:	shl    $0x18,%rdx
  4021b5:	inc    %rdx
  4021b8:	mov    %rdx,(%rcx)
  4021bb:	movabs $0x2ffff0000000000,%rcx
  4021c5:	and    %rcx,%r14
  4021c8:	movabs $0x8000000000000000,%rcx
  4021d2:	or     %rcx,%r14
  4021d5:	or     %rax,%r14
  4021d8:	mov    %rdi,(%r12)
  4021dc:	mov    %r14,(%r8)
  4021df:	movabs $0x200030000000000,%rax
  4021e9:	or     %rax,%rbp
  4021ec:	mov    %rbp,%r14
  4021ef:	jmpq   402083 <nx_string_reverse+0x63>
  4021f4:	movzwl %ax,%eax
  4021f7:	cmp    $0x2,%eax
  4021fa:	jne    40220e <nx_string_reverse+0x1ee>
  4021fc:	mov    %r14,%rax
  4021ff:	add    $0x18,%rsp
  402203:	pop    %rbx
  402204:	pop    %r12
  402206:	pop    %r13
  402208:	pop    %r14
  40220a:	pop    %r15
  40220c:	pop    %rbp
  40220d:	retq   
  40220e:	mov    %rbx,%rdi
  402211:	mov    $0x1,%esi
  402216:	add    $0x18,%rsp
  40221a:	pop    %rbx
  40221b:	pop    %r12
  40221d:	pop    %r13
  40221f:	pop    %r14
  402221:	pop    %r15
  402223:	pop    %rbp
  402224:	jmpq   402a10 <nx_rt_fail>

Disassembly of section .fini:
