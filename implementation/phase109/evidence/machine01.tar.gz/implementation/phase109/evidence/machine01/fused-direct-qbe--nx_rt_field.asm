
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402680 <nx_rt_field>:
  402680:	sub    $0x8,%rsp
  402684:	cmpb   $0x0,0x4af5(%rip)        # 407180 <nx_active>
  40268b:	je     402699 <nx_rt_field+0x19>
  40268d:	lea    0x4b0c(%rip),%rdx        # 4071a0 <nx_context>
  402694:	cmp    %rdx,%rdi
  402697:	je     4026a8 <nx_rt_field+0x28>
  402699:	lea    0x1993(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4026a0:	callq  401990 <err_fail>
  4026a5:	nopl   (%rax)
  4026a8:	mov    %esi,%ecx
  4026aa:	cmp    $0x1,%ecx
  4026ad:	jbe    4026c0 <nx_rt_field+0x40>
  4026af:	lea    0x1c92(%rip),%rdi        # 404348 <_IO_stdin_used+0x348>
  4026b6:	callq  401990 <err_fail>
  4026bb:	nopl   0x0(%rax,%rax,1)
  4026c0:	mov    $0x1,%eax
  4026c5:	mov    0x4af5(%rip),%esi        # 4071c0 <nx_context+0x20>
  4026cb:	shl    %cl,%eax
  4026cd:	test   %eax,%esi
  4026cf:	je     4026af <nx_rt_field+0x2f>
  4026d1:	not    %eax
  4026d3:	add    $0x2,%rcx
  4026d7:	and    %esi,%eax
  4026d9:	mov    %eax,0x4ae1(%rip)        # 4071c0 <nx_context+0x20>
  4026df:	mov    (%rdx,%rcx,8),%rax
  4026e3:	movq   $0xffffffffffffffff,(%rdx,%rcx,8)
  4026eb:	add    $0x8,%rsp
  4026ef:	retq   

Disassembly of section .fini:
