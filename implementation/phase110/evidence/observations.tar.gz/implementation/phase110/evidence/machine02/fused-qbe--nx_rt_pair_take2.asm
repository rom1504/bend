
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404100 <nx_rt_pair_take2>:
  404100:	movabs $0xffffffffff,%rax
  40410a:	push   %r15
  40410c:	and    %rsi,%rax
  40410f:	push   %r14
  404111:	push   %r13
  404113:	lea    0x0(,%rax,8),%rdx
  40411b:	push   %r12
  40411d:	push   %rbp
  40411e:	mov    (%rdi),%rbp
  404121:	mov    0x8(%rdi),%r14
  404125:	lea    0x0(%rbp,%rdx,1),%rcx
  40412a:	test   %rsi,%rsi
  40412d:	js     404190 <nx_rt_pair_take2+0x90>
  40412f:	mov    (%rcx),%r13
  404132:	mov    0x8(%rbp,%rdx,1),%r12
  404137:	cmp    $0x310817f,%rax
  40413d:	ja     404150 <nx_rt_pair_take2+0x50>
  40413f:	pop    %rbp
  404140:	mov    %r13,%rax
  404143:	mov    %r12,%rdx
  404146:	pop    %r12
  404148:	pop    %r13
  40414a:	pop    %r14
  40414c:	pop    %r15
  40414e:	retq   
  40414f:	nop
  404150:	mov    0x8(%r14),%rdx
  404154:	mov    %rdx,0x0(%rbp,%rax,8)
  404159:	mov    0x3d079(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40415f:	mov    %rax,0x8(%r14)
  404163:	mov    0x108(%r14),%rax
  40416a:	add    $0x2,%rax
  40416e:	mov    %rax,0x108(%r14)
  404175:	cmp    %rdx,%rax
  404178:	jae    401be0 <nx_rt_pair_take2.cold>
  40417e:	pop    %rbp
  40417f:	mov    %r13,%rax
  404182:	mov    %r12,%rdx
  404185:	pop    %r12
  404187:	pop    %r13
  404189:	pop    %r14
  40418b:	pop    %r15
  40418d:	retq   
  40418e:	xchg   %ax,%ax
  404190:	mov    0x4(%rcx),%edx
  404193:	mov    (%rcx),%edi
  404195:	shl    $0x20,%rdx
  404199:	or     %rdi,%rdx
  40419c:	mov    %rdx,%r15
  40419f:	and    $0xffffff,%edx
  4041a5:	shr    $0x18,%r15
  4041a9:	lea    0x8(,%r15,8),%rdi
  4041b1:	lea    0x0(%rbp,%rdi,1),%r8
  4041b6:	cmp    $0x1,%rdx
  4041ba:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  4041c0:	mov    (%rcx),%edx
  4041c2:	mov    (%r14),%rdx
  4041c5:	mov    -0x8(%rbp,%rdi,1),%r13
  4041ca:	mov    (%r8),%r12
  4041cd:	mov    %rdx,(%rcx)
  4041d0:	mov    0x3d002(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4041d6:	mov    %rax,(%r14)
  4041d9:	mov    0x100(%r14),%rax
  4041e0:	add    $0x1,%rax
  4041e4:	mov    %rax,0x100(%r14)
  4041eb:	cmp    %rdx,%rax
  4041ee:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  4041f4:	mov    %r15,%rax
  4041f7:	jmpq   404137 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
