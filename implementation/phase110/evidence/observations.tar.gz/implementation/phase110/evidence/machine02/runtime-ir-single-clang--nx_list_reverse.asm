
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	push   %rbp
  401df1:	push   %r15
  401df3:	push   %r14
  401df5:	push   %r13
  401df7:	push   %r12
  401df9:	push   %rbx
  401dfa:	sub    $0x18,%rsp
  401dfe:	mov    %rdx,%r14
  401e01:	mov    %rsi,%rbp
  401e04:	mov    %rdi,%rbx
  401e07:	callq  404600 <nx_rt_ir_heap>
  401e0c:	mov    %rax,%r15
  401e0f:	mov    %rbx,0x8(%rsp)
  401e14:	mov    %rbx,%rdi
  401e17:	callq  404670 <nx_rt_ir_alc>
  401e1c:	mov    %rax,%rsi
  401e1f:	movabs $0xffffffffff,%r12
  401e29:	mov    %rax,0x10(%rsp)
  401e2e:	jmp    401e58 <nx_list_reverse+0x68>
  401e30:	mov    0x8(%rsp),%rbx
  401e35:	mov    %rbx,%rdi
  401e38:	mov    %rbp,%rsi
  401e3b:	mov    %r14,%rdx
  401e3e:	callq  4039c0 <nx_rt_rebuild2_c1_k0>
  401e43:	mov    %rax,%r14
  401e46:	mov    %rbx,%rdi
  401e49:	xor    %esi,%esi
  401e4b:	callq  4032f0 <nx_rt_fast_field>
  401e50:	mov    0x10(%rsp),%rsi
  401e55:	mov    %rax,%rbp
  401e58:	mov    %rbp,%rax
  401e5b:	shr    $0x28,%rax
  401e5f:	cmp    $0x1,%ax
  401e63:	jne    402041 <nx_list_reverse+0x251>
  401e69:	mov    %rbp,%r13
  401e6c:	and    %r12,%r13
  401e6f:	test   %rbp,%rbp
  401e72:	js     401ea0 <nx_list_reverse+0xb0>
  401e74:	cmp    $0x3108180,%r13
  401e7b:	jb     401e30 <nx_list_reverse+0x40>
  401e7d:	lea    (%r15,%r13,8),%rbx
  401e81:	mov    (%r15,%r13,8),%r12
  401e85:	mov    0x8(%r15,%r13,8),%rbp
  401e8a:	lea    (%r15,%r13,8),%rdi
  401e8e:	add    $0x8,%rdi
  401e92:	jmpq   401f1c <nx_list_reverse+0x12c>
  401e97:	nopw   0x0(%rax,%rax,1)
  401ea0:	mov    (%r15,%r13,8),%rbx
  401ea4:	mov    %ebx,%eax
  401ea6:	and    $0xffffff,%eax
  401eab:	cmp    $0x1,%eax
  401eae:	jne    401e30 <nx_list_reverse+0x40>
  401eb0:	mov    %rbx,%rax
  401eb3:	shr    $0x1f,%rax
  401eb7:	cmp    $0x62102,%rax
  401ebd:	jbe    401e30 <nx_list_reverse+0x40>
  401ec3:	shr    $0x18,%rbx
  401ec7:	lea    (%r15,%rbx,8),%rax
  401ecb:	mov    %rax,(%rsp)
  401ecf:	mov    (%r15,%rbx,8),%r12
  401ed3:	mov    0x8(%r15,%rbx,8),%rbp
  401ed8:	lea    0x8(%r15,%rbx,8),%rdi
  401edd:	mov    (%rsi),%rax
  401ee0:	mov    %rax,(%r15,%r13,8)
  401ee4:	mov    %r13,(%rsi)
  401ee7:	mov    0x100(%rsi),%rax
  401eee:	inc    %rax
  401ef1:	mov    %rax,0x100(%rsi)
  401ef8:	cmp    $0x8000,%rax
  401efe:	jb     401f15 <nx_list_reverse+0x125>
  401f00:	mov    %rdi,%r13
  401f03:	mov    0x8(%rsp),%rdi
  401f08:	callq  401c36 <nx_rt_ir_hand0>
  401f0d:	mov    %r13,%rdi
  401f10:	mov    0x10(%rsp),%rsi
  401f15:	mov    %rbx,%r13
  401f18:	mov    (%rsp),%rbx
  401f1c:	mov    %r12,%rax
  401f1f:	movabs $0xff00000000000000,%rcx
  401f29:	and    %rcx,%rax
  401f2c:	movabs $0x200000000000000,%rcx
  401f36:	cmp    %rcx,%rax
  401f39:	jne    401f9c <nx_list_reverse+0x1ac>
  401f3b:	mov    (%rsi),%rax
  401f3e:	test   %rax,%rax
  401f41:	je     401f57 <nx_list_reverse+0x167>
  401f43:	lea    (%r15,%rax,8),%rcx
  401f47:	mov    (%r15,%rax,8),%rdx
  401f4b:	mov    %rdx,(%rsi)
  401f4e:	decq   0x100(%rsi)
  401f55:	jmp    401f72 <nx_list_reverse+0x182>
  401f57:	mov    %rdi,(%rsp)
  401f5b:	mov    0x8(%rsp),%rdi
  401f60:	callq  401c25 <nx_rt_ir_alloc0>
  401f65:	mov    (%rsp),%rdi
  401f69:	mov    0x10(%rsp),%rsi
  401f6e:	lea    (%r15,%rax,8),%rcx
  401f72:	mov    %r12,%rdx
  401f75:	shl    $0x18,%rdx
  401f79:	inc    %rdx
  401f7c:	mov    %rdx,(%rcx)
  401f7f:	movabs $0x2ffff0000000000,%rcx
  401f89:	and    %rcx,%r12
  401f8c:	movabs $0x8000000000000000,%rcx
  401f96:	or     %rcx,%rax
  401f99:	or     %rax,%r12
  401f9c:	mov    %r14,%rax
  401f9f:	movabs $0xff00000000000000,%rcx
  401fa9:	and    %rcx,%rax
  401fac:	movabs $0x200000000000000,%rcx
  401fb6:	cmp    %rcx,%rax
  401fb9:	jne    40201c <nx_list_reverse+0x22c>
  401fbb:	mov    (%rsi),%rax
  401fbe:	test   %rax,%rax
  401fc1:	je     401fd7 <nx_list_reverse+0x1e7>
  401fc3:	lea    (%r15,%rax,8),%rcx
  401fc7:	mov    (%r15,%rax,8),%rdx
  401fcb:	mov    %rdx,(%rsi)
  401fce:	decq   0x100(%rsi)
  401fd5:	jmp    401ff2 <nx_list_reverse+0x202>
  401fd7:	mov    %rdi,(%rsp)
  401fdb:	mov    0x8(%rsp),%rdi
  401fe0:	callq  401c25 <nx_rt_ir_alloc0>
  401fe5:	mov    (%rsp),%rdi
  401fe9:	mov    0x10(%rsp),%rsi
  401fee:	lea    (%r15,%rax,8),%rcx
  401ff2:	mov    %r14,%rdx
  401ff5:	shl    $0x18,%rdx
  401ff9:	inc    %rdx
  401ffc:	mov    %rdx,(%rcx)
  401fff:	movabs $0x2ffff0000000000,%rcx
  402009:	and    %rcx,%r14
  40200c:	movabs $0x8000000000000000,%rcx
  402016:	or     %rcx,%r14
  402019:	or     %rax,%r14
  40201c:	mov    %r12,(%rbx)
  40201f:	mov    %r14,(%rdi)
  402022:	movabs $0x200010000000000,%rax
  40202c:	or     %rax,%r13
  40202f:	mov    %r13,%r14
  402032:	movabs $0xffffffffff,%r12
  40203c:	jmpq   401e58 <nx_list_reverse+0x68>
  402041:	movzwl %ax,%eax
  402044:	test   %eax,%eax
  402046:	jne    40205a <nx_list_reverse+0x26a>
  402048:	mov    %r14,%rax
  40204b:	add    $0x18,%rsp
  40204f:	pop    %rbx
  402050:	pop    %r12
  402052:	pop    %r13
  402054:	pop    %r14
  402056:	pop    %r15
  402058:	pop    %rbp
  402059:	retq   
  40205a:	mov    0x8(%rsp),%rdi
  40205f:	mov    $0x1,%esi
  402064:	add    $0x18,%rsp
  402068:	pop    %rbx
  402069:	pop    %r12
  40206b:	pop    %r13
  40206d:	pop    %r14
  40206f:	pop    %r15
  402071:	pop    %rbp
  402072:	jmpq   402af0 <nx_rt_fail>

Disassembly of section .fini:
