
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401870 <nx_list_reverse>:
  401870:	push   %r15
  401872:	push   %r14
  401874:	push   %rbx
  401875:	mov    %rdx,%r14
  401878:	mov    %rsi,%r15
  40187b:	mov    %rdi,%rbx
  40187e:	xchg   %ax,%ax
  401880:	mov    %rbx,%rdi
  401883:	mov    %r15,%rsi
  401886:	callq  4026b0 <nx_rt_fast_id>
  40188b:	cmp    $0x1,%eax
  40188e:	jne    4018b7 <nx_list_reverse+0x47>
  401890:	mov    %rbx,%rdi
  401893:	mov    %r15,%rsi
  401896:	mov    $0x1,%edx
  40189b:	xor    %ecx,%ecx
  40189d:	mov    %r14,%r8
  4018a0:	callq  402980 <nx_rt_rebuild2>
  4018a5:	mov    %rax,%r14
  4018a8:	mov    %rbx,%rdi
  4018ab:	xor    %esi,%esi
  4018ad:	callq  402960 <nx_rt_fast_field>
  4018b2:	mov    %rax,%r15
  4018b5:	jmp    401880 <nx_list_reverse+0x10>
  4018b7:	test   %eax,%eax
  4018b9:	jne    4018c4 <nx_list_reverse+0x54>
  4018bb:	mov    %r14,%rax
  4018be:	pop    %rbx
  4018bf:	pop    %r14
  4018c1:	pop    %r15
  4018c3:	retq   
  4018c4:	mov    %rbx,%rdi
  4018c7:	mov    $0x1,%esi
  4018cc:	pop    %rbx
  4018cd:	pop    %r14
  4018cf:	pop    %r15
  4018d1:	jmpq   4021b0 <nx_rt_fail>

Disassembly of section .fini:
