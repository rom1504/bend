
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004032f0 <nx_rt_fast_field>:
  4032f0:	mov    %esi,%ecx
  4032f2:	mov    $0xfffffffe,%eax
  4032f7:	rol    %cl,%eax
  4032f9:	add    $0x2,%rcx
  4032fd:	and    %eax,0x20(%rdi)
  403300:	mov    (%rdi,%rcx,8),%rax
  403304:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  40330c:	retq   

Disassembly of section .fini:
