
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402820 <nx_rt_fast_id>:
  402820:	shr    $0x28,%rsi
  402824:	movzwl %si,%eax
  402827:	retq   

Disassembly of section .fini:
