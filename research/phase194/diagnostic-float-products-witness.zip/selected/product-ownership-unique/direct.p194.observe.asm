  40861f:	push   %rbp
  408620:	mov    %rsp,%rbp
  408623:	sub    $0x920,%rsp
  40862a:	mov    %r12,-0x10(%rbp)
  40862e:	mov    %rbx,-0x8(%rbp)
  408632:	mov    %r13,-0x18(%rbp)
  408636:	mov    %rdi,%rax
  408639:	mov    %rax,%r12
  40863c:	mov    %rsi,%rax
  40863f:	mov    %rax,%rbx
  408642:	mov    %r12,%rdi
  408645:	mov    %rbx,%rsi
  408648:	movabs $0x0,%rdx
  408652:	movabs $0x1,%rcx
  40865c:	mov    %ecx,%ecx
  40865e:	xor    %eax,%eax
  408660:	callq  41b170 <p118_rt_borrow_scalar_safe>
  408665:	mov    %rax,%rdi
  408668:	cmp    $0x0,%rdi
  40866f:	je     4086ad <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x8e>
  408675:	mov    %r12,%rdi
  408678:	mov    %rbx,%rsi
  40867b:	xor    %eax,%eax
  40867d:	callq  40843b <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_112_49_57_52_46_111_98_115_101_114_118_101_>
  408682:	mov    %rax,%r13
  408685:	mov    %r12,%rdi
  408688:	mov    %rbx,%rsi
  40868b:	xor    %eax,%eax
  40868d:	callq  414d20 <p111_rt_sink>
  408692:	mov    %rax,-0x8a0(%rbp)
  408699:	mov    %r13,%rax
  40869c:	mov    -0x10(%rbp),%r12
  4086a0:	mov    -0x8(%rbp),%rbx
  4086a4:	mov    -0x18(%rbp),%r13
  4086a8:	mov    %rbp,%rsp
  4086ab:	pop    %rbp
  4086ac:	retq   
  4086ad:	mov    %r12,%rdi
  4086b0:	mov    %rbx,%rsi
  4086b3:	xor    %eax,%eax
  4086b5:	callq  408358 <p113d_FID_36_112_49_50_56_98_111_114_114_111_119_46_111_119_110_101_100_46_112_49_57_52_46_111_98_115_101_114_118_101_>
  4086ba:	mov    %rax,%rdi
  4086bd:	mov    %rdi,%rax
  4086c0:	mov    -0x10(%rbp),%r12
  4086c4:	mov    -0x8(%rbp),%rbx
  4086c8:	mov    -0x18(%rbp),%r13
  4086cc:	mov    %rbp,%rsp
  4086cf:	pop    %rbp
  4086d0:	retq   
