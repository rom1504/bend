
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402510 <nx_rt_take2>:
  402510:	push   %r13
  402512:	push   %r12
  402514:	sub    $0x8,%rsp
  402518:	cmpb   $0x0,0x4c61(%rip)        # 407180 <nx_active>
  40251f:	je     40252d <nx_rt_take2+0x1d>
  402521:	lea    0x4c78(%rip),%rax        # 4071a0 <nx_context>
  402528:	cmp    %rax,%rdi
  40252b:	je     402540 <nx_rt_take2+0x30>
  40252d:	lea    0x1aff(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402534:	callq  4019b0 <err_fail>
  402539:	nopl   0x0(%rax)
  402540:	mov    0x4c7a(%rip),%eax        # 4071c0 <nx_context+0x20>
  402546:	mov    0x4c53(%rip),%rdi        # 4071a0 <nx_context>
  40254d:	test   %eax,%eax
  40254f:	jne    402689 <nx_rt_take2+0x179>
  402555:	mov    %rsi,%r12
  402558:	callq  401ae0 <nx_id.isra.0>
  40255d:	and    $0xfffffffd,%eax
  402560:	cmp    $0x1,%eax
  402563:	jne    40267d <nx_rt_take2+0x16d>
  402569:	mov    0x4c30(%rip),%rdi        # 4071a0 <nx_context>
  402570:	mov    0x4c31(%rip),%rsi        # 4071a8 <nx_context+0x8>
  402577:	movabs $0xffffffffff,%rax
  402581:	and    %r12,%rax
  402584:	lea    0x0(,%rax,8),%rcx
  40258c:	lea    (%rdi,%rcx,1),%rdx
  402590:	test   %r12,%r12
  402593:	js     402600 <nx_rt_take2+0xf0>
  402595:	mov    (%rdx),%rdx
  402598:	mov    %rdx,0x4c11(%rip)        # 4071b0 <nx_context+0x10>
  40259f:	mov    0x8(%rdi,%rcx,1),%rdx
  4025a4:	mov    %rdx,0x4c0d(%rip)        # 4071b8 <nx_context+0x18>
  4025ab:	cmp    $0x310817f,%rax
  4025b1:	ja     4025d0 <nx_rt_take2+0xc0>
  4025b3:	movl   $0x3,0x4c03(%rip)        # 4071c0 <nx_context+0x20>
  4025bd:	add    $0x8,%rsp
  4025c1:	xor    %eax,%eax
  4025c3:	pop    %r12
  4025c5:	pop    %r13
  4025c7:	retq   
  4025c8:	nopl   0x0(%rax,%rax,1)
  4025d0:	mov    0x8(%rsi),%rdx
  4025d4:	mov    %rdx,(%rdi,%rax,8)
  4025d8:	mov    0x4bfa(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4025de:	mov    %rax,0x8(%rsi)
  4025e2:	mov    0x108(%rsi),%rax
  4025e9:	add    $0x2,%rax
  4025ed:	mov    %rax,0x108(%rsi)
  4025f4:	cmp    %rdx,%rax
  4025f7:	jb     4025b3 <nx_rt_take2+0xa3>
  4025f9:	jmpq   401567 <nx_rt_take2.cold>
  4025fe:	xchg   %ax,%ax
  402600:	mov    0x4(%rdx),%ecx
  402603:	mov    (%rdx),%r8d
  402606:	shl    $0x20,%rcx
  40260a:	or     %r8,%rcx
  40260d:	mov    %rcx,%r13
  402610:	and    $0xffffff,%ecx
  402616:	shr    $0x18,%r13
  40261a:	lea    0x0(,%r13,8),%r8
  402622:	lea    (%rdi,%r8,1),%r9
  402626:	lea    0x8(%rdi,%r8,1),%r8
  40262b:	cmp    $0x1,%rcx
  40262f:	jne    401582 <nx_rt_take2.cold+0x1b>
  402635:	mov    (%rdx),%ecx
  402637:	mov    (%r9),%rcx
  40263a:	mov    %rcx,0x4b6f(%rip)        # 4071b0 <nx_context+0x10>
  402641:	mov    (%r8),%rcx
  402644:	mov    %rcx,0x4b6d(%rip)        # 4071b8 <nx_context+0x18>
  40264b:	mov    (%rsi),%rcx
  40264e:	mov    %rcx,(%rdx)
  402651:	mov    0x4b81(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402657:	mov    %rax,(%rsi)
  40265a:	mov    0x100(%rsi),%rax
  402661:	add    $0x1,%rax
  402665:	mov    %rax,0x100(%rsi)
  40266c:	cmp    %rdx,%rax
  40266f:	jae    401576 <nx_rt_take2.cold+0xf>
  402675:	mov    %r13,%rax
  402678:	jmpq   4025ab <nx_rt_take2+0x9b>
  40267d:	lea    0x1c94(%rip),%rdi        # 404318 <_IO_stdin_used+0x318>
  402684:	callq  4019b0 <err_fail>
  402689:	lea    0x1c60(%rip),%rdi        # 4042f0 <_IO_stdin_used+0x2f0>
  402690:	callq  4019b0 <err_fail>

Disassembly of section .fini:
