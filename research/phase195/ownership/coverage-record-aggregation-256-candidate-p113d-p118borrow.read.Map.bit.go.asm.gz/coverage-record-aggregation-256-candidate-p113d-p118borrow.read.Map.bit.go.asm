
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/coverage-record-aggregation-256/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000406a94 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>:
  406a94:	push   %rbp
  406a95:	mov    %rsp,%rbp
  406a98:	sub    $0xa30,%rsp
  406a9f:	mov    %r12,-0x10(%rbp)
  406aa3:	mov    %rbx,-0x8(%rbp)
  406aa7:	mov    %r13,-0x18(%rbp)
  406aab:	mov    %r14,-0x20(%rbp)
  406aaf:	mov    %rdi,%rax
  406ab2:	mov    %rax,%r12
  406ab5:	mov    %rsi,%rax
  406ab8:	mov    %rax,%rdi
  406abb:	mov    %rdx,%rax
  406abe:	mov    %rax,%rbx
  406ac1:	mov    %rcx,%rax
  406ac4:	mov    %rax,%r13
  406ac7:	mov    %rdi,%rsi
  406aca:	shr    $0x28,%rsi
  406ace:	and    $0xffff,%rsi
  406ad5:	movabs $0x18,%r11
  406adf:	cmp    %r11,%rsi
  406ae2:	jne    406b2c <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x98>
  406ae8:	mov    %r12,%rdi
  406aeb:	movabs $0x1,%rsi
  406af5:	mov    %esi,%esi
  406af7:	lea    -0x840(%rbp),%rdx
  406afe:	movabs $0x0,%rcx
  406b08:	mov    %ecx,%ecx
  406b0a:	xor    %eax,%eax
  406b0c:	callq  44bde0 <p111_rt_special_ctor>
  406b11:	mov    %rax,%rdi
  406b14:	mov    %rdi,%rax
  406b17:	mov    -0x10(%rbp),%r12
  406b1b:	mov    -0x8(%rbp),%rbx
  406b1f:	mov    -0x18(%rbp),%r13
  406b23:	mov    -0x20(%rbp),%r14
  406b27:	mov    %rbp,%rsp
  406b2a:	pop    %rbp
  406b2b:	retq   
  406b2c:	mov    %rdi,%rsi
  406b2f:	shr    $0x28,%rsi
  406b33:	and    $0xffff,%rsi
  406b3a:	movabs $0x19,%r11
  406b44:	cmp    %r11,%rsi
  406b47:	jne    406e02 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x36e>
  406b4d:	mov    %rdi,%rsi
  406b50:	shr    $0x38,%rsi
  406b54:	and    $0x7f,%rsi
  406b5b:	mov    %rsi,%rdx
  406b5e:	cmp    $0x2,%rdx
  406b65:	sete   %dl
  406b68:	movzbl %dl,%edx
  406b6b:	mov    %rdi,%rsi
  406b6e:	shr    $0x28,%rsi
  406b72:	and    $0xffff,%rsi
  406b79:	movabs $0x19,%r11
  406b83:	cmp    %r11,%rsi
  406b86:	sete   %sil
  406b8a:	movzbl %sil,%esi
  406b8e:	and    %edx,%esi
  406b90:	mov    %rsi,%r10
  406b93:	test   %r10d,%r10d
  406b96:	je     406c13 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x17f>
  406b9c:	mov    (%r12),%rsi
  406ba0:	movabs $0xffffffffff,%r11
  406baa:	mov    %rdi,%rdx
  406bad:	and    %r11,%rdx
  406bb0:	shr    $0x3f,%rdi
  406bb4:	cmp    $0x0,%rdi
  406bbb:	je     406bdc <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x148>
  406bc1:	mov    (%rsi,%rdx,8),%r8d
  406bc5:	mov    0x4(%rsi,%rdx,8),%edi
  406bc9:	shl    $0x20,%rdi
  406bcd:	or     %r8,%rdi
  406bd0:	mov    %rdi,%rdx
  406bd3:	shr    $0x18,%rdx
  406bd7:	jmpq   406bdc <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x148>
  406bdc:	mov    %rdx,%rdi
  406bdf:	shl    $0x3,%rdi
  406be3:	mov    %rdi,%r11
  406be6:	mov    %rsi,%rdi
  406be9:	add    %r11,%rdi
  406bec:	mov    (%rdi),%rsi
  406bef:	lea    -0x840(%rbp),%r10
  406bf6:	mov    %rsi,%r11
  406bf9:	mov    %r11,(%r10)
  406bfc:	mov    0x8(%rdi),%rdi
  406c00:	lea    -0x840(%rbp),%r10
  406c07:	mov    %rdi,%r11
  406c0a:	mov    %r11,0x8(%r10)
  406c0e:	jmpq   406c7a <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1e6>
  406c13:	mov    %r12,%r10
  406c16:	mov    %r10,0x28(%rsp)
  406c1b:	mov    %rdi,%r10
  406c1e:	mov    %r10,0x30(%rsp)
  406c23:	lea    -0x840(%rbp),%r10
  406c2a:	mov    %r10,0x38(%rsp)
  406c2f:	movabs $0x19,%r10
  406c39:	mov    %r10d,%r10d
  406c3c:	mov    %r10,0x40(%rsp)
  406c41:	movabs $0x2,%r10
  406c4b:	mov    %r10d,%r10d
  406c4e:	mov    %r10,0x48(%rsp)
  406c53:	mov    0x28(%rsp),%rdi
  406c58:	mov    0x30(%rsp),%rsi
  406c5d:	mov    0x38(%rsp),%rdx
  406c62:	mov    0x40(%rsp),%rcx
  406c67:	mov    0x48(%rsp),%r8
  406c6c:	xor    %eax,%eax
  406c6e:	callq  44f470 <p118_rt_borrow_fields>
  406c73:	mov    %rax,-0x968(%rbp)
  406c7a:	lea    -0x840(%rbp),%r10
  406c81:	mov    (%r10),%r14
  406c84:	lea    -0x840(%rbp),%r10
  406c8b:	mov    0x8(%r10),%rdi
  406c8f:	cmp    $0x0,%rbx
  406c96:	jne    406df6 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x362>
  406c9c:	cmp    %r14,%r14
  406c9f:	jne    406dba <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x326>
  406ca5:	cmp    $0x0,%r13
  406cac:	jne    406cf6 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x262>
  406cb2:	mov    %r12,%rdi
  406cb5:	movabs $0x2,%rsi
  406cbf:	mov    %esi,%esi
  406cc1:	lea    -0x840(%rbp),%rdx
  406cc8:	movabs $0x0,%rcx
  406cd2:	mov    %ecx,%ecx
  406cd4:	xor    %eax,%eax
  406cd6:	callq  44bde0 <p111_rt_special_ctor>
  406cdb:	mov    %rax,%rdi
  406cde:	mov    %rdi,%rax
  406ce1:	mov    -0x10(%rbp),%r12
  406ce5:	mov    -0x8(%rbp),%rbx
  406ce9:	mov    -0x18(%rbp),%r13
  406ced:	mov    -0x20(%rbp),%r14
  406cf1:	mov    %rbp,%rsp
  406cf4:	pop    %rbp
  406cf5:	retq   
  406cf6:	mov    %r13,%rdi
  406cf9:	sub    $0x1,%rdi
  406d00:	lea    -0x840(%rbp),%r10
  406d07:	movabs $0x1f,%r11
  406d11:	mov    %r11,(%r10)
  406d14:	lea    -0x840(%rbp),%r10
  406d1b:	mov    %rdi,%r11
  406d1e:	mov    %r11,0x8(%r10)
  406d22:	mov    %r12,%rdi
  406d25:	movabs $0x3f,%rsi
  406d2f:	mov    %esi,%esi
  406d31:	lea    -0x840(%rbp),%rdx
  406d38:	movabs $0x2,%rcx
  406d42:	mov    %ecx,%ecx
  406d44:	xor    %eax,%eax
  406d46:	callq  44ac00 <p111_rt_op>
  406d4b:	mov    %rax,%rdi
  406d4e:	mov    %r14d,%r14d
  406d51:	mov    %rdi,%rsi
  406d54:	cmp    $0x20,%rdi
  406d5b:	setb   %dil
  406d5f:	movzbl %dil,%edi
  406d63:	mov    %rdi,%r10
  406d66:	test   %r10d,%r10d
  406d69:	je     406d82 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x2ee>
  406d6f:	mov    %rsi,%r11
  406d72:	mov    %r14,%rdi
  406d75:	mov    %r11d,%ecx
  406d78:	shr    %cl,%rdi
  406d7b:	mov    %edi,%edi
  406d7d:	jmpq   406d8c <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x2f8>
  406d82:	movabs $0x0,%rdi
  406d8c:	and    $0x1,%rdi
  406d93:	cmp    $0x0,%rdi
  406d9a:	setne  %dil
  406d9e:	movzbl %dil,%edi
  406da2:	mov    %rdi,%rax
  406da5:	mov    -0x10(%rbp),%r12
  406da9:	mov    -0x8(%rbp),%rbx
  406dad:	mov    -0x18(%rbp),%r13
  406db1:	mov    -0x20(%rbp),%r14
  406db5:	mov    %rbp,%rsp
  406db8:	pop    %rbp
  406db9:	retq   
  406dba:	mov    %r12,%rdi
  406dbd:	movabs $0x4,%rsi
  406dc7:	mov    %esi,%esi
  406dc9:	xor    %eax,%eax
  406dcb:	callq  44abe0 <p111_rt_fail>
  406dd0:	mov    %rax,-0x9a0(%rbp)
  406dd7:	movabs $0x0,%rax
  406de1:	mov    -0x10(%rbp),%r12
  406de5:	mov    -0x8(%rbp),%rbx
  406de9:	mov    -0x18(%rbp),%r13
  406ded:	mov    -0x20(%rbp),%r14
  406df1:	mov    %rbp,%rsp
  406df4:	pop    %rbp
  406df5:	retq   
  406df6:	sub    $0x1,%rbx
  406dfd:	jmpq   406ac7 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x33>
  406e02:	mov    %r12,%rdi
  406e05:	movabs $0x4,%rsi
  406e0f:	mov    %esi,%esi
  406e11:	xor    %eax,%eax
  406e13:	callq  44abe0 <p111_rt_fail>
  406e18:	mov    %rax,-0x9a0(%rbp)
  406e1f:	movabs $0x0,%rax
  406e29:	mov    -0x10(%rbp),%r12
  406e2d:	mov    -0x8(%rbp),%rbx
  406e31:	mov    -0x18(%rbp),%r13
  406e35:	mov    -0x20(%rbp),%r14
  406e39:	mov    %rbp,%rsp
  406e3c:	pop    %rbp
  406e3d:	retq   

Disassembly of section .fini:
