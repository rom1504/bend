0000000000406a70 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>:
  406a70:	endbr64 
  406a74:	cs cs cs cs cs push rbp
  406a7a:	cs cs cs mov rbp,rsp
  406a80:	sub    rsp,0x818
  406a87:	push   rbx
  406a88:	push   r12
  406a8a:	push   r13
  406a8c:	push   r14
  406a8e:	push   r15
  406a90:	mov    r15,rdx
  406a93:	mov    rax,rsi
  406a96:	shr    rax,0x28
  406a9a:	mov    rcx,rax
  406a9d:	and    rcx,0xffff
  406aa4:	cmp    rcx,0xa5
  406aab:	sete   dl
  406aae:	movzx  edx,dl
  406ab1:	mov    r8,r15
  406ab4:	shr    r8,0x28
  406ab8:	mov    r12,r8
  406abb:	and    r12,0x7fffff
  406ac2:	movabs r9,0xffffffffff
  406acc:	mov    rbx,r15
  406acf:	and    rbx,r9
  406ad2:	mov    QWORD PTR [rbp-0x10],rbx
  406ad6:	mov    r13,r8
  406ad9:	and    r13,0xffff
  406ae0:	cmp    edx,0x0
  406ae3:	jne    406be5 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x175>
  406ae9:	cmp    rcx,0xa4
  406af0:	je     406b06 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x96>
  406af2:	mov    esi,0x4
  406af7:	call   414bf0 <p111_rt_fail>
  406afc:	mov    eax,0x0
  406b01:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406b06:	and    rax,0x7fffff
  406b0c:	cmp    rax,0x100a4
  406b12:	je     406b2e <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xbe>
  406b14:	lea    rdx,[rbp-0x810]
  406b1b:	mov    rax,rsi
  406b1e:	mov    r14,rdi
  406b21:	call   419f80 <p125_rt_take1>
  406b26:	mov    rsi,r15
  406b29:	mov    rdi,r14
  406b2c:	jmp    406b48 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xd8>
  406b2e:	mov    rax,rsi
  406b31:	mov    rsi,r15
  406b34:	movabs rcx,0xffffffffff
  406b3e:	and    rax,rcx
  406b41:	mov    QWORD PTR [rbp-0x810],rax
  406b48:	cmp    r13,0xa5
  406b4f:	je     406b9b <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x12b>
  406b51:	cmp    r13,0xa4
  406b58:	je     406b6e <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0xfe>
  406b5a:	mov    esi,0x4
  406b5f:	call   414bf0 <p111_rt_fail>
  406b64:	mov    eax,0x0
  406b69:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406b6e:	cmp    r12,0x100a4
  406b75:	je     406b85 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x115>
  406b77:	lea    rdx,[rbp-0x810]
  406b7e:	call   419f80 <p125_rt_take1>
  406b83:	jmp    406b8c <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x11c>
  406b85:	mov    QWORD PTR [rbp-0x810],rbx
  406b8c:	movabs rax,0x100a40000000000
  406b96:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406b9b:	cs cs cs lea rdx,cs:[rbp-0x810]
  406ba6:	cs mov r14,rsi
  406baa:	mov    rbx,rdi
  406bad:	call   41a200 <p125_rt_take2>
  406bb2:	mov    rdi,rbx
  406bb5:	mov    rsi,QWORD PTR [rbp-0x810]
  406bbc:	mov    r12,QWORD PTR [rbp-0x808]
  406bc3:	mov    rbx,rdi
  406bc6:	call   414460 <p111_rt_sink>
  406bcb:	mov    rsi,r12
  406bce:	mov    rdi,rbx
  406bd1:	call   414460 <p111_rt_sink>
  406bd6:	movabs rax,0x100a40000000000
  406be0:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406be5:	mov    r14,r15
  406be8:	lea    rdx,[rbp-0x810]
  406bef:	mov    rbx,rdi
  406bf2:	call   41a200 <p125_rt_take2>
  406bf7:	mov    rsi,r14
  406bfa:	mov    rdi,rbx
  406bfd:	mov    rbx,QWORD PTR [rbp-0x810]
  406c04:	mov    r14,QWORD PTR [rbp-0x808]
  406c0b:	cmp    r13,0xa5
  406c12:	je     406c8d <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x21d>
  406c14:	mov    r15,rsi
  406c17:	mov    rsi,rbx
  406c1a:	mov    rbx,rdi
  406c1d:	call   414460 <p111_rt_sink>
  406c22:	mov    rsi,r15
  406c25:	mov    rdi,rbx
  406c28:	mov    rbx,QWORD PTR [rbp-0x10]
  406c2c:	mov    r15,rsi
  406c2f:	mov    rsi,r14
  406c32:	mov    r14,rdi
  406c35:	call   414460 <p111_rt_sink>
  406c3a:	mov    rsi,r15
  406c3d:	mov    rdi,r14
  406c40:	cmp    r13,0xa4
  406c47:	je     406c5d <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x1ed>
  406c49:	mov    esi,0x4
  406c4e:	call   414bf0 <p111_rt_fail>
  406c53:	mov    eax,0x0
  406c58:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406c5d:	nop    DWORD PTR [rax]
  406c60:	cmp    r12,0x100a4
  406c67:	je     406c77 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x207>
  406c69:	lea    rdx,[rbp-0x810]
  406c70:	call   419f80 <p125_rt_take1>
  406c75:	jmp    406c7e <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x20e>
  406c77:	mov    QWORD PTR [rbp-0x810],rbx
  406c7e:	movabs rax,0x100a40000000000
  406c88:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406c8d:	mov    r13,r14
  406c90:	lea    rdx,[rbp-0x810]
  406c97:	mov    r12,rdi
  406c9a:	call   41a200 <p125_rt_take2>
  406c9f:	mov    rdi,r12
  406ca2:	mov    rcx,QWORD PTR [rbp-0x810]
  406ca9:	mov    r12,QWORD PTR [rbp-0x808]
  406cb0:	mov    QWORD PTR [rbp-0x810],rbx
  406cb7:	mov    QWORD PTR [rbp-0x808],rcx
  406cbe:	mov    r9,QWORD PTR [rdi+0x8]
  406cc2:	mov    rax,QWORD PTR [r9+0x8]
  406cc6:	cmp    rax,0x0
  406cca:	jne    406ce8 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x278>
  406ccc:	lea    rdx,[rbp-0x810]
  406cd3:	mov    esi,0xa5
  406cd8:	mov    rbx,rdi
  406cdb:	call   41a110 <p125_rt_ctor2>
  406ce0:	mov    rdi,rbx
  406ce3:	mov    rbx,rax
  406ce6:	jmp    406d2a <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x2ba>
  406ce8:	cs cs cs mov rdx,QWORD PTR cs:[rdi]
  406cef:	cs mov rsi,rax
  406cf3:	shl    rsi,0x3
  406cf7:	mov    r10,QWORD PTR [rdx+rsi*1]
  406cfb:	mov    r8,QWORD PTR [r9+0x108]
  406d02:	mov    QWORD PTR [r9+0x8],r10
  406d06:	sub    r8,0x2
  406d0a:	mov    QWORD PTR [r9+0x108],r8
  406d11:	mov    QWORD PTR [rdx+rsi*1],rbx
  406d15:	mov    QWORD PTR [rdx+rsi*1+0x8],rcx
  406d1a:	movabs rcx,0x200a50000000000
  406d24:	mov    rbx,rax
  406d27:	or     rbx,rcx
  406d2a:	mov    QWORD PTR [rbp-0x810],r13
  406d31:	mov    QWORD PTR [rbp-0x808],r12
  406d38:	mov    r8,QWORD PTR [rdi+0x8]
  406d3c:	mov    rax,QWORD PTR [r8+0x8]
  406d40:	cmp    rax,0x0
  406d44:	jne    406d62 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x2f2>
  406d46:	lea    rdx,[rbp-0x810]
  406d4d:	mov    esi,0xa5
  406d52:	mov    r12,rdi
  406d55:	call   41a110 <p125_rt_ctor2>
  406d5a:	mov    rdi,r12
  406d5d:	mov    rcx,rax
  406d60:	jmp    406d9c <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x32c>
  406d62:	mov    rcx,QWORD PTR [rdi]
  406d65:	mov    rdx,rax
  406d68:	shl    rdx,0x3
  406d6c:	mov    r9,QWORD PTR [rcx+rdx*1]
  406d70:	mov    rsi,QWORD PTR [r8+0x108]
  406d77:	mov    QWORD PTR [r8+0x8],r9
  406d7b:	sub    rsi,0x2
  406d7f:	mov    QWORD PTR [r8+0x108],rsi
  406d86:	mov    QWORD PTR [rcx+rdx*1],r13
  406d8a:	mov    QWORD PTR [rcx+rdx*1+0x8],r12
  406d8f:	movabs rcx,0x200a50000000000
  406d99:	or     rcx,rax
  406d9c:	mov    QWORD PTR [rbp-0x810],rbx
  406da3:	mov    QWORD PTR [rbp-0x808],rcx
  406daa:	mov    r8,QWORD PTR [rdi+0x8]
  406dae:	mov    rax,QWORD PTR [r8+0x8]
  406db2:	cmp    rax,0x0
  406db6:	jne    406dcb <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x35b>
  406db8:	lea    rdx,[rbp-0x810]
  406dbf:	mov    esi,0xa5
  406dc4:	call   41a110 <p125_rt_ctor2>
  406dc9:	jmp    406e05 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_+0x395>
  406dcb:	mov    rdx,QWORD PTR [rdi]
  406dce:	mov    rsi,rax
  406dd1:	shl    rsi,0x3
  406dd5:	mov    r9,QWORD PTR [rdx+rsi*1]
  406dd9:	mov    rdi,QWORD PTR [r8+0x108]
  406de0:	mov    QWORD PTR [r8+0x8],r9
  406de4:	sub    rdi,0x2
  406de8:	mov    QWORD PTR [r8+0x108],rdi
  406def:	mov    QWORD PTR [rdx+rsi*1],rbx
  406df3:	mov    QWORD PTR [rdx+rsi*1+0x8],rcx
  406df8:	movabs rcx,0x200a50000000000
  406e02:	or     rax,rcx
  406e05:	pop    r15
  406e07:	pop    r14
  406e09:	pop    r13
  406e0b:	pop    r12
  406e0d:	pop    rbx
  406e0e:	leave  
  406e0f:	ret    

