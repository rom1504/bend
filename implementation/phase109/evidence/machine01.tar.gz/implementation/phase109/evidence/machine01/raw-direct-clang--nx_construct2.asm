
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401ca0 <nx_construct2>:
  401ca0:	push   %r12
  401ca2:	mov    %rcx,%rax
  401ca5:	push   %rbp
  401ca6:	shr    $0x38,%rax
  401caa:	lea    0x0(,%r9,8),%rbp
  401cb2:	push   %rbx
  401cb3:	and    $0x7f,%eax
  401cb6:	mov    %edx,%ebx
  401cb8:	lea    (%rdi,%rbp,1),%r12
  401cbc:	mov    %rcx,%rdx
  401cbf:	sub    $0x20,%rsp
  401cc3:	cmp    $0x2,%rax
  401cc7:	je     401d00 <nx_construct2+0x60>
  401cc9:	mov    %r8,%rax
  401ccc:	mov    %rdx,(%r12)
  401cd0:	lea    0x8(%rbp,%rdi,1),%rbp
  401cd5:	shr    $0x38,%rax
  401cd9:	and    $0x7f,%eax
  401cdc:	cmp    $0x2,%rax
  401ce0:	je     401d10 <nx_construct2+0x70>
  401ce2:	mov    %rbx,%rax
  401ce5:	mov    %r8,0x0(%rbp)
  401ce9:	add    $0x20,%rsp
  401ced:	shl    $0x28,%rax
  401cf1:	pop    %rbx
  401cf2:	pop    %rbp
  401cf3:	or     %r9,%rax
  401cf6:	pop    %r12
  401cf8:	bts    $0x39,%rax
  401cfd:	retq   
  401cfe:	xchg   %ax,%ax
  401d00:	test   %rcx,%rcx
  401d03:	js     401cc9 <nx_construct2+0x29>
  401d05:	jmpq   401410 <nx_construct2.cold>
  401d0a:	nopw   0x0(%rax,%rax,1)
  401d10:	test   %r8,%r8
  401d13:	js     401ce2 <nx_construct2+0x42>
  401d15:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
