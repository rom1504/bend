
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402230 <nx_rt_rebuild2>:
  402230:	push   %rbp
  402231:	push   %r14
  402233:	push   %rbx
  402234:	sub    $0x10,%rsp
  402238:	mov    %edx,%eax
  40223a:	mov    %rsi,%rdx
  40223d:	mov    %rdi,%r10
  402240:	mov    (%rdi),%rdi
  402243:	mov    0x8(%r10),%rsi
  402247:	movabs $0xffffffffff,%r11
  402251:	and    %rdx,%r11
  402254:	test   %rdx,%rdx
  402257:	js     402273 <nx_rt_rebuild2+0x43>
  402259:	movups (%rdi,%r11,8),%xmm0
  40225e:	movaps %xmm0,(%rsp)
  402262:	mov    %r11,%r9
  402265:	cmp    $0x310817f,%r9
  40226c:	jbe    4022ea <nx_rt_rebuild2+0xba>
  40226e:	jmpq   402307 <nx_rt_rebuild2+0xd7>
  402273:	mov    0x4(%rdi,%r11,8),%r9d
  402278:	mov    (%rdi,%r11,8),%r14d
  40227c:	mov    %r14d,%ebx
  40227f:	and    $0xffffff,%ebx
  402285:	cmp    $0x1,%rbx
  402289:	jne    40228f <nx_rt_rebuild2+0x5f>
  40228b:	mov    (%rdi,%r11,8),%ebp
  40228f:	shl    $0x20,%r9
  402293:	or     %r14,%r9
  402296:	shr    $0x18,%r9
  40229a:	movups (%rdi,%r9,8),%xmm0
  40229f:	movaps %xmm0,(%rsp)
  4022a3:	cmp    $0x1,%ebx
  4022a6:	jne    4023b5 <nx_rt_rebuild2+0x185>
  4022ac:	mov    (%rsi),%rdx
  4022af:	mov    %rdx,(%rdi,%r11,8)
  4022b3:	mov    %r11,(%rsi)
  4022b6:	mov    0x100(%rsi),%rdx
  4022bd:	inc    %rdx
  4022c0:	mov    %rdx,0x100(%rsi)
  4022c7:	cmpb   $0x1,0x1d232(%rip)        # 41f500 <KEEP_WORDS>
  4022ce:	jne    4023c6 <nx_rt_rebuild2+0x196>
  4022d4:	cmp    $0x8000,%rdx
  4022db:	jae    4023c6 <nx_rt_rebuild2+0x196>
  4022e1:	cmp    $0x310817f,%r9
  4022e8:	ja     402307 <nx_rt_rebuild2+0xd7>
  4022ea:	mov    0x8(%rsi),%r9
  4022ee:	test   %r9,%r9
  4022f1:	je     40239d <nx_rt_rebuild2+0x16d>
  4022f7:	mov    (%rdi,%r9,8),%rdx
  4022fb:	mov    %rdx,0x8(%rsi)
  4022ff:	addq   $0xfffffffffffffffe,0x108(%rsi)
  402307:	movabs $0xff00000000000000,%rbx
  402311:	mov    $0x1,%edx
  402316:	sub    %ecx,%edx
  402318:	mov    (%rsp,%rdx,8),%rdx
  40231c:	mov    %rdx,0x10(%r10)
  402320:	movq   $0xffffffffffffffff,0x18(%r10)
  402328:	movl   $0x1,0x20(%r10)
  402330:	mov    %ecx,%ecx
  402332:	mov    (%rsp,%rcx,8),%rdx
  402336:	mov    %rdx,%rcx
  402339:	shr    $0x38,%rcx
  40233d:	cmp    $0x2,%ecx
  402340:	je     402370 <nx_rt_rebuild2+0x140>
  402342:	mov    %rdx,(%rdi,%r9,8)
  402346:	and    %r8,%rbx
  402349:	movabs $0x200000000000000,%r10
  402353:	cmp    %r10,%rbx
  402356:	je     402385 <nx_rt_rebuild2+0x155>
  402358:	mov    %r8,0x8(%rdi,%r9,8)
  40235d:	shl    $0x28,%rax
  402361:	or     %r10,%rax
  402364:	or     %r9,%rax
  402367:	add    $0x10,%rsp
  40236b:	pop    %rbx
  40236c:	pop    %r14
  40236e:	pop    %rbp
  40236f:	retq   
  402370:	mov    $0x1,%ecx
  402375:	mov    %rax,%r10
  402378:	callq  401168 <rfc_wrap>
  40237d:	mov    %rax,%rdx
  402380:	mov    %r10,%rax
  402383:	jmp    402342 <nx_rt_rebuild2+0x112>
  402385:	mov    %r8,%rdx
  402388:	mov    $0x1,%ecx
  40238d:	mov    %rax,%rbx
  402390:	callq  401168 <rfc_wrap>
  402395:	mov    %rax,%r8
  402398:	mov    %rbx,%rax
  40239b:	jmp    402358 <nx_rt_rebuild2+0x128>
  40239d:	mov    $0x1,%edx
  4023a2:	mov    %rax,%rbx
  4023a5:	callq  401279 <heap_alloc_miss>
  4023aa:	mov    %rax,%r9
  4023ad:	mov    %rbx,%rax
  4023b0:	jmpq   402307 <nx_rt_rebuild2+0xd7>
  4023b5:	mov    %ecx,%ebx
  4023b7:	mov    %r9,%rcx
  4023ba:	callq  40157f <span_fade>
  4023bf:	mov    %ebx,%ecx
  4023c1:	jmpq   4022ea <nx_rt_rebuild2+0xba>
  4023c6:	xor    %edx,%edx
  4023c8:	callq  4011e8 <heap_hand>
  4023cd:	cmp    $0x310817f,%r9
  4023d4:	jbe    4022ea <nx_rt_rebuild2+0xba>
  4023da:	jmpq   402307 <nx_rt_rebuild2+0xd7>

Disassembly of section .fini:
