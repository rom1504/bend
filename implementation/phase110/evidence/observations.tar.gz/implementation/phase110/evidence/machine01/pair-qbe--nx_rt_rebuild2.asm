
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d10 <nx_rt_rebuild2>:
  402d10:	movabs $0xffffffffff,%r9
  402d1a:	push   %r14
  402d1c:	push   %r13
  402d1e:	and    %rsi,%r9
  402d21:	mov    %edx,%r13d
  402d24:	push   %r12
  402d26:	lea    0x0(,%r9,8),%rdx
  402d2e:	push   %rbp
  402d2f:	mov    %ecx,%ebp
  402d31:	push   %rbx
  402d32:	mov    %rdi,%rbx
  402d35:	sub    $0x20,%rsp
  402d39:	mov    (%rdi),%rdi
  402d3c:	mov    0x8(%rbx),%r12
  402d40:	lea    (%rdi,%rdx,1),%rax
  402d44:	test   %rsi,%rsi
  402d47:	js     402dc8 <nx_rt_rebuild2+0xb8>
  402d49:	mov    (%rax),%rax
  402d4c:	mov    %rax,0x10(%rsp)
  402d51:	mov    0x8(%rdi,%rdx,1),%rax
  402d56:	mov    %rax,0x18(%rsp)
  402d5b:	cmp    $0x310817f,%r9
  402d62:	jbe    402da0 <nx_rt_rebuild2+0x90>
  402d64:	mov    $0x1,%eax
  402d69:	mov    0x10(%rsp,%rbp,8),%rcx
  402d6e:	mov    %r13d,%edx
  402d71:	mov    %r12,%rsi
  402d74:	sub    %ebp,%eax
  402d76:	movq   $0xffffffffffffffff,0x18(%rbx)
  402d7e:	mov    0x10(%rsp,%rax,8),%rax
  402d83:	movl   $0x1,0x20(%rbx)
  402d8a:	mov    %rax,0x10(%rbx)
  402d8e:	add    $0x20,%rsp
  402d92:	pop    %rbx
  402d93:	pop    %rbp
  402d94:	pop    %r12
  402d96:	pop    %r13
  402d98:	pop    %r14
  402d9a:	jmpq   401fb0 <nx_construct2>
  402d9f:	nop
  402da0:	mov    0x8(%r12),%r9
  402da5:	test   %r9,%r9
  402da8:	je     401651 <nx_rt_rebuild2.cold>
  402dae:	mov    (%rdi,%r9,8),%rax
  402db2:	subq   $0x2,0x108(%r12)
  402dbb:	mov    %rax,0x8(%r12)
  402dc0:	jmp    402d64 <nx_rt_rebuild2+0x54>
  402dc2:	nopw   0x0(%rax,%rax,1)
  402dc8:	mov    0x4(%rax),%edx
  402dcb:	mov    (%rax),%ecx
  402dcd:	shl    $0x20,%rdx
  402dd1:	or     %rcx,%rdx
  402dd4:	mov    %rdx,%r14
  402dd7:	and    $0xffffff,%edx
  402ddd:	shr    $0x18,%r14
  402de1:	lea    0x0(,%r14,8),%r10
  402de9:	lea    (%rdi,%r10,1),%r11
  402ded:	lea    0x8(%rdi,%r10,1),%r10
  402df2:	cmp    $0x1,%rdx
  402df6:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402dfc:	mov    (%rax),%edx
  402dfe:	mov    (%r11),%rdx
  402e01:	mov    %rdx,0x10(%rsp)
  402e06:	mov    (%r10),%rdx
  402e09:	mov    %rdx,0x18(%rsp)
  402e0e:	mov    (%r12),%rdx
  402e12:	mov    %rdx,(%rax)
  402e15:	mov    0x100(%r12),%rax
  402e1d:	mov    0x3e3b5(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e23:	mov    %r9,(%r12)
  402e27:	add    $0x1,%rax
  402e2b:	mov    %rax,0x100(%r12)
  402e33:	cmp    %rdx,%rax
  402e36:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402e3c:	mov    %r14,%r9
  402e3f:	jmpq   402d5b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
