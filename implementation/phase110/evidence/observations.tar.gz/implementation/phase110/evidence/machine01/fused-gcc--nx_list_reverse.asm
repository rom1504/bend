
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	push   %r13
  401c02:	mov    %rdi,%r13
  401c05:	push   %r12
  401c07:	mov    %rdx,%r12
  401c0a:	push   %rbp
  401c0b:	mov    %rsi,%rbp
  401c0e:	jmp    401c3a <nx_list_reverse+0x3a>
  401c10:	cmp    $0x1,%eax
  401c13:	jne    401c58 <nx_list_reverse+0x58>
  401c15:	mov    %r12,%r8
  401c18:	mov    %rbp,%rsi
  401c1b:	xor    %ecx,%ecx
  401c1d:	mov    $0x1,%edx
  401c22:	mov    %r13,%rdi
  401c25:	callq  402d10 <nx_rt_rebuild2>
  401c2a:	xor    %esi,%esi
  401c2c:	mov    %r13,%rdi
  401c2f:	mov    %rax,%r12
  401c32:	callq  402cf0 <nx_rt_fast_field>
  401c37:	mov    %rax,%rbp
  401c3a:	mov    %rbp,%rsi
  401c3d:	mov    %r13,%rdi
  401c40:	callq  402a40 <nx_rt_fast_id>
  401c45:	test   %eax,%eax
  401c47:	jne    401c10 <nx_list_reverse+0x10>
  401c49:	mov    %r12,%rax
  401c4c:	pop    %rbp
  401c4d:	pop    %r12
  401c4f:	pop    %r13
  401c51:	retq   
  401c52:	nopw   0x0(%rax,%rax,1)
  401c58:	pop    %rbp
  401c59:	mov    %r13,%rdi
  401c5c:	pop    %r12
  401c5e:	mov    $0x1,%esi
  401c63:	pop    %r13
  401c65:	jmpq   402540 <nx_rt_fail>

Disassembly of section .fini:
