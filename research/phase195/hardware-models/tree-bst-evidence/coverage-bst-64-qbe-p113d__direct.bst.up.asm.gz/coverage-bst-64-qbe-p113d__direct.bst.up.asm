0000000000407930 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_>:
  407930:	endbr64 
  407934:	push   rbp
  407935:	mov    rbp,rsp
  407938:	sub    rsp,0x808
  40793f:	push   rbx
  407940:	push   r12
  407942:	push   r13
  407944:	mov    rax,rdx
  407947:	mov    rdx,rax
  40794a:	nop    WORD PTR [rax+rax*1+0x0]
  407950:	cs cs cs mov rax,rsi
  407956:	shr    rax,0x28
  40795a:	and    rax,0xffff
  407960:	cmp    rax,0x11
  407964:	je     407b87 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x257>
  40796a:	cmp    rax,0x12
  40796e:	jne    407b76 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x246>
  407974:	mov    r12,rdx
  407977:	lea    rdx,[rbp-0x800]
  40797e:	mov    rbx,rdi
  407981:	call   418080 <p125_rt_take2>
  407986:	mov    rdx,r12
  407989:	mov    rdi,rbx
  40798c:	mov    rsi,QWORD PTR [rbp-0x800]
  407993:	mov    r12,QWORD PTR [rbp-0x7f8]
  40799a:	mov    rax,rsi
  40799d:	shr    rax,0x28
  4079a1:	and    rax,0xffff
  4079a7:	cmp    rax,0xa6
  4079ad:	jne    407b65 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x235>
  4079b3:	mov    r13,rdx
  4079b6:	lea    rdx,[rbp-0x800]
  4079bd:	mov    rbx,rdi
  4079c0:	call   4182e0 <p125_rt_take3>
  4079c5:	mov    rdx,r13
  4079c8:	mov    rsi,r12
  4079cb:	mov    rdi,rbx
  4079ce:	mov    r9,QWORD PTR [rbp-0x800]
  4079d5:	mov    rcx,QWORD PTR [rbp-0x7f8]
  4079dc:	mov    r8,QWORD PTR [rbp-0x7f0]
  4079e3:	cmp    r8,0x1
  4079e7:	sete   al
  4079ea:	movzx  eax,al
  4079ed:	shr    r8,0x28
  4079f1:	and    r8,0x7fffff
  4079f8:	cmp    r8,0x10002
  4079ff:	sete   r8b
  407a03:	movzx  r8d,r8b
  407a07:	or     eax,r8d
  407a0a:	jne    407ad1 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x1a1>
  407a10:	xor    eax,0x1
  407a13:	je     407aaf <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x17f>
  407a19:	mov    QWORD PTR [rbp-0x800],rcx
  407a20:	mov    QWORD PTR [rbp-0x7f8],r9
  407a27:	mov    QWORD PTR [rbp-0x7f0],rdx
  407a2e:	mov    rbx,QWORD PTR [rdi+0x8]
  407a32:	mov    rax,QWORD PTR [rbx+0x10]
  407a36:	cmp    rax,0x0
  407a3a:	jne    407a65 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x135>
  407a3c:	cs cs cs lea rdx,cs:[rbp-0x800]
  407a47:	mov    r12,rsi
  407a4a:	mov    esi,0xa5
  407a4f:	mov    rbx,rdi
  407a52:	call   418210 <p125_rt_ctor3>
  407a57:	mov    rsi,r12
  407a5a:	mov    rdi,rbx
  407a5d:	mov    rdx,rax
  407a60:	jmp    407950 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x20>
  407a65:	mov    r10,rcx
  407a68:	mov    rcx,QWORD PTR [rdi]
  407a6b:	mov    r8,rax
  407a6e:	shl    r8,0x3
  407a72:	mov    r12,QWORD PTR [rcx+r8*1]
  407a76:	mov    r11,QWORD PTR [rbx+0x110]
  407a7d:	mov    QWORD PTR [rbx+0x10],r12
  407a81:	sub    r11,0x4
  407a85:	mov    QWORD PTR [rbx+0x110],r11
  407a8c:	mov    QWORD PTR [rcx+r8*1],r10
  407a90:	mov    QWORD PTR [rcx+r8*1+0x8],r9
  407a95:	mov    QWORD PTR [rcx+r8*1+0x10],rdx
  407a9a:	movabs rcx,0x200a50000000000
  407aa4:	mov    rdx,rax
  407aa7:	or     rdx,rcx
  407aaa:	jmp    407950 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x20>
  407aaf:	mov    rsi,rcx
  407ab2:	mov    rbx,rdi
  407ab5:	call   4122e0 <p111_rt_sink>
  407aba:	mov    rdi,rbx
  407abd:	mov    esi,0x4
  407ac2:	call   412a70 <p111_rt_fail>
  407ac7:	mov    eax,0x0
  407acc:	jmp    407b8a <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x25a>
  407ad1:	mov    QWORD PTR [rbp-0x800],rdx
  407ad8:	mov    QWORD PTR [rbp-0x7f8],r9
  407adf:	mov    QWORD PTR [rbp-0x7f0],rcx
  407ae6:	mov    r11,QWORD PTR [rdi+0x8]
  407aea:	mov    rax,QWORD PTR [r11+0x10]
  407aee:	cmp    rax,0x0
  407af2:	jne    407b19 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x1e9>
  407af4:	lea    rdx,[rbp-0x800]
  407afb:	mov    r12,rsi
  407afe:	mov    esi,0xa5
  407b03:	mov    rbx,rdi
  407b06:	call   418210 <p125_rt_ctor3>
  407b0b:	mov    rsi,r12
  407b0e:	mov    rdi,rbx
  407b11:	mov    rdx,rax
  407b14:	jmp    407950 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x20>
  407b19:	cs cs mov rbx,rdx
  407b1e:	mov    rdx,QWORD PTR [rdi]
  407b21:	mov    r8,rax
  407b24:	shl    r8,0x3
  407b28:	mov    r12,QWORD PTR [rdx+r8*1]
  407b2c:	mov    r10,QWORD PTR [r11+0x110]
  407b33:	mov    QWORD PTR [r11+0x10],r12
  407b37:	sub    r10,0x4
  407b3b:	mov    QWORD PTR [r11+0x110],r10
  407b42:	mov    QWORD PTR [rdx+r8*1],rbx
  407b46:	mov    QWORD PTR [rdx+r8*1+0x8],r9
  407b4b:	mov    QWORD PTR [rdx+r8*1+0x10],rcx
  407b50:	movabs rcx,0x200a50000000000
  407b5a:	mov    rdx,rax
  407b5d:	or     rdx,rcx
  407b60:	jmp    407950 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x20>
  407b65:	mov    esi,0x4
  407b6a:	call   412a70 <p111_rt_fail>
  407b6f:	mov    eax,0x0
  407b74:	jmp    407b8a <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x25a>
  407b76:	mov    esi,0x4
  407b7b:	call   412a70 <p111_rt_fail>
  407b80:	mov    eax,0x0
  407b85:	jmp    407b8a <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_117_112_+0x25a>
  407b87:	mov    rax,rdx
  407b8a:	pop    r13
  407b8c:	pop    r12
  407b8e:	pop    rbx
  407b8f:	leave  
  407b90:	ret    
  407b91:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  407b9c:	nop    DWORD PTR [rax+0x0]

