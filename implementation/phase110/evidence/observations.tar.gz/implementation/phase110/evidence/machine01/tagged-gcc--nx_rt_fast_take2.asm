
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402c10 <nx_rt_fast_take2>:
  402c10:	movabs $0xffffffffff,%rax
  402c1a:	push   %r12
  402c1c:	and    %rsi,%rax
  402c1f:	push   %rbp
  402c20:	push   %rbx
  402c21:	mov    %rdi,%rbx
  402c24:	mov    (%rdi),%rdi
  402c27:	lea    0x0(,%rax,8),%rcx
  402c2f:	mov    0x8(%rbx),%rbp
  402c33:	lea    (%rdi,%rcx,1),%rdx
  402c37:	test   %rsi,%rsi
  402c3a:	js     402ca8 <nx_rt_fast_take2+0x98>
  402c3c:	mov    (%rdx),%rdx
  402c3f:	mov    %rdx,0x10(%rbx)
  402c43:	mov    0x8(%rdi,%rcx,1),%rdx
  402c48:	mov    %rdx,0x18(%rbx)
  402c4c:	cmp    $0x310817f,%rax
  402c52:	ja     402c68 <nx_rt_fast_take2+0x58>
  402c54:	movl   $0x3,0x20(%rbx)
  402c5b:	xor    %eax,%eax
  402c5d:	pop    %rbx
  402c5e:	pop    %rbp
  402c5f:	pop    %r12
  402c61:	retq   
  402c62:	nopw   0x0(%rax,%rax,1)
  402c68:	mov    0x8(%rbp),%rdx
  402c6c:	mov    %rdx,(%rdi,%rax,8)
  402c70:	mov    0x3e562(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402c76:	mov    %rax,0x8(%rbp)
  402c7a:	mov    0x108(%rbp),%rax
  402c81:	add    $0x2,%rax
  402c85:	mov    %rax,0x108(%rbp)
  402c8c:	cmp    %rdx,%rax
  402c8f:	jae    40160f <nx_rt_fast_take2.cold>
  402c95:	movl   $0x3,0x20(%rbx)
  402c9c:	xor    %eax,%eax
  402c9e:	pop    %rbx
  402c9f:	pop    %rbp
  402ca0:	pop    %r12
  402ca2:	retq   
  402ca3:	nopl   0x0(%rax,%rax,1)
  402ca8:	mov    0x4(%rdx),%ecx
  402cab:	mov    (%rdx),%r8d
  402cae:	shl    $0x20,%rcx
  402cb2:	or     %r8,%rcx
  402cb5:	mov    %rcx,%r12
  402cb8:	and    $0xffffff,%ecx
  402cbe:	shr    $0x18,%r12
  402cc2:	lea    0x0(,%r12,8),%r8
  402cca:	lea    (%rdi,%r8,1),%r9
  402cce:	lea    0x8(%rdi,%r8,1),%r8
  402cd3:	cmp    $0x1,%rcx
  402cd7:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  402cdd:	mov    (%rdx),%ecx
  402cdf:	mov    (%r9),%rcx
  402ce2:	mov    %rcx,0x10(%rbx)
  402ce6:	mov    (%r8),%rcx
  402ce9:	mov    %rcx,0x18(%rbx)
  402ced:	mov    0x0(%rbp),%rcx
  402cf1:	mov    %rcx,(%rdx)
  402cf4:	mov    0x3e4de(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402cfa:	mov    %rax,0x0(%rbp)
  402cfe:	mov    0x100(%rbp),%rax
  402d05:	add    $0x1,%rax
  402d09:	mov    %rax,0x100(%rbp)
  402d10:	cmp    %rdx,%rax
  402d13:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402d19:	mov    %r12,%rax
  402d1c:	jmpq   402c4c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
