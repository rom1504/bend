
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	endbr64 
  401df4:	push   %rbp
  401df5:	mov    %rsp,%rbp
  401df8:	sub    $0x48,%rsp
  401dfc:	push   %rbx
  401dfd:	push   %r12
  401dff:	push   %r13
  401e01:	push   %r14
  401e03:	push   %r15
  401e05:	mov    %rdx,%rbx
  401e08:	mov    %rsi,%r14
  401e0b:	mov    %rdi,%r12
  401e0e:	callq  4047e0 <nx_rt_ir_heap>
  401e13:	mov    %r12,%rdi
  401e16:	mov    %rax,%r12
  401e19:	mov    %rdi,%r13
  401e1c:	callq  404850 <nx_rt_ir_alc>
  401e21:	mov    %r14,%rsi
  401e24:	mov    %r13,%rdi
  401e27:	xchg   %rax,%rbx
  401e29:	mov    %rax,%r15
  401e2c:	nopl   0x0(%rax)
  401e30:	mov    %rsi,-0x18(%rbp)
  401e34:	mov    %rsi,%rax
  401e37:	shr    $0x28,%rax
  401e3b:	and    $0xffff,%rax
  401e41:	cmp    $0x0,%rax
  401e45:	je     402154 <nx_list_reverse+0x364>
  401e4b:	cmp    $0x1,%rax
  401e4f:	jne    402148 <nx_list_reverse+0x358>
  401e55:	movabs $0xffffffffff,%rax
  401e5f:	mov    %rsi,%r13
  401e62:	and    %rax,%r13
  401e65:	mov    %rsi,%r8
  401e68:	shr    $0x3f,%r8
  401e6c:	mov    %r8,-0x10(%rbp)
  401e70:	cmp    $0x1,%r8
  401e74:	je     401e94 <nx_list_reverse+0xa4>
  401e76:	cmp    $0x3108180,%r13
  401e7d:	setb   %al
  401e80:	movzbl %al,%eax
  401e83:	cmp    $0x0,%eax
  401e86:	sete   %al
  401e89:	movzbl %al,%eax
  401e8c:	mov    %r15,%rdx
  401e8f:	mov    %r13,%r15
  401e92:	jmp    401ee7 <nx_list_reverse+0xf7>
  401e94:	mov    %r13,%rsi
  401e97:	mov    %rdi,%r14
  401e9a:	callq  4048c0 <nx_rt_ir_view>
  401e9f:	mov    %r15,%rdx
  401ea2:	mov    %r14,%rdi
  401ea5:	mov    -0x18(%rbp),%rsi
  401ea9:	mov    -0x10(%rbp),%r8
  401ead:	mov    %rax,%rcx
  401eb0:	and    $0xffffff,%rcx
  401eb7:	cmp    $0x1,%rcx
  401ebb:	je     401ec7 <nx_list_reverse+0xd7>
  401ebd:	mov    %r13,%r15
  401ec0:	mov    $0x0,%eax
  401ec5:	jmp    401ee7 <nx_list_reverse+0xf7>
  401ec7:	mov    %r13,%r15
  401eca:	mov    %rax,%r13
  401ecd:	shr    $0x18,%r13
  401ed1:	cmp    $0x3108180,%r13
  401ed8:	setb   %al
  401edb:	movzbl %al,%eax
  401ede:	cmp    $0x0,%eax
  401ee1:	sete   %al
  401ee4:	movzbl %al,%eax
  401ee7:	mov    %r13,-0x40(%rbp)
  401eeb:	cmp    $0x0,%eax
  401eee:	jne    401f19 <nx_list_reverse+0x129>
  401ef0:	mov    %rdi,%r13
  401ef3:	callq  403ba0 <nx_rt_rebuild2_c1_k0>
  401ef8:	mov    %r13,%rdi
  401efb:	mov    %rax,%r14
  401efe:	mov    $0x0,%esi
  401f03:	mov    %rdi,%r13
  401f06:	callq  4034d0 <nx_rt_fast_field>
  401f0b:	mov    %r14,%rdx
  401f0e:	mov    %r13,%rdi
  401f11:	mov    %rax,%rsi
  401f14:	jmpq   402140 <nx_list_reverse+0x350>
  401f19:	mov    %r13,%rcx
  401f1c:	shl    $0x3,%rcx
  401f20:	mov    %rcx,-0x20(%rbp)
  401f24:	mov    %r12,%rax
  401f27:	add    %rcx,%rax
  401f2a:	mov    %rax,-0x30(%rbp)
  401f2e:	mov    (%r12,%rcx,1),%r14
  401f32:	mov    0x8(%r12,%rcx,1),%rsi
  401f37:	mov    %rsi,-0x28(%rbp)
  401f3b:	cmp    $0x1,%r8
  401f3f:	jne    401f93 <nx_list_reverse+0x1a3>
  401f41:	mov    (%rbx),%r8
  401f44:	mov    %r15,%r9
  401f47:	shl    $0x3,%r9
  401f4b:	mov    %r8,(%r12,%r9,1)
  401f4f:	mov    %r15,(%rbx)
  401f52:	mov    %rdx,%r15
  401f55:	mov    0x100(%rbx),%rdx
  401f5c:	add    $0x1,%rdx
  401f60:	mov    %rdx,0x100(%rbx)
  401f67:	cmp    $0x8000,%rdx
  401f6e:	jb     401f90 <nx_list_reverse+0x1a0>
  401f70:	mov    %rdi,%r13
  401f73:	callq  401c36 <nx_rt_ir_hand0>
  401f78:	mov    %r15,%rdx
  401f7b:	mov    %r13,%rdi
  401f7e:	mov    -0x40(%rbp),%r13
  401f82:	mov    -0x28(%rbp),%rsi
  401f86:	mov    -0x30(%rbp),%rax
  401f8a:	mov    -0x20(%rbp),%rcx
  401f8e:	jmp    401f93 <nx_list_reverse+0x1a3>
  401f90:	mov    %r15,%rdx
  401f93:	mov    %r14,%r8
  401f96:	shr    $0x38,%r8
  401f9a:	and    $0x7f,%r8
  401f9e:	cmp    $0x2,%r8
  401fa2:	sete   %r8b
  401fa6:	movzbl %r8b,%r8d
  401faa:	mov    %r14,%r9
  401fad:	shr    $0x3f,%r9
  401fb1:	cmp    $0x0,%r9
  401fb5:	sete   %r9b
  401fb9:	movzbl %r9b,%r9d
  401fbd:	test   %r8d,%r9d
  401fc0:	jne    401fca <nx_list_reverse+0x1da>
  401fc2:	mov    %rcx,%r15
  401fc5:	jmpq   402060 <nx_list_reverse+0x270>
  401fca:	mov    (%rbx),%r8
  401fcd:	cmp    $0x0,%r8
  401fd1:	je     401ffe <nx_list_reverse+0x20e>
  401fd3:	mov    %r8,%r9
  401fd6:	shl    $0x3,%r9
  401fda:	mov    (%r12,%r9,1),%r9
  401fde:	mov    %r9,(%rbx)
  401fe1:	mov    %rdx,%r15
  401fe4:	mov    0x100(%rbx),%rdx
  401feb:	sub    $0x1,%rdx
  401fef:	mov    %rdx,0x100(%rbx)
  401ff6:	mov    %r15,%rdx
  401ff9:	mov    %rcx,%r15
  401ffc:	jmp    402022 <nx_list_reverse+0x232>
  401ffe:	mov    %rdx,%r15
  402001:	mov    %rdi,%r13
  402004:	callq  401c25 <nx_rt_ir_alloc0>
  402009:	mov    %r15,%rdx
  40200c:	mov    %r13,%rdi
  40200f:	mov    %rax,%r8
  402012:	mov    -0x40(%rbp),%r13
  402016:	mov    -0x28(%rbp),%rsi
  40201a:	mov    -0x30(%rbp),%rax
  40201e:	mov    -0x20(%rbp),%r15
  402022:	mov    %r8,%r9
  402025:	shl    $0x3,%r9
  402029:	movabs $0xffffffffff,%rcx
  402033:	and    %r14,%rcx
  402036:	shl    $0x18,%rcx
  40203a:	or     $0x1,%rcx
  40203e:	mov    %rcx,(%r12,%r9,1)
  402042:	mov    %r14,%rcx
  402045:	shr    $0x28,%rcx
  402049:	shl    $0x28,%rcx
  40204d:	movabs $0x8000000000000000,%r9
  402057:	or     %r9,%rcx
  40205a:	mov    %rcx,%r14
  40205d:	or     %r8,%r14
  402060:	mov    %r14,%rcx
  402063:	mov    %rcx,-0x38(%rbp)
  402067:	mov    %rdx,%r8
  40206a:	shr    $0x38,%r8
  40206e:	and    $0x7f,%r8
  402072:	cmp    $0x2,%r8
  402076:	sete   %r8b
  40207a:	movzbl %r8b,%r8d
  40207e:	mov    %rdx,%r9
  402081:	shr    $0x3f,%r9
  402085:	cmp    $0x0,%r9
  402089:	sete   %r9b
  40208d:	movzbl %r9b,%r9d
  402091:	test   %r8d,%r9d
  402094:	jne    40209e <nx_list_reverse+0x2ae>
  402096:	mov    %rcx,%r14
  402099:	jmpq   402128 <nx_list_reverse+0x338>
  40209e:	mov    %rdx,%r14
  4020a1:	mov    (%rbx),%rdx
  4020a4:	cmp    $0x0,%rdx
  4020a8:	je     4020cf <nx_list_reverse+0x2df>
  4020aa:	mov    %rdx,%r8
  4020ad:	shl    $0x3,%r8
  4020b1:	mov    (%r12,%r8,1),%r8
  4020b5:	mov    %r8,(%rbx)
  4020b8:	mov    0x100(%rbx),%r8
  4020bf:	sub    $0x1,%r8
  4020c3:	mov    %r8,0x100(%rbx)
  4020ca:	xchg   %rcx,%r14
  4020cd:	jmp    4020f0 <nx_list_reverse+0x300>
  4020cf:	mov    %rdi,%r13
  4020d2:	callq  401c25 <nx_rt_ir_alloc0>
  4020d7:	mov    %r14,%rcx
  4020da:	mov    %r13,%rdi
  4020dd:	mov    %rax,%rdx
  4020e0:	mov    -0x38(%rbp),%r14
  4020e4:	mov    -0x40(%rbp),%r13
  4020e8:	mov    -0x28(%rbp),%rsi
  4020ec:	mov    -0x30(%rbp),%rax
  4020f0:	mov    %rdx,%r9
  4020f3:	shl    $0x3,%r9
  4020f7:	movabs $0xffffffffff,%r8
  402101:	and    %rcx,%r8
  402104:	shl    $0x18,%r8
  402108:	or     $0x1,%r8
  40210c:	mov    %r8,(%r12,%r9,1)
  402110:	shr    $0x28,%rcx
  402114:	shl    $0x28,%rcx
  402118:	movabs $0x8000000000000000,%r8
  402122:	or     %r8,%rcx
  402125:	or     %rcx,%rdx
  402128:	mov    %r14,(%r12,%r15,1)
  40212c:	mov    %rdx,0x8(%rax)
  402130:	movabs $0x200010000000000,%rax
  40213a:	mov    %r13,%rdx
  40213d:	or     %rax,%rdx
  402140:	mov    %rdx,%r15
  402143:	jmpq   401e30 <nx_list_reverse+0x40>
  402148:	mov    $0x1,%esi
  40214d:	callq  402cd0 <nx_rt_fail>
  402152:	jmp    402157 <nx_list_reverse+0x367>
  402154:	mov    %r15,%rax
  402157:	pop    %r15
  402159:	pop    %r14
  40215b:	pop    %r13
  40215d:	pop    %r12
  40215f:	pop    %rbx
  402160:	leaveq 
  402161:	retq   

Disassembly of section .fini:
