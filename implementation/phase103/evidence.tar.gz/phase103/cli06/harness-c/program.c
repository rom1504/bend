
// Imports
// =======

// The Objective-C headers take #include, not #import: a build
// (-o) reads an #import as the framework of an effect.

#pragma clang fp contract(off)

#if defined(__CUDACC_RTC__)
#define BEND_RTC 1
#endif

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(BEND_RTC)
#ifdef __APPLE__
#define _DARWIN_UNLIMITED_SELECT
#else
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#include <sys/select.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

// Metal needs coherent(device) (MSL 3.2), or M1-class parts lose stores
// across the threadgroups of a dispatch. CUDA keeps plain data cacheable
// in L1: lanes hand off through a32 and FENCE. Only clang 19+ has both
// preserve_none and preserve_most, and compiles preserve_most soundly; at
// -O0 its register allocator cannot place a preserve_none segment, so an
// unoptimized build takes neither. A segment is a case of the device's
// switch; on the host, a preserve_none function (WL_SIG) entered by
// musttail, its words fresh at WL_OPEN.

#ifdef __METAL_VERSION__
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#else
#define DEV     device
#endif
#define THR     thread
#define TG      threadgroup
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)
#else
#define DEV
#define THR
#define TG
#define INLINE  static inline
#define CONSTV  static const
#ifdef BEND_RTC
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#define FENCE() ((void)0)
#endif
#endif
#define FAR static __attribute__((noinline))

#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Term
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue

#define LANE_STEP (DEVICE ? (long)CUBE : 1)
#define STK(I)    sp[(long)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); sp -= LANE_STEP; WL_DYN((u32)STK(0)); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  u64 wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + STAT_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
#elif defined(BEND_RTC)
typedef unsigned long long u64;
typedef unsigned int       u32;
typedef unsigned char      u8;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
#endif
typedef float f32;

typedef u64 Term;

typedef struct {
  DEV u64* mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

// Constants
// =========

#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)
#define LOC_MASK  ((1ull << 40) - 1)
#define RFC_BIT   (1ull << 63)
#define RFC_CNT   ((1u << 24) - 1)
#define NAT_IMM   ((1ull << 48) - 1)

#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8
#define ERR_CNTS 9

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LEN  (1ull << (17 - CUBE_LOG))
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * NCLS_ALL)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

// The bag is 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the
// device). The device program compiles from the binary's own text.

#if !DEVICE

static u64*    CORPUS;
static u64    ALC[CUBE_T + 1][3 * NCLS_ALL] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32             pool_size;
static u32             pool_row;
static u32             pool_done;
static pthread_mutex_t pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  pool_wake = PTHREAD_COND_INITIALIZER;
static pthread_cond_t  pool_join = PTHREAD_COND_INITIALIZER;

#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static DEV Term*  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --bend-help       show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define CID_TUPLE 0
#define CID_SNIL 1
#define CID_SCON 2
#define CID_WCON 3
#define CID_EMIT 4
#define CID_HALT 5
#define CID_FAIL 6
#define CID_DONE 7
#define CID_READY 8
#define CID_WAIT 9
#define CID_NONE 10
#define CID_SOME 11
#define CID_FALSE 12
#define CID_TRUE 13
#define CID_UNIT 14
#define CID_NIL 15
#define CID_CON 16
#define CID_CHR 17
#define CID_CLIERROR 18
#define CID_CLIHELP 19
#define CID_CLIVERSION 20
#define CID_CLIREQUEST 21
#define CID_LT 22
#define CID_EQ 23
#define CID_GT 24
#define CID_IO_ARGS 25
#define CID_IO_PRINT 26
#define CID_NATIVEHOST_PATH 27
#define CID_NATIVEHOST_PUBLISH 28
#define CID_NATIVEHOST_READ 29
#define FID_STRING_CMP 0
#define FID_STRING_CMP_K7 1
#define FID_CLI_DIGEST 2
#define FID_CLI_DIGEST_K16 3
#define FID_CLI_DIGEST_C17 4
#define FID_CLI_DIGEST_C18 5
#define FID_CLI_DIGEST_K19 6
#define FID_CLI_DIGEST_C20 7
#define FID_CLI_DIGEST_C21 8
#define FID_CLI_DIGEST_K22 9
#define FID_CLI_DIGEST_C23 10
#define FID_CLI_DIGEST_C24 11
#define FID_CLI_DIGEST_K25 12
#define FID_CLI_DIGEST_C26 13
#define FID_CLI_DIGEST_C27 14
#define FID_CLI_DIGEST_K28 15
#define FID_CLI_DIGEST_C29 16
#define FID_CLI_DIGEST_C30 17
#define FID_CLI_DIGEST_K31 18
#define FID_CLI_DIGEST_C32 19
#define FID_CLI_DIGEST_C33 20
#define FID_CLI_DIGEST_K34 21
#define FID_CLI_DIGEST_C35 22
#define FID_CLI_DIGEST_C36 23
#define FID_CLI_DIGEST_K37 24
#define FID_CLI_DIGEST_C38 25
#define FID_CLI_DIGEST_C39 26
#define FID_CLI_DIGEST_K40 27
#define FID_CLI_DIGEST_C41 28
#define FID_CLI_DIGEST_C42 29
#define FID_CLI_DIGEST_K43 30
#define FID_CLI_DIGEST_C44 31
#define FID_CLI_DIGEST_C45 32
#define FID_CLI_DIGEST_K46 33
#define FID_CLI_DIGEST_C47 34
#define FID_CLI_DIGEST_C48 35
#define FID_CLI_DIGEST_K49 36
#define FID_CLI_DIGEST_C50 37
#define FID_CLI_DIGEST_C51 38
#define FID_CLI_DIGEST_K52 39
#define FID_CLI_DIGEST_C53 40
#define FID_CLI_DIGEST_C54 41
#define FID_CLI_DIGEST_K55 42
#define FID_CLI_DIGEST_C56 43
#define FID_CLI_DIGEST_C57 44
#define FID_CLI_DIGEST_K58 45
#define FID_CLI_DIGEST_C59 46
#define FID_CLI_DIGEST_C60 47
#define FID_CLI_DIGEST_K61 48
#define FID_CLI_DIGEST_C62 49
#define FID_CLI_DIGEST_C63 50
#define FID_STRING_STARTS_WITH 51
#define FID_STRING_ORDER 52
#define FID_STRING_ORDER_K76 53
#define FID_CLI_READ 54
#define FID_CLI_READ_C79 55
#define FID_CLI_READ_C80 56
#define FID_CLI_READ_C81 57
#define FID_CLI_READ_K82 58
#define FID_CLI_READ_K83 59
#define FID_CLI_READ_K84 60
#define FID_CLI_READ_C85 61
#define FID_CLI_ASSET 62
#define FID_CLI_ASSET_K87 63
#define FID_CLI_ASSET_C88 64
#define FID_CLI_ASSET_K89 65
#define FID_CLI_ASSET_C90 66
#define FID_CLI_ASSET_C91 67
#define FID_CLI_ASSET_K92 68
#define FID_CLI_ASSET_K93 69
#define FID_CLI_OPTIONS 70
#define FID_CLI_OPTIONS_C98 71
#define FID_CLI_OPTIONS_C99 72
#define FID_CLI_OPTIONS_K100 73
#define FID_CLI_OPTIONS_K101 74
#define FID_CLI_OPTIONS_K102 75
#define FID_CLI_OPTIONS_C103 76
#define FID_CLI_OPTIONS_C104 77
#define FID_CLI_OPTIONS_C105 78
#define FID_CLI_OPTIONS_C106 79
#define FID_CLI_OPTIONS_C107 80
#define FID_CLI_OPTIONS_K108 81
#define FID_CLI_OPTIONS_C109 82
#define FID_CLI_OPTIONS_K110 83
#define FID_CLI_OPTIONS_C111 84
#define FID_CLI_OPTIONS_K112 85
#define FID_CLI_OPTIONS_C113 86
#define FID_CLI_OPTIONS_K114 87
#define FID_CLI_OPTIONS_C115 88
#define FID_CLI_OPTIONS_C116 89
#define FID_CLI_OPTIONS_C117 90
#define FID_CLI_OPTIONS_K118 91
#define FID_CLI_OPTIONS_C119 92
#define FID_CLI_OPTIONS_K120 93
#define FID_CLI_OPTIONS_C121 94
#define FID_CLI_OPTIONS_K122 95
#define FID_CLI_OPTIONS_C123 96
#define FID_CLI_OPTIONS_C124 97
#define FID_CLI_OPTIONS_K125 98
#define FID_CLI_OPTIONS_C126 99
#define FID_CLI_OPTIONS_K127 100
#define FID_STRING_EQ 101
#define FID_STRING_EQ_K129 102
#define FID_KC 103
#define FID_CLI_PASS_C135 104
#define FID_CLI_PASS_C136 105
#define FID_CLI_PASS_C151 106
#define FID_CLI_PASS_C152 107
#define FID_IO_PURE 108
#define FID_STRING_APPEND 109
#define FID_STRING_APPEND_K157 110
#define FID_CLI_PARSE 111
#define FID_CLI_PARSE_K161 112
#define FID_CLI_PARSE_C162 113
#define FID_CLI_PARSE_C163 114
#define FID_CLI_PARSE_K164 115
#define FID_CLI_PARSE_C165 116
#define FID_CLI_PARSE_C166 117
#define FID_CLI_PARSE_K167 118
#define FID_CLI_PARSE_K168 119
#define FID_IO_BIND 120
#define FID_IO_BIND_C230 121
#define FID_IO_BIND_K231 122
#define FID_MAIN 123
#define FID_MAIN_C233 124
#define FID_MAIN_C234 125
#define FID_MAIN_K235 126
#define FID_MAIN_K236 127
#define FID_MAIN_K237 128
#define FID_MAIN_C238 129
#define FID_MAIN_C239 130
#define FID_MAIN_C240 131
#define FID_MAIN_C241 132
#define FID_MAIN_C242 133
#define FID_MAIN_C243 134
#define FID_MAIN_C244 135
#define FID_MAIN_C245 136
#define FID_MAIN_C246 137
#define FID_MAIN_C247 138
#define FID_MAIN_C248 139
#define FID_MAIN_K249 140
#define FID_MAIN_C250 141
#define FID_MAIN_C251 142
#define FID_MAIN_C252 143
#define FID_MAIN_C253 144
#define FID_MAIN_C254 145
#define FID_MAIN_C255 146
#define FID_MAIN_K256 147
#define FID_MAIN_C257 148
#define FID_MAIN_C258 149
#define FID_MAIN_C259 150
#define FID_MAIN_C260 151
#define FID_MAIN_C261 152
#define FID_MAIN_C262 153
#define FID_MAIN_C263 154
#define FID_MAIN_C264 155
#define FID_IO_ARGS 156
#define FID_IO_PRINT 157
#define FID_NATIVEHOST_PATH 158
#define FID_NATIVEHOST_PUBLISH 159
#define FID_NATIVEHOST_READ 160
#define FID_IO_EMIT 161
#define FID_CLO_APPLY 162
#define FID_EXIT 163
#define FID_ENTER 164
CONSTV u8 FID_T[][3] = { { 2, 0, 2 }, { 5, 3, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 3, 3, 2 }, { 2, 0, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 3, 1, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 4, 0, 2 }, { 3, 1, 2 }, { 2, 1, 2 }, { 5, 0, 2 }, { 1, 0, 2 }, { 4, 0, 2 }, { 1, 1, 2 }, { 7, 1, 2 }, { 8, 1, 2 }, { 5, 0, 2 }, { 1, 0, 2 }, { 5, 0, 2 }, { 1, 0, 2 }, { 5, 0, 2 }, { 4, 4, 2 }, { 7, 0, 2 }, { 7, 1, 2 }, { 5, 0, 2 }, { 4, 4, 2 }, { 7, 0, 2 }, { 7, 1, 2 }, { 6, 0, 2 }, { 1, 0, 2 }, { 5, 0, 2 }, { 4, 4, 2 }, { 7, 0, 2 }, { 7, 1, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 7, 0, 2 }, { 6, 0, 2 }, { 4, 4, 2 }, { 1, 0, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 4, 4, 2 }, { 1, 1, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 1, 2 }, { 0, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 4, 4, 2 }, { 2, 1, 2 }, { 1, 1, 2 }, { 2, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 6, 0, 2 }, { 3, 0, 2 }, { 3, 1, 2 }, { 4, 0, 2 }, { 3, 0, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 5, 0, 2 }, { 2, 0, 2 }, { 2, 1, 2 }, { 3, 0, 2 }, { 2, 0, 2 }, { 3, 0, 2 }, { 1, 0, 2 }, { 4, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 }, { 2, 0, 2 }, { 3, 0, 2 }, { 4, 0, 2 }, { 1, 0, 2 }, { 2, 0, 2 } };
CONSTV u8 CID_T[][2] = { { 2, 0 }, { 0, 1 }, { 2, 1 }, { 2, 1 }, { 1, 0 }, { 2, 0 }, { 1, 0 }, { 1, 0 }, { 1, 0 }, { 1, 0 }, { 0, 0 }, { 1, 0 }, { 0, 1 }, { 0, 1 }, { 0, 0 }, { 0, 1 }, { 2, 1 }, { 1, 1 }, { 1, 0 }, { 0, 0 }, { 0, 0 }, { 3, 0 }, { 0, 0 }, { 0, 0 }, { 0, 0 }, { 1, 0 }, { 2, 0 }, { 2, 0 }, { 3, 0 }, { 4, 0 } };
#define STAT_LEN 3784

#define WL_RESW 4
#define BANGS   0

#define WL_BANK Term r0, r1, r2, r3, r4, r5, rp, r6;

#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
    if ((N) <= 5) break; r5 = e.mem[(A) + 5]; \
    if ((N) <= 6) break; r6 = e.mem[(A) + 6]; \
  } while (0);

#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); \
      break; \
    case 1: r1 = (X); \
      break; \
    case 2: r2 = (X); \
      break; \
    case 3: r3 = (X); \
      break; \
    case 4: r4 = (X); \
      break; \
    case 5: r5 = (X); \
      break; \
    case 6: r6 = (X); \
      break; \
  }

#define WL_SAVE(V) (V)[0] = r0; (V)[1] = r1; (V)[2] = r2; (V)[3] = r3;

#define WL_TAKE(V) r0 = (V)[0]; r1 = (V)[1]; r2 = (V)[2]; r3 = (V)[3];

#define WL_SIG Env e, DEV Term* sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4, Term r5, Term rp, Term r6

#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4, r5, rp, r6

#define WL_TABLE WL_X(FID_STRING_CMP) WL_X(FID_STRING_CMP_K7) WL_X(FID_CLI_DIGEST) WL_X(FID_CLI_DIGEST_K16) WL_X(FID_CLI_DIGEST_C17) WL_X(FID_CLI_DIGEST_C18) WL_X(FID_CLI_DIGEST_K19) WL_X(FID_CLI_DIGEST_C20) WL_X(FID_CLI_DIGEST_C21) WL_X(FID_CLI_DIGEST_K22) WL_X(FID_CLI_DIGEST_C23) WL_X(FID_CLI_DIGEST_C24) WL_X(FID_CLI_DIGEST_K25) WL_X(FID_CLI_DIGEST_C26) WL_X(FID_CLI_DIGEST_C27) WL_X(FID_CLI_DIGEST_K28) WL_X(FID_CLI_DIGEST_C29) WL_X(FID_CLI_DIGEST_C30) WL_X(FID_CLI_DIGEST_K31) WL_X(FID_CLI_DIGEST_C32) WL_X(FID_CLI_DIGEST_C33) WL_X(FID_CLI_DIGEST_K34) WL_X(FID_CLI_DIGEST_C35) WL_X(FID_CLI_DIGEST_C36) WL_X(FID_CLI_DIGEST_K37) WL_X(FID_CLI_DIGEST_C38) WL_X(FID_CLI_DIGEST_C39) WL_X(FID_CLI_DIGEST_K40) WL_X(FID_CLI_DIGEST_C41) WL_X(FID_CLI_DIGEST_C42) WL_X(FID_CLI_DIGEST_K43) WL_X(FID_CLI_DIGEST_C44) WL_X(FID_CLI_DIGEST_C45) WL_X(FID_CLI_DIGEST_K46) WL_X(FID_CLI_DIGEST_C47) WL_X(FID_CLI_DIGEST_C48) WL_X(FID_CLI_DIGEST_K49) WL_X(FID_CLI_DIGEST_C50) WL_X(FID_CLI_DIGEST_C51) WL_X(FID_CLI_DIGEST_K52) WL_X(FID_CLI_DIGEST_C53) WL_X(FID_CLI_DIGEST_C54) WL_X(FID_CLI_DIGEST_K55) WL_X(FID_CLI_DIGEST_C56) WL_X(FID_CLI_DIGEST_C57) WL_X(FID_CLI_DIGEST_K58) WL_X(FID_CLI_DIGEST_C59) WL_X(FID_CLI_DIGEST_C60) WL_X(FID_CLI_DIGEST_K61) WL_X(FID_CLI_DIGEST_C62) WL_X(FID_CLI_DIGEST_C63) WL_X(FID_STRING_STARTS_WITH) WL_X(FID_STRING_ORDER) WL_X(FID_STRING_ORDER_K76) WL_X(FID_CLI_READ) WL_X(FID_CLI_READ_C79) WL_X(FID_CLI_READ_C80) WL_X(FID_CLI_READ_C81) WL_X(FID_CLI_READ_K82) WL_X(FID_CLI_READ_K83) WL_X(FID_CLI_READ_K84) WL_X(FID_CLI_READ_C85) WL_X(FID_CLI_ASSET) WL_X(FID_CLI_ASSET_K87) WL_X(FID_CLI_ASSET_C88) WL_X(FID_CLI_ASSET_K89) WL_X(FID_CLI_ASSET_C90) WL_X(FID_CLI_ASSET_C91) WL_X(FID_CLI_ASSET_K92) WL_X(FID_CLI_ASSET_K93) WL_X(FID_CLI_OPTIONS) WL_X(FID_CLI_OPTIONS_C98) WL_X(FID_CLI_OPTIONS_C99) WL_X(FID_CLI_OPTIONS_K100) WL_X(FID_CLI_OPTIONS_K101) WL_X(FID_CLI_OPTIONS_K102) WL_X(FID_CLI_OPTIONS_C103) WL_X(FID_CLI_OPTIONS_C104) WL_X(FID_CLI_OPTIONS_C105) WL_X(FID_CLI_OPTIONS_C106) WL_X(FID_CLI_OPTIONS_C107) WL_X(FID_CLI_OPTIONS_K108) WL_X(FID_CLI_OPTIONS_C109) WL_X(FID_CLI_OPTIONS_K110) WL_X(FID_CLI_OPTIONS_C111) WL_X(FID_CLI_OPTIONS_K112) WL_X(FID_CLI_OPTIONS_C113) WL_X(FID_CLI_OPTIONS_K114) WL_X(FID_CLI_OPTIONS_C115) WL_X(FID_CLI_OPTIONS_C116) WL_X(FID_CLI_OPTIONS_C117) WL_X(FID_CLI_OPTIONS_K118) WL_X(FID_CLI_OPTIONS_C119) WL_X(FID_CLI_OPTIONS_K120) WL_X(FID_CLI_OPTIONS_C121) WL_X(FID_CLI_OPTIONS_K122) WL_X(FID_CLI_OPTIONS_C123) WL_X(FID_CLI_OPTIONS_C124) WL_X(FID_CLI_OPTIONS_K125) WL_X(FID_CLI_OPTIONS_C126) WL_X(FID_CLI_OPTIONS_K127) WL_X(FID_STRING_EQ) WL_X(FID_STRING_EQ_K129) WL_X(FID_KC) WL_X(FID_CLI_PASS_C135) WL_X(FID_CLI_PASS_C136) WL_X(FID_CLI_PASS_C151) WL_X(FID_CLI_PASS_C152) WL_X(FID_IO_PURE) WL_X(FID_STRING_APPEND) WL_X(FID_STRING_APPEND_K157) WL_X(FID_CLI_PARSE) WL_X(FID_CLI_PARSE_K161) WL_X(FID_CLI_PARSE_C162) WL_X(FID_CLI_PARSE_C163) WL_X(FID_CLI_PARSE_K164) WL_X(FID_CLI_PARSE_C165) WL_X(FID_CLI_PARSE_C166) WL_X(FID_CLI_PARSE_K167) WL_X(FID_CLI_PARSE_K168) WL_X(FID_IO_BIND) WL_X(FID_IO_BIND_C230) WL_X(FID_IO_BIND_K231) WL_X(FID_MAIN) WL_X(FID_MAIN_C233) WL_X(FID_MAIN_C234) WL_X(FID_MAIN_K235) WL_X(FID_MAIN_K236) WL_X(FID_MAIN_K237) WL_X(FID_MAIN_C238) WL_X(FID_MAIN_C239) WL_X(FID_MAIN_C240) WL_X(FID_MAIN_C241) WL_X(FID_MAIN_C242) WL_X(FID_MAIN_C243) WL_X(FID_MAIN_C244) WL_X(FID_MAIN_C245) WL_X(FID_MAIN_C246) WL_X(FID_MAIN_C247) WL_X(FID_MAIN_C248) WL_X(FID_MAIN_K249) WL_X(FID_MAIN_C250) WL_X(FID_MAIN_C251) WL_X(FID_MAIN_C252) WL_X(FID_MAIN_C253) WL_X(FID_MAIN_C254) WL_X(FID_MAIN_C255) WL_X(FID_MAIN_K256) WL_X(FID_MAIN_C257) WL_X(FID_MAIN_C258) WL_X(FID_MAIN_C259) WL_X(FID_MAIN_C260) WL_X(FID_MAIN_C261) WL_X(FID_MAIN_C262) WL_X(FID_MAIN_C263) WL_X(FID_MAIN_C264) WL_X(FID_IO_ARGS) WL_X(FID_IO_PRINT) WL_X(FID_NATIVEHOST_PATH) WL_X(FID_NATIVEHOST_PUBLISH) WL_X(FID_NATIVEHOST_READ) WL_X(FID_IO_EMIT) WL_X(FID_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_MAIN
#define MAIN_PURE 0
#define BLK_SHR 0

#define TAB_AT(T, S, I) T[S < I ? S : I]

#define fid_arity(x) ((u32)FID_T[x][0])
#define fid_resw(x)  ((u32)FID_T[x][1])
#define fid_bangs(x) ((bool)(FID_T[x][2] & 1))
#define fid_nofk(x)  ((bool)(FID_T[x][2] & 2))
#define cid_arity(x) ((u32)CID_T[x][0])
#define cid_hot(x)   ((bool)CID_T[x][1])

// A32
// ===

// C11's atomics on every lane; a device FENCE releases or acquires.
// Metal's loads read through a volatile local, or the M1 and M2 pipeline
// builds die. A weak CAS may fail with the cell still x: a32_cmpx loops.

#define A32_LOOP(k, x) \
  INLINE u32 a32_##k(DEV u32* p, u32 v) { \
    u32 o = a32_load(p); \
    while (!a32_cas(p, &o, x)) { \
    } \
    return o; \
  }

#ifdef __METAL_VERSION__

INLINE DEV atomic_uint* A32(DEV u32* p) {
  return (DEV atomic_uint*)p;
}

INLINE TG atomic_uint* A32(TG u32* p) {
  return (TG atomic_uint*)p;
}

#define a32_load(p) \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })

#else

#define a32_load(p) atomic_load_explicit(A32(p), RLX)

#ifdef BEND_RTC

#define A32(p) (p)
#define atomic_load_explicit(p, o)     (*(volatile u32*)(p))
#define atomic_store_explicit(p, v, o) (*(volatile u32*)(p) = (v))
#define atomic_fetch_add_explicit(p, v, o) atomicAdd((u32*)(p), v)
#define atomic_fetch_sub_explicit(p, v, o) atomicSub((u32*)(p), v)
#define atomic_fetch_and_explicit(p, v, o) atomicAnd((u32*)(p), v)
#define atomic_fetch_or_explicit(p, v, o) atomicOr((u32*)(p), v)
#define atomic_fetch_xor_explicit(p, v, o) atomicXor((u32*)(p), v)
#define atomic_fetch_min_explicit(p, v, o) atomicMin((u32*)(p), v)
#define atomic_fetch_max_explicit(p, v, o) atomicMax((u32*)(p), v)
#define atomic_compare_exchange_weak_explicit(p, e, v, s, f) a32_swp(p, e, v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#else

#define A32(p) ((_Atomic u32*)(p))
#define atomic_fetch_min_explicit __c11_atomic_fetch_min
#define atomic_fetch_max_explicit __c11_atomic_fetch_max

#endif

#endif

#define RLX memory_order_relaxed

#if DEVICE
#define REL RLX
#define ACQ RLX
#define ACR RLX
#define a32_acq(p) FENCE()
#define w64_load(p) (*(p))
#else
#define REL memory_order_release
#define ACQ memory_order_acquire
#define ACR memory_order_acq_rel
#define a32_acq(p) ((void)a32_load_acq(p))
#define w64_load(p) atomic_load_explicit((_Atomic u64*)(p), RLX)
#endif

#define a32_store(p, v)     atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v) atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v) atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_and(p, v) atomic_fetch_and_explicit(A32(p), v, RLX)
#define a32_or(p, v) atomic_fetch_or_explicit(A32(p), v, RLX)
#define a32_xor(p, v) atomic_fetch_xor_explicit(A32(p), v, RLX)
#define a32_min(p, v) atomic_fetch_min_explicit(A32(p), v, RLX)
#define a32_max(p, v) atomic_fetch_max_explicit(A32(p), v, RLX)
#define a32_sub_rel(p, v)   (FENCE(), atomic_fetch_sub_explicit(A32(p), v, REL))
#define a32_store_rel(p, v) (FENCE(), atomic_store_explicit(A32(p), v, REL))
#define a32_at(H, word)     ((DEV u32*)&(H)[word])

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = DEVICE ? a32_load(p) : atomic_load_explicit(A32(p), ACQ);
  FENCE();
  return v;
}

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = atomic_compare_exchange_weak_explicit(A32(p), e, v, ACR, ACQ);
  FENCE();
  return ok;
}

A32_LOOP(exch, v)

INLINE u32 a32_cmpx(DEV u32* p, u32 x, u32 v) {
  u32 o = x;
  while (!a32_cas(p, &o, v) && o == x) {
  }
  return o;
}

// Err
// ===

#if DEVICE

INLINE void err_post(DEV u64* H, u32 code) {
  a32_cmpx(a32_at(H, H_ERROR_CODE), 0, code);
}

#else

static const char* ERR_TEXT[] = { "",
  "runtime fail-stop",
  "runtime fail-stop",
  "out of memory: run again with a bigger span, as in --gpu 8GB",
  "a function the device does not hold",
  "a Nat past the largest immediate 2^48-1",
  "runtime fail-stop",
  "memory fault (machine stack overflow?)",
  "an array past the deepest block class 31",
  "a value has more than 2^24-1 live copies: keep fewer alive at once, or build it again for some of them (each build counts its own copies)" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(u64* H, u32 code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  err_post(NULL, ERR_DEEP);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#if __METAL_VERSION__ >= 320
#define err_peek(H) *(volatile DEV u32*)a32_at(H, H_ERROR_CODE)
#else
#define err_peek err_seen
#endif

#ifdef __METAL_VERSION__
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))
#else
#define U32_QUO(a, b) ((a) / (b))
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE u64 f32_to_u32(u64 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE u64 nat_chk(Env e, u64 n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE u64 nat_mul(Env e, u64 a, u64 b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

A32_LOOP(fadd, f32_rewrap(f32_unbox(o) + f32_unbox(v)))

// Bank
// ====

// A stack of exact generations per class. The host pops and pushes at rd;
// a device pass pops below rd and pushes above top, compacted after it.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE u64 bank_pop(DEV u64* H, u32 c) {
  DEV Bank* b = bank_at(H, c);
  u64 got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(DEV u64* H, u32 c, u64 head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class: HOT, a LIFO free chain; LEN, its length in words;
// on the host COLD, one parked generation. A host free reaching KEEP_WORDS
// parks HOT as COLD and banks the old COLD. A miss takes COLD, a bank entry
// or a fresh quantum. A device lane banks its complete generations at the
// kernel end (dev_cut). The bump grows only when all of these are empty.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, NCLS_ALL + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * NCLS_ALL + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

INLINE u32 cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

OUTLINE void heap_hand(Env e, u32 cls) {
  u64 cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(u64* H, u64 need);
#endif

OUTLINE u64 heap_alloc_miss(Env e, u32 cls) {
  DEV u64* H = e.mem;
  u64  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      return HEAP_OFF;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE u64 heap_alloc(Env e, u32 cls) {
  u64 h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, u32 cls, u64 loc) {
  if (err_peek(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

INLINE void spare_free(Env e, u32 cls, u64 loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, u32 cls, u64 loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE u64 term_loc(Term t) {
  return t & LOC_MASK;
}

INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  u64 r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

INLINE void rfc_bump(Env e, u64 r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_CNTS);
  }
}

INLINE Term term_keep(Env e, Term t, u32 k) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), k);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1 + k);
}

// A redirect cell holds its target's loc over a 24-bit count, which only
// atomic adds on the low word change: the loc bits never do. The host reads
// the cell in one relaxed 64-bit load; the device's plain load may tear into
// two halves, both holding the same loc. A shared node's fields never change
// either, so ctr_take copies them before it acquires.
INLINE u64 term_peek(DEV u64* H, Term t) {
  if (term_rfc(t)) {
    return w64_load(&H[term_loc(t)]) >> 24;
  }
  return term_loc(t);
}

#define blk_shr(t) (BLK_SHR && term_rfc(t))

#define blk_loc(H, a) (BLK_SHR ? term_peek(H, a) : term_loc(a))

INLINE u32 blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

INLINE u32 blk_wcls(bool arr, u32 c) {
  return arr ? c : c == 0 ? 0 : c - 1;
}

INLINE u32 blk_span(Term t) {
  return blk_wcls(term_tag(t) == TAG_ARR, blk_cls(t));
}

FAR void term_drop(Env e, Term t) {
  DEV u64* H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      u64      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        heap_free(e, blk_span(t), term_loc(t));
      } else {
        u32 aux = (u32)term_aux(t);
        u64 loc = term_loc(t);
        u32 n   = tag == TAG_ARR ? 0 : tag == TAG_CTR ? cid_arity(aux)
          : fid_arity(aux) - (tag == TAG_CLO);
        u32 cls = tag == TAG_ARR ? 64 | blk_cls(t)
          : n > 247 ? 64 | (n - 240)
          : cls_fit(tag == TAG_TSK ? n + 2 : n);
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step) || cur == 0) {
        return;
      }
      u64  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      u32  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, u64 src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE u64 ctr_take(Env e, Term t, u32 n, THR Term* out) {
  DEV u64* H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  u64 src = term_peek(H, t);
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  DEV u32* c = a32_at(H, term_loc(t));
  if ((a32_load(c) & RFC_CNT) == 1) {
    a32_acq(c);
    heap_free(e, 0, term_loc(t));
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    u64 l = term_peek(e.mem, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

// A block owns one allocation in its class (an ARR 2^c Terms, a BUF 2^c
// u32). Matching ANode is blk_half twice (the high call frees the source);
// ANode{l, r} is blk_node; Array.clone is blk_copy.

#define BLK_ALLOC(n, w) \
  u64 n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(DEV u64* H, u64 loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(DEV u64* H, bool arr, u64 loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(DEV u64* H, bool arr, u64 loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, u64 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, u64 at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w, 1);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

INLINE void blk_fill(Env e, u64 dst, u64 src, u64 n, bool keep) {
  for (u64 j = 0; j < n; j += 1) {
    e.mem[dst + j] = keep ? blk_keep(e, src + j) : e.mem[src + j];
  }
}

INLINE void blk_free(Env e, Term t) {
  blk_shr(t) ? term_drop(e, t) : heap_free(e, blk_span(t), term_loc(t));
}

OUTLINE Term blk_copy(Env e, Term a) {
  bool arr = term_tag(a) == TAG_ARR;
  u32 cls = blk_span(a);
  BLK_ALLOC(dst, cls)
  blk_fill(e, dst, blk_loc(e.mem, a), 1ull << cls, arr);
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  DEV u64* H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  u32 c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  u64 pl = blk_loc(H, l);
  u64 pr = blk_loc(H, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    blk_fill(e, n, pl, cw, arr && blk_shr(l));
    blk_fill(e, n + cw, pr, cw, arr && blk_shr(r));
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  DEV u64* H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  u32 c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  u32 cw = blk_wcls(arr, c);
  u64 src = blk_loc(H, a);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, src, hi);
  } else {
    blk_fill(e, n, src + ((u64)hi << cw), 1ull << cw, arr && blk_shr(a));
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, u64 d, u32 lgs, u32 n, THR Term* v) {
  DEV u64* H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  u32 c = (u32)d + lgs;
  BLK_ALLOC(l, blk_wcls(arr, c))
  for (u32 j = 0; arr && d > 0 && j < n; j += 1) {
    if (d >= 24 && !term_triv(v[j])) {
      err_post(H, ERR_CNTS);
    }
    v[j] = term_keep(e, v[j], (1u << d) - 1);
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// Ring
// ====

#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))
#define ring_held(H, r)    (ring_put(H, r) + 1)

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(DEV u64* H, u32 r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE u32 ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (a32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE u64 task_node(Env e, u32 fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  u64 loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE u64 task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(DEV u64* H, Term cont, u32 idx, THR Term* v, u32 n) {
  u64 at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  u64 tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(DEV u64* H, Term join, u32 base, u32 stride, TG u32* cur) {
  u64 loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      ring_push(H, stride != 0 ? ring_pick(base, stride, cur)
        : ring_flip(g & (u32)(LANES - 1)), k);
      g += 1;
    }
  }
}

// Root
// ====

INLINE bool root_done(DEV u64* H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(DEV u64* H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 32ull, term_pak(CID_SNIL, 0), 58ull, term_ctr(CID_SCON, STAT_OFF + 0), 100ull, term_ctr(CID_SCON, STAT_OFF + 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 4), 101ull, term_ctr(CID_SCON, STAT_OFF + 6), 114ull, term_ctr(CID_SCON, STAT_OFF + 8), 100ull, term_pak(CID_SNIL, 0), 110ull, term_ctr(CID_SCON, STAT_OFF + 12), 101ull, term_ctr(CID_SCON, STAT_OFF + 14), 98ull, term_ctr(CID_SCON, STAT_OFF + 16), 46ull, term_ctr(CID_SCON, STAT_OFF + 18), 101ull, term_ctr(CID_SCON, STAT_OFF + 20), 115ull, term_ctr(CID_SCON, STAT_OFF + 22), 97ull, term_ctr(CID_SCON, STAT_OFF + 24), 98ull, term_ctr(CID_SCON, STAT_OFF + 26), 102ull, term_pak(CID_SNIL, 0), 99ull, term_ctr(CID_SCON, STAT_OFF + 30), 97ull, term_ctr(CID_SCON, STAT_OFF + 32), 102ull, term_ctr(CID_SCON, STAT_OFF + 34), 55ull, term_ctr(CID_SCON, STAT_OFF + 36), 102ull, term_ctr(CID_SCON, STAT_OFF + 38), 54ull, term_ctr(CID_SCON, STAT_OFF + 40), 54ull, term_ctr(CID_SCON, STAT_OFF + 42), 97ull, term_ctr(CID_SCON, STAT_OFF + 44), 102ull, term_ctr(CID_SCON, STAT_OFF + 46), 51ull, term_ctr(CID_SCON, STAT_OFF + 48), 55ull, term_ctr(CID_SCON, STAT_OFF + 50), 57ull, term_ctr(CID_SCON, STAT_OFF + 52), 54ull, term_ctr(CID_SCON, STAT_OFF + 54), 100ull, term_ctr(CID_SCON, STAT_OFF + 56), 55ull, term_ctr(CID_SCON, STAT_OFF + 58), 50ull, term_ctr(CID_SCON, STAT_OFF + 60), 56ull, term_ctr(CID_SCON, STAT_OFF + 62), 99ull, term_ctr(CID_SCON, STAT_OFF + 64), 57ull, term_ctr(CID_SCON, STAT_OFF + 66), 54ull, term_ctr(CID_SCON, STAT_OFF + 68), 57ull, term_ctr(CID_SCON, STAT_OFF + 70), 51ull, term_ctr(CID_SCON, STAT_OFF + 72), 49ull, term_ctr(CID_SCON, STAT_OFF + 74), 101ull, term_ctr(CID_SCON, STAT_OFF + 76), 99ull, term_ctr(CID_SCON, STAT_OFF + 78), 57ull, term_ctr(CID_SCON, STAT_OFF + 80), 52ull, term_ctr(CID_SCON, STAT_OFF + 82), 55ull, term_ctr(CID_SCON, STAT_OFF + 84), 52ull, term_ctr(CID_SCON, STAT_OFF + 86), 52ull, term_ctr(CID_SCON, STAT_OFF + 88), 98ull, term_ctr(CID_SCON, STAT_OFF + 90), 99ull, term_ctr(CID_SCON, STAT_OFF + 92), 51ull, term_ctr(CID_SCON, STAT_OFF + 94), 100ull, term_ctr(CID_SCON, STAT_OFF + 96), 98ull, term_ctr(CID_SCON, STAT_OFF + 98), 98ull, term_ctr(CID_SCON, STAT_OFF + 100), 99ull, term_ctr(CID_SCON, STAT_OFF + 102), 101ull, term_ctr(CID_SCON, STAT_OFF + 104), 99ull, term_ctr(CID_SCON, STAT_OFF + 106), 100ull, term_ctr(CID_SCON, STAT_OFF + 108), 101ull, term_ctr(CID_SCON, STAT_OFF + 110), 99ull, term_ctr(CID_SCON, STAT_OFF + 112), 100ull, term_ctr(CID_SCON, STAT_OFF + 114), 99ull, term_ctr(CID_SCON, STAT_OFF + 116), 97ull, term_ctr(CID_SCON, STAT_OFF + 118), 57ull, term_ctr(CID_SCON, STAT_OFF + 120), 51ull, term_ctr(CID_SCON, STAT_OFF + 122), 102ull, term_ctr(CID_SCON, STAT_OFF + 124), 51ull, term_ctr(CID_SCON, STAT_OFF + 126), 101ull, term_ctr(CID_SCON, STAT_OFF + 128), 51ull, term_ctr(CID_SCON, STAT_OFF + 130), 98ull, term_ctr(CID_SCON, STAT_OFF + 132), 98ull, term_ctr(CID_SCON, STAT_OFF + 134), 50ull, term_ctr(CID_SCON, STAT_OFF + 136), 98ull, term_ctr(CID_SCON, STAT_OFF + 138), 50ull, term_ctr(CID_SCON, STAT_OFF + 140), 102ull, term_ctr(CID_SCON, STAT_OFF + 142), 51ull, term_ctr(CID_SCON, STAT_OFF + 144), 52ull, term_ctr(CID_SCON, STAT_OFF + 146), 99ull, term_ctr(CID_SCON, STAT_OFF + 148), 97ull, term_ctr(CID_SCON, STAT_OFF + 150), 57ull, term_ctr(CID_SCON, STAT_OFF + 152), 57ull, term_ctr(CID_SCON, STAT_OFF + 154), 56ull, term_pak(CID_SNIL, 0), 56ull, term_ctr(CID_SCON, STAT_OFF + 158), 112ull, term_ctr(CID_SCON, STAT_OFF + 160), 46ull, term_ctr(CID_SCON, STAT_OFF + 162), 101ull, term_ctr(CID_SCON, STAT_OFF + 164), 115ull, term_ctr(CID_SCON, STAT_OFF + 166), 97ull, term_ctr(CID_SCON, STAT_OFF + 168), 98ull, term_ctr(CID_SCON, STAT_OFF + 170), 55ull, term_pak(CID_SNIL, 0), 97ull, term_ctr(CID_SCON, STAT_OFF + 174), 54ull, term_ctr(CID_SCON, STAT_OFF + 176), 56ull, term_ctr(CID_SCON, STAT_OFF + 178), 49ull, term_ctr(CID_SCON, STAT_OFF + 180), 98ull, term_ctr(CID_SCON, STAT_OFF + 182), 56ull, term_ctr(CID_SCON, STAT_OFF + 184), 100ull, term_ctr(CID_SCON, STAT_OFF + 186), 57ull, term_ctr(CID_SCON, STAT_OFF + 188), 52ull, term_ctr(CID_SCON, STAT_OFF + 190), 49ull, term_ctr(CID_SCON, STAT_OFF + 192), 53ull, term_ctr(CID_SCON, STAT_OFF + 194), 50ull, term_ctr(CID_SCON, STAT_OFF + 196), 57ull, term_ctr(CID_SCON, STAT_OFF + 198), 99ull, term_ctr(CID_SCON, STAT_OFF + 200), 55ull, term_ctr(CID_SCON, STAT_OFF + 202), 57ull, term_ctr(CID_SCON, STAT_OFF + 204), 53ull, term_ctr(CID_SCON, STAT_OFF + 206), 100ull, term_ctr(CID_SCON, STAT_OFF + 208), 55ull, term_ctr(CID_SCON, STAT_OFF + 210), 101ull, term_ctr(CID_SCON, STAT_OFF + 212), 100ull, term_ctr(CID_SCON, STAT_OFF + 214), 57ull, term_ctr(CID_SCON, STAT_OFF + 216), 49ull, term_ctr(CID_SCON, STAT_OFF + 218), 51ull, term_ctr(CID_SCON, STAT_OFF + 220), 57ull, term_ctr(CID_SCON, STAT_OFF + 222), 97ull, term_ctr(CID_SCON, STAT_OFF + 224), 52ull, term_ctr(CID_SCON, STAT_OFF + 226), 54ull, term_ctr(CID_SCON, STAT_OFF + 228), 97ull, term_ctr(CID_SCON, STAT_OFF + 230), 52ull, term_ctr(CID_SCON, STAT_OFF + 232), 53ull, term_ctr(CID_SCON, STAT_OFF + 234), 55ull, term_ctr(CID_SCON, STAT_OFF + 236), 55ull, term_ctr(CID_SCON, STAT_OFF + 238), 48ull, term_ctr(CID_SCON, STAT_OFF + 240), 57ull, term_ctr(CID_SCON, STAT_OFF + 242), 53ull, term_ctr(CID_SCON, STAT_OFF + 244), 55ull, term_ctr(CID_SCON, STAT_OFF + 246), 52ull, term_ctr(CID_SCON, STAT_OFF + 248), 57ull, term_ctr(CID_SCON, STAT_OFF + 250), 100ull, term_ctr(CID_SCON, STAT_OFF + 252), 53ull, term_ctr(CID_SCON, STAT_OFF + 254), 102ull, term_ctr(CID_SCON, STAT_OFF + 256), 57ull, term_ctr(CID_SCON, STAT_OFF + 258), 99ull, term_ctr(CID_SCON, STAT_OFF + 260), 102ull, term_ctr(CID_SCON, STAT_OFF + 262), 49ull, term_ctr(CID_SCON, STAT_OFF + 264), 54ull, term_ctr(CID_SCON, STAT_OFF + 266), 56ull, term_ctr(CID_SCON, STAT_OFF + 268), 100ull, term_ctr(CID_SCON, STAT_OFF + 270), 48ull, term_ctr(CID_SCON, STAT_OFF + 272), 50ull, term_ctr(CID_SCON, STAT_OFF + 274), 56ull, term_ctr(CID_SCON, STAT_OFF + 276), 52ull, term_ctr(CID_SCON, STAT_OFF + 278), 56ull, term_ctr(CID_SCON, STAT_OFF + 280), 98ull, term_ctr(CID_SCON, STAT_OFF + 282), 100ull, term_ctr(CID_SCON, STAT_OFF + 284), 100ull, term_ctr(CID_SCON, STAT_OFF + 286), 99ull, term_ctr(CID_SCON, STAT_OFF + 288), 56ull, term_ctr(CID_SCON, STAT_OFF + 290), 102ull, term_ctr(CID_SCON, STAT_OFF + 292), 97ull, term_ctr(CID_SCON, STAT_OFF + 294), 55ull, term_ctr(CID_SCON, STAT_OFF + 296), 48ull, term_ctr(CID_SCON, STAT_OFF + 298), 48ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 302), 114ull, term_ctr(CID_SCON, STAT_OFF + 304), 97ull, term_ctr(CID_SCON, STAT_OFF + 306), 112ull, term_ctr(CID_SCON, STAT_OFF + 308), 46ull, term_ctr(CID_SCON, STAT_OFF + 310), 99ull, term_ctr(CID_SCON, STAT_OFF + 312), 46ull, term_ctr(CID_SCON, STAT_OFF + 314), 101ull, term_ctr(CID_SCON, STAT_OFF + 316), 109ull, term_ctr(CID_SCON, STAT_OFF + 318), 105ull, term_ctr(CID_SCON, STAT_OFF + 320), 116ull, term_ctr(CID_SCON, STAT_OFF + 322), 110ull, term_ctr(CID_SCON, STAT_OFF + 324), 117ull, term_ctr(CID_SCON, STAT_OFF + 326), 114ull, term_ctr(CID_SCON, STAT_OFF + 328), 99ull, term_ctr(CID_SCON, STAT_OFF + 302), 50ull, term_ctr(CID_SCON, STAT_OFF + 332), 55ull, term_ctr(CID_SCON, STAT_OFF + 334), 50ull, term_ctr(CID_SCON, STAT_OFF + 336), 49ull, term_ctr(CID_SCON, STAT_OFF + 338), 54ull, term_ctr(CID_SCON, STAT_OFF + 340), 101ull, term_ctr(CID_SCON, STAT_OFF + 342), 100ull, term_ctr(CID_SCON, STAT_OFF + 344), 49ull, term_ctr(CID_SCON, STAT_OFF + 346), 100ull, term_ctr(CID_SCON, STAT_OFF + 348), 98ull, term_ctr(CID_SCON, STAT_OFF + 350), 48ull, term_ctr(CID_SCON, STAT_OFF + 352), 48ull, term_ctr(CID_SCON, STAT_OFF + 354), 56ull, term_ctr(CID_SCON, STAT_OFF + 356), 57ull, term_ctr(CID_SCON, STAT_OFF + 358), 102ull, term_ctr(CID_SCON, STAT_OFF + 360), 49ull, term_ctr(CID_SCON, STAT_OFF + 362), 48ull, term_ctr(CID_SCON, STAT_OFF + 364), 56ull, term_ctr(CID_SCON, STAT_OFF + 366), 97ull, term_ctr(CID_SCON, STAT_OFF + 368), 53ull, term_ctr(CID_SCON, STAT_OFF + 370), 55ull, term_ctr(CID_SCON, STAT_OFF + 372), 54ull, term_ctr(CID_SCON, STAT_OFF + 374), 97ull, term_ctr(CID_SCON, STAT_OFF + 376), 54ull, term_ctr(CID_SCON, STAT_OFF + 378), 98ull, term_ctr(CID_SCON, STAT_OFF + 380), 100ull, term_ctr(CID_SCON, STAT_OFF + 382), 57ull, term_ctr(CID_SCON, STAT_OFF + 384), 50ull, term_ctr(CID_SCON, STAT_OFF + 386), 53ull, term_ctr(CID_SCON, STAT_OFF + 388), 98ull, term_ctr(CID_SCON, STAT_OFF + 390), 99ull, term_ctr(CID_SCON, STAT_OFF + 392), 57ull, term_ctr(CID_SCON, STAT_OFF + 394), 54ull, term_ctr(CID_SCON, STAT_OFF + 396), 55ull, term_ctr(CID_SCON, STAT_OFF + 398), 55ull, term_ctr(CID_SCON, STAT_OFF + 400), 56ull, term_ctr(CID_SCON, STAT_OFF + 402), 52ull, term_ctr(CID_SCON, STAT_OFF + 404), 53ull, term_ctr(CID_SCON, STAT_OFF + 406), 57ull, term_ctr(CID_SCON, STAT_OFF + 408), 97ull, term_ctr(CID_SCON, STAT_OFF + 410), 57ull, term_ctr(CID_SCON, STAT_OFF + 412), 55ull, term_ctr(CID_SCON, STAT_OFF + 414), 98ull, term_ctr(CID_SCON, STAT_OFF + 416), 100ull, term_ctr(CID_SCON, STAT_OFF + 418), 100ull, term_ctr(CID_SCON, STAT_OFF + 420), 101ull, term_ctr(CID_SCON, STAT_OFF + 422), 48ull, term_ctr(CID_SCON, STAT_OFF + 424), 52ull, term_ctr(CID_SCON, STAT_OFF + 426), 55ull, term_ctr(CID_SCON, STAT_OFF + 428), 102ull, term_ctr(CID_SCON, STAT_OFF + 430), 56ull, term_ctr(CID_SCON, STAT_OFF + 432), 100ull, term_ctr(CID_SCON, STAT_OFF + 434), 56ull, term_ctr(CID_SCON, STAT_OFF + 436), 56ull, term_ctr(CID_SCON, STAT_OFF + 438), 53ull, term_ctr(CID_SCON, STAT_OFF + 440), 54ull, term_ctr(CID_SCON, STAT_OFF + 442), 55ull, term_ctr(CID_SCON, STAT_OFF + 444), 98ull, term_ctr(CID_SCON, STAT_OFF + 446), 52ull, term_ctr(CID_SCON, STAT_OFF + 448), 55ull, term_ctr(CID_SCON, STAT_OFF + 450), 48ull, term_ctr(CID_SCON, STAT_OFF + 452), 102ull, term_ctr(CID_SCON, STAT_OFF + 454), 49ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 458), 114ull, term_ctr(CID_SCON, STAT_OFF + 460), 97ull, term_ctr(CID_SCON, STAT_OFF + 462), 112ull, term_ctr(CID_SCON, STAT_OFF + 464), 46ull, term_ctr(CID_SCON, STAT_OFF + 466), 99ull, term_ctr(CID_SCON, STAT_OFF + 468), 46ull, term_ctr(CID_SCON, STAT_OFF + 470), 101ull, term_ctr(CID_SCON, STAT_OFF + 472), 109ull, term_ctr(CID_SCON, STAT_OFF + 474), 105ull, term_ctr(CID_SCON, STAT_OFF + 476), 116ull, term_ctr(CID_SCON, STAT_OFF + 478), 110ull, term_ctr(CID_SCON, STAT_OFF + 480), 117ull, term_ctr(CID_SCON, STAT_OFF + 482), 114ull, term_ctr(CID_SCON, STAT_OFF + 484), 53ull, term_pak(CID_SNIL, 0), 50ull, term_ctr(CID_SCON, STAT_OFF + 488), 49ull, term_ctr(CID_SCON, STAT_OFF + 490), 57ull, term_ctr(CID_SCON, STAT_OFF + 492), 49ull, term_ctr(CID_SCON, STAT_OFF + 494), 97ull, term_ctr(CID_SCON, STAT_OFF + 496), 101ull, term_ctr(CID_SCON, STAT_OFF + 498), 51ull, term_ctr(CID_SCON, STAT_OFF + 500), 53ull, term_ctr(CID_SCON, STAT_OFF + 502), 56ull, term_ctr(CID_SCON, STAT_OFF + 504), 100ull, term_ctr(CID_SCON, STAT_OFF + 506), 53ull, term_ctr(CID_SCON, STAT_OFF + 508), 102ull, term_ctr(CID_SCON, STAT_OFF + 510), 57ull, term_ctr(CID_SCON, STAT_OFF + 512), 52ull, term_ctr(CID_SCON, STAT_OFF + 514), 98ull, term_ctr(CID_SCON, STAT_OFF + 516), 98ull, term_ctr(CID_SCON, STAT_OFF + 518), 99ull, term_ctr(CID_SCON, STAT_OFF + 520), 49ull, term_ctr(CID_SCON, STAT_OFF + 522), 48ull, term_ctr(CID_SCON, STAT_OFF + 524), 51ull, term_ctr(CID_SCON, STAT_OFF + 526), 57ull, term_ctr(CID_SCON, STAT_OFF + 528), 53ull, term_ctr(CID_SCON, STAT_OFF + 530), 97ull, term_ctr(CID_SCON, STAT_OFF + 532), 56ull, term_ctr(CID_SCON, STAT_OFF + 534), 98ull, term_ctr(CID_SCON, STAT_OFF + 536), 54ull, term_ctr(CID_SCON, STAT_OFF + 538), 57ull, term_ctr(CID_SCON, STAT_OFF + 540), 48ull, term_ctr(CID_SCON, STAT_OFF + 542), 50ull, term_ctr(CID_SCON, STAT_OFF + 544), 49ull, term_ctr(CID_SCON, STAT_OFF + 546), 53ull, term_ctr(CID_SCON, STAT_OFF + 548), 55ull, term_ctr(CID_SCON, STAT_OFF + 550), 102ull, term_ctr(CID_SCON, STAT_OFF + 552), 50ull, term_ctr(CID_SCON, STAT_OFF + 554), 49ull, term_ctr(CID_SCON, STAT_OFF + 556), 51ull, term_ctr(CID_SCON, STAT_OFF + 558), 48ull, term_ctr(CID_SCON, STAT_OFF + 560), 102ull, term_ctr(CID_SCON, STAT_OFF + 562), 53ull, term_ctr(CID_SCON, STAT_OFF + 564), 100ull, term_ctr(CID_SCON, STAT_OFF + 566), 52ull, term_ctr(CID_SCON, STAT_OFF + 568), 99ull, term_ctr(CID_SCON, STAT_OFF + 570), 54ull, term_ctr(CID_SCON, STAT_OFF + 572), 50ull, term_ctr(CID_SCON, STAT_OFF + 574), 51ull, term_ctr(CID_SCON, STAT_OFF + 576), 98ull, term_ctr(CID_SCON, STAT_OFF + 578), 53ull, term_ctr(CID_SCON, STAT_OFF + 580), 54ull, term_ctr(CID_SCON, STAT_OFF + 582), 49ull, term_ctr(CID_SCON, STAT_OFF + 584), 52ull, term_ctr(CID_SCON, STAT_OFF + 586), 50ull, term_ctr(CID_SCON, STAT_OFF + 588), 54ull, term_ctr(CID_SCON, STAT_OFF + 590), 51ull, term_ctr(CID_SCON, STAT_OFF + 592), 51ull, term_ctr(CID_SCON, STAT_OFF + 594), 53ull, term_ctr(CID_SCON, STAT_OFF + 596), 97ull, term_ctr(CID_SCON, STAT_OFF + 598), 53ull, term_ctr(CID_SCON, STAT_OFF + 600), 49ull, term_ctr(CID_SCON, STAT_OFF + 602), 56ull, term_ctr(CID_SCON, STAT_OFF + 604), 99ull, term_ctr(CID_SCON, STAT_OFF + 606), 100ull, term_ctr(CID_SCON, STAT_OFF + 608), 53ull, term_ctr(CID_SCON, STAT_OFF + 610), 98ull, term_ctr(CID_SCON, STAT_OFF + 612), 50ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 616), 114ull, term_ctr(CID_SCON, STAT_OFF + 618), 97ull, term_ctr(CID_SCON, STAT_OFF + 620), 112ull, term_ctr(CID_SCON, STAT_OFF + 622), 46ull, term_ctr(CID_SCON, STAT_OFF + 624), 99ull, term_ctr(CID_SCON, STAT_OFF + 626), 46ull, term_ctr(CID_SCON, STAT_OFF + 628), 101ull, term_ctr(CID_SCON, STAT_OFF + 630), 109ull, term_ctr(CID_SCON, STAT_OFF + 632), 105ull, term_ctr(CID_SCON, STAT_OFF + 634), 116ull, term_ctr(CID_SCON, STAT_OFF + 636), 110ull, term_ctr(CID_SCON, STAT_OFF + 638), 117ull, term_ctr(CID_SCON, STAT_OFF + 640), 114ull, term_ctr(CID_SCON, STAT_OFF + 642), 49ull, term_ctr(CID_SCON, STAT_OFF + 12), 52ull, term_ctr(CID_SCON, STAT_OFF + 646), 98ull, term_ctr(CID_SCON, STAT_OFF + 648), 48ull, term_ctr(CID_SCON, STAT_OFF + 650), 102ull, term_ctr(CID_SCON, STAT_OFF + 652), 98ull, term_ctr(CID_SCON, STAT_OFF + 654), 53ull, term_ctr(CID_SCON, STAT_OFF + 656), 97ull, term_ctr(CID_SCON, STAT_OFF + 658), 57ull, term_ctr(CID_SCON, STAT_OFF + 660), 98ull, term_ctr(CID_SCON, STAT_OFF + 662), 54ull, term_ctr(CID_SCON, STAT_OFF + 664), 48ull, term_ctr(CID_SCON, STAT_OFF + 666), 54ull, term_ctr(CID_SCON, STAT_OFF + 668), 55ull, term_ctr(CID_SCON, STAT_OFF + 670), 55ull, term_ctr(CID_SCON, STAT_OFF + 672), 53ull, term_ctr(CID_SCON, STAT_OFF + 674), 54ull, term_ctr(CID_SCON, STAT_OFF + 676), 100ull, term_ctr(CID_SCON, STAT_OFF + 678), 55ull, term_ctr(CID_SCON, STAT_OFF + 680), 53ull, term_ctr(CID_SCON, STAT_OFF + 682), 54ull, term_ctr(CID_SCON, STAT_OFF + 684), 48ull, term_ctr(CID_SCON, STAT_OFF + 686), 50ull, term_ctr(CID_SCON, STAT_OFF + 688), 48ull, term_ctr(CID_SCON, STAT_OFF + 690), 57ull, term_ctr(CID_SCON, STAT_OFF + 692), 97ull, term_ctr(CID_SCON, STAT_OFF + 694), 100ull, term_ctr(CID_SCON, STAT_OFF + 696), 51ull, term_ctr(CID_SCON, STAT_OFF + 698), 57ull, term_ctr(CID_SCON, STAT_OFF + 700), 49ull, term_ctr(CID_SCON, STAT_OFF + 702), 101ull, term_ctr(CID_SCON, STAT_OFF + 704), 55ull, term_ctr(CID_SCON, STAT_OFF + 706), 54ull, term_ctr(CID_SCON, STAT_OFF + 708), 100ull, term_ctr(CID_SCON, STAT_OFF + 710), 55ull, term_ctr(CID_SCON, STAT_OFF + 712), 49ull, term_ctr(CID_SCON, STAT_OFF + 714), 98ull, term_ctr(CID_SCON, STAT_OFF + 716), 54ull, term_ctr(CID_SCON, STAT_OFF + 718), 53ull, term_ctr(CID_SCON, STAT_OFF + 720), 100ull, term_ctr(CID_SCON, STAT_OFF + 722), 98ull, term_ctr(CID_SCON, STAT_OFF + 724), 102ull, term_ctr(CID_SCON, STAT_OFF + 726), 97ull, term_ctr(CID_SCON, STAT_OFF + 728), 51ull, term_ctr(CID_SCON, STAT_OFF + 730), 49ull, term_ctr(CID_SCON, STAT_OFF + 732), 50ull, term_ctr(CID_SCON, STAT_OFF + 734), 52ull, term_ctr(CID_SCON, STAT_OFF + 736), 98ull, term_ctr(CID_SCON, STAT_OFF + 738), 52ull, term_ctr(CID_SCON, STAT_OFF + 740), 48ull, term_ctr(CID_SCON, STAT_OFF + 742), 52ull, term_ctr(CID_SCON, STAT_OFF + 744), 48ull, term_ctr(CID_SCON, STAT_OFF + 746), 49ull, term_ctr(CID_SCON, STAT_OFF + 748), 48ull, term_ctr(CID_SCON, STAT_OFF + 750), 97ull, term_ctr(CID_SCON, STAT_OFF + 752), 101ull, term_ctr(CID_SCON, STAT_OFF + 754), 57ull, term_ctr(CID_SCON, STAT_OFF + 756), 51ull, term_ctr(CID_SCON, STAT_OFF + 758), 97ull, term_ctr(CID_SCON, STAT_OFF + 760), 56ull, term_ctr(CID_SCON, STAT_OFF + 762), 48ull, term_ctr(CID_SCON, STAT_OFF + 764), 56ull, term_ctr(CID_SCON, STAT_OFF + 766), 57ull, term_ctr(CID_SCON, STAT_OFF + 768), 51ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 772), 114ull, term_ctr(CID_SCON, STAT_OFF + 774), 97ull, term_ctr(CID_SCON, STAT_OFF + 776), 112ull, term_ctr(CID_SCON, STAT_OFF + 778), 46ull, term_ctr(CID_SCON, STAT_OFF + 780), 99ull, term_ctr(CID_SCON, STAT_OFF + 782), 46ull, term_ctr(CID_SCON, STAT_OFF + 784), 101ull, term_ctr(CID_SCON, STAT_OFF + 786), 109ull, term_ctr(CID_SCON, STAT_OFF + 788), 105ull, term_ctr(CID_SCON, STAT_OFF + 790), 116ull, term_ctr(CID_SCON, STAT_OFF + 792), 110ull, term_ctr(CID_SCON, STAT_OFF + 794), 117ull, term_ctr(CID_SCON, STAT_OFF + 796), 114ull, term_ctr(CID_SCON, STAT_OFF + 798), 57ull, term_pak(CID_SNIL, 0), 48ull, term_ctr(CID_SCON, STAT_OFF + 802), 100ull, term_ctr(CID_SCON, STAT_OFF + 804), 97ull, term_ctr(CID_SCON, STAT_OFF + 806), 102ull, term_ctr(CID_SCON, STAT_OFF + 808), 57ull, term_ctr(CID_SCON, STAT_OFF + 810), 55ull, term_ctr(CID_SCON, STAT_OFF + 812), 54ull, term_ctr(CID_SCON, STAT_OFF + 814), 102ull, term_ctr(CID_SCON, STAT_OFF + 816), 48ull, term_ctr(CID_SCON, STAT_OFF + 818), 48ull, term_ctr(CID_SCON, STAT_OFF + 820), 102ull, term_ctr(CID_SCON, STAT_OFF + 822), 101ull, term_ctr(CID_SCON, STAT_OFF + 824), 51ull, term_ctr(CID_SCON, STAT_OFF + 826), 52ull, term_ctr(CID_SCON, STAT_OFF + 828), 57ull, term_ctr(CID_SCON, STAT_OFF + 830), 101ull, term_ctr(CID_SCON, STAT_OFF + 832), 52ull, term_ctr(CID_SCON, STAT_OFF + 834), 101ull, term_ctr(CID_SCON, STAT_OFF + 836), 98ull, term_ctr(CID_SCON, STAT_OFF + 838), 100ull, term_ctr(CID_SCON, STAT_OFF + 840), 51ull, term_ctr(CID_SCON, STAT_OFF + 842), 55ull, term_ctr(CID_SCON, STAT_OFF + 844), 98ull, term_ctr(CID_SCON, STAT_OFF + 846), 52ull, term_ctr(CID_SCON, STAT_OFF + 848), 55ull, term_ctr(CID_SCON, STAT_OFF + 850), 48ull, term_ctr(CID_SCON, STAT_OFF + 852), 99ull, term_ctr(CID_SCON, STAT_OFF + 854), 57ull, term_ctr(CID_SCON, STAT_OFF + 856), 49ull, term_ctr(CID_SCON, STAT_OFF + 858), 51ull, term_ctr(CID_SCON, STAT_OFF + 860), 57ull, term_ctr(CID_SCON, STAT_OFF + 862), 98ull, term_ctr(CID_SCON, STAT_OFF + 864), 56ull, term_ctr(CID_SCON, STAT_OFF + 866), 102ull, term_ctr(CID_SCON, STAT_OFF + 868), 53ull, term_ctr(CID_SCON, STAT_OFF + 870), 48ull, term_ctr(CID_SCON, STAT_OFF + 872), 49ull, term_ctr(CID_SCON, STAT_OFF + 874), 102ull, term_ctr(CID_SCON, STAT_OFF + 876), 52ull, term_ctr(CID_SCON, STAT_OFF + 878), 57ull, term_ctr(CID_SCON, STAT_OFF + 880), 54ull, term_ctr(CID_SCON, STAT_OFF + 882), 48ull, term_ctr(CID_SCON, STAT_OFF + 884), 50ull, term_ctr(CID_SCON, STAT_OFF + 886), 49ull, term_ctr(CID_SCON, STAT_OFF + 888), 48ull, term_ctr(CID_SCON, STAT_OFF + 890), 54ull, term_ctr(CID_SCON, STAT_OFF + 892), 99ull, term_ctr(CID_SCON, STAT_OFF + 894), 49ull, term_ctr(CID_SCON, STAT_OFF + 896), 50ull, term_ctr(CID_SCON, STAT_OFF + 898), 54ull, term_ctr(CID_SCON, STAT_OFF + 900), 102ull, term_ctr(CID_SCON, STAT_OFF + 902), 50ull, term_ctr(CID_SCON, STAT_OFF + 904), 55ull, term_ctr(CID_SCON, STAT_OFF + 906), 50ull, term_ctr(CID_SCON, STAT_OFF + 908), 50ull, term_ctr(CID_SCON, STAT_OFF + 910), 48ull, term_ctr(CID_SCON, STAT_OFF + 912), 51ull, term_ctr(CID_SCON, STAT_OFF + 914), 53ull, term_ctr(CID_SCON, STAT_OFF + 916), 98ull, term_ctr(CID_SCON, STAT_OFF + 918), 56ull, term_ctr(CID_SCON, STAT_OFF + 920), 57ull, term_ctr(CID_SCON, STAT_OFF + 922), 102ull, term_ctr(CID_SCON, STAT_OFF + 924), 55ull, term_ctr(CID_SCON, STAT_OFF + 926), 52ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 930), 114ull, term_ctr(CID_SCON, STAT_OFF + 932), 97ull, term_ctr(CID_SCON, STAT_OFF + 934), 112ull, term_ctr(CID_SCON, STAT_OFF + 936), 46ull, term_ctr(CID_SCON, STAT_OFF + 938), 99ull, term_ctr(CID_SCON, STAT_OFF + 940), 46ull, term_ctr(CID_SCON, STAT_OFF + 942), 101ull, term_ctr(CID_SCON, STAT_OFF + 944), 109ull, term_ctr(CID_SCON, STAT_OFF + 946), 105ull, term_ctr(CID_SCON, STAT_OFF + 948), 116ull, term_ctr(CID_SCON, STAT_OFF + 950), 110ull, term_ctr(CID_SCON, STAT_OFF + 952), 117ull, term_ctr(CID_SCON, STAT_OFF + 954), 114ull, term_ctr(CID_SCON, STAT_OFF + 956), 98ull, term_pak(CID_SNIL, 0), 100ull, term_ctr(CID_SCON, STAT_OFF + 960), 57ull, term_ctr(CID_SCON, STAT_OFF + 962), 102ull, term_ctr(CID_SCON, STAT_OFF + 964), 52ull, term_ctr(CID_SCON, STAT_OFF + 966), 52ull, term_ctr(CID_SCON, STAT_OFF + 968), 56ull, term_ctr(CID_SCON, STAT_OFF + 970), 98ull, term_ctr(CID_SCON, STAT_OFF + 972), 98ull, term_ctr(CID_SCON, STAT_OFF + 974), 48ull, term_ctr(CID_SCON, STAT_OFF + 976), 57ull, term_ctr(CID_SCON, STAT_OFF + 978), 53ull, term_ctr(CID_SCON, STAT_OFF + 980), 99ull, term_ctr(CID_SCON, STAT_OFF + 982), 50ull, term_ctr(CID_SCON, STAT_OFF + 984), 48ull, term_ctr(CID_SCON, STAT_OFF + 986), 54ull, term_ctr(CID_SCON, STAT_OFF + 988), 54ull, term_ctr(CID_SCON, STAT_OFF + 990), 51ull, term_ctr(CID_SCON, STAT_OFF + 992), 54ull, term_ctr(CID_SCON, STAT_OFF + 994), 53ull, term_ctr(CID_SCON, STAT_OFF + 996), 48ull, term_ctr(CID_SCON, STAT_OFF + 998), 99ull, term_ctr(CID_SCON, STAT_OFF + 1000), 56ull, term_ctr(CID_SCON, STAT_OFF + 1002), 48ull, term_ctr(CID_SCON, STAT_OFF + 1004), 55ull, term_ctr(CID_SCON, STAT_OFF + 1006), 98ull, term_ctr(CID_SCON, STAT_OFF + 1008), 50ull, term_ctr(CID_SCON, STAT_OFF + 1010), 55ull, term_ctr(CID_SCON, STAT_OFF + 1012), 52ull, term_ctr(CID_SCON, STAT_OFF + 1014), 49ull, term_ctr(CID_SCON, STAT_OFF + 1016), 98ull, term_ctr(CID_SCON, STAT_OFF + 1018), 100ull, term_ctr(CID_SCON, STAT_OFF + 1020), 53ull, term_ctr(CID_SCON, STAT_OFF + 1022), 57ull, term_ctr(CID_SCON, STAT_OFF + 1024), 98ull, term_ctr(CID_SCON, STAT_OFF + 1026), 53ull, term_ctr(CID_SCON, STAT_OFF + 1028), 57ull, term_ctr(CID_SCON, STAT_OFF + 1030), 50ull, term_ctr(CID_SCON, STAT_OFF + 1032), 102ull, term_ctr(CID_SCON, STAT_OFF + 1034), 56ull, term_ctr(CID_SCON, STAT_OFF + 1036), 52ull, term_ctr(CID_SCON, STAT_OFF + 1038), 55ull, term_ctr(CID_SCON, STAT_OFF + 1040), 102ull, term_ctr(CID_SCON, STAT_OFF + 1042), 57ull, term_ctr(CID_SCON, STAT_OFF + 1044), 51ull, term_ctr(CID_SCON, STAT_OFF + 1046), 56ull, term_ctr(CID_SCON, STAT_OFF + 1048), 99ull, term_ctr(CID_SCON, STAT_OFF + 1050), 51ull, term_ctr(CID_SCON, STAT_OFF + 1052), 54ull, term_ctr(CID_SCON, STAT_OFF + 1054), 54ull, term_ctr(CID_SCON, STAT_OFF + 1056), 52ull, term_ctr(CID_SCON, STAT_OFF + 1058), 51ull, term_ctr(CID_SCON, STAT_OFF + 1060), 57ull, term_ctr(CID_SCON, STAT_OFF + 1062), 49ull, term_ctr(CID_SCON, STAT_OFF + 1064), 48ull, term_ctr(CID_SCON, STAT_OFF + 1066), 101ull, term_ctr(CID_SCON, STAT_OFF + 1068), 49ull, term_ctr(CID_SCON, STAT_OFF + 1070), 53ull, term_ctr(CID_SCON, STAT_OFF + 1072), 52ull, term_ctr(CID_SCON, STAT_OFF + 1074), 98ull, term_ctr(CID_SCON, STAT_OFF + 1076), 50ull, term_ctr(CID_SCON, STAT_OFF + 1078), 55ull, term_ctr(CID_SCON, STAT_OFF + 1080), 99ull, term_ctr(CID_SCON, STAT_OFF + 1082), 97ull, term_ctr(CID_SCON, STAT_OFF + 1084), 99ull, term_pak(CID_SNIL, 0), 46ull, term_ctr(CID_SCON, STAT_OFF + 1088), 115ull, term_ctr(CID_SCON, STAT_OFF + 1090), 103ull, term_ctr(CID_SCON, STAT_OFF + 1092), 114ull, term_ctr(CID_SCON, STAT_OFF + 1094), 97ull, term_ctr(CID_SCON, STAT_OFF + 1096), 47ull, term_ctr(CID_SCON, STAT_OFF + 1098), 115ull, term_ctr(CID_SCON, STAT_OFF + 1100), 102ull, term_ctr(CID_SCON, STAT_OFF + 1102), 102ull, term_ctr(CID_SCON, STAT_OFF + 1104), 101ull, term_ctr(CID_SCON, STAT_OFF + 1106), 101ull, term_ctr(CID_SCON, STAT_OFF + 302), 54ull, term_ctr(CID_SCON, STAT_OFF + 1110), 55ull, term_ctr(CID_SCON, STAT_OFF + 1112), 54ull, term_ctr(CID_SCON, STAT_OFF + 1114), 57ull, term_ctr(CID_SCON, STAT_OFF + 1116), 54ull, term_ctr(CID_SCON, STAT_OFF + 1118), 102ull, term_ctr(CID_SCON, STAT_OFF + 1120), 53ull, term_ctr(CID_SCON, STAT_OFF + 1122), 97ull, term_ctr(CID_SCON, STAT_OFF + 1124), 51ull, term_ctr(CID_SCON, STAT_OFF + 1126), 49ull, term_ctr(CID_SCON, STAT_OFF + 1128), 101ull, term_ctr(CID_SCON, STAT_OFF + 1130), 53ull, term_ctr(CID_SCON, STAT_OFF + 1132), 50ull, term_ctr(CID_SCON, STAT_OFF + 1134), 97ull, term_ctr(CID_SCON, STAT_OFF + 1136), 55ull, term_ctr(CID_SCON, STAT_OFF + 1138), 52ull, term_ctr(CID_SCON, STAT_OFF + 1140), 56ull, term_ctr(CID_SCON, STAT_OFF + 1142), 99ull, term_ctr(CID_SCON, STAT_OFF + 1144), 50ull, term_ctr(CID_SCON, STAT_OFF + 1146), 52ull, term_ctr(CID_SCON, STAT_OFF + 1148), 52ull, term_ctr(CID_SCON, STAT_OFF + 1150), 101ull, term_ctr(CID_SCON, STAT_OFF + 1152), 55ull, term_ctr(CID_SCON, STAT_OFF + 1154), 57ull, term_ctr(CID_SCON, STAT_OFF + 1156), 55ull, term_ctr(CID_SCON, STAT_OFF + 1158), 52ull, term_ctr(CID_SCON, STAT_OFF + 1160), 53ull, term_ctr(CID_SCON, STAT_OFF + 1162), 53ull, term_ctr(CID_SCON, STAT_OFF + 1164), 102ull, term_ctr(CID_SCON, STAT_OFF + 1166), 48ull, term_ctr(CID_SCON, STAT_OFF + 1168), 52ull, term_ctr(CID_SCON, STAT_OFF + 1170), 99ull, term_ctr(CID_SCON, STAT_OFF + 1172), 51ull, term_ctr(CID_SCON, STAT_OFF + 1174), 49ull, term_ctr(CID_SCON, STAT_OFF + 1176), 57ull, term_ctr(CID_SCON, STAT_OFF + 1178), 99ull, term_ctr(CID_SCON, STAT_OFF + 1180), 56ull, term_ctr(CID_SCON, STAT_OFF + 1182), 51ull, term_ctr(CID_SCON, STAT_OFF + 1184), 55ull, term_ctr(CID_SCON, STAT_OFF + 1186), 54ull, term_ctr(CID_SCON, STAT_OFF + 1188), 97ull, term_ctr(CID_SCON, STAT_OFF + 1190), 55ull, term_ctr(CID_SCON, STAT_OFF + 1192), 54ull, term_ctr(CID_SCON, STAT_OFF + 1194), 54ull, term_ctr(CID_SCON, STAT_OFF + 1196), 48ull, term_ctr(CID_SCON, STAT_OFF + 1198), 98ull, term_ctr(CID_SCON, STAT_OFF + 1200), 56ull, term_ctr(CID_SCON, STAT_OFF + 1202), 97ull, term_ctr(CID_SCON, STAT_OFF + 1204), 102ull, term_ctr(CID_SCON, STAT_OFF + 1206), 54ull, term_ctr(CID_SCON, STAT_OFF + 1208), 57ull, term_ctr(CID_SCON, STAT_OFF + 1210), 51ull, term_ctr(CID_SCON, STAT_OFF + 1212), 49ull, term_ctr(CID_SCON, STAT_OFF + 1214), 49ull, term_ctr(CID_SCON, STAT_OFF + 1216), 97ull, term_ctr(CID_SCON, STAT_OFF + 1218), 102ull, term_ctr(CID_SCON, STAT_OFF + 1220), 53ull, term_ctr(CID_SCON, STAT_OFF + 1222), 97ull, term_ctr(CID_SCON, STAT_OFF + 1224), 57ull, term_ctr(CID_SCON, STAT_OFF + 1226), 48ull, term_ctr(CID_SCON, STAT_OFF + 1228), 50ull, term_ctr(CID_SCON, STAT_OFF + 1230), 55ull, term_ctr(CID_SCON, STAT_OFF + 1232), 116ull, term_ctr(CID_SCON, STAT_OFF + 1090), 110ull, term_ctr(CID_SCON, STAT_OFF + 1236), 105ull, term_ctr(CID_SCON, STAT_OFF + 1238), 114ull, term_ctr(CID_SCON, STAT_OFF + 1240), 112ull, term_ctr(CID_SCON, STAT_OFF + 1242), 47ull, term_ctr(CID_SCON, STAT_OFF + 1244), 115ull, term_ctr(CID_SCON, STAT_OFF + 1246), 102ull, term_ctr(CID_SCON, STAT_OFF + 1248), 102ull, term_ctr(CID_SCON, STAT_OFF + 1250), 101ull, term_ctr(CID_SCON, STAT_OFF + 1252), 54ull, term_pak(CID_SNIL, 0), 50ull, term_ctr(CID_SCON, STAT_OFF + 1256), 98ull, term_ctr(CID_SCON, STAT_OFF + 1258), 53ull, term_ctr(CID_SCON, STAT_OFF + 1260), 51ull, term_ctr(CID_SCON, STAT_OFF + 1262), 54ull, term_ctr(CID_SCON, STAT_OFF + 1264), 97ull, term_ctr(CID_SCON, STAT_OFF + 1266), 50ull, term_ctr(CID_SCON, STAT_OFF + 1268), 101ull, term_ctr(CID_SCON, STAT_OFF + 1270), 55ull, term_ctr(CID_SCON, STAT_OFF + 1272), 102ull, term_ctr(CID_SCON, STAT_OFF + 1274), 101ull, term_ctr(CID_SCON, STAT_OFF + 1276), 102ull, term_ctr(CID_SCON, STAT_OFF + 1278), 100ull, term_ctr(CID_SCON, STAT_OFF + 1280), 48ull, term_ctr(CID_SCON, STAT_OFF + 1282), 55ull, term_ctr(CID_SCON, STAT_OFF + 1284), 100ull, term_ctr(CID_SCON, STAT_OFF + 1286), 98ull, term_ctr(CID_SCON, STAT_OFF + 1288), 57ull, term_ctr(CID_SCON, STAT_OFF + 1290), 56ull, term_ctr(CID_SCON, STAT_OFF + 1292), 50ull, term_ctr(CID_SCON, STAT_OFF + 1294), 101ull, term_ctr(CID_SCON, STAT_OFF + 1296), 49ull, term_ctr(CID_SCON, STAT_OFF + 1298), 99ull, term_ctr(CID_SCON, STAT_OFF + 1300), 51ull, term_ctr(CID_SCON, STAT_OFF + 1302), 98ull, term_ctr(CID_SCON, STAT_OFF + 1304), 50ull, term_ctr(CID_SCON, STAT_OFF + 1306), 48ull, term_ctr(CID_SCON, STAT_OFF + 1308), 52ull, term_ctr(CID_SCON, STAT_OFF + 1310), 101ull, term_ctr(CID_SCON, STAT_OFF + 1312), 53ull, term_ctr(CID_SCON, STAT_OFF + 1314), 99ull, term_ctr(CID_SCON, STAT_OFF + 1316), 101ull, term_ctr(CID_SCON, STAT_OFF + 1318), 52ull, term_ctr(CID_SCON, STAT_OFF + 1320), 100ull, term_ctr(CID_SCON, STAT_OFF + 1322), 51ull, term_ctr(CID_SCON, STAT_OFF + 1324), 55ull, term_ctr(CID_SCON, STAT_OFF + 1326), 51ull, term_ctr(CID_SCON, STAT_OFF + 1328), 52ull, term_ctr(CID_SCON, STAT_OFF + 1330), 101ull, term_ctr(CID_SCON, STAT_OFF + 1332), 49ull, term_ctr(CID_SCON, STAT_OFF + 1334), 102ull, term_ctr(CID_SCON, STAT_OFF + 1336), 53ull, term_ctr(CID_SCON, STAT_OFF + 1338), 102ull, term_ctr(CID_SCON, STAT_OFF + 1340), 48ull, term_ctr(CID_SCON, STAT_OFF + 1342), 99ull, term_ctr(CID_SCON, STAT_OFF + 1344), 101ull, term_ctr(CID_SCON, STAT_OFF + 1346), 101ull, term_ctr(CID_SCON, STAT_OFF + 1348), 97ull, term_ctr(CID_SCON, STAT_OFF + 1350), 101ull, term_ctr(CID_SCON, STAT_OFF + 1352), 50ull, term_ctr(CID_SCON, STAT_OFF + 1354), 101ull, term_ctr(CID_SCON, STAT_OFF + 1356), 54ull, term_ctr(CID_SCON, STAT_OFF + 1358), 101ull, term_ctr(CID_SCON, STAT_OFF + 1360), 99ull, term_ctr(CID_SCON, STAT_OFF + 1362), 97ull, term_ctr(CID_SCON, STAT_OFF + 1364), 50ull, term_ctr(CID_SCON, STAT_OFF + 1366), 100ull, term_ctr(CID_SCON, STAT_OFF + 1368), 48ull, term_ctr(CID_SCON, STAT_OFF + 1370), 48ull, term_ctr(CID_SCON, STAT_OFF + 1372), 53ull, term_ctr(CID_SCON, STAT_OFF + 1374), 57ull, term_ctr(CID_SCON, STAT_OFF + 1376), 48ull, term_ctr(CID_SCON, STAT_OFF + 1378), 55ull, term_ctr(CID_SCON, STAT_OFF + 1380), 119ull, term_ctr(CID_SCON, STAT_OFF + 1090), 111ull, term_ctr(CID_SCON, STAT_OFF + 1384), 110ull, term_ctr(CID_SCON, STAT_OFF + 1386), 47ull, term_ctr(CID_SCON, STAT_OFF + 1388), 115ull, term_ctr(CID_SCON, STAT_OFF + 1390), 102ull, term_ctr(CID_SCON, STAT_OFF + 1392), 102ull, term_ctr(CID_SCON, STAT_OFF + 1394), 101ull, term_ctr(CID_SCON, STAT_OFF + 1396), 98ull, term_ctr(CID_SCON, STAT_OFF + 802), 53ull, term_ctr(CID_SCON, STAT_OFF + 1400), 50ull, term_ctr(CID_SCON, STAT_OFF + 1402), 56ull, term_ctr(CID_SCON, STAT_OFF + 1404), 98ull, term_ctr(CID_SCON, STAT_OFF + 1406), 55ull, term_ctr(CID_SCON, STAT_OFF + 1408), 56ull, term_ctr(CID_SCON, STAT_OFF + 1410), 56ull, term_ctr(CID_SCON, STAT_OFF + 1412), 49ull, term_ctr(CID_SCON, STAT_OFF + 1414), 54ull, term_ctr(CID_SCON, STAT_OFF + 1416), 97ull, term_ctr(CID_SCON, STAT_OFF + 1418), 100ull, term_ctr(CID_SCON, STAT_OFF + 1420), 100ull, term_ctr(CID_SCON, STAT_OFF + 1422), 101ull, term_ctr(CID_SCON, STAT_OFF + 1424), 97ull, term_ctr(CID_SCON, STAT_OFF + 1426), 49ull, term_ctr(CID_SCON, STAT_OFF + 1428), 101ull, term_ctr(CID_SCON, STAT_OFF + 1430), 98ull, term_ctr(CID_SCON, STAT_OFF + 1432), 98ull, term_ctr(CID_SCON, STAT_OFF + 1434), 54ull, term_ctr(CID_SCON, STAT_OFF + 1436), 98ull, term_ctr(CID_SCON, STAT_OFF + 1438), 55ull, term_ctr(CID_SCON, STAT_OFF + 1440), 100ull, term_ctr(CID_SCON, STAT_OFF + 1442), 98ull, term_ctr(CID_SCON, STAT_OFF + 1444), 102ull, term_ctr(CID_SCON, STAT_OFF + 1446), 101ull, term_ctr(CID_SCON, STAT_OFF + 1448), 101ull, term_ctr(CID_SCON, STAT_OFF + 1450), 50ull, term_ctr(CID_SCON, STAT_OFF + 1452), 98ull, term_ctr(CID_SCON, STAT_OFF + 1454), 48ull, term_ctr(CID_SCON, STAT_OFF + 1456), 54ull, term_ctr(CID_SCON, STAT_OFF + 1458), 100ull, term_ctr(CID_SCON, STAT_OFF + 1460), 52ull, term_ctr(CID_SCON, STAT_OFF + 1462), 98ull, term_ctr(CID_SCON, STAT_OFF + 1464), 53ull, term_ctr(CID_SCON, STAT_OFF + 1466), 49ull, term_ctr(CID_SCON, STAT_OFF + 1468), 54ull, term_ctr(CID_SCON, STAT_OFF + 1470), 57ull, term_ctr(CID_SCON, STAT_OFF + 1472), 99ull, term_ctr(CID_SCON, STAT_OFF + 1474), 53ull, term_ctr(CID_SCON, STAT_OFF + 1476), 50ull, term_ctr(CID_SCON, STAT_OFF + 1478), 54ull, term_ctr(CID_SCON, STAT_OFF + 1480), 48ull, term_ctr(CID_SCON, STAT_OFF + 1482), 54ull, term_ctr(CID_SCON, STAT_OFF + 1484), 53ull, term_ctr(CID_SCON, STAT_OFF + 1486), 55ull, term_ctr(CID_SCON, STAT_OFF + 1488), 99ull, term_ctr(CID_SCON, STAT_OFF + 1490), 100ull, term_ctr(CID_SCON, STAT_OFF + 1492), 97ull, term_ctr(CID_SCON, STAT_OFF + 1494), 102ull, term_ctr(CID_SCON, STAT_OFF + 1496), 52ull, term_ctr(CID_SCON, STAT_OFF + 1498), 99ull, term_ctr(CID_SCON, STAT_OFF + 1500), 49ull, term_ctr(CID_SCON, STAT_OFF + 1502), 48ull, term_ctr(CID_SCON, STAT_OFF + 1504), 55ull, term_ctr(CID_SCON, STAT_OFF + 1506), 53ull, term_ctr(CID_SCON, STAT_OFF + 1508), 54ull, term_ctr(CID_SCON, STAT_OFF + 1510), 101ull, term_ctr(CID_SCON, STAT_OFF + 1512), 100ull, term_ctr(CID_SCON, STAT_OFF + 1514), 102ull, term_ctr(CID_SCON, STAT_OFF + 1516), 53ull, term_ctr(CID_SCON, STAT_OFF + 1518), 97ull, term_ctr(CID_SCON, STAT_OFF + 1520), 100ull, term_ctr(CID_SCON, STAT_OFF + 1522), 114ull, term_ctr(CID_SCON, STAT_OFF + 1090), 114ull, term_ctr(CID_SCON, STAT_OFF + 1526), 101ull, term_ctr(CID_SCON, STAT_OFF + 1528), 95ull, term_ctr(CID_SCON, STAT_OFF + 1530), 116ull, term_ctr(CID_SCON, STAT_OFF + 1532), 110ull, term_ctr(CID_SCON, STAT_OFF + 1534), 105ull, term_ctr(CID_SCON, STAT_OFF + 1536), 114ull, term_ctr(CID_SCON, STAT_OFF + 1538), 112ull, term_ctr(CID_SCON, STAT_OFF + 1540), 47ull, term_ctr(CID_SCON, STAT_OFF + 1542), 115ull, term_ctr(CID_SCON, STAT_OFF + 1544), 102ull, term_ctr(CID_SCON, STAT_OFF + 1546), 102ull, term_ctr(CID_SCON, STAT_OFF + 1548), 101ull, term_ctr(CID_SCON, STAT_OFF + 1550), 98ull, term_ctr(CID_SCON, STAT_OFF + 1256), 52ull, term_ctr(CID_SCON, STAT_OFF + 1554), 102ull, term_ctr(CID_SCON, STAT_OFF + 1556), 57ull, term_ctr(CID_SCON, STAT_OFF + 1558), 49ull, term_ctr(CID_SCON, STAT_OFF + 1560), 101ull, term_ctr(CID_SCON, STAT_OFF + 1562), 55ull, term_ctr(CID_SCON, STAT_OFF + 1564), 57ull, term_ctr(CID_SCON, STAT_OFF + 1566), 54ull, term_ctr(CID_SCON, STAT_OFF + 1568), 97ull, term_ctr(CID_SCON, STAT_OFF + 1570), 54ull, term_ctr(CID_SCON, STAT_OFF + 1572), 97ull, term_ctr(CID_SCON, STAT_OFF + 1574), 97ull, term_ctr(CID_SCON, STAT_OFF + 1576), 97ull, term_ctr(CID_SCON, STAT_OFF + 1578), 53ull, term_ctr(CID_SCON, STAT_OFF + 1580), 48ull, term_ctr(CID_SCON, STAT_OFF + 1582), 98ull, term_ctr(CID_SCON, STAT_OFF + 1584), 102ull, term_ctr(CID_SCON, STAT_OFF + 1586), 51ull, term_ctr(CID_SCON, STAT_OFF + 1588), 52ull, term_ctr(CID_SCON, STAT_OFF + 1590), 97ull, term_ctr(CID_SCON, STAT_OFF + 1592), 98ull, term_ctr(CID_SCON, STAT_OFF + 1594), 49ull, term_ctr(CID_SCON, STAT_OFF + 1596), 97ull, term_ctr(CID_SCON, STAT_OFF + 1598), 97ull, term_ctr(CID_SCON, STAT_OFF + 1600), 53ull, term_ctr(CID_SCON, STAT_OFF + 1602), 100ull, term_ctr(CID_SCON, STAT_OFF + 1604), 56ull, term_ctr(CID_SCON, STAT_OFF + 1606), 51ull, term_ctr(CID_SCON, STAT_OFF + 1608), 99ull, term_ctr(CID_SCON, STAT_OFF + 1610), 52ull, term_ctr(CID_SCON, STAT_OFF + 1612), 50ull, term_ctr(CID_SCON, STAT_OFF + 1614), 56ull, term_ctr(CID_SCON, STAT_OFF + 1616), 48ull, term_ctr(CID_SCON, STAT_OFF + 1618), 50ull, term_ctr(CID_SCON, STAT_OFF + 1620), 102ull, term_ctr(CID_SCON, STAT_OFF + 1622), 102ull, term_ctr(CID_SCON, STAT_OFF + 1624), 101ull, term_ctr(CID_SCON, STAT_OFF + 1626), 100ull, term_ctr(CID_SCON, STAT_OFF + 1628), 57ull, term_ctr(CID_SCON, STAT_OFF + 1630), 99ull, term_ctr(CID_SCON, STAT_OFF + 1632), 48ull, term_ctr(CID_SCON, STAT_OFF + 1634), 51ull, term_ctr(CID_SCON, STAT_OFF + 1636), 53ull, term_ctr(CID_SCON, STAT_OFF + 1638), 53ull, term_ctr(CID_SCON, STAT_OFF + 1640), 100ull, term_ctr(CID_SCON, STAT_OFF + 1642), 49ull, term_ctr(CID_SCON, STAT_OFF + 1644), 57ull, term_ctr(CID_SCON, STAT_OFF + 1646), 55ull, term_ctr(CID_SCON, STAT_OFF + 1648), 52ull, term_ctr(CID_SCON, STAT_OFF + 1650), 97ull, term_ctr(CID_SCON, STAT_OFF + 1652), 56ull, term_ctr(CID_SCON, STAT_OFF + 1654), 56ull, term_ctr(CID_SCON, STAT_OFF + 1656), 99ull, term_ctr(CID_SCON, STAT_OFF + 1658), 100ull, term_ctr(CID_SCON, STAT_OFF + 1660), 97ull, term_ctr(CID_SCON, STAT_OFF + 1662), 50ull, term_ctr(CID_SCON, STAT_OFF + 1664), 100ull, term_ctr(CID_SCON, STAT_OFF + 1666), 49ull, term_ctr(CID_SCON, STAT_OFF + 1668), 56ull, term_ctr(CID_SCON, STAT_OFF + 1670), 55ull, term_ctr(CID_SCON, STAT_OFF + 1672), 50ull, term_ctr(CID_SCON, STAT_OFF + 1674), 55ull, term_ctr(CID_SCON, STAT_OFF + 1676), 110ull, term_ctr(CID_SCON, STAT_OFF + 1090), 101ull, term_ctr(CID_SCON, STAT_OFF + 1680), 112ull, term_ctr(CID_SCON, STAT_OFF + 1682), 111ull, term_ctr(CID_SCON, STAT_OFF + 1684), 95ull, term_ctr(CID_SCON, STAT_OFF + 1686), 101ull, term_ctr(CID_SCON, STAT_OFF + 1688), 108ull, term_ctr(CID_SCON, STAT_OFF + 1690), 105ull, term_ctr(CID_SCON, STAT_OFF + 1692), 102ull, term_ctr(CID_SCON, STAT_OFF + 1694), 47ull, term_ctr(CID_SCON, STAT_OFF + 1696), 115ull, term_ctr(CID_SCON, STAT_OFF + 1698), 102ull, term_ctr(CID_SCON, STAT_OFF + 1700), 102ull, term_ctr(CID_SCON, STAT_OFF + 1702), 101ull, term_ctr(CID_SCON, STAT_OFF + 1704), 101ull, term_ctr(CID_SCON, STAT_OFF + 174), 54ull, term_ctr(CID_SCON, STAT_OFF + 1708), 52ull, term_ctr(CID_SCON, STAT_OFF + 1710), 55ull, term_ctr(CID_SCON, STAT_OFF + 1712), 50ull, term_ctr(CID_SCON, STAT_OFF + 1714), 54ull, term_ctr(CID_SCON, STAT_OFF + 1716), 48ull, term_ctr(CID_SCON, STAT_OFF + 1718), 97ull, term_ctr(CID_SCON, STAT_OFF + 1720), 102ull, term_ctr(CID_SCON, STAT_OFF + 1722), 50ull, term_ctr(CID_SCON, STAT_OFF + 1724), 99ull, term_ctr(CID_SCON, STAT_OFF + 1726), 48ull, term_ctr(CID_SCON, STAT_OFF + 1728), 57ull, term_ctr(CID_SCON, STAT_OFF + 1730), 99ull, term_ctr(CID_SCON, STAT_OFF + 1732), 57ull, term_ctr(CID_SCON, STAT_OFF + 1734), 50ull, term_ctr(CID_SCON, STAT_OFF + 1736), 57ull, term_ctr(CID_SCON, STAT_OFF + 1738), 97ull, term_ctr(CID_SCON, STAT_OFF + 1740), 101ull, term_ctr(CID_SCON, STAT_OFF + 1742), 100ull, term_ctr(CID_SCON, STAT_OFF + 1744), 53ull, term_ctr(CID_SCON, STAT_OFF + 1746), 49ull, term_ctr(CID_SCON, STAT_OFF + 1748), 101ull, term_ctr(CID_SCON, STAT_OFF + 1750), 98ull, term_ctr(CID_SCON, STAT_OFF + 1752), 99ull, term_ctr(CID_SCON, STAT_OFF + 1754), 102ull, term_ctr(CID_SCON, STAT_OFF + 1756), 101ull, term_ctr(CID_SCON, STAT_OFF + 1758), 57ull, term_ctr(CID_SCON, STAT_OFF + 1760), 102ull, term_ctr(CID_SCON, STAT_OFF + 1762), 52ull, term_ctr(CID_SCON, STAT_OFF + 1764), 49ull, term_ctr(CID_SCON, STAT_OFF + 1766), 99ull, term_ctr(CID_SCON, STAT_OFF + 1768), 57ull, term_ctr(CID_SCON, STAT_OFF + 1770), 48ull, term_ctr(CID_SCON, STAT_OFF + 1772), 97ull, term_ctr(CID_SCON, STAT_OFF + 1774), 99ull, term_ctr(CID_SCON, STAT_OFF + 1776), 55ull, term_ctr(CID_SCON, STAT_OFF + 1778), 56ull, term_ctr(CID_SCON, STAT_OFF + 1780), 50ull, term_ctr(CID_SCON, STAT_OFF + 1782), 57ull, term_ctr(CID_SCON, STAT_OFF + 1784), 57ull, term_ctr(CID_SCON, STAT_OFF + 1786), 97ull, term_ctr(CID_SCON, STAT_OFF + 1788), 99ull, term_ctr(CID_SCON, STAT_OFF + 1790), 54ull, term_ctr(CID_SCON, STAT_OFF + 1792), 102ull, term_ctr(CID_SCON, STAT_OFF + 1794), 55ull, term_ctr(CID_SCON, STAT_OFF + 1796), 99ull, term_ctr(CID_SCON, STAT_OFF + 1798), 51ull, term_ctr(CID_SCON, STAT_OFF + 1800), 48ull, term_ctr(CID_SCON, STAT_OFF + 1802), 48ull, term_ctr(CID_SCON, STAT_OFF + 1804), 57ull, term_ctr(CID_SCON, STAT_OFF + 1806), 98ull, term_ctr(CID_SCON, STAT_OFF + 1808), 50ull, term_ctr(CID_SCON, STAT_OFF + 1810), 52ull, term_ctr(CID_SCON, STAT_OFF + 1812), 49ull, term_ctr(CID_SCON, STAT_OFF + 1814), 99ull, term_ctr(CID_SCON, STAT_OFF + 1816), 99ull, term_ctr(CID_SCON, STAT_OFF + 1818), 98ull, term_ctr(CID_SCON, STAT_OFF + 1820), 56ull, term_ctr(CID_SCON, STAT_OFF + 1822), 97ull, term_ctr(CID_SCON, STAT_OFF + 1824), 50ull, term_ctr(CID_SCON, STAT_OFF + 1826), 52ull, term_ctr(CID_SCON, STAT_OFF + 1828), 102ull, term_ctr(CID_SCON, STAT_OFF + 1830), 100ull, term_ctr(CID_SCON, STAT_OFF + 1090), 97ull, term_ctr(CID_SCON, STAT_OFF + 1834), 101ull, term_ctr(CID_SCON, STAT_OFF + 1836), 114ull, term_ctr(CID_SCON, STAT_OFF + 1838), 95ull, term_ctr(CID_SCON, STAT_OFF + 1840), 101ull, term_ctr(CID_SCON, STAT_OFF + 1842), 108ull, term_ctr(CID_SCON, STAT_OFF + 1844), 105ull, term_ctr(CID_SCON, STAT_OFF + 1846), 102ull, term_ctr(CID_SCON, STAT_OFF + 1848), 47ull, term_ctr(CID_SCON, STAT_OFF + 1850), 115ull, term_ctr(CID_SCON, STAT_OFF + 1852), 102ull, term_ctr(CID_SCON, STAT_OFF + 1854), 102ull, term_ctr(CID_SCON, STAT_OFF + 1856), 101ull, term_ctr(CID_SCON, STAT_OFF + 1858), 55ull, term_ctr(CID_SCON, STAT_OFF + 158), 54ull, term_ctr(CID_SCON, STAT_OFF + 1862), 98ull, term_ctr(CID_SCON, STAT_OFF + 1864), 102ull, term_ctr(CID_SCON, STAT_OFF + 1866), 49ull, term_ctr(CID_SCON, STAT_OFF + 1868), 51ull, term_ctr(CID_SCON, STAT_OFF + 1870), 102ull, term_ctr(CID_SCON, STAT_OFF + 1872), 101ull, term_ctr(CID_SCON, STAT_OFF + 1874), 100ull, term_ctr(CID_SCON, STAT_OFF + 1876), 97ull, term_ctr(CID_SCON, STAT_OFF + 1878), 57ull, term_ctr(CID_SCON, STAT_OFF + 1880), 55ull, term_ctr(CID_SCON, STAT_OFF + 1882), 53ull, term_ctr(CID_SCON, STAT_OFF + 1884), 51ull, term_ctr(CID_SCON, STAT_OFF + 1886), 102ull, term_ctr(CID_SCON, STAT_OFF + 1888), 98ull, term_ctr(CID_SCON, STAT_OFF + 1890), 102ull, term_ctr(CID_SCON, STAT_OFF + 1892), 99ull, term_ctr(CID_SCON, STAT_OFF + 1894), 56ull, term_ctr(CID_SCON, STAT_OFF + 1896), 48ull, term_ctr(CID_SCON, STAT_OFF + 1898), 57ull, term_ctr(CID_SCON, STAT_OFF + 1900), 56ull, term_ctr(CID_SCON, STAT_OFF + 1902), 55ull, term_ctr(CID_SCON, STAT_OFF + 1904), 54ull, term_ctr(CID_SCON, STAT_OFF + 1906), 97ull, term_ctr(CID_SCON, STAT_OFF + 1908), 55ull, term_ctr(CID_SCON, STAT_OFF + 1910), 97ull, term_ctr(CID_SCON, STAT_OFF + 1912), 55ull, term_ctr(CID_SCON, STAT_OFF + 1914), 98ull, term_ctr(CID_SCON, STAT_OFF + 1916), 102ull, term_ctr(CID_SCON, STAT_OFF + 1918), 98ull, term_ctr(CID_SCON, STAT_OFF + 1920), 54ull, term_ctr(CID_SCON, STAT_OFF + 1922), 97ull, term_ctr(CID_SCON, STAT_OFF + 1924), 101ull, term_ctr(CID_SCON, STAT_OFF + 1926), 101ull, term_ctr(CID_SCON, STAT_OFF + 1928), 55ull, term_ctr(CID_SCON, STAT_OFF + 1930), 49ull, term_ctr(CID_SCON, STAT_OFF + 1932), 99ull, term_ctr(CID_SCON, STAT_OFF + 1934), 48ull, term_ctr(CID_SCON, STAT_OFF + 1936), 50ull, term_ctr(CID_SCON, STAT_OFF + 1938), 102ull, term_ctr(CID_SCON, STAT_OFF + 1940), 98ull, term_ctr(CID_SCON, STAT_OFF + 1942), 51ull, term_ctr(CID_SCON, STAT_OFF + 1944), 100ull, term_ctr(CID_SCON, STAT_OFF + 1946), 100ull, term_ctr(CID_SCON, STAT_OFF + 1948), 50ull, term_ctr(CID_SCON, STAT_OFF + 1950), 98ull, term_ctr(CID_SCON, STAT_OFF + 1952), 53ull, term_ctr(CID_SCON, STAT_OFF + 1954), 53ull, term_ctr(CID_SCON, STAT_OFF + 1956), 98ull, term_ctr(CID_SCON, STAT_OFF + 1958), 97ull, term_ctr(CID_SCON, STAT_OFF + 1960), 51ull, term_ctr(CID_SCON, STAT_OFF + 1962), 56ull, term_ctr(CID_SCON, STAT_OFF + 1964), 97ull, term_ctr(CID_SCON, STAT_OFF + 1966), 99ull, term_ctr(CID_SCON, STAT_OFF + 1968), 54ull, term_ctr(CID_SCON, STAT_OFF + 1970), 54ull, term_ctr(CID_SCON, STAT_OFF + 1972), 50ull, term_ctr(CID_SCON, STAT_OFF + 1974), 52ull, term_ctr(CID_SCON, STAT_OFF + 1976), 52ull, term_ctr(CID_SCON, STAT_OFF + 1978), 102ull, term_ctr(CID_SCON, STAT_OFF + 1980), 97ull, term_ctr(CID_SCON, STAT_OFF + 1982), 54ull, term_ctr(CID_SCON, STAT_OFF + 1984), 101ull, term_ctr(CID_SCON, STAT_OFF + 1090), 122ull, term_ctr(CID_SCON, STAT_OFF + 1988), 105ull, term_ctr(CID_SCON, STAT_OFF + 1990), 115ull, term_ctr(CID_SCON, STAT_OFF + 1992), 95ull, term_ctr(CID_SCON, STAT_OFF + 1994), 101ull, term_ctr(CID_SCON, STAT_OFF + 1996), 108ull, term_ctr(CID_SCON, STAT_OFF + 1998), 105ull, term_ctr(CID_SCON, STAT_OFF + 2000), 102ull, term_ctr(CID_SCON, STAT_OFF + 2002), 47ull, term_ctr(CID_SCON, STAT_OFF + 2004), 115ull, term_ctr(CID_SCON, STAT_OFF + 2006), 102ull, term_ctr(CID_SCON, STAT_OFF + 2008), 102ull, term_ctr(CID_SCON, STAT_OFF + 2010), 101ull, term_ctr(CID_SCON, STAT_OFF + 2012), 100ull, term_ctr(CID_SCON, STAT_OFF + 158), 53ull, term_ctr(CID_SCON, STAT_OFF + 2016), 100ull, term_ctr(CID_SCON, STAT_OFF + 2018), 53ull, term_ctr(CID_SCON, STAT_OFF + 2020), 102ull, term_ctr(CID_SCON, STAT_OFF + 2022), 54ull, term_ctr(CID_SCON, STAT_OFF + 2024), 53ull, term_ctr(CID_SCON, STAT_OFF + 2026), 53ull, term_ctr(CID_SCON, STAT_OFF + 2028), 48ull, term_ctr(CID_SCON, STAT_OFF + 2030), 101ull, term_ctr(CID_SCON, STAT_OFF + 2032), 51ull, term_ctr(CID_SCON, STAT_OFF + 2034), 52ull, term_ctr(CID_SCON, STAT_OFF + 2036), 98ull, term_ctr(CID_SCON, STAT_OFF + 2038), 98ull, term_ctr(CID_SCON, STAT_OFF + 2040), 101ull, term_ctr(CID_SCON, STAT_OFF + 2042), 100ull, term_ctr(CID_SCON, STAT_OFF + 2044), 56ull, term_ctr(CID_SCON, STAT_OFF + 2046), 101ull, term_ctr(CID_SCON, STAT_OFF + 2048), 56ull, term_ctr(CID_SCON, STAT_OFF + 2050), 55ull, term_ctr(CID_SCON, STAT_OFF + 2052), 98ull, term_ctr(CID_SCON, STAT_OFF + 2054), 50ull, term_ctr(CID_SCON, STAT_OFF + 2056), 99ull, term_ctr(CID_SCON, STAT_OFF + 2058), 100ull, term_ctr(CID_SCON, STAT_OFF + 2060), 55ull, term_ctr(CID_SCON, STAT_OFF + 2062), 50ull, term_ctr(CID_SCON, STAT_OFF + 2064), 54ull, term_ctr(CID_SCON, STAT_OFF + 2066), 51ull, term_ctr(CID_SCON, STAT_OFF + 2068), 48ull, term_ctr(CID_SCON, STAT_OFF + 2070), 101ull, term_ctr(CID_SCON, STAT_OFF + 2072), 56ull, term_ctr(CID_SCON, STAT_OFF + 2074), 102ull, term_ctr(CID_SCON, STAT_OFF + 2076), 53ull, term_ctr(CID_SCON, STAT_OFF + 2078), 51ull, term_ctr(CID_SCON, STAT_OFF + 2080), 101ull, term_ctr(CID_SCON, STAT_OFF + 2082), 56ull, term_ctr(CID_SCON, STAT_OFF + 2084), 52ull, term_ctr(CID_SCON, STAT_OFF + 2086), 57ull, term_ctr(CID_SCON, STAT_OFF + 2088), 99ull, term_ctr(CID_SCON, STAT_OFF + 2090), 52ull, term_ctr(CID_SCON, STAT_OFF + 2092), 52ull, term_ctr(CID_SCON, STAT_OFF + 2094), 57ull, term_ctr(CID_SCON, STAT_OFF + 2096), 97ull, term_ctr(CID_SCON, STAT_OFF + 2098), 101ull, term_ctr(CID_SCON, STAT_OFF + 2100), 101ull, term_ctr(CID_SCON, STAT_OFF + 2102), 49ull, term_ctr(CID_SCON, STAT_OFF + 2104), 97ull, term_ctr(CID_SCON, STAT_OFF + 2106), 98ull, term_ctr(CID_SCON, STAT_OFF + 2108), 102ull, term_ctr(CID_SCON, STAT_OFF + 2110), 48ull, term_ctr(CID_SCON, STAT_OFF + 2112), 102ull, term_ctr(CID_SCON, STAT_OFF + 2114), 48ull, term_ctr(CID_SCON, STAT_OFF + 2116), 102ull, term_ctr(CID_SCON, STAT_OFF + 2118), 57ull, term_ctr(CID_SCON, STAT_OFF + 2120), 51ull, term_ctr(CID_SCON, STAT_OFF + 2122), 56ull, term_ctr(CID_SCON, STAT_OFF + 2124), 51ull, term_ctr(CID_SCON, STAT_OFF + 2126), 102ull, term_ctr(CID_SCON, STAT_OFF + 2128), 54ull, term_ctr(CID_SCON, STAT_OFF + 2130), 48ull, term_ctr(CID_SCON, STAT_OFF + 2132), 57ull, term_ctr(CID_SCON, STAT_OFF + 2134), 57ull, term_ctr(CID_SCON, STAT_OFF + 2136), 48ull, term_ctr(CID_SCON, STAT_OFF + 2138), 116ull, term_ctr(CID_SCON, STAT_OFF + 1988), 105ull, term_ctr(CID_SCON, STAT_OFF + 2142), 114ull, term_ctr(CID_SCON, STAT_OFF + 2144), 119ull, term_ctr(CID_SCON, STAT_OFF + 2146), 95ull, term_ctr(CID_SCON, STAT_OFF + 2148), 101ull, term_ctr(CID_SCON, STAT_OFF + 2150), 108ull, term_ctr(CID_SCON, STAT_OFF + 2152), 105ull, term_ctr(CID_SCON, STAT_OFF + 2154), 102ull, term_ctr(CID_SCON, STAT_OFF + 2156), 47ull, term_ctr(CID_SCON, STAT_OFF + 2158), 115ull, term_ctr(CID_SCON, STAT_OFF + 2160), 102ull, term_ctr(CID_SCON, STAT_OFF + 2162), 102ull, term_ctr(CID_SCON, STAT_OFF + 2164), 101ull, term_ctr(CID_SCON, STAT_OFF + 2166), 101ull, term_ctr(CID_SCON, STAT_OFF + 616), 101ull, term_ctr(CID_SCON, STAT_OFF + 2170), 52ull, term_ctr(CID_SCON, STAT_OFF + 2172), 53ull, term_ctr(CID_SCON, STAT_OFF + 2174), 49ull, term_ctr(CID_SCON, STAT_OFF + 2176), 101ull, term_ctr(CID_SCON, STAT_OFF + 2178), 57ull, term_ctr(CID_SCON, STAT_OFF + 2180), 97ull, term_ctr(CID_SCON, STAT_OFF + 2182), 55ull, term_ctr(CID_SCON, STAT_OFF + 2184), 48ull, term_ctr(CID_SCON, STAT_OFF + 2186), 99ull, term_ctr(CID_SCON, STAT_OFF + 2188), 48ull, term_ctr(CID_SCON, STAT_OFF + 2190), 54ull, term_ctr(CID_SCON, STAT_OFF + 2192), 57ull, term_ctr(CID_SCON, STAT_OFF + 2194), 49ull, term_ctr(CID_SCON, STAT_OFF + 2196), 56ull, term_ctr(CID_SCON, STAT_OFF + 2198), 57ull, term_ctr(CID_SCON, STAT_OFF + 2200), 102ull, term_ctr(CID_SCON, STAT_OFF + 2202), 100ull, term_ctr(CID_SCON, STAT_OFF + 2204), 102ull, term_ctr(CID_SCON, STAT_OFF + 2206), 99ull, term_ctr(CID_SCON, STAT_OFF + 2208), 55ull, term_ctr(CID_SCON, STAT_OFF + 2210), 51ull, term_ctr(CID_SCON, STAT_OFF + 2212), 99ull, term_ctr(CID_SCON, STAT_OFF + 2214), 100ull, term_ctr(CID_SCON, STAT_OFF + 2216), 53ull, term_ctr(CID_SCON, STAT_OFF + 2218), 101ull, term_ctr(CID_SCON, STAT_OFF + 2220), 48ull, term_ctr(CID_SCON, STAT_OFF + 2222), 100ull, term_ctr(CID_SCON, STAT_OFF + 2224), 49ull, term_ctr(CID_SCON, STAT_OFF + 2226), 48ull, term_ctr(CID_SCON, STAT_OFF + 2228), 48ull, term_ctr(CID_SCON, STAT_OFF + 2230), 54ull, term_ctr(CID_SCON, STAT_OFF + 2232), 100ull, term_ctr(CID_SCON, STAT_OFF + 2234), 54ull, term_ctr(CID_SCON, STAT_OFF + 2236), 97ull, term_ctr(CID_SCON, STAT_OFF + 2238), 100ull, term_ctr(CID_SCON, STAT_OFF + 2240), 99ull, term_ctr(CID_SCON, STAT_OFF + 2242), 51ull, term_ctr(CID_SCON, STAT_OFF + 2244), 56ull, term_ctr(CID_SCON, STAT_OFF + 2246), 57ull, term_ctr(CID_SCON, STAT_OFF + 2248), 98ull, term_ctr(CID_SCON, STAT_OFF + 2250), 56ull, term_ctr(CID_SCON, STAT_OFF + 2252), 56ull, term_ctr(CID_SCON, STAT_OFF + 2254), 49ull, term_ctr(CID_SCON, STAT_OFF + 2256), 101ull, term_ctr(CID_SCON, STAT_OFF + 2258), 53ull, term_ctr(CID_SCON, STAT_OFF + 2260), 51ull, term_ctr(CID_SCON, STAT_OFF + 2262), 53ull, term_ctr(CID_SCON, STAT_OFF + 2264), 101ull, term_ctr(CID_SCON, STAT_OFF + 2266), 49ull, term_ctr(CID_SCON, STAT_OFF + 2268), 101ull, term_ctr(CID_SCON, STAT_OFF + 2270), 52ull, term_ctr(CID_SCON, STAT_OFF + 2272), 48ull, term_ctr(CID_SCON, STAT_OFF + 2274), 50ull, term_ctr(CID_SCON, STAT_OFF + 2276), 48ull, term_ctr(CID_SCON, STAT_OFF + 2278), 50ull, term_ctr(CID_SCON, STAT_OFF + 2280), 102ull, term_ctr(CID_SCON, STAT_OFF + 2282), 102ull, term_ctr(CID_SCON, STAT_OFF + 2284), 100ull, term_ctr(CID_SCON, STAT_OFF + 2286), 53ull, term_ctr(CID_SCON, STAT_OFF + 2288), 54ull, term_ctr(CID_SCON, STAT_OFF + 2290), 53ull, term_ctr(CID_SCON, STAT_OFF + 2292), 115ull, term_ctr(CID_SCON, STAT_OFF + 1988), 111ull, term_ctr(CID_SCON, STAT_OFF + 2296), 108ull, term_ctr(CID_SCON, STAT_OFF + 2298), 99ull, term_ctr(CID_SCON, STAT_OFF + 2300), 95ull, term_ctr(CID_SCON, STAT_OFF + 2302), 101ull, term_ctr(CID_SCON, STAT_OFF + 2304), 108ull, term_ctr(CID_SCON, STAT_OFF + 2306), 105ull, term_ctr(CID_SCON, STAT_OFF + 2308), 102ull, term_ctr(CID_SCON, STAT_OFF + 2310), 47ull, term_ctr(CID_SCON, STAT_OFF + 2312), 115ull, term_ctr(CID_SCON, STAT_OFF + 2314), 102ull, term_ctr(CID_SCON, STAT_OFF + 2316), 102ull, term_ctr(CID_SCON, STAT_OFF + 2318), 101ull, term_ctr(CID_SCON, STAT_OFF + 2320), 98ull, term_ctr(CID_SCON, STAT_OFF + 772), 102ull, term_ctr(CID_SCON, STAT_OFF + 2324), 50ull, term_ctr(CID_SCON, STAT_OFF + 2326), 98ull, term_ctr(CID_SCON, STAT_OFF + 2328), 56ull, term_ctr(CID_SCON, STAT_OFF + 2330), 101ull, term_ctr(CID_SCON, STAT_OFF + 2332), 53ull, term_ctr(CID_SCON, STAT_OFF + 2334), 56ull, term_ctr(CID_SCON, STAT_OFF + 2336), 99ull, term_ctr(CID_SCON, STAT_OFF + 2338), 52ull, term_ctr(CID_SCON, STAT_OFF + 2340), 56ull, term_ctr(CID_SCON, STAT_OFF + 2342), 53ull, term_ctr(CID_SCON, STAT_OFF + 2344), 48ull, term_ctr(CID_SCON, STAT_OFF + 2346), 57ull, term_ctr(CID_SCON, STAT_OFF + 2348), 97ull, term_ctr(CID_SCON, STAT_OFF + 2350), 98ull, term_ctr(CID_SCON, STAT_OFF + 2352), 56ull, term_ctr(CID_SCON, STAT_OFF + 2354), 100ull, term_ctr(CID_SCON, STAT_OFF + 2356), 55ull, term_ctr(CID_SCON, STAT_OFF + 2358), 50ull, term_ctr(CID_SCON, STAT_OFF + 2360), 51ull, term_ctr(CID_SCON, STAT_OFF + 2362), 54ull, term_ctr(CID_SCON, STAT_OFF + 2364), 101ull, term_ctr(CID_SCON, STAT_OFF + 2366), 57ull, term_ctr(CID_SCON, STAT_OFF + 2368), 53ull, term_ctr(CID_SCON, STAT_OFF + 2370), 101ull, term_ctr(CID_SCON, STAT_OFF + 2372), 48ull, term_ctr(CID_SCON, STAT_OFF + 2374), 51ull, term_ctr(CID_SCON, STAT_OFF + 2376), 51ull, term_ctr(CID_SCON, STAT_OFF + 2378), 55ull, term_ctr(CID_SCON, STAT_OFF + 2380), 97ull, term_ctr(CID_SCON, STAT_OFF + 2382), 101ull, term_ctr(CID_SCON, STAT_OFF + 2384), 57ull, term_ctr(CID_SCON, STAT_OFF + 2386), 49ull, term_ctr(CID_SCON, STAT_OFF + 2388), 48ull, term_ctr(CID_SCON, STAT_OFF + 2390), 49ull, term_ctr(CID_SCON, STAT_OFF + 2392), 98ull, term_ctr(CID_SCON, STAT_OFF + 2394), 54ull, term_ctr(CID_SCON, STAT_OFF + 2396), 50ull, term_ctr(CID_SCON, STAT_OFF + 2398), 100ull, term_ctr(CID_SCON, STAT_OFF + 2400), 50ull, term_ctr(CID_SCON, STAT_OFF + 2402), 50ull, term_ctr(CID_SCON, STAT_OFF + 2404), 50ull, term_ctr(CID_SCON, STAT_OFF + 2406), 50ull, term_ctr(CID_SCON, STAT_OFF + 2408), 55ull, term_ctr(CID_SCON, STAT_OFF + 2410), 55ull, term_ctr(CID_SCON, STAT_OFF + 2412), 100ull, term_ctr(CID_SCON, STAT_OFF + 2414), 54ull, term_ctr(CID_SCON, STAT_OFF + 2416), 51ull, term_ctr(CID_SCON, STAT_OFF + 2418), 57ull, term_ctr(CID_SCON, STAT_OFF + 2420), 56ull, term_ctr(CID_SCON, STAT_OFF + 2422), 56ull, term_ctr(CID_SCON, STAT_OFF + 2424), 98ull, term_ctr(CID_SCON, STAT_OFF + 2426), 49ull, term_ctr(CID_SCON, STAT_OFF + 2428), 51ull, term_ctr(CID_SCON, STAT_OFF + 2430), 97ull, term_ctr(CID_SCON, STAT_OFF + 2432), 53ull, term_ctr(CID_SCON, STAT_OFF + 2434), 54ull, term_ctr(CID_SCON, STAT_OFF + 2436), 52ull, term_ctr(CID_SCON, STAT_OFF + 2438), 100ull, term_ctr(CID_SCON, STAT_OFF + 2440), 102ull, term_ctr(CID_SCON, STAT_OFF + 2442), 101ull, term_ctr(CID_SCON, STAT_OFF + 2444), 98ull, term_ctr(CID_SCON, STAT_OFF + 2446), 110ull, term_pak(CID_SNIL, 0), 111ull, term_ctr(CID_SCON, STAT_OFF + 2450), 105ull, term_ctr(CID_SCON, STAT_OFF + 2452), 116ull, term_ctr(CID_SCON, STAT_OFF + 2454), 112ull, term_ctr(CID_SCON, STAT_OFF + 2456), 111ull, term_ctr(CID_SCON, STAT_OFF + 2458), 32ull, term_ctr(CID_SCON, STAT_OFF + 2460), 116ull, term_ctr(CID_SCON, STAT_OFF + 2462), 117ull, term_ctr(CID_SCON, STAT_OFF + 2464), 112ull, term_ctr(CID_SCON, STAT_OFF + 2466), 116ull, term_ctr(CID_SCON, STAT_OFF + 2468), 117ull, term_ctr(CID_SCON, STAT_OFF + 2470), 111ull, term_ctr(CID_SCON, STAT_OFF + 2472), 32ull, term_ctr(CID_SCON, STAT_OFF + 2474), 101ull, term_ctr(CID_SCON, STAT_OFF + 2476), 116ull, term_ctr(CID_SCON, STAT_OFF + 2478), 97ull, term_ctr(CID_SCON, STAT_OFF + 2480), 99ull, term_ctr(CID_SCON, STAT_OFF + 2482), 105ull, term_ctr(CID_SCON, STAT_OFF + 2484), 108ull, term_ctr(CID_SCON, STAT_OFF + 2486), 112ull, term_ctr(CID_SCON, STAT_OFF + 2488), 117ull, term_ctr(CID_SCON, STAT_OFF + 2490), 100ull, term_ctr(CID_SCON, STAT_OFF + 2492), term_ctr(CID_SCON, STAT_OFF + 2494), 104ull, term_pak(CID_SNIL, 0), 116ull, term_ctr(CID_SCON, STAT_OFF + 2497), 97ull, term_ctr(CID_SCON, STAT_OFF + 2499), 112ull, term_ctr(CID_SCON, STAT_OFF + 2501), 32ull, term_ctr(CID_SCON, STAT_OFF + 2503), 116ull, term_ctr(CID_SCON, STAT_OFF + 2505), 117ull, term_ctr(CID_SCON, STAT_OFF + 2507), 112ull, term_ctr(CID_SCON, STAT_OFF + 2509), 116ull, term_ctr(CID_SCON, STAT_OFF + 2511), 117ull, term_ctr(CID_SCON, STAT_OFF + 2513), 111ull, term_ctr(CID_SCON, STAT_OFF + 2515), 32ull, term_ctr(CID_SCON, STAT_OFF + 2517), 121ull, term_ctr(CID_SCON, STAT_OFF + 2519), 116ull, term_ctr(CID_SCON, STAT_OFF + 2521), 112ull, term_ctr(CID_SCON, STAT_OFF + 2523), 109ull, term_ctr(CID_SCON, STAT_OFF + 2525), 101ull, term_ctr(CID_SCON, STAT_OFF + 2527), term_ctr(CID_SCON, STAT_OFF + 2529), 103ull, term_ctr(CID_SCON, STAT_OFF + 2519), 110ull, term_ctr(CID_SCON, STAT_OFF + 2532), 105ull, term_ctr(CID_SCON, STAT_OFF + 2534), 115ull, term_ctr(CID_SCON, STAT_OFF + 2536), 115ull, term_ctr(CID_SCON, STAT_OFF + 2538), 105ull, term_ctr(CID_SCON, STAT_OFF + 2540), 109ull, term_ctr(CID_SCON, STAT_OFF + 2542), 116ull, term_ctr(CID_SCON, STAT_OFF + 2), 101ull, term_ctr(CID_SCON, STAT_OFF + 2546), 115ull, term_ctr(CID_SCON, STAT_OFF + 2548), 115ull, term_ctr(CID_SCON, STAT_OFF + 2550), 97ull, term_ctr(CID_SCON, STAT_OFF + 2552), 32ull, term_ctr(CID_SCON, STAT_OFF + 2554), 114ull, term_ctr(CID_SCON, STAT_OFF + 2556), 101ull, term_ctr(CID_SCON, STAT_OFF + 2558), 108ull, term_ctr(CID_SCON, STAT_OFF + 2560), 105ull, term_ctr(CID_SCON, STAT_OFF + 2562), 112ull, term_ctr(CID_SCON, STAT_OFF + 2564), 109ull, term_ctr(CID_SCON, STAT_OFF + 2566), 111ull, term_ctr(CID_SCON, STAT_OFF + 2568), 99ull, term_ctr(CID_SCON, STAT_OFF + 2570), 32ull, term_ctr(CID_SCON, STAT_OFF + 2572), 110ull, term_ctr(CID_SCON, STAT_OFF + 2574), 119ull, term_ctr(CID_SCON, STAT_OFF + 2576), 111ull, term_ctr(CID_SCON, STAT_OFF + 2578), 110ull, term_ctr(CID_SCON, STAT_OFF + 2580), 107ull, term_ctr(CID_SCON, STAT_OFF + 2582), 110ull, term_ctr(CID_SCON, STAT_OFF + 2584), 117ull, term_ctr(CID_SCON, STAT_OFF + 2586), 47ull, term_pak(CID_SNIL, 0), 115ull, term_ctr(CID_SCON, STAT_OFF + 2590), 116ull, term_ctr(CID_SCON, STAT_OFF + 2592), 101ull, term_ctr(CID_SCON, STAT_OFF + 2594), 115ull, term_ctr(CID_SCON, STAT_OFF + 2596), 115ull, term_ctr(CID_SCON, STAT_OFF + 2598), 97ull, term_ctr(CID_SCON, STAT_OFF + 2600), 47ull, term_ctr(CID_SCON, STAT_OFF + 2602), 101ull, term_ctr(CID_SCON, STAT_OFF + 12), 114ull, term_ctr(CID_SCON, STAT_OFF + 2606), 105ull, term_ctr(CID_SCON, STAT_OFF + 2608), 117ull, term_ctr(CID_SCON, STAT_OFF + 2610), 113ull, term_ctr(CID_SCON, STAT_OFF + 2612), 101ull, term_ctr(CID_SCON, STAT_OFF + 2614), 114ull, term_ctr(CID_SCON, STAT_OFF + 2616), 32ull, term_ctr(CID_SCON, STAT_OFF + 2618), 101ull, term_ctr(CID_SCON, STAT_OFF + 2620), 114ull, term_ctr(CID_SCON, STAT_OFF + 2622), 97ull, term_ctr(CID_SCON, STAT_OFF + 2624), 32ull, term_ctr(CID_SCON, STAT_OFF + 2626), 99ull, term_ctr(CID_SCON, STAT_OFF + 2628), 46ull, term_ctr(CID_SCON, STAT_OFF + 2630), 84ull, term_ctr(CID_SCON, STAT_OFF + 2632), 85ull, term_ctr(CID_SCON, STAT_OFF + 2634), 80ull, term_ctr(CID_SCON, STAT_OFF + 2636), 84ull, term_ctr(CID_SCON, STAT_OFF + 2638), 85ull, term_ctr(CID_SCON, STAT_OFF + 2640), 79ull, term_ctr(CID_SCON, STAT_OFF + 2642), 32ull, term_ctr(CID_SCON, STAT_OFF + 2644), 111ull, term_ctr(CID_SCON, STAT_OFF + 2646), 45ull, term_ctr(CID_SCON, STAT_OFF + 2648), 32ull, term_ctr(CID_SCON, STAT_OFF + 2650), 100ull, term_ctr(CID_SCON, STAT_OFF + 2652), 110ull, term_ctr(CID_SCON, STAT_OFF + 2654), 97ull, term_ctr(CID_SCON, STAT_OFF + 2656), 32ull, term_ctr(CID_SCON, STAT_OFF + 2658), 116ull, term_ctr(CID_SCON, STAT_OFF + 2660), 117ull, term_ctr(CID_SCON, STAT_OFF + 2662), 112ull, term_ctr(CID_SCON, STAT_OFF + 2664), 110ull, term_ctr(CID_SCON, STAT_OFF + 2666), 105ull, term_ctr(CID_SCON, STAT_OFF + 2668), 32ull, term_ctr(CID_SCON, STAT_OFF + 2670), 101ull, term_ctr(CID_SCON, STAT_OFF + 2672), 110ull, term_ctr(CID_SCON, STAT_OFF + 2674), 111ull, term_ctr(CID_SCON, STAT_OFF + 2676), term_ctr(CID_SCON, STAT_OFF + 2678), 111ull, term_pak(CID_SNIL, 0), 45ull, term_ctr(CID_SCON, STAT_OFF + 2681), 116ull, term_pak(CID_SNIL, 0), 117ull, term_ctr(CID_SCON, STAT_OFF + 2685), 112ull, term_ctr(CID_SCON, STAT_OFF + 2687), 116ull, term_ctr(CID_SCON, STAT_OFF + 2689), 117ull, term_ctr(CID_SCON, STAT_OFF + 2691), 111ull, term_ctr(CID_SCON, STAT_OFF + 2693), 45ull, term_ctr(CID_SCON, STAT_OFF + 2695), 45ull, term_ctr(CID_SCON, STAT_OFF + 2697), term_ctr(CID_SCON, STAT_OFF + 2544), 45ull, term_pak(CID_SNIL, 0), 45ull, term_ctr(CID_SCON, STAT_OFF + 2702), 101ull, term_pak(CID_SNIL, 0), 118ull, term_ctr(CID_SCON, STAT_OFF + 2706), 105ull, term_ctr(CID_SCON, STAT_OFF + 2708), 108ull, term_ctr(CID_SCON, STAT_OFF + 2710), 45ull, term_ctr(CID_SCON, STAT_OFF + 2712), 45ull, term_ctr(CID_SCON, STAT_OFF + 2714), 32ull, term_ctr(CID_SCON, STAT_OFF + 2716), 101ull, term_ctr(CID_SCON, STAT_OFF + 2718), 116ull, term_ctr(CID_SCON, STAT_OFF + 2720), 97ull, term_ctr(CID_SCON, STAT_OFF + 2722), 99ull, term_ctr(CID_SCON, STAT_OFF + 2724), 105ull, term_ctr(CID_SCON, STAT_OFF + 2726), 108ull, term_ctr(CID_SCON, STAT_OFF + 2728), 112ull, term_ctr(CID_SCON, STAT_OFF + 2730), 117ull, term_ctr(CID_SCON, STAT_OFF + 2732), 100ull, term_ctr(CID_SCON, STAT_OFF + 2734), term_ctr(CID_SCON, STAT_OFF + 2736), 110ull, term_ctr(CID_SCON, STAT_OFF + 2), 111ull, term_ctr(CID_SCON, STAT_OFF + 2739), 105ull, term_ctr(CID_SCON, STAT_OFF + 2741), 116ull, term_ctr(CID_SCON, STAT_OFF + 2743), 112ull, term_ctr(CID_SCON, STAT_OFF + 2745), 111ull, term_ctr(CID_SCON, STAT_OFF + 2747), 32ull, term_ctr(CID_SCON, STAT_OFF + 2749), 110ull, term_ctr(CID_SCON, STAT_OFF + 2751), 119ull, term_ctr(CID_SCON, STAT_OFF + 2753), 111ull, term_ctr(CID_SCON, STAT_OFF + 2755), 110ull, term_ctr(CID_SCON, STAT_OFF + 2757), 107ull, term_ctr(CID_SCON, STAT_OFF + 2759), 110ull, term_ctr(CID_SCON, STAT_OFF + 2761), 117ull, term_ctr(CID_SCON, STAT_OFF + 2763), 110ull, term_ctr(CID_SCON, STAT_OFF + 2511), 105ull, term_ctr(CID_SCON, STAT_OFF + 2767), 32ull, term_ctr(CID_SCON, STAT_OFF + 2769), 121ull, term_ctr(CID_SCON, STAT_OFF + 2771), 116ull, term_ctr(CID_SCON, STAT_OFF + 2773), 112ull, term_ctr(CID_SCON, STAT_OFF + 2775), 109ull, term_ctr(CID_SCON, STAT_OFF + 2777), 101ull, term_ctr(CID_SCON, STAT_OFF + 2779), 110ull, term_ctr(CID_SCON, STAT_OFF + 2781), 111ull, term_ctr(CID_SCON, STAT_OFF + 2783), 110ull, term_ctr(CID_SCON, STAT_OFF + 2785), 32ull, term_ctr(CID_SCON, STAT_OFF + 2787), 101ull, term_ctr(CID_SCON, STAT_OFF + 2789), 110ull, term_ctr(CID_SCON, STAT_OFF + 2791), 111ull, term_ctr(CID_SCON, STAT_OFF + 2793), 32ull, term_ctr(CID_SCON, STAT_OFF + 2795), 121ull, term_ctr(CID_SCON, STAT_OFF + 2797), 108ull, term_ctr(CID_SCON, STAT_OFF + 2799), 116ull, term_ctr(CID_SCON, STAT_OFF + 2801), 99ull, term_ctr(CID_SCON, STAT_OFF + 2803), 97ull, term_ctr(CID_SCON, STAT_OFF + 2805), 120ull, term_ctr(CID_SCON, STAT_OFF + 2807), 101ull, term_ctr(CID_SCON, STAT_OFF + 2809), 32ull, term_ctr(CID_SCON, STAT_OFF + 2811), 100ull, term_ctr(CID_SCON, STAT_OFF + 2813), 101ull, term_ctr(CID_SCON, STAT_OFF + 2815), 116ull, term_ctr(CID_SCON, STAT_OFF + 2817), 99ull, term_ctr(CID_SCON, STAT_OFF + 2819), 101ull, term_ctr(CID_SCON, STAT_OFF + 2821), 112ull, term_ctr(CID_SCON, STAT_OFF + 2823), 120ull, term_ctr(CID_SCON, STAT_OFF + 2825), 101ull, term_ctr(CID_SCON, STAT_OFF + 2827), term_ctr(CID_SCON, STAT_OFF + 2829), 46ull, term_pak(CID_SNIL, 0), 121ull, term_ctr(CID_SCON, STAT_OFF + 2832), 108ull, term_ctr(CID_SCON, STAT_OFF + 2834), 101ull, term_ctr(CID_SCON, STAT_OFF + 2836), 116ull, term_ctr(CID_SCON, STAT_OFF + 2838), 97ull, term_ctr(CID_SCON, STAT_OFF + 2840), 114ull, term_ctr(CID_SCON, STAT_OFF + 2842), 97ull, term_ctr(CID_SCON, STAT_OFF + 2844), 112ull, term_ctr(CID_SCON, STAT_OFF + 2846), 101ull, term_ctr(CID_SCON, STAT_OFF + 2848), 115ull, term_ctr(CID_SCON, STAT_OFF + 2850), 32ull, term_ctr(CID_SCON, STAT_OFF + 2852), 67ull, term_ctr(CID_SCON, STAT_OFF + 2854), 32ull, term_ctr(CID_SCON, STAT_OFF + 2856), 100ull, term_ctr(CID_SCON, STAT_OFF + 2858), 101ull, term_ctr(CID_SCON, STAT_OFF + 2860), 116ull, term_ctr(CID_SCON, STAT_OFF + 2862), 116ull, term_ctr(CID_SCON, STAT_OFF + 2864), 105ull, term_ctr(CID_SCON, STAT_OFF + 2866), 109ull, term_ctr(CID_SCON, STAT_OFF + 2868), 101ull, term_ctr(CID_SCON, STAT_OFF + 2870), 32ull, term_ctr(CID_SCON, STAT_OFF + 2872), 100ull, term_ctr(CID_SCON, STAT_OFF + 2874), 108ull, term_ctr(CID_SCON, STAT_OFF + 2876), 105ull, term_ctr(CID_SCON, STAT_OFF + 2878), 117ull, term_ctr(CID_SCON, STAT_OFF + 2880), 66ull, term_ctr(CID_SCON, STAT_OFF + 2882), 32ull, term_ctr(CID_SCON, STAT_OFF + 2884), 46ull, term_ctr(CID_SCON, STAT_OFF + 2886), 114ull, term_ctr(CID_SCON, STAT_OFF + 2888), 101ull, term_ctr(CID_SCON, STAT_OFF + 2890), 107ull, term_ctr(CID_SCON, STAT_OFF + 2892), 114ull, term_ctr(CID_SCON, STAT_OFF + 2894), 111ull, term_ctr(CID_SCON, STAT_OFF + 2896), 119ull, term_ctr(CID_SCON, STAT_OFF + 2898), 32ull, term_ctr(CID_SCON, STAT_OFF + 2900), 85ull, term_ctr(CID_SCON, STAT_OFF + 2902), 80ull, term_ctr(CID_SCON, STAT_OFF + 2904), 67ull, term_ctr(CID_SCON, STAT_OFF + 2906), 32ull, term_ctr(CID_SCON, STAT_OFF + 2908), 101ull, term_ctr(CID_SCON, STAT_OFF + 2910), 110ull, term_ctr(CID_SCON, STAT_OFF + 2912), 111ull, term_ctr(CID_SCON, STAT_OFF + 2914), 32ull, term_ctr(CID_SCON, STAT_OFF + 2916), 115ull, term_ctr(CID_SCON, STAT_OFF + 2918), 101ull, term_ctr(CID_SCON, STAT_OFF + 2920), 115ull, term_ctr(CID_SCON, STAT_OFF + 2922), 117ull, term_ctr(CID_SCON, STAT_OFF + 2924), 32ull, term_ctr(CID_SCON, STAT_OFF + 2926), 110ull, term_ctr(CID_SCON, STAT_OFF + 2928), 111ull, term_ctr(CID_SCON, STAT_OFF + 2930), 105ull, term_ctr(CID_SCON, STAT_OFF + 2932), 116ull, term_ctr(CID_SCON, STAT_OFF + 2934), 117ull, term_ctr(CID_SCON, STAT_OFF + 2936), 99ull, term_ctr(CID_SCON, STAT_OFF + 2938), 101ull, term_ctr(CID_SCON, STAT_OFF + 2940), 120ull, term_ctr(CID_SCON, STAT_OFF + 2942), 101ull, term_ctr(CID_SCON, STAT_OFF + 2944), 32ull, term_ctr(CID_SCON, STAT_OFF + 2946), 114ull, term_ctr(CID_SCON, STAT_OFF + 2948), 101ull, term_ctr(CID_SCON, STAT_OFF + 2950), 108ull, term_ctr(CID_SCON, STAT_OFF + 2952), 105ull, term_ctr(CID_SCON, STAT_OFF + 2954), 112ull, term_ctr(CID_SCON, STAT_OFF + 2956), 109ull, term_ctr(CID_SCON, STAT_OFF + 2958), 111ull, term_ctr(CID_SCON, STAT_OFF + 2960), 67ull, term_ctr(CID_SCON, STAT_OFF + 2962), 10ull, term_ctr(CID_SCON, STAT_OFF + 2964), 46ull, term_ctr(CID_SCON, STAT_OFF + 2966), 101ull, term_ctr(CID_SCON, STAT_OFF + 2968), 115ull, term_ctr(CID_SCON, STAT_OFF + 2970), 111ull, term_ctr(CID_SCON, STAT_OFF + 2972), 108ull, term_ctr(CID_SCON, STAT_OFF + 2974), 99ull, term_ctr(CID_SCON, STAT_OFF + 2976), 47ull, term_ctr(CID_SCON, STAT_OFF + 2978), 101ull, term_ctr(CID_SCON, STAT_OFF + 2980), 116ull, term_ctr(CID_SCON, STAT_OFF + 2982), 105ull, term_ctr(CID_SCON, STAT_OFF + 2984), 114ull, term_ctr(CID_SCON, STAT_OFF + 2986), 119ull, term_ctr(CID_SCON, STAT_OFF + 2988), 47ull, term_ctr(CID_SCON, STAT_OFF + 2990), 101ull, term_ctr(CID_SCON, STAT_OFF + 2992), 122ull, term_ctr(CID_SCON, STAT_OFF + 2994), 105ull, term_ctr(CID_SCON, STAT_OFF + 2996), 115ull, term_ctr(CID_SCON, STAT_OFF + 2998), 47ull, term_ctr(CID_SCON, STAT_OFF + 3000), 100ull, term_ctr(CID_SCON, STAT_OFF + 3002), 97ull, term_ctr(CID_SCON, STAT_OFF + 3004), 101ull, term_ctr(CID_SCON, STAT_OFF + 3006), 114ull, term_ctr(CID_SCON, STAT_OFF + 3008), 47ull, term_ctr(CID_SCON, STAT_OFF + 3010), 110ull, term_ctr(CID_SCON, STAT_OFF + 3012), 101ull, term_ctr(CID_SCON, STAT_OFF + 3014), 112ull, term_ctr(CID_SCON, STAT_OFF + 3016), 111ull, term_ctr(CID_SCON, STAT_OFF + 3018), 46ull, term_ctr(CID_SCON, STAT_OFF + 3020), 101ull, term_ctr(CID_SCON, STAT_OFF + 3022), 108ull, term_ctr(CID_SCON, STAT_OFF + 3024), 105ull, term_ctr(CID_SCON, STAT_OFF + 3026), 70ull, term_ctr(CID_SCON, STAT_OFF + 3028), 32ull, term_ctr(CID_SCON, STAT_OFF + 3030), 100ull, term_ctr(CID_SCON, STAT_OFF + 3032), 110ull, term_ctr(CID_SCON, STAT_OFF + 3034), 97ull, term_ctr(CID_SCON, STAT_OFF + 3036), 32ull, term_ctr(CID_SCON, STAT_OFF + 3038), 119ull, term_ctr(CID_SCON, STAT_OFF + 3040), 111ull, term_ctr(CID_SCON, STAT_OFF + 3042), 110ull, term_ctr(CID_SCON, STAT_OFF + 3044), 47ull, term_ctr(CID_SCON, STAT_OFF + 3046), 114ull, term_ctr(CID_SCON, STAT_OFF + 3048), 114ull, term_ctr(CID_SCON, STAT_OFF + 3050), 101ull, term_ctr(CID_SCON, STAT_OFF + 3052), 95ull, term_ctr(CID_SCON, STAT_OFF + 3054), 116ull, term_ctr(CID_SCON, STAT_OFF + 3056), 110ull, term_ctr(CID_SCON, STAT_OFF + 3058), 105ull, term_ctr(CID_SCON, STAT_OFF + 3060), 114ull, term_ctr(CID_SCON, STAT_OFF + 3062), 112ull, term_ctr(CID_SCON, STAT_OFF + 3064), 47ull, term_ctr(CID_SCON, STAT_OFF + 3066), 116ull, term_ctr(CID_SCON, STAT_OFF + 3068), 110ull, term_ctr(CID_SCON, STAT_OFF + 3070), 105ull, term_ctr(CID_SCON, STAT_OFF + 3072), 114ull, term_ctr(CID_SCON, STAT_OFF + 3074), 112ull, term_ctr(CID_SCON, STAT_OFF + 3076), 47ull, term_ctr(CID_SCON, STAT_OFF + 3078), 115ull, term_ctr(CID_SCON, STAT_OFF + 3080), 103ull, term_ctr(CID_SCON, STAT_OFF + 3082), 114ull, term_ctr(CID_SCON, STAT_OFF + 3084), 97ull, term_ctr(CID_SCON, STAT_OFF + 3086), 46ull, term_ctr(CID_SCON, STAT_OFF + 3088), 79ull, term_ctr(CID_SCON, STAT_OFF + 3090), 73ull, term_ctr(CID_SCON, STAT_OFF + 3092), 32ull, term_ctr(CID_SCON, STAT_OFF + 3094), 58ull, term_ctr(CID_SCON, STAT_OFF + 3096), 115ull, term_ctr(CID_SCON, STAT_OFF + 3098), 116ull, term_ctr(CID_SCON, STAT_OFF + 3100), 99ull, term_ctr(CID_SCON, STAT_OFF + 3102), 101ull, term_ctr(CID_SCON, STAT_OFF + 3104), 102ull, term_ctr(CID_SCON, STAT_OFF + 3106), 102ull, term_ctr(CID_SCON, STAT_OFF + 3108), 101ull, term_ctr(CID_SCON, STAT_OFF + 3110), 32ull, term_ctr(CID_SCON, STAT_OFF + 3112), 100ull, term_ctr(CID_SCON, STAT_OFF + 3114), 101ull, term_ctr(CID_SCON, STAT_OFF + 3116), 116ull, term_ctr(CID_SCON, STAT_OFF + 3118), 114ull, term_ctr(CID_SCON, STAT_OFF + 3120), 111ull, term_ctr(CID_SCON, STAT_OFF + 3122), 112ull, term_ctr(CID_SCON, STAT_OFF + 3124), 112ull, term_ctr(CID_SCON, STAT_OFF + 3126), 117ull, term_ctr(CID_SCON, STAT_OFF + 3128), 83ull, term_ctr(CID_SCON, STAT_OFF + 3130), 10ull, term_ctr(CID_SCON, STAT_OFF + 3132), 46ull, term_ctr(CID_SCON, STAT_OFF + 3134), 41ull, term_ctr(CID_SCON, STAT_OFF + 3136), 115ull, term_ctr(CID_SCON, STAT_OFF + 3138), 104ull, term_ctr(CID_SCON, STAT_OFF + 3140), 116ull, term_ctr(CID_SCON, STAT_OFF + 3142), 97ull, term_ctr(CID_SCON, STAT_OFF + 3144), 112ull, term_ctr(CID_SCON, STAT_OFF + 3146), 32ull, term_ctr(CID_SCON, STAT_OFF + 3148), 116ull, term_ctr(CID_SCON, STAT_OFF + 3150), 117ull, term_ctr(CID_SCON, STAT_OFF + 3152), 112ull, term_ctr(CID_SCON, STAT_OFF + 3154), 110ull, term_ctr(CID_SCON, STAT_OFF + 3156), 105ull, term_ctr(CID_SCON, STAT_OFF + 3158), 32ull, term_ctr(CID_SCON, STAT_OFF + 3160), 101ull, term_ctr(CID_SCON, STAT_OFF + 3162), 114ull, term_ctr(CID_SCON, STAT_OFF + 3164), 97ull, term_ctr(CID_SCON, STAT_OFF + 3166), 32ull, term_ctr(CID_SCON, STAT_OFF + 3168), 115ull, term_ctr(CID_SCON, STAT_OFF + 3170), 116ull, term_ctr(CID_SCON, STAT_OFF + 3172), 110ull, term_ctr(CID_SCON, STAT_OFF + 3174), 101ull, term_ctr(CID_SCON, STAT_OFF + 3176), 109ull, term_ctr(CID_SCON, STAT_OFF + 3178), 117ull, term_ctr(CID_SCON, STAT_OFF + 3180), 103ull, term_ctr(CID_SCON, STAT_OFF + 3182), 114ull, term_ctr(CID_SCON, STAT_OFF + 3184), 97ull, term_ctr(CID_SCON, STAT_OFF + 3186), 32ull, term_ctr(CID_SCON, STAT_OFF + 3188), 103ull, term_ctr(CID_SCON, STAT_OFF + 3190), 110ull, term_ctr(CID_SCON, STAT_OFF + 3192), 105ull, term_ctr(CID_SCON, STAT_OFF + 3194), 110ull, term_ctr(CID_SCON, STAT_OFF + 3196), 105ull, term_ctr(CID_SCON, STAT_OFF + 3198), 97ull, term_ctr(CID_SCON, STAT_OFF + 3200), 109ull, term_ctr(CID_SCON, STAT_OFF + 3202), 101ull, term_ctr(CID_SCON, STAT_OFF + 3204), 114ull, term_ctr(CID_SCON, STAT_OFF + 3206), 40ull, term_ctr(CID_SCON, STAT_OFF + 3208), 32ull, term_ctr(CID_SCON, STAT_OFF + 3210), 45ull, term_ctr(CID_SCON, STAT_OFF + 3212), 45ull, term_ctr(CID_SCON, STAT_OFF + 3214), 32ull, term_ctr(CID_SCON, STAT_OFF + 3216), 59ull, term_ctr(CID_SCON, STAT_OFF + 3218), 110ull, term_ctr(CID_SCON, STAT_OFF + 3220), 111ull, term_ctr(CID_SCON, STAT_OFF + 3222), 105ull, term_ctr(CID_SCON, STAT_OFF + 3224), 115ull, term_ctr(CID_SCON, STAT_OFF + 3226), 114ull, term_ctr(CID_SCON, STAT_OFF + 3228), 101ull, term_ctr(CID_SCON, STAT_OFF + 3230), 118ull, term_ctr(CID_SCON, STAT_OFF + 3232), 45ull, term_ctr(CID_SCON, STAT_OFF + 3234), 45ull, term_ctr(CID_SCON, STAT_OFF + 3236), 32ull, term_ctr(CID_SCON, STAT_OFF + 3238), 59ull, term_ctr(CID_SCON, STAT_OFF + 3240), 112ull, term_ctr(CID_SCON, STAT_OFF + 3242), 108ull, term_ctr(CID_SCON, STAT_OFF + 3244), 101ull, term_ctr(CID_SCON, STAT_OFF + 3246), 104ull, term_ctr(CID_SCON, STAT_OFF + 3248), 45ull, term_ctr(CID_SCON, STAT_OFF + 3250), 45ull, term_ctr(CID_SCON, STAT_OFF + 3252), 32ull, term_ctr(CID_SCON, STAT_OFF + 3254), 32ull, term_ctr(CID_SCON, STAT_OFF + 3256), 32ull, term_ctr(CID_SCON, STAT_OFF + 3258), 32ull, term_ctr(CID_SCON, STAT_OFF + 3260), 32ull, term_ctr(CID_SCON, STAT_OFF + 3262), 32ull, term_ctr(CID_SCON, STAT_OFF + 3264), 32ull, term_ctr(CID_SCON, STAT_OFF + 3266), 32ull, term_ctr(CID_SCON, STAT_OFF + 3268), 32ull, term_ctr(CID_SCON, STAT_OFF + 3270), 10ull, term_ctr(CID_SCON, STAT_OFF + 3272), 59ull, term_ctr(CID_SCON, STAT_OFF + 3274), 41ull, term_ctr(CID_SCON, STAT_OFF + 3276), 101ull, term_ctr(CID_SCON, STAT_OFF + 3278), 104ull, term_ctr(CID_SCON, STAT_OFF + 3280), 99ull, term_ctr(CID_SCON, STAT_OFF + 3282), 97ull, term_ctr(CID_SCON, STAT_OFF + 3284), 99ull, term_ctr(CID_SCON, STAT_OFF + 3286), 32ull, term_ctr(CID_SCON, STAT_OFF + 3288), 115ull, term_ctr(CID_SCON, STAT_OFF + 3290), 116ull, term_ctr(CID_SCON, STAT_OFF + 3292), 105ull, term_ctr(CID_SCON, STAT_OFF + 3294), 32ull, term_ctr(CID_SCON, STAT_OFF + 3296), 116ull, term_ctr(CID_SCON, STAT_OFF + 3298), 117ull, term_ctr(CID_SCON, STAT_OFF + 3300), 111ull, term_ctr(CID_SCON, STAT_OFF + 3302), 104ull, term_ctr(CID_SCON, STAT_OFF + 3304), 116ull, term_ctr(CID_SCON, STAT_OFF + 3306), 105ull, term_ctr(CID_SCON, STAT_OFF + 3308), 119ull, term_ctr(CID_SCON, STAT_OFF + 3310), 32ull, term_ctr(CID_SCON, STAT_OFF + 3312), 101ull, term_ctr(CID_SCON, STAT_OFF + 3314), 115ull, term_ctr(CID_SCON, STAT_OFF + 3316), 97ull, term_ctr(CID_SCON, STAT_OFF + 3318), 66ull, term_ctr(CID_SCON, STAT_OFF + 3320), 32ull, term_ctr(CID_SCON, STAT_OFF + 3322), 101ull, term_ctr(CID_SCON, STAT_OFF + 3324), 114ull, term_ctr(CID_SCON, STAT_OFF + 3326), 97ull, term_ctr(CID_SCON, STAT_OFF + 3328), 112ull, term_ctr(CID_SCON, STAT_OFF + 3330), 101ull, term_ctr(CID_SCON, STAT_OFF + 3332), 114ull, term_ctr(CID_SCON, STAT_OFF + 3334), 112ull, term_ctr(CID_SCON, STAT_OFF + 3336), 40ull, term_ctr(CID_SCON, STAT_OFF + 3338), 32ull, term_ctr(CID_SCON, STAT_OFF + 3340), 101ull, term_ctr(CID_SCON, STAT_OFF + 3342), 118ull, term_ctr(CID_SCON, STAT_OFF + 3344), 105ull, term_ctr(CID_SCON, STAT_OFF + 3346), 108ull, term_ctr(CID_SCON, STAT_OFF + 3348), 45ull, term_ctr(CID_SCON, STAT_OFF + 3350), 45ull, term_ctr(CID_SCON, STAT_OFF + 3352), 32ull, term_ctr(CID_SCON, STAT_OFF + 3354), 59ull, term_ctr(CID_SCON, STAT_OFF + 3356), 72ull, term_ctr(CID_SCON, STAT_OFF + 3358), 84ull, term_ctr(CID_SCON, STAT_OFF + 3360), 65ull, term_ctr(CID_SCON, STAT_OFF + 3362), 80ull, term_ctr(CID_SCON, STAT_OFF + 3364), 32ull, term_ctr(CID_SCON, STAT_OFF + 3366), 116ull, term_ctr(CID_SCON, STAT_OFF + 3368), 117ull, term_ctr(CID_SCON, STAT_OFF + 3370), 112ull, term_ctr(CID_SCON, STAT_OFF + 3372), 116ull, term_ctr(CID_SCON, STAT_OFF + 3374), 117ull, term_ctr(CID_SCON, STAT_OFF + 3376), 111ull, term_ctr(CID_SCON, STAT_OFF + 3378), 45ull, term_ctr(CID_SCON, STAT_OFF + 3380), 45ull, term_ctr(CID_SCON, STAT_OFF + 3382), 32ull, term_ctr(CID_SCON, STAT_OFF + 3384), 44ull, term_ctr(CID_SCON, STAT_OFF + 3386), 111ull, term_ctr(CID_SCON, STAT_OFF + 3388), 45ull, term_ctr(CID_SCON, STAT_OFF + 3390), 32ull, term_ctr(CID_SCON, STAT_OFF + 3392), 58ull, term_ctr(CID_SCON, STAT_OFF + 3394), 115ull, term_ctr(CID_SCON, STAT_OFF + 3396), 110ull, term_ctr(CID_SCON, STAT_OFF + 3398), 111ull, term_ctr(CID_SCON, STAT_OFF + 3400), 105ull, term_ctr(CID_SCON, STAT_OFF + 3402), 116ull, term_ctr(CID_SCON, STAT_OFF + 3404), 112ull, term_ctr(CID_SCON, STAT_OFF + 3406), 79ull, term_ctr(CID_SCON, STAT_OFF + 3408), 10ull, term_ctr(CID_SCON, STAT_OFF + 3410), 46ull, term_ctr(CID_SCON, STAT_OFF + 3412), 100ull, term_ctr(CID_SCON, STAT_OFF + 3414), 101ull, term_ctr(CID_SCON, STAT_OFF + 3416), 115ull, term_ctr(CID_SCON, STAT_OFF + 3418), 117ull, term_ctr(CID_SCON, STAT_OFF + 3420), 102ull, term_ctr(CID_SCON, STAT_OFF + 3422), 101ull, term_ctr(CID_SCON, STAT_OFF + 3424), 114ull, term_ctr(CID_SCON, STAT_OFF + 3426), 32ull, term_ctr(CID_SCON, STAT_OFF + 3428), 101ull, term_ctr(CID_SCON, STAT_OFF + 3430), 114ull, term_ctr(CID_SCON, STAT_OFF + 3432), 97ull, term_ctr(CID_SCON, STAT_OFF + 3434), 32ull, term_ctr(CID_SCON, STAT_OFF + 3436), 115ull, term_ctr(CID_SCON, STAT_OFF + 3438), 116ull, term_ctr(CID_SCON, STAT_OFF + 3440), 117ull, term_ctr(CID_SCON, STAT_OFF + 3442), 112ull, term_ctr(CID_SCON, STAT_OFF + 3444), 116ull, term_ctr(CID_SCON, STAT_OFF + 3446), 117ull, term_ctr(CID_SCON, STAT_OFF + 3448), 111ull, term_ctr(CID_SCON, STAT_OFF + 3450), 32ull, term_ctr(CID_SCON, STAT_OFF + 3452), 103ull, term_ctr(CID_SCON, STAT_OFF + 3454), 110ull, term_ctr(CID_SCON, STAT_OFF + 3456), 105ull, term_ctr(CID_SCON, STAT_OFF + 3458), 116ull, term_ctr(CID_SCON, STAT_OFF + 3460), 115ull, term_ctr(CID_SCON, STAT_OFF + 3462), 105ull, term_ctr(CID_SCON, STAT_OFF + 3464), 120ull, term_ctr(CID_SCON, STAT_OFF + 3466), 69ull, term_ctr(CID_SCON, STAT_OFF + 3468), 32ull, term_ctr(CID_SCON, STAT_OFF + 3470), 46ull, term_ctr(CID_SCON, STAT_OFF + 3472), 67ull, term_ctr(CID_SCON, STAT_OFF + 3474), 32ull, term_ctr(CID_SCON, STAT_OFF + 3476), 111ull, term_ctr(CID_SCON, STAT_OFF + 3478), 116ull, term_ctr(CID_SCON, STAT_OFF + 3480), 32ull, term_ctr(CID_SCON, STAT_OFF + 3482), 101ull, term_ctr(CID_SCON, STAT_OFF + 3484), 99ull, term_ctr(CID_SCON, STAT_OFF + 3486), 114ull, term_ctr(CID_SCON, STAT_OFF + 3488), 117ull, term_ctr(CID_SCON, STAT_OFF + 3490), 111ull, term_ctr(CID_SCON, STAT_OFF + 3492), 115ull, term_ctr(CID_SCON, STAT_OFF + 3494), 32ull, term_ctr(CID_SCON, STAT_OFF + 3496), 100ull, term_ctr(CID_SCON, STAT_OFF + 3498), 110ull, term_ctr(CID_SCON, STAT_OFF + 3500), 101ull, term_ctr(CID_SCON, STAT_OFF + 3502), 66ull, term_ctr(CID_SCON, STAT_OFF + 3504), 32ull, term_ctr(CID_SCON, STAT_OFF + 3506), 103ull, term_ctr(CID_SCON, STAT_OFF + 3508), 110ull, term_ctr(CID_SCON, STAT_OFF + 3510), 105ull, term_ctr(CID_SCON, STAT_OFF + 3512), 116ull, term_ctr(CID_SCON, STAT_OFF + 3514), 114ull, term_ctr(CID_SCON, STAT_OFF + 3516), 111ull, term_ctr(CID_SCON, STAT_OFF + 3518), 112ull, term_ctr(CID_SCON, STAT_OFF + 3520), 109ull, term_ctr(CID_SCON, STAT_OFF + 3522), 105ull, term_ctr(CID_SCON, STAT_OFF + 3524), 45ull, term_ctr(CID_SCON, STAT_OFF + 3526), 101ull, term_ctr(CID_SCON, STAT_OFF + 3528), 115ull, term_ctr(CID_SCON, STAT_OFF + 3530), 97ull, term_ctr(CID_SCON, STAT_OFF + 3532), 66ull, term_ctr(CID_SCON, STAT_OFF + 3534), 32ull, term_ctr(CID_SCON, STAT_OFF + 3536), 101ull, term_ctr(CID_SCON, STAT_OFF + 3538), 110ull, term_ctr(CID_SCON, STAT_OFF + 3540), 111ull, term_ctr(CID_SCON, STAT_OFF + 3542), 32ull, term_ctr(CID_SCON, STAT_OFF + 3544), 101ull, term_ctr(CID_SCON, STAT_OFF + 3546), 108ull, term_ctr(CID_SCON, STAT_OFF + 3548), 105ull, term_ctr(CID_SCON, STAT_OFF + 3550), 112ull, term_ctr(CID_SCON, STAT_OFF + 3552), 109ull, term_ctr(CID_SCON, STAT_OFF + 3554), 111ull, term_ctr(CID_SCON, STAT_OFF + 3556), 67ull, term_ctr(CID_SCON, STAT_OFF + 3558), 10ull, term_ctr(CID_SCON, STAT_OFF + 3560), 10ull, term_ctr(CID_SCON, STAT_OFF + 3562), 93ull, term_ctr(CID_SCON, STAT_OFF + 3564), 101ull, term_ctr(CID_SCON, STAT_OFF + 3566), 118ull, term_ctr(CID_SCON, STAT_OFF + 3568), 105ull, term_ctr(CID_SCON, STAT_OFF + 3570), 108ull, term_ctr(CID_SCON, STAT_OFF + 3572), 45ull, term_ctr(CID_SCON, STAT_OFF + 3574), 45ull, term_ctr(CID_SCON, STAT_OFF + 3576), 91ull, term_ctr(CID_SCON, STAT_OFF + 3578), 32ull, term_ctr(CID_SCON, STAT_OFF + 3580), 99ull, term_ctr(CID_SCON, STAT_OFF + 3582), 46ull, term_ctr(CID_SCON, STAT_OFF + 3584), 84ull, term_ctr(CID_SCON, STAT_OFF + 3586), 85ull, term_ctr(CID_SCON, STAT_OFF + 3588), 80ull, term_ctr(CID_SCON, STAT_OFF + 3590), 84ull, term_ctr(CID_SCON, STAT_OFF + 3592), 85ull, term_ctr(CID_SCON, STAT_OFF + 3594), 79ull, term_ctr(CID_SCON, STAT_OFF + 3596), 32ull, term_ctr(CID_SCON, STAT_OFF + 3598), 111ull, term_ctr(CID_SCON, STAT_OFF + 3600), 45ull, term_ctr(CID_SCON, STAT_OFF + 3602), 32ull, term_ctr(CID_SCON, STAT_OFF + 3604), 100ull, term_ctr(CID_SCON, STAT_OFF + 3606), 110ull, term_ctr(CID_SCON, STAT_OFF + 3608), 101ull, term_ctr(CID_SCON, STAT_OFF + 3610), 98ull, term_ctr(CID_SCON, STAT_OFF + 3612), 46ull, term_ctr(CID_SCON, STAT_OFF + 3614), 84ull, term_ctr(CID_SCON, STAT_OFF + 3616), 85ull, term_ctr(CID_SCON, STAT_OFF + 3618), 80ull, term_ctr(CID_SCON, STAT_OFF + 3620), 78ull, term_ctr(CID_SCON, STAT_OFF + 3622), 73ull, term_ctr(CID_SCON, STAT_OFF + 3624), 32ull, term_ctr(CID_SCON, STAT_OFF + 3626), 100ull, term_ctr(CID_SCON, STAT_OFF + 3628), 110ull, term_ctr(CID_SCON, STAT_OFF + 3630), 101ull, term_ctr(CID_SCON, STAT_OFF + 3632), 98ull, term_ctr(CID_SCON, STAT_OFF + 3634), 32ull, term_ctr(CID_SCON, STAT_OFF + 3636), 58ull, term_ctr(CID_SCON, STAT_OFF + 3638), 101ull, term_ctr(CID_SCON, STAT_OFF + 3640), 103ull, term_ctr(CID_SCON, STAT_OFF + 3642), 97ull, term_ctr(CID_SCON, STAT_OFF + 3644), 115ull, term_ctr(CID_SCON, STAT_OFF + 3646), 85ull, term_ctr(CID_SCON, STAT_OFF + 3648), 112ull, term_pak(CID_SNIL, 0), 108ull, term_ctr(CID_SCON, STAT_OFF + 3652), 101ull, term_ctr(CID_SCON, STAT_OFF + 3654), 104ull, term_ctr(CID_SCON, STAT_OFF + 3656), 45ull, term_ctr(CID_SCON, STAT_OFF + 3658), 45ull, term_ctr(CID_SCON, STAT_OFF + 3660), 115ull, term_ctr(CID_SCON, STAT_OFF + 2454), 114ull, term_ctr(CID_SCON, STAT_OFF + 3664), 101ull, term_ctr(CID_SCON, STAT_OFF + 3666), 118ull, term_ctr(CID_SCON, STAT_OFF + 3668), 45ull, term_ctr(CID_SCON, STAT_OFF + 3670), 45ull, term_ctr(CID_SCON, STAT_OFF + 3672), 10ull, term_pak(CID_SNIL, 0), 66ull, term_ctr(CID_SCON, STAT_OFF + 616), 32ull, term_ctr(CID_SCON, STAT_OFF + 3678), 101ull, term_ctr(CID_SCON, STAT_OFF + 3680), 118ull, term_ctr(CID_SCON, STAT_OFF + 3682), 105ull, term_ctr(CID_SCON, STAT_OFF + 3684), 116ull, term_ctr(CID_SCON, STAT_OFF + 3686), 97ull, term_ctr(CID_SCON, STAT_OFF + 3688), 110ull, term_ctr(CID_SCON, STAT_OFF + 3690), 32ull, term_ctr(CID_SCON, STAT_OFF + 3692), 47ull, term_ctr(CID_SCON, STAT_OFF + 3694), 32ull, term_ctr(CID_SCON, STAT_OFF + 3696), 52ull, term_ctr(CID_SCON, STAT_OFF + 3698), 48ull, term_ctr(CID_SCON, STAT_OFF + 3700), 103ull, term_ctr(CID_SCON, STAT_OFF + 3702), 110ull, term_ctr(CID_SCON, STAT_OFF + 3704), 105ull, term_ctr(CID_SCON, STAT_OFF + 3706), 114ull, term_ctr(CID_SCON, STAT_OFF + 3708), 101ull, term_ctr(CID_SCON, STAT_OFF + 3710), 119ull, term_ctr(CID_SCON, STAT_OFF + 3712), 111ull, term_ctr(CID_SCON, STAT_OFF + 3714), 108ull, term_ctr(CID_SCON, STAT_OFF + 3716), 45ull, term_ctr(CID_SCON, STAT_OFF + 3718), 50ull, term_ctr(CID_SCON, STAT_OFF + 3720), 48ull, term_ctr(CID_SCON, STAT_OFF + 3722), 49ull, term_ctr(CID_SCON, STAT_OFF + 3724), 101ull, term_ctr(CID_SCON, STAT_OFF + 3726), 115ull, term_ctr(CID_SCON, STAT_OFF + 3728), 97ull, term_ctr(CID_SCON, STAT_OFF + 3730), 104ull, term_ctr(CID_SCON, STAT_OFF + 3732), 112ull, term_ctr(CID_SCON, STAT_OFF + 3734), 32ull, term_ctr(CID_SCON, STAT_OFF + 3736), 47ull, term_ctr(CID_SCON, STAT_OFF + 3738), 32ull, term_ctr(CID_SCON, STAT_OFF + 3740), 51ull, term_ctr(CID_SCON, STAT_OFF + 3742), 48ull, term_ctr(CID_SCON, STAT_OFF + 3744), 49ull, term_ctr(CID_SCON, STAT_OFF + 3746), 101ull, term_ctr(CID_SCON, STAT_OFF + 3748), 115ull, term_ctr(CID_SCON, STAT_OFF + 3750), 97ull, term_ctr(CID_SCON, STAT_OFF + 3752), 104ull, term_ctr(CID_SCON, STAT_OFF + 3754), 112ull, term_ctr(CID_SCON, STAT_OFF + 3756), 32ull, term_ctr(CID_SCON, STAT_OFF + 3758), 101ull, term_ctr(CID_SCON, STAT_OFF + 3760), 118ull, term_ctr(CID_SCON, STAT_OFF + 3762), 105ull, term_ctr(CID_SCON, STAT_OFF + 3764), 116ull, term_ctr(CID_SCON, STAT_OFF + 3766), 97ull, term_ctr(CID_SCON, STAT_OFF + 3768), 110ull, term_ctr(CID_SCON, STAT_OFF + 3770), 45ull, term_ctr(CID_SCON, STAT_OFF + 3772), 100ull, term_ctr(CID_SCON, STAT_OFF + 3774), 110ull, term_ctr(CID_SCON, STAT_OFF + 3776), 101ull, term_ctr(CID_SCON, STAT_OFF + 3778), 98ull, term_ctr(CID_SCON, STAT_OFF + 3780) };

INLINE Term spin_0(Env e, THR Term* o, u32 r0, u32 r1, Term r2, Term r3, u32 r4) {
  u32 wpoll = 0;
  u32 _h1b_0 = r0;
  u32 _h2b_0 = r1;
  Term _rr_0 = r2;
  Term _rr_1 = r3;
  u32 _rr_2 = r4;
  WL_SPIN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _h1b_0);
    e.mem[_nd_2 + 1] = rfc_seal(e, _rr_0);
    u64 _nd_3 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_3 + 0] = rfc_seal(e, _h2b_0);
    e.mem[_nd_3 + 1] = rfc_seal(e, _rr_1);
    o[0] = term_ctr(CID_SCON, _nd_2);
    o[1] = term_ctr(CID_SCON, _nd_3);
    o[2] = _rr_2;
  break;
  }
  return 1;
}

INLINE Term spin_1(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _a_1 = r0;
  u32 _b_1 = r1;
  WL_SPIN
    o[0] = _a_1;
    o[1] = _b_1;
    o[2] = (U32_BIN(_a_1, >, _b_1) + U32_BIN(_a_1, >=, _b_1));
  break;
  }
  return 1;
}

INLINE Term spin_2(Env e, THR Term* o, u32 r0, Term r1, Term r2) {
  u32 wpoll = 0;
  u32 _code_0 = r0;
  Term _msg_0 = r1;
  Term _k_0 = r2;
  WL_SPIN
    term_sink(e, _k_0);
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = _code_0;
    e.mem[_nd_2 + 1] = _msg_0;
    o[0] = term_ctr(CID_HALT, _nd_2);
  break;
  }
  return 1;
}

INLINE Term spin_3(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    o[0] = U32_BIN(_a_0, ==, _b_0);
  break;
  }
  return 1;
}

INLINE Term spin_4(Env e, THR Term* o, Term r0) {
  u32 wpoll = 0;
  Term _s_0 = r0;
  WL_SPIN
    if (term_aux(_s_0) == CID_SNIL) {
      o[0] = 1;
    } else {
      u64 _sp_1 = term_peek(e.mem, _s_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      o[0] = 0;
    }
  break;
  }
  return 1;
}

INLINE Term spin_5(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _b_0 = r0;
  WL_SPIN
    if (_b_0 == 0) {
      o[0] = 1;
    } else {
      o[0] = 0;
    }
  break;
  }
  return 1;
}

INLINE Term spin_6(Env e, THR Term* o, Term r0, Term r1) {
  u32 wpoll = 0;
  Term _p_0 = r0;
  Term _p_1 = r1;
  WL_SPIN
    term_sink(e, _p_0);
    o[0] = _p_1;
  break;
  }
  return 1;
}

INLINE Term spin_7(Env e, THR Term* o, u32 r0, u32 r1) {
  u32 wpoll = 0;
  u32 _a_0 = r0;
  u32 _b_0 = r1;
  WL_SPIN
    if (_a_0 == 0) {
      o[0] = 0;
    } else {
      o[0] = _b_0;
    }
  break;
  }
  return 1;
}

INLINE Term spin_8(Env e, THR Term* o, u32 r0) {
  u32 wpoll = 0;
  u32 _c_0 = r0;
  WL_SPIN
    if (_c_0 == 1) {
      o[0] = 1;
    } else {
      o[0] = 0;
    }
  break;
  }
  return 1;
}

INLINE Term spin_9(Env e, THR Term* o, u32 r0, Term r1, Term r2) {
  u32 wpoll = 0;
  u32 _result_0 = r0;
  Term _result_1 = r1;
  Term _result_2 = r2;
  WL_SPIN
    if (_result_0 == 1) {
      u64 _nd_4 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_4 + 0] = _result_1;
      o[0] = term_clo(FID_CLI_PASS_C135, _nd_4);
    } else {
      u64 _nd_5 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_5 + 0] = _result_2;
      o[0] = term_clo(FID_CLI_PASS_C136, _nd_5);
    }
  break;
  }
  return 1;
}

INLINE Term spin_11(Env e, THR Term* o, u32 r0, Term r1, Term r2) {
  u32 wpoll = 0;
  u32 _code_0 = r0;
  Term _msg_0 = r1;
  Term _k_0 = r2;
  WL_SPIN
    term_sink(e, _k_0);
    u64 _nd_21 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_21 + 0] = _code_0;
    e.mem[_nd_21 + 1] = _msg_0;
    o[0] = term_ctr(CID_HALT, _nd_21);
  break;
  }
  return 1;
}

INLINE Term spin_10(Env e, THR Term* o, u32 r0, Term r1, Term r2) {
  u32 wpoll = 0;
  u32 _result_5 = r0;
  Term _result_6 = r1;
  Term _result_7 = r2;
  WL_SPIN
    if (_result_5 == 1) {
      u64 _nd_19 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_19 + 0] = _result_6;
      o[0] = term_clo(FID_CLI_PASS_C151, _nd_19);
    } else {
      u64 _nd_20 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_20 + 0] = _result_7;
      o[0] = term_clo(FID_CLI_PASS_C152, _nd_20);
    }
  break;
  }
  return 1;
}

INLINE Term spin_12(Env e, THR Term* o, u32 r0, Term r1, Term r2) {
  u32 wpoll = 0;
  u32 _code_0 = r0;
  Term _msg_0 = r1;
  Term _k_0 = r2;
  WL_SPIN
    term_sink(e, _k_0);
    u64 _nd_1 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_1 + 0] = _code_0;
    e.mem[_nd_1 + 1] = _msg_0;
    o[0] = term_ctr(CID_HALT, _nd_1);
  break;
  }
  return 1;
}

// Work
// ====

// A host self-jump is a tail call: as a loop, clang hoisted constants into
// symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN    WL_JMP

typedef Term (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#endif

static Term work_loop(Env e, DEV Term* sp, Term t, u32 seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  u32 fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

// A task enters through its words: a continuation's results ride r0..
// and its parameters the stack; any other segment's parameters ride r0..

#if !DEVICE
  WL_CASE(FID_STRING_CMP)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      if (term_aux(_b_0) == CID_SNIL) {
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 1;
        WL_RETN(3);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _b_0, 2, _fb_0);
        u32 _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        u64 _nd_0 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_0 + 0] = rfc_seal(e, _f_0);
        e.mem[_nd_0 + 1] = rfc_seal(e, _f_1);
        r0 = term_pak(CID_SNIL, 0);
        r1 = term_ctr(CID_SCON, _nd_0);
        r2 = 0;
        WL_RETN(3);
      }
    } else {
      Term _fb_1[2];
      u64 _sp_1 = ctr_take(e, _a_0, 2, _fb_1);
      u32 _f_2 = _fb_1[0];
      Term _f_3 = _fb_1[1];
      if (term_aux(_b_0) == CID_SNIL) {
        u64 _nd_1 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_1 + 0] = rfc_seal(e, _f_2);
        e.mem[_nd_1 + 1] = rfc_seal(e, _f_3);
        r0 = term_ctr(CID_SCON, _nd_1);
        r1 = term_pak(CID_SNIL, 0);
        r2 = 2;
        WL_RETN(3);
      } else {
        Term _fb_2[2];
        u64 _sp_2 = ctr_take(e, _b_0, 2, _fb_2);
        u32 _f_4 = _fb_2[0];
        Term _f_5 = _fb_2[1];
        u32 _v_0 = 0;
        u32 _v_1 = 0;
        u32 _v_2 = 0;
        Term _o_0[3];
        if (spin_1(e, _o_0, _f_2, _f_4) == 0) {
          return 0;
        }
        _v_0 = (u32)_o_0[0];
        _v_1 = (u32)_o_0[1];
        _v_2 = (u32)_o_0[2];
        if (_v_2 == 0) {
          u64 _nd_2 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_2 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_2 + 1] = rfc_seal(e, _f_3);
          u64 _nd_3 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_3 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_3 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_2);
          r1 = term_ctr(CID_SCON, _nd_3);
          r2 = 0;
          WL_RETN(3);
        } else if (_v_2 == 1) {
          spare_free(e, cls_fit(2), _sp_2);
          spare_free(e, cls_fit(2), _sp_1);
          if (seq) {
            WL_ROOM(3);
            STK(0) = _v_0;
            STK(1) = _v_1;
            STK(2) = FID_STRING_CMP_K7;
            WL_PUSHN(3);
          } else {
            u64 _t_0 = task_node(e, FID_STRING_CMP_K7, WL_CONT, WL_IDX, 1);
            e.mem[_t_0 + 0] = _v_0;
            e.mem[_t_0 + 1] = _v_1;
            WL_CONT = term_tsk(FID_STRING_CMP_K7, _t_0);
            WL_IDX = 2;
          }
          r0 = _f_3;
          r1 = _f_5;
          _a_0 = r0;
          _b_0 = r1;
          WL_AGAIN(FID_STRING_CMP);
        } else {
          u64 _nd_4 = _sp_1 >= HEAP_OFF ? _sp_1 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_4 + 0] = rfc_seal(e, _v_0);
          e.mem[_nd_4 + 1] = rfc_seal(e, _f_3);
          u64 _nd_5 = _sp_2 >= HEAP_OFF ? _sp_2 : heap_alloc(e, cls_fit(2));
          e.mem[_nd_5 + 0] = rfc_seal(e, _v_1);
          e.mem[_nd_5 + 1] = rfc_seal(e, _f_5);
          r0 = term_ctr(CID_SCON, _nd_4);
          r1 = term_ctr(CID_SCON, _nd_5);
          r2 = 2;
          WL_RETN(3);
        }
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_CMP_K7)
  {
    WL_POPN(2);
    u32 _v_3 = STK(0);
    u32 _v_4 = STK(1);
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    Term _o_1[3];
    if (spin_0(e, _o_1, _v_3, _v_4, _h_0, _h_1, _h_2) == 0) {
      return 0;
    }
    r0 = _o_1[0];
    r1 = _o_1[1];
    r2 = (u32)_o_1[2];
    WL_RETN(3);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST)
  {
    Term _name_0 = r0;
    WL_OPEN
    _name_0 = term_keep(e, _name_0, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_0;
      STK(1) = FID_CLI_DIGEST_K16;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_CLI_DIGEST_K16, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _name_0;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K16, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_1 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _name_0;
      e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 28);
      return term_tsk(FID_STRING_EQ, _t_1);
    }
    r0 = _name_0;
    r1 = term_ctr(CID_SCON, STAT_OFF + 28);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K16)
  {
    WL_POPN(1);
    Term _name_1 = STK(0);
    u32 _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _name_1;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_47 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_47 + 0] = _h_0;
      e.mem[_t_47 + 1] = term_clo(FID_CLI_DIGEST_C17, 0);
      e.mem[_t_47 + 2] = term_clo(FID_CLI_DIGEST_C18, _nd_0);
      return term_tsk(FID_KC, _t_47);
    }
    r0 = _h_0;
    r1 = term_clo(FID_CLI_DIGEST_C17, 0);
    r2 = term_clo(FID_CLI_DIGEST_C18, _nd_0);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C17)
  {
    Term _x_0 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 156);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C18)
  {
    Term _name_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    _name_2 = term_keep(e, _name_2, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_2;
      STK(1) = FID_CLI_DIGEST_K19;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CLI_DIGEST_K19, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _name_2;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K19, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_3 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _name_2;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 172);
      return term_tsk(FID_STRING_EQ, _t_3);
    }
    r0 = _name_2;
    r1 = term_ctr(CID_SCON, STAT_OFF + 172);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K19)
  {
    WL_POPN(1);
    Term _name_3 = STK(0);
    u32 _h_1 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _name_3;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_46 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_46 + 0] = _h_1;
      e.mem[_t_46 + 1] = term_clo(FID_CLI_DIGEST_C20, 0);
      e.mem[_t_46 + 2] = term_clo(FID_CLI_DIGEST_C21, _nd_1);
      return term_tsk(FID_KC, _t_46);
    }
    r0 = _h_1;
    r1 = term_clo(FID_CLI_DIGEST_C20, 0);
    r2 = term_clo(FID_CLI_DIGEST_C21, _nd_1);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C20)
  {
    Term _x_2 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 300);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C21)
  {
    Term _name_4 = r0;
    Term _x_3 = r1;
    WL_OPEN
    _name_4 = term_keep(e, _name_4, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_4;
      STK(1) = FID_CLI_DIGEST_K22;
      WL_PUSHN(2);
    } else {
      u64 _t_4 = task_node(e, FID_CLI_DIGEST_K22, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _name_4;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K22, _t_4);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_5 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _name_4;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 330);
      return term_tsk(FID_STRING_EQ, _t_5);
    }
    r0 = _name_4;
    r1 = term_ctr(CID_SCON, STAT_OFF + 330);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K22)
  {
    WL_POPN(1);
    Term _name_5 = STK(0);
    u32 _h_2 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = _name_5;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_45 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_45 + 0] = _h_2;
      e.mem[_t_45 + 1] = term_clo(FID_CLI_DIGEST_C23, 0);
      e.mem[_t_45 + 2] = term_clo(FID_CLI_DIGEST_C24, _nd_2);
      return term_tsk(FID_KC, _t_45);
    }
    r0 = _h_2;
    r1 = term_clo(FID_CLI_DIGEST_C23, 0);
    r2 = term_clo(FID_CLI_DIGEST_C24, _nd_2);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C23)
  {
    Term _x_4 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 456);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C24)
  {
    Term _name_6 = r0;
    Term _x_5 = r1;
    WL_OPEN
    _name_6 = term_keep(e, _name_6, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_6;
      STK(1) = FID_CLI_DIGEST_K25;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_CLI_DIGEST_K25, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _name_6;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K25, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_7 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _name_6;
      e.mem[_t_7 + 1] = term_ctr(CID_SCON, STAT_OFF + 486);
      return term_tsk(FID_STRING_EQ, _t_7);
    }
    r0 = _name_6;
    r1 = term_ctr(CID_SCON, STAT_OFF + 486);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K25)
  {
    WL_POPN(1);
    Term _name_7 = STK(0);
    u32 _h_3 = r0;
    WL_OPEN
    u64 _nd_3 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_3 + 0] = _name_7;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_44 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_44 + 0] = _h_3;
      e.mem[_t_44 + 1] = term_clo(FID_CLI_DIGEST_C26, 0);
      e.mem[_t_44 + 2] = term_clo(FID_CLI_DIGEST_C27, _nd_3);
      return term_tsk(FID_KC, _t_44);
    }
    r0 = _h_3;
    r1 = term_clo(FID_CLI_DIGEST_C26, 0);
    r2 = term_clo(FID_CLI_DIGEST_C27, _nd_3);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C26)
  {
    Term _x_6 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 614);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C27)
  {
    Term _name_8 = r0;
    Term _x_7 = r1;
    WL_OPEN
    _name_8 = term_keep(e, _name_8, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_8;
      STK(1) = FID_CLI_DIGEST_K28;
      WL_PUSHN(2);
    } else {
      u64 _t_8 = task_node(e, FID_CLI_DIGEST_K28, WL_CONT, WL_IDX, 1);
      e.mem[_t_8 + 0] = _name_8;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K28, _t_8);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_9 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _name_8;
      e.mem[_t_9 + 1] = term_ctr(CID_SCON, STAT_OFF + 644);
      return term_tsk(FID_STRING_EQ, _t_9);
    }
    r0 = _name_8;
    r1 = term_ctr(CID_SCON, STAT_OFF + 644);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K28)
  {
    WL_POPN(1);
    Term _name_9 = STK(0);
    u32 _h_4 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_4 + 0] = _name_9;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_43 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_43 + 0] = _h_4;
      e.mem[_t_43 + 1] = term_clo(FID_CLI_DIGEST_C29, 0);
      e.mem[_t_43 + 2] = term_clo(FID_CLI_DIGEST_C30, _nd_4);
      return term_tsk(FID_KC, _t_43);
    }
    r0 = _h_4;
    r1 = term_clo(FID_CLI_DIGEST_C29, 0);
    r2 = term_clo(FID_CLI_DIGEST_C30, _nd_4);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C29)
  {
    Term _x_8 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 770);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C30)
  {
    Term _name_10 = r0;
    Term _x_9 = r1;
    WL_OPEN
    _name_10 = term_keep(e, _name_10, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_10;
      STK(1) = FID_CLI_DIGEST_K31;
      WL_PUSHN(2);
    } else {
      u64 _t_10 = task_node(e, FID_CLI_DIGEST_K31, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _name_10;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K31, _t_10);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_11 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _name_10;
      e.mem[_t_11 + 1] = term_ctr(CID_SCON, STAT_OFF + 800);
      return term_tsk(FID_STRING_EQ, _t_11);
    }
    r0 = _name_10;
    r1 = term_ctr(CID_SCON, STAT_OFF + 800);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K31)
  {
    WL_POPN(1);
    Term _name_11 = STK(0);
    u32 _h_5 = r0;
    WL_OPEN
    u64 _nd_5 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_5 + 0] = _name_11;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_42 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_42 + 0] = _h_5;
      e.mem[_t_42 + 1] = term_clo(FID_CLI_DIGEST_C32, 0);
      e.mem[_t_42 + 2] = term_clo(FID_CLI_DIGEST_C33, _nd_5);
      return term_tsk(FID_KC, _t_42);
    }
    r0 = _h_5;
    r1 = term_clo(FID_CLI_DIGEST_C32, 0);
    r2 = term_clo(FID_CLI_DIGEST_C33, _nd_5);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C32)
  {
    Term _x_10 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 928);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C33)
  {
    Term _name_12 = r0;
    Term _x_11 = r1;
    WL_OPEN
    _name_12 = term_keep(e, _name_12, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_12;
      STK(1) = FID_CLI_DIGEST_K34;
      WL_PUSHN(2);
    } else {
      u64 _t_12 = task_node(e, FID_CLI_DIGEST_K34, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _name_12;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K34, _t_12);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_13 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _name_12;
      e.mem[_t_13 + 1] = term_ctr(CID_SCON, STAT_OFF + 958);
      return term_tsk(FID_STRING_EQ, _t_13);
    }
    r0 = _name_12;
    r1 = term_ctr(CID_SCON, STAT_OFF + 958);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K34)
  {
    WL_POPN(1);
    Term _name_13 = STK(0);
    u32 _h_6 = r0;
    WL_OPEN
    u64 _nd_6 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_6 + 0] = _name_13;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_41 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_41 + 0] = _h_6;
      e.mem[_t_41 + 1] = term_clo(FID_CLI_DIGEST_C35, 0);
      e.mem[_t_41 + 2] = term_clo(FID_CLI_DIGEST_C36, _nd_6);
      return term_tsk(FID_KC, _t_41);
    }
    r0 = _h_6;
    r1 = term_clo(FID_CLI_DIGEST_C35, 0);
    r2 = term_clo(FID_CLI_DIGEST_C36, _nd_6);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C35)
  {
    Term _x_12 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 1086);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C36)
  {
    Term _name_14 = r0;
    Term _x_13 = r1;
    WL_OPEN
    _name_14 = term_keep(e, _name_14, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_14;
      STK(1) = FID_CLI_DIGEST_K37;
      WL_PUSHN(2);
    } else {
      u64 _t_14 = task_node(e, FID_CLI_DIGEST_K37, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _name_14;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K37, _t_14);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_15 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _name_14;
      e.mem[_t_15 + 1] = term_ctr(CID_SCON, STAT_OFF + 1108);
      return term_tsk(FID_STRING_EQ, _t_15);
    }
    r0 = _name_14;
    r1 = term_ctr(CID_SCON, STAT_OFF + 1108);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K37)
  {
    WL_POPN(1);
    Term _name_15 = STK(0);
    u32 _h_7 = r0;
    WL_OPEN
    u64 _nd_7 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_7 + 0] = _name_15;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_40 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_40 + 0] = _h_7;
      e.mem[_t_40 + 1] = term_clo(FID_CLI_DIGEST_C38, 0);
      e.mem[_t_40 + 2] = term_clo(FID_CLI_DIGEST_C39, _nd_7);
      return term_tsk(FID_KC, _t_40);
    }
    r0 = _h_7;
    r1 = term_clo(FID_CLI_DIGEST_C38, 0);
    r2 = term_clo(FID_CLI_DIGEST_C39, _nd_7);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C38)
  {
    Term _x_14 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 1234);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C39)
  {
    Term _name_16 = r0;
    Term _x_15 = r1;
    WL_OPEN
    _name_16 = term_keep(e, _name_16, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_16;
      STK(1) = FID_CLI_DIGEST_K40;
      WL_PUSHN(2);
    } else {
      u64 _t_16 = task_node(e, FID_CLI_DIGEST_K40, WL_CONT, WL_IDX, 1);
      e.mem[_t_16 + 0] = _name_16;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K40, _t_16);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_17 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _name_16;
      e.mem[_t_17 + 1] = term_ctr(CID_SCON, STAT_OFF + 1254);
      return term_tsk(FID_STRING_EQ, _t_17);
    }
    r0 = _name_16;
    r1 = term_ctr(CID_SCON, STAT_OFF + 1254);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K40)
  {
    WL_POPN(1);
    Term _name_17 = STK(0);
    u32 _h_8 = r0;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_8 + 0] = _name_17;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_39 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_39 + 0] = _h_8;
      e.mem[_t_39 + 1] = term_clo(FID_CLI_DIGEST_C41, 0);
      e.mem[_t_39 + 2] = term_clo(FID_CLI_DIGEST_C42, _nd_8);
      return term_tsk(FID_KC, _t_39);
    }
    r0 = _h_8;
    r1 = term_clo(FID_CLI_DIGEST_C41, 0);
    r2 = term_clo(FID_CLI_DIGEST_C42, _nd_8);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C41)
  {
    Term _x_16 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 1382);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C42)
  {
    Term _name_18 = r0;
    Term _x_17 = r1;
    WL_OPEN
    _name_18 = term_keep(e, _name_18, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_18;
      STK(1) = FID_CLI_DIGEST_K43;
      WL_PUSHN(2);
    } else {
      u64 _t_18 = task_node(e, FID_CLI_DIGEST_K43, WL_CONT, WL_IDX, 1);
      e.mem[_t_18 + 0] = _name_18;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K43, _t_18);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_19 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = _name_18;
      e.mem[_t_19 + 1] = term_ctr(CID_SCON, STAT_OFF + 1398);
      return term_tsk(FID_STRING_EQ, _t_19);
    }
    r0 = _name_18;
    r1 = term_ctr(CID_SCON, STAT_OFF + 1398);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K43)
  {
    WL_POPN(1);
    Term _name_19 = STK(0);
    u32 _h_9 = r0;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_9 + 0] = _name_19;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_38 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_38 + 0] = _h_9;
      e.mem[_t_38 + 1] = term_clo(FID_CLI_DIGEST_C44, 0);
      e.mem[_t_38 + 2] = term_clo(FID_CLI_DIGEST_C45, _nd_9);
      return term_tsk(FID_KC, _t_38);
    }
    r0 = _h_9;
    r1 = term_clo(FID_CLI_DIGEST_C44, 0);
    r2 = term_clo(FID_CLI_DIGEST_C45, _nd_9);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C44)
  {
    Term _x_18 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 1524);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C45)
  {
    Term _name_20 = r0;
    Term _x_19 = r1;
    WL_OPEN
    _name_20 = term_keep(e, _name_20, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_20;
      STK(1) = FID_CLI_DIGEST_K46;
      WL_PUSHN(2);
    } else {
      u64 _t_20 = task_node(e, FID_CLI_DIGEST_K46, WL_CONT, WL_IDX, 1);
      e.mem[_t_20 + 0] = _name_20;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K46, _t_20);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_21 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _name_20;
      e.mem[_t_21 + 1] = term_ctr(CID_SCON, STAT_OFF + 1552);
      return term_tsk(FID_STRING_EQ, _t_21);
    }
    r0 = _name_20;
    r1 = term_ctr(CID_SCON, STAT_OFF + 1552);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K46)
  {
    WL_POPN(1);
    Term _name_21 = STK(0);
    u32 _h_10 = r0;
    WL_OPEN
    u64 _nd_10 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_10 + 0] = _name_21;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_37 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_37 + 0] = _h_10;
      e.mem[_t_37 + 1] = term_clo(FID_CLI_DIGEST_C47, 0);
      e.mem[_t_37 + 2] = term_clo(FID_CLI_DIGEST_C48, _nd_10);
      return term_tsk(FID_KC, _t_37);
    }
    r0 = _h_10;
    r1 = term_clo(FID_CLI_DIGEST_C47, 0);
    r2 = term_clo(FID_CLI_DIGEST_C48, _nd_10);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C47)
  {
    Term _x_20 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 1678);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C48)
  {
    Term _name_22 = r0;
    Term _x_21 = r1;
    WL_OPEN
    _name_22 = term_keep(e, _name_22, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_22;
      STK(1) = FID_CLI_DIGEST_K49;
      WL_PUSHN(2);
    } else {
      u64 _t_22 = task_node(e, FID_CLI_DIGEST_K49, WL_CONT, WL_IDX, 1);
      e.mem[_t_22 + 0] = _name_22;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K49, _t_22);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_23 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = _name_22;
      e.mem[_t_23 + 1] = term_ctr(CID_SCON, STAT_OFF + 1706);
      return term_tsk(FID_STRING_EQ, _t_23);
    }
    r0 = _name_22;
    r1 = term_ctr(CID_SCON, STAT_OFF + 1706);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K49)
  {
    WL_POPN(1);
    Term _name_23 = STK(0);
    u32 _h_11 = r0;
    WL_OPEN
    u64 _nd_11 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_11 + 0] = _name_23;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_36 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_36 + 0] = _h_11;
      e.mem[_t_36 + 1] = term_clo(FID_CLI_DIGEST_C50, 0);
      e.mem[_t_36 + 2] = term_clo(FID_CLI_DIGEST_C51, _nd_11);
      return term_tsk(FID_KC, _t_36);
    }
    r0 = _h_11;
    r1 = term_clo(FID_CLI_DIGEST_C50, 0);
    r2 = term_clo(FID_CLI_DIGEST_C51, _nd_11);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C50)
  {
    Term _x_22 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 1832);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C51)
  {
    Term _name_24 = r0;
    Term _x_23 = r1;
    WL_OPEN
    _name_24 = term_keep(e, _name_24, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_24;
      STK(1) = FID_CLI_DIGEST_K52;
      WL_PUSHN(2);
    } else {
      u64 _t_24 = task_node(e, FID_CLI_DIGEST_K52, WL_CONT, WL_IDX, 1);
      e.mem[_t_24 + 0] = _name_24;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K52, _t_24);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_25 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _name_24;
      e.mem[_t_25 + 1] = term_ctr(CID_SCON, STAT_OFF + 1860);
      return term_tsk(FID_STRING_EQ, _t_25);
    }
    r0 = _name_24;
    r1 = term_ctr(CID_SCON, STAT_OFF + 1860);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K52)
  {
    WL_POPN(1);
    Term _name_25 = STK(0);
    u32 _h_12 = r0;
    WL_OPEN
    u64 _nd_12 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_12 + 0] = _name_25;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_35 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_35 + 0] = _h_12;
      e.mem[_t_35 + 1] = term_clo(FID_CLI_DIGEST_C53, 0);
      e.mem[_t_35 + 2] = term_clo(FID_CLI_DIGEST_C54, _nd_12);
      return term_tsk(FID_KC, _t_35);
    }
    r0 = _h_12;
    r1 = term_clo(FID_CLI_DIGEST_C53, 0);
    r2 = term_clo(FID_CLI_DIGEST_C54, _nd_12);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C53)
  {
    Term _x_24 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 1986);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C54)
  {
    Term _name_26 = r0;
    Term _x_25 = r1;
    WL_OPEN
    _name_26 = term_keep(e, _name_26, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_26;
      STK(1) = FID_CLI_DIGEST_K55;
      WL_PUSHN(2);
    } else {
      u64 _t_26 = task_node(e, FID_CLI_DIGEST_K55, WL_CONT, WL_IDX, 1);
      e.mem[_t_26 + 0] = _name_26;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K55, _t_26);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_27 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _name_26;
      e.mem[_t_27 + 1] = term_ctr(CID_SCON, STAT_OFF + 2014);
      return term_tsk(FID_STRING_EQ, _t_27);
    }
    r0 = _name_26;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2014);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K55)
  {
    WL_POPN(1);
    Term _name_27 = STK(0);
    u32 _h_13 = r0;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_13 + 0] = _name_27;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_34 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_34 + 0] = _h_13;
      e.mem[_t_34 + 1] = term_clo(FID_CLI_DIGEST_C56, 0);
      e.mem[_t_34 + 2] = term_clo(FID_CLI_DIGEST_C57, _nd_13);
      return term_tsk(FID_KC, _t_34);
    }
    r0 = _h_13;
    r1 = term_clo(FID_CLI_DIGEST_C56, 0);
    r2 = term_clo(FID_CLI_DIGEST_C57, _nd_13);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C56)
  {
    Term _x_26 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 2140);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C57)
  {
    Term _name_28 = r0;
    Term _x_27 = r1;
    WL_OPEN
    _name_28 = term_keep(e, _name_28, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _name_28;
      STK(1) = FID_CLI_DIGEST_K58;
      WL_PUSHN(2);
    } else {
      u64 _t_28 = task_node(e, FID_CLI_DIGEST_K58, WL_CONT, WL_IDX, 1);
      e.mem[_t_28 + 0] = _name_28;
      WL_CONT = term_tsk(FID_CLI_DIGEST_K58, _t_28);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_29 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_29 + 0] = _name_28;
      e.mem[_t_29 + 1] = term_ctr(CID_SCON, STAT_OFF + 2168);
      return term_tsk(FID_STRING_EQ, _t_29);
    }
    r0 = _name_28;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2168);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K58)
  {
    WL_POPN(1);
    Term _name_29 = STK(0);
    u32 _h_14 = r0;
    WL_OPEN
    u64 _nd_14 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_14 + 0] = _name_29;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_33 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_33 + 0] = _h_14;
      e.mem[_t_33 + 1] = term_clo(FID_CLI_DIGEST_C59, 0);
      e.mem[_t_33 + 2] = term_clo(FID_CLI_DIGEST_C60, _nd_14);
      return term_tsk(FID_KC, _t_33);
    }
    r0 = _h_14;
    r1 = term_clo(FID_CLI_DIGEST_C59, 0);
    r2 = term_clo(FID_CLI_DIGEST_C60, _nd_14);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C59)
  {
    Term _x_28 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 2294);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C60)
  {
    Term _name_30 = r0;
    Term _x_29 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_DIGEST_K61;
      WL_PUSHN(1);
    } else {
      u64 _t_30 = task_node(e, FID_CLI_DIGEST_K61, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_DIGEST_K61, _t_30);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_31 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_31 + 0] = _name_30;
      e.mem[_t_31 + 1] = term_ctr(CID_SCON, STAT_OFF + 2322);
      return term_tsk(FID_STRING_EQ, _t_31);
    }
    r0 = _name_30;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2322);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_K61)
  {
    u32 _h_15 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_32 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_32 + 0] = _h_15;
      e.mem[_t_32 + 1] = term_clo(FID_CLI_DIGEST_C62, 0);
      e.mem[_t_32 + 2] = term_clo(FID_CLI_DIGEST_C63, 0);
      return term_tsk(FID_KC, _t_32);
    }
    r0 = _h_15;
    r1 = term_clo(FID_CLI_DIGEST_C62, 0);
    r2 = term_clo(FID_CLI_DIGEST_C63, 0);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C62)
  {
    Term _x_30 = r0;
    WL_OPEN
    r0 = term_ctr(CID_SCON, STAT_OFF + 2448);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_DIGEST_C63)
  {
    Term _x_31 = r0;
    WL_OPEN
    r0 = term_pak(CID_SNIL, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_STARTS_WITH)
  {
    Term _s_0 = r0;
    Term _p_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_s_0) == CID_SNIL) {
      if (term_aux(_p_0) == CID_SNIL) {
        r0 = 1;
        WL_RETN(1);
      } else {
        Term _fb_0[2];
        u64 _sp_0 = ctr_take(e, _p_0, 2, _fb_0);
        u32 _f_0 = _fb_0[0];
        Term _f_1 = _fb_0[1];
        term_sink(e, _f_1);
        spare_free(e, cls_fit(2), _sp_0);
        r0 = 0;
        WL_RETN(1);
      }
    } else {
      u64 _sp_1 = term_peek(e.mem, _s_0);
      u32 _f_2 = e.mem[_sp_1 + 0];
      Term _f_3 = e.mem[_sp_1 + 1];
      if (term_aux(_p_0) == CID_SNIL) {
        r0 = 1;
        WL_RETN(1);
      } else {
        Term _fb_1[2];
        u64 _sp_2 = ctr_take(e, _p_0, 2, _fb_1);
        u32 _f_4 = _fb_1[0];
        Term _f_5 = _fb_1[1];
        u32 _v_0 = 0;
        Term _o_0[1];
        if (spin_3(e, _o_0, _f_2, _f_4) == 0) {
          return 0;
        }
        _v_0 = (u32)_o_0[0];
        if (_v_0 == 0) {
          term_sink(e, _f_5);
          spare_free(e, cls_fit(2), _sp_2);
          r0 = 0;
          WL_RETN(1);
        } else {
          spare_free(e, cls_fit(2), _sp_2);
          r0 = _f_3;
          r1 = _f_5;
          _s_0 = r0;
          _p_0 = r1;
          WL_AGAIN(FID_STRING_STARTS_WITH);
        }
      }
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_ORDER_K76;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_ORDER_K76, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_ORDER_K76, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_CMP)) {
      u64 _t_1 = task_node(e, FID_STRING_CMP, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_CMP, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_CMP);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_ORDER_K76)
  {
    Term _h_0 = r0;
    Term _h_1 = r1;
    u32 _h_2 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _h_0;
    e.mem[_nd_0 + 1] = _h_1;
    Term _b_1 = 0;
    if (_h_2 == 0) {
      _b_1 = term_pak(CID_LT, 0);
    } else if (_h_2 == 1) {
      _b_1 = term_pak(CID_EQ, 0);
    } else {
      _b_1 = term_pak(CID_GT, 0);
    }
    Term _o_0[1];
    if (spin_6(e, _o_0, term_ctr(CID_TUPLE, _nd_0), _b_1) == 0) {
      return 0;
    }
    Term _u_0 = _o_0[0];
    u32 _o_1 = 0;
    if (term_aux(_u_0) == CID_LT) {
      _o_1 = 0;
    } else if (term_aux(_u_0) == CID_EQ) {
      _o_1 = 1;
    } else {
      _o_1 = 2;
    }
    r0 = _o_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ)
  {
    Term _path_0 = r0;
    Term _digest_0 = r1;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _path_0;
    e.mem[_nd_0 + 1] = _digest_0;
    r0 = term_clo(FID_CLI_READ_C79, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ_C79)
  {
    Term _path_1 = r0;
    Term _digest_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    _path_1 = term_keep(e, _path_1, 1);
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = _path_1;
    e.mem[_nd_1 + 1] = _digest_1;
    e.mem[_nd_1 + 2] = 16777216ull;
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = _path_1;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_7 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_clo(FID_NATIVEHOST_READ, _nd_1);
      e.mem[_t_7 + 1] = term_clo(FID_CLI_READ_C80, _nd_2);
      e.mem[_t_7 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_7);
    }
    r0 = term_clo(FID_NATIVEHOST_READ, _nd_1);
    r1 = term_clo(FID_CLI_READ_C80, _nd_2);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ_C80)
  {
    Term _path_2 = r0;
    Term _x_1 = r1;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    Term _o_2 = 0;
    if (term_aux(_x_1) == CID_FAIL) {
      _o_0 = 0;
      u64 _sp_0 = term_loc(_x_1);
      Term _f_0 = e.mem[_sp_0 + 0];
      heap_free(e, cls_fit(1), _sp_0);
      u64 _sp_1 = term_loc(_f_0);
      Term _f_1 = e.mem[_sp_1 + 0];
      Term _f_2 = e.mem[_sp_1 + 1];
      heap_free(e, cls_fit(2), _sp_1);
      _o_1 = _f_1;
      _o_2 = _f_2;
    } else {
      _o_0 = 1;
      u64 _sp_2 = term_loc(_x_1);
      Term _f_3 = e.mem[_sp_2 + 0];
      heap_free(e, cls_fit(1), _sp_2);
      _o_1 = _f_3;
    }
    if (_o_0 == 1) {
      term_sink(e, _path_2);
      u64 _nd_3 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_3 + 0] = _o_1;
      r0 = term_clo(FID_CLI_READ_C81, _nd_3);
      WL_RETN(1);
    } else {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _path_2;
        STK(1) = FID_CLI_READ_K82;
        WL_PUSHN(2);
      } else {
        u64 _t_1 = task_node(e, FID_CLI_READ_K82, WL_CONT, WL_IDX, 1);
        e.mem[_t_1 + 0] = _path_2;
        WL_CONT = term_tsk(FID_CLI_READ_K82, _t_1);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_2 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 2);
        e.mem[_t_2 + 1] = _o_2;
        return term_tsk(FID_STRING_APPEND, _t_2);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 2);
      r1 = _o_2;
      WL_JMP(FID_STRING_APPEND);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ_C81)
  {
    Term _o_3 = r0;
    Term _x_2 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_0 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _o_3;
      e.mem[_t_0 + 1] = _x_2;
      return term_tsk(FID_IO_PURE, _t_0);
    }
    r0 = _o_3;
    r1 = _x_2;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ_K82)
  {
    WL_POPN(1);
    Term _path_3 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_READ_K83;
      WL_PUSHN(1);
    } else {
      u64 _t_3 = task_node(e, FID_CLI_READ_K83, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_READ_K83, _t_3);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_4 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_4 + 0] = _path_3;
      e.mem[_t_4 + 1] = _h_0;
      return term_tsk(FID_STRING_APPEND, _t_4);
    }
    r0 = _path_3;
    r1 = _h_0;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ_K83)
  {
    Term _h_1 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_READ_K84;
      WL_PUSHN(1);
    } else {
      u64 _t_5 = task_node(e, FID_CLI_READ_K84, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_READ_K84, _t_5);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_6 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = term_ctr(CID_SCON, STAT_OFF + 10);
      e.mem[_t_6 + 1] = _h_1;
      return term_tsk(FID_STRING_APPEND, _t_6);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 10);
    r1 = _h_1;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ_K84)
  {
    Term _h_2 = r0;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_4 + 0] = _h_2;
    r0 = term_clo(FID_CLI_READ_C85, _nd_4);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_READ_C85)
  {
    Term _h_3 = r0;
    Term _x_3 = r1;
    WL_OPEN
    Term _o_4[1];
    if (spin_2(e, _o_4, 1ull, _h_3, _x_3) == 0) {
      return 0;
    }
    r0 = _o_4[0];
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET)
  {
    Term _root_0 = r0;
    Term _name_0 = r1;
    WL_OPEN
    _name_0 = term_keep(e, _name_0, 1);
    if (seq) {
      WL_ROOM(3);
      STK(0) = _root_0;
      STK(1) = _name_0;
      STK(2) = FID_CLI_ASSET_K87;
      WL_PUSHN(3);
    } else {
      u64 _t_0 = task_node(e, FID_CLI_ASSET_K87, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _root_0;
      e.mem[_t_0 + 1] = _name_0;
      WL_CONT = term_tsk(FID_CLI_ASSET_K87, _t_0);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_DIGEST)) {
      u64 _t_1 = task_node(e, FID_CLI_DIGEST, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _name_0;
      return term_tsk(FID_CLI_DIGEST, _t_1);
    }
    r0 = _name_0;
    WL_JMP(FID_CLI_DIGEST);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET_K87)
  {
    WL_POPN(2);
    Term _root_1 = STK(0);
    Term _name_1 = STK(1);
    Term _digest_0 = r0;
    WL_OPEN
    u32 _v_0 = 0;
    Term _o_0[1];
    if (spin_4(e, _o_0, _digest_0) == 0) {
      return 0;
    }
    _v_0 = (u32)_o_0[0];
    _name_1 = term_keep(e, _name_1, 1);
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _name_1;
    u64 _nd_2 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_2 + 0] = _root_1;
    e.mem[_nd_2 + 1] = _name_1;
    e.mem[_nd_2 + 2] = _digest_0;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_9 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = _v_0;
      e.mem[_t_9 + 1] = term_clo(FID_CLI_ASSET_C88, _nd_0);
      e.mem[_t_9 + 2] = term_clo(FID_CLI_ASSET_C91, _nd_2);
      return term_tsk(FID_KC, _t_9);
    }
    r0 = _v_0;
    r1 = term_clo(FID_CLI_ASSET_C88, _nd_0);
    r2 = term_clo(FID_CLI_ASSET_C91, _nd_2);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET_C88)
  {
    Term _name_2 = r0;
    Term _x_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_ASSET_K89;
      WL_PUSHN(1);
    } else {
      u64 _t_2 = task_node(e, FID_CLI_ASSET_K89, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_ASSET_K89, _t_2);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 2588);
      e.mem[_t_3 + 1] = _name_2;
      return term_tsk(FID_STRING_APPEND, _t_3);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2588);
    r1 = _name_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET_K89)
  {
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _h_0;
    r0 = term_clo(FID_CLI_ASSET_C90, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET_C90)
  {
    Term _h_1 = r0;
    Term _x_1 = r1;
    WL_OPEN
    Term _o_1[1];
    if (spin_2(e, _o_1, 1ull, _h_1, _x_1) == 0) {
      return 0;
    }
    r0 = _o_1[0];
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET_C91)
  {
    Term _root_2 = r0;
    Term _name_3 = r1;
    Term _digest_1 = r2;
    Term _x_2 = r3;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _root_2;
      STK(1) = _digest_1;
      STK(2) = FID_CLI_ASSET_K92;
      WL_PUSHN(3);
    } else {
      u64 _t_4 = task_node(e, FID_CLI_ASSET_K92, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _root_2;
      e.mem[_t_4 + 1] = _digest_1;
      WL_CONT = term_tsk(FID_CLI_ASSET_K92, _t_4);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_SCON, STAT_OFF + 2604);
      e.mem[_t_5 + 1] = _name_3;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2604);
    r1 = _name_3;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET_K92)
  {
    WL_POPN(2);
    Term _root_3 = STK(0);
    Term _digest_2 = STK(1);
    Term _h_2 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _digest_2;
      STK(1) = FID_CLI_ASSET_K93;
      WL_PUSHN(2);
    } else {
      u64 _t_6 = task_node(e, FID_CLI_ASSET_K93, WL_CONT, WL_IDX, 1);
      e.mem[_t_6 + 0] = _digest_2;
      WL_CONT = term_tsk(FID_CLI_ASSET_K93, _t_6);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_7 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _root_3;
      e.mem[_t_7 + 1] = _h_2;
      return term_tsk(FID_STRING_APPEND, _t_7);
    }
    r0 = _root_3;
    r1 = _h_2;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_ASSET_K93)
  {
    WL_POPN(1);
    Term _digest_3 = STK(0);
    Term _h_3 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLI_READ)) {
      u64 _t_8 = task_node(e, FID_CLI_READ, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_3;
      e.mem[_t_8 + 1] = _digest_3;
      return term_tsk(FID_CLI_READ, _t_8);
    }
    r0 = _h_3;
    r1 = _digest_3;
    WL_JMP(FID_CLI_READ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS)
  {
    Term _args_0 = r0;
    Term _input_0 = r1;
    Term _output_0 = r2;
    u32 _live_0 = r3;
    u32 _positional_0 = r4;
    WL_OPEN
    if (term_aux(_args_0) == CID_NIL) {
      u32 _v_0 = 0;
      Term _o_0[1];
      if (spin_4(e, _o_0, _input_0) == 0) {
        return 0;
      }
      _v_0 = (u32)_o_0[0];
      u32 _v_1 = 0;
      Term _o_1[1];
      if (spin_4(e, _o_1, _output_0) == 0) {
        return 0;
      }
      _v_1 = (u32)_o_1[0];
      u64 _nd_0 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_0 + 0] = _input_0;
      e.mem[_nd_0 + 1] = _output_0;
      e.mem[_nd_0 + 2] = _live_0;
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_CLI_OPTIONS_K100;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_CLI_OPTIONS_K100, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_CLI_OPTIONS_K100, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_KC)) {
        u64 _t_1 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = ((_v_0) | (_v_1));
        e.mem[_t_1 + 1] = term_clo(FID_CLI_OPTIONS_C98, 0);
        e.mem[_t_1 + 2] = term_clo(FID_CLI_OPTIONS_C99, _nd_0);
        return term_tsk(FID_KC, _t_1);
      }
      r0 = ((_v_0) | (_v_1));
      r1 = term_clo(FID_CLI_OPTIONS_C98, 0);
      r2 = term_clo(FID_CLI_OPTIONS_C99, _nd_0);
      WL_JMP(FID_KC);
    } else {
      Term _fb_1[2];
      u64 _sp_2 = ctr_take(e, _args_0, 2, _fb_1);
      Term _f_4 = _fb_1[0];
      Term _f_5 = _fb_1[1];
      _f_4 = term_keep(e, _f_4, 1);
      spare_free(e, cls_fit(2), _sp_2);
      if (seq) {
        WL_ROOM(7);
        STK(0) = _f_4;
        STK(1) = _f_5;
        STK(2) = _input_0;
        STK(3) = _output_0;
        STK(4) = _live_0;
        STK(5) = _positional_0;
        STK(6) = FID_CLI_OPTIONS_K101;
        WL_PUSHN(7);
      } else {
        u64 _t_2 = task_node(e, FID_CLI_OPTIONS_K101, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _f_4;
        e.mem[_t_2 + 1] = _f_5;
        e.mem[_t_2 + 2] = _input_0;
        e.mem[_t_2 + 3] = _output_0;
        e.mem[_t_2 + 4] = _live_0;
        e.mem[_t_2 + 5] = _positional_0;
        WL_CONT = term_tsk(FID_CLI_OPTIONS_K101, _t_2);
        WL_IDX = 6;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
        u64 _t_3 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = _f_4;
        e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 2683);
        return term_tsk(FID_STRING_EQ, _t_3);
      }
      r0 = _f_4;
      r1 = term_ctr(CID_SCON, STAT_OFF + 2683);
      WL_JMP(FID_STRING_EQ);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C98)
  {
    Term _x_0 = r0;
    WL_OPEN
    r0 = term_ctr(CID_CLIERROR, STAT_OFF + 2680);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C99)
  {
    Term _input_1 = r0;
    Term _output_1 = r1;
    u32 _live_1 = r2;
    Term _x_1 = r3;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_1 + 0] = _input_1;
    e.mem[_nd_1 + 1] = _output_1;
    e.mem[_nd_1 + 2] = _live_1;
    r0 = term_ctr(CID_CLIREQUEST, _nd_1);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K100)
  {
    Term _r_0 = r0;
    WL_OPEN
    u32 _o_2 = 0;
    Term _o_3 = 0;
    Term _o_4 = 0;
    u32 _o_5 = 0;
    if (term_aux(_r_0) == CID_CLIERROR) {
      _o_2 = 0;
      Term _fb_0[1];
      u64 _sp_0 = ctr_take(e, _r_0, 1, _fb_0);
      Term _f_0 = _fb_0[0];
      spare_free(e, cls_fit(1), _sp_0);
      _o_3 = _f_0;
    } else if (term_aux(_r_0) == CID_CLIHELP) {
      _o_2 = 1;
    } else if (term_aux(_r_0) == CID_CLIVERSION) {
      _o_2 = 2;
    } else {
      _o_2 = 3;
      u64 _sp_1 = term_loc(_r_0);
      Term _f_1 = e.mem[_sp_1 + 0];
      Term _f_2 = e.mem[_sp_1 + 1];
      u32 _f_3 = e.mem[_sp_1 + 2];
      heap_free(e, cls_fit(3), _sp_1);
      _o_3 = _f_1;
      _o_4 = _f_2;
      _o_5 = _f_3;
    }
    r0 = _o_2;
    r1 = _o_3;
    r2 = _o_4;
    r3 = _o_5;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K101)
  {
    WL_POPN(6);
    Term _f_6 = STK(0);
    Term _f_7 = STK(1);
    Term _input_2 = STK(2);
    Term _output_2 = STK(3);
    u32 _live_2 = STK(4);
    u32 _positional_1 = STK(5);
    u32 _h_0 = r0;
    WL_OPEN
    _f_6 = term_keep(e, _f_6, 1);
    if (seq) {
      WL_ROOM(8);
      STK(0) = _f_6;
      STK(1) = _f_7;
      STK(2) = _input_2;
      STK(3) = _output_2;
      STK(4) = _live_2;
      STK(5) = _positional_1;
      STK(6) = _h_0;
      STK(7) = FID_CLI_OPTIONS_K102;
      WL_PUSHN(8);
    } else {
      u64 _t_4 = task_node(e, FID_CLI_OPTIONS_K102, WL_CONT, WL_IDX, 1);
      e.mem[_t_4 + 0] = _f_6;
      e.mem[_t_4 + 1] = _f_7;
      e.mem[_t_4 + 2] = _input_2;
      e.mem[_t_4 + 3] = _output_2;
      e.mem[_t_4 + 4] = _live_2;
      e.mem[_t_4 + 5] = _positional_1;
      e.mem[_t_4 + 6] = _h_0;
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K102, _t_4);
      WL_IDX = 7;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_5 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _f_6;
      e.mem[_t_5 + 1] = term_ctr(CID_SCON, STAT_OFF + 2699);
      return term_tsk(FID_STRING_EQ, _t_5);
    }
    r0 = _f_6;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2699);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K102)
  {
    WL_POPN(7);
    Term _f_8 = STK(0);
    Term _f_9 = STK(1);
    Term _input_3 = STK(2);
    Term _output_3 = STK(3);
    u32 _live_3 = STK(4);
    u32 _positional_2 = STK(5);
    u32 _h_2 = STK(6);
    u32 _h_1 = r0;
    WL_OPEN
    u32 _v_2 = 0;
    u32 _v_3 = 0;
    Term _o_6[1];
    if (spin_5(e, _o_6, _positional_2) == 0) {
      return 0;
    }
    _v_3 = (u32)_o_6[0];
    Term _o_7[1];
    if (spin_7(e, _o_7, _v_3, ((_h_2) | (_h_1))) == 0) {
      return 0;
    }
    _v_2 = (u32)_o_7[0];
    _f_9 = term_keep(e, _f_9, 1);
    _input_3 = term_keep(e, _input_3, 1);
    _output_3 = term_keep(e, _output_3, 1);
    u64 _nd_2 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_2 + 0] = _f_9;
    e.mem[_nd_2 + 1] = _input_3;
    e.mem[_nd_2 + 2] = _output_3;
    e.mem[_nd_2 + 3] = _live_3;
    u64 _nd_7 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_7 + 0] = _f_8;
    e.mem[_nd_7 + 1] = _f_9;
    e.mem[_nd_7 + 2] = _input_3;
    e.mem[_nd_7 + 3] = _output_3;
    e.mem[_nd_7 + 4] = _live_3;
    e.mem[_nd_7 + 5] = _positional_2;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_OPTIONS_K127;
      WL_PUSHN(1);
    } else {
      u64 _t_29 = task_node(e, FID_CLI_OPTIONS_K127, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K127, _t_29);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_30 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_30 + 0] = _v_2;
      e.mem[_t_30 + 1] = term_clo(FID_CLI_OPTIONS_C103, _nd_2);
      e.mem[_t_30 + 2] = term_clo(FID_CLI_OPTIONS_C109, _nd_7);
      return term_tsk(FID_KC, _t_30);
    }
    r0 = _v_2;
    r1 = term_clo(FID_CLI_OPTIONS_C103, _nd_2);
    r2 = term_clo(FID_CLI_OPTIONS_C109, _nd_7);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C103)
  {
    Term _f_10 = r0;
    Term _input_4 = r1;
    Term _output_4 = r2;
    u32 _live_4 = r3;
    Term _x_2 = r4;
    WL_OPEN
    if (term_aux(_f_10) == CID_CON) {
      Term _fb_2[2];
      u64 _sp_3 = ctr_take(e, _f_10, 2, _fb_2);
      Term _f_11 = _fb_2[0];
      Term _f_12 = _fb_2[1];
      u32 _v_4 = 0;
      u32 _v_5 = 0;
      Term _o_8[1];
      if (spin_4(e, _o_8, _output_4) == 0) {
        return 0;
      }
      term_sink(e, _output_4);
      _v_5 = (u32)_o_8[0];
      Term _o_9[1];
      if (spin_5(e, _o_9, _v_5) == 0) {
        return 0;
      }
      _v_4 = (u32)_o_9[0];
      u64 _nd_3 = heap_alloc(e, cls_fit(4));
      e.mem[_nd_3 + 0] = _f_11;
      e.mem[_nd_3 + 1] = _f_12;
      e.mem[_nd_3 + 2] = _input_4;
      e.mem[_nd_3 + 3] = _live_4;
      spare_free(e, cls_fit(2), _sp_3);
      if (!DEVICE && !seq && fid_nofk(FID_KC)) {
        u64 _t_9 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
        e.mem[_t_9 + 0] = _v_4;
        e.mem[_t_9 + 1] = term_clo(FID_CLI_OPTIONS_C104, 0);
        e.mem[_t_9 + 2] = term_clo(FID_CLI_OPTIONS_C105, _nd_3);
        return term_tsk(FID_KC, _t_9);
      }
      r0 = _v_4;
      r1 = term_clo(FID_CLI_OPTIONS_C104, 0);
      r2 = term_clo(FID_CLI_OPTIONS_C105, _nd_3);
      WL_JMP(FID_KC);
    } else {
      term_sink(e, _input_4);
      term_sink(e, _output_4);
      r0 = term_ctr(CID_CLIERROR, STAT_OFF + 2701);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C104)
  {
    Term _x_3 = r0;
    WL_OPEN
    r0 = term_ctr(CID_CLIERROR, STAT_OFF + 2496);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C105)
  {
    Term _f_13 = r0;
    Term _f_14 = r1;
    Term _input_5 = r2;
    u32 _live_5 = r3;
    Term _x_4 = r4;
    WL_OPEN
    u32 _v_6 = 0;
    Term _o_10[1];
    if (spin_4(e, _o_10, _f_13) == 0) {
      return 0;
    }
    _v_6 = (u32)_o_10[0];
    u64 _nd_4 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_4 + 0] = _f_13;
    e.mem[_nd_4 + 1] = _f_14;
    e.mem[_nd_4 + 2] = _input_5;
    e.mem[_nd_4 + 3] = _live_5;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_8 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _v_6;
      e.mem[_t_8 + 1] = term_clo(FID_CLI_OPTIONS_C106, 0);
      e.mem[_t_8 + 2] = term_clo(FID_CLI_OPTIONS_C107, _nd_4);
      return term_tsk(FID_KC, _t_8);
    }
    r0 = _v_6;
    r1 = term_clo(FID_CLI_OPTIONS_C106, 0);
    r2 = term_clo(FID_CLI_OPTIONS_C107, _nd_4);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C106)
  {
    Term _x_5 = r0;
    WL_OPEN
    r0 = term_ctr(CID_CLIERROR, STAT_OFF + 2531);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C107)
  {
    Term _f_15 = r0;
    Term _f_16 = r1;
    Term _input_6 = r2;
    u32 _live_6 = r3;
    Term _x_6 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_OPTIONS_K108;
      WL_PUSHN(1);
    } else {
      u64 _t_6 = task_node(e, FID_CLI_OPTIONS_K108, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K108, _t_6);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_OPTIONS)) {
      u64 _t_7 = task_node(e, FID_CLI_OPTIONS, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = _f_16;
      e.mem[_t_7 + 1] = _input_6;
      e.mem[_t_7 + 2] = _f_15;
      e.mem[_t_7 + 3] = _live_6;
      e.mem[_t_7 + 4] = 0;
      return term_tsk(FID_CLI_OPTIONS, _t_7);
    }
    r0 = _f_16;
    r1 = _input_6;
    r2 = _f_15;
    r3 = _live_6;
    r4 = 0;
    WL_JMP(FID_CLI_OPTIONS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K108)
  {
    u32 _r_1 = r0;
    Term _r_2 = r1;
    Term _r_3 = r2;
    u32 _r_4 = r3;
    WL_OPEN
    Term _b_1 = 0;
    if (_r_1 == 0) {
      u64 _nd_5 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_5 + 0] = _r_2;
      _b_1 = term_ctr(CID_CLIERROR, _nd_5);
    } else if (_r_1 == 1) {
      _b_1 = term_pak(CID_CLIHELP, 0);
    } else if (_r_1 == 2) {
      _b_1 = term_pak(CID_CLIVERSION, 0);
    } else {
      u64 _nd_6 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_6 + 0] = _r_2;
      e.mem[_nd_6 + 1] = _r_3;
      e.mem[_nd_6 + 2] = _r_4;
      _b_1 = term_ctr(CID_CLIREQUEST, _nd_6);
    }
    r0 = _b_1;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C109)
  {
    Term _f_17 = r0;
    Term _f_18 = r1;
    Term _input_7 = r2;
    Term _output_5 = r3;
    u32 _live_7 = r4;
    u32 _positional_3 = r5;
    Term _x_7 = r6;
    WL_OPEN
    _f_17 = term_keep(e, _f_17, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _f_17;
      STK(1) = _f_18;
      STK(2) = _input_7;
      STK(3) = _output_5;
      STK(4) = _live_7;
      STK(5) = _positional_3;
      STK(6) = FID_CLI_OPTIONS_K110;
      WL_PUSHN(7);
    } else {
      u64 _t_10 = task_node(e, FID_CLI_OPTIONS_K110, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _f_17;
      e.mem[_t_10 + 1] = _f_18;
      e.mem[_t_10 + 2] = _input_7;
      e.mem[_t_10 + 3] = _output_5;
      e.mem[_t_10 + 4] = _live_7;
      e.mem[_t_10 + 5] = _positional_3;
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K110, _t_10);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_11 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _f_17;
      e.mem[_t_11 + 1] = term_ctr(CID_SCON, STAT_OFF + 2704);
      return term_tsk(FID_STRING_EQ, _t_11);
    }
    r0 = _f_17;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2704);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K110)
  {
    WL_POPN(6);
    Term _f_19 = STK(0);
    Term _f_20 = STK(1);
    Term _input_8 = STK(2);
    Term _output_6 = STK(3);
    u32 _live_8 = STK(4);
    u32 _positional_4 = STK(5);
    u32 _h_3 = r0;
    WL_OPEN
    u32 _v_7 = 0;
    u32 _v_8 = 0;
    Term _o_11[1];
    if (spin_5(e, _o_11, _positional_4) == 0) {
      return 0;
    }
    _v_8 = (u32)_o_11[0];
    Term _o_12[1];
    if (spin_7(e, _o_12, _v_8, _h_3) == 0) {
      return 0;
    }
    _v_7 = (u32)_o_12[0];
    _f_20 = term_keep(e, _f_20, 1);
    _input_8 = term_keep(e, _input_8, 1);
    _output_6 = term_keep(e, _output_6, 1);
    u64 _nd_8 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_8 + 0] = _f_20;
    e.mem[_nd_8 + 1] = _input_8;
    e.mem[_nd_8 + 2] = _output_6;
    e.mem[_nd_8 + 3] = _live_8;
    u64 _nd_11 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_11 + 0] = _f_19;
    e.mem[_nd_11 + 1] = _f_20;
    e.mem[_nd_11 + 2] = _input_8;
    e.mem[_nd_11 + 3] = _output_6;
    e.mem[_nd_11 + 4] = _live_8;
    e.mem[_nd_11 + 5] = _positional_4;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_28 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_28 + 0] = _v_7;
      e.mem[_t_28 + 1] = term_clo(FID_CLI_OPTIONS_C111, _nd_8);
      e.mem[_t_28 + 2] = term_clo(FID_CLI_OPTIONS_C113, _nd_11);
      return term_tsk(FID_KC, _t_28);
    }
    r0 = _v_7;
    r1 = term_clo(FID_CLI_OPTIONS_C111, _nd_8);
    r2 = term_clo(FID_CLI_OPTIONS_C113, _nd_11);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C111)
  {
    Term _f_21 = r0;
    Term _input_9 = r1;
    Term _output_7 = r2;
    u32 _live_9 = r3;
    Term _x_8 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_OPTIONS_K112;
      WL_PUSHN(1);
    } else {
      u64 _t_12 = task_node(e, FID_CLI_OPTIONS_K112, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K112, _t_12);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_OPTIONS)) {
      u64 _t_13 = task_node(e, FID_CLI_OPTIONS, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _f_21;
      e.mem[_t_13 + 1] = _input_9;
      e.mem[_t_13 + 2] = _output_7;
      e.mem[_t_13 + 3] = _live_9;
      e.mem[_t_13 + 4] = 1;
      return term_tsk(FID_CLI_OPTIONS, _t_13);
    }
    r0 = _f_21;
    r1 = _input_9;
    r2 = _output_7;
    r3 = _live_9;
    r4 = 1;
    WL_JMP(FID_CLI_OPTIONS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K112)
  {
    u32 _r_5 = r0;
    Term _r_6 = r1;
    Term _r_7 = r2;
    u32 _r_8 = r3;
    WL_OPEN
    Term _b_2 = 0;
    if (_r_5 == 0) {
      u64 _nd_9 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_9 + 0] = _r_6;
      _b_2 = term_ctr(CID_CLIERROR, _nd_9);
    } else if (_r_5 == 1) {
      _b_2 = term_pak(CID_CLIHELP, 0);
    } else if (_r_5 == 2) {
      _b_2 = term_pak(CID_CLIVERSION, 0);
    } else {
      u64 _nd_10 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_10 + 0] = _r_6;
      e.mem[_nd_10 + 1] = _r_7;
      e.mem[_nd_10 + 2] = _r_8;
      _b_2 = term_ctr(CID_CLIREQUEST, _nd_10);
    }
    r0 = _b_2;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C113)
  {
    Term _f_22 = r0;
    Term _f_23 = r1;
    Term _input_10 = r2;
    Term _output_8 = r3;
    u32 _live_10 = r4;
    u32 _positional_5 = r5;
    Term _x_9 = r6;
    WL_OPEN
    _f_22 = term_keep(e, _f_22, 1);
    if (seq) {
      WL_ROOM(7);
      STK(0) = _f_22;
      STK(1) = _f_23;
      STK(2) = _input_10;
      STK(3) = _output_8;
      STK(4) = _live_10;
      STK(5) = _positional_5;
      STK(6) = FID_CLI_OPTIONS_K114;
      WL_PUSHN(7);
    } else {
      u64 _t_14 = task_node(e, FID_CLI_OPTIONS_K114, WL_CONT, WL_IDX, 1);
      e.mem[_t_14 + 0] = _f_22;
      e.mem[_t_14 + 1] = _f_23;
      e.mem[_t_14 + 2] = _input_10;
      e.mem[_t_14 + 3] = _output_8;
      e.mem[_t_14 + 4] = _live_10;
      e.mem[_t_14 + 5] = _positional_5;
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K114, _t_14);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_15 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _f_22;
      e.mem[_t_15 + 1] = term_ctr(CID_SCON, STAT_OFF + 2716);
      return term_tsk(FID_STRING_EQ, _t_15);
    }
    r0 = _f_22;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2716);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K114)
  {
    WL_POPN(6);
    Term _f_24 = STK(0);
    Term _f_25 = STK(1);
    Term _input_11 = STK(2);
    Term _output_9 = STK(3);
    u32 _live_11 = STK(4);
    u32 _positional_6 = STK(5);
    u32 _h_4 = r0;
    WL_OPEN
    u32 _v_9 = 0;
    u32 _v_10 = 0;
    Term _o_13[1];
    if (spin_5(e, _o_13, _positional_6) == 0) {
      return 0;
    }
    _v_10 = (u32)_o_13[0];
    Term _o_14[1];
    if (spin_7(e, _o_14, _v_10, _h_4) == 0) {
      return 0;
    }
    _v_9 = (u32)_o_14[0];
    _f_25 = term_keep(e, _f_25, 1);
    _input_11 = term_keep(e, _input_11, 1);
    _output_9 = term_keep(e, _output_9, 1);
    u64 _nd_12 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_12 + 0] = _f_25;
    e.mem[_nd_12 + 1] = _input_11;
    e.mem[_nd_12 + 2] = _output_9;
    e.mem[_nd_12 + 3] = _live_11;
    e.mem[_nd_12 + 4] = _positional_6;
    u64 _nd_16 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_16 + 0] = _f_24;
    e.mem[_nd_16 + 1] = _f_25;
    e.mem[_nd_16 + 2] = _input_11;
    e.mem[_nd_16 + 3] = _output_9;
    e.mem[_nd_16 + 4] = _live_11;
    e.mem[_nd_16 + 5] = _positional_6;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_27 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_27 + 0] = _v_9;
      e.mem[_t_27 + 1] = term_clo(FID_CLI_OPTIONS_C115, _nd_12);
      e.mem[_t_27 + 2] = term_clo(FID_CLI_OPTIONS_C119, _nd_16);
      return term_tsk(FID_KC, _t_27);
    }
    r0 = _v_9;
    r1 = term_clo(FID_CLI_OPTIONS_C115, _nd_12);
    r2 = term_clo(FID_CLI_OPTIONS_C119, _nd_16);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C115)
  {
    Term _f_26 = r0;
    Term _input_12 = r1;
    Term _output_10 = r2;
    u32 _live_12 = r3;
    u32 _positional_7 = r4;
    Term _x_10 = r5;
    WL_OPEN
    u64 _nd_13 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_13 + 0] = _f_26;
    e.mem[_nd_13 + 1] = _input_12;
    e.mem[_nd_13 + 2] = _output_10;
    e.mem[_nd_13 + 3] = _positional_7;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_18 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _live_12;
      e.mem[_t_18 + 1] = term_clo(FID_CLI_OPTIONS_C116, 0);
      e.mem[_t_18 + 2] = term_clo(FID_CLI_OPTIONS_C117, _nd_13);
      return term_tsk(FID_KC, _t_18);
    }
    r0 = _live_12;
    r1 = term_clo(FID_CLI_OPTIONS_C116, 0);
    r2 = term_clo(FID_CLI_OPTIONS_C117, _nd_13);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C116)
  {
    Term _x_11 = r0;
    WL_OPEN
    r0 = term_ctr(CID_CLIERROR, STAT_OFF + 2738);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C117)
  {
    Term _f_27 = r0;
    Term _input_13 = r1;
    Term _output_11 = r2;
    u32 _positional_8 = r3;
    Term _x_12 = r4;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_OPTIONS_K118;
      WL_PUSHN(1);
    } else {
      u64 _t_16 = task_node(e, FID_CLI_OPTIONS_K118, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K118, _t_16);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_OPTIONS)) {
      u64 _t_17 = task_node(e, FID_CLI_OPTIONS, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _f_27;
      e.mem[_t_17 + 1] = _input_13;
      e.mem[_t_17 + 2] = _output_11;
      e.mem[_t_17 + 3] = 1;
      e.mem[_t_17 + 4] = _positional_8;
      return term_tsk(FID_CLI_OPTIONS, _t_17);
    }
    r0 = _f_27;
    r1 = _input_13;
    r2 = _output_11;
    r3 = 1;
    r4 = _positional_8;
    WL_JMP(FID_CLI_OPTIONS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K118)
  {
    u32 _r_9 = r0;
    Term _r_10 = r1;
    Term _r_11 = r2;
    u32 _r_12 = r3;
    WL_OPEN
    Term _b_3 = 0;
    if (_r_9 == 0) {
      u64 _nd_14 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_14 + 0] = _r_10;
      _b_3 = term_ctr(CID_CLIERROR, _nd_14);
    } else if (_r_9 == 1) {
      _b_3 = term_pak(CID_CLIHELP, 0);
    } else if (_r_9 == 2) {
      _b_3 = term_pak(CID_CLIVERSION, 0);
    } else {
      u64 _nd_15 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_15 + 0] = _r_10;
      e.mem[_nd_15 + 1] = _r_11;
      e.mem[_nd_15 + 2] = _r_12;
      _b_3 = term_ctr(CID_CLIREQUEST, _nd_15);
    }
    r0 = _b_3;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C119)
  {
    Term _f_28 = r0;
    Term _f_29 = r1;
    Term _input_14 = r2;
    Term _output_12 = r3;
    u32 _live_13 = r4;
    u32 _positional_9 = r5;
    Term _x_13 = r6;
    WL_OPEN
    if (seq) {
      WL_ROOM(7);
      STK(0) = _f_28;
      STK(1) = _f_29;
      STK(2) = _input_14;
      STK(3) = _output_12;
      STK(4) = _live_13;
      STK(5) = _positional_9;
      STK(6) = FID_CLI_OPTIONS_K120;
      WL_PUSHN(7);
    } else {
      u64 _t_19 = task_node(e, FID_CLI_OPTIONS_K120, WL_CONT, WL_IDX, 1);
      e.mem[_t_19 + 0] = _f_28;
      e.mem[_t_19 + 1] = _f_29;
      e.mem[_t_19 + 2] = _input_14;
      e.mem[_t_19 + 3] = _output_12;
      e.mem[_t_19 + 4] = _live_13;
      e.mem[_t_19 + 5] = _positional_9;
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K120, _t_19);
      WL_IDX = 6;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_STARTS_WITH)) {
      u64 _t_20 = task_node(e, FID_STRING_STARTS_WITH, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = _f_28;
      e.mem[_t_20 + 1] = term_ctr(CID_SCON, STAT_OFF + 2702);
      return term_tsk(FID_STRING_STARTS_WITH, _t_20);
    }
    r0 = _f_28;
    r1 = term_ctr(CID_SCON, STAT_OFF + 2702);
    WL_JMP(FID_STRING_STARTS_WITH);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K120)
  {
    WL_POPN(6);
    Term _f_30 = STK(0);
    Term _f_31 = STK(1);
    Term _input_15 = STK(2);
    Term _output_13 = STK(3);
    u32 _live_14 = STK(4);
    u32 _positional_10 = STK(5);
    u32 _h_5 = r0;
    WL_OPEN
    u32 _v_11 = 0;
    u32 _v_12 = 0;
    Term _o_15[1];
    if (spin_5(e, _o_15, _positional_10) == 0) {
      return 0;
    }
    _v_12 = (u32)_o_15[0];
    Term _o_16[1];
    if (spin_7(e, _o_16, _v_12, _h_5) == 0) {
      return 0;
    }
    _v_11 = (u32)_o_16[0];
    _f_30 = term_keep(e, _f_30, 1);
    u64 _nd_17 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_17 + 0] = _f_30;
    u64 _nd_19 = heap_alloc(e, cls_fit(6));
    e.mem[_nd_19 + 0] = _f_30;
    e.mem[_nd_19 + 1] = _f_31;
    e.mem[_nd_19 + 2] = _input_15;
    e.mem[_nd_19 + 3] = _output_13;
    e.mem[_nd_19 + 4] = _live_14;
    e.mem[_nd_19 + 5] = _positional_10;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_26 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_26 + 0] = _v_11;
      e.mem[_t_26 + 1] = term_clo(FID_CLI_OPTIONS_C121, _nd_17);
      e.mem[_t_26 + 2] = term_clo(FID_CLI_OPTIONS_C123, _nd_19);
      return term_tsk(FID_KC, _t_26);
    }
    r0 = _v_11;
    r1 = term_clo(FID_CLI_OPTIONS_C121, _nd_17);
    r2 = term_clo(FID_CLI_OPTIONS_C123, _nd_19);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C121)
  {
    Term _f_32 = r0;
    Term _x_14 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_OPTIONS_K122;
      WL_PUSHN(1);
    } else {
      u64 _t_21 = task_node(e, FID_CLI_OPTIONS_K122, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K122, _t_21);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_22 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = term_ctr(CID_SCON, STAT_OFF + 2765);
      e.mem[_t_22 + 1] = _f_32;
      return term_tsk(FID_STRING_APPEND, _t_22);
    }
    r0 = term_ctr(CID_SCON, STAT_OFF + 2765);
    r1 = _f_32;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K122)
  {
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_18 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_18 + 0] = _h_6;
    r0 = term_ctr(CID_CLIERROR, _nd_18);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C123)
  {
    Term _f_33 = r0;
    Term _f_34 = r1;
    Term _input_16 = r2;
    Term _output_14 = r3;
    u32 _live_15 = r4;
    u32 _positional_11 = r5;
    Term _x_15 = r6;
    WL_OPEN
    u32 _v_13 = 0;
    u32 _v_14 = 0;
    Term _o_17[1];
    if (spin_4(e, _o_17, _input_16) == 0) {
      return 0;
    }
    term_sink(e, _input_16);
    _v_14 = (u32)_o_17[0];
    u32 _v_15 = 0;
    u32 _v_16 = 0;
    Term _o_18[1];
    if (spin_4(e, _o_18, _f_33) == 0) {
      return 0;
    }
    _v_16 = (u32)_o_18[0];
    Term _o_19[1];
    if (spin_5(e, _o_19, _v_16) == 0) {
      return 0;
    }
    _v_15 = (u32)_o_19[0];
    Term _o_20[1];
    if (spin_7(e, _o_20, _v_14, _v_15) == 0) {
      return 0;
    }
    _v_13 = (u32)_o_20[0];
    u64 _nd_20 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_20 + 0] = _f_33;
    e.mem[_nd_20 + 1] = _f_34;
    e.mem[_nd_20 + 2] = _output_14;
    e.mem[_nd_20 + 3] = _live_15;
    e.mem[_nd_20 + 4] = _positional_11;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_25 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_25 + 0] = _v_13;
      e.mem[_t_25 + 1] = term_clo(FID_CLI_OPTIONS_C124, _nd_20);
      e.mem[_t_25 + 2] = term_clo(FID_CLI_OPTIONS_C126, 0);
      return term_tsk(FID_KC, _t_25);
    }
    r0 = _v_13;
    r1 = term_clo(FID_CLI_OPTIONS_C124, _nd_20);
    r2 = term_clo(FID_CLI_OPTIONS_C126, 0);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C124)
  {
    Term _f_35 = r0;
    Term _f_36 = r1;
    Term _output_15 = r2;
    u32 _live_16 = r3;
    u32 _positional_12 = r4;
    Term _x_16 = r5;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_OPTIONS_K125;
      WL_PUSHN(1);
    } else {
      u64 _t_23 = task_node(e, FID_CLI_OPTIONS_K125, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_OPTIONS_K125, _t_23);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_OPTIONS)) {
      u64 _t_24 = task_node(e, FID_CLI_OPTIONS, WL_CONT, WL_IDX, 0);
      e.mem[_t_24 + 0] = _f_36;
      e.mem[_t_24 + 1] = _f_35;
      e.mem[_t_24 + 2] = _output_15;
      e.mem[_t_24 + 3] = _live_16;
      e.mem[_t_24 + 4] = _positional_12;
      return term_tsk(FID_CLI_OPTIONS, _t_24);
    }
    r0 = _f_36;
    r1 = _f_35;
    r2 = _output_15;
    r3 = _live_16;
    r4 = _positional_12;
    WL_JMP(FID_CLI_OPTIONS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K125)
  {
    u32 _r_13 = r0;
    Term _r_14 = r1;
    Term _r_15 = r2;
    u32 _r_16 = r3;
    WL_OPEN
    Term _b_4 = 0;
    if (_r_13 == 0) {
      u64 _nd_21 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_21 + 0] = _r_14;
      _b_4 = term_ctr(CID_CLIERROR, _nd_21);
    } else if (_r_13 == 1) {
      _b_4 = term_pak(CID_CLIHELP, 0);
    } else if (_r_13 == 2) {
      _b_4 = term_pak(CID_CLIVERSION, 0);
    } else {
      u64 _nd_22 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_22 + 0] = _r_14;
      e.mem[_nd_22 + 1] = _r_15;
      e.mem[_nd_22 + 2] = _r_16;
      _b_4 = term_ctr(CID_CLIREQUEST, _nd_22);
    }
    r0 = _b_4;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_C126)
  {
    Term _x_17 = r0;
    WL_OPEN
    r0 = term_ctr(CID_CLIERROR, STAT_OFF + 2831);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_OPTIONS_K127)
  {
    Term _r_17 = r0;
    WL_OPEN
    u32 _o_21 = 0;
    Term _o_22 = 0;
    Term _o_23 = 0;
    u32 _o_24 = 0;
    if (term_aux(_r_17) == CID_CLIERROR) {
      _o_21 = 0;
      Term _fb_3[1];
      u64 _sp_4 = ctr_take(e, _r_17, 1, _fb_3);
      Term _f_37 = _fb_3[0];
      spare_free(e, cls_fit(1), _sp_4);
      _o_22 = _f_37;
    } else if (term_aux(_r_17) == CID_CLIHELP) {
      _o_21 = 1;
    } else if (term_aux(_r_17) == CID_CLIVERSION) {
      _o_21 = 2;
    } else {
      _o_21 = 3;
      u64 _sp_5 = term_loc(_r_17);
      Term _f_38 = e.mem[_sp_5 + 0];
      Term _f_39 = e.mem[_sp_5 + 1];
      u32 _f_40 = e.mem[_sp_5 + 2];
      heap_free(e, cls_fit(3), _sp_5);
      _o_22 = _f_38;
      _o_23 = _f_39;
      _o_24 = _f_40;
    }
    r0 = _o_21;
    r1 = _o_22;
    r2 = _o_23;
    r3 = _o_24;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_STRING_EQ_K129;
      WL_PUSHN(1);
    } else {
      u64 _t_0 = task_node(e, FID_STRING_EQ_K129, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_STRING_EQ_K129, _t_0);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_ORDER)) {
      u64 _t_1 = task_node(e, FID_STRING_ORDER, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _a_0;
      e.mem[_t_1 + 1] = _b_0;
      return term_tsk(FID_STRING_ORDER, _t_1);
    }
    r0 = _a_0;
    r1 = _b_0;
    WL_JMP(FID_STRING_ORDER);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_EQ_K129)
  {
    u32 _h_0 = r0;
    WL_OPEN
    Term _o_0[1];
    if (spin_8(e, _o_0, _h_0) == 0) {
      return 0;
    }
    r0 = (u32)_o_0[0];
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_KC)
  {
    u32 _b_0 = r0;
    Term _yes_0 = r1;
    Term _no_0 = r2;
    WL_OPEN
    if (_b_0 == 1) {
      term_sink(e, _no_0);
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_0 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_0 + 0] = _yes_0;
        e.mem[_t_0 + 1] = term_pak(CID_UNIT, 0);
        return term_tsk(FID_CLO_APPLY, _t_0);
      }
      r0 = _yes_0;
      r1 = term_pak(CID_UNIT, 0);
      WL_JMP(FID_CLO_APPLY);
    } else {
      term_sink(e, _yes_0);
      if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
        u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _no_0;
        e.mem[_t_1 + 1] = term_pak(CID_UNIT, 0);
        return term_tsk(FID_CLO_APPLY, _t_1);
      }
      r0 = _no_0;
      r1 = term_pak(CID_UNIT, 0);
      WL_JMP(FID_CLO_APPLY);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PASS_C135)
  {
    Term _result_3 = r0;
    Term _x_3 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_0 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _result_3;
      e.mem[_t_0 + 1] = _x_3;
      return term_tsk(FID_IO_PURE, _t_0);
    }
    r0 = _result_3;
    r1 = _x_3;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PASS_C136)
  {
    Term _result_4 = r0;
    Term _x_4 = r1;
    WL_OPEN
    Term _o_6[1];
    if (spin_2(e, _o_6, 1ull, _result_4, _x_4) == 0) {
      return 0;
    }
    r0 = _o_6[0];
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PASS_C151)
  {
    Term _result_8 = r0;
    Term _x_18 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_5 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _result_8;
      e.mem[_t_5 + 1] = _x_18;
      return term_tsk(FID_IO_PURE, _t_5);
    }
    r0 = _result_8;
    r1 = _x_18;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PASS_C152)
  {
    Term _result_9 = r0;
    Term _x_19 = r1;
    WL_OPEN
    Term _o_24[1];
    if (spin_11(e, _o_24, 1ull, _result_9, _x_19) == 0) {
      return 0;
    }
    r0 = _o_24[0];
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PURE)
  {
    Term _x_0 = r0;
    Term _k_0 = r1;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_0 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_0 + 0] = _k_0;
      e.mem[_t_0 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_0);
    }
    r0 = _k_0;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND)
  {
    Term _a_0 = r0;
    Term _b_0 = r1;
    WL_OPEN
    WL_SPIN
    if (term_aux(_a_0) == CID_SNIL) {
      r0 = _b_0;
      WL_RETN(1);
    } else {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _a_0, 2, _fb_0);
      u32 _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(2);
        STK(0) = _f_0;
        STK(1) = FID_STRING_APPEND_K157;
        WL_PUSHN(2);
      } else {
        u64 _t_0 = task_node(e, FID_STRING_APPEND_K157, WL_CONT, WL_IDX, 1);
        e.mem[_t_0 + 0] = _f_0;
        WL_CONT = term_tsk(FID_STRING_APPEND_K157, _t_0);
        WL_IDX = 1;
      }
      r0 = _f_1;
      r1 = _b_0;
      _a_0 = r0;
      _b_0 = r1;
      WL_AGAIN(FID_STRING_APPEND);
    }
    WL_SPUN
  }}
#endif

#if !DEVICE
  WL_CASE(FID_STRING_APPEND_K157)
  {
    WL_POPN(1);
    u32 _f_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = rfc_seal(e, _f_2);
    e.mem[_nd_0 + 1] = rfc_seal(e, _h_0);
    r0 = term_ctr(CID_SCON, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE)
  {
    Term _args_0 = r0;
    WL_OPEN
    if (term_aux(_args_0) == CID_CON) {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _args_0, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      if (term_aux(_f_1) == CID_NIL) {
        _f_0 = term_keep(e, _f_0, 1);
        spare_free(e, cls_fit(2), _sp_0);
        if (seq) {
          WL_ROOM(2);
          STK(0) = _f_0;
          STK(1) = FID_CLI_PARSE_K161;
          WL_PUSHN(2);
        } else {
          u64 _t_0 = task_node(e, FID_CLI_PARSE_K161, WL_CONT, WL_IDX, 1);
          e.mem[_t_0 + 0] = _f_0;
          WL_CONT = term_tsk(FID_CLI_PARSE_K161, _t_0);
          WL_IDX = 1;
        }
        if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
          u64 _t_1 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
          e.mem[_t_1 + 0] = _f_0;
          e.mem[_t_1 + 1] = term_ctr(CID_SCON, STAT_OFF + 3662);
          return term_tsk(FID_STRING_EQ, _t_1);
        }
        r0 = _f_0;
        r1 = term_ctr(CID_SCON, STAT_OFF + 3662);
        WL_JMP(FID_STRING_EQ);
      } else {
        u64 _nd_5 = _sp_0 >= HEAP_OFF ? _sp_0 : heap_alloc(e, cls_fit(2));
        e.mem[_nd_5 + 0] = rfc_seal(e, _f_0);
        e.mem[_nd_5 + 1] = rfc_seal(e, _f_1);
        if (!DEVICE && !seq && fid_nofk(FID_CLI_OPTIONS)) {
          u64 _t_9 = task_node(e, FID_CLI_OPTIONS, WL_CONT, WL_IDX, 0);
          e.mem[_t_9 + 0] = term_ctr(CID_CON, _nd_5);
          e.mem[_t_9 + 1] = term_pak(CID_SNIL, 0);
          e.mem[_t_9 + 2] = term_pak(CID_SNIL, 0);
          e.mem[_t_9 + 3] = 0;
          e.mem[_t_9 + 4] = 0;
          return term_tsk(FID_CLI_OPTIONS, _t_9);
        }
        r0 = term_ctr(CID_CON, _nd_5);
        r1 = term_pak(CID_SNIL, 0);
        r2 = term_pak(CID_SNIL, 0);
        r3 = 0;
        r4 = 0;
        WL_JMP(FID_CLI_OPTIONS);
      }
    } else {
      if (!DEVICE && !seq && fid_nofk(FID_CLI_OPTIONS)) {
        u64 _t_10 = task_node(e, FID_CLI_OPTIONS, WL_CONT, WL_IDX, 0);
        e.mem[_t_10 + 0] = _args_0;
        e.mem[_t_10 + 1] = term_pak(CID_SNIL, 0);
        e.mem[_t_10 + 2] = term_pak(CID_SNIL, 0);
        e.mem[_t_10 + 3] = 0;
        e.mem[_t_10 + 4] = 0;
        return term_tsk(FID_CLI_OPTIONS, _t_10);
      }
      r0 = _args_0;
      r1 = term_pak(CID_SNIL, 0);
      r2 = term_pak(CID_SNIL, 0);
      r3 = 0;
      r4 = 0;
      WL_JMP(FID_CLI_OPTIONS);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_K161)
  {
    WL_POPN(1);
    Term _f_2 = STK(0);
    u32 _h_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _f_2;
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_PARSE_K168;
      WL_PUSHN(1);
    } else {
      u64 _t_7 = task_node(e, FID_CLI_PARSE_K168, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_PARSE_K168, _t_7);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_8 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = _h_0;
      e.mem[_t_8 + 1] = term_clo(FID_CLI_PARSE_C162, 0);
      e.mem[_t_8 + 2] = term_clo(FID_CLI_PARSE_C163, _nd_0);
      return term_tsk(FID_KC, _t_8);
    }
    r0 = _h_0;
    r1 = term_clo(FID_CLI_PARSE_C162, 0);
    r2 = term_clo(FID_CLI_PARSE_C163, _nd_0);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_C162)
  {
    Term _x_0 = r0;
    WL_OPEN
    r0 = term_pak(CID_CLIHELP, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_C163)
  {
    Term _f_3 = r0;
    Term _x_1 = r1;
    WL_OPEN
    _f_3 = term_keep(e, _f_3, 1);
    if (seq) {
      WL_ROOM(2);
      STK(0) = _f_3;
      STK(1) = FID_CLI_PARSE_K164;
      WL_PUSHN(2);
    } else {
      u64 _t_2 = task_node(e, FID_CLI_PARSE_K164, WL_CONT, WL_IDX, 1);
      e.mem[_t_2 + 0] = _f_3;
      WL_CONT = term_tsk(FID_CLI_PARSE_K164, _t_2);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_EQ)) {
      u64 _t_3 = task_node(e, FID_STRING_EQ, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _f_3;
      e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 3674);
      return term_tsk(FID_STRING_EQ, _t_3);
    }
    r0 = _f_3;
    r1 = term_ctr(CID_SCON, STAT_OFF + 3674);
    WL_JMP(FID_STRING_EQ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_K164)
  {
    WL_POPN(1);
    Term _f_4 = STK(0);
    u32 _h_1 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = _f_4;
    if (!DEVICE && !seq && fid_nofk(FID_KC)) {
      u64 _t_6 = task_node(e, FID_KC, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = _h_1;
      e.mem[_t_6 + 1] = term_clo(FID_CLI_PARSE_C165, 0);
      e.mem[_t_6 + 2] = term_clo(FID_CLI_PARSE_C166, _nd_1);
      return term_tsk(FID_KC, _t_6);
    }
    r0 = _h_1;
    r1 = term_clo(FID_CLI_PARSE_C165, 0);
    r2 = term_clo(FID_CLI_PARSE_C166, _nd_1);
    WL_JMP(FID_KC);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_C165)
  {
    Term _x_2 = r0;
    WL_OPEN
    r0 = term_pak(CID_CLIVERSION, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_C166)
  {
    Term _f_5 = r0;
    Term _x_3 = r1;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_2 + 0] = rfc_seal(e, _f_5);
    e.mem[_nd_2 + 1] = rfc_seal(e, term_pak(CID_NIL, 0));
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_CLI_PARSE_K167;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_CLI_PARSE_K167, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_CLI_PARSE_K167, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_OPTIONS)) {
      u64 _t_5 = task_node(e, FID_CLI_OPTIONS, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = term_ctr(CID_CON, _nd_2);
      e.mem[_t_5 + 1] = term_pak(CID_SNIL, 0);
      e.mem[_t_5 + 2] = term_pak(CID_SNIL, 0);
      e.mem[_t_5 + 3] = 0;
      e.mem[_t_5 + 4] = 0;
      return term_tsk(FID_CLI_OPTIONS, _t_5);
    }
    r0 = term_ctr(CID_CON, _nd_2);
    r1 = term_pak(CID_SNIL, 0);
    r2 = term_pak(CID_SNIL, 0);
    r3 = 0;
    r4 = 0;
    WL_JMP(FID_CLI_OPTIONS);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_K167)
  {
    u32 _r_0 = r0;
    Term _r_1 = r1;
    Term _r_2 = r2;
    u32 _r_3 = r3;
    WL_OPEN
    Term _b_0 = 0;
    if (_r_0 == 0) {
      u64 _nd_3 = heap_alloc(e, cls_fit(1));
      e.mem[_nd_3 + 0] = _r_1;
      _b_0 = term_ctr(CID_CLIERROR, _nd_3);
    } else if (_r_0 == 1) {
      _b_0 = term_pak(CID_CLIHELP, 0);
    } else if (_r_0 == 2) {
      _b_0 = term_pak(CID_CLIVERSION, 0);
    } else {
      u64 _nd_4 = heap_alloc(e, cls_fit(3));
      e.mem[_nd_4 + 0] = _r_1;
      e.mem[_nd_4 + 1] = _r_2;
      e.mem[_nd_4 + 2] = _r_3;
      _b_0 = term_ctr(CID_CLIREQUEST, _nd_4);
    }
    r0 = _b_0;
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_CLI_PARSE_K168)
  {
    Term _r_4 = r0;
    WL_OPEN
    u32 _o_0 = 0;
    Term _o_1 = 0;
    Term _o_2 = 0;
    u32 _o_3 = 0;
    if (term_aux(_r_4) == CID_CLIERROR) {
      _o_0 = 0;
      Term _fb_1[1];
      u64 _sp_1 = ctr_take(e, _r_4, 1, _fb_1);
      Term _f_6 = _fb_1[0];
      spare_free(e, cls_fit(1), _sp_1);
      _o_1 = _f_6;
    } else if (term_aux(_r_4) == CID_CLIHELP) {
      _o_0 = 1;
    } else if (term_aux(_r_4) == CID_CLIVERSION) {
      _o_0 = 2;
    } else {
      _o_0 = 3;
      u64 _sp_2 = term_loc(_r_4);
      Term _f_7 = e.mem[_sp_2 + 0];
      Term _f_8 = e.mem[_sp_2 + 1];
      u32 _f_9 = e.mem[_sp_2 + 2];
      heap_free(e, cls_fit(3), _sp_2);
      _o_1 = _f_7;
      _o_2 = _f_8;
      _o_3 = _f_9;
    }
    r0 = _o_0;
    r1 = _o_1;
    r2 = _o_2;
    r3 = _o_3;
    WL_RETN(4);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND)
  {
    Term _m_0 = r0;
    Term _f_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _f_0;
    e.mem[_nd_0 + 1] = _k_0;
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_3 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_3 + 0] = _m_0;
      e.mem[_t_3 + 1] = term_clo(FID_IO_BIND_C230, _nd_0);
      return term_tsk(FID_CLO_APPLY, _t_3);
    }
    r0 = _m_0;
    r1 = term_clo(FID_IO_BIND_C230, _nd_0);
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_C230)
  {
    Term _f_1 = r0;
    Term _k_1 = r1;
    Term _x_0 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _k_1;
      STK(1) = FID_IO_BIND_K231;
      WL_PUSHN(2);
    } else {
      u64 _t_0 = task_node(e, FID_IO_BIND_K231, WL_CONT, WL_IDX, 1);
      e.mem[_t_0 + 0] = _k_1;
      WL_CONT = term_tsk(FID_IO_BIND_K231, _t_0);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_1 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_1 + 0] = _f_1;
      e.mem[_t_1 + 1] = _x_0;
      return term_tsk(FID_CLO_APPLY, _t_1);
    }
    r0 = _f_1;
    r1 = _x_0;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_BIND_K231)
  {
    WL_POPN(1);
    Term _k_2 = STK(0);
    Term _h_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_CLO_APPLY)) {
      u64 _t_2 = task_node(e, FID_CLO_APPLY, WL_CONT, WL_IDX, 0);
      e.mem[_t_2 + 0] = _h_0;
      e.mem[_t_2 + 1] = _k_2;
      return term_tsk(FID_CLO_APPLY, _t_2);
    }
    r0 = _h_0;
    r1 = _k_2;
    WL_JMP(FID_CLO_APPLY);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN)
  {
    WL_OPEN
    r0 = term_clo(FID_MAIN_C233, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C233)
  {
    Term _x_0 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_23 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_23 + 0] = term_clo(FID_IO_ARGS, 0);
      e.mem[_t_23 + 1] = term_clo(FID_MAIN_C234, 0);
      e.mem[_t_23 + 2] = _x_0;
      return term_tsk(FID_IO_BIND, _t_23);
    }
    r0 = term_clo(FID_IO_ARGS, 0);
    r1 = term_clo(FID_MAIN_C234, 0);
    r2 = _x_0;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C234)
  {
    Term _x_1 = r0;
    WL_OPEN
    if (term_aux(_x_1) == CID_CON) {
      Term _fb_0[2];
      u64 _sp_0 = ctr_take(e, _x_1, 2, _fb_0);
      Term _f_0 = _fb_0[0];
      Term _f_1 = _fb_0[1];
      term_sink(e, _f_0);
      spare_free(e, cls_fit(2), _sp_0);
      if (seq) {
        WL_ROOM(1);
        STK(0) = FID_MAIN_K235;
        WL_PUSHN(1);
      } else {
        u64 _t_0 = task_node(e, FID_MAIN_K235, WL_CONT, WL_IDX, 1);
        WL_CONT = term_tsk(FID_MAIN_K235, _t_0);
        WL_IDX = 0;
      }
      if (!DEVICE && !seq && fid_nofk(FID_CLI_PARSE)) {
        u64 _t_1 = task_node(e, FID_CLI_PARSE, WL_CONT, WL_IDX, 0);
        e.mem[_t_1 + 0] = _f_1;
        return term_tsk(FID_CLI_PARSE, _t_1);
      }
      r0 = _f_1;
      WL_JMP(FID_CLI_PARSE);
    } else {
      r0 = term_clo(FID_MAIN_C264, 0);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K235)
  {
    u32 _h_0 = r0;
    Term _h_1 = r1;
    Term _h_2 = r2;
    u32 _h_3 = r3;
    WL_OPEN
    if (_h_0 == 0) {
      if (seq) {
        WL_ROOM(2);
        STK(0) = _h_1;
        STK(1) = FID_MAIN_K236;
        WL_PUSHN(2);
      } else {
        u64 _t_2 = task_node(e, FID_MAIN_K236, WL_CONT, WL_IDX, 1);
        e.mem[_t_2 + 0] = _h_1;
        WL_CONT = term_tsk(FID_MAIN_K236, _t_2);
        WL_IDX = 1;
      }
      if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
        u64 _t_3 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
        e.mem[_t_3 + 0] = term_ctr(CID_SCON, STAT_OFF + 3676);
        e.mem[_t_3 + 1] = term_ctr(CID_SCON, STAT_OFF + 3650);
        return term_tsk(FID_STRING_APPEND, _t_3);
      }
      r0 = term_ctr(CID_SCON, STAT_OFF + 3676);
      r1 = term_ctr(CID_SCON, STAT_OFF + 3650);
      WL_JMP(FID_STRING_APPEND);
    } else if (_h_0 == 1) {
      r0 = term_clo(FID_MAIN_C239, 0);
      WL_RETN(1);
    } else if (_h_0 == 2) {
      r0 = term_clo(FID_MAIN_C242, 0);
      WL_RETN(1);
    } else {
      u64 _nd_3 = heap_alloc(e, cls_fit(2));
      e.mem[_nd_3 + 0] = _h_1;
      e.mem[_nd_3 + 1] = _h_2;
      r0 = term_clo(FID_MAIN_C245, _nd_3);
      WL_RETN(1);
    }
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K236)
  {
    WL_POPN(1);
    Term _h_5 = STK(0);
    Term _h_4 = r0;
    WL_OPEN
    if (seq) {
      WL_ROOM(1);
      STK(0) = FID_MAIN_K237;
      WL_PUSHN(1);
    } else {
      u64 _t_4 = task_node(e, FID_MAIN_K237, WL_CONT, WL_IDX, 1);
      WL_CONT = term_tsk(FID_MAIN_K237, _t_4);
      WL_IDX = 0;
    }
    if (!DEVICE && !seq && fid_nofk(FID_STRING_APPEND)) {
      u64 _t_5 = task_node(e, FID_STRING_APPEND, WL_CONT, WL_IDX, 0);
      e.mem[_t_5 + 0] = _h_5;
      e.mem[_t_5 + 1] = _h_4;
      return term_tsk(FID_STRING_APPEND, _t_5);
    }
    r0 = _h_5;
    r1 = _h_4;
    WL_JMP(FID_STRING_APPEND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K237)
  {
    Term _h_6 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _h_6;
    r0 = term_clo(FID_MAIN_C238, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C238)
  {
    Term _h_7 = r0;
    Term _x_2 = r1;
    WL_OPEN
    Term _o_0[1];
    if (spin_12(e, _o_0, 2ull, _h_7, _x_2) == 0) {
      return 0;
    }
    r0 = _o_0[0];
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C239)
  {
    Term _x_3 = r0;
    WL_OPEN
    u64 _nd_1 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_1 + 0] = term_ctr(CID_SCON, STAT_OFF + 3650);
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_7 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_7 + 0] = term_clo(FID_IO_PRINT, _nd_1);
      e.mem[_t_7 + 1] = term_clo(FID_MAIN_C240, 0);
      e.mem[_t_7 + 2] = _x_3;
      return term_tsk(FID_IO_BIND, _t_7);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_1);
    r1 = term_clo(FID_MAIN_C240, 0);
    r2 = _x_3;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C240)
  {
    Term _x_4 = r0;
    WL_OPEN
    r0 = term_clo(FID_MAIN_C241, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C241)
  {
    Term _x_5 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_6 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_6 + 0] = 0ull;
      e.mem[_t_6 + 1] = _x_5;
      return term_tsk(FID_IO_PURE, _t_6);
    }
    r0 = 0ull;
    r1 = _x_5;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C242)
  {
    Term _x_6 = r0;
    WL_OPEN
    u64 _nd_2 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_2 + 0] = term_ctr(CID_SCON, STAT_OFF + 3782);
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_9 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_9 + 0] = term_clo(FID_IO_PRINT, _nd_2);
      e.mem[_t_9 + 1] = term_clo(FID_MAIN_C243, 0);
      e.mem[_t_9 + 2] = _x_6;
      return term_tsk(FID_IO_BIND, _t_9);
    }
    r0 = term_clo(FID_IO_PRINT, _nd_2);
    r1 = term_clo(FID_MAIN_C243, 0);
    r2 = _x_6;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C243)
  {
    Term _x_7 = r0;
    WL_OPEN
    r0 = term_clo(FID_MAIN_C244, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C244)
  {
    Term _x_8 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_8 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_8 + 0] = 0ull;
      e.mem[_t_8 + 1] = _x_8;
      return term_tsk(FID_IO_PURE, _t_8);
    }
    r0 = 0ull;
    r1 = _x_8;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C245)
  {
    Term _h_8 = r0;
    Term _h_9 = r1;
    Term _x_9 = r2;
    WL_OPEN
    u64 _nd_4 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_4 + 0] = term_pak(CID_SNIL, 0);
    u64 _nd_5 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_5 + 0] = _h_8;
    e.mem[_nd_5 + 1] = _h_9;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_22 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_22 + 0] = term_clo(FID_NATIVEHOST_PATH, _nd_4);
      e.mem[_t_22 + 1] = term_clo(FID_MAIN_C246, _nd_5);
      e.mem[_t_22 + 2] = _x_9;
      return term_tsk(FID_IO_BIND, _t_22);
    }
    r0 = term_clo(FID_NATIVEHOST_PATH, _nd_4);
    r1 = term_clo(FID_MAIN_C246, _nd_5);
    r2 = _x_9;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C246)
  {
    Term _h_10 = r0;
    Term _h_11 = r1;
    Term _x_10 = r2;
    WL_OPEN
    u32 _o_1 = 0;
    Term _o_2 = 0;
    Term _o_3 = 0;
    if (term_aux(_x_10) == CID_FAIL) {
      _o_1 = 0;
      u64 _sp_1 = term_loc(_x_10);
      Term _f_2 = e.mem[_sp_1 + 0];
      heap_free(e, cls_fit(1), _sp_1);
      u64 _sp_2 = term_loc(_f_2);
      Term _f_3 = e.mem[_sp_2 + 0];
      Term _f_4 = e.mem[_sp_2 + 1];
      heap_free(e, cls_fit(2), _sp_2);
      _o_2 = _f_3;
      _o_3 = _f_4;
    } else {
      _o_1 = 1;
      u64 _sp_3 = term_loc(_x_10);
      Term _f_5 = e.mem[_sp_3 + 0];
      heap_free(e, cls_fit(1), _sp_3);
      _o_2 = _f_5;
    }
    u64 _nd_6 = heap_alloc(e, cls_fit(5));
    e.mem[_nd_6 + 0] = _h_10;
    e.mem[_nd_6 + 1] = _h_11;
    e.mem[_nd_6 + 2] = _o_1;
    e.mem[_nd_6 + 3] = _o_2;
    e.mem[_nd_6 + 4] = _o_3;
    r0 = term_clo(FID_MAIN_C247, _nd_6);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C247)
  {
    Term _h_12 = r0;
    Term _h_13 = r1;
    u32 _o_4 = r2;
    Term _o_5 = r3;
    Term _o_6 = r4;
    Term _x_11 = r5;
    WL_OPEN
    Term _v_0 = 0;
    Term _o_7[1];
    if (spin_9(e, _o_7, _o_4, _o_5, _o_6) == 0) {
      return 0;
    }
    _v_0 = _o_7[0];
    u64 _nd_7 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_7 + 0] = _h_12;
    e.mem[_nd_7 + 1] = _h_13;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_21 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_21 + 0] = _v_0;
      e.mem[_t_21 + 1] = term_clo(FID_MAIN_C248, _nd_7);
      e.mem[_t_21 + 2] = _x_11;
      return term_tsk(FID_IO_BIND, _t_21);
    }
    r0 = _v_0;
    r1 = term_clo(FID_MAIN_C248, _nd_7);
    r2 = _x_11;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C248)
  {
    Term _h_14 = r0;
    Term _h_15 = r1;
    Term _x_12 = r2;
    WL_OPEN
    if (seq) {
      WL_ROOM(3);
      STK(0) = _h_14;
      STK(1) = _h_15;
      STK(2) = FID_MAIN_K249;
      WL_PUSHN(3);
    } else {
      u64 _t_10 = task_node(e, FID_MAIN_K249, WL_CONT, WL_IDX, 1);
      e.mem[_t_10 + 0] = _h_14;
      e.mem[_t_10 + 1] = _h_15;
      WL_CONT = term_tsk(FID_MAIN_K249, _t_10);
      WL_IDX = 2;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_ASSET)) {
      u64 _t_11 = task_node(e, FID_CLI_ASSET, WL_CONT, WL_IDX, 0);
      e.mem[_t_11 + 0] = _x_12;
      e.mem[_t_11 + 1] = term_ctr(CID_SCON, STAT_OFF + 28);
      return term_tsk(FID_CLI_ASSET, _t_11);
    }
    r0 = _x_12;
    r1 = term_ctr(CID_SCON, STAT_OFF + 28);
    WL_JMP(FID_CLI_ASSET);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K249)
  {
    WL_POPN(2);
    Term _h_17 = STK(0);
    Term _h_18 = STK(1);
    Term _h_16 = r0;
    WL_OPEN
    u64 _nd_8 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_8 + 0] = _h_17;
    e.mem[_nd_8 + 1] = _h_18;
    e.mem[_nd_8 + 2] = _h_16;
    r0 = term_clo(FID_MAIN_C250, _nd_8);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C250)
  {
    Term _h_19 = r0;
    Term _h_20 = r1;
    Term _h_21 = r2;
    Term _x_13 = r3;
    WL_OPEN
    u64 _nd_9 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_9 + 0] = _h_19;
    e.mem[_nd_9 + 1] = _h_20;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_20 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_20 + 0] = _h_21;
      e.mem[_t_20 + 1] = term_clo(FID_MAIN_C251, _nd_9);
      e.mem[_t_20 + 2] = _x_13;
      return term_tsk(FID_IO_BIND, _t_20);
    }
    r0 = _h_21;
    r1 = term_clo(FID_MAIN_C251, _nd_9);
    r2 = _x_13;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C251)
  {
    Term _h_22 = r0;
    Term _h_23 = r1;
    Term _x_14 = r2;
    WL_OPEN
    term_sink(e, _x_14);
    u64 _nd_10 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_10 + 0] = _h_22;
    e.mem[_nd_10 + 1] = _h_23;
    r0 = term_clo(FID_MAIN_C252, _nd_10);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C252)
  {
    Term _h_24 = r0;
    Term _h_25 = r1;
    Term _x_15 = r2;
    WL_OPEN
    u64 _nd_11 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_11 + 0] = _h_24;
    u64 _nd_12 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_12 + 0] = _h_25;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_19 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_19 + 0] = term_clo(FID_NATIVEHOST_PATH, _nd_11);
      e.mem[_t_19 + 1] = term_clo(FID_MAIN_C253, _nd_12);
      e.mem[_t_19 + 2] = _x_15;
      return term_tsk(FID_IO_BIND, _t_19);
    }
    r0 = term_clo(FID_NATIVEHOST_PATH, _nd_11);
    r1 = term_clo(FID_MAIN_C253, _nd_12);
    r2 = _x_15;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C253)
  {
    Term _h_26 = r0;
    Term _x_16 = r1;
    WL_OPEN
    u32 _o_8 = 0;
    Term _o_9 = 0;
    Term _o_10 = 0;
    if (term_aux(_x_16) == CID_FAIL) {
      _o_8 = 0;
      u64 _sp_4 = term_loc(_x_16);
      Term _f_6 = e.mem[_sp_4 + 0];
      heap_free(e, cls_fit(1), _sp_4);
      u64 _sp_5 = term_loc(_f_6);
      Term _f_7 = e.mem[_sp_5 + 0];
      Term _f_8 = e.mem[_sp_5 + 1];
      heap_free(e, cls_fit(2), _sp_5);
      _o_9 = _f_7;
      _o_10 = _f_8;
    } else {
      _o_8 = 1;
      u64 _sp_6 = term_loc(_x_16);
      Term _f_9 = e.mem[_sp_6 + 0];
      heap_free(e, cls_fit(1), _sp_6);
      _o_9 = _f_9;
    }
    u64 _nd_13 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_13 + 0] = _h_26;
    e.mem[_nd_13 + 1] = _o_8;
    e.mem[_nd_13 + 2] = _o_9;
    e.mem[_nd_13 + 3] = _o_10;
    r0 = term_clo(FID_MAIN_C254, _nd_13);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C254)
  {
    Term _h_27 = r0;
    u32 _o_11 = r1;
    Term _o_12 = r2;
    Term _o_13 = r3;
    Term _x_17 = r4;
    WL_OPEN
    Term _v_1 = 0;
    Term _o_14[1];
    if (spin_9(e, _o_14, _o_11, _o_12, _o_13) == 0) {
      return 0;
    }
    _v_1 = _o_14[0];
    u64 _nd_14 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_14 + 0] = _h_27;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_18 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_18 + 0] = _v_1;
      e.mem[_t_18 + 1] = term_clo(FID_MAIN_C255, _nd_14);
      e.mem[_t_18 + 2] = _x_17;
      return term_tsk(FID_IO_BIND, _t_18);
    }
    r0 = _v_1;
    r1 = term_clo(FID_MAIN_C255, _nd_14);
    r2 = _x_17;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C255)
  {
    Term _h_28 = r0;
    Term _x_18 = r1;
    WL_OPEN
    if (seq) {
      WL_ROOM(2);
      STK(0) = _h_28;
      STK(1) = FID_MAIN_K256;
      WL_PUSHN(2);
    } else {
      u64 _t_12 = task_node(e, FID_MAIN_K256, WL_CONT, WL_IDX, 1);
      e.mem[_t_12 + 0] = _h_28;
      WL_CONT = term_tsk(FID_MAIN_K256, _t_12);
      WL_IDX = 1;
    }
    if (!DEVICE && !seq && fid_nofk(FID_CLI_READ)) {
      u64 _t_13 = task_node(e, FID_CLI_READ, WL_CONT, WL_IDX, 0);
      e.mem[_t_13 + 0] = _x_18;
      e.mem[_t_13 + 1] = term_pak(CID_SNIL, 0);
      return term_tsk(FID_CLI_READ, _t_13);
    }
    r0 = _x_18;
    r1 = term_pak(CID_SNIL, 0);
    WL_JMP(FID_CLI_READ);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_K256)
  {
    WL_POPN(1);
    Term _h_30 = STK(0);
    Term _h_29 = r0;
    WL_OPEN
    u64 _nd_15 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_15 + 0] = _h_30;
    e.mem[_nd_15 + 1] = _h_29;
    r0 = term_clo(FID_MAIN_C257, _nd_15);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C257)
  {
    Term _h_31 = r0;
    Term _h_32 = r1;
    Term _x_19 = r2;
    WL_OPEN
    u64 _nd_16 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_16 + 0] = _h_31;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_17 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_17 + 0] = _h_32;
      e.mem[_t_17 + 1] = term_clo(FID_MAIN_C258, _nd_16);
      e.mem[_t_17 + 2] = _x_19;
      return term_tsk(FID_IO_BIND, _t_17);
    }
    r0 = _h_32;
    r1 = term_clo(FID_MAIN_C258, _nd_16);
    r2 = _x_19;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C258)
  {
    Term _h_33 = r0;
    Term _x_20 = r1;
    WL_OPEN
    u64 _nd_17 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_17 + 0] = _h_33;
    e.mem[_nd_17 + 1] = _x_20;
    r0 = term_clo(FID_MAIN_C259, _nd_17);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C259)
  {
    Term _h_34 = r0;
    Term _x_22 = r1;
    Term _x_21 = r2;
    WL_OPEN
    u64 _nd_18 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_18 + 0] = _h_34;
    e.mem[_nd_18 + 1] = _x_22;
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_16 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_16 + 0] = term_clo(FID_NATIVEHOST_PUBLISH, _nd_18);
      e.mem[_t_16 + 1] = term_clo(FID_MAIN_C260, 0);
      e.mem[_t_16 + 2] = _x_21;
      return term_tsk(FID_IO_BIND, _t_16);
    }
    r0 = term_clo(FID_NATIVEHOST_PUBLISH, _nd_18);
    r1 = term_clo(FID_MAIN_C260, 0);
    r2 = _x_21;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C260)
  {
    Term _x_23 = r0;
    WL_OPEN
    u32 _o_15 = 0;
    u32 _o_16 = 0;
    Term _o_17 = 0;
    if (term_aux(_x_23) == CID_FAIL) {
      _o_15 = 0;
      u64 _sp_7 = term_loc(_x_23);
      Term _f_10 = e.mem[_sp_7 + 0];
      heap_free(e, cls_fit(1), _sp_7);
      u64 _sp_8 = term_loc(_f_10);
      Term _f_11 = e.mem[_sp_8 + 0];
      Term _f_12 = e.mem[_sp_8 + 1];
      heap_free(e, cls_fit(2), _sp_8);
      _o_16 = _f_11;
      _o_17 = _f_12;
    } else {
      _o_15 = 1;
      u64 _sp_9 = term_loc(_x_23);
      Term _f_13 = e.mem[_sp_9 + 0];
      heap_free(e, cls_fit(1), _sp_9);
    }
    u64 _nd_19 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_19 + 0] = _o_15;
    e.mem[_nd_19 + 1] = _o_16;
    e.mem[_nd_19 + 2] = _o_17;
    r0 = term_clo(FID_MAIN_C261, _nd_19);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C261)
  {
    u32 _o_18 = r0;
    u32 _o_19 = r1;
    Term _o_20 = r2;
    Term _x_24 = r3;
    WL_OPEN
    Term _v_2 = 0;
    u32 _o_21 = 0;
    Term _o_22 = 0;
    Term _o_23 = 0;
    if (_o_18 == 0) {
      _o_21 = 0;
      _o_22 = _o_19;
      _o_23 = _o_20;
    } else {
      _o_21 = 1;
      _o_22 = term_pak(CID_UNIT, 0);
    }
    Term _o_24[1];
    if (spin_10(e, _o_24, _o_21, _o_22, _o_23) == 0) {
      return 0;
    }
    _v_2 = _o_24[0];
    if (!DEVICE && !seq && fid_nofk(FID_IO_BIND)) {
      u64 _t_15 = task_node(e, FID_IO_BIND, WL_CONT, WL_IDX, 0);
      e.mem[_t_15 + 0] = _v_2;
      e.mem[_t_15 + 1] = term_clo(FID_MAIN_C262, 0);
      e.mem[_t_15 + 2] = _x_24;
      return term_tsk(FID_IO_BIND, _t_15);
    }
    r0 = _v_2;
    r1 = term_clo(FID_MAIN_C262, 0);
    r2 = _x_24;
    WL_JMP(FID_IO_BIND);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C262)
  {
    Term _x_25 = r0;
    WL_OPEN
    r0 = term_clo(FID_MAIN_C263, 0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C263)
  {
    Term _x_26 = r0;
    WL_OPEN
    if (!DEVICE && !seq && fid_nofk(FID_IO_PURE)) {
      u64 _t_14 = task_node(e, FID_IO_PURE, WL_CONT, WL_IDX, 0);
      e.mem[_t_14 + 0] = 0ull;
      e.mem[_t_14 + 1] = _x_26;
      return term_tsk(FID_IO_PURE, _t_14);
    }
    r0 = 0ull;
    r1 = _x_26;
    WL_JMP(FID_IO_PURE);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_MAIN_C264)
  {
    Term _x_27 = r0;
    WL_OPEN
    Term _o_25[1];
    if (spin_12(e, _o_25, 2ull, term_ctr(CID_SCON, STAT_OFF + 3650), _x_27) == 0) {
      return 0;
    }
    r0 = _o_25[0];
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_ARGS)
  {
    Term _k_0 = r0;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(1));
    e.mem[_nd_0 + 0] = _k_0;
    r0 = term_ctr(CID_IO_ARGS, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_IO_PRINT)
  {
    Term _text_0 = r0;
    Term _k_0 = r1;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _text_0;
    e.mem[_nd_0 + 1] = _k_0;
    r0 = term_ctr(CID_IO_PRINT, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NATIVEHOST_PATH)
  {
    Term _path_0 = r0;
    Term _k_0 = r1;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(2));
    e.mem[_nd_0 + 0] = _path_0;
    e.mem[_nd_0 + 1] = _k_0;
    r0 = term_ctr(CID_NATIVEHOST_PATH, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NATIVEHOST_PUBLISH)
  {
    Term _path_0 = r0;
    Term _text_0 = r1;
    Term _k_0 = r2;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(3));
    e.mem[_nd_0 + 0] = _path_0;
    e.mem[_nd_0 + 1] = _text_0;
    e.mem[_nd_0 + 2] = _k_0;
    r0 = term_ctr(CID_NATIVEHOST_PUBLISH, _nd_0);
    WL_RETN(1);
  }}
#endif

#if !DEVICE
  WL_CASE(FID_NATIVEHOST_READ)
  {
    Term _path_0 = r0;
    Term _digest_0 = r1;
    Term _limit_0 = r2;
    Term _k_0 = r3;
    WL_OPEN
    u64 _nd_0 = heap_alloc(e, cls_fit(4));
    e.mem[_nd_0 + 0] = _path_0;
    e.mem[_nd_0 + 1] = _digest_0;
    e.mem[_nd_0 + 2] = _limit_0;
    e.mem[_nd_0 + 3] = _k_0;
    r0 = term_ctr(CID_NATIVEHOST_READ, _nd_0);
    WL_RETN(1);
  }}
#endif

  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    u32 f   = (u32)term_aux(t);
    u64 a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    seq |= fid_nofk(f) << 1;
    u32 rw = fid_resw(f);
    if (rw) {
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    u64 l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(FID_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    u32 f    = (u32)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    u64 a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    u32  wf   = (u32)term_aux(cont);
    if (cont != TERM_HOLE && fid_resw(wf)) {
      u64 wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      seq = (seq & 1) | fid_nofk(wf) << 1;
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing
// lane skips a fork-free one). The host grows a row ring by
// ring and drains a ring; a device lane does both.
INLINE u32 monk_step(Env e, DEV Term* stk, u32 rg, u32 put0, u32 base, u32 stride,
  TG u32* cur) {
  DEV u64* H   = e.mem;
  bool     seq = stride == 0;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Term r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// One kernel: pass 0 grows the frontier, pass 1 runs the c-th deal on lane
// c, pass 2 packs the banks: in one group, each bank's [top, wr) slides onto
// rd, CUBE_T entries a step (loads, barrier, stores: rd <= top), off the
// host's pages. A grow pass ends when its group is full or nothing grew,
// so a spine of forks unrolls whole. TG_HOLD words of threadgroup memory
// hold one group per Apple core (bitonic 1.35x without). Pass 3 is pass 1
// after a grow from under CUBE_T roots, on the lane's own ring to ring_held.

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      u64 head = ALC_AT(e, c);
      u64 tail = head;
      for (u32 i = 1; i < KEEP(c); i += 1) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

INLINE void bank_pack(DEV u64* H, u32 lane) {
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

#ifdef __METAL_VERSION__
kernel void bend_dev(DEV u64* H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  TG u32* vote [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(DEV u64* H, u32 pass) {
  extern __shared__ u32 vote[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  u32 rg     = pass == 1 ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  DEV Term*  stk    = (DEV Term*)(H + STAK_OFF + me);
  if (lane == 0) {
    for (u32 i = 0; i < 3; i += 1) {
      a32_store(vote + i, 0);
    }
  }
  BAR();
  u32 put0      = a32_load(pass == 3 ? ring_held(H, rg) : ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (;;) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 has = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        has = CUBE_T;
      }
      a32_add(vote + 2, has);
      BAR();
      has = a32_load(vote + 2);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, row * CUBE_T, pass ? 0 : stride,
      vote);
    if (!pass) {
      if (ran == 1) {
        a32_add(vote + 1, 1);
      }
      BARD();
      u32 grew = a32_load(vote + 1);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  if (pass == 0) {
    a32_store(ring_held(H, rg), a32_load(ring_put(H, rg)));
  }
  dev_cut(e);
}

#endif

// Window
// ======

// Linux's window fill (the Mac's is window_msl): an Image is a quadtree over
// 2^k x 2^k (Qua splits tl, tr, bl, br; Pix is 0xRRGGBB).
#if defined(__linux__) || defined(BEND_RTC)

INLINE u32 window_pix(DEV u64* H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    t = H[term_peek(H, t) + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef BEND_RTC
extern "C" __global__ void window_dev(DEV u64* H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static u32 row_grow(Env e, DEV Term* stk, u32 base, u32 stride, u32 want) {
  u64* H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return cur;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], base, stride,
        &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return cur;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

// A wait yields a while before it sleeps, so a turn that ends (or follows)
// within microseconds never pays a condvar wake.

#define POOL_WAIT(c, cv) \
  for (u32 s = 0; s < 128 && (c); s += 1) { \
    sched_yield(); \
  } \
  pthread_mutex_lock(&pool_lock); \
  while (c) { \
    pthread_cond_wait(&cv, &pool_lock); \
  } \
  pthread_mutex_unlock(&pool_lock);

static u32 pool_step(u32 rows) {
  u32 per = rows * CUBE_T / (32 * pool_size);
  return CUBE_T >> (31 - CLZ(per < LINE ? per | 1 : LINE));
}

static u32 pool_rows(Env e, DEV Term* stk) {
  u32 n = 0;
  for (;;) {
    u32 c    = a32_add(&pool_row, 1);
    u32 r    = c & 32767;
    u32 rows = c >> 15 & 255;
    u32 step = c >> 23 & 1 ? 1 : pool_step(rows);
    if (r >= rows * step) {
      if (n != 0 && a32_sub_rel(&pool_done, n) == n) {
        pthread_mutex_lock(&pool_lock);
        pthread_cond_signal(&pool_join);
        pthread_mutex_unlock(&pool_lock);
      }
      return c >> 24;
    }
    a32_acq(&pool_row);
    if (c >> 23 & 1) {
      row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
    } else {
      u32 row = r / step * CUBE_T;
      for (u32 rg = row + r % step; rg < row + CUBE_T; rg += step) {
        u32 put0 = a32_load(ring_put(e.mem, rg));
        while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
          monk_step(e, stk, rg, put0, rg, 0, NULL);
        }
      }
    }
    n += 1;
  }
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u32   seen = 0;
  for (;;) {
    POOL_WAIT(a32_load(&pool_row) >> 24 == seen, pool_wake)
    seen = pool_rows((Env){ CORPUS, ALC[(uintptr_t)arg] }, stk);
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 1; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  if (f == NULL) {
    return 0;
  }
  int n = fscanf(f, "%ld %ld", a, b);
  fclose(f);
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow, u32 rows) {
  static u32 turn;
  u32 n = rows < CUBE_G ? rows : CUBE_G;
  turn += 1;
  a32_store(&pool_done, grow ? n : n * pool_step(n));
  pthread_mutex_lock(&pool_lock);
  a32_store_rel(&pool_row, turn << 24 | grow << 23 | n << 15);
  pthread_cond_broadcast(&pool_wake);
  pthread_mutex_unlock(&pool_lock);
  pool_rows((Env){ CORPUS, ALC[0] }, io_stk);
  POOL_WAIT(a32_load_acq(&pool_done) != 0, pool_join)
}

// Gpu
// ===

// gpu_make compiles the device program into <binary>.gpu
// (--gpu-build): Metal's binary archive, or CUDA's cubin behind a
// hash of the text. A launch loads it, else notes and compiles. CUDA
// shapes the bag by the device: a group of 128 lanes per 64 KB of
// L2, a power of two in 16..128 (Apple keeps the tuned 128). CUDA
// runs one stream: the default 8 cost about half of the startup.

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(f < CUBE_T ? 3 : 1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_METAL

static void gpu_fail(NSError* err) {
  err_fail([[err localizedDescription] UTF8String]);
}

static const char* gpu_probe(void) {
  gpu_dev = MTLCreateSystemDefaultDevice();
  return gpu_dev == nil ? "this binary found no usable Metal GPU" : NULL;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    gpu_fail(err);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    gpu_fail(err);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    gpu_fail(err);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  u64 most = [gpu_dev maxBufferLength];
  if (!gpu_buf && bytes > most) {
    char msg[96];
    snprintf(msg, sizeof msg, "--gpu %lluMB is over the device's %lluMB",
      (unsigned long long)(bytes >> 20), (unsigned long long)(most >> 20));
    err_fail(msg);
  }
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      gpu_fail([cb error]);
    }
  }
}

#elif BEND_CUDA

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

#define GPU_CHECK(fn, ...) do { \
  if ((result = fn(__VA_ARGS__)) != CUDA_SUCCESS) { why = #fn; goto fail; } \
} while (0)

static const char* gpu_probe(void) {
  static char error[192];
  const char* why;
  CUresult result;
  int managed = 0;
  CUcontext ctx;
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  GPU_CHECK(cuInit, 0);
  GPU_CHECK(cuDeviceGet, &gpu_dev, 0);
  GPU_CHECK(cuDeviceGetAttribute, &managed,
    CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  if (managed == 0) {
    return "CUDA device lacks concurrent managed access (WSL2 lacks it)";
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  int units = l2 >> 16;
  CUBE_LOG  = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
  GPU_CHECK(cuDevicePrimaryCtxRetain, &ctx, gpu_dev);
  result = cuCtxSetCurrent(ctx);
  if (result != CUDA_SUCCESS) {
    cuDevicePrimaryCtxRelease(gpu_dev);
    why = "cuCtxSetCurrent";
    goto fail;
  }
  return NULL;
fail:;
  const char* name = NULL;
  if (cuGetErrorName(result, &name) != CUDA_SUCCESS || name == NULL) {
    name = "unknown CUDA error";
  }
  snprintf(error, sizeof error, "%s failed: %s", why, name);
  return error;
}

#undef GPU_CHECK

static u64* gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (u64*)(uintptr_t)p;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() "this binary has no CUDA or Metal GPU support"
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

// The host's column grows to the rows that give a LINE of tasks a thread,
// no more: every task a grow starts early is live at once (tree-matmul's
// 2048 at 16 threads start 384 rounds: 15 MB -> 68 MB), and pool_step
// splits the few rows finely instead. A turn visits only the rows below
// its bound: a drain deals task g to ring_flip(g), whose row is at most g,
// a row grows into itself, and a column grow's cur tasks land in rows 0
// to cur - 1, so those rows hold every task.

// Between turns, each ring's pending tasks move back to slot 0.

static void ring_rewind(u64* H, u32 rows) {
  Term keep[RING_LEN];
  for (u32 r = 0; r < (rows < CUBE_G ? rows : CUBE_G) * CUBE_T; r += 1) {
    u32 g = *ring_get(H, r);
    u32 n = *ring_put(H, r) - g;
    if (g == 0) {
      continue;
    }
    for (u32 i = 0; i < n; i += 1) {
      keep[i] = *ring_slot(H, r, g + i) & ~RFC_BIT;
    }
    for (u32 i = n; i < g + n && i < RING_LEN; i += 1) {
      ((u32*)ring_slot(H, r, i))[1] = 0;
    }
    *ring_get(H, r) = *ring_put(H, r) = 0;
    for (u32 i = 0; i < n; i += 1) {
      ring_push(H, r, keep[i]);
    }
  }
}

static void cube_run(u64* H, bool gpu) {
  for (;;) {
    u32 f = a32_exch(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      u32 rows = f;
      u32 want = (pool_size - 1) / (CUBE_T / LINE) + 1;
      if (f < want) {
        u32 cur = row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, want);
        rows = cur > f ? cur : f;
      }
      if (f < CUBE) {
        pool_turn(true, rows);
      }
      f = a32_load(a32_at(H, H_CURSOR));
      pool_turn(false, f > rows ? f : rows);
      f = a32_load(a32_at(H, H_CURSOR));
      ring_rewind(H, f > rows ? f : rows);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, so one
// base holds every location; the banks move up past the pages. The GPU maps
// its whole span at once, and never grows it.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  for (u64 hint = 1ull << 45; hint > size; hint /= 2) {
    void* p = pool_try((void*)hint, size);
    if (p == (void*)hint) {
      return p;
    }
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
  }
  return pool_mmap(size);
}

static void corpus_lay(u64* H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(u64* H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static u64* corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  u64* H     = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  corpus_lay(H, size);
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(u64* H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  while ((t = work_loop(e, io_stk, t, !BANGS && pool_size == 1)) != 0) {
    u64 tl = task_tail(t);
    if ((u32)H[tl + 1] != 0) {
      task_deal(H, t, 0, 0, NULL);
      pool_open();
      cube_run(H, false);
      break;
    }
    if (io_gpu && fid_bangs((u32)term_aux(t))) {
      Term cont = H[tl];
      u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
      H[tl]     = TERM_HOLE;
      a32_store(a32_at(H, H_CURSOR), 1);
      ring_push(H, 0, t);
      cube_run(H, true);
      t = task_deliver(H, cont, idx, rv, root_take(H, rv));
      if (t == 0) {
        break;
      }
    }
  }
  if (!root_done(H)) {
    err_fail("a delivery lost");
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

// Base's opaque, linear handles pack host fds or pointers into aux and loc:
// no forging, copying, reuse or host wrapper. A request's cont applied to
// its item is the next request. A parked request keeps its fd, deadline and
// readiness in word, time and evts; the loop then calls pack: a value
// resumes, IO_PARK parks again. The edge is UTF-8, decoded as WHATWG does: a
// broken sequence yields one U+FFFD and its breaking byte is read again as a
// lead. inet_aton reads a leading zero as octal, so io_sys_addr refuses it.
// macOS poll misses FIFO EOF, so io_wait selects, its sets sized to the
// highest fd (_DARWIN_UNLIMITED_SELECT allows fds past FD_SETSIZE).

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_PARK TERM_HOLE

#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

typedef struct IoWork {
  intptr_t       hand;
  intptr_t       made;
  u32            word;
  u64            size;
  char*          data;
  char*          text;
  u32            code;
  IoCall         call;
  IoPack         pack;
  Term           cont;
  Term           item;
  u64            time;
  short          evts;
  struct IoWork* next;
  struct IoWork* prev;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

Effect io_eff_rows[sizeof CID_T / sizeof *CID_T];
static u32    io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    if ((p == host || p[-1] == '.') && *p == '0'
      && p[1] >= '0' && p[1] <= '9') {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

static int    io_argc;
static char** io_argv;

static void io_eff(u32 cid, Effect run) {
  if (io_eff_rows[cid] != NULL) {
    err_fail("two effects register one request");
  }
  io_eff_rows[cid] = run;
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

static IoWork* io_runs;
static IoWork* io_park;
static IoWork* io_jobs;

static void io_push(IoWork** q, IoWork* a) {
  IoWork* l = *q != NULL ? *q : a;
  a->next = l->next;
  l->next = a;
  *q      = a;
}

static IoWork* io_pop(IoWork** q) {
  IoWork* a  = (*q)->next;
  (*q)->next = a->next;
  *q         = a != *q ? *q : NULL;
  return a;
}

static void io_spawn(Term m) {
  IoWork* a = io_mem(calloc(1, sizeof(IoWork)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// io_park stays in deadline order (time 0, none, sorts last; ties keep
// their park order), so io_wait wakes due timers in the order they expire.
// It links both ways, so io_park_cut drops a waiter in O(1).
static void io_park_add(IoWork* w) {
  IoWork* p = io_park;
  if (p == NULL || p->time - 1 <= w->time - 1) {
    io_push(&io_park, w);
  } else {
    while (p->next->time - 1 <= w->time - 1) {
      p = p->next;
    }
    io_push(&p, w);
  }
  w->prev       = w->next == w ? w : w->next->prev;
  w->next->prev = w;
}

static void io_park_cut(IoWork* w) {
  w->prev->next = w->next;
  w->next->prev = w->prev;
  io_park = w->next == w ? NULL : io_park == w ? w->prev : io_park;
}

static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  w->word = (u32)fd;
  w->pack = more;
  w->time = time;
  w->evts = evts;
  io_park_add(w);
  return IO_PARK;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  u64 l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

static Term io_str(Env e, const char* p, u64 n) {
  Term  s;
  Term* hole = &s;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    u64  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    *hole = hole == &s ? t : io_seal(e, t, CID_SCON);
    hole = &e.mem[l + 1];
  }
  *hole = term_pak(CID_SNIL, 0);
  return s;
}

// Bytes cross as they are (0..255), one List cell each, with no UTF-8.
#ifdef CID_CON

static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

#endif

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)
#define io_res(e, w, v) ((w)->code ? io_fail(e, (w)->code, NULL) \
  : io_done(e, v))
#define io_until(ms)    (io_tick() + (u64)(ms) * 1000000ull)
#define io_again(w) ((w)->code == EAGAIN \
  && ((w)->time == 0 || io_tick() < (w)->time))
#define io_poll_end(e, w, rest, r) ((w)->code == EAGAIN \
  ? io_box(e, CID_WAIT, rest) : (w)->time ? io_box(e, CID_READY, r) : (r))

static Term io_box(Env e, u64 cid, Term v) {
  u64 l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_err(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  return io_tup(e, code, io_str(e, s, strlen(s)));
}

#define io_fail(e, code, text) io_box(e, CID_FAIL, io_err(e, code, text))

static pthread_mutex_t io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t  io_bell = PTHREAD_COND_INITIALIZER;
static u32             io_busy;
static u32             io_size;
static int             io_wake_fd[2];

static void io_take(Env e) {
  IoWork* acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoWork*); i += 1) {
      IoWork* a = acts[i];
      a->item   = a->pack(e, a);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoWork* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->call(a);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

static bool io_bit(u8* set, int fd, bool put) {
  u8* at = set + fd / 8;
  *at |= put << fd % 8;
  return *at >> fd % 8 & 1;
}

static void io_wait(Env e, bool block) {
  int top  = io_wake_fd[0];
  u64 soon = io_park != NULL ? io_park->next->time : 0;
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0 && (int)a->word > top) {
      top = (int)a->word;
    }
  }
  u64 len = (u64)top / 64 * 8 + 8;
  u8* set[2] = { io_mem(calloc(2, len)), NULL };
  set[1] = set[0] + len;
  io_bit(set[0], io_wake_fd[0], true);
  for (IoWork* a = io_park; a != NULL;
    a = a->next != io_park ? a->next : NULL) {
    if (a->evts != 0) {
      io_bit(set[a->evts == POLLOUT], (int)a->word, true);
    }
  }
  u64 tick = io_tick();
  u64 ms = soon > tick && block ? (soon - tick) / 1000000 + 1 : 0;
  struct timeval tv = { ms / 1000, ms % 1000 * 1000 };
  io_sync();
  if (select(top + 1, (fd_set*)set[0], (fd_set*)set[1], NULL,
    soon == 0 && block ? NULL : &tv) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
    memset(set[0], 0, 2 * len);
  }
  if (io_bit(set[0], io_wake_fd[0], false)) {
    io_take(e);
  }
  u64     now  = io_tick();
  IoWork* todo = io_park;
  io_park = NULL;
  while (todo != NULL) {
    IoWork* a   = io_pop(&todo);
    bool    due = (a->evts != 0
        && io_bit(set[a->evts == POLLOUT], (int)a->word, false))
      || (a->time != 0 && a->time <= now);
    if (!due) {
      io_park_add(a);
      continue;
    }
    Term x = a->pack(e, a);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(set[0]);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}


// Show
// ====

// show_val prints a pure main's value as term_show spells it: d
// is a SHOW_DESC node (see show_main), w its words, and chain the
// bracket of the [a, b] or (a, b) the value continues, or 0. Con
// or Nil spell a list, Tuple a tuple, and their tails continue
// it. show_chr escapes as char_show does; show_f32 prints the
// shortest text that reads back, with a point before an e.

#if MAIN_PURE

static void show_val(Env e, u32 d, const Term* w, char chain);

static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

static void show_f32(u32 x) {
  char buf[40];
  int  n = f32_text(buf, f32_unbox(x));
  buf[n] = 0;
  int  m = (int)strcspn(buf, "e");
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0:
      printf("%u", (u32)w[0]);
      break;
    case 1:
      show_f32((u32)w[0]);
      break;
    case 2:
      printf("%llun", (unsigned long long)w[0]);
      break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        u64 l = term_peek(e.mem, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5:
      fputs("{==}", stdout);
      break;
    case 6:
      putchar('[');
      for (u32 i = 0, g = D[d + 2]; i < 1u << (blk_cls(w[0]) - g); i += 1) {
        Term v[1u << g];
        for (u32 j = 0; j < 1u << g; j += 1) {
          v[j] = blk_read(e.mem, term_tag(w[0]) == TAG_ARR,
            term_peek(e.mem, w[0]), (i << g) + j);
        }
        fputs(i > 0 ? ", " : "", stdout);
        show_val(e, D[d + 1], v, 0);
      }
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 4 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e.mem, t);
      }
      char o = "{[("[D[a + 3]];
      if (o == '{') {
        fputs(SHOW_NAMES[D[a]], stdout);
      }
      if (chain != o) {
        putchar(o);
        zs[zn++] = "}])"[D[a + 3]];
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 5 + 2 * j];
          w     = w + D[a + 4 + 2 * j];
        } else {
          show_val(e, D[a + 5 + 2 * j], w + D[a + 4 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Run
// ===

static void io_step(Env e, IoWork* a) {
  for (;;) {
    u64  ap  = task_node(e, FID_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(FID_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return;
    }
    Term fs[256];
    u32  n = cid_arity(c);
    spare_free(e, cls_fit(n), ctr_take(e, req, n, fs));
    if (c == CID_HALT) {
      io_errs(e, fs[1]);
      exit((int)(u32)fs[0]);
    }
    if (io_eff_rows[c] == NULL) {
      err_fail("an alien request");
    }
    a->cont = fs[n - 1];
    Term x  = io_eff_rows[c](e, fs, a);
    if (x == IO_PARK) {
      return;
    }
    a->item = x;
  }
}

OUTLINE void io_loop(u64* H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return;
#endif
  io_spawn(m);
  u64 look = 0;
  for (u32 n = 0;; n += 1) {
    if (io_runs == NULL) {
      if (io_live == 0) {
        return;
      }
      if (io_park == NULL && io_busy == 0) {
        io_sync();
        err_fail("deadlock: every computation waits on a channel");
      }
      io_wait(e, true);
      continue;
    }
    // A busy loop still checks due timers, and fds periodically.
    if ((n & 63) == 0) {
      if (io_busy != 0) {
        io_take(e);
      }
      if (io_park != NULL) {
        u64 now = io_tick();
        if (now >= look || io_park->next->time - 1 < now) {
          look = now + 10000000;
          io_wait(e, false);
        }
      }
    }
    io_step(e, io_pop(&io_runs));
  }
}

// Requests
// ========

// IO
// ==

Term io_args_run(Env e, Term* f, IoWork* w) {
  Term xs = term_pak(CID_NIL, 0);
  for (int i = io_argc; i > 0; i -= 1) {
    const char* a = io_argv[i - 1];
    xs = io_node(e, CID_CON, io_str(e, a, strlen(a)), xs);
  }
  return xs;
}

static void __attribute__((constructor)) io_args_use(void) {
  io_eff(CID_IO_ARGS, io_args_run);
}
// IO
// ==

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_out(stdout, text, n);
  io_out(stdout, "\n", 1);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run);
}
// Linux host effects. Compiler policy and expected asset identities stay in Bend.
// read/path: Result<U32 & String, String>; publish: Result<U32 & String, Unit>.
// io_cstr consumes arguments; only the IO loop touches Bend values. Helpers own
// malloc buffers until pack. Read rejects invalid UTF-8 so io_str is lossless.
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/random.h>
#include <sys/stat.h>
#include <unistd.h>

typedef struct {
  char *path, *hash, *data;
  uint64_t size;
  uint32_t limit;
  const char *error;
} NativeHostWork;

static uint32_t nh_rotr(uint32_t x, unsigned n) {
  return (x >> n) | (x << (32 - n));
}

static void nh_sha_block(uint32_t h[8], const unsigned char *p) {
  static const uint32_t k[64] = {
    0x428a2f98,0x71374491,0xb5c0fbcf,0xe9b5dba5,0x3956c25b,0x59f111f1,0x923f82a4,0xab1c5ed5,
    0xd807aa98,0x12835b01,0x243185be,0x550c7dc3,0x72be5d74,0x80deb1fe,0x9bdc06a7,0xc19bf174,
    0xe49b69c1,0xefbe4786,0x0fc19dc6,0x240ca1cc,0x2de92c6f,0x4a7484aa,0x5cb0a9dc,0x76f988da,
    0x983e5152,0xa831c66d,0xb00327c8,0xbf597fc7,0xc6e00bf3,0xd5a79147,0x06ca6351,0x14292967,
    0x27b70a85,0x2e1b2138,0x4d2c6dfc,0x53380d13,0x650a7354,0x766a0abb,0x81c2c92e,0x92722c85,
    0xa2bfe8a1,0xa81a664b,0xc24b8b70,0xc76c51a3,0xd192e819,0xd6990624,0xf40e3585,0x106aa070,
    0x19a4c116,0x1e376c08,0x2748774c,0x34b0bcb5,0x391c0cb3,0x4ed8aa4a,0x5b9cca4f,0x682e6ff3,
    0x748f82ee,0x78a5636f,0x84c87814,0x8cc70208,0x90befffa,0xa4506ceb,0xbef9a3f7,0xc67178f2
  };
  uint32_t s[64];
  for (unsigned i = 0; i < 16; ++i)
    s[i] = (uint32_t)p[4*i]<<24 | (uint32_t)p[4*i+1]<<16 |
           (uint32_t)p[4*i+2]<<8 | p[4*i+3];
  for (unsigned i = 16; i < 64; ++i) {
    uint32_t x = s[i-15], y = s[i-2];
    s[i] = s[i-16] + (nh_rotr(x,7)^nh_rotr(x,18)^(x>>3)) + s[i-7] +
           (nh_rotr(y,17)^nh_rotr(y,19)^(y>>10));
  }
  uint32_t a=h[0],b=h[1],c=h[2],d=h[3],e=h[4],f=h[5],g=h[6],v=h[7];
  for (unsigned i = 0; i < 64; ++i) {
    uint32_t t = v + (nh_rotr(e,6)^nh_rotr(e,11)^nh_rotr(e,25)) +
                 ((e&f)^(~e&g)) + k[i] + s[i];
    uint32_t u = (nh_rotr(a,2)^nh_rotr(a,13)^nh_rotr(a,22)) + ((a&b)^(a&c)^(b&c));
    v=g; g=f; f=e; e=d+t; d=c; c=b; b=a; a=t+u;
  }
  h[0]+=a; h[1]+=b; h[2]+=c; h[3]+=d; h[4]+=e; h[5]+=f; h[6]+=g; h[7]+=v;
}

static void nh_sha256(const char *data, size_t size, char out[65]) {
  uint32_t h[8] = {0x6a09e667,0xbb67ae85,0x3c6ef372,0xa54ff53a,
                   0x510e527f,0x9b05688c,0x1f83d9ab,0x5be0cd19};
  size_t full = size & ~(size_t)63, rest = size - full;
  for (size_t i = 0; i < full; i += 64) nh_sha_block(h, (const unsigned char *)data+i);
  unsigned char tail[128] = {0};
  memcpy(tail, data+full, rest); tail[rest] = 0x80;
  size_t width = rest < 56 ? 64 : 128;
  uint64_t bits = (uint64_t)size * 8;
  for (unsigned i = 0; i < 8; ++i) tail[width-1-i] = (unsigned char)(bits >> (8*i));
  nh_sha_block(h, tail);
  if (width == 128) nh_sha_block(h, tail+64);
  static const char hex[] = "0123456789abcdef";
  for (unsigned i = 0; i < 64; ++i) out[i] = hex[(h[i/8] >> (28-4*(i%8))) & 15];
  out[64] = 0;
}

static int nh_utf8(const char *text, size_t size) {
  unsigned need=0, lo=0x80, hi=0xbf;
  for (size_t i=0; i<size; ++i) {
    unsigned b=(unsigned char)text[i];
    if (need) { if (b<lo || b>hi) return 0; --need; lo=0x80; hi=0xbf; }
    else if (b>=0x80) {
      if (b<0xc2 || b>0xf4) return 0;
      need=b<0xe0 ? 1 : b<0xf0 ? 2 : 3;
      lo=b==0xe0 ? 0xa0 : b==0xf0 ? 0x90 : 0x80;
      hi=b==0xed ? 0x9f : b==0xf4 ? 0x8f : 0xbf;
    }
  }
  return need==0;
}

static Term nh_pack(Env e, IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  Term result=w->code ? io_fail(e,w->code,x->error) :
    io_done(e,w->word==2 ? term_pak(CID_UNIT,0) : io_str(e,x->data,x->size));
  free(x->path); free(x->hash); free(x->data); free(x);
  return result;
}

static NativeHostWork *nh_begin(Env e, Term path, IoWork *w, uint32_t op) {
  NativeHostWork *x=io_mem(calloc(1,sizeof *x));
  uint64_t size=0;
  x->path=io_cstr(e,path,&size);
  w->data=(char *)x; w->word=op; w->code=io_nul(x->path,size) ? EILSEQ : 0;
  return x;
}

static void nh_read_call(IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  int fd=open(x->path,O_RDONLY|O_CLOEXEC|O_NOFOLLOW|O_NONBLOCK);
  if (fd<0) { w->code=errno; return; }
  struct stat before,after;
  if (fstat(fd,&before)<0) w->code=errno;
  else if (!S_ISREG(before.st_mode)) w->code=EINVAL;
  else if (before.st_size<0 || (uint64_t)before.st_size>x->limit ||
           (uint64_t)before.st_size>=SIZE_MAX) w->code=EFBIG;
  if (!w->code) {
    size_t size=(size_t)before.st_size, at=0;
    x->data=malloc(size+1);
    if (!x->data) w->code=ENOMEM;
    while (!w->code && at<size) {
      size_t count=size-at; if (count>1048576) count=1048576;
      ssize_t n=read(fd,x->data+at,count);
      if (n<0 && errno==EINTR) continue;
      if (n<=0) w->code=n<0 ? errno : EIO; else at+=(size_t)n;
    }
    if (!w->code) {
      char extra; ssize_t n;
      do { n=read(fd,&extra,1); } while (n<0 && errno==EINTR);
      if (n!=0) w->code=n<0 ? errno : EFBIG;
      else if (fstat(fd,&after)<0) w->code=errno;
      else if (before.st_size!=after.st_size ||
        before.st_mtim.tv_sec!=after.st_mtim.tv_sec || before.st_mtim.tv_nsec!=after.st_mtim.tv_nsec ||
        before.st_ctim.tv_sec!=after.st_ctim.tv_sec || before.st_ctim.tv_nsec!=after.st_ctim.tv_nsec) w->code=ESTALE;
      x->size=size; x->data[size]=0;
    }
  }
  if (close(fd)<0 && !w->code) w->code=errno; // Do not retry close on Linux.
  if (!w->code && x->hash[0]) {
    char actual[65]; nh_sha256(x->data,(size_t)x->size,actual);
    if (memcmp(actual,x->hash,64)) { w->code=EBADMSG; x->error="SHA-256 mismatch"; }
  }
  if (!w->code && !nh_utf8(x->data,(size_t)x->size)) w->code=EILSEQ;
}

Term native_host_read_run(Env e, Term *f, IoWork *w) {
  NativeHostWork *x=nh_begin(e,f[0],w,0);
  uint64_t n=0; x->hash=io_cstr(e,f[1],&n); x->limit=(uint32_t)f[2];
  if (n!=0 && n!=64) w->code=EINVAL;
  for (uint64_t i=0; i<n && !w->code; ++i)
    if (!((x->hash[i]>='0' && x->hash[i]<='9') || (x->hash[i]>='a' && x->hash[i]<='f'))) w->code=EINVAL;
  return w->code ? nh_pack(e,w) : io_work(w,nh_read_call,nh_pack);
}

static void nh_path_call(IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  if (x->path[0]) x->data=realpath(x->path,NULL);
  else {
    x->data=malloc(PATH_MAX+1);
    if (!x->data) { w->code=ENOMEM; return; }
    ssize_t n=readlink("/proc/self/exe",x->data,PATH_MAX);
    if (n<0) { w->code=errno; return; }
    if (n==PATH_MAX) { w->code=ENAMETOOLONG; return; }
    x->data[n]=0;
    char *slash=strrchr(x->data,'/');
    if (!slash) { w->code=EINVAL; return; }
    slash[slash==x->data ? 1 : 0]=0;
  }
  if (!x->data) { w->code=errno; return; }
  x->size=strlen(x->data);
  if (!nh_utf8(x->data,(size_t)x->size)) w->code=EILSEQ;
}

Term native_host_path_run(Env e, Term *f, IoWork *w) {
  nh_begin(e,f[0],w,1);
  return w->code ? nh_pack(e,w) : io_work(w,nh_path_call,nh_pack);
}

static void nh_publish_call(IoWork *w) {
  NativeHostWork *x=(NativeHostWork *)w->data;
  char *slash=strrchr(x->path,'/'), *name=slash ? slash+1 : x->path;
  if (!*name) { w->code=EINVAL; return; }
  const char *dir=".";
  if (slash) { *slash=0; dir=slash==x->path ? "/" : x->path; }
  int parent=open(dir,O_RDONLY|O_DIRECTORY|O_CLOEXEC);
  if (parent<0) { w->code=errno; return; }
  int fd=-1; char temp[64]={0};
  for (unsigned attempt=0; attempt<64; ++attempt) {
    uint64_t random; size_t at=0;
    while (at<sizeof random) {
      ssize_t n=getrandom((char *)&random+at,sizeof random-at,0);
      if (n<0 && errno==EINTR) continue;
      if (n<=0) { w->code=n<0 ? errno : EIO; break; } at+=(size_t)n;
    }
    if (w->code) break;
    snprintf(temp,sizeof temp,".bend-native-%ld-%016llx",(long)getpid(),(unsigned long long)random);
    if (strcmp(temp,name)==0) continue;
    fd=openat(parent,temp,O_WRONLY|O_CREAT|O_EXCL|O_CLOEXEC,0600);
    if (fd>=0) break;
    if (errno!=EEXIST) { w->code=errno; break; }
  }
  if (fd<0) { if (!w->code) w->code=EEXIST; close(parent); return; }
  struct stat made;
  int known=fstat(fd,&made)==0;
  if (!known) w->code=errno;
  for (uint64_t at=0; !w->code && at<x->size;) {
    size_t count=(size_t)(x->size-at); if (count>1048576) count=1048576;
    ssize_t n=write(fd,x->data+at,count);
    if (n<0 && errno==EINTR) continue;
    if (n<=0) w->code=n<0 ? errno : EIO; else at+=(uint64_t)n;
  }
  if (!w->code && fsync(fd)<0) w->code=errno;
  // Keep the inode, not its mutable directory entry, through writer close.
  char proc[64]; int held=-1, published=0;
  if (!w->code) {
    snprintf(proc,sizeof proc,"/proc/self/fd/%d",fd);
    held=open(proc,O_PATH|O_CLOEXEC);
    if (held<0) w->code=errno;
  }
  if (close(fd)<0 && !w->code) w->code=errno;
  if (!w->code) {
    snprintf(proc,sizeof proc,"/proc/self/fd/%d",held);
    if (linkat(AT_FDCWD,proc,parent,name,AT_SYMLINK_FOLLOW)<0) w->code=errno;
    else published=1;
  }
  if (held>=0 && close(held)<0 && !w->code) w->code=errno;
  struct stat current;
  int cleanup=0;
  if (fstatat(parent,temp,&current,AT_SYMLINK_NOFOLLOW)<0) {
    if (errno!=ENOENT) cleanup=errno;
  } else if (!known || current.st_dev!=made.st_dev || current.st_ino!=made.st_ino) cleanup=ESTALE;
  else if (unlinkat(parent,temp,0)<0) cleanup=errno;
  if (!w->code) w->code=cleanup;
  if (close(parent)<0 && !w->code) w->code=errno;
  if (published && w->code) x->error="output published; temporary cleanup failed";
}

Term native_host_publish_run(Env e, Term *f, IoWork *w) {
  NativeHostWork *x=nh_begin(e,f[0],w,2);
  x->data=io_cstr(e,f[1],&x->size);
  if (x->size>67108864) w->code=EFBIG;
  return w->code ? nh_pack(e,w) : io_work(w,nh_publish_call,nh_pack);
}

static void __attribute__((constructor)) native_host_use(void) {
  io_eff(CID_NATIVEHOST_READ,native_host_read_run);
  io_eff(CID_NATIVEHOST_PATH,native_host_path_run);
  io_eff(CID_NATIVEHOST_PUBLISH,native_host_publish_run);
}


// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv;
  io_argc = 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : "";
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--bend-help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() == NULL && !gpu_make(gpu_path())) {
        fprintf(stderr, "bend: cannot write %s\n", gpu_path());
        return 1;
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end;
      thr = strtol(v, &end, 10);
      if (thr < 1 || *end != '\0') {
        err_fail("expected a thread count of 1 or more after --threads");
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end;
      double n   = strtod(v, &end);
      u64    mul = strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (strcmp(v, "on") == 0 || (mul != 0 && n > 0)) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        err_fail("expected on, off or a size like 4GB after --gpu");
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  const char* why = gpu != 0 && BANGS != 0 ? gpu_probe() : "";
  if (gpu == 1 && BANGS != 0 && why != NULL) {
    err_fail(why);
  }
  bool dev = why == NULL;
  io_loop(corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem));
  io_sync();
  return 0;
}

#endif
