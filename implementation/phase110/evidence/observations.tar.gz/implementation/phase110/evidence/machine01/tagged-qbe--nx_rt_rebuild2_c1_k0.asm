
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403380 <nx_rt_rebuild2_c1_k0>:
  403380:	push   %r13
  403382:	mov    %rsi,%r10
  403385:	mov    %rdx,%r8
  403388:	movabs $0xffffffffff,%r9
  403392:	push   %r12
  403394:	and    %r10,%r9
  403397:	push   %rbp
  403398:	lea    0x0(,%r9,8),%rax
  4033a0:	push   %rbx
  4033a1:	mov    %rdi,%rbx
  4033a4:	sub    $0x28,%rsp
  4033a8:	mov    (%rdi),%rdi
  4033ab:	mov    0x8(%rbx),%rsi
  4033af:	lea    (%rdi,%rax,1),%rdx
  4033b3:	test   %r10,%r10
  4033b6:	js     403420 <nx_rt_rebuild2_c1_k0+0xa0>
  4033b8:	mov    (%rdx),%r12
  4033bb:	mov    0x8(%rdi,%rax,1),%rbp
  4033c0:	cmp    $0x310817f,%r9
  4033c7:	jbe    4033f8 <nx_rt_rebuild2_c1_k0+0x78>
  4033c9:	mov    %rbp,0x10(%rbx)
  4033cd:	mov    %r12,%rcx
  4033d0:	mov    $0x1,%edx
  4033d5:	movq   $0xffffffffffffffff,0x18(%rbx)
  4033dd:	movl   $0x1,0x20(%rbx)
  4033e4:	add    $0x28,%rsp
  4033e8:	pop    %rbx
  4033e9:	pop    %rbp
  4033ea:	pop    %r12
  4033ec:	pop    %r13
  4033ee:	jmpq   401fd0 <nx_construct2>
  4033f3:	nopl   0x0(%rax,%rax,1)
  4033f8:	mov    0x8(%rsi),%r9
  4033fc:	test   %r9,%r9
  4033ff:	je     4016c4 <nx_rt_rebuild2_c1_k0.cold>
  403405:	mov    (%rdi,%r9,8),%rax
  403409:	subq   $0x2,0x108(%rsi)
  403411:	mov    %rax,0x8(%rsi)
  403415:	jmp    4033c9 <nx_rt_rebuild2_c1_k0+0x49>
  403417:	nopw   0x0(%rax,%rax,1)
  403420:	mov    0x4(%rdx),%eax
  403423:	mov    (%rdx),%ecx
  403425:	shl    $0x20,%rax
  403429:	or     %rcx,%rax
  40342c:	mov    %rax,%r13
  40342f:	and    $0xffffff,%eax
  403434:	shr    $0x18,%r13
  403438:	lea    0x0(,%r13,8),%r11
  403440:	lea    (%rdi,%r11,1),%rbp
  403444:	lea    0x8(%rdi,%r11,1),%r11
  403449:	cmp    $0x1,%rax
  40344d:	jne    40170a <nx_rt_rebuild2_c1_k0.cold+0x46>
  403453:	mov    (%rdx),%eax
  403455:	mov    (%rsi),%rax
  403458:	mov    0x0(%rbp),%r12
  40345c:	mov    (%r11),%rbp
  40345f:	mov    %rax,(%rdx)
  403462:	mov    0x100(%rsi),%rax
  403469:	mov    0x3dd69(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40346f:	mov    %r9,(%rsi)
  403472:	add    $0x1,%rax
  403476:	mov    %rax,0x100(%rsi)
  40347d:	cmp    %rdx,%rax
  403480:	jae    4016f4 <nx_rt_rebuild2_c1_k0.cold+0x30>
  403486:	mov    %r13,%r9
  403489:	jmpq   4033c0 <nx_rt_rebuild2_c1_k0+0x40>

Disassembly of section .fini:
