
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403540 <nx_rt_rebuild2_c1_k0>:
  403540:	push   %r15
  403542:	push   %r14
  403544:	push   %r13
  403546:	push   %r12
  403548:	mov    %rdx,%r12
  40354b:	push   %rbp
  40354c:	mov    %rdi,%rbp
  40354f:	push   %rbx
  403550:	movabs $0xffffffffff,%rbx
  40355a:	and    %rsi,%rbx
  40355d:	lea    0x0(,%rbx,8),%rdx
  403565:	sub    $0x18,%rsp
  403569:	mov    (%rdi),%r13
  40356c:	mov    0x8(%rdi),%r15
  403570:	lea    0x0(%r13,%rdx,1),%rax
  403575:	test   %rsi,%rsi
  403578:	js     403640 <nx_rt_rebuild2_c1_k0+0x100>
  40357e:	mov    (%rax),%r14
  403581:	mov    0x8(%r13,%rdx,1),%r9
  403586:	cmp    $0x310817f,%rbx
  40358d:	jbe    403618 <nx_rt_rebuild2_c1_k0+0xd8>
  403593:	lea    0x0(%r13,%rbx,8),%r8
  403598:	mov    %r14,%rax
  40359b:	mov    %r9,0x10(%rbp)
  40359f:	shr    $0x38,%rax
  4035a3:	movq   $0xffffffffffffffff,0x18(%rbp)
  4035ab:	and    $0x7f,%eax
  4035ae:	movl   $0x1,0x20(%rbp)
  4035b5:	cmp    $0x2,%rax
  4035b9:	je     4035f8 <nx_rt_rebuild2_c1_k0+0xb8>
  4035bb:	mov    %r12,%rax
  4035be:	mov    %r14,(%r8)
  4035c1:	lea    0x8(%r13,%rbx,8),%rbp
  4035c6:	shr    $0x38,%rax
  4035ca:	and    $0x7f,%eax
  4035cd:	cmp    $0x2,%rax
  4035d1:	je     403608 <nx_rt_rebuild2_c1_k0+0xc8>
  4035d3:	movabs $0x200010000000000,%rax
  4035dd:	mov    %r12,0x0(%rbp)
  4035e1:	add    $0x18,%rsp
  4035e5:	or     %rbx,%rax
  4035e8:	pop    %rbx
  4035e9:	pop    %rbp
  4035ea:	pop    %r12
  4035ec:	pop    %r13
  4035ee:	pop    %r14
  4035f0:	pop    %r15
  4035f2:	retq   
  4035f3:	nopl   0x0(%rax,%rax,1)
  4035f8:	test   %r14,%r14
  4035fb:	js     4035bb <nx_rt_rebuild2_c1_k0+0x7b>
  4035fd:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403602:	nopw   0x0(%rax,%rax,1)
  403608:	test   %r12,%r12
  40360b:	js     4035d3 <nx_rt_rebuild2_c1_k0+0x93>
  40360d:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403612:	nopw   0x0(%rax,%rax,1)
  403618:	mov    0x8(%r15),%rbx
  40361c:	test   %rbx,%rbx
  40361f:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  403625:	lea    0x0(%r13,%rbx,8),%r8
  40362a:	mov    (%r8),%rax
  40362d:	subq   $0x2,0x108(%r15)
  403635:	mov    %rax,0x8(%r15)
  403639:	jmpq   403598 <nx_rt_rebuild2_c1_k0+0x58>
  40363e:	xchg   %ax,%ax
  403640:	mov    0x4(%rax),%edx
  403643:	mov    (%rax),%ecx
  403645:	shl    $0x20,%rdx
  403649:	or     %rcx,%rdx
  40364c:	mov    %rdx,%rcx
  40364f:	and    $0xffffff,%edx
  403655:	shr    $0x18,%rcx
  403659:	lea    0x8(,%rcx,8),%rdi
  403661:	lea    0x0(%r13,%rdi,1),%r8
  403666:	lea    -0x8(%r13,%rdi,1),%rdi
  40366b:	cmp    $0x1,%rdx
  40366f:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  403675:	mov    (%rax),%edx
  403677:	mov    (%r15),%rdx
  40367a:	mov    (%rdi),%r14
  40367d:	mov    (%r8),%r9
  403680:	mov    %rdx,(%rax)
  403683:	mov    0x100(%r15),%rax
  40368a:	mov    0x3db48(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403690:	mov    %rbx,(%r15)
  403693:	add    $0x1,%rax
  403697:	mov    %rax,0x100(%r15)
  40369e:	cmp    %rdx,%rax
  4036a1:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  4036a7:	mov    %rcx,%rbx
  4036aa:	jmpq   403586 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
