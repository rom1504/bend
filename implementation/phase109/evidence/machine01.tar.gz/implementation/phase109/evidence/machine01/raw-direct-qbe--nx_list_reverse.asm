
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401870 <nx_list_reverse>:
  401870:	endbr64 
  401874:	push   %rbp
  401875:	mov    %rsp,%rbp
  401878:	sub    $0x8,%rsp
  40187c:	push   %rbx
  40187d:	push   %r12
  40187f:	push   %r13
  401881:	mov    %rdx,%rax
  401884:	mov    %rax,%rbx
  401887:	nopw   0x0(%rax,%rax,1)
  401890:	mov    %rsi,%r13
  401893:	mov    %rdi,%r12
  401896:	callq  402210 <nx_rt_id>
  40189b:	mov    %r13,%rsi
  40189e:	mov    %r12,%rdi
  4018a1:	cmp    $0x0,%eax
  4018a4:	je     401920 <nx_list_reverse+0xb0>
  4018a6:	mov    %rsi,%r13
  4018a9:	mov    %rdi,%r12
  4018ac:	callq  402210 <nx_rt_id>
  4018b1:	mov    %r13,%rsi
  4018b4:	mov    %r12,%rdi
  4018b7:	cmp    $0x1,%eax
  4018ba:	jne    401914 <nx_list_reverse+0xa4>
  4018bc:	mov    %rdi,%r12
  4018bf:	callq  402550 <nx_rt_take2>
  4018c4:	mov    %r12,%rdi
  4018c7:	mov    $0x0,%esi
  4018cc:	mov    %rdi,%r12
  4018cf:	callq  4026e0 <nx_rt_field>
  4018d4:	mov    %r12,%rdi
  4018d7:	mov    %rax,%r13
  4018da:	mov    $0x1,%esi
  4018df:	mov    %rdi,%r12
  4018e2:	callq  4026e0 <nx_rt_field>
  4018e7:	mov    %r13,%rdx
  4018ea:	mov    %r12,%rdi
  4018ed:	mov    %rax,%rsi
  4018f0:	mov    %rbx,%rcx
  4018f3:	mov    %rsi,%r12
  4018f6:	mov    $0x1,%esi
  4018fb:	mov    %rdi,%rbx
  4018fe:	callq  4024c0 <nx_rt_build2>
  401903:	mov    %r12,%rsi
  401906:	mov    %rbx,%rdi
  401909:	mov    %rax,%rdx
  40190c:	mov    %rdx,%rbx
  40190f:	jmpq   401890 <nx_list_reverse+0x20>
  401914:	mov    $0x1,%esi
  401919:	callq  402250 <nx_rt_fail>
  40191e:	jmp    401923 <nx_list_reverse+0xb3>
  401920:	mov    %rbx,%rax
  401923:	pop    %r13
  401925:	pop    %r12
  401927:	pop    %rbx
  401928:	leaveq 
  401929:	retq   

Disassembly of section .fini:
