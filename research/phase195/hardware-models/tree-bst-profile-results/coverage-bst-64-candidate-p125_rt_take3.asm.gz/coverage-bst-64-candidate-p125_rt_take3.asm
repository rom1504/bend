000000000041de20 <p125_rt_take3>:
  41de20:	mov    rax,rsi
  41de23:	mov    r8,QWORD PTR [rip+0x108ca6]        # 526ad0 <p111_program_active>
  41de2a:	push   r12
  41de2c:	shr    rax,0x28
  41de30:	push   rbp
  41de31:	movzx  eax,ax
  41de34:	push   rbx
  41de35:	cmp    QWORD PTR [r8+0x18],rax
  41de39:	ja     41de50 <p125_rt_take3+0x30>
  41de3b:	lea    rdi,[rip+0x1521]        # 41f363 <_IO_stdin_used+0x363>
  41de42:	call   413ef0 <err_fail>
  41de47:	nop    WORD PTR [rax+rax*1+0x0]
  41de50:	mov    rcx,rdx
  41de53:	mov    rdx,QWORD PTR [r8+0x80]
  41de5a:	cmp    BYTE PTR [rdx+rax*1],0x3
  41de5e:	jne    41de3b <p125_rt_take3+0x1b>
  41de60:	mov    rax,rsi
  41de63:	shr    rax,0x38
  41de67:	and    eax,0x7f
  41de6a:	cmp    rax,0x2
  41de6e:	jne    41dfab <p125_rt_take3+0x18b>
  41de74:	mov    r9,QWORD PTR [rdi]
  41de77:	mov    rbx,rdi
  41de7a:	movabs rdi,0xffffffffff
  41de84:	and    rdi,rsi
  41de87:	test   rsi,rsi
  41de8a:	js     41df20 <p125_rt_take3+0x100>
  41de90:	lea    rsi,[r9+rdi*8]
  41de94:	xor    eax,eax
  41de96:	nop    WORD PTR cs:[rax+rax*1+0x0]
  41dea0:	mov    rdx,QWORD PTR [rsi+rax*1]
  41dea4:	mov    QWORD PTR [rcx+rax*1],rdx
  41dea8:	add    rax,0x8
  41deac:	cmp    rax,0x18
  41deb0:	jne    41dea0 <p125_rt_take3+0x80>
  41deb2:	mov    rax,QWORD PTR [r8+0x40]
  41deb6:	add    rax,0x7f
  41deba:	and    rax,0xffffffffffffff80
  41debe:	add    rax,0x3108200
  41dec4:	cmp    rax,rdi
  41dec7:	jbe    41ded8 <p125_rt_take3+0xb8>
  41dec9:	pop    rbx
  41deca:	mov    eax,0x3
  41decf:	pop    rbp
  41ded0:	pop    r12
  41ded2:	ret    
  41ded3:	nop    DWORD PTR [rax+rax*1+0x0]
  41ded8:	mov    rsi,QWORD PTR [rbx+0x8]
  41dedc:	mov    r8,QWORD PTR [rbx]
  41dedf:	mov    edx,DWORD PTR [rip+0x108c9f]        # 526b84 <KEEP_WORDS>
  41dee5:	mov    rax,QWORD PTR [rsi+0x10]
  41dee9:	mov    QWORD PTR [r8+rdi*8],rax
  41deed:	mov    rax,QWORD PTR [rsi+0x110]
  41def4:	mov    QWORD PTR [rsi+0x10],rdi
  41def8:	add    rax,0x4
  41defc:	mov    QWORD PTR [rsi+0x110],rax
  41df03:	cmp    rax,rdx
  41df06:	jae    4050fa <p125_rt_take3.cold+0x37>
  41df0c:	pop    rbx
  41df0d:	mov    eax,0x3
  41df12:	pop    rbp
  41df13:	pop    r12
  41df15:	ret    
  41df16:	nop    WORD PTR cs:[rax+rax*1+0x0]
  41df20:	lea    rbp,[r9+rdi*8]
  41df24:	mov    r11,QWORD PTR [rbx+0x8]
  41df28:	mov    r12d,DWORD PTR [rbp+0x4]
  41df2c:	mov    r10d,DWORD PTR [rbp+0x0]
  41df30:	shl    r12,0x20
  41df34:	or     r12,r10
  41df37:	and    r10d,0xffffff
  41df3e:	cmp    r10,0x1
  41df42:	je     41dfa6 <p125_rt_take3+0x186>
  41df44:	shr    r12,0x18
  41df48:	xor    eax,eax
  41df4a:	lea    r8,[r9+r12*8]
  41df4e:	xchg   ax,ax
  41df50:	mov    rdx,QWORD PTR [r8+rax*1]
  41df54:	mov    QWORD PTR [rcx+rax*1],rdx
  41df58:	add    rax,0x8
  41df5c:	cmp    rax,0x18
  41df60:	jne    41df50 <p125_rt_take3+0x130>
  41df62:	cmp    r10,0x1
  41df66:	jne    4050c3 <p125_rt_take3.cold>
  41df6c:	mov    rax,QWORD PTR [r11]
  41df6f:	mov    edx,DWORD PTR [rip+0x108c0f]        # 526b84 <KEEP_WORDS>
  41df75:	mov    QWORD PTR [rbp+0x0],rax
  41df79:	mov    rax,QWORD PTR [r11+0x100]
  41df80:	mov    QWORD PTR [r11],rdi
  41df83:	add    rax,0x1
  41df87:	mov    QWORD PTR [r11+0x100],rax
  41df8e:	cmp    rax,rdx
  41df91:	jae    4050e8 <p125_rt_take3.cold+0x25>
  41df97:	mov    r8,QWORD PTR [rip+0x108b32]        # 526ad0 <p111_program_active>
  41df9e:	mov    rdi,r12
  41dfa1:	jmp    41deb2 <p125_rt_take3+0x92>
  41dfa6:	mov    eax,DWORD PTR [rbp+0x0]
  41dfa9:	jmp    41df44 <p125_rt_take3+0x124>
  41dfab:	lea    rdi,[rip+0x1f6e]        # 41ff20 <_IO_stdin_used+0xf20>
  41dfb2:	call   413ef0 <err_fail>
  41dfb7:	nop    WORD PTR [rax+rax*1+0x0]

