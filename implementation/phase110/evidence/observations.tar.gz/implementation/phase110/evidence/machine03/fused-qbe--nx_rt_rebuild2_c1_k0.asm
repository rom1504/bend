
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004035e0 <nx_rt_rebuild2_c1_k0>:
  4035e0:	push   %r15
  4035e2:	push   %r14
  4035e4:	push   %r13
  4035e6:	push   %r12
  4035e8:	mov    %rdx,%r12
  4035eb:	push   %rbp
  4035ec:	mov    %rdi,%rbp
  4035ef:	push   %rbx
  4035f0:	movabs $0xffffffffff,%rbx
  4035fa:	and    %rsi,%rbx
  4035fd:	lea    0x0(,%rbx,8),%rdx
  403605:	sub    $0x18,%rsp
  403609:	mov    (%rdi),%r13
  40360c:	mov    0x8(%rdi),%r15
  403610:	lea    0x0(%r13,%rdx,1),%rax
  403615:	test   %rsi,%rsi
  403618:	js     4036e0 <nx_rt_rebuild2_c1_k0+0x100>
  40361e:	mov    (%rax),%r14
  403621:	mov    0x8(%r13,%rdx,1),%r9
  403626:	cmp    $0x310817f,%rbx
  40362d:	jbe    4036b8 <nx_rt_rebuild2_c1_k0+0xd8>
  403633:	lea    0x0(%r13,%rbx,8),%r8
  403638:	mov    %r14,%rax
  40363b:	mov    %r9,0x10(%rbp)
  40363f:	shr    $0x38,%rax
  403643:	movq   $0xffffffffffffffff,0x18(%rbp)
  40364b:	and    $0x7f,%eax
  40364e:	movl   $0x1,0x20(%rbp)
  403655:	cmp    $0x2,%rax
  403659:	je     403698 <nx_rt_rebuild2_c1_k0+0xb8>
  40365b:	mov    %r12,%rax
  40365e:	mov    %r14,(%r8)
  403661:	lea    0x8(%r13,%rbx,8),%rbp
  403666:	shr    $0x38,%rax
  40366a:	and    $0x7f,%eax
  40366d:	cmp    $0x2,%rax
  403671:	je     4036a8 <nx_rt_rebuild2_c1_k0+0xc8>
  403673:	movabs $0x200010000000000,%rax
  40367d:	mov    %r12,0x0(%rbp)
  403681:	add    $0x18,%rsp
  403685:	or     %rbx,%rax
  403688:	pop    %rbx
  403689:	pop    %rbp
  40368a:	pop    %r12
  40368c:	pop    %r13
  40368e:	pop    %r14
  403690:	pop    %r15
  403692:	retq   
  403693:	nopl   0x0(%rax,%rax,1)
  403698:	test   %r14,%r14
  40369b:	js     40365b <nx_rt_rebuild2_c1_k0+0x7b>
  40369d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  4036a2:	nopw   0x0(%rax,%rax,1)
  4036a8:	test   %r12,%r12
  4036ab:	js     403673 <nx_rt_rebuild2_c1_k0+0x93>
  4036ad:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  4036b2:	nopw   0x0(%rax,%rax,1)
  4036b8:	mov    0x8(%r15),%rbx
  4036bc:	test   %rbx,%rbx
  4036bf:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  4036c5:	lea    0x0(%r13,%rbx,8),%r8
  4036ca:	mov    (%r8),%rax
  4036cd:	subq   $0x2,0x108(%r15)
  4036d5:	mov    %rax,0x8(%r15)
  4036d9:	jmpq   403638 <nx_rt_rebuild2_c1_k0+0x58>
  4036de:	xchg   %ax,%ax
  4036e0:	mov    0x4(%rax),%edx
  4036e3:	mov    (%rax),%ecx
  4036e5:	shl    $0x20,%rdx
  4036e9:	or     %rcx,%rdx
  4036ec:	mov    %rdx,%rcx
  4036ef:	and    $0xffffff,%edx
  4036f5:	shr    $0x18,%rcx
  4036f9:	lea    0x8(,%rcx,8),%rdi
  403701:	lea    0x0(%r13,%rdi,1),%r8
  403706:	lea    -0x8(%r13,%rdi,1),%rdi
  40370b:	cmp    $0x1,%rdx
  40370f:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  403715:	mov    (%rax),%edx
  403717:	mov    (%r15),%rdx
  40371a:	mov    (%rdi),%r14
  40371d:	mov    (%r8),%r9
  403720:	mov    %rdx,(%rax)
  403723:	mov    0x100(%r15),%rax
  40372a:	mov    0x3daa8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403730:	mov    %rbx,(%r15)
  403733:	add    $0x1,%rax
  403737:	mov    %rax,0x100(%r15)
  40373e:	cmp    %rdx,%rax
  403741:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  403747:	mov    %rcx,%rbx
  40374a:	jmpq   403626 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
