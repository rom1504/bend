0000000000418080 <p125_rt_take2>:
  418080:	push   r12
  418082:	mov    rax,rdx
  418085:	mov    rdx,rsi
  418088:	push   rbx
  418089:	shr    rdx,0x28
  41808d:	movzx  edx,dx
  418090:	sub    rsp,0x8
  418094:	mov    rcx,QWORD PTR [rip+0x108a35]        # 520ad0 <p111_program_active>
  41809b:	cmp    QWORD PTR [rcx+0x18],rdx
  41809f:	ja     4180b0 <p125_rt_take2+0x30>
  4180a1:	lea    rdi,[rip+0x12b7]        # 41935f <_IO_stdin_used+0x35f>
  4180a8:	call   40e3b0 <err_fail>
  4180ad:	nop    DWORD PTR [rax]
  4180b0:	mov    rbx,rdi
  4180b3:	mov    rdi,QWORD PTR [rcx+0x80]
  4180ba:	cmp    BYTE PTR [rdi+rdx*1],0x2
  4180be:	jne    4180a1 <p125_rt_take2+0x21>
  4180c0:	mov    rdx,rsi
  4180c3:	shr    rdx,0x38
  4180c7:	and    edx,0x7f
  4180ca:	cmp    rdx,0x2
  4180ce:	jne    4181fb <p125_rt_take2+0x17b>
  4180d4:	movabs rdx,0xffffffffff
  4180de:	mov    rdi,QWORD PTR [rbx]
  4180e1:	and    rdx,rsi
  4180e4:	lea    r9,[rdx*8+0x0]
  4180ec:	lea    r8,[rdi+r9*1]
  4180f0:	test   rsi,rsi
  4180f3:	js     418178 <p125_rt_take2+0xf8>
  4180f9:	mov    rsi,QWORD PTR [r8]
  4180fc:	mov    QWORD PTR [rax],rsi
  4180ff:	mov    rsi,QWORD PTR [rdi+r9*1+0x8]
  418104:	mov    QWORD PTR [rax+0x8],rsi
  418108:	mov    rax,QWORD PTR [rcx+0x40]
  41810c:	add    rax,0x7f
  418110:	and    rax,0xffffffffffffff80
  418114:	add    rax,0x3108200
  41811a:	cmp    rax,rdx
  41811d:	jbe    418130 <p125_rt_take2+0xb0>
  41811f:	add    rsp,0x8
  418123:	mov    eax,0x2
  418128:	pop    rbx
  418129:	pop    r12
  41812b:	ret    
  41812c:	nop    DWORD PTR [rax+0x0]
  418130:	mov    rsi,QWORD PTR [rbx+0x8]
  418134:	mov    rdi,QWORD PTR [rbx]
  418137:	mov    rax,QWORD PTR [rsi+0x8]
  41813b:	mov    QWORD PTR [rdi+rdx*8],rax
  41813f:	mov    rax,QWORD PTR [rsi+0x108]
  418146:	mov    QWORD PTR [rsi+0x8],rdx
  41814a:	mov    edx,DWORD PTR [rip+0x108a34]        # 520b84 <KEEP_WORDS>
  418150:	add    rax,0x2
  418154:	mov    QWORD PTR [rsi+0x108],rax
  41815b:	cmp    rax,rdx
  41815e:	jae    405077 <p125_rt_take2.cold+0x2f>
  418164:	add    rsp,0x8
  418168:	mov    eax,0x2
  41816d:	pop    rbx
  41816e:	pop    r12
  418170:	ret    
  418171:	nop    DWORD PTR [rax+0x0]
  418178:	mov    r9,QWORD PTR [rbx+0x8]
  41817c:	mov    ecx,DWORD PTR [r8+0x4]
  418180:	mov    r10d,DWORD PTR [r8]
  418183:	shl    rcx,0x20
  418187:	or     rcx,r10
  41818a:	mov    r12,rcx
  41818d:	and    ecx,0xffffff
  418193:	shr    r12,0x18
  418197:	lea    r10,[r12*8+0x0]
  41819f:	lea    r11,[rdi+r10*1]
  4181a3:	lea    r10,[r10+rdi*1+0x8]
  4181a8:	cmp    rcx,0x1
  4181ac:	jne    405048 <p125_rt_take2.cold>
  4181b2:	mov    ecx,DWORD PTR [r8]
  4181b5:	mov    rcx,QWORD PTR [r11]
  4181b8:	mov    QWORD PTR [rax],rcx
  4181bb:	mov    rcx,QWORD PTR [r10]
  4181be:	mov    QWORD PTR [rax+0x8],rcx
  4181c2:	mov    rax,QWORD PTR [r9]
  4181c5:	mov    QWORD PTR [r8],rax
  4181c8:	mov    rax,QWORD PTR [r9+0x100]
  4181cf:	mov    QWORD PTR [r9],rdx
  4181d2:	mov    edx,DWORD PTR [rip+0x1089ac]        # 520b84 <KEEP_WORDS>
  4181d8:	add    rax,0x1
  4181dc:	mov    QWORD PTR [r9+0x100],rax
  4181e3:	cmp    rax,rdx
  4181e6:	jae    405086 <p125_rt_take2.cold+0x3e>
  4181ec:	mov    rcx,QWORD PTR [rip+0x1088dd]        # 520ad0 <p111_program_active>
  4181f3:	mov    rdx,r12
  4181f6:	jmp    418108 <p125_rt_take2+0x88>
  4181fb:	lea    rdi,[rip+0x1d1e]        # 419f20 <_IO_stdin_used+0xf20>
  418202:	call   40e3b0 <err_fail>
  418207:	nop    WORD PTR [rax+rax*1+0x0]

