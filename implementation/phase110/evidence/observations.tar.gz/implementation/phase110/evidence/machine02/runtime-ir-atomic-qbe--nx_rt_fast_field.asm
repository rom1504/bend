
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004034d0 <nx_rt_fast_field>:
  4034d0:	mov    %esi,%ecx
  4034d2:	mov    $0xfffffffe,%eax
  4034d7:	rol    %cl,%eax
  4034d9:	add    $0x2,%rcx
  4034dd:	and    %eax,0x20(%rdi)
  4034e0:	mov    (%rdi,%rcx,8),%rax
  4034e4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  4034ec:	retq   

Disassembly of section .fini:
