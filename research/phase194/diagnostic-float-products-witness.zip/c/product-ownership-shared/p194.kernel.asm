    f400:	push   %rbp
    f401:	push   %r15
    f403:	push   %r14
    f405:	push   %r13
    f407:	push   %r12
    f409:	push   %rbx
    f40a:	push   %rax
    f40b:	mov    %rdx,(%rsp)
    f40f:	test   %rcx,%rcx
    f412:	je     f711 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x311>
    f418:	mov    %r8d,%r10d
    f41b:	mov    %rcx,%rbx
    f41e:	movabs $0xffffffffff,%r12
    f428:	movabs $0x200a40000000000,%r13
    f432:	movabs $0xffff0000000000,%rbp
    f43c:	movabs $0xa40000000000,%r14
    f446:	jmp    f485 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x85>
    f448:	shl    $0x20,%rcx
    f44c:	or     %rax,%rcx
    f44f:	shr    $0x18,%rcx
    f453:	mov    0x8(%rdi,%rcx,8),%rax
    f458:	mov    %r15,%rdx
    f45b:	mov    $0x2,%r8d
    f461:	callq  114b2 <span_fade>
    f466:	nopw   %cs:0x0(%rax,%rax,1)
    f470:	dec    %rbx
    f473:	xor    $0x7,%eax
    f476:	add    %eax,%r9d
    f479:	inc    %r10d
    f47c:	test   %rbx,%rbx
    f47f:	je     f711 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x311>
    f485:	mov    0x8(%rsi),%rax
    f489:	test   %rax,%rax
    f48c:	je     f5f2 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x1f2>
    f492:	mov    (%rdi,%rax,8),%rcx
    f496:	mov    %rcx,0x8(%rsi)
    f49a:	addq   $0xfffffffffffffffe,0x108(%rsi)
    f4a2:	mov    %r9d,%ecx
    f4a5:	add    %r10d,%r9d
    f4a8:	mov    %rcx,(%rdi,%rax,8)
    f4ac:	mov    %r9,0x8(%rdi,%rax,8)
    f4b1:	mov    %rax,%r15
    f4b4:	or     %r13,%r15
    f4b7:	test   %rax,%rax
    f4ba:	js     f4e0 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0xe0>
    f4bc:	lea    -0x7f(%r12),%rcx
    f4c1:	and    %rcx,%rax
    f4c4:	cmp    $0x3108180,%rax
    f4ca:	jb     f4fb <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0xfb>
    f4cc:	mov    %r15,%rdx
    f4cf:	mov    $0x2,%ecx
    f4d4:	callq  1184e <rfc_wrap>
    f4d9:	mov    %rax,%r15
    f4dc:	jmp    f4fb <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0xfb>
    f4de:	xchg   %ax,%ax
    f4e0:	and    %r12,%rax
    f4e3:	mov    $0x1,%ecx
    f4e8:	lock xadd %ecx,(%rdi,%rax,8)
    f4ed:	not    %ecx
    f4ef:	test   $0xfffffe,%ecx
    f4f5:	je     f768 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x368>
    f4fb:	mov    %r15,%rax
    f4fe:	and    %rbp,%rax
    f501:	cmp    %r14,%rax
    f504:	jne    f72f <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x32f>
    f50a:	mov    %r15,%rdx
    f50d:	and    %r12,%rdx
    f510:	test   %r15,%r15
    f513:	js     f530 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x130>
    f515:	mov    (%rdi,%rdx,8),%rax
    f519:	mov    %rdx,%rcx
    f51c:	cmp    $0x3108180,%rcx
    f523:	jae    f59c <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x19c>
    f525:	jmpq   f5cc <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x1cc>
    f52a:	nopw   0x0(%rax,%rax,1)
    f530:	mov    0x4(%rdi,%rdx,8),%ecx
    f534:	mov    (%rdi,%rdx,8),%eax
    f537:	mov    %eax,%r8d
    f53a:	and    $0xffffff,%r8d
    f541:	cmp    $0x1,%r8d
    f545:	jne    f60d <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x20d>
    f54b:	mov    (%rdi,%rdx,8),%r8d
    f54f:	shl    $0x20,%rcx
    f553:	or     %rax,%rcx
    f556:	shr    $0x18,%rcx
    f55a:	mov    (%rdi,%rcx,8),%rax
    f55e:	mov    (%rsi),%r8
    f561:	mov    %r8,(%rdi,%rdx,8)
    f565:	mov    %rdx,(%rsi)
    f568:	mov    0x100(%rsi),%rdx
    f56f:	inc    %rdx
    f572:	mov    %rdx,0x100(%rsi)
    f579:	cmpb   $0x1,0x105c90(%rip)        # 115210 <KEEP_WORDS>
    f580:	jne    f6f8 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x2f8>
    f586:	cmp    $0x8000,%rdx
    f58d:	jae    f6f8 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x2f8>
    f593:	cmp    $0x3108180,%rcx
    f59a:	jb     f5cc <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x1cc>
    f59c:	mov    0x8(%rsi),%rdx
    f5a0:	mov    %rdx,(%rdi,%rcx,8)
    f5a4:	mov    %rcx,0x8(%rsi)
    f5a8:	mov    0x108(%rsi),%rcx
    f5af:	add    $0x2,%rcx
    f5b3:	mov    %rcx,0x108(%rsi)
    f5ba:	cmpb   $0x1,0x105c4f(%rip)        # 115210 <KEEP_WORDS>
    f5c1:	jne    f601 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x201>
    f5c3:	cmp    $0x8000,%rcx
    f5ca:	jae    f601 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x201>
    f5cc:	lea    (%rax,%rax,2),%r9
    f5d0:	test   %r15,%r15
    f5d3:	js     f630 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x230>
    f5d5:	and    %r12,%r15
    f5d8:	mov    0x8(%rdi,%r15,8),%rax
    f5dd:	mov    %r15,%rcx
    f5e0:	cmp    $0x3108180,%rcx
    f5e7:	jb     f470 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x70>
    f5ed:	jmpq   f69f <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x29f>
    f5f2:	mov    $0x1,%edx
    f5f7:	callq  11548 <heap_alloc_miss>
    f5fc:	jmpq   f4a2 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0xa2>
    f601:	mov    $0x1,%edx
    f606:	callq  11421 <heap_hand>
    f60b:	jmp    f5cc <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x1cc>
    f60d:	shl    $0x20,%rcx
    f611:	or     %rax,%rcx
    f614:	shr    $0x18,%rcx
    f618:	mov    (%rdi,%rcx,8),%rax
    f61c:	mov    %r15,%rdx
    f61f:	mov    $0x2,%r8d
    f625:	callq  114b2 <span_fade>
    f62a:	lea    (%rax,%rax,2),%r9
    f62e:	xchg   %ax,%ax
    f630:	mov    %r15,%rdx
    f633:	and    %r12,%rdx
    f636:	mov    0x4(%rdi,%rdx,8),%ecx
    f63a:	mov    (%rdi,%rdx,8),%eax
    f63d:	mov    %eax,%r8d
    f640:	and    $0xffffff,%r8d
    f647:	cmp    $0x1,%r8d
    f64b:	jne    f448 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x48>
    f651:	mov    (%rdi,%rdx,8),%r8d
    f655:	shl    $0x20,%rcx
    f659:	or     %rax,%rcx
    f65c:	shr    $0x18,%rcx
    f660:	mov    0x8(%rdi,%rcx,8),%rax
    f665:	mov    (%rsi),%r8
    f668:	mov    %r8,(%rdi,%rdx,8)
    f66c:	mov    %rdx,(%rsi)
    f66f:	mov    0x100(%rsi),%rdx
    f676:	inc    %rdx
    f679:	mov    %rdx,0x100(%rsi)
    f680:	cmpb   $0x1,0x105b89(%rip)        # 115210 <KEEP_WORDS>
    f687:	jne    f6e2 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x2e2>
    f689:	cmp    $0x8000,%rdx
    f690:	jae    f6e2 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x2e2>
    f692:	cmp    $0x3108180,%rcx
    f699:	jb     f470 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x70>
    f69f:	mov    0x8(%rsi),%rdx
    f6a3:	mov    %rdx,(%rdi,%rcx,8)
    f6a7:	mov    %rcx,0x8(%rsi)
    f6ab:	mov    0x108(%rsi),%rcx
    f6b2:	add    $0x2,%rcx
    f6b6:	mov    %rcx,0x108(%rsi)
    f6bd:	cmpb   $0x1,0x105b4c(%rip)        # 115210 <KEEP_WORDS>
    f6c4:	jne    f6d3 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x2d3>
    f6c6:	cmp    $0x8000,%rcx
    f6cd:	jb     f470 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x70>
    f6d3:	mov    $0x1,%edx
    f6d8:	callq  11421 <heap_hand>
    f6dd:	jmpq   f470 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x70>
    f6e2:	xor    %edx,%edx
    f6e4:	callq  11421 <heap_hand>
    f6e9:	cmp    $0x3108180,%rcx
    f6f0:	jb     f470 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x70>
    f6f6:	jmp    f69f <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x29f>
    f6f8:	xor    %edx,%edx
    f6fa:	callq  11421 <heap_hand>
    f6ff:	cmp    $0x3108180,%rcx
    f706:	jae    f59c <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x19c>
    f70c:	jmpq   f5cc <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x1cc>
    f711:	mov    %r9d,%eax
    f714:	mov    (%rsp),%rcx
    f718:	mov    %rax,(%rcx)
    f71b:	mov    $0x1,%eax
    f720:	add    $0x8,%rsp
    f724:	pop    %rbx
    f725:	pop    %r12
    f727:	pop    %r13
    f729:	pop    %r14
    f72b:	pop    %r15
    f72d:	pop    %rbp
    f72e:	retq   
    f72f:	cmp    $0xffffffffffffffff,%r15
    f733:	je     f75c <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x35c>
    f735:	movabs $0x7e00000000000000,%rax
    f73f:	and    %r15,%rax
    f742:	je     f75c <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x35c>
    f744:	add    $0xffffffffffffff81,%r12
    f748:	and    %r15,%r12
    f74b:	cmp    $0x3108180,%r12
    f752:	jb     f75c <NF_FID_112_49_57_52_46_107_101_114_110_101_108_+0x35c>
    f754:	mov    %r15,%rdx
    f757:	callq  6ac0 <term_drop>
    f75c:	lea    -0xd253(%rip),%rdi        # 2510 <FID_RESW_T+0x310>
    f763:	callq  113c0 <err_fail>
    f768:	lea    -0xcc96(%rip),%rdi        # 2ad9 <FID_RESW_T+0x8d9>
    f76f:	callq  113c0 <err_fail>
    f774:	data16 data16 nopw %cs:0x0(%rax,%rax,1)
