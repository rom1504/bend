    9970:	test   %rsi,%rsi
    9973:	je     99de <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x6e>
    9975:	test   $0x1,%sil
    9979:	jne    9986 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x16>
    997b:	mov    %rsi,%rax
    997e:	cmp    $0x1,%rsi
    9982:	jne    99b0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x40>
    9984:	jmp    99de <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x6e>
    9986:	lea    -0x1(%rsi),%rax
    998a:	lea    0x1(%rdx),%edi
    998d:	xor    %ecx,%edx
    998f:	lea    (%rcx,%rcx,2),%r8d
    9993:	inc    %r8d
    9996:	and    $0x7,%ecx
    9999:	cmp    $0x3,%ecx
    999c:	cmovb  %r8,%rdx
    99a0:	mov    %edx,%ecx
    99a2:	mov    %edi,%edx
    99a4:	cmp    $0x1,%rsi
    99a8:	je     99de <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x6e>
    99aa:	nopw   0x0(%rax,%rax,1)
    99b0:	mov    %edx,%esi
    99b2:	xor    %ecx,%esi
    99b4:	lea    (%rcx,%rcx,2),%edi
    99b7:	inc    %edi
    99b9:	and    $0x7,%ecx
    99bc:	cmp    $0x3,%ecx
    99bf:	cmovae %esi,%edi
    99c2:	lea    0x1(%rdx),%esi
    99c5:	xor    %edi,%esi
    99c7:	lea    (%rdi,%rdi,2),%ecx
    99ca:	inc    %ecx
    99cc:	and    $0x7,%edi
    99cf:	cmp    $0x3,%edi
    99d2:	cmovae %esi,%ecx
    99d5:	add    $0x2,%edx
    99d8:	add    $0xfffffffffffffffe,%rax
    99dc:	jne    99b0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x40>
    99de:	mov    %ecx,%esi
    99e0:	mov    -0x8(%r14),%eax
    99e4:	add    $0xfffffffffffffff8,%r14
    99e8:	lea    0x9391(%rip),%rcx        # 12d80 <wl_tab>
    99ef:	mov    (%rcx,%rax,8),%rax
    99f3:	mov    $0x1,%edi
    99f8:	jmpq   *%rax
    99fa:	nopw   0x0(%rax,%rax,1)
