00000000004085e0 <p112w_FID_105_110_111_114_100_101_114_>:
  4085e0:	endbr64 
  4085e4:	push   rbp
  4085e5:	mov    rbp,rsp
  4085e8:	sub    rsp,0x800
  4085ef:	mov    ecx,0x0
  4085f4:	lea    rdx,[rbp-0x800]
  4085fb:	mov    esi,0x45
  408600:	call   4126f0 <p111_rt_closure>
  408605:	mov    QWORD PTR [rbp-0x800],rax
  40860c:	leave  
  40860d:	ret    
  40860e:	xchg   ax,ax

