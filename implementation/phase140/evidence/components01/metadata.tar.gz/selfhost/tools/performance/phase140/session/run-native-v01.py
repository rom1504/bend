"""Bounded native A/B session supervisor; transports bytes, never compiler semantics.

Run under the shared guard. Each output directory is fresh; producer, inputs and
runtime are pinned before launch. Experimental only: does not select a compiler.
"""
import argparse, hashlib, importlib.util, json, os, re, subprocess, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[5]
def pin(p):
 p=Path(p).resolve();h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1<<20):h.update(b)
 return dict(file=str(p),bytes=p.stat().st_size,sha256=h.hexdigest())
def require(ok,msg):
 if not ok:raise ValueError(msg)
def main():
 ap=argparse.ArgumentParser(description=__doc__)
 for x in ['image','a','b','out']:ap.add_argument('--'+x,type=Path,required=True)
 ap.add_argument('--hint',type=int,required=True);ap.add_argument('--owner',required=True)
 ap.add_argument('--mode',choices=['warm','cold'],default='warm');ap.add_argument('--seconds',type=int,default=1200)
 ap.add_argument('--expected-a',type=Path);ap.add_argument('--expected-b',type=Path)
 args=ap.parse_args();out=args.out.resolve()
 require(not out.exists() and out.is_relative_to(ROOT/'selfhost/build/phase140'),'Fresh Phase140 output required')
 selection=ROOT/'implementation/phase137/candidate.json';sel=json.loads(selection.read_text());require(sel['nativeQualified'],'Qualified seed context required')
 spec=importlib.util.spec_from_file_location('p130request',ROOT/'selfhost/tools/performance/phase130/native-request.py');n=importlib.util.module_from_spec(spec);spec.loader.exec_module(n)
 carrier,base,pins=n.carrier_inputs(Path(sel['preferredCarrierReceipt']['file']))
 inputs=[pin(__file__),pin(selection),pin(args.image),pin(args.a),pin(args.b),sel['runtime'],*pins]
 for p in [args.expected_a,args.expected_b]:
  if p:inputs.append(pin(p))
 require(args.hint>=0 and args.hint<=2**32-1,'Bounded edit offset required')
 require(not any(k in os.environ for k in ('LD_PRELOAD','BEND_SAMPLE_OUT','BEND_SAMPLE_CONTEXT_OUT','BEND_PROFILE_EVENTS_OUT','BEND_PROFILE_COUNTERS')),'No ambient profiling')
 out.mkdir(parents=True);(out/'method.py').write_bytes(Path(__file__).read_bytes())
 command=[str(args.image.resolve()),'--threads','1','--gpu','off','--','phase140-session',str(args.a.resolve()),str(args.b.resolve()),base['file'],carrier['carrier']['file'],carrier['stamp'],str(out/'a.frames'),str(out/'b.frames'),args.mode,str(args.hint),args.owner]
 report=dict(kind='phase140-native-session',complete=False,experimental=True,selected=False,inputs=inputs,command=command,mode=args.mode,sourceA=pin(args.a),sourceB=pin(args.b),logicalSourcePath=str(args.a.resolve()),timingScope='Process wall/CPU includes Base/source IO, A acquisition, B request, both closed output frames and teardown. Native stage clocks exclude host materialization and machine build, reported separately.',scope='No native qualification or installed selection change. In-process typed caches; source/runtime fixed. A and B use the same logical source path, actual bytes pinned separately.')
 def save():(out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
 save();start=time.monotonic()
 try:
  with (out/'stdout.log').open('xb') as so,(out/'stderr.log').open('xb') as se:
   child=subprocess.Popen(command,cwd=ROOT,stdout=so,stderr=se)
   try:child.wait(timeout=args.seconds)
   except subprocess.TimeoutExpired:
    child.kill();child.wait();raise
  report.update(nativeSeconds=time.monotonic()-start,exitCode=child.returncode,stdout=pin(out/'stdout.log'),stderr=pin(out/'stderr.log'))
  require(child.returncode==0,'Native compiler failed: '+str(child.returncode));require((out/'stderr.log').stat().st_size==0,'Unexpected native diagnostics')
  report['frames']=[pin(out/'a.frames'),pin(out/'b.frames')]
  report['nativeCompleted']=True
  # A separate strict decoder authenticates prior payloads and writes current
  # whole QBE. Its integration is versioned separately from this native clock.
  report['complete']=True
 except BaseException as e:report['error']=repr(e)
 finally:
  report['totalSeconds']=time.monotonic()-start
  report['changedInputs']=[p['file'] for p in inputs if pin(p['file'])!=p]
  if report['changedInputs']:report['complete']=False
  save()
 print(json.dumps({k:report.get(k) for k in ['complete','nativeSeconds','error']}))
 return 0 if report['complete'] else 1
if __name__=='__main__':sys.exit(main())
