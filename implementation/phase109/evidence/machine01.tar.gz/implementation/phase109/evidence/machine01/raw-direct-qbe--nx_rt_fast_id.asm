
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402750 <nx_rt_fast_id>:
  402750:	shr    $0x28,%rsi
  402754:	movzwl %si,%eax
  402757:	retq   

Disassembly of section .fini:
