
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e70 <nx_string_reverse>:
  401e70:	endbr64 
  401e74:	push   %rbp
  401e75:	mov    %rsp,%rbp
  401e78:	push   %rbx
  401e79:	push   %r12
  401e7b:	mov    %rdx,%rax
  401e7e:	mov    %rax,%rdx
  401e81:	data16 nopw %cs:0x0(%rax,%rax,1)
  401e8c:	nopl   0x0(%rax)
  401e90:	mov    %rsi,%rax
  401e93:	shr    $0x28,%rax
  401e97:	and    $0xffff,%rax
  401e9d:	cmp    $0x2,%rax
  401ea1:	je     401edb <nx_string_reverse+0x6b>
  401ea3:	cmp    $0x3,%rax
  401ea7:	jne    401ecf <nx_string_reverse+0x5f>
  401ea9:	mov    %rdi,%rbx
  401eac:	callq  403b40 <nx_rt_rebuild2_c3_k0>
  401eb1:	mov    %rbx,%rdi
  401eb4:	mov    %rax,%r12
  401eb7:	mov    $0x0,%esi
  401ebc:	mov    %rdi,%rbx
  401ebf:	callq  402ed0 <nx_rt_fast_field>
  401ec4:	mov    %r12,%rdx
  401ec7:	mov    %rbx,%rdi
  401eca:	mov    %rax,%rsi
  401ecd:	jmp    401e90 <nx_string_reverse+0x20>
  401ecf:	mov    $0x1,%esi
  401ed4:	callq  4026d0 <nx_rt_fail>
  401ed9:	jmp    401ede <nx_string_reverse+0x6e>
  401edb:	mov    %rdx,%rax
  401ede:	pop    %r12
  401ee0:	pop    %rbx
  401ee1:	leaveq 
  401ee2:	retq   

Disassembly of section .fini:
