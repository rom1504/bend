
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404080 <nx_rt_pair_take2>:
  404080:	movabs $0xffffffffff,%rax
  40408a:	push   %r15
  40408c:	and    %rsi,%rax
  40408f:	push   %r14
  404091:	push   %r13
  404093:	lea    0x0(,%rax,8),%rdx
  40409b:	push   %r12
  40409d:	push   %rbp
  40409e:	mov    (%rdi),%rbp
  4040a1:	mov    0x8(%rdi),%r14
  4040a5:	lea    0x0(%rbp,%rdx,1),%rcx
  4040aa:	test   %rsi,%rsi
  4040ad:	js     404110 <nx_rt_pair_take2+0x90>
  4040af:	mov    (%rcx),%r13
  4040b2:	mov    0x8(%rbp,%rdx,1),%r12
  4040b7:	cmp    $0x310817f,%rax
  4040bd:	ja     4040d0 <nx_rt_pair_take2+0x50>
  4040bf:	pop    %rbp
  4040c0:	mov    %r13,%rax
  4040c3:	mov    %r12,%rdx
  4040c6:	pop    %r12
  4040c8:	pop    %r13
  4040ca:	pop    %r14
  4040cc:	pop    %r15
  4040ce:	retq   
  4040cf:	nop
  4040d0:	mov    0x8(%r14),%rdx
  4040d4:	mov    %rdx,0x0(%rbp,%rax,8)
  4040d9:	mov    0x3d0f9(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4040df:	mov    %rax,0x8(%r14)
  4040e3:	mov    0x108(%r14),%rax
  4040ea:	add    $0x2,%rax
  4040ee:	mov    %rax,0x108(%r14)
  4040f5:	cmp    %rdx,%rax
  4040f8:	jae    401be0 <nx_rt_pair_take2.cold>
  4040fe:	pop    %rbp
  4040ff:	mov    %r13,%rax
  404102:	mov    %r12,%rdx
  404105:	pop    %r12
  404107:	pop    %r13
  404109:	pop    %r14
  40410b:	pop    %r15
  40410d:	retq   
  40410e:	xchg   %ax,%ax
  404110:	mov    0x4(%rcx),%edx
  404113:	mov    (%rcx),%edi
  404115:	shl    $0x20,%rdx
  404119:	or     %rdi,%rdx
  40411c:	mov    %rdx,%r15
  40411f:	and    $0xffffff,%edx
  404125:	shr    $0x18,%r15
  404129:	lea    0x8(,%r15,8),%rdi
  404131:	lea    0x0(%rbp,%rdi,1),%r8
  404136:	cmp    $0x1,%rdx
  40413a:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  404140:	mov    (%rcx),%edx
  404142:	mov    (%r14),%rdx
  404145:	mov    -0x8(%rbp,%rdi,1),%r13
  40414a:	mov    (%r8),%r12
  40414d:	mov    %rdx,(%rcx)
  404150:	mov    0x3d082(%rip),%edx        # 4411d8 <KEEP_WORDS>
  404156:	mov    %rax,(%r14)
  404159:	mov    0x100(%r14),%rax
  404160:	add    $0x1,%rax
  404164:	mov    %rax,0x100(%r14)
  40416b:	cmp    %rdx,%rax
  40416e:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  404174:	mov    %r15,%rax
  404177:	jmpq   4040b7 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
