
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401ca0 <nx_rt_build2>:
  401ca0:	push   %r15
  401ca2:	push   %r14
  401ca4:	push   %r13
  401ca6:	push   %r12
  401ca8:	push   %rbx
  401ca9:	lea    0x54d8(%rip),%rax        # 407188 <nx_context>
  401cb0:	cmp    %rax,%rdi
  401cb3:	jne    401d8d <nx_rt_build2+0xed>
  401cb9:	testb  $0x1,0x54c0(%rip)        # 407180 <nx_active>
  401cc0:	je     401d8d <nx_rt_build2+0xed>
  401cc6:	mov    %rcx,%r14
  401cc9:	mov    %rdx,%r13
  401ccc:	mov    %esi,%ebx
  401cce:	mov    0x54b3(%rip),%r15        # 407188 <nx_context>
  401cd5:	mov    0x54b4(%rip),%r12        # 407190 <nx_context+0x8>
  401cdc:	mov    %r15,%rdi
  401cdf:	callq  401da0 <nx_fields>
  401ce4:	mov    0x8(%r12),%r8
  401ce9:	test   %r8,%r8
  401cec:	je     401d48 <nx_rt_build2+0xa8>
  401cee:	mov    (%r15,%r8,8),%rax
  401cf2:	mov    %rax,0x8(%r12)
  401cf7:	addq   $0xfffffffffffffffe,0x108(%r12)
  401d00:	movabs $0xff00000000000000,%r9
  401d0a:	mov    %r13,%rax
  401d0d:	shr    $0x38,%rax
  401d11:	cmp    $0x2,%eax
  401d14:	je     401d5d <nx_rt_build2+0xbd>
  401d16:	mov    %r13,(%r15,%r8,8)
  401d1a:	and    %r14,%r9
  401d1d:	movabs $0x200000000000000,%r10
  401d27:	cmp    %r10,%r9
  401d2a:	je     401d75 <nx_rt_build2+0xd5>
  401d2c:	mov    %r14,0x8(%r15,%r8,8)
  401d31:	shl    $0x28,%rbx
  401d35:	or     %r10,%rbx
  401d38:	or     %r8,%rbx
  401d3b:	mov    %rbx,%rax
  401d3e:	pop    %rbx
  401d3f:	pop    %r12
  401d41:	pop    %r13
  401d43:	pop    %r14
  401d45:	pop    %r15
  401d47:	retq   
  401d48:	mov    %r15,%rdi
  401d4b:	mov    %r12,%rsi
  401d4e:	mov    $0x1,%edx
  401d53:	callq  401279 <heap_alloc_miss>
  401d58:	mov    %rax,%r8
  401d5b:	jmp    401d00 <nx_rt_build2+0x60>
  401d5d:	mov    %r15,%rdi
  401d60:	mov    %r12,%rsi
  401d63:	mov    %r13,%rdx
  401d66:	mov    $0x1,%ecx
  401d6b:	callq  401168 <rfc_wrap>
  401d70:	mov    %rax,%r13
  401d73:	jmp    401d16 <nx_rt_build2+0x76>
  401d75:	mov    %r15,%rdi
  401d78:	mov    %r12,%rsi
  401d7b:	mov    %r14,%rdx
  401d7e:	mov    $0x1,%ecx
  401d83:	callq  401168 <rfc_wrap>
  401d88:	mov    %rax,%r14
  401d8b:	jmp    401d2c <nx_rt_build2+0x8c>
  401d8d:	lea    0x2580(%rip),%rdi        # 404314 <_IO_stdin_used+0x314>
  401d94:	callq  401130 <err_fail>

Disassembly of section .fini:
