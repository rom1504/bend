  408518:	push   %rbp
  408519:	mov    %rsp,%rbp
  40851c:	sub    $0x960,%rsp
  408523:	mov    %r12,-0x10(%rbp)
  408527:	mov    %rbx,-0x8(%rbp)
  40852b:	mov    %rdi,%rax
  40852e:	mov    %rax,%r12
  408531:	mov    %rsi,%rax
  408534:	mov    %rax,%rsi
  408537:	mov    %rdx,%rax
  40853a:	mov    %rax,%rbx
  40853d:	mov    %rcx,%rax
  408540:	mov    %rax,%rdi
  408543:	cmp    $0x0,%rsi
  40854a:	jne    408560 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x48>
  408550:	mov    %rdi,%rax
  408553:	mov    -0x10(%rbp),%r12
  408557:	mov    -0x8(%rbp),%rbx
  40855b:	mov    %rbp,%rsp
  40855e:	pop    %rbp
  40855f:	retq   
  408560:	mov    %rsi,%rdx
  408563:	sub    $0x1,%rdx
  40856a:	mov    %ebx,%esi
  40856c:	mov    %rsi,%r8
  40856f:	add    $0x1,%r8d
  408576:	mov    %edi,%esi
  408578:	and    $0x7,%rsi
  40857f:	cmp    $0x3,%rsi
  408586:	setb   %sil
  40858a:	movzbl %sil,%esi
  40858e:	mov    %esi,%esi
  408590:	mov    %rsi,%r10
  408593:	test   %r10d,%r10d
  408596:	je     4085af <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x97>
  40859c:	mov    %edi,%edi
  40859e:	imul   $0x3,%edi,%edi
  4085a4:	add    $0x1,%edi
  4085aa:	jmpq   4085b6 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x9e>
  4085af:	mov    %edi,%edi
  4085b1:	mov    %ebx,%ebx
  4085b3:	xor    %rbx,%rdi
  4085b6:	mov    %rdx,%rsi
  4085b9:	mov    %r8,%rbx
  4085bc:	jmpq   408543 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x2b>
