
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402210 <nx_rt_id>:
  402210:	cmpb   $0x0,0x4f69(%rip)        # 407180 <nx_active>
  402217:	je     402225 <nx_rt_id+0x15>
  402219:	lea    0x4f80(%rip),%rax        # 4071a0 <nx_context>
  402220:	cmp    %rax,%rdi
  402223:	je     402238 <nx_rt_id+0x28>
  402225:	push   %rax
  402226:	lea    0x1e06(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  40222d:	callq  4019f0 <err_fail>
  402232:	nopw   0x0(%rax,%rax,1)
  402238:	mov    0x4f61(%rip),%rdi        # 4071a0 <nx_context>
  40223f:	jmpq   401b20 <nx_id.isra.0>

Disassembly of section .fini:
