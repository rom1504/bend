
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403490 <nx_rt_pair_rebuild2_c1_k0>:
  403490:	push   %r14
  403492:	mov    %rsi,%r10
  403495:	mov    %rdx,%r8
  403498:	movabs $0xffffffffff,%r9
  4034a2:	push   %r13
  4034a4:	and    %r10,%r9
  4034a7:	push   %r12
  4034a9:	lea    0x0(,%r9,8),%rax
  4034b1:	push   %rbp
  4034b2:	sub    $0x18,%rsp
  4034b6:	mov    (%rdi),%rbp
  4034b9:	mov    0x8(%rdi),%rsi
  4034bd:	lea    0x0(%rbp,%rax,1),%rdx
  4034c2:	test   %r10,%r10
  4034c5:	js     403520 <nx_rt_pair_rebuild2_c1_k0+0x90>
  4034c7:	mov    (%rdx),%r13
  4034ca:	mov    0x8(%rbp,%rax,1),%r12
  4034cf:	cmp    $0x310817f,%r9
  4034d6:	jbe    403500 <nx_rt_pair_rebuild2_c1_k0+0x70>
  4034d8:	mov    %r13,%rcx
  4034db:	mov    $0x1,%edx
  4034e0:	mov    %rbp,%rdi
  4034e3:	callq  401fd0 <nx_construct2>
  4034e8:	add    $0x18,%rsp
  4034ec:	mov    %r12,%rdx
  4034ef:	pop    %rbp
  4034f0:	pop    %r12
  4034f2:	pop    %r13
  4034f4:	pop    %r14
  4034f6:	retq   
  4034f7:	nopw   0x0(%rax,%rax,1)
  403500:	mov    0x8(%rsi),%r9
  403504:	test   %r9,%r9
  403507:	je     40173f <nx_rt_pair_rebuild2_c1_k0.cold>
  40350d:	mov    0x0(%rbp,%r9,8),%rax
  403512:	subq   $0x2,0x108(%rsi)
  40351a:	mov    %rax,0x8(%rsi)
  40351e:	jmp    4034d8 <nx_rt_pair_rebuild2_c1_k0+0x48>
  403520:	mov    0x4(%rdx),%eax
  403523:	mov    (%rdx),%ecx
  403525:	shl    $0x20,%rax
  403529:	or     %rcx,%rax
  40352c:	mov    %rax,%r14
  40352f:	and    $0xffffff,%eax
  403534:	shr    $0x18,%r14
  403538:	lea    0x0(,%r14,8),%rcx
  403540:	lea    0x8(%rbp,%rcx,1),%rdi
  403545:	add    %rbp,%rcx
  403548:	cmp    $0x1,%rax
  40354c:	jne    40177d <nx_rt_pair_rebuild2_c1_k0.cold+0x3e>
  403552:	mov    (%rdx),%eax
  403554:	mov    (%rsi),%rax
  403557:	mov    (%rcx),%r13
  40355a:	mov    (%rdi),%r12
  40355d:	mov    %rax,(%rdx)
  403560:	mov    0x100(%rsi),%rax
  403567:	mov    0x3dc6b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40356d:	mov    %r9,(%rsi)
  403570:	add    $0x1,%rax
  403574:	mov    %rax,0x100(%rsi)
  40357b:	cmp    %rdx,%rax
  40357e:	jae    401766 <nx_rt_pair_rebuild2_c1_k0.cold+0x27>
  403584:	mov    %r14,%r9
  403587:	jmpq   4034cf <nx_rt_pair_rebuild2_c1_k0+0x3f>

Disassembly of section .fini:
