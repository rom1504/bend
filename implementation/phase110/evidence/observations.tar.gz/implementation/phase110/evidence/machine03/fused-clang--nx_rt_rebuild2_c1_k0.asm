
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004035a0 <nx_rt_rebuild2_c1_k0>:
  4035a0:	push   %r15
  4035a2:	push   %r14
  4035a4:	push   %r13
  4035a6:	push   %r12
  4035a8:	mov    %rdx,%r12
  4035ab:	push   %rbp
  4035ac:	mov    %rdi,%rbp
  4035af:	push   %rbx
  4035b0:	movabs $0xffffffffff,%rbx
  4035ba:	and    %rsi,%rbx
  4035bd:	lea    0x0(,%rbx,8),%rdx
  4035c5:	sub    $0x18,%rsp
  4035c9:	mov    (%rdi),%r13
  4035cc:	mov    0x8(%rdi),%r15
  4035d0:	lea    0x0(%r13,%rdx,1),%rax
  4035d5:	test   %rsi,%rsi
  4035d8:	js     4036a0 <nx_rt_rebuild2_c1_k0+0x100>
  4035de:	mov    (%rax),%r14
  4035e1:	mov    0x8(%r13,%rdx,1),%r9
  4035e6:	cmp    $0x310817f,%rbx
  4035ed:	jbe    403678 <nx_rt_rebuild2_c1_k0+0xd8>
  4035f3:	lea    0x0(%r13,%rbx,8),%r8
  4035f8:	mov    %r14,%rax
  4035fb:	mov    %r9,0x10(%rbp)
  4035ff:	shr    $0x38,%rax
  403603:	movq   $0xffffffffffffffff,0x18(%rbp)
  40360b:	and    $0x7f,%eax
  40360e:	movl   $0x1,0x20(%rbp)
  403615:	cmp    $0x2,%rax
  403619:	je     403658 <nx_rt_rebuild2_c1_k0+0xb8>
  40361b:	mov    %r12,%rax
  40361e:	mov    %r14,(%r8)
  403621:	lea    0x8(%r13,%rbx,8),%rbp
  403626:	shr    $0x38,%rax
  40362a:	and    $0x7f,%eax
  40362d:	cmp    $0x2,%rax
  403631:	je     403668 <nx_rt_rebuild2_c1_k0+0xc8>
  403633:	movabs $0x200010000000000,%rax
  40363d:	mov    %r12,0x0(%rbp)
  403641:	add    $0x18,%rsp
  403645:	or     %rbx,%rax
  403648:	pop    %rbx
  403649:	pop    %rbp
  40364a:	pop    %r12
  40364c:	pop    %r13
  40364e:	pop    %r14
  403650:	pop    %r15
  403652:	retq   
  403653:	nopl   0x0(%rax,%rax,1)
  403658:	test   %r14,%r14
  40365b:	js     40361b <nx_rt_rebuild2_c1_k0+0x7b>
  40365d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403662:	nopw   0x0(%rax,%rax,1)
  403668:	test   %r12,%r12
  40366b:	js     403633 <nx_rt_rebuild2_c1_k0+0x93>
  40366d:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403672:	nopw   0x0(%rax,%rax,1)
  403678:	mov    0x8(%r15),%rbx
  40367c:	test   %rbx,%rbx
  40367f:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  403685:	lea    0x0(%r13,%rbx,8),%r8
  40368a:	mov    (%r8),%rax
  40368d:	subq   $0x2,0x108(%r15)
  403695:	mov    %rax,0x8(%r15)
  403699:	jmpq   4035f8 <nx_rt_rebuild2_c1_k0+0x58>
  40369e:	xchg   %ax,%ax
  4036a0:	mov    0x4(%rax),%edx
  4036a3:	mov    (%rax),%ecx
  4036a5:	shl    $0x20,%rdx
  4036a9:	or     %rcx,%rdx
  4036ac:	mov    %rdx,%rcx
  4036af:	and    $0xffffff,%edx
  4036b5:	shr    $0x18,%rcx
  4036b9:	lea    0x8(,%rcx,8),%rdi
  4036c1:	lea    0x0(%r13,%rdi,1),%r8
  4036c6:	lea    -0x8(%r13,%rdi,1),%rdi
  4036cb:	cmp    $0x1,%rdx
  4036cf:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  4036d5:	mov    (%rax),%edx
  4036d7:	mov    (%r15),%rdx
  4036da:	mov    (%rdi),%r14
  4036dd:	mov    (%r8),%r9
  4036e0:	mov    %rdx,(%rax)
  4036e3:	mov    0x100(%r15),%rax
  4036ea:	mov    0x3dae8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4036f0:	mov    %rbx,(%r15)
  4036f3:	add    $0x1,%rax
  4036f7:	mov    %rax,0x100(%r15)
  4036fe:	cmp    %rdx,%rax
  403701:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  403707:	mov    %rcx,%rbx
  40370a:	jmpq   4035e6 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
