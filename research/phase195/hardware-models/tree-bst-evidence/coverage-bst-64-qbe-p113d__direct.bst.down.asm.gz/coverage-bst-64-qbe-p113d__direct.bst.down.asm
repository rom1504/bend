0000000000407580 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_>:
  407580:	endbr64 
  407584:	push   rbp
  407585:	mov    rbp,rsp
  407588:	sub    rsp,0x8
  40758c:	push   rbx
  40758d:	push   r12
  40758f:	push   r13
  407591:	mov    rax,rcx
  407594:	mov    rcx,rax
  407597:	nop    WORD PTR [rax+rax*1+0x0]
  4075a0:	cmp    rsi,0x0
  4075a4:	je     4075cc <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x4c>
  4075a6:	sub    rsi,0x1
  4075aa:	mov    r13,rdx
  4075ad:	mov    rdx,rcx
  4075b0:	mov    r12,rsi
  4075b3:	mov    rsi,r13
  4075b6:	mov    rbx,rdi
  4075b9:	call   407080 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_>
  4075be:	mov    rdx,r13
  4075c1:	mov    rsi,r12
  4075c4:	mov    rdi,rbx
  4075c7:	mov    rcx,rax
  4075ca:	jmp    4075a0 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x20>
  4075cc:	mov    rax,rcx
  4075cf:	pop    r13
  4075d1:	pop    r12
  4075d3:	pop    rbx
  4075d4:	leave  
  4075d5:	ret    
  4075d6:	nop    WORD PTR cs:[rax+rax*1+0x0]

