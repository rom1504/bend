
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d80 <nx_rt_fast_take2>:
  402d80:	movabs $0xffffffffff,%rax
  402d8a:	push   %r12
  402d8c:	and    %rsi,%rax
  402d8f:	push   %rbp
  402d90:	push   %rbx
  402d91:	mov    %rdi,%rbx
  402d94:	mov    (%rdi),%rdi
  402d97:	lea    0x0(,%rax,8),%rcx
  402d9f:	mov    0x8(%rbx),%rbp
  402da3:	lea    (%rdi,%rcx,1),%rdx
  402da7:	test   %rsi,%rsi
  402daa:	js     402e18 <nx_rt_fast_take2+0x98>
  402dac:	mov    (%rdx),%rdx
  402daf:	mov    %rdx,0x10(%rbx)
  402db3:	mov    0x8(%rdi,%rcx,1),%rdx
  402db8:	mov    %rdx,0x18(%rbx)
  402dbc:	cmp    $0x310817f,%rax
  402dc2:	ja     402dd8 <nx_rt_fast_take2+0x58>
  402dc4:	movl   $0x3,0x20(%rbx)
  402dcb:	xor    %eax,%eax
  402dcd:	pop    %rbx
  402dce:	pop    %rbp
  402dcf:	pop    %r12
  402dd1:	retq   
  402dd2:	nopw   0x0(%rax,%rax,1)
  402dd8:	mov    0x8(%rbp),%rdx
  402ddc:	mov    %rdx,(%rdi,%rax,8)
  402de0:	mov    0x3e3f2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402de6:	mov    %rax,0x8(%rbp)
  402dea:	mov    0x108(%rbp),%rax
  402df1:	add    $0x2,%rax
  402df5:	mov    %rax,0x108(%rbp)
  402dfc:	cmp    %rdx,%rax
  402dff:	jae    4015fe <nx_rt_fast_take2.cold>
  402e05:	movl   $0x3,0x20(%rbx)
  402e0c:	xor    %eax,%eax
  402e0e:	pop    %rbx
  402e0f:	pop    %rbp
  402e10:	pop    %r12
  402e12:	retq   
  402e13:	nopl   0x0(%rax,%rax,1)
  402e18:	mov    0x4(%rdx),%ecx
  402e1b:	mov    (%rdx),%r8d
  402e1e:	shl    $0x20,%rcx
  402e22:	or     %r8,%rcx
  402e25:	mov    %rcx,%r12
  402e28:	and    $0xffffff,%ecx
  402e2e:	shr    $0x18,%r12
  402e32:	lea    0x0(,%r12,8),%r8
  402e3a:	lea    (%rdi,%r8,1),%r9
  402e3e:	lea    0x8(%rdi,%r8,1),%r8
  402e43:	cmp    $0x1,%rcx
  402e47:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  402e4d:	mov    (%rdx),%ecx
  402e4f:	mov    (%r9),%rcx
  402e52:	mov    %rcx,0x10(%rbx)
  402e56:	mov    (%r8),%rcx
  402e59:	mov    %rcx,0x18(%rbx)
  402e5d:	mov    0x0(%rbp),%rcx
  402e61:	mov    %rcx,(%rdx)
  402e64:	mov    0x3e36e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e6a:	mov    %rax,0x0(%rbp)
  402e6e:	mov    0x100(%rbp),%rax
  402e75:	add    $0x1,%rax
  402e79:	mov    %rax,0x100(%rbp)
  402e80:	cmp    %rdx,%rax
  402e83:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  402e89:	mov    %r12,%rax
  402e8c:	jmpq   402dbc <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
