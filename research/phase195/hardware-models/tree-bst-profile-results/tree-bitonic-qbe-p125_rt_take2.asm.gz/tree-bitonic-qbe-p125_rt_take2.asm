000000000041a200 <p125_rt_take2>:
  41a200:	push   r12
  41a202:	mov    rax,rdx
  41a205:	mov    rdx,rsi
  41a208:	push   rbx
  41a209:	shr    rdx,0x28
  41a20d:	movzx  edx,dx
  41a210:	sub    rsp,0x8
  41a214:	mov    rcx,QWORD PTR [rip+0x108ab5]        # 522cd0 <p111_program_active>
  41a21b:	cmp    QWORD PTR [rcx+0x18],rdx
  41a21f:	ja     41a230 <p125_rt_take2+0x30>
  41a221:	lea    rdi,[rip+0x1137]        # 41b35f <_IO_stdin_used+0x35f>
  41a228:	call   410530 <err_fail>
  41a22d:	nop    DWORD PTR [rax]
  41a230:	mov    rbx,rdi
  41a233:	mov    rdi,QWORD PTR [rcx+0x80]
  41a23a:	cmp    BYTE PTR [rdi+rdx*1],0x2
  41a23e:	jne    41a221 <p125_rt_take2+0x21>
  41a240:	mov    rdx,rsi
  41a243:	shr    rdx,0x38
  41a247:	and    edx,0x7f
  41a24a:	cmp    rdx,0x2
  41a24e:	jne    41a37b <p125_rt_take2+0x17b>
  41a254:	movabs rdx,0xffffffffff
  41a25e:	mov    rdi,QWORD PTR [rbx]
  41a261:	and    rdx,rsi
  41a264:	lea    r9,[rdx*8+0x0]
  41a26c:	lea    r8,[rdi+r9*1]
  41a270:	test   rsi,rsi
  41a273:	js     41a2f8 <p125_rt_take2+0xf8>
  41a279:	mov    rsi,QWORD PTR [r8]
  41a27c:	mov    QWORD PTR [rax],rsi
  41a27f:	mov    rsi,QWORD PTR [rdi+r9*1+0x8]
  41a284:	mov    QWORD PTR [rax+0x8],rsi
  41a288:	mov    rax,QWORD PTR [rcx+0x40]
  41a28c:	add    rax,0x7f
  41a290:	and    rax,0xffffffffffffff80
  41a294:	add    rax,0x3108200
  41a29a:	cmp    rax,rdx
  41a29d:	jbe    41a2b0 <p125_rt_take2+0xb0>
  41a29f:	add    rsp,0x8
  41a2a3:	mov    eax,0x2
  41a2a8:	pop    rbx
  41a2a9:	pop    r12
  41a2ab:	ret    
  41a2ac:	nop    DWORD PTR [rax+0x0]
  41a2b0:	mov    rsi,QWORD PTR [rbx+0x8]
  41a2b4:	mov    rdi,QWORD PTR [rbx]
  41a2b7:	mov    rax,QWORD PTR [rsi+0x8]
  41a2bb:	mov    QWORD PTR [rdi+rdx*8],rax
  41a2bf:	mov    rax,QWORD PTR [rsi+0x108]
  41a2c6:	mov    QWORD PTR [rsi+0x8],rdx
  41a2ca:	mov    edx,DWORD PTR [rip+0x108ab4]        # 522d84 <KEEP_WORDS>
  41a2d0:	add    rax,0x2
  41a2d4:	mov    QWORD PTR [rsi+0x108],rax
  41a2db:	cmp    rax,rdx
  41a2de:	jae    405077 <p125_rt_take2.cold+0x2f>
  41a2e4:	add    rsp,0x8
  41a2e8:	mov    eax,0x2
  41a2ed:	pop    rbx
  41a2ee:	pop    r12
  41a2f0:	ret    
  41a2f1:	nop    DWORD PTR [rax+0x0]
  41a2f8:	mov    r9,QWORD PTR [rbx+0x8]
  41a2fc:	mov    ecx,DWORD PTR [r8+0x4]
  41a300:	mov    r10d,DWORD PTR [r8]
  41a303:	shl    rcx,0x20
  41a307:	or     rcx,r10
  41a30a:	mov    r12,rcx
  41a30d:	and    ecx,0xffffff
  41a313:	shr    r12,0x18
  41a317:	lea    r10,[r12*8+0x0]
  41a31f:	lea    r11,[rdi+r10*1]
  41a323:	lea    r10,[r10+rdi*1+0x8]
  41a328:	cmp    rcx,0x1
  41a32c:	jne    405048 <p125_rt_take2.cold>
  41a332:	mov    ecx,DWORD PTR [r8]
  41a335:	mov    rcx,QWORD PTR [r11]
  41a338:	mov    QWORD PTR [rax],rcx
  41a33b:	mov    rcx,QWORD PTR [r10]
  41a33e:	mov    QWORD PTR [rax+0x8],rcx
  41a342:	mov    rax,QWORD PTR [r9]
  41a345:	mov    QWORD PTR [r8],rax
  41a348:	mov    rax,QWORD PTR [r9+0x100]
  41a34f:	mov    QWORD PTR [r9],rdx
  41a352:	mov    edx,DWORD PTR [rip+0x108a2c]        # 522d84 <KEEP_WORDS>
  41a358:	add    rax,0x1
  41a35c:	mov    QWORD PTR [r9+0x100],rax
  41a363:	cmp    rax,rdx
  41a366:	jae    405086 <p125_rt_take2.cold+0x3e>
  41a36c:	mov    rcx,QWORD PTR [rip+0x10895d]        # 522cd0 <p111_program_active>
  41a373:	mov    rdx,r12
  41a376:	jmp    41a288 <p125_rt_take2+0x88>
  41a37b:	lea    rdi,[rip+0x1b9e]        # 41bf20 <_IO_stdin_used+0xf20>
  41a382:	call   410530 <err_fail>
  41a387:	nop    WORD PTR [rax+rax*1+0x0]

