
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004031e0 <nx_rt_fast_id>:
  4031e0:	shr    $0x28,%rsi
  4031e4:	movzwl %si,%eax
  4031e7:	retq   

Disassembly of section .fini:
