0000000000009bf0 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>:
    9bf0:	push   rbp
    9bf1:	sub    rsp,0x10
    9bf5:	mov    rbp,rsi
    9bf8:	movabs r9,0xffffffffff
    9c02:	mov    r8d,edx
    9c05:	add    r14,0xffffffffffffffe8
    9c09:	nop    DWORD PTR [rax+0x0]
    9c10:	mov    rax,rbp
    9c13:	shr    rax,0x28
    9c17:	movzx  eax,ax
    9c1a:	cmp    eax,0xa5
    9c1f:	jne    9d80 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x190>
    9c25:	mov    rax,rbp
    9c28:	and    rax,r9
    9c2b:	test   rbp,rbp
    9c2e:	js     9c50 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x60>
    9c30:	mov    rbp,QWORD PTR [r12+rax*8]
    9c34:	mov    r10d,DWORD PTR [r12+rax*8+0x8]
    9c39:	mov    rbx,QWORD PTR [r12+rax*8+0x10]
    9c3e:	mov    rcx,rax
    9c41:	cmp    rcx,0x3108180
    9c48:	jae    9cc6 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0xd6>
    9c4a:	jmp    9cf5 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x105>
    9c4f:	nop
    9c50:	mov    ecx,DWORD PTR [r12+rax*8+0x4]
    9c55:	mov    edx,DWORD PTR [r12+rax*8]
    9c59:	mov    esi,edx
    9c5b:	and    esi,0xffffff
    9c61:	cmp    esi,0x1
    9c64:	jne    9d29 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x139>
    9c6a:	mov    esi,DWORD PTR [r12+rax*8]
    9c6e:	shl    rcx,0x20
    9c72:	or     rcx,rdx
    9c75:	shr    rcx,0x18
    9c79:	mov    rbp,QWORD PTR [r12+rcx*8]
    9c7d:	mov    r10d,DWORD PTR [r12+rcx*8+0x8]
    9c82:	mov    rbx,QWORD PTR [r12+rcx*8+0x10]
    9c87:	mov    rdx,QWORD PTR [r13+0x0]
    9c8b:	mov    QWORD PTR [r12+rax*8],rdx
    9c8f:	mov    QWORD PTR [r13+0x0],rax
    9c93:	mov    rax,QWORD PTR [r13+0x100]
    9c9a:	inc    rax
    9c9d:	mov    QWORD PTR [r13+0x100],rax
    9ca4:	cmp    BYTE PTR [rip+0x10e0e5],0x1        # 117d90 <KEEP_WORDS>
    9cab:	jne    9d61 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x171>
    9cb1:	cmp    rax,0x8000
    9cb7:	jae    9d61 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x171>
    9cbd:	cmp    rcx,0x3108180
    9cc4:	jb     9cf5 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x105>
    9cc6:	mov    rax,QWORD PTR [r13+0x10]
    9cca:	mov    QWORD PTR [r12+rcx*8],rax
    9cce:	mov    QWORD PTR [r13+0x10],rcx
    9cd2:	mov    rax,QWORD PTR [r13+0x110]
    9cd9:	add    rax,0x4
    9cdd:	mov    QWORD PTR [r13+0x110],rax
    9ce4:	cmp    BYTE PTR [rip+0x10e0a5],0x1        # 117d90 <KEEP_WORDS>
    9ceb:	jne    9d17 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x127>
    9ced:	cmp    rax,0x8000
    9cf3:	jae    9d17 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x127>
    9cf5:	test   r15d,r15d
    9cf8:	je     9da6 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x1b6>
    9cfe:	mov    QWORD PTR [r14+0x18],r10
    9d02:	mov    QWORD PTR [r14+0x20],rbx
    9d06:	mov    QWORD PTR [r14+0x28],0x46
    9d0e:	add    r14,0x18
    9d12:	jmp    9c10 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x20>
    9d17:	mov    rdi,r12
    9d1a:	mov    rsi,r13
    9d1d:	mov    edx,0x2
    9d22:	call   13ed1 <heap_hand>
    9d27:	jmp    9cf5 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x105>
    9d29:	shl    rcx,0x20
    9d2d:	or     rcx,rdx
    9d30:	shr    rcx,0x18
    9d34:	mov    rax,QWORD PTR [r12+rcx*8]
    9d38:	mov    r10d,DWORD PTR [r12+rcx*8+0x8]
    9d3d:	mov    rbx,QWORD PTR [r12+rcx*8+0x10]
    9d42:	mov    rdi,r12
    9d45:	mov    rsi,r13
    9d48:	mov    rdx,rbp
    9d4b:	mov    rbp,r8
    9d4e:	mov    r8d,0x3
    9d54:	call   13f62 <span_fade>
    9d59:	mov    r8,rbp
    9d5c:	mov    rbp,rax
    9d5f:	jmp    9cf5 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x105>
    9d61:	mov    rdi,r12
    9d64:	mov    rsi,r13
    9d67:	xor    edx,edx
    9d69:	call   13ed1 <heap_hand>
    9d6e:	cmp    rcx,0x3108180
    9d75:	jae    9cc6 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0xd6>
    9d7b:	jmp    9cf5 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x105>
    9d80:	cmp    eax,0xa4
    9d85:	je     9fb9 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3c9>
    9d8b:	mov    QWORD PTR [rsp],r8
    9d8f:	test   r15d,r15d
    9d92:	jne    a076 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x486>
    9d98:	lea    rax,[r14+0x8]
    9d9c:	mov    QWORD PTR [rsp+0x8],rax
    9da1:	jmp    9ff0 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x400>
    9da6:	mov    QWORD PTR [rsp],r8
    9daa:	mov    r8,QWORD PTR [r14]
    9dad:	mov    rcx,QWORD PTR [r14+0x8]
    9db1:	mov    rax,QWORD PTR [r13+0x18]
    9db5:	test   rax,rax
    9db8:	je     9fdb <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3eb>
    9dbe:	mov    rdx,QWORD PTR [r12+rax*8]
    9dc2:	mov    QWORD PTR [r13+0x18],rdx
    9dc6:	add    QWORD PTR [r13+0x118],0xfffffffffffffff8
    9dce:	lea    rdx,[r14+0x8]
    9dd2:	mov    QWORD PTR [rsp+0x8],rdx
    9dd7:	movabs r15,0x500460000000000
    9de1:	jmp    9e44 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x254>
    9de3:	shl    rcx,0x20
    9de7:	or     rcx,rdx
    9dea:	shr    rcx,0x18
    9dee:	mov    rax,QWORD PTR [r12+rcx*8]
    9df2:	mov    r10d,DWORD PTR [r12+rcx*8+0x8]
    9df7:	mov    rbx,QWORD PTR [r12+rcx*8+0x10]
    9dfc:	mov    rdi,r12
    9dff:	mov    rsi,r13
    9e02:	mov    rdx,rbp
    9e05:	mov    r8d,0x3
    9e0b:	call   13f62 <span_fade>
    9e10:	mov    rbp,rax
    9e13:	data16 data16 data16 nop WORD PTR cs:[rax+rax*1+0x0]
    9e20:	mov    r8,QWORD PTR [r14]
    9e23:	mov    rcx,QWORD PTR [r14+0x8]
    9e27:	mov    rax,QWORD PTR [r13+0x18]
    9e2b:	test   rax,rax
    9e2e:	je     9f7a <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x38a>
    9e34:	mov    rdx,QWORD PTR [r12+rax*8]
    9e38:	mov    QWORD PTR [r13+0x18],rdx
    9e3c:	add    QWORD PTR [r13+0x118],0xfffffffffffffff8
    9e44:	mov    QWORD PTR [r12+rax*8+0x10],0xffffffffffffffff
    9e4d:	mov    QWORD PTR [r12+rax*8+0x18],r8
    9e52:	shl    rcx,0x20
    9e56:	inc    rcx
    9e59:	mov    QWORD PTR [r12+rax*8+0x20],rcx
    9e5e:	mov    ecx,r10d
    9e61:	mov    QWORD PTR [r12+rax*8],rcx
    9e65:	mov    QWORD PTR [r12+rax*8+0x8],rbx
    9e6a:	or     rax,r15
    9e6d:	mov    QWORD PTR [r14],rax
    9e70:	mov    QWORD PTR [r14+0x8],0x2
    9e78:	mov    rax,rbp
    9e7b:	shr    rax,0x28
    9e7f:	movzx  eax,ax
    9e82:	cmp    eax,0xa5
    9e87:	jne    9fab <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3bb>
    9e8d:	mov    rax,rbp
    9e90:	and    rax,r9
    9e93:	test   rbp,rbp
    9e96:	js     9ec0 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x2d0>
    9e98:	mov    rbp,QWORD PTR [r12+rax*8]
    9e9c:	mov    r10d,DWORD PTR [r12+rax*8+0x8]
    9ea1:	mov    rbx,QWORD PTR [r12+rax*8+0x10]
    9ea6:	mov    rcx,rax
    9ea9:	cmp    rcx,0x3108180
    9eb0:	jb     9e20 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x230>
    9eb6:	jmp    9f32 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x342>
    9eb8:	nop    DWORD PTR [rax+rax*1+0x0]
    9ec0:	mov    ecx,DWORD PTR [r12+rax*8+0x4]
    9ec5:	mov    edx,DWORD PTR [r12+rax*8]
    9ec9:	mov    esi,edx
    9ecb:	and    esi,0xffffff
    9ed1:	cmp    esi,0x1
    9ed4:	jne    9de3 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x1f3>
    9eda:	mov    esi,DWORD PTR [r12+rax*8]
    9ede:	shl    rcx,0x20
    9ee2:	or     rcx,rdx
    9ee5:	shr    rcx,0x18
    9ee9:	mov    rbp,QWORD PTR [r12+rcx*8]
    9eed:	mov    r10d,DWORD PTR [r12+rcx*8+0x8]
    9ef2:	mov    rbx,QWORD PTR [r12+rcx*8+0x10]
    9ef7:	mov    rdx,QWORD PTR [r13+0x0]
    9efb:	mov    QWORD PTR [r12+rax*8],rdx
    9eff:	mov    QWORD PTR [r13+0x0],rax
    9f03:	mov    rax,QWORD PTR [r13+0x100]
    9f0a:	inc    rax
    9f0d:	mov    QWORD PTR [r13+0x100],rax
    9f14:	cmp    BYTE PTR [rip+0x10de75],0x1        # 117d90 <KEEP_WORDS>
    9f1b:	jne    9f8f <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x39f>
    9f1d:	cmp    rax,0x8000
    9f23:	jae    9f8f <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x39f>
    9f25:	cmp    rcx,0x3108180
    9f2c:	jb     9e20 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x230>
    9f32:	mov    rax,QWORD PTR [r13+0x10]
    9f36:	mov    QWORD PTR [r12+rcx*8],rax
    9f3a:	mov    QWORD PTR [r13+0x10],rcx
    9f3e:	mov    rax,QWORD PTR [r13+0x110]
    9f45:	add    rax,0x4
    9f49:	mov    QWORD PTR [r13+0x110],rax
    9f50:	cmp    BYTE PTR [rip+0x10de39],0x1        # 117d90 <KEEP_WORDS>
    9f57:	jne    9f65 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x375>
    9f59:	cmp    rax,0x8000
    9f5f:	jb     9e20 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x230>
    9f65:	mov    rdi,r12
    9f68:	mov    rsi,r13
    9f6b:	mov    edx,0x2
    9f70:	call   13ed1 <heap_hand>
    9f75:	jmp    9e20 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x230>
    9f7a:	mov    rdi,r12
    9f7d:	mov    rsi,r13
    9f80:	mov    edx,0x3
    9f85:	call   13ff8 <heap_alloc_miss>
    9f8a:	jmp    9e44 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x254>
    9f8f:	mov    rdi,r12
    9f92:	mov    rsi,r13
    9f95:	xor    edx,edx
    9f97:	call   13ed1 <heap_hand>
    9f9c:	cmp    rcx,0x3108180
    9fa3:	jb     9e20 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x230>
    9fa9:	jmp    9f32 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x342>
    9fab:	cmp    eax,0xa4
    9fb0:	mov    r8,QWORD PTR [rsp]
    9fb4:	jne    9ff0 <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x400>
    9fb6:	xor    r15d,r15d
    9fb9:	mov    eax,DWORD PTR [r14+0x10]
    9fbd:	add    r14,0x10
    9fc1:	lea    rcx,[rip+0xc498]        # 16460 <wl_tab>
    9fc8:	mov    rax,QWORD PTR [rcx+rax*8]
    9fcc:	mov    edi,0x1
    9fd1:	mov    rsi,r8
    9fd4:	add    rsp,0x10
    9fd8:	pop    rbp
    9fd9:	jmp    rax
    9fdb:	mov    rdi,r12
    9fde:	mov    rsi,r13
    9fe1:	mov    edx,0x3
    9fe6:	call   13ff8 <heap_alloc_miss>
    9feb:	jmp    9dce <WL_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x1de>
    9ff0:	mov    rcx,QWORD PTR [r14]
    9ff3:	mov    r8d,DWORD PTR [r14+0x8]
    9ff7:	mov    rdi,r12
    9ffa:	mov    rsi,r13
    9ffd:	mov    edx,0x47
    a002:	mov    r9d,0x1
    a008:	call   7270 <task_node>
    a00d:	mov    rcx,QWORD PTR [rsp]
    a011:	mov    QWORD PTR [r12+rax*8],rcx
    a015:	movabs rcx,0x500470000000000
    a01f:	or     rcx,rax
    a022:	mov    QWORD PTR [r14],rcx
    a025:	mov    QWORD PTR [r14+0x8],0x1
    a02d:	mov    rdi,r12
    a030:	mov    rsi,r13
    a033:	mov    edx,0x48
    a038:	mov    r8d,0x1
    a03e:	mov    r9d,0x1
    a044:	call   7270 <task_node>
    a049:	mov    QWORD PTR [r12+rax*8],rbp
    a04d:	movabs rcx,0x500480000000000
    a057:	or     rcx,rax
    a05a:	mov    QWORD PTR [r14],rcx
    a05d:	mov    eax,0x1
    a062:	mov    rcx,QWORD PTR [rsp+0x8]
    a067:	mov    QWORD PTR [rcx],rax
    a06a:	lea    rdi,[rip+0xffffffffffff861f]        # 2690 <FID_RESW_T+0x320>
    a071:	call   13e70 <err_fail>
    a076:	mov    rax,QWORD PTR [rsp]
    a07a:	mov    QWORD PTR [r14+0x18],rax
    a07e:	mov    QWORD PTR [r14+0x20],0x47
    a086:	mov    QWORD PTR [r14+0x28],rbp
    a08a:	add    r14,0x30
    a08e:	mov    eax,0x48
    a093:	mov    QWORD PTR [rsp+0x8],r14
    a098:	mov    rcx,QWORD PTR [rsp+0x8]
    a09d:	mov    QWORD PTR [rcx],rax
    a0a0:	lea    rdi,[rip+0xffffffffffff85e9]        # 2690 <FID_RESW_T+0x320>
    a0a7:	call   13e70 <err_fail>
    a0ac:	nop    DWORD PTR [rax+0x0]

