000000000041a110 <p125_rt_ctor2>:
  41a110:	push   r15
  41a112:	push   r14
  41a114:	push   r13
  41a116:	mov    r13,rdx
  41a119:	push   r12
  41a11b:	push   rbp
  41a11c:	push   rbx
  41a11d:	mov    ebx,esi
  41a11f:	sub    rsp,0x8
  41a123:	mov    r12,QWORD PTR [rdi+0x8]
  41a127:	mov    r14,QWORD PTR [rdi]
  41a12a:	mov    rbp,QWORD PTR [r12+0x8]
  41a12f:	test   rbp,rbp
  41a132:	je     40502c <p125_rt_ctor2.cold+0x30>
  41a138:	lea    rcx,[r14+rbp*8]
  41a13c:	mov    rax,QWORD PTR [rcx]
  41a13f:	sub    QWORD PTR [r12+0x108],0x2
  41a148:	mov    QWORD PTR [r12+0x8],rax
  41a14d:	mov    rax,QWORD PTR [rip+0x108b7c]        # 522cd0 <p111_program_active>
  41a154:	mov    rdx,QWORD PTR [r13+0x0]
  41a158:	test   BYTE PTR [rax+0x58],0x8
  41a15c:	je     41a180 <p125_rt_ctor2+0x70>
  41a15e:	mov    rax,QWORD PTR [rax+0x88]
  41a165:	cmp    BYTE PTR [rax+rbx*1],0x0
  41a169:	jne    41a180 <p125_rt_ctor2+0x70>
  41a16b:	mov    QWORD PTR [rcx],rdx
  41a16e:	mov    rax,QWORD PTR [r13+0x8]
  41a172:	mov    QWORD PTR [r14+rbp*8+0x8],rax
  41a177:	jmp    41a1b4 <p125_rt_ctor2+0xa4>
  41a179:	nop    DWORD PTR [rax+0x0]
  41a180:	mov    rax,rdx
  41a183:	lea    r15,[r14+rbp*8]
  41a187:	shr    rax,0x38
  41a18b:	and    eax,0x7f
  41a18e:	cmp    rax,0x2
  41a192:	je     41a1e8 <p125_rt_ctor2+0xd8>
  41a194:	mov    QWORD PTR [r15],rdx
  41a197:	mov    rdx,QWORD PTR [r13+0x8]
  41a19b:	lea    r13,[r14+rbp*8+0x8]
  41a1a0:	mov    rax,rdx
  41a1a3:	shr    rax,0x38
  41a1a7:	and    eax,0x7f
  41a1aa:	cmp    rax,0x2
  41a1ae:	je     41a1d8 <p125_rt_ctor2+0xc8>
  41a1b0:	mov    QWORD PTR [r13+0x0],rdx
  41a1b4:	mov    rax,rbx
  41a1b7:	add    rsp,0x8
  41a1bb:	shl    rax,0x28
  41a1bf:	pop    rbx
  41a1c0:	or     rax,rbp
  41a1c3:	pop    rbp
  41a1c4:	pop    r12
  41a1c6:	bts    rax,0x39
  41a1cb:	pop    r13
  41a1cd:	pop    r14
  41a1cf:	pop    r15
  41a1d1:	ret    
  41a1d2:	nop    WORD PTR [rax+rax*1+0x0]
  41a1d8:	test   rdx,rdx
  41a1db:	js     41a1b0 <p125_rt_ctor2+0xa0>
  41a1dd:	jmp    404ffc <p125_rt_ctor2.cold>
  41a1e2:	nop    WORD PTR [rax+rax*1+0x0]
  41a1e8:	test   rdx,rdx
  41a1eb:	js     41a194 <p125_rt_ctor2+0x84>
  41a1ed:	jmp    405014 <p125_rt_ctor2.cold+0x18>
  41a1f2:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
  41a1fd:	nop    DWORD PTR [rax]

