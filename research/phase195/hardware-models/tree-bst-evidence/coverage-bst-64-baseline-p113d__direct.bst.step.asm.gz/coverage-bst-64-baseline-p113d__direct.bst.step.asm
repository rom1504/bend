000000000040891c <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_>:
  40891c:	push   rbp
  40891d:	mov    rbp,rsp
  408920:	sub    rsp,0x9b0
  408927:	mov    QWORD PTR [rbp-0x10],r12
  40892b:	mov    QWORD PTR [rbp-0x8],rbx
  40892f:	mov    QWORD PTR [rbp-0x18],r13
  408933:	mov    rax,rdi
  408936:	mov    r12,rax
  408939:	mov    rax,rsi
  40893c:	mov    r13,rax
  40893f:	mov    rax,rdx
  408942:	mov    rsi,rax
  408945:	mov    rdi,rsi
  408948:	shr    rdi,0x28
  40894c:	and    rdi,0xffff
  408953:	movabs r11,0x8
  40895d:	cmp    rdi,r11
  408960:	jne    408bc7 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x2ab>
  408966:	mov    r10,r12
  408969:	mov    QWORD PTR [rsp+0x18],r10
  40896e:	mov    r10,rsi
  408971:	mov    QWORD PTR [rsp+0x20],r10
  408976:	lea    r10,[rbp-0x840]
  40897d:	mov    QWORD PTR [rsp+0x28],r10
  408982:	mov    rdi,QWORD PTR [rsp+0x18]
  408987:	mov    rsi,QWORD PTR [rsp+0x20]
  40898c:	mov    rdx,QWORD PTR [rsp+0x28]
  408991:	xor    eax,eax
  408993:	call   41dbc0 <p125_rt_take2>
  408998:	mov    QWORD PTR [rbp-0x8b0],rax
  40899f:	lea    r10,[rbp-0x840]
  4089a6:	mov    rsi,QWORD PTR [r10]
  4089a9:	lea    r10,[rbp-0x840]
  4089b0:	mov    rbx,QWORD PTR [r10+0x8]
  4089b4:	mov    rdi,rsi
  4089b7:	shr    rdi,0x28
  4089bb:	and    rdi,0xffff
  4089c2:	movabs r11,0xa4
  4089cc:	cmp    rdi,r11
  4089cf:	jne    408a2b <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x10f>
  4089d5:	lea    r10,[rbp-0x840]
  4089dc:	movabs r11,0x100a40000000000
  4089e6:	mov    QWORD PTR [r10],r11
  4089e9:	lea    r10,[rbp-0x840]
  4089f0:	mov    r11,rbx
  4089f3:	mov    QWORD PTR [r10+0x8],r11
  4089f7:	mov    rdi,r12
  4089fa:	movabs rsi,0x8
  408a04:	mov    esi,esi
  408a06:	lea    rdx,[rbp-0x840]
  408a0d:	xor    eax,eax
  408a0f:	call   41dad0 <p125_rt_ctor2>
  408a14:	mov    rdi,rax
  408a17:	mov    rax,rdi
  408a1a:	mov    r12,QWORD PTR [rbp-0x10]
  408a1e:	mov    rbx,QWORD PTR [rbp-0x8]
  408a22:	mov    r13,QWORD PTR [rbp-0x18]
  408a26:	mov    rsp,rbp
  408a29:	pop    rbp
  408a2a:	ret    
  408a2b:	mov    rdi,rsi
  408a2e:	shr    rdi,0x28
  408a32:	and    rdi,0xffff
  408a39:	movabs r11,0xa5
  408a43:	cmp    rdi,r11
  408a46:	jne    408b8f <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x273>
  408a4c:	mov    r10,r12
  408a4f:	mov    QWORD PTR [rsp+0x18],r10
  408a54:	mov    r10,rsi
  408a57:	mov    QWORD PTR [rsp+0x20],r10
  408a5c:	lea    r10,[rbp-0x840]
  408a63:	mov    QWORD PTR [rsp+0x28],r10
  408a68:	mov    rdi,QWORD PTR [rsp+0x18]
  408a6d:	mov    rsi,QWORD PTR [rsp+0x20]
  408a72:	mov    rdx,QWORD PTR [rsp+0x28]
  408a77:	xor    eax,eax
  408a79:	call   41de20 <p125_rt_take3>
  408a7e:	mov    QWORD PTR [rbp-0x8b0],rax
  408a85:	lea    r10,[rbp-0x840]
  408a8c:	mov    rdx,QWORD PTR [r10]
  408a8f:	lea    r10,[rbp-0x840]
  408a96:	mov    rdi,QWORD PTR [r10+0x8]
  408a9a:	lea    r10,[rbp-0x840]
  408aa1:	mov    r8,QWORD PTR [r10+0x10]
  408aa5:	mov    r13d,r13d
  408aa8:	mov    esi,edi
  408aaa:	mov    r11,rsi
  408aad:	mov    rsi,r13
  408ab0:	cmp    rsi,r11
  408ab3:	setb   sil
  408ab7:	movzx  esi,sil
  408abb:	mov    r10,r12
  408abe:	mov    QWORD PTR [rsp+0x38],r10
  408ac3:	lea    r10,[rbp-0x880]
  408aca:	mov    QWORD PTR [rsp+0x40],r10
  408acf:	mov    r10,rdx
  408ad2:	mov    QWORD PTR [rsp+0x48],r10
  408ad7:	mov    r10,rdi
  408ada:	mov    QWORD PTR [rsp+0x50],r10
  408adf:	mov    r10,r8
  408ae2:	mov    QWORD PTR [rsp+0x58],r10
  408ae7:	mov    r10,rbx
  408aea:	mov    QWORD PTR [rsp+0x60],r10
  408aef:	mov    r10,rsi
  408af2:	mov    QWORD PTR [rsp+0x68],r10
  408af7:	mov    rdi,QWORD PTR [rsp+0x38]
  408afc:	mov    rsi,QWORD PTR [rsp+0x40]
  408b01:	mov    rdx,QWORD PTR [rsp+0x48]
  408b06:	mov    rcx,QWORD PTR [rsp+0x50]
  408b0b:	mov    r8,QWORD PTR [rsp+0x58]
  408b10:	mov    r9,QWORD PTR [rsp+0x60]
  408b15:	mov    r10,QWORD PTR [rsp+0x68]
  408b1a:	mov    QWORD PTR [rsp],r10
  408b1e:	xor    eax,eax
  408b20:	call   408628 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_112_105_99_107_>
  408b25:	lea    r11,[rbp-0x880]
  408b2c:	mov    rax,QWORD PTR [r11]
  408b2f:	mov    rdi,rax
  408b32:	lea    r11,[rbp-0x880]
  408b39:	mov    rax,QWORD PTR [r11+0x8]
  408b3d:	mov    rsi,rax
  408b40:	lea    r10,[rbp-0x840]
  408b47:	mov    r11,rdi
  408b4a:	mov    QWORD PTR [r10],r11
  408b4d:	lea    r10,[rbp-0x840]
  408b54:	mov    r11,rsi
  408b57:	mov    QWORD PTR [r10+0x8],r11
  408b5b:	mov    rdi,r12
  408b5e:	movabs rsi,0x8
  408b68:	mov    esi,esi
  408b6a:	lea    rdx,[rbp-0x840]
  408b71:	xor    eax,eax
  408b73:	call   41dad0 <p125_rt_ctor2>
  408b78:	mov    rdi,rax
  408b7b:	mov    rax,rdi
  408b7e:	mov    r12,QWORD PTR [rbp-0x10]
  408b82:	mov    rbx,QWORD PTR [rbp-0x8]
  408b86:	mov    r13,QWORD PTR [rbp-0x18]
  408b8a:	mov    rsp,rbp
  408b8d:	pop    rbp
  408b8e:	ret    
  408b8f:	mov    rdi,r12
  408b92:	movabs rsi,0x4
  408b9c:	mov    esi,esi
  408b9e:	xor    eax,eax
  408ba0:	call   4185b0 <p111_rt_fail>
  408ba5:	mov    QWORD PTR [rbp-0x8b0],rax
  408bac:	movabs rax,0x0
  408bb6:	mov    r12,QWORD PTR [rbp-0x10]
  408bba:	mov    rbx,QWORD PTR [rbp-0x8]
  408bbe:	mov    r13,QWORD PTR [rbp-0x18]
  408bc2:	mov    rsp,rbp
  408bc5:	pop    rbp
  408bc6:	ret    
  408bc7:	mov    rdi,r12
  408bca:	movabs rsi,0x4
  408bd4:	mov    esi,esi
  408bd6:	xor    eax,eax
  408bd8:	call   4185b0 <p111_rt_fail>
  408bdd:	mov    QWORD PTR [rbp-0x8b0],rax
  408be4:	movabs rax,0x0
  408bee:	mov    r12,QWORD PTR [rbp-0x10]
  408bf2:	mov    rbx,QWORD PTR [rbp-0x8]
  408bf6:	mov    r13,QWORD PTR [rbp-0x18]
  408bfa:	mov    rsp,rbp
  408bfd:	pop    rbp
  408bfe:	ret    

