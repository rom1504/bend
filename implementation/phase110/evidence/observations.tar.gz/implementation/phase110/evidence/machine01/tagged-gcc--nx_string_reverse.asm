
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c90 <nx_string_reverse>:
  401c90:	push   %r12
  401c92:	mov    %rsi,%rax
  401c95:	mov    %rdx,%r12
  401c98:	push   %rbp
  401c99:	shr    $0x28,%rax
  401c9d:	sub    $0x8,%rsp
  401ca1:	cmp    $0x2,%ax
  401ca5:	je     401ced <nx_string_reverse+0x5d>
  401ca7:	movzwl %ax,%edx
  401caa:	mov    %rdi,%rbp
  401cad:	cmp    $0x3,%rdx
  401cb1:	je     401cbe <nx_string_reverse+0x2e>
  401cb3:	jmp    401d00 <nx_string_reverse+0x70>
  401cb5:	nopl   (%rax)
  401cb8:	cmp    $0x3,%rdx
  401cbc:	jne    401d00 <nx_string_reverse+0x70>
  401cbe:	mov    %r12,%r8
  401cc1:	mov    $0x3,%edx
  401cc6:	xor    %ecx,%ecx
  401cc8:	mov    %rbp,%rdi
  401ccb:	callq  402d50 <nx_rt_rebuild2>
  401cd0:	xor    %esi,%esi
  401cd2:	mov    %rbp,%rdi
  401cd5:	mov    %rax,%r12
  401cd8:	callq  402d30 <nx_rt_fast_field>
  401cdd:	mov    %rax,%rsi
  401ce0:	shr    $0x28,%rax
  401ce4:	movzwl %ax,%edx
  401ce7:	cmp    $0x2,%ax
  401ceb:	jne    401cb8 <nx_string_reverse+0x28>
  401ced:	add    $0x8,%rsp
  401cf1:	mov    %r12,%rax
  401cf4:	pop    %rbp
  401cf5:	pop    %r12
  401cf7:	retq   
  401cf8:	nopl   0x0(%rax,%rax,1)
  401d00:	add    $0x8,%rsp
  401d04:	mov    %rbp,%rdi
  401d07:	mov    $0x1,%esi
  401d0c:	pop    %rbp
  401d0d:	pop    %r12
  401d0f:	jmpq   402580 <nx_rt_fail>

Disassembly of section .fini:
