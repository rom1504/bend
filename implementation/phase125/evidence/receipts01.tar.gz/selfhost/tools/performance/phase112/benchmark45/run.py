#!/usr/bin/env python3
"""Bind complete product receipts, or measure already-built matched programs.

Only root launches measure, under the serial CPU3 process-tree guard.
"""
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import statistics
import subprocess
import sys
import time

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[4]


def pin(path):
    path = Path(path).resolve()
    digest = hashlib.sha256()
    size = 0
    with path.open('rb') as stream:
        for data in iter(lambda: stream.read(1024 * 1024), b''):
            digest.update(data)
            size += len(data)
    return dict(file=str(path), bytes=size, sha256=digest.hexdigest())


def verify(row):
    actual = pin(ROOT / row['file'])
    if any(actual[k] != row[k] for k in ('bytes', 'sha256')):
        raise ValueError('Changed input: ' + row['file'])
    return Path(actual['file'])


def read(path):
    return json.loads(Path(path).read_text())


def save(path, value):
    path = Path(path)
    temporary = path.with_suffix('.tmp')
    temporary.write_text(json.dumps(value, indent=2) + '\n')
    temporary.replace(path)


def observation(stdout, stderr, code, case, wall):
    expected = (case['expectedStdout'] + str(case['warmups']) + '\n' + str(case['repetitions']) + '\n').encode()
    if code != 0 or stderr or not stdout.startswith(expected):
        raise ValueError('Program failed complete-output or success-count check')
    suffix = stdout[len(expected):]
    if not suffix.endswith(b'\n') or not suffix[:-1] or any(x not in b'0123456789' for x in suffix[:-1]):
        raise ValueError('Invalid exact elapsed-milliseconds suffix')
    elapsed = int(suffix[:-1])
    if elapsed > wall * 1000 + 2:
        raise ValueError('In-program interval exceeds process wall clock')
    return elapsed


def api_producer(emission):
    by_path = {str((ROOT / x['file']).resolve()): x for x in emission['inputs']}
    apis = [x for x in emission['inputs'] if Path(x['file']).name == 'api.mjs']
    if len(apis) != 1:
        raise ValueError('Hosted emission must bind one checked api.mjs')
    api = pin(verify(apis[0]))
    report_path = str(Path(api['file']).parent / 'report.json')
    receipt = by_path.get(report_path)
    if not receipt:
        raise ValueError('Hosted emission lacks checked API receipt pin')
    checked = read(verify(receipt))
    if (not checked.get('complete') or not checked.get('checked') or
            'p111_compile_source' not in checked.get('exports', []) or checked['api'] != api):
        raise ValueError('Complete checked p111_compile_source API required')
    sources = [str(Path(x).resolve()) for x in checked['command'] if x.endswith('.bend')]
    source_inputs = {str(Path(x['file']).resolve()): x for x in checked['inputs']}
    if len(sources) != 1 or sources[0] not in source_inputs:
        raise ValueError('Checked API receipt must identify its compiler source')
    source = pin(verify(source_inputs[sources[0]]))
    return dict(api=api, apiReport=pin(report_path), compilerSource=source)


def bind(args, manifest):
    if args.label == 'upstream' or not re.fullmatch(r'[a-z][a-z0-9_-]*', args.label):
        raise ValueError('Upstream is fixed by manifest')
    reports = read(args.reports)
    cases = {x['name']: x for x in manifest['cases']}
    requested = args.names or list(cases)
    if len(set(requested)) != len(requested) or set(requested) - set(cases):
        raise ValueError('Unknown or duplicate binding case names')
    if set(reports) - set(cases) or not set(requested).issubset(reports):
        raise ValueError('Binding map must contain every explicitly requested frozen case')
    if not args.names and set(reports) != set(cases):
        raise ValueError('Default binding requires all frozen corpus cases; use --names for an explicit subset')
    inputs = [pin(__file__), pin(HERE / 'manifest01.json'), pin(args.reports)]
    products = {}
    for name in requested:
        entry = reports[name]
        report_path = (ROOT / (entry['emission'] if isinstance(entry, dict) else entry)).resolve()
        emission = read(report_path)
        if not emission.get('complete') or emission.get('mode') != 'cache':
            raise ValueError('Complete cached native emission/build required: ' + name)
        if not emission.get('image') and not emission.get('sourceChecked'):
            raise ValueError('Hosted candidate must have an actual checked-source emission receipt')
        expected_source = cases[name]['source']
        by_path = {str((ROOT / row['file']).resolve()): row for row in emission['inputs']}
        for expected in [expected_source, manifest['base'], manifest['carrier']]:
            actual = by_path.get(expected['file'])
            if not actual or any(actual[k] != expected[k] for k in ('bytes', 'sha256')):
                raise ValueError('Unmatched source/Base/carrier: ' + name)
            verify(actual)
        producer = {} if emission.get('image') else api_producer(emission)
        if args.label == 'phase111':
            if emission.get('image'):
                if emission['image'] != manifest['phase111Compiler']:
                    raise ValueError('Phase111 native binding must use frozen qualified successor')
            else:
                selection = next(x for x in manifest['inputs'] if x['file'].endswith('/implementation/phase111/selection.json'))
                qualified_source = read(verify(selection))['source']
                if any(producer['compilerSource'][k] != qualified_source[k] for k in ['bytes', 'sha256']):
                    raise ValueError('Phase111 API must compile exact qualified Phase111 source')
        qbe = verify(emission['product'])
        if isinstance(entry, dict):
            build_path = (ROOT / entry['build']).resolve()
        else:
            build_path = verify(emission['buildReport'])
        built = read(build_path)
        if not built.get('complete') or built.get('perProgramC') or built.get('cproc'):
            raise ValueError('Complete direct-QBE build required')
        binary = verify(built['binary'])
        jobs = {row['label']: row for row in built['jobs']}
        qcmd, acmd, lcmd = [jobs[x]['command'] for x in ['qbe', 'assemble', 'link']]
        if (len(qcmd) != 6 or qcmd[1:4] != ['-t', 'amd64_sysv', '-o'] or qcmd[-1] != str(qbe) or
                len(acmd) != 4 or acmd[1] != '-o' or acmd[3] != qcmd[4] or
                len(lcmd) != 8 or lcmd[1] != '-no-pie' or lcmd[2] != acmd[2] or
                lcmd[-4:-2] != ['-pthread', '-lm'] or lcmd[-1] != str(binary)):
            raise ValueError('Unexpected QBE/assembler/link flags')
        runtime_path = lcmd[3]
        build_inputs = {str((ROOT / row['file']).resolve()): row for row in built['inputs']}
        for item in build_inputs.values():
            verify(item)
        toolchain = {key: build_inputs[str(Path(command[0]).resolve())]
                     for key, command in [('qbe', qcmd), ('assembler', acmd), ('linker', lcmd)]}
        for key, row in toolchain.items():
            verify(row)
            if row != manifest['directToolchain'][key]:
                raise ValueError('Unmatched direct toolchain ' + key)
        runtime = build_inputs[str(Path(runtime_path).resolve())]
        verify(runtime)
        if args.label == 'phase111' and runtime != manifest['phase111Runtime']:
            raise ValueError('Unmatched Phase111 runtime')
        record = dict(binary=pin(binary), source=expected_source, emission=pin(report_path),
                      build=pin(build_path), qbe=emission['product'], runtime=runtime,
                      compiler=emission.get('image'), toolchain=toolchain,
                      producerKind=emission.get('kind'), compilerHost=emission.get('compilerHost'),
                      buildCommands=[qcmd, acmd, lcmd], **producer)
        products[name] = record
        inputs += [record['binary'], record['emission'], record['build'], record['qbe'], runtime]
        inputs += list(producer.values())
    for item in inputs:
        verify(item)
    if args.out.exists():
        raise ValueError('Fresh binding path required')
    args.out.parent.mkdir(parents=True, exist_ok=True)
    save(args.out, dict(kind='phase112-matched-product-binding', complete=True, label=args.label,
                       manifest=pin(HERE / 'manifest01.json'), inputs=inputs, products=products,
                       requestedNames=requested, qualifiedNames=list(products),
                       fullFrozenNames=list(cases), missingFromFrozen=[x for x in cases if x not in products],
                       fullFrozenQualified=len(products) == len(cases),
                       targetsRun=False, scope='Source-only receipt and binary authentication; no execution or timing.'))
    print(json.dumps(dict(complete=True, targetsRun=False, binding=pin(args.out))))


def summarize(records, roles, requested, rounds, frozen):
    coverage, per_program = {}, {}
    for role, products in roles.items():
        qualified = [name for name in requested if len([r for r in records if r['case'] == name and r['role'] == role]) == rounds and
                     all(r.get('correct') and r.get('qualified') for r in records if r['case'] == name and r['role'] == role)]
        coverage[role] = dict(requested=requested, qualified=qualified,
            missingProducts=[name for name in requested if name not in products],
            availableNotQualified=[name for name in requested if name in products and name not in qualified],
            missingFromFrozen=[name for name in frozen if name not in products],
            excludedByRequest=[name for name in frozen if name not in requested],
            requestedCount=len(requested), qualifiedCount=len(qualified),
            fullRequestedQualified=len(qualified) == len(requested))
    for name in requested:
        samples = {role: [r['elapsedMs'] for r in records if r['case'] == name and r['role'] == role]
                   for role in roles if name in coverage[role]['qualified']}
        medians = {role: statistics.median(values) for role, values in samples.items()}
        per_program[name] = dict(samplesMs=samples, mediansMs=medians,
            missingProducts=[role for role in roles if name not in roles[role]],
            ratiosToUpstream={role: value / medians['upstream'] for role, value in medians.items()} if 'upstream' in medians else {},
            ratiosToPhase111={role: value / medians['phase111'] for role, value in medians.items()} if 'phase111' in medians else {})
    pairwise, geomeans = {}, {}
    for denominator in ['upstream', 'phase111']:
        if denominator not in roles:
            continue
        pairwise[denominator], geomeans[denominator] = {}, {}
        for role in roles:
            available = [name for name in requested if name in roles[role] and name in roles[denominator]]
            matched = [name for name in requested if name in coverage[role]['qualified'] and name in coverage[denominator]['qualified']]
            missing = [name for name in requested if name not in matched]
            value = (math.exp(sum(math.log(per_program[name]['mediansMs'][role] / per_program[name]['mediansMs'][denominator])
                                 for name in matched) / len(matched)) if matched else None)
            pairwise[denominator][role] = dict(requested=requested, qualified=matched, missing=missing,
                requestedCount=len(requested), qualifiedCount=len(matched), fullRequestedQualified=not missing,
                geomeanRatio=value if not missing else None,
                availablePairCases=available, availablePairComplete=matched == available,
                matchedSubsetGeomeanRatio=value if matched == available else None,
                scope='Matched named subset only; never interpreted as the requested full set when missing is nonempty.')
            geomeans[denominator][role] = value if not missing else None
    return dict(coverage=coverage, perProgram=per_program, pairwise=pairwise, geomeanRatios=geomeans,
                fullRequestedQualification=all(x['fullRequestedQualified'] for x in coverage.values()),
                fullMeasuredCorpus=len(requested) == len(frozen) and all(x['fullRequestedQualified'] for x in coverage.values()))


def measure(args, manifest):
    if sorted(os.sched_getaffinity(0)) != [3]:
        raise ValueError('Root must bind this supervisor to CPU3')
    out = args.out.resolve()
    if out.exists() or not out.is_relative_to(ROOT / 'selfhost/build/phase112'):
        raise ValueError('Fresh Phase112 output directory required')
    inputs = [pin(__file__), pin(HERE / 'manifest01.json'), *manifest['inputs']]
    roles = {'upstream': {c['name']: c['upstream'] for c in manifest['cases']}}
    for path in args.bindings:
        binding = read(path)
        if not binding.get('complete') or binding.get('kind') != 'phase112-matched-product-binding':
            raise ValueError('Complete matched product binding required')
        if binding['manifest'] != pin(HERE / 'manifest01.json') or binding['label'] in roles:
            raise ValueError('Wrong manifest or duplicate product role')
        for item in binding['inputs']:
            verify(item)
        inputs += [pin(path), *binding['inputs']]
        roles[binding['label']] = binding['products']
    if any(set(products) - {x['name'] for x in manifest['cases']} for products in roles.values()):
        raise ValueError('Binding contains unknown frozen cases')
    cases = manifest['cases']
    profile = None
    minimum_ms = manifest['minimumMs']
    if args.profile:
        profile = read(args.profile)
        if (profile.get('kind') != 'phase112-frozen-runtime-profile' or
                profile.get('manifest') != pin(HERE / 'manifest01.json') or
                set(profile['cases']) != {x['name'] for x in cases}):
            raise ValueError('Profile must bind exact manifest and all frozen corpus cases cases')
        minimum_ms = profile['minimumMs']
        if type(minimum_ms) is not int or minimum_ms <= 0:
            raise ValueError('Positive profile minimum required')
        for counts in profile['cases'].values():
            if set(counts) != {'repetitions', 'warmups'} or any(type(n) is not int or not 0 < n < 2**32 for n in counts.values()):
                raise ValueError('Profile may change only bounded positive repetition/warmup counts')
        cases = [dict(case, **profile['cases'][case['name']]) for case in cases]
        inputs.append(pin(args.profile))
    if args.names:
        names = set(args.names)
        cases = [c for c in cases if c['name'] in names]
        if len(cases) != len(args.names):
            raise ValueError('Unknown or duplicate case names')
    for case in cases:
        for role, products in roles.items():
            if case['name'] in products:
                verify(products[case['name']]['binary'])
    for item in inputs:
        verify(item)
    out.mkdir(parents=True)
    (out / 'method.py').write_bytes(Path(__file__).read_bytes())
    (out / 'manifest.json').write_bytes((HERE / 'manifest01.json').read_bytes())
    if args.profile:
        (out / 'timing-profile.json').write_bytes(args.profile.read_bytes())
    excluded = {x['name'] for x in manifest['zeroWorkExclusions']}
    report = dict(kind='phase112-matched-program-runtime', version=3, complete=False, executionComplete=False, inputs=inputs,
                  roles=list(roles), cases=[c['name'] for c in cases], records=[], rounds=args.rounds,
                  started=time.time(), cpuAffinity=[3], qualifiedMinimumMs=minimum_ms,
                  timingProfile=pin(args.profile) if args.profile else None,
                  timingProfileScope=profile.get('scope') if profile else 'Original Phase93 counts and 100ms minimum.',
                  producerKinds={role: sorted({x.get('producerKind', 'pinned-upstream-C-Clang') for x in products.values()})
                                 for role, products in roles.items()},
                  budgetSeconds=args.budget_seconds, sampleDeadlineSeconds=args.seconds,
                  zeroWorkExclusions=manifest['zeroWorkExclusions'],
                  clock=manifest['clock'], acquisitionIncluded=False,
                  scope='Exact same existing Phase93 batch sources, inputs, counts and one-CPU flags across roles. Upstream retains pinned Clang -O3; direct roles retain QBE/tool/link flags. Full original45 batch corpus: 44 measurable fixed-input points plus named zero-work correctness control.')
    start = time.monotonic()
    def persist():
        report['wallSeconds'] = time.monotonic() - start
        measured_names = [name for name in report['cases'] if name not in excluded]
        report.update(summarize(report['records'], roles, measured_names, args.rounds,
                                [x['name'] for x in manifest['cases'] if x['name'] not in excluded]))
        report['requestedCorpusNames'] = report['cases']
        report['ratioCaseNames'] = measured_names
        report['requestedCorpusCount'] = len(report['cases'])
        report['ratioCaseCount'] = len(measured_names)
        report['zeroWorkControlRecords'] = [x for x in report['records'] if x['case'] in excluded]
        report['fullCorpusOutputQualified'] = all(
            len([r for r in report['records'] if r['case'] == name and r['role'] == role and r.get('correct')]) == args.rounds
            for name in report['cases'] for role in roles)
        report['partitionNames'] = manifest['partitions']
        heldout = [name for name in measured_names if name in manifest['partitions']['heldoutMeasurable38']]
        report['phase112Heldout'] = summarize(report['records'], roles, heldout, args.rounds,
                                              manifest['partitions']['heldoutMeasurable38'])
        report['phase112Heldout']['scope'] = manifest['heldoutScope']
        save(out / 'report.json', report)
    persist()
    try:
        for index, case in enumerate(cases):
            name = case['name']
            for rnd in range(args.rounds):
                order = [role for role, products in roles.items() if name in products]
                shift = (index + rnd) % len(order)
                order = order[shift:] + order[:shift]
                for role in order:
                    binary = verify(roles[role][name]['binary'])
                    command = [str(binary), '--threads', '1', '--gpu', 'off', '--',
                               str(case['repetitions']), str(case['warmups']), *map(str, case['runtimeArgs'])]
                    stem = out / (name + '-' + str(rnd + 1) + '-' + role)
                    row = dict(case=name, role=role, round=rnd + 1, command=command,
                               binary=pin(binary), repetitions=case['repetitions'], warmups=case['warmups'],
                               correct=False, qualified=False)
                    report['records'].append(row)
                    remaining = args.budget_seconds - (time.monotonic() - start)
                    if remaining <= 0:
                        raise TimeoutError('Campaign budget exhausted; partial records are not an aggregate')
                    row['limitSeconds'] = min(args.seconds, remaining)
                    persist()
                    t0 = time.monotonic()
                    with stem.with_suffix('.stdout').open('xb') as so, stem.with_suffix('.stderr').open('xb') as se:
                        child = subprocess.Popen(command, cwd=ROOT, stdout=so, stderr=se, start_new_session=True)
                        try:
                            child.wait(timeout=row['limitSeconds'])
                        except BaseException as error:
                            if child.poll() is None:
                                os.killpg(child.pid, signal.SIGKILL)
                            child.wait()
                            row['timedOut'] = isinstance(error, subprocess.TimeoutExpired)
                            raise
                        finally:
                            row.update(processSeconds=time.monotonic() - t0, exitCode=child.returncode,
                                       stdout=pin(stem.with_suffix('.stdout')), stderr=pin(stem.with_suffix('.stderr')))
                            persist()
                    elapsed = observation(Path(row['stdout']['file']).read_bytes(), Path(row['stderr']['file']).read_bytes(),
                                          row['exitCode'], case, row['processSeconds'])
                    row.update(elapsedMs=elapsed, correct=True, qualified=name in excluded or elapsed >= minimum_ms,
                               ratioEligible=name not in excluded)
                    persist()
                    print(json.dumps(dict(case=name, role=role, round=rnd + 1, elapsedMs=elapsed)), flush=True)
                    if not row['qualified']:
                        raise ValueError('Below frozen minimum interval; preserve attempt, no automatic retuning or zero-work classification')
        report['executionComplete'] = True
        report['requestedCount'] = len(cases)
        report['ratioDirection'] = 'role milliseconds / comparator milliseconds; below 1 is faster'
        for item in inputs:
            verify(item)
        report['complete'] = True
    except BaseException as error:
        report['error'] = repr(error)
    finally:
        report['finished'] = time.time()
        persist()
    print(json.dumps(dict(complete=report['complete'], geomeanRatios=report.get('geomeanRatios'))), flush=True)
    return 0 if report['complete'] else 1


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest='action', required=True)
    b = commands.add_parser('bind')
    b.add_argument('--label', required=True)
    b.add_argument('--reports', type=Path, required=True)
    b.add_argument('--out', type=Path, required=True)
    b.add_argument('--names', nargs='+', help='Explicit subset; default requires all frozen corpus cases')
    b.add_argument('--names-file', type=Path)
    m = commands.add_parser('measure')
    m.add_argument('--bindings', type=Path, nargs='+', required=True)
    m.add_argument('--out', type=Path, required=True)
    m.add_argument('--names', nargs='+')
    m.add_argument('--names-file', type=Path)
    m.add_argument('--rounds', type=int, default=3)
    m.add_argument('--seconds', type=int, default=30)
    m.add_argument('--budget-seconds', type=int, default=300)
    m.add_argument('--profile', type=Path, help='Separately frozen matched repetition/warmup profile')
    args = parser.parse_args()
    if args.names_file:
        if args.names:
            raise ValueError('Use names or names-file, not both')
        args.names = args.names_file.read_text().split()
        if not args.names:
            raise ValueError('Names file must be nonempty')
    manifest = read(HERE / 'manifest01.json')
    if args.action == 'bind':
        return bind(args, manifest) or 0
    if args.rounds < 3 or args.seconds <= 0 or args.budget_seconds <= 0:
        raise ValueError('At least three rounds and positive deadline required')
    return measure(args, manifest)


if __name__ == '__main__':
    raise SystemExit(main())
