
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402530 <nx_rt_take2>:
  402530:	push   %r13
  402532:	push   %r12
  402534:	sub    $0x8,%rsp
  402538:	cmpb   $0x0,0x4c41(%rip)        # 407180 <nx_active>
  40253f:	je     40254d <nx_rt_take2+0x1d>
  402541:	lea    0x4c58(%rip),%rax        # 4071a0 <nx_context>
  402548:	cmp    %rax,%rdi
  40254b:	je     402560 <nx_rt_take2+0x30>
  40254d:	lea    0x1adf(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402554:	callq  4019d0 <err_fail>
  402559:	nopl   0x0(%rax)
  402560:	mov    0x4c5a(%rip),%eax        # 4071c0 <nx_context+0x20>
  402566:	mov    0x4c33(%rip),%rdi        # 4071a0 <nx_context>
  40256d:	test   %eax,%eax
  40256f:	jne    4026a9 <nx_rt_take2+0x179>
  402575:	mov    %rsi,%r12
  402578:	callq  401b00 <nx_id.isra.0>
  40257d:	and    $0xfffffffd,%eax
  402580:	cmp    $0x1,%eax
  402583:	jne    40269d <nx_rt_take2+0x16d>
  402589:	mov    0x4c10(%rip),%rdi        # 4071a0 <nx_context>
  402590:	mov    0x4c11(%rip),%rsi        # 4071a8 <nx_context+0x8>
  402597:	movabs $0xffffffffff,%rax
  4025a1:	and    %r12,%rax
  4025a4:	lea    0x0(,%rax,8),%rcx
  4025ac:	lea    (%rdi,%rcx,1),%rdx
  4025b0:	test   %r12,%r12
  4025b3:	js     402620 <nx_rt_take2+0xf0>
  4025b5:	mov    (%rdx),%rdx
  4025b8:	mov    %rdx,0x4bf1(%rip)        # 4071b0 <nx_context+0x10>
  4025bf:	mov    0x8(%rdi,%rcx,1),%rdx
  4025c4:	mov    %rdx,0x4bed(%rip)        # 4071b8 <nx_context+0x18>
  4025cb:	cmp    $0x310817f,%rax
  4025d1:	ja     4025f0 <nx_rt_take2+0xc0>
  4025d3:	movl   $0x3,0x4be3(%rip)        # 4071c0 <nx_context+0x20>
  4025dd:	add    $0x8,%rsp
  4025e1:	xor    %eax,%eax
  4025e3:	pop    %r12
  4025e5:	pop    %r13
  4025e7:	retq   
  4025e8:	nopl   0x0(%rax,%rax,1)
  4025f0:	mov    0x8(%rsi),%rdx
  4025f4:	mov    %rdx,(%rdi,%rax,8)
  4025f8:	mov    0x4bda(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4025fe:	mov    %rax,0x8(%rsi)
  402602:	mov    0x108(%rsi),%rax
  402609:	add    $0x2,%rax
  40260d:	mov    %rax,0x108(%rsi)
  402614:	cmp    %rdx,%rax
  402617:	jb     4025d3 <nx_rt_take2+0xa3>
  402619:	jmpq   401567 <nx_rt_take2.cold>
  40261e:	xchg   %ax,%ax
  402620:	mov    0x4(%rdx),%ecx
  402623:	mov    (%rdx),%r8d
  402626:	shl    $0x20,%rcx
  40262a:	or     %r8,%rcx
  40262d:	mov    %rcx,%r13
  402630:	and    $0xffffff,%ecx
  402636:	shr    $0x18,%r13
  40263a:	lea    0x0(,%r13,8),%r8
  402642:	lea    (%rdi,%r8,1),%r9
  402646:	lea    0x8(%rdi,%r8,1),%r8
  40264b:	cmp    $0x1,%rcx
  40264f:	jne    401582 <nx_rt_take2.cold+0x1b>
  402655:	mov    (%rdx),%ecx
  402657:	mov    (%r9),%rcx
  40265a:	mov    %rcx,0x4b4f(%rip)        # 4071b0 <nx_context+0x10>
  402661:	mov    (%r8),%rcx
  402664:	mov    %rcx,0x4b4d(%rip)        # 4071b8 <nx_context+0x18>
  40266b:	mov    (%rsi),%rcx
  40266e:	mov    %rcx,(%rdx)
  402671:	mov    0x4b61(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402677:	mov    %rax,(%rsi)
  40267a:	mov    0x100(%rsi),%rax
  402681:	add    $0x1,%rax
  402685:	mov    %rax,0x100(%rsi)
  40268c:	cmp    %rdx,%rax
  40268f:	jae    401576 <nx_rt_take2.cold+0xf>
  402695:	mov    %r13,%rax
  402698:	jmpq   4025cb <nx_rt_take2+0x9b>
  40269d:	lea    0x1c74(%rip),%rdi        # 404318 <_IO_stdin_used+0x318>
  4026a4:	callq  4019d0 <err_fail>
  4026a9:	lea    0x1c40(%rip),%rdi        # 4042f0 <_IO_stdin_used+0x2f0>
  4026b0:	callq  4019d0 <err_fail>

Disassembly of section .fini:
