
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402bc0 <nx_rt_fast_take2>:
  402bc0:	movabs $0xffffffffff,%rax
  402bca:	push   %r12
  402bcc:	and    %rsi,%rax
  402bcf:	push   %rbp
  402bd0:	push   %rbx
  402bd1:	mov    %rdi,%rbx
  402bd4:	mov    (%rdi),%rdi
  402bd7:	lea    0x0(,%rax,8),%rcx
  402bdf:	mov    0x8(%rbx),%rbp
  402be3:	lea    (%rdi,%rcx,1),%rdx
  402be7:	test   %rsi,%rsi
  402bea:	js     402c58 <nx_rt_fast_take2+0x98>
  402bec:	mov    (%rdx),%rdx
  402bef:	mov    %rdx,0x10(%rbx)
  402bf3:	mov    0x8(%rdi,%rcx,1),%rdx
  402bf8:	mov    %rdx,0x18(%rbx)
  402bfc:	cmp    $0x310817f,%rax
  402c02:	ja     402c18 <nx_rt_fast_take2+0x58>
  402c04:	movl   $0x3,0x20(%rbx)
  402c0b:	xor    %eax,%eax
  402c0d:	pop    %rbx
  402c0e:	pop    %rbp
  402c0f:	pop    %r12
  402c11:	retq   
  402c12:	nopw   0x0(%rax,%rax,1)
  402c18:	mov    0x8(%rbp),%rdx
  402c1c:	mov    %rdx,(%rdi,%rax,8)
  402c20:	mov    0x3e5b2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402c26:	mov    %rax,0x8(%rbp)
  402c2a:	mov    0x108(%rbp),%rax
  402c31:	add    $0x2,%rax
  402c35:	mov    %rax,0x108(%rbp)
  402c3c:	cmp    %rdx,%rax
  402c3f:	jae    40160f <nx_rt_fast_take2.cold>
  402c45:	movl   $0x3,0x20(%rbx)
  402c4c:	xor    %eax,%eax
  402c4e:	pop    %rbx
  402c4f:	pop    %rbp
  402c50:	pop    %r12
  402c52:	retq   
  402c53:	nopl   0x0(%rax,%rax,1)
  402c58:	mov    0x4(%rdx),%ecx
  402c5b:	mov    (%rdx),%r8d
  402c5e:	shl    $0x20,%rcx
  402c62:	or     %r8,%rcx
  402c65:	mov    %rcx,%r12
  402c68:	and    $0xffffff,%ecx
  402c6e:	shr    $0x18,%r12
  402c72:	lea    0x0(,%r12,8),%r8
  402c7a:	lea    (%rdi,%r8,1),%r9
  402c7e:	lea    0x8(%rdi,%r8,1),%r8
  402c83:	cmp    $0x1,%rcx
  402c87:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  402c8d:	mov    (%rdx),%ecx
  402c8f:	mov    (%r9),%rcx
  402c92:	mov    %rcx,0x10(%rbx)
  402c96:	mov    (%r8),%rcx
  402c99:	mov    %rcx,0x18(%rbx)
  402c9d:	mov    0x0(%rbp),%rcx
  402ca1:	mov    %rcx,(%rdx)
  402ca4:	mov    0x3e52e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402caa:	mov    %rax,0x0(%rbp)
  402cae:	mov    0x100(%rbp),%rax
  402cb5:	add    $0x1,%rax
  402cb9:	mov    %rax,0x100(%rbp)
  402cc0:	cmp    %rdx,%rax
  402cc3:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402cc9:	mov    %r12,%rax
  402ccc:	jmpq   402bfc <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
