
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	endbr64 
  401c04:	push   %rbp
  401c05:	mov    %rsp,%rbp
  401c08:	sub    $0x8,%rsp
  401c0c:	push   %rbx
  401c0d:	push   %r12
  401c0f:	push   %r13
  401c11:	mov    %rdx,%rax
  401c14:	mov    %rax,%r13
  401c17:	nopw   0x0(%rax,%rax,1)
  401c20:	mov    %rsi,%r12
  401c23:	mov    %rdi,%rbx
  401c26:	callq  402a80 <nx_rt_fast_id>
  401c2b:	mov    %r13,%rdx
  401c2e:	mov    %r12,%rsi
  401c31:	mov    %rbx,%rdi
  401c34:	cmp    $0x0,%eax
  401c37:	je     401c80 <nx_list_reverse+0x80>
  401c39:	cmp    $0x1,%eax
  401c3c:	jne    401c74 <nx_list_reverse+0x74>
  401c3e:	mov    %rdx,%r8
  401c41:	mov    $0x0,%ecx
  401c46:	mov    $0x1,%edx
  401c4b:	mov    %rdi,%rbx
  401c4e:	callq  402d50 <nx_rt_rebuild2>
  401c53:	mov    %rbx,%rdi
  401c56:	mov    %rax,%r12
  401c59:	mov    $0x0,%esi
  401c5e:	mov    %rdi,%rbx
  401c61:	callq  402d30 <nx_rt_fast_field>
  401c66:	mov    %r12,%rdx
  401c69:	mov    %rbx,%rdi
  401c6c:	mov    %rax,%rsi
  401c6f:	mov    %rdx,%r13
  401c72:	jmp    401c20 <nx_list_reverse+0x20>
  401c74:	mov    $0x1,%esi
  401c79:	callq  402580 <nx_rt_fail>
  401c7e:	jmp    401c83 <nx_list_reverse+0x83>
  401c80:	mov    %rdx,%rax
  401c83:	pop    %r13
  401c85:	pop    %r12
  401c87:	pop    %rbx
  401c88:	leaveq 
  401c89:	retq   

Disassembly of section .fini:
