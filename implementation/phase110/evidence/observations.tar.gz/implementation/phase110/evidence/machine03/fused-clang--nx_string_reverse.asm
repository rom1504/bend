
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e80 <nx_string_reverse>:
  401e80:	push   %r15
  401e82:	push   %r14
  401e84:	push   %rbx
  401e85:	mov    %rdx,%r14
  401e88:	mov    %rsi,%r15
  401e8b:	mov    %rdi,%rbx
  401e8e:	xchg   %ax,%ax
  401e90:	mov    %rbx,%rdi
  401e93:	mov    %r15,%rsi
  401e96:	callq  402c20 <nx_rt_fast_id>
  401e9b:	cmp    $0x3,%eax
  401e9e:	jne    401ec7 <nx_string_reverse+0x47>
  401ea0:	mov    %rbx,%rdi
  401ea3:	mov    %r15,%rsi
  401ea6:	mov    $0x3,%edx
  401eab:	xor    %ecx,%ecx
  401ead:	mov    %r14,%r8
  401eb0:	callq  402ef0 <nx_rt_rebuild2>
  401eb5:	mov    %rax,%r14
  401eb8:	mov    %rbx,%rdi
  401ebb:	xor    %esi,%esi
  401ebd:	callq  402ed0 <nx_rt_fast_field>
  401ec2:	mov    %rax,%r15
  401ec5:	jmp    401e90 <nx_string_reverse+0x10>
  401ec7:	cmp    $0x2,%eax
  401eca:	jne    401ed5 <nx_string_reverse+0x55>
  401ecc:	mov    %r14,%rax
  401ecf:	pop    %rbx
  401ed0:	pop    %r14
  401ed2:	pop    %r15
  401ed4:	retq   
  401ed5:	mov    %rbx,%rdi
  401ed8:	mov    $0x1,%esi
  401edd:	pop    %rbx
  401ede:	pop    %r14
  401ee0:	pop    %r15
  401ee2:	jmpq   4026d0 <nx_rt_fail>

Disassembly of section .fini:
