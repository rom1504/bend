
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402db0 <nx_rt_fast_take2>:
  402db0:	movabs $0xffffffffff,%rax
  402dba:	push   %r12
  402dbc:	and    %rsi,%rax
  402dbf:	push   %rbp
  402dc0:	push   %rbx
  402dc1:	mov    %rdi,%rbx
  402dc4:	mov    (%rdi),%rdi
  402dc7:	lea    0x0(,%rax,8),%rcx
  402dcf:	mov    0x8(%rbx),%rbp
  402dd3:	lea    (%rdi,%rcx,1),%rdx
  402dd7:	test   %rsi,%rsi
  402dda:	js     402e48 <nx_rt_fast_take2+0x98>
  402ddc:	mov    (%rdx),%rdx
  402ddf:	mov    %rdx,0x10(%rbx)
  402de3:	mov    0x8(%rdi,%rcx,1),%rdx
  402de8:	mov    %rdx,0x18(%rbx)
  402dec:	cmp    $0x310817f,%rax
  402df2:	ja     402e08 <nx_rt_fast_take2+0x58>
  402df4:	movl   $0x3,0x20(%rbx)
  402dfb:	xor    %eax,%eax
  402dfd:	pop    %rbx
  402dfe:	pop    %rbp
  402dff:	pop    %r12
  402e01:	retq   
  402e02:	nopw   0x0(%rax,%rax,1)
  402e08:	mov    0x8(%rbp),%rdx
  402e0c:	mov    %rdx,(%rdi,%rax,8)
  402e10:	mov    0x3e3c2(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e16:	mov    %rax,0x8(%rbp)
  402e1a:	mov    0x108(%rbp),%rax
  402e21:	add    $0x2,%rax
  402e25:	mov    %rax,0x108(%rbp)
  402e2c:	cmp    %rdx,%rax
  402e2f:	jae    4015fe <nx_rt_fast_take2.cold>
  402e35:	movl   $0x3,0x20(%rbx)
  402e3c:	xor    %eax,%eax
  402e3e:	pop    %rbx
  402e3f:	pop    %rbp
  402e40:	pop    %r12
  402e42:	retq   
  402e43:	nopl   0x0(%rax,%rax,1)
  402e48:	mov    0x4(%rdx),%ecx
  402e4b:	mov    (%rdx),%r8d
  402e4e:	shl    $0x20,%rcx
  402e52:	or     %r8,%rcx
  402e55:	mov    %rcx,%r12
  402e58:	and    $0xffffff,%ecx
  402e5e:	shr    $0x18,%r12
  402e62:	lea    0x0(,%r12,8),%r8
  402e6a:	lea    (%rdi,%r8,1),%r9
  402e6e:	lea    0x8(%rdi,%r8,1),%r8
  402e73:	cmp    $0x1,%rcx
  402e77:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  402e7d:	mov    (%rdx),%ecx
  402e7f:	mov    (%r9),%rcx
  402e82:	mov    %rcx,0x10(%rbx)
  402e86:	mov    (%r8),%rcx
  402e89:	mov    %rcx,0x18(%rbx)
  402e8d:	mov    0x0(%rbp),%rcx
  402e91:	mov    %rcx,(%rdx)
  402e94:	mov    0x3e33e(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e9a:	mov    %rax,0x0(%rbp)
  402e9e:	mov    0x100(%rbp),%rax
  402ea5:	add    $0x1,%rax
  402ea9:	mov    %rax,0x100(%rbp)
  402eb0:	cmp    %rdx,%rax
  402eb3:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  402eb9:	mov    %r12,%rax
  402ebc:	jmpq   402dec <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
