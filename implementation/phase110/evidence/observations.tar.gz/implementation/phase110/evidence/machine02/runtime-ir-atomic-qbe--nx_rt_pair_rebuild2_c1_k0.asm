
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403d10 <nx_rt_pair_rebuild2_c1_k0>:
  403d10:	push   %r15
  403d12:	push   %r14
  403d14:	push   %r13
  403d16:	push   %r12
  403d18:	mov    %rdx,%r12
  403d1b:	push   %rbp
  403d1c:	push   %rbx
  403d1d:	movabs $0xffffffffff,%rbx
  403d27:	and    %rsi,%rbx
  403d2a:	lea    0x0(,%rbx,8),%rdx
  403d32:	sub    $0x18,%rsp
  403d36:	mov    (%rdi),%rbp
  403d39:	mov    0x8(%rdi),%r15
  403d3d:	lea    0x0(%rbp,%rdx,1),%rax
  403d42:	test   %rsi,%rsi
  403d45:	js     403e00 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  403d4b:	mov    (%rax),%r14
  403d4e:	mov    0x8(%rbp,%rdx,1),%r13
  403d53:	cmp    $0x310817f,%rbx
  403d5a:	jbe    403dd0 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  403d5c:	lea    0x0(%rbp,%rbx,8),%r8
  403d61:	mov    %r14,%rax
  403d64:	shr    $0x38,%rax
  403d68:	and    $0x7f,%eax
  403d6b:	cmp    $0x2,%rax
  403d6f:	je     403db0 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403d71:	mov    %r12,%rax
  403d74:	mov    %r14,(%r8)
  403d77:	lea    0x8(%rbp,%rbx,8),%r14
  403d7c:	shr    $0x38,%rax
  403d80:	and    $0x7f,%eax
  403d83:	cmp    $0x2,%rax
  403d87:	je     403dc0 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403d89:	movabs $0x200010000000000,%rax
  403d93:	mov    %r12,(%r14)
  403d96:	mov    %r13,%rdx
  403d99:	add    $0x18,%rsp
  403d9d:	or     %rbx,%rax
  403da0:	pop    %rbx
  403da1:	pop    %rbp
  403da2:	pop    %r12
  403da4:	pop    %r13
  403da6:	pop    %r14
  403da8:	pop    %r15
  403daa:	retq   
  403dab:	nopl   0x0(%rax,%rax,1)
  403db0:	test   %r14,%r14
  403db3:	js     403d71 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403db5:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  403dba:	nopw   0x0(%rax,%rax,1)
  403dc0:	test   %r12,%r12
  403dc3:	js     403d89 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403dc5:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  403dca:	nopw   0x0(%rax,%rax,1)
  403dd0:	mov    0x8(%r15),%rbx
  403dd4:	test   %rbx,%rbx
  403dd7:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  403ddd:	lea    0x0(%rbp,%rbx,8),%r8
  403de2:	mov    (%r8),%rax
  403de5:	subq   $0x2,0x108(%r15)
  403ded:	mov    %rax,0x8(%r15)
  403df1:	jmpq   403d61 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403df6:	nopw   %cs:0x0(%rax,%rax,1)
  403e00:	mov    0x4(%rax),%edx
  403e03:	mov    (%rax),%ecx
  403e05:	shl    $0x20,%rdx
  403e09:	or     %rcx,%rdx
  403e0c:	mov    %rdx,%rcx
  403e0f:	and    $0xffffff,%edx
  403e15:	shr    $0x18,%rcx
  403e19:	lea    0x8(,%rcx,8),%rdi
  403e21:	lea    0x0(%rbp,%rdi,1),%r8
  403e26:	lea    -0x8(%rbp,%rdi,1),%rdi
  403e2b:	cmp    $0x1,%rdx
  403e2f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403e35:	mov    (%rax),%edx
  403e37:	mov    (%r15),%rdx
  403e3a:	mov    (%rdi),%r14
  403e3d:	mov    (%r8),%r13
  403e40:	mov    %rdx,(%rax)
  403e43:	mov    0x100(%r15),%rax
  403e4a:	mov    0x3e388(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403e50:	mov    %rbx,(%r15)
  403e53:	add    $0x1,%rax
  403e57:	mov    %rax,0x100(%r15)
  403e5e:	cmp    %rdx,%rax
  403e61:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403e67:	mov    %rcx,%rbx
  403e6a:	jmpq   403d53 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
