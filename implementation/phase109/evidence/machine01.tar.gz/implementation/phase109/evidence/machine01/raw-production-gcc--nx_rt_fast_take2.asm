
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004029b0 <nx_rt_fast_take2>:
  4029b0:	movabs $0xffffffffff,%rax
  4029ba:	push   %r12
  4029bc:	and    %rsi,%rax
  4029bf:	push   %rbp
  4029c0:	push   %rbx
  4029c1:	mov    %rdi,%rbx
  4029c4:	mov    (%rdi),%rdi
  4029c7:	lea    0x0(,%rax,8),%rcx
  4029cf:	mov    0x8(%rbx),%rbp
  4029d3:	lea    (%rdi,%rcx,1),%rdx
  4029d7:	test   %rsi,%rsi
  4029da:	js     402a48 <nx_rt_fast_take2+0x98>
  4029dc:	mov    (%rdx),%rdx
  4029df:	mov    %rdx,0x10(%rbx)
  4029e3:	mov    0x8(%rdi,%rcx,1),%rdx
  4029e8:	mov    %rdx,0x18(%rbx)
  4029ec:	cmp    $0x310817f,%rax
  4029f2:	ja     402a08 <nx_rt_fast_take2+0x58>
  4029f4:	movl   $0x3,0x20(%rbx)
  4029fb:	xor    %eax,%eax
  4029fd:	pop    %rbx
  4029fe:	pop    %rbp
  4029ff:	pop    %r12
  402a01:	retq   
  402a02:	nopw   0x0(%rax,%rax,1)
  402a08:	mov    0x8(%rbp),%rdx
  402a0c:	mov    %rdx,(%rdi,%rax,8)
  402a10:	mov    0x57c2(%rip),%edx        # 4081d8 <KEEP_WORDS>
  402a16:	mov    %rax,0x8(%rbp)
  402a1a:	mov    0x108(%rbp),%rax
  402a21:	add    $0x2,%rax
  402a25:	mov    %rax,0x108(%rbp)
  402a2c:	cmp    %rdx,%rax
  402a2f:	jae    40160f <nx_rt_fast_take2.cold>
  402a35:	movl   $0x3,0x20(%rbx)
  402a3c:	xor    %eax,%eax
  402a3e:	pop    %rbx
  402a3f:	pop    %rbp
  402a40:	pop    %r12
  402a42:	retq   
  402a43:	nopl   0x0(%rax,%rax,1)
  402a48:	mov    0x4(%rdx),%ecx
  402a4b:	mov    (%rdx),%r8d
  402a4e:	shl    $0x20,%rcx
  402a52:	or     %r8,%rcx
  402a55:	mov    %rcx,%r12
  402a58:	and    $0xffffff,%ecx
  402a5e:	shr    $0x18,%r12
  402a62:	lea    0x0(,%r12,8),%r8
  402a6a:	lea    (%rdi,%r8,1),%r9
  402a6e:	lea    0x8(%rdi,%r8,1),%r8
  402a73:	cmp    $0x1,%rcx
  402a77:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  402a7d:	mov    (%rdx),%ecx
  402a7f:	mov    (%r9),%rcx
  402a82:	mov    %rcx,0x10(%rbx)
  402a86:	mov    (%r8),%rcx
  402a89:	mov    %rcx,0x18(%rbx)
  402a8d:	mov    0x0(%rbp),%rcx
  402a91:	mov    %rcx,(%rdx)
  402a94:	mov    0x573e(%rip),%edx        # 4081d8 <KEEP_WORDS>
  402a9a:	mov    %rax,0x0(%rbp)
  402a9e:	mov    0x100(%rbp),%rax
  402aa5:	add    $0x1,%rax
  402aa9:	mov    %rax,0x100(%rbp)
  402ab0:	cmp    %rdx,%rax
  402ab3:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402ab9:	mov    %r12,%rax
  402abc:	jmpq   4029ec <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
