
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403710 <nx_rt_pair_rebuild2_c1_k0>:
  403710:	push   %r15
  403712:	push   %r14
  403714:	push   %r13
  403716:	push   %r12
  403718:	mov    %rdx,%r12
  40371b:	push   %rbp
  40371c:	push   %rbx
  40371d:	movabs $0xffffffffff,%rbx
  403727:	and    %rsi,%rbx
  40372a:	lea    0x0(,%rbx,8),%rdx
  403732:	sub    $0x18,%rsp
  403736:	mov    (%rdi),%rbp
  403739:	mov    0x8(%rdi),%r15
  40373d:	lea    0x0(%rbp,%rdx,1),%rax
  403742:	test   %rsi,%rsi
  403745:	js     403800 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  40374b:	mov    (%rax),%r14
  40374e:	mov    0x8(%rbp,%rdx,1),%r13
  403753:	cmp    $0x310817f,%rbx
  40375a:	jbe    4037d0 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  40375c:	lea    0x0(%rbp,%rbx,8),%r8
  403761:	mov    %r14,%rax
  403764:	shr    $0x38,%rax
  403768:	and    $0x7f,%eax
  40376b:	cmp    $0x2,%rax
  40376f:	je     4037b0 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403771:	mov    %r12,%rax
  403774:	mov    %r14,(%r8)
  403777:	lea    0x8(%rbp,%rbx,8),%r14
  40377c:	shr    $0x38,%rax
  403780:	and    $0x7f,%eax
  403783:	cmp    $0x2,%rax
  403787:	je     4037c0 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403789:	movabs $0x200010000000000,%rax
  403793:	mov    %r12,(%r14)
  403796:	mov    %r13,%rdx
  403799:	add    $0x18,%rsp
  40379d:	or     %rbx,%rax
  4037a0:	pop    %rbx
  4037a1:	pop    %rbp
  4037a2:	pop    %r12
  4037a4:	pop    %r13
  4037a6:	pop    %r14
  4037a8:	pop    %r15
  4037aa:	retq   
  4037ab:	nopl   0x0(%rax,%rax,1)
  4037b0:	test   %r14,%r14
  4037b3:	js     403771 <nx_rt_pair_rebuild2_c1_k0+0x61>
  4037b5:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  4037ba:	nopw   0x0(%rax,%rax,1)
  4037c0:	test   %r12,%r12
  4037c3:	js     403789 <nx_rt_pair_rebuild2_c1_k0+0x79>
  4037c5:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  4037ca:	nopw   0x0(%rax,%rax,1)
  4037d0:	mov    0x8(%r15),%rbx
  4037d4:	test   %rbx,%rbx
  4037d7:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  4037dd:	lea    0x0(%rbp,%rbx,8),%r8
  4037e2:	mov    (%r8),%rax
  4037e5:	subq   $0x2,0x108(%r15)
  4037ed:	mov    %rax,0x8(%r15)
  4037f1:	jmpq   403761 <nx_rt_pair_rebuild2_c1_k0+0x51>
  4037f6:	nopw   %cs:0x0(%rax,%rax,1)
  403800:	mov    0x4(%rax),%edx
  403803:	mov    (%rax),%ecx
  403805:	shl    $0x20,%rdx
  403809:	or     %rcx,%rdx
  40380c:	mov    %rdx,%rcx
  40380f:	and    $0xffffff,%edx
  403815:	shr    $0x18,%rcx
  403819:	lea    0x8(,%rcx,8),%rdi
  403821:	lea    0x0(%rbp,%rdi,1),%r8
  403826:	lea    -0x8(%rbp,%rdi,1),%rdi
  40382b:	cmp    $0x1,%rdx
  40382f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403835:	mov    (%rax),%edx
  403837:	mov    (%r15),%rdx
  40383a:	mov    (%rdi),%r14
  40383d:	mov    (%r8),%r13
  403840:	mov    %rdx,(%rax)
  403843:	mov    0x100(%r15),%rax
  40384a:	mov    0x3d988(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403850:	mov    %rbx,(%r15)
  403853:	add    $0x1,%rax
  403857:	mov    %rax,0x100(%r15)
  40385e:	cmp    %rdx,%rax
  403861:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403867:	mov    %rcx,%rbx
  40386a:	jmpq   403753 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
