
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004034b0 <nx_rt_pair_rebuild2_c1_k0>:
  4034b0:	push   %r14
  4034b2:	mov    %rsi,%r10
  4034b5:	mov    %rdx,%r8
  4034b8:	movabs $0xffffffffff,%r9
  4034c2:	push   %r13
  4034c4:	and    %r10,%r9
  4034c7:	push   %r12
  4034c9:	lea    0x0(,%r9,8),%rax
  4034d1:	push   %rbp
  4034d2:	sub    $0x18,%rsp
  4034d6:	mov    (%rdi),%rbp
  4034d9:	mov    0x8(%rdi),%rsi
  4034dd:	lea    0x0(%rbp,%rax,1),%rdx
  4034e2:	test   %r10,%r10
  4034e5:	js     403540 <nx_rt_pair_rebuild2_c1_k0+0x90>
  4034e7:	mov    (%rdx),%r13
  4034ea:	mov    0x8(%rbp,%rax,1),%r12
  4034ef:	cmp    $0x310817f,%r9
  4034f6:	jbe    403520 <nx_rt_pair_rebuild2_c1_k0+0x70>
  4034f8:	mov    %r13,%rcx
  4034fb:	mov    $0x1,%edx
  403500:	mov    %rbp,%rdi
  403503:	callq  401ff0 <nx_construct2>
  403508:	add    $0x18,%rsp
  40350c:	mov    %r12,%rdx
  40350f:	pop    %rbp
  403510:	pop    %r12
  403512:	pop    %r13
  403514:	pop    %r14
  403516:	retq   
  403517:	nopw   0x0(%rax,%rax,1)
  403520:	mov    0x8(%rsi),%r9
  403524:	test   %r9,%r9
  403527:	je     40173f <nx_rt_pair_rebuild2_c1_k0.cold>
  40352d:	mov    0x0(%rbp,%r9,8),%rax
  403532:	subq   $0x2,0x108(%rsi)
  40353a:	mov    %rax,0x8(%rsi)
  40353e:	jmp    4034f8 <nx_rt_pair_rebuild2_c1_k0+0x48>
  403540:	mov    0x4(%rdx),%eax
  403543:	mov    (%rdx),%ecx
  403545:	shl    $0x20,%rax
  403549:	or     %rcx,%rax
  40354c:	mov    %rax,%r14
  40354f:	and    $0xffffff,%eax
  403554:	shr    $0x18,%r14
  403558:	lea    0x0(,%r14,8),%rcx
  403560:	lea    0x8(%rbp,%rcx,1),%rdi
  403565:	add    %rbp,%rcx
  403568:	cmp    $0x1,%rax
  40356c:	jne    40177d <nx_rt_pair_rebuild2_c1_k0.cold+0x3e>
  403572:	mov    (%rdx),%eax
  403574:	mov    (%rsi),%rax
  403577:	mov    (%rcx),%r13
  40357a:	mov    (%rdi),%r12
  40357d:	mov    %rax,(%rdx)
  403580:	mov    0x100(%rsi),%rax
  403587:	mov    0x3dc4b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40358d:	mov    %r9,(%rsi)
  403590:	add    $0x1,%rax
  403594:	mov    %rax,0x100(%rsi)
  40359b:	cmp    %rdx,%rax
  40359e:	jae    401766 <nx_rt_pair_rebuild2_c1_k0.cold+0x27>
  4035a4:	mov    %r14,%r9
  4035a7:	jmpq   4034ef <nx_rt_pair_rebuild2_c1_k0+0x3f>

Disassembly of section .fini:
