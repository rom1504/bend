
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004038e0 <nx_rt_rebuild2_c1_k0>:
  4038e0:	push   %r15
  4038e2:	push   %r14
  4038e4:	push   %r13
  4038e6:	push   %r12
  4038e8:	mov    %rdx,%r12
  4038eb:	push   %rbp
  4038ec:	mov    %rdi,%rbp
  4038ef:	push   %rbx
  4038f0:	movabs $0xffffffffff,%rbx
  4038fa:	and    %rsi,%rbx
  4038fd:	lea    0x0(,%rbx,8),%rdx
  403905:	sub    $0x18,%rsp
  403909:	mov    (%rdi),%r13
  40390c:	mov    0x8(%rdi),%r15
  403910:	lea    0x0(%r13,%rdx,1),%rax
  403915:	test   %rsi,%rsi
  403918:	js     4039e0 <nx_rt_rebuild2_c1_k0+0x100>
  40391e:	mov    (%rax),%r14
  403921:	mov    0x8(%r13,%rdx,1),%r9
  403926:	cmp    $0x310817f,%rbx
  40392d:	jbe    4039b8 <nx_rt_rebuild2_c1_k0+0xd8>
  403933:	lea    0x0(%r13,%rbx,8),%r8
  403938:	mov    %r14,%rax
  40393b:	mov    %r9,0x10(%rbp)
  40393f:	shr    $0x38,%rax
  403943:	movq   $0xffffffffffffffff,0x18(%rbp)
  40394b:	and    $0x7f,%eax
  40394e:	movl   $0x1,0x20(%rbp)
  403955:	cmp    $0x2,%rax
  403959:	je     403998 <nx_rt_rebuild2_c1_k0+0xb8>
  40395b:	mov    %r12,%rax
  40395e:	mov    %r14,(%r8)
  403961:	lea    0x8(%r13,%rbx,8),%rbp
  403966:	shr    $0x38,%rax
  40396a:	and    $0x7f,%eax
  40396d:	cmp    $0x2,%rax
  403971:	je     4039a8 <nx_rt_rebuild2_c1_k0+0xc8>
  403973:	movabs $0x200010000000000,%rax
  40397d:	mov    %r12,0x0(%rbp)
  403981:	add    $0x18,%rsp
  403985:	or     %rbx,%rax
  403988:	pop    %rbx
  403989:	pop    %rbp
  40398a:	pop    %r12
  40398c:	pop    %r13
  40398e:	pop    %r14
  403990:	pop    %r15
  403992:	retq   
  403993:	nopl   0x0(%rax,%rax,1)
  403998:	test   %r14,%r14
  40399b:	js     40395b <nx_rt_rebuild2_c1_k0+0x7b>
  40399d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  4039a2:	nopw   0x0(%rax,%rax,1)
  4039a8:	test   %r12,%r12
  4039ab:	js     403973 <nx_rt_rebuild2_c1_k0+0x93>
  4039ad:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  4039b2:	nopw   0x0(%rax,%rax,1)
  4039b8:	mov    0x8(%r15),%rbx
  4039bc:	test   %rbx,%rbx
  4039bf:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  4039c5:	lea    0x0(%r13,%rbx,8),%r8
  4039ca:	mov    (%r8),%rax
  4039cd:	subq   $0x2,0x108(%r15)
  4039d5:	mov    %rax,0x8(%r15)
  4039d9:	jmpq   403938 <nx_rt_rebuild2_c1_k0+0x58>
  4039de:	xchg   %ax,%ax
  4039e0:	mov    0x4(%rax),%edx
  4039e3:	mov    (%rax),%ecx
  4039e5:	shl    $0x20,%rdx
  4039e9:	or     %rcx,%rdx
  4039ec:	mov    %rdx,%rcx
  4039ef:	and    $0xffffff,%edx
  4039f5:	shr    $0x18,%rcx
  4039f9:	lea    0x8(,%rcx,8),%rdi
  403a01:	lea    0x0(%r13,%rdi,1),%r8
  403a06:	lea    -0x8(%r13,%rdi,1),%rdi
  403a0b:	cmp    $0x1,%rdx
  403a0f:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  403a15:	mov    (%rax),%edx
  403a17:	mov    (%r15),%rdx
  403a1a:	mov    (%rdi),%r14
  403a1d:	mov    (%r8),%r9
  403a20:	mov    %rdx,(%rax)
  403a23:	mov    0x100(%r15),%rax
  403a2a:	mov    0x3e7a8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403a30:	mov    %rbx,(%r15)
  403a33:	add    $0x1,%rax
  403a37:	mov    %rax,0x100(%r15)
  403a3e:	cmp    %rdx,%rax
  403a41:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  403a47:	mov    %rcx,%rbx
  403a4a:	jmpq   403926 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
