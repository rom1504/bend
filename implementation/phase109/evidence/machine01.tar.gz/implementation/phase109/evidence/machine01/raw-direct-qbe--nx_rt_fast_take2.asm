
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004028e0 <nx_rt_fast_take2>:
  4028e0:	movabs $0xffffffffff,%rax
  4028ea:	push   %r12
  4028ec:	and    %rsi,%rax
  4028ef:	push   %rbp
  4028f0:	push   %rbx
  4028f1:	mov    %rdi,%rbx
  4028f4:	mov    (%rdi),%rdi
  4028f7:	lea    0x0(,%rax,8),%rcx
  4028ff:	mov    0x8(%rbx),%rbp
  402903:	lea    (%rdi,%rcx,1),%rdx
  402907:	test   %rsi,%rsi
  40290a:	js     402978 <nx_rt_fast_take2+0x98>
  40290c:	mov    (%rdx),%rdx
  40290f:	mov    %rdx,0x10(%rbx)
  402913:	mov    0x8(%rdi,%rcx,1),%rdx
  402918:	mov    %rdx,0x18(%rbx)
  40291c:	cmp    $0x310817f,%rax
  402922:	ja     402938 <nx_rt_fast_take2+0x58>
  402924:	movl   $0x3,0x20(%rbx)
  40292b:	xor    %eax,%eax
  40292d:	pop    %rbx
  40292e:	pop    %rbp
  40292f:	pop    %r12
  402931:	retq   
  402932:	nopw   0x0(%rax,%rax,1)
  402938:	mov    0x8(%rbp),%rdx
  40293c:	mov    %rdx,(%rdi,%rax,8)
  402940:	mov    0x4892(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402946:	mov    %rax,0x8(%rbp)
  40294a:	mov    0x108(%rbp),%rax
  402951:	add    $0x2,%rax
  402955:	mov    %rax,0x108(%rbp)
  40295c:	cmp    %rdx,%rax
  40295f:	jae    40160f <nx_rt_fast_take2.cold>
  402965:	movl   $0x3,0x20(%rbx)
  40296c:	xor    %eax,%eax
  40296e:	pop    %rbx
  40296f:	pop    %rbp
  402970:	pop    %r12
  402972:	retq   
  402973:	nopl   0x0(%rax,%rax,1)
  402978:	mov    0x4(%rdx),%ecx
  40297b:	mov    (%rdx),%r8d
  40297e:	shl    $0x20,%rcx
  402982:	or     %r8,%rcx
  402985:	mov    %rcx,%r12
  402988:	and    $0xffffff,%ecx
  40298e:	shr    $0x18,%r12
  402992:	lea    0x0(,%r12,8),%r8
  40299a:	lea    (%rdi,%r8,1),%r9
  40299e:	lea    0x8(%rdi,%r8,1),%r8
  4029a3:	cmp    $0x1,%rcx
  4029a7:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  4029ad:	mov    (%rdx),%ecx
  4029af:	mov    (%r9),%rcx
  4029b2:	mov    %rcx,0x10(%rbx)
  4029b6:	mov    (%r8),%rcx
  4029b9:	mov    %rcx,0x18(%rbx)
  4029bd:	mov    0x0(%rbp),%rcx
  4029c1:	mov    %rcx,(%rdx)
  4029c4:	mov    0x480e(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4029ca:	mov    %rax,0x0(%rbp)
  4029ce:	mov    0x100(%rbp),%rax
  4029d5:	add    $0x1,%rax
  4029d9:	mov    %rax,0x100(%rbp)
  4029e0:	cmp    %rdx,%rax
  4029e3:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  4029e9:	mov    %r12,%rax
  4029ec:	jmpq   40291c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
