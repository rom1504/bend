
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403b10 <nx_rt_rebuild2_c3_k0>:
  403b10:	push   %r15
  403b12:	push   %r14
  403b14:	push   %r13
  403b16:	push   %r12
  403b18:	mov    %rdx,%r12
  403b1b:	push   %rbp
  403b1c:	mov    %rdi,%rbp
  403b1f:	push   %rbx
  403b20:	movabs $0xffffffffff,%rbx
  403b2a:	and    %rsi,%rbx
  403b2d:	lea    0x0(,%rbx,8),%rdx
  403b35:	sub    $0x18,%rsp
  403b39:	mov    (%rdi),%r13
  403b3c:	mov    0x8(%rdi),%r15
  403b40:	lea    0x0(%r13,%rdx,1),%rax
  403b45:	test   %rsi,%rsi
  403b48:	js     403c10 <nx_rt_rebuild2_c3_k0+0x100>
  403b4e:	mov    (%rax),%r14
  403b51:	mov    0x8(%r13,%rdx,1),%r9
  403b56:	cmp    $0x310817f,%rbx
  403b5d:	jbe    403be8 <nx_rt_rebuild2_c3_k0+0xd8>
  403b63:	lea    0x0(%r13,%rbx,8),%r8
  403b68:	mov    %r14,%rax
  403b6b:	mov    %r9,0x10(%rbp)
  403b6f:	shr    $0x38,%rax
  403b73:	movq   $0xffffffffffffffff,0x18(%rbp)
  403b7b:	and    $0x7f,%eax
  403b7e:	movl   $0x1,0x20(%rbp)
  403b85:	cmp    $0x2,%rax
  403b89:	je     403bc8 <nx_rt_rebuild2_c3_k0+0xb8>
  403b8b:	mov    %r12,%rax
  403b8e:	mov    %r14,(%r8)
  403b91:	lea    0x8(%r13,%rbx,8),%rbp
  403b96:	shr    $0x38,%rax
  403b9a:	and    $0x7f,%eax
  403b9d:	cmp    $0x2,%rax
  403ba1:	je     403bd8 <nx_rt_rebuild2_c3_k0+0xc8>
  403ba3:	movabs $0x200030000000000,%rax
  403bad:	mov    %r12,0x0(%rbp)
  403bb1:	add    $0x18,%rsp
  403bb5:	or     %rbx,%rax
  403bb8:	pop    %rbx
  403bb9:	pop    %rbp
  403bba:	pop    %r12
  403bbc:	pop    %r13
  403bbe:	pop    %r14
  403bc0:	pop    %r15
  403bc2:	retq   
  403bc3:	nopl   0x0(%rax,%rax,1)
  403bc8:	test   %r14,%r14
  403bcb:	js     403b8b <nx_rt_rebuild2_c3_k0+0x7b>
  403bcd:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  403bd2:	nopw   0x0(%rax,%rax,1)
  403bd8:	test   %r12,%r12
  403bdb:	js     403ba3 <nx_rt_rebuild2_c3_k0+0x93>
  403bdd:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  403be2:	nopw   0x0(%rax,%rax,1)
  403be8:	mov    0x8(%r15),%rbx
  403bec:	test   %rbx,%rbx
  403bef:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  403bf5:	lea    0x0(%r13,%rbx,8),%r8
  403bfa:	mov    (%r8),%rax
  403bfd:	subq   $0x2,0x108(%r15)
  403c05:	mov    %rax,0x8(%r15)
  403c09:	jmpq   403b68 <nx_rt_rebuild2_c3_k0+0x58>
  403c0e:	xchg   %ax,%ax
  403c10:	mov    0x4(%rax),%edx
  403c13:	mov    (%rax),%ecx
  403c15:	shl    $0x20,%rdx
  403c19:	or     %rcx,%rdx
  403c1c:	mov    %rdx,%rcx
  403c1f:	and    $0xffffff,%edx
  403c25:	shr    $0x18,%rcx
  403c29:	lea    0x8(,%rcx,8),%rdi
  403c31:	lea    0x0(%r13,%rdi,1),%r8
  403c36:	lea    -0x8(%r13,%rdi,1),%rdi
  403c3b:	cmp    $0x1,%rdx
  403c3f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  403c45:	mov    (%rax),%edx
  403c47:	mov    (%r15),%rdx
  403c4a:	mov    (%rdi),%r14
  403c4d:	mov    (%r8),%r9
  403c50:	mov    %rdx,(%rax)
  403c53:	mov    0x100(%r15),%rax
  403c5a:	mov    0x3d578(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403c60:	mov    %rbx,(%r15)
  403c63:	add    $0x1,%rax
  403c67:	mov    %rax,0x100(%r15)
  403c6e:	cmp    %rdx,%rax
  403c71:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  403c77:	mov    %rcx,%rbx
  403c7a:	jmpq   403b56 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
