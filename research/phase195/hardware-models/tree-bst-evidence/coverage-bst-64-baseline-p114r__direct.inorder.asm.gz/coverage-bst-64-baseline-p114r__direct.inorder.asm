000000000040e968 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>:
  40e968:	push   rbp
  40e969:	mov    rbp,rsp
  40e96c:	sub    rsp,0x1210
  40e973:	mov    QWORD PTR [rbp-0x10],r12
  40e977:	mov    QWORD PTR [rbp-0x8],rbx
  40e97b:	mov    QWORD PTR [rbp-0x18],r13
  40e97f:	mov    QWORD PTR [rbp-0x20],r14
  40e983:	mov    rax,rdi
  40e986:	mov    r12,rax
  40e989:	mov    rax,rsi
  40e98c:	mov    rsi,rax
  40e98f:	mov    rax,rdx
  40e992:	mov    r13,rax
  40e995:	mov    rax,rcx
  40e998:	mov    rdi,rax
  40e99b:	mov    rax,r8
  40e99e:	mov    rbx,rax
  40e9a1:	mov    rax,r9
  40e9a4:	mov    r14,rax
  40e9a7:	mov    r10,rdi
  40e9aa:	test   r10d,r10d
  40e9ad:	je     40ea91 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x129>
  40e9b3:	cmp    rbx,0x0
  40e9ba:	je     40ea79 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x111>
  40e9c0:	sub    rbx,0x1
  40e9c7:	mov    rdi,QWORD PTR [r12+0x10]
  40e9cc:	movabs r11,0xfffffffffffffff8
  40e9d6:	add    rdi,r11
  40e9d9:	mov    QWORD PTR [r12+0x10],rdi
  40e9de:	mov    rdi,QWORD PTR [r12+0x10]
  40e9e3:	mov    rdi,QWORD PTR [rdi]
  40e9e6:	movabs r11,0x48
  40e9f0:	cmp    rdi,r11
  40e9f3:	jne    40ea48 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0xe0>
  40e9f9:	mov    rdi,QWORD PTR [r12+0x10]
  40e9fe:	movabs r11,0xfffffffffffffff0
  40ea08:	add    rdi,r11
  40ea0b:	mov    QWORD PTR [r12+0x10],rdi
  40ea10:	mov    rdi,QWORD PTR [r12+0x10]
  40ea15:	mov    rsi,QWORD PTR [rdi]
  40ea18:	mov    rdi,QWORD PTR [r12+0x10]
  40ea1d:	mov    rdx,QWORD PTR [rdi+0x8]
  40ea21:	mov    edi,r14d
  40ea24:	mov    r13,rdi
  40ea27:	imul   r13d,r13d,0xa
  40ea2e:	mov    esi,esi
  40ea30:	add    r13d,esi
  40ea33:	mov    rsi,rdx
  40ea36:	movabs r10,0x0
  40ea40:	mov    rdi,r10
  40ea43:	jmp    40e9a7 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3f>
  40ea48:	mov    rdi,r12
  40ea4b:	movabs rsi,0x4
  40ea55:	mov    esi,esi
  40ea57:	xor    eax,eax
  40ea59:	call   4185b0 <p111_rt_fail>
  40ea5e:	mov    rdi,rax
  40ea61:	mov    rax,rdi
  40ea64:	mov    r12,QWORD PTR [rbp-0x10]
  40ea68:	mov    rbx,QWORD PTR [rbp-0x8]
  40ea6c:	mov    r13,QWORD PTR [rbp-0x18]
  40ea70:	mov    r14,QWORD PTR [rbp-0x20]
  40ea74:	mov    rsp,rbp
  40ea77:	pop    rbp
  40ea78:	ret    
  40ea79:	mov    rax,r14
  40ea7c:	mov    r12,QWORD PTR [rbp-0x10]
  40ea80:	mov    rbx,QWORD PTR [rbp-0x8]
  40ea84:	mov    r13,QWORD PTR [rbp-0x18]
  40ea88:	mov    r14,QWORD PTR [rbp-0x20]
  40ea8c:	mov    rsp,rbp
  40ea8f:	pop    rbp
  40ea90:	ret    
  40ea91:	mov    rdi,rsi
  40ea94:	shr    rdi,0x28
  40ea98:	and    rdi,0xffff
  40ea9f:	movabs r11,0xa4
  40eaa9:	cmp    rdi,r11
  40eaac:	jne    40eac7 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x15f>
  40eab2:	movabs r10,0x1
  40eabc:	mov    rdi,r10
  40eabf:	mov    r14,r13
  40eac2:	jmp    40e9a7 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3f>
  40eac7:	mov    rdi,rsi
  40eaca:	shr    rdi,0x28
  40eace:	and    rdi,0xffff
  40ead5:	movabs r11,0xa5
  40eadf:	cmp    rdi,r11
  40eae2:	jne    40ebc7 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x25f>
  40eae8:	mov    r10,r12
  40eaeb:	mov    QWORD PTR [rsp+0x18],r10
  40eaf0:	mov    r10,rsi
  40eaf3:	mov    QWORD PTR [rsp+0x20],r10
  40eaf8:	lea    r10,[rbp-0x850]
  40eaff:	mov    QWORD PTR [rsp+0x28],r10
  40eb04:	mov    rdi,QWORD PTR [rsp+0x18]
  40eb09:	mov    rsi,QWORD PTR [rsp+0x20]
  40eb0e:	mov    rdx,QWORD PTR [rsp+0x28]
  40eb13:	xor    eax,eax
  40eb15:	call   41de20 <p125_rt_take3>
  40eb1a:	mov    QWORD PTR [rbp-0x1158],rax
  40eb21:	lea    r10,[rbp-0x850]
  40eb28:	mov    rdx,QWORD PTR [r10]
  40eb2b:	lea    r10,[rbp-0x850]
  40eb32:	mov    rsi,QWORD PTR [r10+0x8]
  40eb36:	lea    r10,[rbp-0x850]
  40eb3d:	mov    rdi,QWORD PTR [r10+0x10]
  40eb41:	lea    r10,[rbp-0x850]
  40eb48:	mov    r11,rsi
  40eb4b:	mov    QWORD PTR [r10],r11
  40eb4e:	lea    r10,[rbp-0x850]
  40eb55:	mov    r11,rdi
  40eb58:	mov    QWORD PTR [r10+0x8],r11
  40eb5c:	mov    rdi,QWORD PTR [r12+0x10]
  40eb61:	mov    QWORD PTR [rdi],rsi
  40eb64:	lea    r10,[rbp-0x850]
  40eb6b:	mov    rsi,QWORD PTR [r10+0x8]
  40eb6f:	mov    QWORD PTR [rdi+0x8],rsi
  40eb73:	mov    r10,rdi
  40eb76:	movabs r11,0x48
  40eb80:	mov    QWORD PTR [r10+0x10],r11
  40eb84:	add    rdi,0x18
  40eb8b:	mov    QWORD PTR [r12+0x10],rdi
  40eb90:	add    rbx,0x1
  40eb97:	lea    r10,[rbp-0x850]
  40eb9e:	mov    r11,rdx
  40eba1:	mov    QWORD PTR [r10],r11
  40eba4:	lea    r10,[rbp-0x850]
  40ebab:	mov    r11,r13
  40ebae:	mov    QWORD PTR [r10+0x8],r11
  40ebb2:	mov    rsi,rdx
  40ebb5:	movabs r10,0x0
  40ebbf:	mov    rdi,r10
  40ebc2:	jmp    40e9a7 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_+0x3f>
  40ebc7:	lea    r10,[rbp-0x850]
  40ebce:	mov    r11,r13
  40ebd1:	mov    QWORD PTR [r10],r11
  40ebd4:	mov    rdi,QWORD PTR [r12+0x10]
  40ebd9:	mov    QWORD PTR [rdi],r13
  40ebdc:	mov    r10,rdi
  40ebdf:	movabs r11,0x49
  40ebe9:	mov    QWORD PTR [r10+0x8],r11
  40ebed:	add    rdi,0x10
  40ebf4:	mov    QWORD PTR [r12+0x10],rdi
  40ebf9:	lea    r10,[rbp-0x850]
  40ec00:	mov    r11,rsi
  40ec03:	mov    QWORD PTR [r10],r11
  40ec06:	mov    rdi,QWORD PTR [r12+0x10]
  40ec0b:	mov    QWORD PTR [rdi],rsi
  40ec0e:	mov    r10,rdi
  40ec11:	movabs r11,0x4a
  40ec1b:	mov    QWORD PTR [r10+0x8],r11
  40ec1f:	mov    r10,rdi
  40ec22:	add    r10,0x10
  40ec29:	mov    QWORD PTR [rbp-0x11a8],r10
  40ec30:	mov    r10,r12
  40ec33:	mov    r11,QWORD PTR [rbp-0x11a8]
  40ec3a:	mov    QWORD PTR [r10+0x10],r11
  40ec3e:	mov    rdi,r12
  40ec41:	movabs rsi,0x4
  40ec4b:	mov    esi,esi
  40ec4d:	xor    eax,eax
  40ec4f:	call   4185b0 <p111_rt_fail>
  40ec54:	mov    QWORD PTR [rbp-0x11b0],rax
  40ec5b:	mov    r12,QWORD PTR [rbp-0x10]
  40ec5f:	mov    rbx,QWORD PTR [rbp-0x8]
  40ec63:	mov    r13,QWORD PTR [rbp-0x18]
  40ec67:	mov    r14,QWORD PTR [rbp-0x20]
  40ec6b:	mov    rsp,rbp
  40ec6e:	pop    rbp
  40ec6f:	ret    

