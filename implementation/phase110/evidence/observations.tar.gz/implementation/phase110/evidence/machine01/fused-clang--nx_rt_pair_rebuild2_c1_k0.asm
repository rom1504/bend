
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403470 <nx_rt_pair_rebuild2_c1_k0>:
  403470:	push   %r14
  403472:	mov    %rsi,%r10
  403475:	mov    %rdx,%r8
  403478:	movabs $0xffffffffff,%r9
  403482:	push   %r13
  403484:	and    %r10,%r9
  403487:	push   %r12
  403489:	lea    0x0(,%r9,8),%rax
  403491:	push   %rbp
  403492:	sub    $0x18,%rsp
  403496:	mov    (%rdi),%rbp
  403499:	mov    0x8(%rdi),%rsi
  40349d:	lea    0x0(%rbp,%rax,1),%rdx
  4034a2:	test   %r10,%r10
  4034a5:	js     403500 <nx_rt_pair_rebuild2_c1_k0+0x90>
  4034a7:	mov    (%rdx),%r13
  4034aa:	mov    0x8(%rbp,%rax,1),%r12
  4034af:	cmp    $0x310817f,%r9
  4034b6:	jbe    4034e0 <nx_rt_pair_rebuild2_c1_k0+0x70>
  4034b8:	mov    %r13,%rcx
  4034bb:	mov    $0x1,%edx
  4034c0:	mov    %rbp,%rdi
  4034c3:	callq  401fb0 <nx_construct2>
  4034c8:	add    $0x18,%rsp
  4034cc:	mov    %r12,%rdx
  4034cf:	pop    %rbp
  4034d0:	pop    %r12
  4034d2:	pop    %r13
  4034d4:	pop    %r14
  4034d6:	retq   
  4034d7:	nopw   0x0(%rax,%rax,1)
  4034e0:	mov    0x8(%rsi),%r9
  4034e4:	test   %r9,%r9
  4034e7:	je     40173f <nx_rt_pair_rebuild2_c1_k0.cold>
  4034ed:	mov    0x0(%rbp,%r9,8),%rax
  4034f2:	subq   $0x2,0x108(%rsi)
  4034fa:	mov    %rax,0x8(%rsi)
  4034fe:	jmp    4034b8 <nx_rt_pair_rebuild2_c1_k0+0x48>
  403500:	mov    0x4(%rdx),%eax
  403503:	mov    (%rdx),%ecx
  403505:	shl    $0x20,%rax
  403509:	or     %rcx,%rax
  40350c:	mov    %rax,%r14
  40350f:	and    $0xffffff,%eax
  403514:	shr    $0x18,%r14
  403518:	lea    0x0(,%r14,8),%rcx
  403520:	lea    0x8(%rbp,%rcx,1),%rdi
  403525:	add    %rbp,%rcx
  403528:	cmp    $0x1,%rax
  40352c:	jne    40177d <nx_rt_pair_rebuild2_c1_k0.cold+0x3e>
  403532:	mov    (%rdx),%eax
  403534:	mov    (%rsi),%rax
  403537:	mov    (%rcx),%r13
  40353a:	mov    (%rdi),%r12
  40353d:	mov    %rax,(%rdx)
  403540:	mov    0x100(%rsi),%rax
  403547:	mov    0x3dc8b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40354d:	mov    %r9,(%rsi)
  403550:	add    $0x1,%rax
  403554:	mov    %rax,0x100(%rsi)
  40355b:	cmp    %rdx,%rax
  40355e:	jae    401766 <nx_rt_pair_rebuild2_c1_k0.cold+0x27>
  403564:	mov    %r14,%r9
  403567:	jmpq   4034af <nx_rt_pair_rebuild2_c1_k0+0x3f>

Disassembly of section .fini:
