
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403230 <nx_rt_fast_take2>:
  403230:	movabs $0xffffffffff,%rax
  40323a:	push   %r12
  40323c:	and    %rsi,%rax
  40323f:	push   %rbp
  403240:	push   %rbx
  403241:	mov    %rdi,%rbx
  403244:	mov    (%rdi),%rdi
  403247:	lea    0x0(,%rax,8),%rcx
  40324f:	mov    0x8(%rbx),%rbp
  403253:	lea    (%rdi,%rcx,1),%rdx
  403257:	test   %rsi,%rsi
  40325a:	js     4032c8 <nx_rt_fast_take2+0x98>
  40325c:	mov    (%rdx),%rdx
  40325f:	mov    %rdx,0x10(%rbx)
  403263:	mov    0x8(%rdi,%rcx,1),%rdx
  403268:	mov    %rdx,0x18(%rbx)
  40326c:	cmp    $0x310817f,%rax
  403272:	ja     403288 <nx_rt_fast_take2+0x58>
  403274:	movl   $0x3,0x20(%rbx)
  40327b:	xor    %eax,%eax
  40327d:	pop    %rbx
  40327e:	pop    %rbp
  40327f:	pop    %r12
  403281:	retq   
  403282:	nopw   0x0(%rax,%rax,1)
  403288:	mov    0x8(%rbp),%rdx
  40328c:	mov    %rdx,(%rdi,%rax,8)
  403290:	mov    0x3ef42(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403296:	mov    %rax,0x8(%rbp)
  40329a:	mov    0x108(%rbp),%rax
  4032a1:	add    $0x2,%rax
  4032a5:	mov    %rax,0x108(%rbp)
  4032ac:	cmp    %rdx,%rax
  4032af:	jae    4015fe <nx_rt_fast_take2.cold>
  4032b5:	movl   $0x3,0x20(%rbx)
  4032bc:	xor    %eax,%eax
  4032be:	pop    %rbx
  4032bf:	pop    %rbp
  4032c0:	pop    %r12
  4032c2:	retq   
  4032c3:	nopl   0x0(%rax,%rax,1)
  4032c8:	mov    0x4(%rdx),%ecx
  4032cb:	mov    (%rdx),%r8d
  4032ce:	shl    $0x20,%rcx
  4032d2:	or     %r8,%rcx
  4032d5:	mov    %rcx,%r12
  4032d8:	and    $0xffffff,%ecx
  4032de:	shr    $0x18,%r12
  4032e2:	lea    0x0(,%r12,8),%r8
  4032ea:	lea    (%rdi,%r8,1),%r9
  4032ee:	lea    0x8(%rdi,%r8,1),%r8
  4032f3:	cmp    $0x1,%rcx
  4032f7:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  4032fd:	mov    (%rdx),%ecx
  4032ff:	mov    (%r9),%rcx
  403302:	mov    %rcx,0x10(%rbx)
  403306:	mov    (%r8),%rcx
  403309:	mov    %rcx,0x18(%rbx)
  40330d:	mov    0x0(%rbp),%rcx
  403311:	mov    %rcx,(%rdx)
  403314:	mov    0x3eebe(%rip),%edx        # 4421d8 <KEEP_WORDS>
  40331a:	mov    %rax,0x0(%rbp)
  40331e:	mov    0x100(%rbp),%rax
  403325:	add    $0x1,%rax
  403329:	mov    %rax,0x100(%rbp)
  403330:	cmp    %rdx,%rax
  403333:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  403339:	mov    %r12,%rax
  40333c:	jmpq   40326c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
