
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004024b0 <nx_rt_take2>:
  4024b0:	push   %r13
  4024b2:	push   %r12
  4024b4:	sub    $0x8,%rsp
  4024b8:	cmpb   $0x0,0x4cc1(%rip)        # 407180 <nx_active>
  4024bf:	je     4024cd <nx_rt_take2+0x1d>
  4024c1:	lea    0x4cd8(%rip),%rax        # 4071a0 <nx_context>
  4024c8:	cmp    %rax,%rdi
  4024cb:	je     4024e0 <nx_rt_take2+0x30>
  4024cd:	lea    0x1b5f(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4024d4:	callq  401950 <err_fail>
  4024d9:	nopl   0x0(%rax)
  4024e0:	mov    0x4cda(%rip),%eax        # 4071c0 <nx_context+0x20>
  4024e6:	mov    0x4cb3(%rip),%rdi        # 4071a0 <nx_context>
  4024ed:	test   %eax,%eax
  4024ef:	jne    402629 <nx_rt_take2+0x179>
  4024f5:	mov    %rsi,%r12
  4024f8:	callq  401a80 <nx_id.isra.0>
  4024fd:	and    $0xfffffffd,%eax
  402500:	cmp    $0x1,%eax
  402503:	jne    40261d <nx_rt_take2+0x16d>
  402509:	mov    0x4c90(%rip),%rdi        # 4071a0 <nx_context>
  402510:	mov    0x4c91(%rip),%rsi        # 4071a8 <nx_context+0x8>
  402517:	movabs $0xffffffffff,%rax
  402521:	and    %r12,%rax
  402524:	lea    0x0(,%rax,8),%rcx
  40252c:	lea    (%rdi,%rcx,1),%rdx
  402530:	test   %r12,%r12
  402533:	js     4025a0 <nx_rt_take2+0xf0>
  402535:	mov    (%rdx),%rdx
  402538:	mov    %rdx,0x4c71(%rip)        # 4071b0 <nx_context+0x10>
  40253f:	mov    0x8(%rdi,%rcx,1),%rdx
  402544:	mov    %rdx,0x4c6d(%rip)        # 4071b8 <nx_context+0x18>
  40254b:	cmp    $0x310817f,%rax
  402551:	ja     402570 <nx_rt_take2+0xc0>
  402553:	movl   $0x3,0x4c63(%rip)        # 4071c0 <nx_context+0x20>
  40255d:	add    $0x8,%rsp
  402561:	xor    %eax,%eax
  402563:	pop    %r12
  402565:	pop    %r13
  402567:	retq   
  402568:	nopl   0x0(%rax,%rax,1)
  402570:	mov    0x8(%rsi),%rdx
  402574:	mov    %rdx,(%rdi,%rax,8)
  402578:	mov    0x4c5a(%rip),%edx        # 4071d8 <KEEP_WORDS>
  40257e:	mov    %rax,0x8(%rsi)
  402582:	mov    0x108(%rsi),%rax
  402589:	add    $0x2,%rax
  40258d:	mov    %rax,0x108(%rsi)
  402594:	cmp    %rdx,%rax
  402597:	jb     402553 <nx_rt_take2+0xa3>
  402599:	jmpq   401567 <nx_rt_take2.cold>
  40259e:	xchg   %ax,%ax
  4025a0:	mov    0x4(%rdx),%ecx
  4025a3:	mov    (%rdx),%r8d
  4025a6:	shl    $0x20,%rcx
  4025aa:	or     %r8,%rcx
  4025ad:	mov    %rcx,%r13
  4025b0:	and    $0xffffff,%ecx
  4025b6:	shr    $0x18,%r13
  4025ba:	lea    0x0(,%r13,8),%r8
  4025c2:	lea    (%rdi,%r8,1),%r9
  4025c6:	lea    0x8(%rdi,%r8,1),%r8
  4025cb:	cmp    $0x1,%rcx
  4025cf:	jne    401582 <nx_rt_take2.cold+0x1b>
  4025d5:	mov    (%rdx),%ecx
  4025d7:	mov    (%r9),%rcx
  4025da:	mov    %rcx,0x4bcf(%rip)        # 4071b0 <nx_context+0x10>
  4025e1:	mov    (%r8),%rcx
  4025e4:	mov    %rcx,0x4bcd(%rip)        # 4071b8 <nx_context+0x18>
  4025eb:	mov    (%rsi),%rcx
  4025ee:	mov    %rcx,(%rdx)
  4025f1:	mov    0x4be1(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4025f7:	mov    %rax,(%rsi)
  4025fa:	mov    0x100(%rsi),%rax
  402601:	add    $0x1,%rax
  402605:	mov    %rax,0x100(%rsi)
  40260c:	cmp    %rdx,%rax
  40260f:	jae    401576 <nx_rt_take2.cold+0xf>
  402615:	mov    %r13,%rax
  402618:	jmpq   40254b <nx_rt_take2+0x9b>
  40261d:	lea    0x1cf4(%rip),%rdi        # 404318 <_IO_stdin_used+0x318>
  402624:	callq  401950 <err_fail>
  402629:	lea    0x1cc0(%rip),%rdi        # 4042f0 <_IO_stdin_used+0x2f0>
  402630:	callq  401950 <err_fail>

Disassembly of section .fini:
