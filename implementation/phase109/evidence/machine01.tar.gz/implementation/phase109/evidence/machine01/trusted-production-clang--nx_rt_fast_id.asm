
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402050 <nx_rt_fast_id>:
  402050:	shr    $0x28,%rsi
  402054:	movzwl %si,%eax
  402057:	retq   

Disassembly of section .fini:
