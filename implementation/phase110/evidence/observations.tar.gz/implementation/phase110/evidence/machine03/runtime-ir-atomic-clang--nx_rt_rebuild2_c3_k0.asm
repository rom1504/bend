
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403e80 <nx_rt_rebuild2_c3_k0>:
  403e80:	push   %r15
  403e82:	push   %r14
  403e84:	push   %r13
  403e86:	push   %r12
  403e88:	mov    %rdx,%r12
  403e8b:	push   %rbp
  403e8c:	mov    %rdi,%rbp
  403e8f:	push   %rbx
  403e90:	movabs $0xffffffffff,%rbx
  403e9a:	and    %rsi,%rbx
  403e9d:	lea    0x0(,%rbx,8),%rdx
  403ea5:	sub    $0x18,%rsp
  403ea9:	mov    (%rdi),%r13
  403eac:	mov    0x8(%rdi),%r15
  403eb0:	lea    0x0(%r13,%rdx,1),%rax
  403eb5:	test   %rsi,%rsi
  403eb8:	js     403f80 <nx_rt_rebuild2_c3_k0+0x100>
  403ebe:	mov    (%rax),%r14
  403ec1:	mov    0x8(%r13,%rdx,1),%r9
  403ec6:	cmp    $0x310817f,%rbx
  403ecd:	jbe    403f58 <nx_rt_rebuild2_c3_k0+0xd8>
  403ed3:	lea    0x0(%r13,%rbx,8),%r8
  403ed8:	mov    %r14,%rax
  403edb:	mov    %r9,0x10(%rbp)
  403edf:	shr    $0x38,%rax
  403ee3:	movq   $0xffffffffffffffff,0x18(%rbp)
  403eeb:	and    $0x7f,%eax
  403eee:	movl   $0x1,0x20(%rbp)
  403ef5:	cmp    $0x2,%rax
  403ef9:	je     403f38 <nx_rt_rebuild2_c3_k0+0xb8>
  403efb:	mov    %r12,%rax
  403efe:	mov    %r14,(%r8)
  403f01:	lea    0x8(%r13,%rbx,8),%rbp
  403f06:	shr    $0x38,%rax
  403f0a:	and    $0x7f,%eax
  403f0d:	cmp    $0x2,%rax
  403f11:	je     403f48 <nx_rt_rebuild2_c3_k0+0xc8>
  403f13:	movabs $0x200030000000000,%rax
  403f1d:	mov    %r12,0x0(%rbp)
  403f21:	add    $0x18,%rsp
  403f25:	or     %rbx,%rax
  403f28:	pop    %rbx
  403f29:	pop    %rbp
  403f2a:	pop    %r12
  403f2c:	pop    %r13
  403f2e:	pop    %r14
  403f30:	pop    %r15
  403f32:	retq   
  403f33:	nopl   0x0(%rax,%rax,1)
  403f38:	test   %r14,%r14
  403f3b:	js     403efb <nx_rt_rebuild2_c3_k0+0x7b>
  403f3d:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  403f42:	nopw   0x0(%rax,%rax,1)
  403f48:	test   %r12,%r12
  403f4b:	js     403f13 <nx_rt_rebuild2_c3_k0+0x93>
  403f4d:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  403f52:	nopw   0x0(%rax,%rax,1)
  403f58:	mov    0x8(%r15),%rbx
  403f5c:	test   %rbx,%rbx
  403f5f:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  403f65:	lea    0x0(%r13,%rbx,8),%r8
  403f6a:	mov    (%r8),%rax
  403f6d:	subq   $0x2,0x108(%r15)
  403f75:	mov    %rax,0x8(%r15)
  403f79:	jmpq   403ed8 <nx_rt_rebuild2_c3_k0+0x58>
  403f7e:	xchg   %ax,%ax
  403f80:	mov    0x4(%rax),%edx
  403f83:	mov    (%rax),%ecx
  403f85:	shl    $0x20,%rdx
  403f89:	or     %rcx,%rdx
  403f8c:	mov    %rdx,%rcx
  403f8f:	and    $0xffffff,%edx
  403f95:	shr    $0x18,%rcx
  403f99:	lea    0x8(,%rcx,8),%rdi
  403fa1:	lea    0x0(%r13,%rdi,1),%r8
  403fa6:	lea    -0x8(%r13,%rdi,1),%rdi
  403fab:	cmp    $0x1,%rdx
  403faf:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  403fb5:	mov    (%rax),%edx
  403fb7:	mov    (%r15),%rdx
  403fba:	mov    (%rdi),%r14
  403fbd:	mov    (%r8),%r9
  403fc0:	mov    %rdx,(%rax)
  403fc3:	mov    0x100(%r15),%rax
  403fca:	mov    0x3e208(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403fd0:	mov    %rbx,(%r15)
  403fd3:	add    $0x1,%rax
  403fd7:	mov    %rax,0x100(%r15)
  403fde:	cmp    %rdx,%rax
  403fe1:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  403fe7:	mov    %rcx,%rbx
  403fea:	jmpq   403ec6 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
