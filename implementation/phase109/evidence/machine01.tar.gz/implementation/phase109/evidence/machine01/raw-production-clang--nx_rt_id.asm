
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401980 <nx_rt_id>:
  401980:	lea    0x5801(%rip),%rax        # 407188 <nx_context>
  401987:	cmp    %rax,%rdi
  40198a:	jne    40199e <nx_rt_id+0x1e>
  40198c:	testb  $0x1,0x57ed(%rip)        # 407180 <nx_active>
  401993:	je     40199e <nx_rt_id+0x1e>
  401995:	mov    0x57ec(%rip),%rdi        # 407188 <nx_context>
  40199c:	jmp    4019b0 <nx_id>
  40199e:	push   %rax
  40199f:	lea    0x296e(%rip),%rdi        # 404314 <_IO_stdin_used+0x314>
  4019a6:	callq  401130 <err_fail>

Disassembly of section .fini:
