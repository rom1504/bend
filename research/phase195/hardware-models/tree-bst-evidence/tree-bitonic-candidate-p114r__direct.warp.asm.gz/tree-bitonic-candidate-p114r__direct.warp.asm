0000000000411e32 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_>:
  411e32:	push   rbp
  411e33:	mov    rbp,rsp
  411e36:	sub    rsp,0x1b60
  411e3d:	mov    QWORD PTR [rbp-0x10],r12
  411e41:	mov    QWORD PTR [rbp-0x8],rbx
  411e45:	mov    QWORD PTR [rbp-0x18],r13
  411e49:	mov    QWORD PTR [rbp-0x20],r14
  411e4d:	mov    QWORD PTR [rbp-0x28],r15
  411e51:	mov    rax,rdi
  411e54:	mov    r12,rax
  411e57:	mov    rax,rsi
  411e5a:	mov    r13,rax
  411e5d:	mov    rax,rdx
  411e60:	mov    rbx,rax
  411e63:	mov    rax,rcx
  411e66:	mov    r14,rax
  411e69:	mov    rax,r8
  411e6c:	mov    rdi,rax
  411e6f:	mov    rax,r9
  411e72:	mov    r15,rax
  411e75:	mov    rax,QWORD PTR [rbp+0x10]
  411e79:	mov    QWORD PTR [rbp-0x58],rax
  411e7d:	mov    r10,rdi
  411e80:	test   r10d,r10d
  411e83:	je     412048 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x216>
  411e89:	cmp    r15,0x0
  411e90:	je     41202b <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f9>
  411e96:	sub    r15,0x1
  411e9d:	mov    rdi,QWORD PTR [r12+0x10]
  411ea2:	movabs r11,0xfffffffffffffff8
  411eac:	add    rdi,r11
  411eaf:	mov    QWORD PTR [r12+0x10],rdi
  411eb4:	mov    rdi,QWORD PTR [r12+0x10]
  411eb9:	mov    rdi,QWORD PTR [rdi]
  411ebc:	movabs r11,0x74
  411ec6:	cmp    rdi,r11
  411ec9:	jne    411f80 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x14e>
  411ecf:	mov    rdi,QWORD PTR [r12+0x10]
  411ed4:	movabs r11,0xffffffffffffffe8
  411ede:	add    rdi,r11
  411ee1:	mov    QWORD PTR [r12+0x10],rdi
  411ee6:	mov    rdi,QWORD PTR [r12+0x10]
  411eeb:	mov    r13,QWORD PTR [rdi]
  411eee:	mov    rdi,QWORD PTR [r12+0x10]
  411ef3:	mov    r14,QWORD PTR [rdi+0x8]
  411ef7:	mov    rdi,QWORD PTR [r12+0x10]
  411efc:	mov    rbx,QWORD PTR [rdi+0x10]
  411f00:	lea    r10,[rbp-0x10d8]
  411f07:	mov    r11,QWORD PTR [rbp-0x58]
  411f0b:	mov    QWORD PTR [r10],r11
  411f0e:	mov    rdi,r12
  411f11:	movabs rsi,0x75
  411f1b:	mov    esi,esi
  411f1d:	lea    rdx,[rbp-0x10d8]
  411f24:	movabs rcx,0x1
  411f2e:	mov    ecx,ecx
  411f30:	xor    eax,eax
  411f32:	call   41c4d0 <p111_rt_frame>
  411f37:	mov    QWORD PTR [rbp-0x1950],rax
  411f3e:	add    r15,0x1
  411f45:	lea    r10,[rbp-0x10d8]
  411f4c:	mov    r11,r13
  411f4f:	mov    QWORD PTR [r10],r11
  411f52:	lea    r10,[rbp-0x10d8]
  411f59:	mov    r11,rbx
  411f5c:	mov    QWORD PTR [r10+0x8],r11
  411f60:	lea    r10,[rbp-0x10d8]
  411f67:	mov    r11,r14
  411f6a:	mov    QWORD PTR [r10+0x10],r11
  411f6e:	movabs r10,0x0
  411f78:	mov    rdi,r10
  411f7b:	jmp    411e7d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  411f80:	movabs r11,0x75
  411f8a:	cmp    rdi,r11
  411f8d:	jne    411ff5 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1c3>
  411f93:	mov    rdi,QWORD PTR [r12+0x10]
  411f98:	movabs r11,0xfffffffffffffff8
  411fa2:	add    rdi,r11
  411fa5:	mov    QWORD PTR [r12+0x10],rdi
  411faa:	mov    rdi,QWORD PTR [r12+0x10]
  411faf:	mov    r10,rdi
  411fb2:	mov    r10,QWORD PTR [r10]
  411fb5:	mov    QWORD PTR [rbp-0x1970],r10
  411fbc:	mov    rdi,r12
  411fbf:	mov    rsi,QWORD PTR [rbp-0x1970]
  411fc6:	mov    rdx,QWORD PTR [rbp-0x58]
  411fca:	xor    eax,eax
  411fcc:	call   40886b <p112w_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>
  411fd1:	mov    QWORD PTR [rbp-0x1978],rax
  411fd8:	movabs r10,0x1
  411fe2:	mov    rdi,r10
  411fe5:	mov    r10,QWORD PTR [rbp-0x1978]
  411fec:	mov    QWORD PTR [rbp-0x58],r10
  411ff0:	jmp    411e7d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  411ff5:	mov    rdi,r12
  411ff8:	movabs rsi,0x4
  412002:	mov    esi,esi
  412004:	xor    eax,eax
  412006:	call   41c720 <p111_rt_fail>
  41200b:	mov    QWORD PTR [rbp-0x1980],rax
  412012:	mov    r12,QWORD PTR [rbp-0x10]
  412016:	mov    rbx,QWORD PTR [rbp-0x8]
  41201a:	mov    r13,QWORD PTR [rbp-0x18]
  41201e:	mov    r14,QWORD PTR [rbp-0x20]
  412022:	mov    r15,QWORD PTR [rbp-0x28]
  412026:	mov    rsp,rbp
  412029:	pop    rbp
  41202a:	ret    
  41202b:	mov    rax,QWORD PTR [rbp-0x58]
  41202f:	mov    r12,QWORD PTR [rbp-0x10]
  412033:	mov    rbx,QWORD PTR [rbp-0x8]
  412037:	mov    r13,QWORD PTR [rbp-0x18]
  41203b:	mov    r14,QWORD PTR [rbp-0x20]
  41203f:	mov    r15,QWORD PTR [rbp-0x28]
  412043:	mov    rsp,rbp
  412046:	pop    rbp
  412047:	ret    
  412048:	mov    rdi,r13
  41204b:	shr    rdi,0x28
  41204f:	and    rdi,0xffff
  412056:	movabs r11,0xa4
  412060:	cmp    rdi,r11
  412063:	jne    41240a <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x5d8>
  412069:	mov    r10,r13
  41206c:	shr    r10,0x28
  412070:	mov    QWORD PTR [rbp-0x1998],r10
  412077:	and    r10,0x7fffff
  41207e:	mov    QWORD PTR [rbp-0x19a0],r10
  412085:	movabs r10,0xa4
  41208f:	or     r10,0x10000
  412096:	mov    QWORD PTR [rbp-0x19a8],r10
  41209d:	mov    r10,QWORD PTR [rbp-0x19a0]
  4120a4:	mov    r11,QWORD PTR [rbp-0x19a8]
  4120ab:	cmp    r10,r11
  4120ae:	jne    4120e1 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2af>
  4120b4:	mov    r10,r13
  4120b7:	movabs r11,0xffffffffff
  4120c1:	and    r10,r11
  4120c4:	mov    QWORD PTR [rbp-0x19b8],r10
  4120cb:	lea    r10,[rbp-0x860]
  4120d2:	mov    r11,QWORD PTR [rbp-0x19b8]
  4120d9:	mov    QWORD PTR [r10],r11
  4120dc:	jmp    4120fc <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2ca>
  4120e1:	mov    rdi,r12
  4120e4:	mov    rsi,r13
  4120e7:	lea    rdx,[rbp-0x860]
  4120ee:	xor    eax,eax
  4120f0:	call   421ab0 <p125_rt_take1>
  4120f5:	mov    QWORD PTR [rbp-0x19c0],rax
  4120fc:	lea    r10,[rbp-0x860]
  412103:	mov    r10,QWORD PTR [r10]
  412106:	mov    QWORD PTR [rbp-0x19c8],r10
  41210d:	mov    rdi,rbx
  412110:	shr    rdi,0x28
  412114:	and    rdi,0xffff
  41211b:	movabs r11,0xa4
  412125:	cmp    rdi,r11
  412128:	jne    41225b <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x429>
  41212e:	mov    r10,rbx
  412131:	shr    r10,0x28
  412135:	mov    QWORD PTR [rbp-0x19d0],r10
  41213c:	and    r10,0x7fffff
  412143:	mov    QWORD PTR [rbp-0x19d8],r10
  41214a:	movabs r10,0xa4
  412154:	or     r10,0x10000
  41215b:	mov    QWORD PTR [rbp-0x19e0],r10
  412162:	mov    r10,QWORD PTR [rbp-0x19d8]
  412169:	mov    r11,QWORD PTR [rbp-0x19e0]
  412170:	cmp    r10,r11
  412173:	jne    4121a6 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x374>
  412179:	mov    r10,rbx
  41217c:	movabs r11,0xffffffffff
  412186:	and    r10,r11
  412189:	mov    QWORD PTR [rbp-0x19f0],r10
  412190:	lea    r10,[rbp-0x860]
  412197:	mov    r11,QWORD PTR [rbp-0x19f0]
  41219e:	mov    QWORD PTR [r10],r11
  4121a1:	jmp    4121c1 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x38f>
  4121a6:	mov    rdi,r12
  4121a9:	mov    rsi,rbx
  4121ac:	lea    rdx,[rbp-0x860]
  4121b3:	xor    eax,eax
  4121b5:	call   421ab0 <p125_rt_take1>
  4121ba:	mov    QWORD PTR [rbp-0x19c0],rax
  4121c1:	lea    r10,[rbp-0x860]
  4121c8:	mov    rdi,QWORD PTR [r10]
  4121cb:	lea    r10,[rbp-0x860]
  4121d2:	mov    r11,QWORD PTR [rbp-0x19c8]
  4121d9:	mov    QWORD PTR [r10],r11
  4121dc:	lea    r10,[rbp-0x860]
  4121e3:	mov    r11,rdi
  4121e6:	mov    QWORD PTR [r10+0x8],r11
  4121ea:	lea    r10,[rbp-0x860]
  4121f1:	mov    r11,r14
  4121f4:	mov    QWORD PTR [r10+0x10],r11
  4121f8:	mov    r10,r12
  4121fb:	mov    QWORD PTR [rsp+0x20],r10
  412200:	mov    r10,QWORD PTR [rbp-0x19c8]
  412207:	mov    QWORD PTR [rsp+0x28],r10
  41220c:	mov    r10,rdi
  41220f:	mov    QWORD PTR [rsp+0x30],r10
  412214:	mov    r10,r14
  412217:	mov    QWORD PTR [rsp+0x38],r10
  41221c:	mov    rdi,QWORD PTR [rsp+0x20]
  412221:	mov    rsi,QWORD PTR [rsp+0x28]
  412226:	mov    rdx,QWORD PTR [rsp+0x30]
  41222b:	mov    rcx,QWORD PTR [rsp+0x38]
  412230:	xor    eax,eax
  412232:	call   408e82 <p112w_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_108_101_97_102_>
  412237:	mov    QWORD PTR [rbp-0x1a00],rax
  41223e:	movabs r10,0x1
  412248:	mov    rdi,r10
  41224b:	mov    r10,QWORD PTR [rbp-0x1a00]
  412252:	mov    QWORD PTR [rbp-0x58],r10
  412256:	jmp    411e7d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  41225b:	mov    rdi,r12
  41225e:	mov    rsi,QWORD PTR [rbp-0x19c8]
  412265:	xor    eax,eax
  412267:	call   41bf90 <p111_rt_sink>
  41226c:	mov    QWORD PTR [rbp-0x19c0],rax
  412273:	mov    rdi,rbx
  412276:	shr    rdi,0x28
  41227a:	and    rdi,0xffff
  412281:	movabs r11,0xa5
  41228b:	cmp    rdi,r11
  41228e:	jne    412322 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4f0>
  412294:	mov    rdi,r12
  412297:	mov    rsi,rbx
  41229a:	lea    rdx,[rbp-0x860]
  4122a1:	xor    eax,eax
  4122a3:	call   421d30 <p125_rt_take2>
  4122a8:	mov    QWORD PTR [rbp-0x19c0],rax
  4122af:	lea    r10,[rbp-0x860]
  4122b6:	mov    r10,QWORD PTR [r10]
  4122b9:	mov    QWORD PTR [rbp-0x1a08],r10
  4122c0:	lea    r10,[rbp-0x860]
  4122c7:	mov    r10,QWORD PTR [r10+0x8]
  4122cb:	mov    QWORD PTR [rbp-0x1a10],r10
  4122d2:	mov    rdi,r12
  4122d5:	mov    rsi,QWORD PTR [rbp-0x1a08]
  4122dc:	xor    eax,eax
  4122de:	call   41bf90 <p111_rt_sink>
  4122e3:	mov    QWORD PTR [rbp-0x19c0],rax
  4122ea:	mov    rdi,r12
  4122ed:	mov    rsi,QWORD PTR [rbp-0x1a10]
  4122f4:	xor    eax,eax
  4122f6:	call   41bf90 <p111_rt_sink>
  4122fb:	mov    QWORD PTR [rbp-0x19c0],rax
  412302:	movabs r10,0x1
  41230c:	mov    rdi,r10
  41230f:	movabs r10,0x100a40000000000
  412319:	mov    QWORD PTR [rbp-0x58],r10
  41231d:	jmp    411e7d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  412322:	lea    r10,[rbp-0x860]
  412329:	mov    r11,r14
  41232c:	mov    QWORD PTR [r10],r11
  41232f:	mov    r10,r12
  412332:	mov    r10,QWORD PTR [r10+0x10]
  412336:	mov    QWORD PTR [rbp-0x1a18],r10
  41233d:	mov    r11,r14
  412340:	mov    QWORD PTR [r10],r11
  412343:	mov    r10,QWORD PTR [rbp-0x1a18]
  41234a:	movabs r11,0x72
  412354:	mov    QWORD PTR [r10+0x8],r11
  412358:	mov    r10,QWORD PTR [rbp-0x1a18]
  41235f:	add    r10,0x10
  412366:	mov    QWORD PTR [rbp-0x1a20],r10
  41236d:	mov    r10,r12
  412370:	mov    r11,QWORD PTR [rbp-0x1a20]
  412377:	mov    QWORD PTR [r10+0x10],r11
  41237b:	lea    r10,[rbp-0x860]
  412382:	mov    r11,rbx
  412385:	mov    QWORD PTR [r10],r11
  412388:	mov    r10,r12
  41238b:	mov    r10,QWORD PTR [r10+0x10]
  41238f:	mov    QWORD PTR [rbp-0x1a28],r10
  412396:	mov    r11,rbx
  412399:	mov    QWORD PTR [r10],r11
  41239c:	mov    r10,QWORD PTR [rbp-0x1a28]
  4123a3:	movabs r11,0x73
  4123ad:	mov    QWORD PTR [r10+0x8],r11
  4123b1:	mov    r10,QWORD PTR [rbp-0x1a28]
  4123b8:	add    r10,0x10
  4123bf:	mov    QWORD PTR [rbp-0x1a30],r10
  4123c6:	mov    r10,r12
  4123c9:	mov    r11,QWORD PTR [rbp-0x1a30]
  4123d0:	mov    QWORD PTR [r10+0x10],r11
  4123d4:	mov    rdi,r12
  4123d7:	movabs rsi,0x4
  4123e1:	mov    esi,esi
  4123e3:	xor    eax,eax
  4123e5:	call   41c720 <p111_rt_fail>
  4123ea:	mov    QWORD PTR [rbp-0x1a38],rax
  4123f1:	mov    r12,QWORD PTR [rbp-0x10]
  4123f5:	mov    rbx,QWORD PTR [rbp-0x8]
  4123f9:	mov    r13,QWORD PTR [rbp-0x18]
  4123fd:	mov    r14,QWORD PTR [rbp-0x20]
  412401:	mov    r15,QWORD PTR [rbp-0x28]
  412405:	mov    rsp,rbp
  412408:	pop    rbp
  412409:	ret    
  41240a:	mov    rdi,r13
  41240d:	shr    rdi,0x28
  412411:	and    rdi,0xffff
  412418:	movabs r11,0xa5
  412422:	cmp    rdi,r11
  412425:	jne    4127e7 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9b5>
  41242b:	mov    rdi,r12
  41242e:	mov    rsi,r13
  412431:	lea    rdx,[rbp-0x860]
  412438:	xor    eax,eax
  41243a:	call   421d30 <p125_rt_take2>
  41243f:	mov    QWORD PTR [rbp-0x19c0],rax
  412446:	lea    r10,[rbp-0x860]
  41244d:	mov    r10,QWORD PTR [r10]
  412450:	mov    QWORD PTR [rbp-0x1a40],r10
  412457:	lea    r10,[rbp-0x860]
  41245e:	mov    r10,QWORD PTR [r10+0x8]
  412462:	mov    QWORD PTR [rbp-0x1a48],r10
  412469:	mov    rdi,rbx
  41246c:	shr    rdi,0x28
  412470:	and    rdi,0xffff
  412477:	movabs r11,0xa4
  412481:	cmp    rdi,r11
  412484:	jne    412596 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x764>
  41248a:	mov    r10,rbx
  41248d:	shr    r10,0x28
  412491:	mov    QWORD PTR [rbp-0x1a50],r10
  412498:	and    r10,0x7fffff
  41249f:	mov    QWORD PTR [rbp-0x1a58],r10
  4124a6:	movabs r10,0xa4
  4124b0:	or     r10,0x10000
  4124b7:	mov    QWORD PTR [rbp-0x1a60],r10
  4124be:	mov    r10,QWORD PTR [rbp-0x1a58]
  4124c5:	mov    r11,QWORD PTR [rbp-0x1a60]
  4124cc:	cmp    r10,r11
  4124cf:	jne    412502 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6d0>
  4124d5:	mov    r10,rbx
  4124d8:	movabs r11,0xffffffffff
  4124e2:	and    r10,r11
  4124e5:	mov    QWORD PTR [rbp-0x1a70],r10
  4124ec:	lea    r10,[rbp-0x860]
  4124f3:	mov    r11,QWORD PTR [rbp-0x1a70]
  4124fa:	mov    QWORD PTR [r10],r11
  4124fd:	jmp    41251d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6eb>
  412502:	mov    rdi,r12
  412505:	mov    rsi,rbx
  412508:	lea    rdx,[rbp-0x860]
  41250f:	xor    eax,eax
  412511:	call   421ab0 <p125_rt_take1>
  412516:	mov    QWORD PTR [rbp-0x19c0],rax
  41251d:	lea    r10,[rbp-0x860]
  412524:	mov    r10,QWORD PTR [r10]
  412527:	mov    QWORD PTR [rbp-0x1a78],r10
  41252e:	mov    rdi,r12
  412531:	mov    rsi,QWORD PTR [rbp-0x1a40]
  412538:	xor    eax,eax
  41253a:	call   41bf90 <p111_rt_sink>
  41253f:	mov    QWORD PTR [rbp-0x19c0],rax
  412546:	mov    rdi,r12
  412549:	mov    rsi,QWORD PTR [rbp-0x1a48]
  412550:	xor    eax,eax
  412552:	call   41bf90 <p111_rt_sink>
  412557:	mov    QWORD PTR [rbp-0x19c0],rax
  41255e:	mov    rdi,r12
  412561:	mov    rsi,QWORD PTR [rbp-0x1a78]
  412568:	xor    eax,eax
  41256a:	call   41bf90 <p111_rt_sink>
  41256f:	mov    QWORD PTR [rbp-0x19c0],rax
  412576:	movabs r10,0x1
  412580:	mov    rdi,r10
  412583:	movabs r10,0x100a40000000000
  41258d:	mov    QWORD PTR [rbp-0x58],r10
  412591:	jmp    411e7d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  412596:	mov    rdi,rbx
  412599:	shr    rdi,0x28
  41259d:	and    rdi,0xffff
  4125a4:	movabs r11,0xa5
  4125ae:	cmp    rdi,r11
  4125b1:	jne    4126cf <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x89d>
  4125b7:	mov    rdi,r12
  4125ba:	mov    rsi,rbx
  4125bd:	lea    rdx,[rbp-0x860]
  4125c4:	xor    eax,eax
  4125c6:	call   421d30 <p125_rt_take2>
  4125cb:	mov    QWORD PTR [rbp-0x19c0],rax
  4125d2:	lea    r10,[rbp-0x860]
  4125d9:	mov    rbx,QWORD PTR [r10]
  4125dc:	lea    r10,[rbp-0x860]
  4125e3:	mov    r10,QWORD PTR [r10+0x8]
  4125e7:	mov    QWORD PTR [rbp-0x1a88],r10
  4125ee:	lea    r10,[rbp-0x860]
  4125f5:	mov    r11,QWORD PTR [rbp-0x1a48]
  4125fc:	mov    QWORD PTR [r10],r11
  4125ff:	lea    r10,[rbp-0x860]
  412606:	mov    r11,r14
  412609:	mov    QWORD PTR [r10+0x8],r11
  41260d:	lea    r10,[rbp-0x860]
  412614:	mov    r11,QWORD PTR [rbp-0x1a88]
  41261b:	mov    QWORD PTR [r10+0x10],r11
  41261f:	mov    rdi,QWORD PTR [r12+0x10]
  412624:	mov    r10,rdi
  412627:	mov    r11,QWORD PTR [rbp-0x1a48]
  41262e:	mov    QWORD PTR [r10],r11
  412631:	lea    r10,[rbp-0x860]
  412638:	mov    rsi,QWORD PTR [r10+0x8]
  41263c:	mov    QWORD PTR [rdi+0x8],rsi
  412640:	lea    r10,[rbp-0x860]
  412647:	mov    rsi,QWORD PTR [r10+0x10]
  41264b:	mov    QWORD PTR [rdi+0x10],rsi
  41264f:	mov    r10,rdi
  412652:	movabs r11,0x74
  41265c:	mov    QWORD PTR [r10+0x18],r11
  412660:	mov    r10,rdi
  412663:	add    r10,0x20
  41266a:	mov    QWORD PTR [rbp-0x1aa0],r10
  412671:	mov    r10,r12
  412674:	mov    r11,QWORD PTR [rbp-0x1aa0]
  41267b:	mov    QWORD PTR [r10+0x10],r11
  41267f:	add    r15,0x1
  412686:	lea    r10,[rbp-0x860]
  41268d:	mov    r11,QWORD PTR [rbp-0x1a40]
  412694:	mov    QWORD PTR [r10],r11
  412697:	lea    r10,[rbp-0x860]
  41269e:	mov    r11,rbx
  4126a1:	mov    QWORD PTR [r10+0x8],r11
  4126a5:	lea    r10,[rbp-0x860]
  4126ac:	mov    r11,r14
  4126af:	mov    QWORD PTR [r10+0x10],r11
  4126b3:	mov    r10,QWORD PTR [rbp-0x1a40]
  4126ba:	mov    r13,r10
  4126bd:	movabs r10,0x0
  4126c7:	mov    rdi,r10
  4126ca:	jmp    411e7d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  4126cf:	mov    rdi,r12
  4126d2:	mov    rsi,QWORD PTR [rbp-0x1a40]
  4126d9:	xor    eax,eax
  4126db:	call   41bf90 <p111_rt_sink>
  4126e0:	mov    QWORD PTR [rbp-0x19c0],rax
  4126e7:	mov    rdi,r12
  4126ea:	mov    rsi,QWORD PTR [rbp-0x1a48]
  4126f1:	xor    eax,eax
  4126f3:	call   41bf90 <p111_rt_sink>
  4126f8:	mov    QWORD PTR [rbp-0x19c0],rax
  4126ff:	lea    r10,[rbp-0x860]
  412706:	mov    r11,r14
  412709:	mov    QWORD PTR [r10],r11
  41270c:	mov    r10,r12
  41270f:	mov    r10,QWORD PTR [r10+0x10]
  412713:	mov    QWORD PTR [rbp-0x1aa8],r10
  41271a:	mov    r11,r14
  41271d:	mov    QWORD PTR [r10],r11
  412720:	mov    r10,QWORD PTR [rbp-0x1aa8]
  412727:	movabs r11,0x76
  412731:	mov    QWORD PTR [r10+0x8],r11
  412735:	mov    r10,QWORD PTR [rbp-0x1aa8]
  41273c:	add    r10,0x10
  412743:	mov    QWORD PTR [rbp-0x1ab0],r10
  41274a:	mov    r10,r12
  41274d:	mov    r11,QWORD PTR [rbp-0x1ab0]
  412754:	mov    QWORD PTR [r10+0x10],r11
  412758:	lea    r10,[rbp-0x860]
  41275f:	mov    r11,rbx
  412762:	mov    QWORD PTR [r10],r11
  412765:	mov    r10,r12
  412768:	mov    r10,QWORD PTR [r10+0x10]
  41276c:	mov    QWORD PTR [rbp-0x1ab8],r10
  412773:	mov    r11,rbx
  412776:	mov    QWORD PTR [r10],r11
  412779:	mov    r10,QWORD PTR [rbp-0x1ab8]
  412780:	movabs r11,0x77
  41278a:	mov    QWORD PTR [r10+0x8],r11
  41278e:	mov    r10,QWORD PTR [rbp-0x1ab8]
  412795:	add    r10,0x10
  41279c:	mov    QWORD PTR [rbp-0x1ac0],r10
  4127a3:	mov    r10,r12
  4127a6:	mov    r11,QWORD PTR [rbp-0x1ac0]
  4127ad:	mov    QWORD PTR [r10+0x10],r11
  4127b1:	mov    rdi,r12
  4127b4:	movabs rsi,0x4
  4127be:	mov    esi,esi
  4127c0:	xor    eax,eax
  4127c2:	call   41c720 <p111_rt_fail>
  4127c7:	mov    QWORD PTR [rbp-0x1a38],rax
  4127ce:	mov    r12,QWORD PTR [rbp-0x10]
  4127d2:	mov    rbx,QWORD PTR [rbp-0x8]
  4127d6:	mov    r13,QWORD PTR [rbp-0x18]
  4127da:	mov    r14,QWORD PTR [rbp-0x20]
  4127de:	mov    r15,QWORD PTR [rbp-0x28]
  4127e2:	mov    rsp,rbp
  4127e5:	pop    rbp
  4127e6:	ret    
  4127e7:	lea    r10,[rbp-0x860]
  4127ee:	mov    r11,r14
  4127f1:	mov    QWORD PTR [r10],r11
  4127f4:	mov    r10,r12
  4127f7:	mov    r10,QWORD PTR [r10+0x10]
  4127fb:	mov    QWORD PTR [rbp-0x1ac8],r10
  412802:	mov    r11,r14
  412805:	mov    QWORD PTR [r10],r11
  412808:	mov    r10,QWORD PTR [rbp-0x1ac8]
  41280f:	movabs r11,0x78
  412819:	mov    QWORD PTR [r10+0x8],r11
  41281d:	mov    r10,QWORD PTR [rbp-0x1ac8]
  412824:	add    r10,0x10
  41282b:	mov    QWORD PTR [rbp-0x1ad0],r10
  412832:	mov    r10,r12
  412835:	mov    r11,QWORD PTR [rbp-0x1ad0]
  41283c:	mov    QWORD PTR [r10+0x10],r11
  412840:	lea    r10,[rbp-0x860]
  412847:	mov    r11,rbx
  41284a:	mov    QWORD PTR [r10],r11
  41284d:	mov    r10,r12
  412850:	mov    r10,QWORD PTR [r10+0x10]
  412854:	mov    QWORD PTR [rbp-0x1ad8],r10
  41285b:	mov    r11,rbx
  41285e:	mov    QWORD PTR [r10],r11
  412861:	mov    r10,QWORD PTR [rbp-0x1ad8]
  412868:	movabs r11,0x79
  412872:	mov    QWORD PTR [r10+0x8],r11
  412876:	mov    r10,QWORD PTR [rbp-0x1ad8]
  41287d:	add    r10,0x10
  412884:	mov    QWORD PTR [rbp-0x1ae0],r10
  41288b:	mov    r10,r12
  41288e:	mov    r11,QWORD PTR [rbp-0x1ae0]
  412895:	mov    QWORD PTR [r10+0x10],r11
  412899:	lea    r10,[rbp-0x860]
  4128a0:	mov    r11,r13
  4128a3:	mov    QWORD PTR [r10],r11
  4128a6:	mov    r10,r12
  4128a9:	mov    r10,QWORD PTR [r10+0x10]
  4128ad:	mov    QWORD PTR [rbp-0x1ae8],r10
  4128b4:	mov    r11,r13
  4128b7:	mov    QWORD PTR [r10],r11
  4128ba:	mov    r10,QWORD PTR [rbp-0x1ae8]
  4128c1:	movabs r11,0x7a
  4128cb:	mov    QWORD PTR [r10+0x8],r11
  4128cf:	mov    r10,QWORD PTR [rbp-0x1ae8]
  4128d6:	add    r10,0x10
  4128dd:	mov    QWORD PTR [rbp-0x1af0],r10
  4128e4:	mov    r10,r12
  4128e7:	mov    r11,QWORD PTR [rbp-0x1af0]
  4128ee:	mov    QWORD PTR [r10+0x10],r11
  4128f2:	mov    rdi,r12
  4128f5:	movabs rsi,0x4
  4128ff:	mov    esi,esi
  412901:	xor    eax,eax
  412903:	call   41c720 <p111_rt_fail>
  412908:	mov    QWORD PTR [rbp-0x1a38],rax
  41290f:	mov    r12,QWORD PTR [rbp-0x10]
  412913:	mov    rbx,QWORD PTR [rbp-0x8]
  412917:	mov    r13,QWORD PTR [rbp-0x18]
  41291b:	mov    r14,QWORD PTR [rbp-0x20]
  41291f:	mov    r15,QWORD PTR [rbp-0x28]
  412923:	mov    rsp,rbp
  412926:	pop    rbp
  412927:	ret    

