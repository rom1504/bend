
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403350 <nx_rt_fast_field>:
  403350:	mov    %esi,%ecx
  403352:	mov    $0xfffffffe,%eax
  403357:	rol    %cl,%eax
  403359:	add    $0x2,%rcx
  40335d:	and    %eax,0x20(%rdi)
  403360:	mov    (%rdi,%rcx,8),%rax
  403364:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  40336c:	retq   

Disassembly of section .fini:
