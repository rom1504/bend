000000000041dd50 <p125_rt_ctor3>:
  41dd50:	push   r15
  41dd52:	mov    rax,rdi
  41dd55:	push   r14
  41dd57:	push   r13
  41dd59:	push   r12
  41dd5b:	mov    r12,rdx
  41dd5e:	push   rbp
  41dd5f:	push   rbx
  41dd60:	mov    ebx,esi
  41dd62:	sub    rsp,0x18
  41dd66:	mov    r14,QWORD PTR [rax+0x8]
  41dd6a:	mov    rdi,QWORD PTR [rdi]
  41dd6d:	mov    r13,QWORD PTR [r14+0x10]
  41dd71:	test   r13,r13
  41dd74:	je     405085 <p125_rt_ctor3.cold>
  41dd7a:	mov    rax,QWORD PTR [rdi+r13*8]
  41dd7e:	sub    QWORD PTR [r14+0x110],0x4
  41dd86:	mov    QWORD PTR [r14+0x10],rax
  41dd8a:	mov    rax,QWORD PTR [rip+0x108d3f]        # 526ad0 <p111_program_active>
  41dd91:	test   BYTE PTR [rax+0x58],0x8
  41dd95:	je     41dda4 <p125_rt_ctor3+0x54>
  41dd97:	mov    rax,QWORD PTR [rax+0x88]
  41dd9e:	cmp    BYTE PTR [rax+rbx*1],0x0
  41dda2:	je     41de00 <p125_rt_ctor3+0xb0>
  41dda4:	lea    r15,[rdi+r13*8]
  41dda8:	xor    ebp,ebp
  41ddaa:	mov    rdx,QWORD PTR [r12+rbp*1]
  41ddae:	mov    rax,rdx
  41ddb1:	shr    rax,0x38
  41ddb5:	and    eax,0x7f
  41ddb8:	cmp    rax,0x2
  41ddbc:	je     41ddf0 <p125_rt_ctor3+0xa0>
  41ddbe:	mov    QWORD PTR [r15+rbp*1],rdx
  41ddc2:	add    rbp,0x8
  41ddc6:	cmp    rbp,0x18
  41ddca:	jne    41ddaa <p125_rt_ctor3+0x5a>
  41ddcc:	mov    rax,rbx
  41ddcf:	add    rsp,0x18
  41ddd3:	shl    rax,0x28
  41ddd7:	pop    rbx
  41ddd8:	pop    rbp
  41ddd9:	or     rax,r13
  41dddc:	pop    r12
  41ddde:	pop    r13
  41dde0:	bts    rax,0x39
  41dde5:	pop    r14
  41dde7:	pop    r15
  41dde9:	ret    
  41ddea:	nop    WORD PTR [rax+rax*1+0x0]
  41ddf0:	test   rdx,rdx
  41ddf3:	js     41ddbe <p125_rt_ctor3+0x6e>
  41ddf5:	jmp    4050a4 <p125_rt_ctor3.cold+0x1f>
  41ddfa:	nop    WORD PTR [rax+rax*1+0x0]
  41de00:	lea    rcx,[rdi+r13*8]
  41de04:	xor    eax,eax
  41de06:	mov    rdx,QWORD PTR [r12+rax*1]
  41de0a:	mov    QWORD PTR [rcx+rax*1],rdx
  41de0e:	add    rax,0x8
  41de12:	cmp    rax,0x18
  41de16:	jne    41de06 <p125_rt_ctor3+0xb6>
  41de18:	jmp    41ddcc <p125_rt_ctor3+0x7c>
  41de1a:	nop    WORD PTR [rax+rax*1+0x0]

