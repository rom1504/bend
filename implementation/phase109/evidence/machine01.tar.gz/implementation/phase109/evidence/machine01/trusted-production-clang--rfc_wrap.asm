
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401168 <rfc_wrap>:
  401168:	push   %r10
  40116a:	push   %r9
  40116c:	push   %r8
  40116e:	push   %rdi
  40116f:	push   %rsi
  401170:	push   %rdx
  401171:	push   %rcx
  401172:	mov    %rdx,%rax
  401175:	shr    $0x38,%rax
  401179:	and    $0x7f,%eax
  40117c:	cmp    $0x5,%rax
  401180:	je     4011dc <rfc_wrap+0x74>
  401182:	cmp    $0x3,%eax
  401185:	je     4011dc <rfc_wrap+0x74>
  401187:	mov    %rdx,%r8
  40118a:	mov    (%rsi),%rax
  40118d:	test   %rax,%rax
  401190:	je     4011d3 <rfc_wrap+0x6b>
  401192:	mov    (%rdi,%rax,8),%r11
  401196:	mov    %r11,(%rsi)
  401199:	decq   0x100(%rsi)
  4011a0:	mov    %r8,%r11
  4011a3:	shl    $0x18,%r11
  4011a7:	mov    %ecx,%ecx
  4011a9:	or     %r11,%rcx
  4011ac:	mov    %rcx,(%rdi,%rax,8)
  4011b0:	movabs $0x7fffff0000000000,%r11
  4011ba:	and    %r8,%r11
  4011bd:	or     %rax,%r11
  4011c0:	bts    $0x3f,%r11
  4011c5:	mov    %r11,%rax
  4011c8:	pop    %rcx
  4011c9:	pop    %rdx
  4011ca:	pop    %rsi
  4011cb:	pop    %rdi
  4011cc:	pop    %r8
  4011ce:	pop    %r9
  4011d0:	pop    %r10
  4011d2:	retq   
  4011d3:	xor    %edx,%edx
  4011d5:	callq  401279 <heap_alloc_miss>
  4011da:	jmp    4011a0 <rfc_wrap+0x38>
  4011dc:	lea    0x3153(%rip),%rdi        # 404336 <_IO_stdin_used+0x336>
  4011e3:	callq  401130 <err_fail>

Disassembly of section .fini:
