
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403880 <nx_rt_pair_rebuild2_c3_k0>:
  403880:	push   %r14
  403882:	mov    %rsi,%r10
  403885:	mov    %rdx,%r8
  403888:	movabs $0xffffffffff,%r9
  403892:	push   %r13
  403894:	and    %r10,%r9
  403897:	push   %r12
  403899:	lea    0x0(,%r9,8),%rax
  4038a1:	push   %rbp
  4038a2:	sub    $0x18,%rsp
  4038a6:	mov    (%rdi),%rbp
  4038a9:	mov    0x8(%rdi),%rsi
  4038ad:	lea    0x0(%rbp,%rax,1),%rdx
  4038b2:	test   %r10,%r10
  4038b5:	js     403910 <nx_rt_pair_rebuild2_c3_k0+0x90>
  4038b7:	mov    (%rdx),%r13
  4038ba:	mov    0x8(%rbp,%rax,1),%r12
  4038bf:	cmp    $0x310817f,%r9
  4038c6:	jbe    4038f0 <nx_rt_pair_rebuild2_c3_k0+0x70>
  4038c8:	mov    %r13,%rcx
  4038cb:	mov    $0x3,%edx
  4038d0:	mov    %rbp,%rdi
  4038d3:	callq  401fa0 <nx_construct2>
  4038d8:	add    $0x18,%rsp
  4038dc:	mov    %r12,%rdx
  4038df:	pop    %rbp
  4038e0:	pop    %r12
  4038e2:	pop    %r13
  4038e4:	pop    %r14
  4038e6:	retq   
  4038e7:	nopw   0x0(%rax,%rax,1)
  4038f0:	mov    0x8(%rsi),%r9
  4038f4:	test   %r9,%r9
  4038f7:	je     401907 <nx_rt_pair_rebuild2_c3_k0.cold>
  4038fd:	mov    0x0(%rbp,%r9,8),%rax
  403902:	subq   $0x2,0x108(%rsi)
  40390a:	mov    %rax,0x8(%rsi)
  40390e:	jmp    4038c8 <nx_rt_pair_rebuild2_c3_k0+0x48>
  403910:	mov    0x4(%rdx),%eax
  403913:	mov    (%rdx),%ecx
  403915:	shl    $0x20,%rax
  403919:	or     %rcx,%rax
  40391c:	mov    %rax,%r14
  40391f:	and    $0xffffff,%eax
  403924:	shr    $0x18,%r14
  403928:	lea    0x0(,%r14,8),%rcx
  403930:	lea    0x8(%rbp,%rcx,1),%rdi
  403935:	add    %rbp,%rcx
  403938:	cmp    $0x1,%rax
  40393c:	jne    401945 <nx_rt_pair_rebuild2_c3_k0.cold+0x3e>
  403942:	mov    (%rdx),%eax
  403944:	mov    (%rsi),%rax
  403947:	mov    (%rcx),%r13
  40394a:	mov    (%rdi),%r12
  40394d:	mov    %rax,(%rdx)
  403950:	mov    0x100(%rsi),%rax
  403957:	mov    0x3d87b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40395d:	mov    %r9,(%rsi)
  403960:	add    $0x1,%rax
  403964:	mov    %rax,0x100(%rsi)
  40396b:	cmp    %rdx,%rax
  40396e:	jae    40192e <nx_rt_pair_rebuild2_c3_k0.cold+0x27>
  403974:	mov    %r14,%r9
  403977:	jmpq   4038bf <nx_rt_pair_rebuild2_c3_k0+0x3f>

Disassembly of section .fini:
