
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	push   %r15
  401df2:	push   %r14
  401df4:	push   %rbx
  401df5:	mov    %rdx,%r14
  401df8:	mov    %rsi,%r15
  401dfb:	mov    %rdi,%rbx
  401dfe:	xchg   %ax,%ax
  401e00:	mov    %rbx,%rdi
  401e03:	mov    %r15,%rsi
  401e06:	callq  402c00 <nx_rt_fast_id>
  401e0b:	cmp    $0x1,%eax
  401e0e:	jne    401e37 <nx_list_reverse+0x47>
  401e10:	mov    %rbx,%rdi
  401e13:	mov    %r15,%rsi
  401e16:	mov    $0x1,%edx
  401e1b:	xor    %ecx,%ecx
  401e1d:	mov    %r14,%r8
  401e20:	callq  402ed0 <nx_rt_rebuild2>
  401e25:	mov    %rax,%r14
  401e28:	mov    %rbx,%rdi
  401e2b:	xor    %esi,%esi
  401e2d:	callq  402eb0 <nx_rt_fast_field>
  401e32:	mov    %rax,%r15
  401e35:	jmp    401e00 <nx_list_reverse+0x10>
  401e37:	test   %eax,%eax
  401e39:	jne    401e44 <nx_list_reverse+0x54>
  401e3b:	mov    %r14,%rax
  401e3e:	pop    %rbx
  401e3f:	pop    %r14
  401e41:	pop    %r15
  401e43:	retq   
  401e44:	mov    %rbx,%rdi
  401e47:	mov    $0x1,%esi
  401e4c:	pop    %rbx
  401e4d:	pop    %r14
  401e4f:	pop    %r15
  401e51:	jmpq   4026b0 <nx_rt_fail>

Disassembly of section .fini:
