
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ef0 <nx_rt_fast_field>:
  402ef0:	mov    %esi,%ecx
  402ef2:	mov    $0xfffffffe,%eax
  402ef7:	rol    %cl,%eax
  402ef9:	add    $0x2,%rcx
  402efd:	and    %eax,0x20(%rdi)
  402f00:	mov    (%rdi,%rcx,8),%rax
  402f04:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402f0c:	retq   

Disassembly of section .fini:
