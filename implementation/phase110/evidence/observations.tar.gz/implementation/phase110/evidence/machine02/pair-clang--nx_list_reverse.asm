
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	push   %rbx
  401df1:	mov    %rdx,%rax
  401df4:	mov    %rdi,%rbx
  401df7:	nopw   0x0(%rax,%rax,1)
  401e00:	mov    %rsi,%rcx
  401e03:	shr    $0x28,%rcx
  401e07:	cmp    $0x1,%cx
  401e0b:	jne    401e1d <nx_list_reverse+0x2d>
  401e0d:	mov    %rbx,%rdi
  401e10:	mov    %rax,%rdx
  401e13:	callq  4036b0 <nx_rt_pair_rebuild2_c1_k0>
  401e18:	mov    %rdx,%rsi
  401e1b:	jmp    401e00 <nx_list_reverse+0x10>
  401e1d:	movzwl %cx,%ecx
  401e20:	test   %ecx,%ecx
  401e22:	jne    401e26 <nx_list_reverse+0x36>
  401e24:	pop    %rbx
  401e25:	retq   
  401e26:	mov    %rbx,%rdi
  401e29:	mov    $0x1,%esi
  401e2e:	pop    %rbx
  401e2f:	jmpq   402670 <nx_rt_fail>

Disassembly of section .fini:
