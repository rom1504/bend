
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404270 <nx_rt_pair_rebuild2_c3_k0>:
  404270:	push   %r15
  404272:	push   %r14
  404274:	push   %r13
  404276:	push   %r12
  404278:	mov    %rdx,%r12
  40427b:	push   %rbp
  40427c:	push   %rbx
  40427d:	movabs $0xffffffffff,%rbx
  404287:	and    %rsi,%rbx
  40428a:	lea    0x0(,%rbx,8),%rdx
  404292:	sub    $0x18,%rsp
  404296:	mov    (%rdi),%rbp
  404299:	mov    0x8(%rdi),%r15
  40429d:	lea    0x0(%rbp,%rdx,1),%rax
  4042a2:	test   %rsi,%rsi
  4042a5:	js     404360 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  4042ab:	mov    (%rax),%r14
  4042ae:	mov    0x8(%rbp,%rdx,1),%r13
  4042b3:	cmp    $0x310817f,%rbx
  4042ba:	jbe    404330 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  4042bc:	lea    0x0(%rbp,%rbx,8),%r8
  4042c1:	mov    %r14,%rax
  4042c4:	shr    $0x38,%rax
  4042c8:	and    $0x7f,%eax
  4042cb:	cmp    $0x2,%rax
  4042cf:	je     404310 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  4042d1:	mov    %r12,%rax
  4042d4:	mov    %r14,(%r8)
  4042d7:	lea    0x8(%rbp,%rbx,8),%r14
  4042dc:	shr    $0x38,%rax
  4042e0:	and    $0x7f,%eax
  4042e3:	cmp    $0x2,%rax
  4042e7:	je     404320 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  4042e9:	movabs $0x200030000000000,%rax
  4042f3:	mov    %r12,(%r14)
  4042f6:	mov    %r13,%rdx
  4042f9:	add    $0x18,%rsp
  4042fd:	or     %rbx,%rax
  404300:	pop    %rbx
  404301:	pop    %rbp
  404302:	pop    %r12
  404304:	pop    %r13
  404306:	pop    %r14
  404308:	pop    %r15
  40430a:	retq   
  40430b:	nopl   0x0(%rax,%rax,1)
  404310:	test   %r14,%r14
  404313:	js     4042d1 <nx_rt_pair_rebuild2_c3_k0+0x61>
  404315:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  40431a:	nopw   0x0(%rax,%rax,1)
  404320:	test   %r12,%r12
  404323:	js     4042e9 <nx_rt_pair_rebuild2_c3_k0+0x79>
  404325:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  40432a:	nopw   0x0(%rax,%rax,1)
  404330:	mov    0x8(%r15),%rbx
  404334:	test   %rbx,%rbx
  404337:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  40433d:	lea    0x0(%rbp,%rbx,8),%r8
  404342:	mov    (%r8),%rax
  404345:	subq   $0x2,0x108(%r15)
  40434d:	mov    %rax,0x8(%r15)
  404351:	jmpq   4042c1 <nx_rt_pair_rebuild2_c3_k0+0x51>
  404356:	nopw   %cs:0x0(%rax,%rax,1)
  404360:	mov    0x4(%rax),%edx
  404363:	mov    (%rax),%ecx
  404365:	shl    $0x20,%rdx
  404369:	or     %rcx,%rdx
  40436c:	mov    %rdx,%rcx
  40436f:	and    $0xffffff,%edx
  404375:	shr    $0x18,%rcx
  404379:	lea    0x8(,%rcx,8),%rdi
  404381:	lea    0x0(%rbp,%rdi,1),%r8
  404386:	lea    -0x8(%rbp,%rdi,1),%rdi
  40438b:	cmp    $0x1,%rdx
  40438f:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  404395:	mov    (%rax),%edx
  404397:	mov    (%r15),%rdx
  40439a:	mov    (%rdi),%r14
  40439d:	mov    (%r8),%r13
  4043a0:	mov    %rdx,(%rax)
  4043a3:	mov    0x100(%r15),%rax
  4043aa:	mov    0x3de28(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4043b0:	mov    %rbx,(%r15)
  4043b3:	add    $0x1,%rax
  4043b7:	mov    %rax,0x100(%r15)
  4043be:	cmp    %rdx,%rax
  4043c1:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  4043c7:	mov    %rcx,%rbx
  4043ca:	jmpq   4042b3 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
