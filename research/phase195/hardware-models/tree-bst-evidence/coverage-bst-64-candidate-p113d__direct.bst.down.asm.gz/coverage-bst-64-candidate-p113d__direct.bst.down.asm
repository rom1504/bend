0000000000408eda <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_>:
  408eda:	push   rbp
  408edb:	mov    rbp,rsp
  408ede:	sub    rsp,0x920
  408ee5:	mov    QWORD PTR [rbp-0x10],r12
  408ee9:	mov    QWORD PTR [rbp-0x8],rbx
  408eed:	mov    QWORD PTR [rbp-0x18],r13
  408ef1:	mov    rax,rdi
  408ef4:	mov    r12,rax
  408ef7:	mov    rax,rsi
  408efa:	mov    rdi,rax
  408efd:	mov    rax,rdx
  408f00:	mov    rbx,rax
  408f03:	mov    rax,rcx
  408f06:	mov    rdx,rax
  408f09:	cmp    rdi,0x0
  408f10:	jne    408f2a <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x50>
  408f16:	mov    rax,rdx
  408f19:	mov    r12,QWORD PTR [rbp-0x10]
  408f1d:	mov    rbx,QWORD PTR [rbp-0x8]
  408f21:	mov    r13,QWORD PTR [rbp-0x18]
  408f25:	mov    rsp,rbp
  408f28:	pop    rbp
  408f29:	ret    
  408f2a:	mov    r13,rdi
  408f2d:	sub    r13,0x1
  408f34:	mov    r10,r12
  408f37:	mov    QWORD PTR [rsp+0x18],r10
  408f3c:	mov    r10,rbx
  408f3f:	mov    QWORD PTR [rsp+0x20],r10
  408f44:	mov    r10,rdx
  408f47:	mov    QWORD PTR [rsp+0x28],r10
  408f4c:	mov    rdi,QWORD PTR [rsp+0x18]
  408f51:	mov    rsi,QWORD PTR [rsp+0x20]
  408f56:	mov    rdx,QWORD PTR [rsp+0x28]
  408f5b:	xor    eax,eax
  408f5d:	call   40891c <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_>
  408f62:	mov    rdx,rax
  408f65:	mov    rdi,r13
  408f68:	jmp    408f09 <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2f>

