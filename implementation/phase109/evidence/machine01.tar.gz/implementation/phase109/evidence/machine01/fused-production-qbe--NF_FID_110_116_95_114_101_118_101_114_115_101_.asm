
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403930 <NF_FID_110_116_95_114_101_118_101_114_115_101_>:
  403930:	endbr64 
  403934:	push   %rbp
  403935:	mov    %rsp,%rbp
  403938:	sub    $0x28,%rsp
  40393c:	push   %rbx
  40393d:	push   %r12
  40393f:	push   %r13
  403941:	push   %r14
  403943:	push   %r15
  403945:	mov    %r9,%r15
  403948:	mov    %r8,%rdx
  40394b:	mov    %rcx,%r12
  40394e:	mov    %rdi,-0x20(%rbp)
  403952:	mov    %rsi,-0x18(%rbp)
  403956:	mov    %rdx,%r13
  403959:	mov    $0x0,%ebx
  40395e:	xchg   %ax,%ax
  403960:	add    $0x1,%ebx
  403963:	mov    %r13,%rdi
  403966:	callq  401b30 <term_aux>
  40396b:	cmp    $0x0,%rax
  40396f:	je     403a85 <NF_FID_110_116_95_114_101_118_101_114_115_101_+0x155>
  403975:	mov    %r13,%rdi
  403978:	callq  401b30 <term_aux>
  40397d:	cmp    $0x1,%rax
  403981:	jne    403a50 <NF_FID_110_116_95_114_101_118_101_114_115_101_+0x120>
  403987:	mov    $0x2,%edi
  40398c:	callq  4015a0 <cls_fit>
  403991:	mov    %r13,%r8
  403994:	mov    %r12,%rcx
  403997:	mov    %eax,%edx
  403999:	mov    %r8,%r14
  40399c:	lea    -0x10(%rbp),%r8
  4039a0:	mov    %rcx,%r13
  4039a3:	mov    $0x2,%ecx
  4039a8:	mov    %edx,%r12d
  4039ab:	mov    %r14,%rdx
  4039ae:	mov    -0x20(%rbp),%rdi
  4039b2:	mov    -0x18(%rbp),%rsi
  4039b6:	callq  402390 <ctr_take>
  4039bb:	mov    %r12d,%edx
  4039be:	mov    %rax,%rcx
  4039c1:	mov    -0x20(%rbp),%rdi
  4039c5:	mov    -0x18(%rbp),%rsi
  4039c9:	callq  401aa0 <spare_free>
  4039ce:	mov    -0x10(%rbp),%r12
  4039d2:	mov    -0x8(%rbp),%r14
  4039d6:	mov    $0x2,%edi
  4039db:	callq  4015a0 <cls_fit>
  4039e0:	mov    %eax,%edx
  4039e2:	mov    -0x20(%rbp),%rdi
  4039e6:	mov    -0x18(%rbp),%rsi
  4039ea:	callq  4019b0 <heap_alloc>
  4039ef:	mov    %r12,%rdx
  4039f2:	mov    %rax,%r12
  4039f5:	mov    -0x20(%rbp),%rdi
  4039f9:	mov    -0x18(%rbp),%rsi
  4039fd:	callq  401c60 <rfc_seal>
  403a02:	mov    %r15,%r9
  403a05:	mov    %r13,%rcx
  403a08:	mov    %rcx,%r13
  403a0b:	mov    -0x20(%rbp),%rcx
  403a0f:	mov    %rax,(%rcx,%r12,8)
  403a13:	mov    %r9,%rdx
  403a16:	mov    -0x20(%rbp),%rdi
  403a1a:	mov    -0x18(%rbp),%rsi
  403a1e:	callq  401c60 <rfc_seal>
  403a23:	mov    %r14,%r8
  403a26:	mov    %r13,%rcx
  403a29:	mov    -0x20(%rbp),%rdx
  403a2d:	mov    %rax,0x8(%rdx,%r12,8)
  403a32:	movabs $0x200010000000000,%rax
  403a3c:	mov    %r12,%r9
  403a3f:	or     %rax,%r9
  403a42:	mov    %rcx,%r12
  403a45:	mov    %r8,%r13
  403a48:	mov    %r9,%r15
  403a4b:	jmpq   403960 <NF_FID_110_116_95_114_101_118_101_114_115_101_+0x30>
  403a50:	mov    %r13,%rdx
  403a53:	mov    -0x20(%rbp),%rdi
  403a57:	mov    -0x18(%rbp),%rsi
  403a5b:	callq  402280 <term_sink>
  403a60:	mov    %r15,%rdx
  403a63:	mov    -0x20(%rbp),%rdi
  403a67:	mov    -0x18(%rbp),%rsi
  403a6b:	callq  402280 <term_sink>
  403a70:	mov    -0x20(%rbp),%rdi
  403a74:	mov    $0x4,%esi
  403a79:	callq  401450 <err_post>
  403a7e:	mov    $0x0,%eax
  403a83:	jmp    403a8e <NF_FID_110_116_95_114_101_118_101_114_115_101_+0x15e>
  403a85:	mov    %r15,(%r12)
  403a89:	mov    $0x1,%eax
  403a8e:	pop    %r15
  403a90:	pop    %r14
  403a92:	pop    %r13
  403a94:	pop    %r12
  403a96:	pop    %rbx
  403a97:	leaveq 
  403a98:	retq   

Disassembly of section .fini:
