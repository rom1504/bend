    9940:	test   %rsi,%rsi
    9943:	je     99b0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x70>
    9945:	movss  -0x7bc9(%rip),%xmm0        # 1d84 <_IO_stdin_used-0x8>
    994d:	movss  -0x7bcd(%rip),%xmm1        # 1d88 <_IO_stdin_used-0x4>
    9955:	xor    %eax,%eax
    9957:	movss  -0x7bdf(%rip),%xmm2        # 1d80 <_IO_stdin_used-0xc>
    995f:	xorps  %xmm3,%xmm3
    9962:	data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
    9970:	movd   %edx,%xmm4
    9974:	movdqa %xmm4,%xmm5
    9978:	addss  %xmm0,%xmm5
    997c:	addss  %xmm5,%xmm5
    9980:	subss  %xmm4,%xmm5
    9984:	mulss  %xmm1,%xmm5
    9988:	ucomiss %xmm5,%xmm2
    998b:	cvttss2si %xmm5,%rcx
    9990:	mov    %ecx,%ecx
    9992:	xorps  %xmm4,%xmm4
    9995:	cvtsi2ss %rcx,%xmm4
    999a:	mulss  %xmm0,%xmm4
    999e:	movd   %xmm4,%edx
    99a2:	cmovbe %eax,%edx
    99a5:	ucomiss %xmm3,%xmm5
    99a8:	cmovb  %eax,%edx
    99ab:	dec    %rsi
    99ae:	jne    9970 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x30>
    99b0:	mov    %edx,%esi
    99b2:	mov    -0x8(%r14),%eax
    99b6:	add    $0xfffffffffffffff8,%r14
    99ba:	lea    0x92ef(%rip),%rcx        # 12cb0 <wl_tab>
    99c1:	mov    (%rcx,%rax,8),%rax
    99c5:	mov    $0x1,%edi
    99ca:	jmpq   *%rax
    99cc:	nopl   0x0(%rax)
