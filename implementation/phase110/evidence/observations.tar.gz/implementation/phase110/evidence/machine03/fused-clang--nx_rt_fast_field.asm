
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ed0 <nx_rt_fast_field>:
  402ed0:	mov    %esi,%ecx
  402ed2:	mov    $0xfffffffe,%eax
  402ed7:	rol    %cl,%eax
  402ed9:	add    $0x2,%rcx
  402edd:	and    %eax,0x20(%rdi)
  402ee0:	mov    (%rdi,%rcx,8),%rax
  402ee4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402eec:	retq   

Disassembly of section .fini:
