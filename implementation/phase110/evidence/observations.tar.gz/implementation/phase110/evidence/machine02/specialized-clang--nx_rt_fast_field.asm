
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ea0 <nx_rt_fast_field>:
  402ea0:	mov    %esi,%ecx
  402ea2:	mov    $0xfffffffe,%eax
  402ea7:	rol    %cl,%eax
  402ea9:	add    $0x2,%rcx
  402ead:	and    %eax,0x20(%rdi)
  402eb0:	mov    (%rdi,%rcx,8),%rax
  402eb4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402ebc:	retq   

Disassembly of section .fini:
