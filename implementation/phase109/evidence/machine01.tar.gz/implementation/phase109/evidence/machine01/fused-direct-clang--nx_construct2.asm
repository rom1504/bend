
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c20 <nx_construct2>:
  401c20:	push   %r12
  401c22:	mov    %rcx,%rax
  401c25:	push   %rbp
  401c26:	shr    $0x38,%rax
  401c2a:	lea    0x0(,%r9,8),%rbp
  401c32:	push   %rbx
  401c33:	and    $0x7f,%eax
  401c36:	mov    %edx,%ebx
  401c38:	lea    (%rdi,%rbp,1),%r12
  401c3c:	mov    %rcx,%rdx
  401c3f:	sub    $0x20,%rsp
  401c43:	cmp    $0x2,%rax
  401c47:	je     401c80 <nx_construct2+0x60>
  401c49:	mov    %r8,%rax
  401c4c:	mov    %rdx,(%r12)
  401c50:	lea    0x8(%rbp,%rdi,1),%rbp
  401c55:	shr    $0x38,%rax
  401c59:	and    $0x7f,%eax
  401c5c:	cmp    $0x2,%rax
  401c60:	je     401c90 <nx_construct2+0x70>
  401c62:	mov    %rbx,%rax
  401c65:	mov    %r8,0x0(%rbp)
  401c69:	add    $0x20,%rsp
  401c6d:	shl    $0x28,%rax
  401c71:	pop    %rbx
  401c72:	pop    %rbp
  401c73:	or     %r9,%rax
  401c76:	pop    %r12
  401c78:	bts    $0x39,%rax
  401c7d:	retq   
  401c7e:	xchg   %ax,%ax
  401c80:	test   %rcx,%rcx
  401c83:	js     401c49 <nx_construct2+0x29>
  401c85:	jmpq   401410 <nx_construct2.cold>
  401c8a:	nopw   0x0(%rax,%rax,1)
  401c90:	test   %r8,%r8
  401c93:	js     401c62 <nx_construct2+0x42>
  401c95:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
