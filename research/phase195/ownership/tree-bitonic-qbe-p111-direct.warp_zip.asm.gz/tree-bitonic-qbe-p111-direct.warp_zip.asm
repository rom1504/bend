
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/tree-bitonic/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040d3a0 <p111_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>:
  40d3a0:	endbr64 
  40d3a4:	push   %rbp
  40d3a5:	mov    %rsp,%rbp
  40d3a8:	sub    $0x10,%rsp
  40d3ac:	push   %rbx
  40d3ad:	push   %r12
  40d3af:	mov    $0x0,%esi
  40d3b4:	mov    %rdi,%rbx
  40d3b7:	callq  414bd0 <p111_rt_reg_get>
  40d3bc:	mov    %rbx,%rdi
  40d3bf:	mov    %rax,%rsi
  40d3c2:	mov    %rsi,%r12
  40d3c5:	mov    $0x1,%esi
  40d3ca:	mov    %rdi,%rbx
  40d3cd:	callq  414bd0 <p111_rt_reg_get>
  40d3d2:	mov    %r12,%rsi
  40d3d5:	mov    %rbx,%rdi
  40d3d8:	mov    %rax,%rdx
  40d3db:	mov    %rdi,%rbx
  40d3de:	callq  406a70 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>
  40d3e3:	mov    %rbx,%rdi
  40d3e6:	mov    %rax,-0x8(%rbp)
  40d3ea:	mov    $0x1,%edx
  40d3ef:	lea    -0x8(%rbp),%rsi
  40d3f3:	callq  414a80 <p111_rt_return>
  40d3f8:	pop    %r12
  40d3fa:	pop    %rbx
  40d3fb:	leaveq 
  40d3fc:	retq   

Disassembly of section .fini:
