
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403460 <nx_rt_pair_rebuild2_c1_k0>:
  403460:	push   %r14
  403462:	mov    %rsi,%r10
  403465:	mov    %rdx,%r8
  403468:	movabs $0xffffffffff,%r9
  403472:	push   %r13
  403474:	and    %r10,%r9
  403477:	push   %r12
  403479:	lea    0x0(,%r9,8),%rax
  403481:	push   %rbp
  403482:	sub    $0x18,%rsp
  403486:	mov    (%rdi),%rbp
  403489:	mov    0x8(%rdi),%rsi
  40348d:	lea    0x0(%rbp,%rax,1),%rdx
  403492:	test   %r10,%r10
  403495:	js     4034f0 <nx_rt_pair_rebuild2_c1_k0+0x90>
  403497:	mov    (%rdx),%r13
  40349a:	mov    0x8(%rbp,%rax,1),%r12
  40349f:	cmp    $0x310817f,%r9
  4034a6:	jbe    4034d0 <nx_rt_pair_rebuild2_c1_k0+0x70>
  4034a8:	mov    %r13,%rcx
  4034ab:	mov    $0x1,%edx
  4034b0:	mov    %rbp,%rdi
  4034b3:	callq  401fa0 <nx_construct2>
  4034b8:	add    $0x18,%rsp
  4034bc:	mov    %r12,%rdx
  4034bf:	pop    %rbp
  4034c0:	pop    %r12
  4034c2:	pop    %r13
  4034c4:	pop    %r14
  4034c6:	retq   
  4034c7:	nopw   0x0(%rax,%rax,1)
  4034d0:	mov    0x8(%rsi),%r9
  4034d4:	test   %r9,%r9
  4034d7:	je     40173f <nx_rt_pair_rebuild2_c1_k0.cold>
  4034dd:	mov    0x0(%rbp,%r9,8),%rax
  4034e2:	subq   $0x2,0x108(%rsi)
  4034ea:	mov    %rax,0x8(%rsi)
  4034ee:	jmp    4034a8 <nx_rt_pair_rebuild2_c1_k0+0x48>
  4034f0:	mov    0x4(%rdx),%eax
  4034f3:	mov    (%rdx),%ecx
  4034f5:	shl    $0x20,%rax
  4034f9:	or     %rcx,%rax
  4034fc:	mov    %rax,%r14
  4034ff:	and    $0xffffff,%eax
  403504:	shr    $0x18,%r14
  403508:	lea    0x0(,%r14,8),%rcx
  403510:	lea    0x8(%rbp,%rcx,1),%rdi
  403515:	add    %rbp,%rcx
  403518:	cmp    $0x1,%rax
  40351c:	jne    40177d <nx_rt_pair_rebuild2_c1_k0.cold+0x3e>
  403522:	mov    (%rdx),%eax
  403524:	mov    (%rsi),%rax
  403527:	mov    (%rcx),%r13
  40352a:	mov    (%rdi),%r12
  40352d:	mov    %rax,(%rdx)
  403530:	mov    0x100(%rsi),%rax
  403537:	mov    0x3dc9b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40353d:	mov    %r9,(%rsi)
  403540:	add    $0x1,%rax
  403544:	mov    %rax,0x100(%rsi)
  40354b:	cmp    %rdx,%rax
  40354e:	jae    401766 <nx_rt_pair_rebuild2_c1_k0.cold+0x27>
  403554:	mov    %r14,%r9
  403557:	jmpq   40349f <nx_rt_pair_rebuild2_c1_k0+0x3f>

Disassembly of section .fini:
