
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004034f0 <nx_rt_rebuild2>:
  4034f0:	push   %r15
  4034f2:	push   %r14
  4034f4:	push   %r13
  4034f6:	mov    %ecx,%r13d
  4034f9:	push   %r12
  4034fb:	mov    %rdi,%r12
  4034fe:	push   %rbp
  4034ff:	movabs $0xffffffffff,%rbp
  403509:	push   %rbx
  40350a:	and    %rsi,%rbp
  40350d:	mov    %edx,%ebx
  40350f:	lea    0x0(,%rbp,8),%rdx
  403517:	sub    $0x28,%rsp
  40351b:	mov    (%rdi),%r14
  40351e:	mov    0x8(%rdi),%r15
  403522:	lea    (%r14,%rdx,1),%rax
  403526:	test   %rsi,%rsi
  403529:	js     403610 <nx_rt_rebuild2+0x120>
  40352f:	mov    (%rax),%rax
  403532:	mov    %rax,0x10(%rsp)
  403537:	mov    0x8(%r14,%rdx,1),%rax
  40353c:	mov    %rax,0x18(%rsp)
  403541:	cmp    $0x310817f,%rbp
  403548:	jbe    4035e8 <nx_rt_rebuild2+0xf8>
  40354e:	lea    (%r14,%rbp,8),%r9
  403552:	mov    $0x1,%eax
  403557:	mov    0x10(%rsp,%r13,8),%rdx
  40355c:	movq   $0xffffffffffffffff,0x18(%r12)
  403565:	movl   $0x1,0x20(%r12)
  40356e:	sub    %r13d,%eax
  403571:	mov    0x10(%rsp,%rax,8),%rax
  403576:	mov    %rax,0x10(%r12)
  40357b:	mov    %rdx,%rax
  40357e:	shr    $0x38,%rax
  403582:	and    $0x7f,%eax
  403585:	cmp    $0x2,%rax
  403589:	je     4035c8 <nx_rt_rebuild2+0xd8>
  40358b:	mov    %r8,%rax
  40358e:	mov    %rdx,(%r9)
  403591:	lea    0x8(%r14,%rbp,8),%r12
  403596:	shr    $0x38,%rax
  40359a:	and    $0x7f,%eax
  40359d:	cmp    $0x2,%rax
  4035a1:	je     4035d8 <nx_rt_rebuild2+0xe8>
  4035a3:	mov    %rbx,%rax
  4035a6:	mov    %r8,(%r12)
  4035aa:	add    $0x28,%rsp
  4035ae:	shl    $0x28,%rax
  4035b2:	pop    %rbx
  4035b3:	or     %rbp,%rax
  4035b6:	pop    %rbp
  4035b7:	pop    %r12
  4035b9:	bts    $0x39,%rax
  4035be:	pop    %r13
  4035c0:	pop    %r14
  4035c2:	pop    %r15
  4035c4:	retq   
  4035c5:	nopl   (%rax)
  4035c8:	test   %rdx,%rdx
  4035cb:	js     40358b <nx_rt_rebuild2+0x9b>
  4035cd:	jmpq   401640 <nx_rt_rebuild2.cold>
  4035d2:	nopw   0x0(%rax,%rax,1)
  4035d8:	test   %r8,%r8
  4035db:	js     4035a3 <nx_rt_rebuild2+0xb3>
  4035dd:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  4035e2:	nopw   0x0(%rax,%rax,1)
  4035e8:	mov    0x8(%r15),%rbp
  4035ec:	test   %rbp,%rbp
  4035ef:	je     401685 <nx_rt_rebuild2.cold+0x45>
  4035f5:	lea    (%r14,%rbp,8),%r9
  4035f9:	mov    (%r9),%rax
  4035fc:	subq   $0x2,0x108(%r15)
  403604:	mov    %rax,0x8(%r15)
  403608:	jmpq   403552 <nx_rt_rebuild2+0x62>
  40360d:	nopl   (%rax)
  403610:	mov    0x4(%rax),%edx
  403613:	mov    (%rax),%ecx
  403615:	shl    $0x20,%rdx
  403619:	or     %rcx,%rdx
  40361c:	mov    %rdx,%rcx
  40361f:	and    $0xffffff,%edx
  403625:	shr    $0x18,%rcx
  403629:	lea    0x0(,%rcx,8),%rdi
  403631:	lea    (%r14,%rdi,1),%r9
  403635:	lea    0x8(%r14,%rdi,1),%rdi
  40363a:	cmp    $0x1,%rdx
  40363e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403644:	mov    (%rax),%edx
  403646:	mov    (%r9),%rdx
  403649:	mov    %rdx,0x10(%rsp)
  40364e:	mov    (%rdi),%rdx
  403651:	mov    %rdx,0x18(%rsp)
  403656:	mov    (%r15),%rdx
  403659:	mov    %rdx,(%rax)
  40365c:	mov    0x100(%r15),%rax
  403663:	mov    0x3eb6f(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403669:	mov    %rbp,(%r15)
  40366c:	add    $0x1,%rax
  403670:	mov    %rax,0x100(%r15)
  403677:	cmp    %rdx,%rax
  40367a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  403680:	mov    %rcx,%rbp
  403683:	jmpq   403541 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
