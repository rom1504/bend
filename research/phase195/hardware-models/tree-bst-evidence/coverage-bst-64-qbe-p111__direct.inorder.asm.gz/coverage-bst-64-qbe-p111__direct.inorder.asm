000000000040af70 <p111_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>:
  40af70:	endbr64 
  40af74:	push   rbp
  40af75:	mov    rbp,rsp
  40af78:	sub    rsp,0x10
  40af7c:	push   rbx
  40af7d:	push   r12
  40af7f:	mov    esi,0x0
  40af84:	mov    rbx,rdi
  40af87:	call   412a50 <p111_rt_reg_get>
  40af8c:	mov    rdi,rbx
  40af8f:	mov    rsi,rax
  40af92:	mov    r12,rsi
  40af95:	mov    esi,0x1
  40af9a:	mov    rbx,rdi
  40af9d:	call   412a50 <p111_rt_reg_get>
  40afa2:	mov    rsi,r12
  40afa5:	mov    rdi,rbx
  40afa8:	mov    rdx,rax
  40afab:	mov    rbx,rdi
  40afae:	call   40afd0 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>
  40afb3:	mov    rdi,rbx
  40afb6:	mov    QWORD PTR [rbp-0x8],rax
  40afba:	mov    edx,0x1
  40afbf:	lea    rsi,[rbp-0x8]
  40afc3:	call   412900 <p111_rt_return>
  40afc8:	pop    r12
  40afca:	pop    rbx
  40afcb:	leave  
  40afcc:	ret    
  40afcd:	nop    DWORD PTR [rax]

