
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c60 <nx_string_reverse>:
  401c60:	push   %r14
  401c62:	push   %rbx
  401c63:	push   %rax
  401c64:	mov    %rdx,%r14
  401c67:	mov    %rdi,%rbx
  401c6a:	nopw   0x0(%rax,%rax,1)
  401c70:	mov    %rsi,%rax
  401c73:	shr    $0x28,%rax
  401c77:	cmp    $0x3,%ax
  401c7b:	jne    401c9a <nx_string_reverse+0x3a>
  401c7d:	mov    %rbx,%rdi
  401c80:	mov    %r14,%rdx
  401c83:	callq  403770 <nx_rt_rebuild2_c3_k0>
  401c88:	mov    %rax,%r14
  401c8b:	mov    %rbx,%rdi
  401c8e:	xor    %esi,%esi
  401c90:	callq  402ce0 <nx_rt_fast_field>
  401c95:	mov    %rax,%rsi
  401c98:	jmp    401c70 <nx_string_reverse+0x10>
  401c9a:	movzwl %ax,%eax
  401c9d:	cmp    $0x2,%eax
  401ca0:	jne    401cad <nx_string_reverse+0x4d>
  401ca2:	mov    %r14,%rax
  401ca5:	add    $0x8,%rsp
  401ca9:	pop    %rbx
  401caa:	pop    %r14
  401cac:	retq   
  401cad:	mov    %rbx,%rdi
  401cb0:	mov    $0x1,%esi
  401cb5:	add    $0x8,%rsp
  401cb9:	pop    %rbx
  401cba:	pop    %r14
  401cbc:	jmpq   402530 <nx_rt_fail>

Disassembly of section .fini:
