
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d50 <nx_rt_rebuild2>:
  402d50:	movabs $0xffffffffff,%r9
  402d5a:	push   %r14
  402d5c:	push   %r13
  402d5e:	and    %rsi,%r9
  402d61:	mov    %edx,%r13d
  402d64:	push   %r12
  402d66:	lea    0x0(,%r9,8),%rdx
  402d6e:	push   %rbp
  402d6f:	mov    %ecx,%ebp
  402d71:	push   %rbx
  402d72:	mov    %rdi,%rbx
  402d75:	sub    $0x20,%rsp
  402d79:	mov    (%rdi),%rdi
  402d7c:	mov    0x8(%rbx),%r12
  402d80:	lea    (%rdi,%rdx,1),%rax
  402d84:	test   %rsi,%rsi
  402d87:	js     402e08 <nx_rt_rebuild2+0xb8>
  402d89:	mov    (%rax),%rax
  402d8c:	mov    %rax,0x10(%rsp)
  402d91:	mov    0x8(%rdi,%rdx,1),%rax
  402d96:	mov    %rax,0x18(%rsp)
  402d9b:	cmp    $0x310817f,%r9
  402da2:	jbe    402de0 <nx_rt_rebuild2+0x90>
  402da4:	mov    $0x1,%eax
  402da9:	mov    0x10(%rsp,%rbp,8),%rcx
  402dae:	mov    %r13d,%edx
  402db1:	mov    %r12,%rsi
  402db4:	sub    %ebp,%eax
  402db6:	movq   $0xffffffffffffffff,0x18(%rbx)
  402dbe:	mov    0x10(%rsp,%rax,8),%rax
  402dc3:	movl   $0x1,0x20(%rbx)
  402dca:	mov    %rax,0x10(%rbx)
  402dce:	add    $0x20,%rsp
  402dd2:	pop    %rbx
  402dd3:	pop    %rbp
  402dd4:	pop    %r12
  402dd6:	pop    %r13
  402dd8:	pop    %r14
  402dda:	jmpq   401ff0 <nx_construct2>
  402ddf:	nop
  402de0:	mov    0x8(%r12),%r9
  402de5:	test   %r9,%r9
  402de8:	je     401651 <nx_rt_rebuild2.cold>
  402dee:	mov    (%rdi,%r9,8),%rax
  402df2:	subq   $0x2,0x108(%r12)
  402dfb:	mov    %rax,0x8(%r12)
  402e00:	jmp    402da4 <nx_rt_rebuild2+0x54>
  402e02:	nopw   0x0(%rax,%rax,1)
  402e08:	mov    0x4(%rax),%edx
  402e0b:	mov    (%rax),%ecx
  402e0d:	shl    $0x20,%rdx
  402e11:	or     %rcx,%rdx
  402e14:	mov    %rdx,%r14
  402e17:	and    $0xffffff,%edx
  402e1d:	shr    $0x18,%r14
  402e21:	lea    0x0(,%r14,8),%r10
  402e29:	lea    (%rdi,%r10,1),%r11
  402e2d:	lea    0x8(%rdi,%r10,1),%r10
  402e32:	cmp    $0x1,%rdx
  402e36:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402e3c:	mov    (%rax),%edx
  402e3e:	mov    (%r11),%rdx
  402e41:	mov    %rdx,0x10(%rsp)
  402e46:	mov    (%r10),%rdx
  402e49:	mov    %rdx,0x18(%rsp)
  402e4e:	mov    (%r12),%rdx
  402e52:	mov    %rdx,(%rax)
  402e55:	mov    0x100(%r12),%rax
  402e5d:	mov    0x3e375(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e63:	mov    %r9,(%r12)
  402e67:	add    $0x1,%rax
  402e6b:	mov    %rax,0x100(%r12)
  402e73:	cmp    %rdx,%rax
  402e76:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402e7c:	mov    %r14,%r9
  402e7f:	jmpq   402d9b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
