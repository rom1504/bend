
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004020b0 <nx_string_reverse>:
  4020b0:	push   %rbp
  4020b1:	push   %r15
  4020b3:	push   %r14
  4020b5:	push   %r13
  4020b7:	push   %r12
  4020b9:	push   %rbx
  4020ba:	sub    $0x18,%rsp
  4020be:	mov    %rdx,%r14
  4020c1:	mov    %rsi,%r13
  4020c4:	mov    %rdi,%rbx
  4020c7:	callq  404660 <nx_rt_ir_heap>
  4020cc:	mov    %rax,(%rsp)
  4020d0:	mov    %rbx,%rdi
  4020d3:	callq  4046d0 <nx_rt_ir_alc>
  4020d8:	mov    %rax,%r12
  4020db:	mov    %rbx,0x10(%rsp)
  4020e0:	jmp    402111 <nx_string_reverse+0x61>
  4020e2:	data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  4020f0:	mov    %rbx,%rdi
  4020f3:	mov    %r13,%rsi
  4020f6:	mov    %r14,%rdx
  4020f9:	callq  403fc0 <nx_rt_rebuild2_c3_k0>
  4020fe:	mov    %rax,%r14
  402101:	mov    %rbx,%rdi
  402104:	xor    %esi,%esi
  402106:	callq  403350 <nx_rt_fast_field>
  40210b:	mov    %rax,%r13
  40210e:	mov    %r15,%r12
  402111:	mov    %r13,%rax
  402114:	shr    $0x28,%rax
  402118:	cmp    $0x3,%ax
  40211c:	jne    402338 <nx_string_reverse+0x288>
  402122:	mov    %r12,%r15
  402125:	mov    %r13,%rbp
  402128:	movabs $0xffffffffff,%rax
  402132:	and    %rax,%rbp
  402135:	test   %r13,%r13
  402138:	js     402170 <nx_string_reverse+0xc0>
  40213a:	cmp    $0x3108180,%rbp
  402141:	jb     4020f0 <nx_string_reverse+0x40>
  402143:	mov    (%rsp),%rax
  402147:	lea    (%rax,%rbp,8),%rsi
  40214b:	mov    (%rax,%rbp,8),%rbx
  40214f:	mov    0x8(%rax,%rbp,8),%r13
  402154:	lea    (%rax,%rbp,8),%rdi
  402158:	add    $0x8,%rdi
  40215c:	jmpq   4021f9 <nx_string_reverse+0x149>
  402161:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  402170:	mov    %rbx,%rdi
  402173:	mov    %rbp,%rsi
  402176:	callq  404740 <nx_rt_ir_view>
  40217b:	mov    %rax,%r12
  40217e:	and    $0xffffff,%eax
  402183:	cmp    $0x1,%eax
  402186:	jne    4020f0 <nx_string_reverse+0x40>
  40218c:	mov    %r12,%rax
  40218f:	shr    $0x1f,%rax
  402193:	cmp    $0x62102,%rax
  402199:	jbe    4020f0 <nx_string_reverse+0x40>
  40219f:	shr    $0x18,%r12
  4021a3:	mov    (%rsp),%rdx
  4021a7:	lea    (%rdx,%r12,8),%rsi
  4021ab:	mov    (%rdx,%r12,8),%rbx
  4021af:	mov    0x8(%rdx,%r12,8),%r13
  4021b4:	lea    0x8(%rdx,%r12,8),%rdi
  4021b9:	mov    (%r15),%rax
  4021bc:	mov    %rax,(%rdx,%rbp,8)
  4021c0:	mov    %rbp,(%r15)
  4021c3:	mov    0x100(%r15),%rax
  4021ca:	inc    %rax
  4021cd:	mov    %rax,0x100(%r15)
  4021d4:	cmp    $0x8000,%rax
  4021da:	jb     4021f6 <nx_string_reverse+0x146>
  4021dc:	mov    %rdi,0x8(%rsp)
  4021e1:	mov    0x10(%rsp),%rdi
  4021e6:	mov    %rsi,%rbp
  4021e9:	callq  401c36 <nx_rt_ir_hand0>
  4021ee:	mov    0x8(%rsp),%rdi
  4021f3:	mov    %rbp,%rsi
  4021f6:	mov    %r12,%rbp
  4021f9:	mov    %rbx,%rax
  4021fc:	movabs $0xff00000000000000,%rcx
  402206:	and    %rcx,%rax
  402209:	movabs $0x200000000000000,%rcx
  402213:	cmp    %rcx,%rax
  402216:	mov    %r15,%r12
  402219:	jne    40228a <nx_string_reverse+0x1da>
  40221b:	mov    (%r12),%rax
  40221f:	test   %rax,%rax
  402222:	je     40223e <nx_string_reverse+0x18e>
  402224:	mov    (%rsp),%rdx
  402228:	lea    (%rdx,%rax,8),%rcx
  40222c:	mov    (%rdx,%rax,8),%rdx
  402230:	mov    %rdx,(%r12)
  402234:	decq   0x100(%r12)
  40223c:	jmp    402260 <nx_string_reverse+0x1b0>
  40223e:	mov    %rdi,0x8(%rsp)
  402243:	mov    0x10(%rsp),%rdi
  402248:	mov    %rsi,%r15
  40224b:	callq  401c25 <nx_rt_ir_alloc0>
  402250:	mov    0x8(%rsp),%rdi
  402255:	mov    %r15,%rsi
  402258:	mov    (%rsp),%rcx
  40225c:	lea    (%rcx,%rax,8),%rcx
  402260:	mov    %rbx,%rdx
  402263:	shl    $0x18,%rdx
  402267:	inc    %rdx
  40226a:	mov    %rdx,(%rcx)
  40226d:	movabs $0x2ffff0000000000,%rcx
  402277:	and    %rcx,%rbx
  40227a:	movabs $0x8000000000000000,%rcx
  402284:	or     %rcx,%rax
  402287:	or     %rax,%rbx
  40228a:	mov    %r14,%rax
  40228d:	movabs $0xff00000000000000,%rcx
  402297:	and    %rcx,%rax
  40229a:	movabs $0x200000000000000,%rcx
  4022a4:	cmp    %rcx,%rax
  4022a7:	jne    402318 <nx_string_reverse+0x268>
  4022a9:	mov    (%r12),%rax
  4022ad:	test   %rax,%rax
  4022b0:	je     4022cc <nx_string_reverse+0x21c>
  4022b2:	mov    (%rsp),%rdx
  4022b6:	lea    (%rdx,%rax,8),%rcx
  4022ba:	mov    (%rdx,%rax,8),%rdx
  4022be:	mov    %rdx,(%r12)
  4022c2:	decq   0x100(%r12)
  4022ca:	jmp    4022ee <nx_string_reverse+0x23e>
  4022cc:	mov    %rdi,0x8(%rsp)
  4022d1:	mov    0x10(%rsp),%rdi
  4022d6:	mov    %rsi,%r15
  4022d9:	callq  401c25 <nx_rt_ir_alloc0>
  4022de:	mov    0x8(%rsp),%rdi
  4022e3:	mov    %r15,%rsi
  4022e6:	mov    (%rsp),%rcx
  4022ea:	lea    (%rcx,%rax,8),%rcx
  4022ee:	mov    %r14,%rdx
  4022f1:	shl    $0x18,%rdx
  4022f5:	inc    %rdx
  4022f8:	mov    %rdx,(%rcx)
  4022fb:	movabs $0x2ffff0000000000,%rcx
  402305:	and    %rcx,%r14
  402308:	movabs $0x8000000000000000,%rcx
  402312:	or     %rcx,%r14
  402315:	or     %rax,%r14
  402318:	mov    %rbx,(%rsi)
  40231b:	mov    %r14,(%rdi)
  40231e:	movabs $0x200030000000000,%rax
  402328:	or     %rax,%rbp
  40232b:	mov    %rbp,%r14
  40232e:	mov    0x10(%rsp),%rbx
  402333:	jmpq   402111 <nx_string_reverse+0x61>
  402338:	movzwl %ax,%eax
  40233b:	cmp    $0x2,%eax
  40233e:	jne    402352 <nx_string_reverse+0x2a2>
  402340:	mov    %r14,%rax
  402343:	add    $0x18,%rsp
  402347:	pop    %rbx
  402348:	pop    %r12
  40234a:	pop    %r13
  40234c:	pop    %r14
  40234e:	pop    %r15
  402350:	pop    %rbp
  402351:	retq   
  402352:	mov    %rbx,%rdi
  402355:	mov    $0x1,%esi
  40235a:	add    $0x18,%rsp
  40235e:	pop    %rbx
  40235f:	pop    %r12
  402361:	pop    %r13
  402363:	pop    %r14
  402365:	pop    %r15
  402367:	pop    %rbp
  402368:	jmpq   402b50 <nx_rt_fail>

Disassembly of section .fini:
