
/home/ai/bend2/build/publish/bend/selfhost/build/phase184/bend-products01/tree-bitonic/bend-c/program:     file format elf64-x86-64


Disassembly of section .text:

000000000000ce60 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_>:
    ce60:	push   %rbp
    ce61:	sub    $0x10,%rsp
    ce65:	mov    %rdx,%rbx
    ce68:	mov    %rsi,%rbp
    ce6b:	movabs $0xffffffff80,%rax
    ce75:	mov    %ecx,%r8d
    ce78:	lea    0x7f(%rax),%r9
    ce7c:	mov    %r14,(%rsp)
    ce80:	mov    %rbp,%rcx
    ce83:	shr    $0x28,%rcx
    ce87:	movzwl %cx,%ecx
    ce8a:	cmp    $0xa5,%ecx
    ce90:	jne    d174 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x314>
    ce96:	mov    %rbp,%rdx
    ce99:	and    %r9,%rdx
    ce9c:	test   %rbp,%rbp
    ce9f:	js     cec0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x60>
    cea1:	mov    (%r12,%rdx,8),%rbp
    cea5:	mov    0x8(%r12,%rdx,8),%r11
    ceaa:	mov    %rdx,%rcx
    cead:	cmp    $0x3108180,%rcx
    ceb4:	jae    cf32 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd2>
    ceb6:	jmpq   cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    cebb:	nopl   0x0(%rax,%rax,1)
    cec0:	mov    0x4(%r12,%rdx,8),%ecx
    cec5:	mov    (%r12,%rdx,8),%esi
    cec9:	mov    %esi,%edi
    cecb:	and    $0xffffff,%edi
    ced1:	cmp    $0x1,%edi
    ced4:	jne    d0ad <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x24d>
    ceda:	mov    (%r12,%rdx,8),%edi
    cede:	shl    $0x20,%rcx
    cee2:	or     %rsi,%rcx
    cee5:	shr    $0x18,%rcx
    cee9:	mov    (%r12,%rcx,8),%rbp
    ceed:	mov    0x8(%r12,%rcx,8),%r11
    cef2:	mov    0x0(%r13),%rsi
    cef6:	mov    %rsi,(%r12,%rdx,8)
    cefa:	mov    %rdx,0x0(%r13)
    cefe:	mov    0x100(%r13),%rdx
    cf05:	inc    %rdx
    cf08:	mov    %rdx,0x100(%r13)
    cf0f:	cmpb   $0x1,0x10c97a(%rip)        # 119890 <KEEP_WORDS>
    cf16:	jne    d12d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2cd>
    cf1c:	cmp    $0x8000,%rdx
    cf23:	jae    d12d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2cd>
    cf29:	cmp    $0x3108180,%rcx
    cf30:	jb     cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    cf32:	mov    0x8(%r13),%rdx
    cf36:	mov    %rdx,(%r12,%rcx,8)
    cf3a:	mov    %rcx,0x8(%r13)
    cf3e:	mov    0x108(%r13),%rcx
    cf45:	add    $0x2,%rcx
    cf49:	mov    %rcx,0x108(%r13)
    cf50:	cmpb   $0x1,0x10c939(%rip)        # 119890 <KEEP_WORDS>
    cf57:	jne    d07d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x21d>
    cf5d:	cmp    $0x8000,%rcx
    cf64:	jae    d07d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x21d>
    cf6a:	mov    %rbx,%rcx
    cf6d:	shr    $0x28,%rcx
    cf71:	movzwl %cx,%ecx
    cf74:	cmp    $0xa5,%ecx
    cf7a:	jne    d1cb <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x36b>
    cf80:	mov    %rbx,%rdx
    cf83:	and    %r9,%rdx
    cf86:	test   %rbx,%rbx
    cf89:	js     cfb0 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x150>
    cf8b:	mov    (%r12,%rdx,8),%rbx
    cf8f:	mov    0x8(%r12,%rdx,8),%r10
    cf94:	mov    %rdx,%rcx
    cf97:	cmp    $0x3108180,%rcx
    cf9e:	jae    d028 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1c8>
    cfa4:	jmpq   d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    cfa9:	nopl   0x0(%rax)
    cfb0:	mov    %r11,%rax
    cfb3:	mov    0x4(%r12,%rdx,8),%ecx
    cfb8:	mov    (%r12,%rdx,8),%esi
    cfbc:	mov    %esi,%edi
    cfbe:	and    $0xffffff,%edi
    cfc4:	cmp    $0x1,%edi
    cfc7:	jne    d0ed <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x28d>
    cfcd:	mov    (%r12,%rdx,8),%edi
    cfd1:	shl    $0x20,%rcx
    cfd5:	or     %rsi,%rcx
    cfd8:	shr    $0x18,%rcx
    cfdc:	mov    (%r12,%rcx,8),%rbx
    cfe0:	mov    0x8(%r12,%rcx,8),%r10
    cfe5:	mov    0x0(%r13),%rsi
    cfe9:	mov    %rsi,(%r12,%rdx,8)
    cfed:	mov    %rdx,0x0(%r13)
    cff1:	mov    0x100(%r13),%rdx
    cff8:	inc    %rdx
    cffb:	mov    %rdx,0x100(%r13)
    d002:	cmpb   $0x1,0x10c887(%rip)        # 119890 <KEEP_WORDS>
    d009:	jne    d152 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2f2>
    d00f:	cmp    $0x8000,%rdx
    d016:	jae    d152 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2f2>
    d01c:	mov    %rax,%r11
    d01f:	cmp    $0x3108180,%rcx
    d026:	jb     d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    d028:	mov    0x8(%r13),%rax
    d02c:	mov    %rax,(%r12,%rcx,8)
    d030:	mov    %rcx,0x8(%r13)
    d034:	mov    0x108(%r13),%rcx
    d03b:	add    $0x2,%rcx
    d03f:	mov    %rcx,0x108(%r13)
    d046:	cmpb   $0x1,0x10c843(%rip)        # 119890 <KEEP_WORDS>
    d04d:	jne    d098 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x238>
    d04f:	cmp    $0x8000,%rcx
    d056:	jae    d098 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x238>
    d058:	test   %r15d,%r15d
    d05b:	je     d218 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x3b8>
    d061:	mov    %r11,(%r14)
    d064:	mov    %r8,0x8(%r14)
    d068:	mov    %r10,0x10(%r14)
    d06c:	movq   $0x74,0x18(%r14)
    d074:	add    $0x20,%r14
    d078:	jmpq   ce80 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x20>
    d07d:	mov    %r12,%rdi
    d080:	mov    %r13,%rsi
    d083:	mov    $0x1,%edx
    d088:	mov    %r11,%rax
    d08b:	callq  15881 <heap_hand>
    d090:	mov    %rax,%r11
    d093:	jmpq   cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    d098:	mov    %r12,%rdi
    d09b:	mov    %r13,%rsi
    d09e:	mov    $0x1,%edx
    d0a3:	mov    %r11,%rax
    d0a6:	callq  15881 <heap_hand>
    d0ab:	jmp    d125 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2c5>
    d0ad:	shl    $0x20,%rcx
    d0b1:	or     %rsi,%rcx
    d0b4:	shr    $0x18,%rcx
    d0b8:	mov    (%r12,%rcx,8),%rax
    d0bc:	mov    %rax,0x8(%rsp)
    d0c1:	mov    0x8(%r12,%rcx,8),%r10
    d0c6:	mov    %r12,%rdi
    d0c9:	mov    %r13,%rsi
    d0cc:	mov    %rbp,%rdx
    d0cf:	mov    %r8,%rax
    d0d2:	mov    $0x2,%r8d
    d0d8:	callq  15912 <span_fade>
    d0dd:	mov    %r10,%r11
    d0e0:	mov    %rax,%r8
    d0e3:	mov    0x8(%rsp),%rbp
    d0e8:	jmpq   cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    d0ed:	shl    $0x20,%rcx
    d0f1:	or     %rsi,%rcx
    d0f4:	shr    $0x18,%rcx
    d0f8:	mov    (%r12,%rcx,8),%rdx
    d0fc:	mov    %rdx,0x8(%rsp)
    d101:	mov    0x8(%r12,%rcx,8),%r10
    d106:	mov    %r12,%rdi
    d109:	mov    %r13,%rsi
    d10c:	mov    %rbx,%rdx
    d10f:	mov    %r8,%rbx
    d112:	mov    $0x2,%r8d
    d118:	callq  15912 <span_fade>
    d11d:	mov    %rbx,%r8
    d120:	mov    0x8(%rsp),%rbx
    d125:	mov    %rax,%r11
    d128:	jmpq   d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    d12d:	mov    %r12,%rdi
    d130:	mov    %r13,%rsi
    d133:	xor    %edx,%edx
    d135:	mov    %r11,%rax
    d138:	callq  15881 <heap_hand>
    d13d:	mov    %rax,%r11
    d140:	cmp    $0x3108180,%rcx
    d147:	jae    cf32 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd2>
    d14d:	jmpq   cf6a <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x10a>
    d152:	mov    %r12,%rdi
    d155:	mov    %r13,%rsi
    d158:	xor    %edx,%edx
    d15a:	callq  15881 <heap_hand>
    d15f:	mov    %rax,%r11
    d162:	cmp    $0x3108180,%rcx
    d169:	jae    d028 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1c8>
    d16f:	jmpq   d058 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f8>
    d174:	cmp    $0xa4,%ecx
    d17a:	jne    d941 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xae1>
    d180:	movabs $0x7f00000000000000,%rax
    d18a:	mov    %rbp,%rcx
    d18d:	and    %rax,%rcx
    d190:	movabs $0x100000000000000,%r10
    d19a:	cmp    %r10,%rcx
    d19d:	je     d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d1a3:	mov    %rbp,%rdx
    d1a6:	and    %r9,%rdx
    d1a9:	test   %rbp,%rbp
    d1ac:	js     d310 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b0>
    d1b2:	mov    (%r12,%rdx,8),%ebp
    d1b6:	mov    %rdx,%rcx
    d1b9:	cmp    $0x3108180,%rcx
    d1c0:	jae    d37d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x51d>
    d1c6:	jmpq   d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d1cb:	cmp    $0xa4,%ecx
    d1d1:	jne    d9f9 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xb99>
    d1d7:	movabs $0x7f00000000000000,%rax
    d1e1:	and    %rbx,%rax
    d1e4:	movabs $0x100000000000000,%rcx
    d1ee:	cmp    %rcx,%rax
    d1f1:	je     d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d1f7:	and    %rbx,%r9
    d1fa:	test   %rbx,%rbx
    d1fd:	js     d549 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6e9>
    d203:	mov    %r9,%rcx
    d206:	cmp    $0x3108180,%rcx
    d20d:	jae    d5b1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x751>
    d213:	jmpq   d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d218:	mov    (%rsp),%rax
    d21c:	mov    -0x18(%rax),%r14
    d220:	mov    -0x10(%rax),%r9
    d224:	mov    0x10(%r13),%rcx
    d228:	mov    %r8,%r15
    d22b:	test   %rcx,%rcx
    d22e:	je     d744 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8e4>
    d234:	mov    (%r12,%rcx,8),%rax
    d238:	mov    %rax,0x10(%r13)
    d23c:	addq   $0xfffffffffffffffc,0x110(%r13)
    d244:	lea    (%r12,%rcx,8),%r8
    d248:	pcmpeqd %xmm0,%xmm0
    d24c:	movdqu %xmm0,(%r12,%rcx,8)
    d252:	mov    %r14,0x10(%r12,%rcx,8)
    d257:	shl    $0x20,%r9
    d25b:	or     $0x2,%r9
    d25f:	mov    %r9,0x18(%r12,%rcx,8)
    d264:	movabs $0x500730000000000,%rax
    d26e:	or     %rcx,%rax
    d271:	mov    0x18(%r13),%rcx
    d275:	test   %rcx,%rcx
    d278:	je     d762 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x902>
    d27e:	mov    (%r12,%rcx,8),%rdx
    d282:	mov    %rdx,0x18(%r13)
    d286:	addq   $0xfffffffffffffff8,0x118(%r13)
    d28e:	mov    %rax,0x18(%r12,%rcx,8)
    d293:	movq   $0x0,0x20(%r12,%rcx,8)
    d29c:	mov    %rbp,(%r12,%rcx,8)
    d2a0:	mov    %r15,0x8(%r12,%rcx,8)
    d2a5:	mov    %rbx,0x10(%r12,%rcx,8)
    d2aa:	movabs $0x500760000000000,%rdx
    d2b4:	or     %rcx,%rdx
    d2b7:	mov    %rdx,(%r8)
    d2ba:	mov    0x18(%r13),%rcx
    d2be:	test   %rcx,%rcx
    d2c1:	je     d786 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x926>
    d2c7:	mov    (%r12,%rcx,8),%rdx
    d2cb:	mov    %rdx,0x18(%r13)
    d2cf:	addq   $0xfffffffffffffff8,0x118(%r13)
    d2d7:	mov    %rax,0x18(%r12,%rcx,8)
    d2dc:	movabs $0x100000000,%rdx
    d2e6:	mov    %rdx,0x20(%r12,%rcx,8)
    d2eb:	mov    %r11,(%r12,%rcx,8)
    d2ef:	mov    %r15,0x8(%r12,%rcx,8)
    d2f4:	mov    %r10,0x10(%r12,%rcx,8)
    d2f9:	movabs $0x500770000000000,%rdx
    d303:	or     %rcx,%rdx
    d306:	mov    %rdx,0x8(%r8)
    d30a:	add    $0x10,%rsp
    d30e:	pop    %rbp
    d30f:	retq   
    d310:	mov    0x4(%r12,%rdx,8),%ecx
    d315:	mov    (%r12,%rdx,8),%esi
    d319:	mov    %esi,%edi
    d31b:	and    $0xffffff,%edi
    d321:	cmp    $0x1,%edi
    d324:	jne    d7e6 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x986>
    d32a:	mov    (%r12,%rdx,8),%edi
    d32e:	shl    $0x20,%rcx
    d332:	or     %rsi,%rcx
    d335:	shr    $0x18,%rcx
    d339:	mov    (%r12,%rcx,8),%ebp
    d33d:	mov    0x0(%r13),%rsi
    d341:	mov    %rsi,(%r12,%rdx,8)
    d345:	mov    %rdx,0x0(%r13)
    d349:	mov    0x100(%r13),%rdx
    d350:	inc    %rdx
    d353:	mov    %rdx,0x100(%r13)
    d35a:	cmpb   $0x1,0x10c52f(%rip)        # 119890 <KEEP_WORDS>
    d361:	jne    d876 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa16>
    d367:	cmp    $0x8000,%rdx
    d36e:	jae    d876 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa16>
    d374:	cmp    $0x3108180,%rcx
    d37b:	jb     d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d37d:	mov    0x0(%r13),%rdx
    d381:	mov    %rdx,(%r12,%rcx,8)
    d385:	mov    %rcx,0x0(%r13)
    d389:	mov    0x100(%r13),%rcx
    d390:	inc    %rcx
    d393:	mov    %rcx,0x100(%r13)
    d39a:	cmpb   $0x1,0x10c4ef(%rip)        # 119890 <KEEP_WORDS>
    d3a1:	jne    d7aa <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x94a>
    d3a7:	cmp    $0x8000,%rcx
    d3ae:	jae    d7aa <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x94a>
    d3b4:	mov    %rbx,%rcx
    d3b7:	shr    $0x28,%rcx
    d3bb:	movzwl %cx,%ecx
    d3be:	cmp    $0xa5,%ecx
    d3c4:	je     d403 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x5a3>
    d3c6:	cmp    $0xa4,%ecx
    d3cc:	jne    db84 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd24>
    d3d2:	and    %rbx,%rax
    d3d5:	cmp    %r10,%rax
    d3d8:	je     d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d3de:	and    %rbx,%r9
    d3e1:	test   %rbx,%rbx
    d3e4:	js     d691 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x831>
    d3ea:	mov    (%r12,%r9,8),%ebx
    d3ee:	mov    %r9,%rcx
    d3f1:	cmp    $0x3108180,%rcx
    d3f8:	jae    d6fd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x89d>
    d3fe:	jmpq   d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d403:	and    %rbx,%r9
    d406:	test   %rbx,%rbx
    d409:	js     d425 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x5c5>
    d40b:	mov    (%r12,%r9,8),%rdx
    d40f:	mov    0x8(%r12,%r9,8),%rbp
    d414:	mov    %r9,%rcx
    d417:	cmp    $0x3108180,%rcx
    d41e:	jae    d496 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x636>
    d420:	jmpq   d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d425:	mov    0x4(%r12,%r9,8),%ecx
    d42a:	mov    (%r12,%r9,8),%eax
    d42e:	mov    %eax,%edx
    d430:	and    $0xffffff,%edx
    d436:	cmp    $0x1,%edx
    d439:	jne    d81c <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9bc>
    d43f:	mov    (%r12,%r9,8),%edx
    d443:	shl    $0x20,%rcx
    d447:	or     %rax,%rcx
    d44a:	shr    $0x18,%rcx
    d44e:	mov    (%r12,%rcx,8),%rdx
    d452:	mov    0x8(%r12,%rcx,8),%rbp
    d457:	mov    0x0(%r13),%rax
    d45b:	mov    %rax,(%r12,%r9,8)
    d45f:	mov    %r9,0x0(%r13)
    d463:	mov    0x100(%r13),%rax
    d46a:	inc    %rax
    d46d:	mov    %rax,0x100(%r13)
    d474:	cmpb   $0x1,0x10c415(%rip)        # 119890 <KEEP_WORDS>
    d47b:	jne    d895 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa35>
    d481:	cmp    $0x8000,%rax
    d487:	jae    d895 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa35>
    d48d:	cmp    $0x3108180,%rcx
    d494:	jb     d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d496:	mov    0x8(%r13),%rax
    d49a:	mov    %rax,(%r12,%rcx,8)
    d49e:	mov    %rcx,0x8(%r13)
    d4a2:	mov    0x108(%r13),%rax
    d4a9:	add    $0x2,%rax
    d4ad:	mov    %rax,0x108(%r13)
    d4b4:	cmpb   $0x1,0x10c3d5(%rip)        # 119890 <KEEP_WORDS>
    d4bb:	jne    d7bc <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x95c>
    d4c1:	cmp    $0x8000,%rax
    d4c7:	jae    d7bc <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x95c>
    d4cd:	movabs $0x7e00000000000000,%rbx
    d4d7:	test   %rbx,%rdx
    d4da:	sete   %al
    d4dd:	cmp    $0xffffffffffffffff,%rdx
    d4e1:	sete   %cl
    d4e4:	or     %al,%cl
    d4e6:	mov    %rdx,%rax
    d4e9:	movabs $0xffffffff80,%rsi
    d4f3:	and    %rsi,%rax
    d4f6:	cmp    $0x3108180,%rax
    d4fc:	setb   %al
    d4ff:	or     %cl,%al
    d501:	jne    d50e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6ae>
    d503:	mov    %r12,%rdi
    d506:	mov    %r13,%rsi
    d509:	callq  7810 <term_drop>
    d50e:	test   %rbx,%rbp
    d511:	sete   %al
    d514:	cmp    $0xffffffffffffffff,%rbp
    d518:	sete   %cl
    d51b:	or     %al,%cl
    d51d:	movabs $0xffffffff80,%rax
    d527:	and    %rbp,%rax
    d52a:	cmp    $0x3108180,%rax
    d530:	setb   %al
    d533:	or     %cl,%al
    d535:	jne    d668 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x808>
    d53b:	mov    %r12,%rdi
    d53e:	mov    %r13,%rsi
    d541:	mov    %rbp,%rdx
    d544:	jmpq   d663 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x803>
    d549:	mov    0x4(%r12,%r9,8),%ecx
    d54e:	mov    (%r12,%r9,8),%eax
    d552:	mov    %eax,%edx
    d554:	and    $0xffffff,%edx
    d55a:	cmp    $0x1,%edx
    d55d:	jne    d84c <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9ec>
    d563:	mov    (%r12,%r9,8),%edx
    d567:	shl    $0x20,%rcx
    d56b:	or     %rax,%rcx
    d56e:	shr    $0x18,%rcx
    d572:	mov    0x0(%r13),%rax
    d576:	mov    %rax,(%r12,%r9,8)
    d57a:	mov    %r9,0x0(%r13)
    d57e:	mov    0x100(%r13),%rax
    d585:	inc    %rax
    d588:	mov    %rax,0x100(%r13)
    d58f:	cmpb   $0x1,0x10c2fa(%rip)        # 119890 <KEEP_WORDS>
    d596:	jne    d8ba <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa5a>
    d59c:	cmp    $0x8000,%rax
    d5a2:	jae    d8ba <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa5a>
    d5a8:	cmp    $0x3108180,%rcx
    d5af:	jb     d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d5b1:	mov    0x0(%r13),%rax
    d5b5:	mov    %rax,(%r12,%rcx,8)
    d5b9:	mov    %rcx,0x0(%r13)
    d5bd:	mov    0x100(%r13),%rax
    d5c4:	inc    %rax
    d5c7:	mov    %rax,0x100(%r13)
    d5ce:	cmpb   $0x1,0x10c2bb(%rip)        # 119890 <KEEP_WORDS>
    d5d5:	jne    d7d1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x971>
    d5db:	cmp    $0x8000,%rax
    d5e1:	jae    d7d1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x971>
    d5e7:	movabs $0x7e00000000000000,%rbx
    d5f1:	test   %rbx,%rbp
    d5f4:	sete   %al
    d5f7:	cmp    $0xffffffffffffffff,%rbp
    d5fb:	sete   %cl
    d5fe:	or     %al,%cl
    d600:	mov    %rbp,%rax
    d603:	movabs $0xffffffff80,%rdx
    d60d:	and    %rdx,%rax
    d610:	cmp    $0x3108180,%rax
    d616:	setb   %al
    d619:	or     %cl,%al
    d61b:	jne    d631 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x7d1>
    d61d:	mov    %r12,%rdi
    d620:	mov    %r13,%rsi
    d623:	mov    %rbp,%rdx
    d626:	mov    %r11,%rbp
    d629:	callq  7810 <term_drop>
    d62e:	mov    %rbp,%r11
    d631:	test   %rbx,%r11
    d634:	sete   %al
    d637:	cmp    $0xffffffffffffffff,%r11
    d63b:	sete   %cl
    d63e:	or     %al,%cl
    d640:	movabs $0xffffffff80,%rax
    d64a:	and    %r11,%rax
    d64d:	cmp    $0x3108180,%rax
    d653:	setb   %al
    d656:	or     %cl,%al
    d658:	jne    d668 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x808>
    d65a:	mov    %r12,%rdi
    d65d:	mov    %r13,%rsi
    d660:	mov    %r11,%rdx
    d663:	callq  7810 <term_drop>
    d668:	mov    -0x8(%r14),%eax
    d66c:	add    $0xfffffffffffffff8,%r14
    d670:	lea    0xa799(%rip),%rcx        # 17e10 <wl_tab>
    d677:	mov    (%rcx,%rax,8),%rax
    d67b:	movabs $0x100a40000000000,%rsi
    d685:	mov    $0x1,%edi
    d68a:	add    $0x10,%rsp
    d68e:	pop    %rbp
    d68f:	jmpq   *%rax
    d691:	mov    0x4(%r12,%r9,8),%ecx
    d696:	mov    (%r12,%r9,8),%eax
    d69a:	mov    %eax,%edx
    d69c:	and    $0xffffff,%edx
    d6a2:	cmp    $0x1,%edx
    d6a5:	jne    d8f1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa91>
    d6ab:	mov    (%r12,%r9,8),%edx
    d6af:	shl    $0x20,%rcx
    d6b3:	or     %rax,%rcx
    d6b6:	shr    $0x18,%rcx
    d6ba:	mov    (%r12,%rcx,8),%ebx
    d6be:	mov    0x0(%r13),%rax
    d6c2:	mov    %rax,(%r12,%r9,8)
    d6c6:	mov    %r9,0x0(%r13)
    d6ca:	mov    0x100(%r13),%rax
    d6d1:	inc    %rax
    d6d4:	mov    %rax,0x100(%r13)
    d6db:	cmpb   $0x1,0x10c1ae(%rip)        # 119890 <KEEP_WORDS>
    d6e2:	jne    d922 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xac2>
    d6e8:	cmp    $0x8000,%rax
    d6ee:	jae    d922 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xac2>
    d6f4:	cmp    $0x3108180,%rcx
    d6fb:	jb     d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d6fd:	mov    0x0(%r13),%rax
    d701:	mov    %rax,(%r12,%rcx,8)
    d705:	mov    %rcx,0x0(%r13)
    d709:	mov    0x100(%r13),%rax
    d710:	inc    %rax
    d713:	mov    %rax,0x100(%r13)
    d71a:	cmpb   $0x1,0x10c16f(%rip)        # 119890 <KEEP_WORDS>
    d721:	jne    d8df <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa7f>
    d727:	cmp    $0x8000,%rax
    d72d:	jae    d8df <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa7f>
    d733:	mov    %ebp,%esi
    d735:	mov    %ebx,%edx
    d737:	mov    %r8,%rcx
    d73a:	add    $0x10,%rsp
    d73e:	pop    %rbp
    d73f:	jmpq   de10 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_108_101_97_102_>
    d744:	mov    %r12,%rdi
    d747:	mov    %r13,%rsi
    d74a:	mov    $0x2,%edx
    d74f:	mov    %r11,%rcx
    d752:	callq  159a8 <heap_alloc_miss>
    d757:	mov    %rcx,%r11
    d75a:	mov    %rax,%rcx
    d75d:	jmpq   d244 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x3e4>
    d762:	mov    %r12,%rdi
    d765:	mov    %r13,%rsi
    d768:	mov    $0x3,%edx
    d76d:	mov    %rax,%r9
    d770:	mov    %r11,%rcx
    d773:	callq  159a8 <heap_alloc_miss>
    d778:	mov    %rcx,%r11
    d77b:	mov    %rax,%rcx
    d77e:	mov    %r9,%rax
    d781:	jmpq   d28e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x42e>
    d786:	mov    %r12,%rdi
    d789:	mov    %r13,%rsi
    d78c:	mov    $0x3,%edx
    d791:	mov    %rax,%r9
    d794:	mov    %r11,%rcx
    d797:	callq  159a8 <heap_alloc_miss>
    d79c:	mov    %rcx,%r11
    d79f:	mov    %rax,%rcx
    d7a2:	mov    %r9,%rax
    d7a5:	jmpq   d2d7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x477>
    d7aa:	mov    %r12,%rdi
    d7ad:	mov    %r13,%rsi
    d7b0:	xor    %edx,%edx
    d7b2:	callq  15881 <heap_hand>
    d7b7:	jmpq   d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d7bc:	mov    %r12,%rdi
    d7bf:	mov    %r13,%rsi
    d7c2:	mov    %rdx,%rax
    d7c5:	mov    $0x1,%edx
    d7ca:	callq  15881 <heap_hand>
    d7cf:	jmp    d844 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9e4>
    d7d1:	mov    %r12,%rdi
    d7d4:	mov    %r13,%rsi
    d7d7:	xor    %edx,%edx
    d7d9:	mov    %r11,%rax
    d7dc:	callq  15881 <heap_hand>
    d7e1:	jmpq   d86e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xa0e>
    d7e6:	shl    $0x20,%rcx
    d7ea:	or     %rsi,%rcx
    d7ed:	shr    $0x18,%rcx
    d7f1:	mov    (%r12,%rcx,8),%edx
    d7f5:	mov    %rdx,(%rsp)
    d7f9:	mov    %r12,%rdi
    d7fc:	mov    %r13,%rsi
    d7ff:	mov    %rbp,%rdx
    d802:	mov    %r8,%rbp
    d805:	mov    $0x1,%r8d
    d80b:	callq  15912 <span_fade>
    d810:	mov    %rbp,%r8
    d813:	mov    (%rsp),%rbp
    d817:	jmpq   d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d81c:	shl    $0x20,%rcx
    d820:	or     %rax,%rcx
    d823:	shr    $0x18,%rcx
    d827:	mov    (%r12,%rcx,8),%rax
    d82b:	mov    0x8(%r12,%rcx,8),%rbp
    d830:	mov    %r12,%rdi
    d833:	mov    %r13,%rsi
    d836:	mov    %rbx,%rdx
    d839:	mov    $0x2,%r8d
    d83f:	callq  15912 <span_fade>
    d844:	mov    %rax,%rdx
    d847:	jmpq   d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d84c:	shl    $0x20,%rcx
    d850:	or     %rax,%rcx
    d853:	shr    $0x18,%rcx
    d857:	mov    %r12,%rdi
    d85a:	mov    %r13,%rsi
    d85d:	mov    %rbx,%rdx
    d860:	mov    $0x1,%r8d
    d866:	mov    %r11,%rax
    d869:	callq  15912 <span_fade>
    d86e:	mov    %rax,%r11
    d871:	jmpq   d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d876:	mov    %r12,%rdi
    d879:	mov    %r13,%rsi
    d87c:	xor    %edx,%edx
    d87e:	callq  15881 <heap_hand>
    d883:	cmp    $0x3108180,%rcx
    d88a:	jae    d37d <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x51d>
    d890:	jmpq   d3b4 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x554>
    d895:	mov    %r12,%rdi
    d898:	mov    %r13,%rsi
    d89b:	mov    %rdx,%rax
    d89e:	xor    %edx,%edx
    d8a0:	callq  15881 <heap_hand>
    d8a5:	mov    %rax,%rdx
    d8a8:	cmp    $0x3108180,%rcx
    d8af:	jae    d496 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x636>
    d8b5:	jmpq   d4cd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x66d>
    d8ba:	mov    %r12,%rdi
    d8bd:	mov    %r13,%rsi
    d8c0:	xor    %edx,%edx
    d8c2:	mov    %r11,%rax
    d8c5:	callq  15881 <heap_hand>
    d8ca:	mov    %rax,%r11
    d8cd:	cmp    $0x3108180,%rcx
    d8d4:	jae    d5b1 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x751>
    d8da:	jmpq   d5e7 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x787>
    d8df:	mov    %r12,%rdi
    d8e2:	mov    %r13,%rsi
    d8e5:	xor    %edx,%edx
    d8e7:	callq  15881 <heap_hand>
    d8ec:	jmpq   d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d8f1:	shl    $0x20,%rcx
    d8f5:	or     %rax,%rcx
    d8f8:	shr    $0x18,%rcx
    d8fc:	mov    (%r12,%rcx,8),%eax
    d900:	mov    %r12,%rdi
    d903:	mov    %r13,%rsi
    d906:	mov    %rbx,%rdx
    d909:	mov    %r8,%r9
    d90c:	mov    $0x1,%r8d
    d912:	callq  15912 <span_fade>
    d917:	mov    %r9,%r8
    d91a:	mov    %rax,%rbx
    d91d:	jmpq   d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d922:	mov    %r12,%rdi
    d925:	mov    %r13,%rsi
    d928:	xor    %edx,%edx
    d92a:	callq  15881 <heap_hand>
    d92f:	cmp    $0x3108180,%rcx
    d936:	jae    d6fd <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x89d>
    d93c:	jmpq   d733 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x8d3>
    d941:	mov    %r8,(%rsp)
    d945:	test   %r15d,%r15d
    d948:	jne    db22 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xcc2>
    d94e:	mov    -0x18(%r14),%rcx
    d952:	lea    -0x10(%r14),%r15
    d956:	mov    -0x10(%r14),%r8d
    d95a:	mov    %r12,%rdi
    d95d:	mov    %r13,%rsi
    d960:	mov    $0x7a,%edx
    d965:	mov    $0x1,%r9d
    d96b:	callq  7ca0 <task_node>
    d970:	mov    (%rsp),%rcx
    d974:	mov    %rcx,(%r12,%rax,8)
    d978:	movabs $0x5007a0000000000,%rcx
    d982:	or     %rax,%rcx
    d985:	mov    %rcx,-0x18(%r14)
    d989:	movq   $0x1,-0x10(%r14)
    d991:	mov    %r12,%rdi
    d994:	mov    %r13,%rsi
    d997:	mov    $0x7b,%edx
    d99c:	mov    $0x1,%r8d
    d9a2:	mov    $0x1,%r9d
    d9a8:	callq  7ca0 <task_node>
    d9ad:	mov    %rbx,(%r12,%rax,8)
    d9b1:	movabs $0x5007b0000000000,%rcx
    d9bb:	or     %rax,%rcx
    d9be:	mov    %rcx,-0x18(%r14)
    d9c2:	movq   $0x1,-0x10(%r14)
    d9ca:	mov    %r12,%rdi
    d9cd:	mov    %r13,%rsi
    d9d0:	mov    $0x7c,%edx
    d9d5:	mov    $0x1,%r8d
    d9db:	mov    $0x1,%r9d
    d9e1:	callq  7ca0 <task_node>
    d9e6:	mov    %rbp,(%r12,%rax,8)
    d9ea:	movabs $0x5007c0000000000,%rcx
    d9f4:	jmpq   db04 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xca4>
    d9f9:	mov    %r11,0x8(%rsp)
    d9fe:	mov    %r8,(%rsp)
    da02:	movabs $0x7e00000000000000,%rax
    da0c:	test   %rax,%rbp
    da0f:	sete   %al
    da12:	cmp    $0xffffffffffffffff,%rbp
    da16:	sete   %cl
    da19:	or     %al,%cl
    da1b:	mov    %rbp,%rax
    da1e:	movabs $0xffffffff80,%rdx
    da28:	and    %rdx,%rax
    da2b:	cmp    $0x3108180,%rax
    da31:	setb   %al
    da34:	or     %cl,%al
    da36:	jne    da46 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xbe6>
    da38:	mov    %r12,%rdi
    da3b:	mov    %r13,%rsi
    da3e:	mov    %rbp,%rdx
    da41:	callq  7810 <term_drop>
    da46:	mov    0x8(%rsp),%rdx
    da4b:	movabs $0x7e00000000000000,%rax
    da55:	test   %rax,%rdx
    da58:	sete   %al
    da5b:	cmp    $0xffffffffffffffff,%rdx
    da5f:	sete   %cl
    da62:	or     %al,%cl
    da64:	movabs $0xffffffff80,%rax
    da6e:	and    %rdx,%rax
    da71:	cmp    $0x3108180,%rax
    da77:	setb   %al
    da7a:	or     %cl,%al
    da7c:	jne    da8e <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xc2e>
    da7e:	mov    %r12,%rdi
    da81:	mov    %r13,%rsi
    da84:	mov    0x8(%rsp),%rdx
    da89:	callq  7810 <term_drop>
    da8e:	test   %r15d,%r15d
    da91:	jne    db59 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xcf9>
    da97:	mov    -0x18(%r14),%rcx
    da9b:	lea    -0x10(%r14),%r15
    da9f:	mov    -0x10(%r14),%r8d
    daa3:	mov    %r12,%rdi
    daa6:	mov    %r13,%rsi
    daa9:	mov    $0x78,%edx
    daae:	mov    $0x1,%r9d
    dab4:	callq  7ca0 <task_node>
    dab9:	mov    (%rsp),%rcx
    dabd:	mov    %rcx,(%r12,%rax,8)
    dac1:	movabs $0x500780000000000,%rcx
    dacb:	or     %rax,%rcx
    dace:	mov    %rcx,-0x18(%r14)
    dad2:	movq   $0x1,-0x10(%r14)
    dada:	mov    %r12,%rdi
    dadd:	mov    %r13,%rsi
    dae0:	mov    $0x79,%edx
    dae5:	mov    $0x1,%r8d
    daeb:	mov    $0x1,%r9d
    daf1:	callq  7ca0 <task_node>
    daf6:	mov    %rbx,(%r12,%rax,8)
    dafa:	movabs $0x500790000000000,%rcx
    db04:	or     %rax,%rcx
    db07:	mov    %rcx,-0x18(%r14)
    db0b:	mov    $0x1,%eax
    db10:	mov    %r15,%r14
    db13:	mov    %rax,(%r14)
    db16:	lea    -0xaf6d(%rip),%rdi        # 2bb0 <FID_RESW_T+0x350>
    db1d:	callq  15820 <err_fail>
    db22:	mov    (%rsp),%rax
    db26:	mov    %rax,(%r14)
    db29:	movq   $0x7a,0x8(%r14)
    db31:	mov    %rbx,0x10(%r14)
    db35:	movq   $0x7b,0x18(%r14)
    db3d:	mov    %rbp,0x20(%r14)
    db41:	add    $0x28,%r14
    db45:	mov    $0x7c,%eax
    db4a:	mov    %rax,(%r14)
    db4d:	lea    -0xafa4(%rip),%rdi        # 2bb0 <FID_RESW_T+0x350>
    db54:	callq  15820 <err_fail>
    db59:	mov    (%rsp),%rax
    db5d:	mov    %rax,(%r14)
    db60:	movq   $0x78,0x8(%r14)
    db68:	mov    %rbx,0x10(%r14)
    db6c:	add    $0x18,%r14
    db70:	mov    $0x79,%eax
    db75:	mov    %rax,(%r14)
    db78:	lea    -0xafcf(%rip),%rdi        # 2bb0 <FID_RESW_T+0x350>
    db7f:	callq  15820 <err_fail>
    db84:	mov    %r8,%rbp
    db87:	test   %r15d,%r15d
    db8a:	jne    dbfa <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xd9a>
    db8c:	mov    -0x18(%r14),%rcx
    db90:	lea    -0x10(%r14),%r15
    db94:	mov    -0x10(%r14),%r8d
    db98:	mov    %r12,%rdi
    db9b:	mov    %r13,%rsi
    db9e:	mov    $0x71,%edx
    dba3:	mov    $0x1,%r9d
    dba9:	callq  7ca0 <task_node>
    dbae:	mov    %rbp,(%r12,%rax,8)
    dbb2:	movabs $0x500710000000000,%rcx
    dbbc:	or     %rax,%rcx
    dbbf:	mov    %rcx,-0x18(%r14)
    dbc3:	movq   $0x1,-0x10(%r14)
    dbcb:	mov    %r12,%rdi
    dbce:	mov    %r13,%rsi
    dbd1:	mov    $0x72,%edx
    dbd6:	mov    $0x1,%r8d
    dbdc:	mov    $0x1,%r9d
    dbe2:	callq  7ca0 <task_node>
    dbe7:	mov    %rbx,(%r12,%rax,8)
    dbeb:	movabs $0x500720000000000,%rcx
    dbf5:	jmpq   db04 <WL_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0xca4>
    dbfa:	mov    %rbp,(%r14)
    dbfd:	movq   $0x71,0x8(%r14)
    dc05:	mov    %rbx,0x10(%r14)
    dc09:	add    $0x18,%r14
    dc0d:	mov    $0x72,%eax
    dc12:	mov    %rax,(%r14)
    dc15:	lea    -0xb06c(%rip),%rdi        # 2bb0 <FID_RESW_T+0x350>
    dc1c:	callq  15820 <err_fail>

Disassembly of section .init:

Disassembly of section .fini:

Disassembly of section .plt:
