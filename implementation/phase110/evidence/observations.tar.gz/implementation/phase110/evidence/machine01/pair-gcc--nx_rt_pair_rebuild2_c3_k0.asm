
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403890 <nx_rt_pair_rebuild2_c3_k0>:
  403890:	push   %r14
  403892:	mov    %rsi,%r10
  403895:	mov    %rdx,%r8
  403898:	movabs $0xffffffffff,%r9
  4038a2:	push   %r13
  4038a4:	and    %r10,%r9
  4038a7:	push   %r12
  4038a9:	lea    0x0(,%r9,8),%rax
  4038b1:	push   %rbp
  4038b2:	sub    $0x18,%rsp
  4038b6:	mov    (%rdi),%rbp
  4038b9:	mov    0x8(%rdi),%rsi
  4038bd:	lea    0x0(%rbp,%rax,1),%rdx
  4038c2:	test   %r10,%r10
  4038c5:	js     403920 <nx_rt_pair_rebuild2_c3_k0+0x90>
  4038c7:	mov    (%rdx),%r13
  4038ca:	mov    0x8(%rbp,%rax,1),%r12
  4038cf:	cmp    $0x310817f,%r9
  4038d6:	jbe    403900 <nx_rt_pair_rebuild2_c3_k0+0x70>
  4038d8:	mov    %r13,%rcx
  4038db:	mov    $0x3,%edx
  4038e0:	mov    %rbp,%rdi
  4038e3:	callq  401fb0 <nx_construct2>
  4038e8:	add    $0x18,%rsp
  4038ec:	mov    %r12,%rdx
  4038ef:	pop    %rbp
  4038f0:	pop    %r12
  4038f2:	pop    %r13
  4038f4:	pop    %r14
  4038f6:	retq   
  4038f7:	nopw   0x0(%rax,%rax,1)
  403900:	mov    0x8(%rsi),%r9
  403904:	test   %r9,%r9
  403907:	je     401907 <nx_rt_pair_rebuild2_c3_k0.cold>
  40390d:	mov    0x0(%rbp,%r9,8),%rax
  403912:	subq   $0x2,0x108(%rsi)
  40391a:	mov    %rax,0x8(%rsi)
  40391e:	jmp    4038d8 <nx_rt_pair_rebuild2_c3_k0+0x48>
  403920:	mov    0x4(%rdx),%eax
  403923:	mov    (%rdx),%ecx
  403925:	shl    $0x20,%rax
  403929:	or     %rcx,%rax
  40392c:	mov    %rax,%r14
  40392f:	and    $0xffffff,%eax
  403934:	shr    $0x18,%r14
  403938:	lea    0x0(,%r14,8),%rcx
  403940:	lea    0x8(%rbp,%rcx,1),%rdi
  403945:	add    %rbp,%rcx
  403948:	cmp    $0x1,%rax
  40394c:	jne    401945 <nx_rt_pair_rebuild2_c3_k0.cold+0x3e>
  403952:	mov    (%rdx),%eax
  403954:	mov    (%rsi),%rax
  403957:	mov    (%rcx),%r13
  40395a:	mov    (%rdi),%r12
  40395d:	mov    %rax,(%rdx)
  403960:	mov    0x100(%rsi),%rax
  403967:	mov    0x3d86b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40396d:	mov    %r9,(%rsi)
  403970:	add    $0x1,%rax
  403974:	mov    %rax,0x100(%rsi)
  40397b:	cmp    %rdx,%rax
  40397e:	jae    40192e <nx_rt_pair_rebuild2_c3_k0.cold+0x27>
  403984:	mov    %r14,%r9
  403987:	jmpq   4038cf <nx_rt_pair_rebuild2_c3_k0+0x3f>

Disassembly of section .fini:
