
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/coverage-record-aggregation-256/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000405e60 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>:
  405e60:	endbr64 
  405e64:	push   %rbp
  405e65:	mov    %rsp,%rbp
  405e68:	sub    $0x808,%rsp
  405e6f:	push   %rbx
  405e70:	push   %r12
  405e72:	push   %r13
  405e74:	data16 nopw %cs:0x0(%rax,%rax,1)
  405e7f:	nop
  405e80:	mov    %rsi,%rax
  405e83:	shr    $0x28,%rax
  405e87:	and    $0xffff,%rax
  405e8d:	cmp    $0x18,%rax
  405e91:	je     405ff8 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x198>
  405e97:	cmp    $0x19,%rax
  405e9b:	sete   %r8b
  405e9f:	movzbl %r8b,%r8d
  405ea3:	jne    405fe7 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x187>
  405ea9:	cs cs mov %rsi,%rax
  405eae:	shr    $0x38,%rax
  405eb2:	and    $0x7f,%rax
  405eb6:	cmp    $0x2,%rax
  405eba:	sete   %al
  405ebd:	movzbl %al,%eax
  405ec0:	test   %eax,%r8d
  405ec3:	jne    405ef0 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x90>
  405ec5:	mov    $0x2,%r8d
  405ecb:	mov    %rcx,%r13
  405ece:	mov    $0x19,%ecx
  405ed3:	mov    %rdx,%r12
  405ed6:	lea    -0x800(%rbp),%rdx
  405edd:	mov    %rdi,%rbx
  405ee0:	callq  42fee0 <p118_rt_borrow_fields>
  405ee5:	mov    %r13,%rcx
  405ee8:	mov    %r12,%rdx
  405eeb:	mov    %rbx,%rdi
  405eee:	jmp    405f46 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0xe6>
  405ef0:	mov    %rsi,%r9
  405ef3:	mov    (%rdi),%rsi
  405ef6:	movabs $0xffffffffff,%rax
  405f00:	and    %r9,%rax
  405f03:	mov    %r9,%r8
  405f06:	shr    $0x3f,%r8
  405f0a:	cmp    $0x0,%r8
  405f0e:	je     405f2b <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0xcb>
  405f10:	mov    %rax,%r8
  405f13:	shl    $0x3,%r8
  405f17:	mov    (%r8,%rsi,1),%eax
  405f1b:	mov    0x4(%r8,%rsi,1),%r8d
  405f20:	shl    $0x20,%r8
  405f24:	or     %r8,%rax
  405f27:	shr    $0x18,%rax
  405f2b:	shl    $0x3,%rax
  405f2f:	mov    (%rax,%rsi,1),%r8
  405f33:	mov    %r8,-0x800(%rbp)
  405f3a:	mov    0x8(%rax,%rsi,1),%rax
  405f3f:	mov    %rax,-0x7f8(%rbp)
  405f46:	mov    -0x800(%rbp),%rbx
  405f4d:	mov    -0x7f8(%rbp),%rsi
  405f54:	cmp    $0x0,%rdx
  405f58:	je     405f65 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x105>
  405f5a:	cs cs sub $0x1,%rdx
  405f60:	jmpq   405e80 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x20>
  405f65:	cmp    $0x0,%rcx
  405f69:	je     405fcf <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x16f>
  405f6b:	cs cs cs mov %rcx,%rax
  405f71:	sub    $0x1,%rax
  405f75:	movq   $0x1f,-0x800(%rbp)
  405f80:	mov    %rax,-0x7f8(%rbp)
  405f87:	mov    $0x2,%ecx
  405f8c:	lea    -0x800(%rbp),%rdx
  405f93:	mov    $0x3f,%esi
  405f98:	callq  42b670 <p111_rt_op>
  405f9d:	mov    %rax,%rcx
  405fa0:	cmp    $0x20,%rcx
  405fa4:	jb     405fad <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x14d>
  405fa6:	mov    $0x0,%eax
  405fab:	jmp    405fba <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x15a>
  405fad:	mov    %ebx,%eax
  405faf:	shr    %cl,%rax
  405fb2:	mov    $0xffffffff,%ecx
  405fb7:	and    %rcx,%rax
  405fba:	mov    %eax,%eax
  405fbc:	and    $0x1,%eax
  405fbf:	mov    %eax,%eax
  405fc1:	cmp    $0x0,%rax
  405fc5:	setne  %al
  405fc8:	movzbl %al,%eax
  405fcb:	mov    %eax,%eax
  405fcd:	jmp    40600e <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1ae>
  405fcf:	mov    $0x0,%ecx
  405fd4:	lea    -0x800(%rbp),%rdx
  405fdb:	mov    $0x2,%esi
  405fe0:	callq  42c850 <p111_rt_special_ctor>
  405fe5:	jmp    40600e <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1ae>
  405fe7:	mov    $0x4,%esi
  405fec:	callq  42b650 <p111_rt_fail>
  405ff1:	mov    $0x0,%eax
  405ff6:	jmp    40600e <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_+0x1ae>
  405ff8:	mov    $0x0,%ecx
  405ffd:	lea    -0x800(%rbp),%rdx
  406004:	mov    $0x1,%esi
  406009:	callq  42c850 <p111_rt_special_ctor>
  40600e:	pop    %r13
  406010:	pop    %r12
  406012:	pop    %rbx
  406013:	leaveq 
  406014:	retq   

Disassembly of section .fini:
