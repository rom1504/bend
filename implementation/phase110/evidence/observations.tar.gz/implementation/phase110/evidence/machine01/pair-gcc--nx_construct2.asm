
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401fb0 <nx_construct2>:
  401fb0:	push   %r12
  401fb2:	mov    %rcx,%rax
  401fb5:	push   %rbp
  401fb6:	shr    $0x38,%rax
  401fba:	lea    0x0(,%r9,8),%rbp
  401fc2:	push   %rbx
  401fc3:	and    $0x7f,%eax
  401fc6:	mov    %edx,%ebx
  401fc8:	lea    (%rdi,%rbp,1),%r12
  401fcc:	mov    %rcx,%rdx
  401fcf:	sub    $0x20,%rsp
  401fd3:	cmp    $0x2,%rax
  401fd7:	je     402010 <nx_construct2+0x60>
  401fd9:	mov    %r8,%rax
  401fdc:	mov    %rdx,(%r12)
  401fe0:	lea    0x8(%rbp,%rdi,1),%rbp
  401fe5:	shr    $0x38,%rax
  401fe9:	and    $0x7f,%eax
  401fec:	cmp    $0x2,%rax
  401ff0:	je     402020 <nx_construct2+0x70>
  401ff2:	mov    %rbx,%rax
  401ff5:	mov    %r8,0x0(%rbp)
  401ff9:	add    $0x20,%rsp
  401ffd:	shl    $0x28,%rax
  402001:	pop    %rbx
  402002:	pop    %rbp
  402003:	or     %r9,%rax
  402006:	pop    %r12
  402008:	bts    $0x39,%rax
  40200d:	retq   
  40200e:	xchg   %ax,%ax
  402010:	test   %rcx,%rcx
  402013:	js     401fd9 <nx_construct2+0x29>
  402015:	jmpq   401410 <nx_construct2.cold>
  40201a:	nopw   0x0(%rax,%rax,1)
  402020:	test   %r8,%r8
  402023:	js     401ff2 <nx_construct2+0x42>
  402025:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
