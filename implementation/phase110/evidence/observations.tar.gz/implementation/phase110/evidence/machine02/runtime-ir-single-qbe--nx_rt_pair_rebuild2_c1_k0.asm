
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403cd0 <nx_rt_pair_rebuild2_c1_k0>:
  403cd0:	push   %r15
  403cd2:	push   %r14
  403cd4:	push   %r13
  403cd6:	push   %r12
  403cd8:	mov    %rdx,%r12
  403cdb:	push   %rbp
  403cdc:	push   %rbx
  403cdd:	movabs $0xffffffffff,%rbx
  403ce7:	and    %rsi,%rbx
  403cea:	lea    0x0(,%rbx,8),%rdx
  403cf2:	sub    $0x18,%rsp
  403cf6:	mov    (%rdi),%rbp
  403cf9:	mov    0x8(%rdi),%r15
  403cfd:	lea    0x0(%rbp,%rdx,1),%rax
  403d02:	test   %rsi,%rsi
  403d05:	js     403dc0 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  403d0b:	mov    (%rax),%r14
  403d0e:	mov    0x8(%rbp,%rdx,1),%r13
  403d13:	cmp    $0x310817f,%rbx
  403d1a:	jbe    403d90 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  403d1c:	lea    0x0(%rbp,%rbx,8),%r8
  403d21:	mov    %r14,%rax
  403d24:	shr    $0x38,%rax
  403d28:	and    $0x7f,%eax
  403d2b:	cmp    $0x2,%rax
  403d2f:	je     403d70 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403d31:	mov    %r12,%rax
  403d34:	mov    %r14,(%r8)
  403d37:	lea    0x8(%rbp,%rbx,8),%r14
  403d3c:	shr    $0x38,%rax
  403d40:	and    $0x7f,%eax
  403d43:	cmp    $0x2,%rax
  403d47:	je     403d80 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403d49:	movabs $0x200010000000000,%rax
  403d53:	mov    %r12,(%r14)
  403d56:	mov    %r13,%rdx
  403d59:	add    $0x18,%rsp
  403d5d:	or     %rbx,%rax
  403d60:	pop    %rbx
  403d61:	pop    %rbp
  403d62:	pop    %r12
  403d64:	pop    %r13
  403d66:	pop    %r14
  403d68:	pop    %r15
  403d6a:	retq   
  403d6b:	nopl   0x0(%rax,%rax,1)
  403d70:	test   %r14,%r14
  403d73:	js     403d31 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403d75:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  403d7a:	nopw   0x0(%rax,%rax,1)
  403d80:	test   %r12,%r12
  403d83:	js     403d49 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403d85:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  403d8a:	nopw   0x0(%rax,%rax,1)
  403d90:	mov    0x8(%r15),%rbx
  403d94:	test   %rbx,%rbx
  403d97:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  403d9d:	lea    0x0(%rbp,%rbx,8),%r8
  403da2:	mov    (%r8),%rax
  403da5:	subq   $0x2,0x108(%r15)
  403dad:	mov    %rax,0x8(%r15)
  403db1:	jmpq   403d21 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403db6:	nopw   %cs:0x0(%rax,%rax,1)
  403dc0:	mov    0x4(%rax),%edx
  403dc3:	mov    (%rax),%ecx
  403dc5:	shl    $0x20,%rdx
  403dc9:	or     %rcx,%rdx
  403dcc:	mov    %rdx,%rcx
  403dcf:	and    $0xffffff,%edx
  403dd5:	shr    $0x18,%rcx
  403dd9:	lea    0x8(,%rcx,8),%rdi
  403de1:	lea    0x0(%rbp,%rdi,1),%r8
  403de6:	lea    -0x8(%rbp,%rdi,1),%rdi
  403deb:	cmp    $0x1,%rdx
  403def:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403df5:	mov    (%rax),%edx
  403df7:	mov    (%r15),%rdx
  403dfa:	mov    (%rdi),%r14
  403dfd:	mov    (%r8),%r13
  403e00:	mov    %rdx,(%rax)
  403e03:	mov    0x100(%r15),%rax
  403e0a:	mov    0x3e3c8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403e10:	mov    %rbx,(%r15)
  403e13:	add    $0x1,%rax
  403e17:	mov    %rax,0x100(%r15)
  403e1e:	cmp    %rdx,%rax
  403e21:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403e27:	mov    %rcx,%rbx
  403e2a:	jmpq   403d13 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
