# JavaScript backend

Read the [runtime IR architecture](../../../docs/JAVASCRIPT_IR.md) for the
ordinary lowering pipeline, pass contracts and remaining compatibility adapters.
Its Bend modules live in `ir/`; the established private planners below remain
explicit migration boundaries.

`emit.bend`, `choice.bend`, `projection.bend`, `u32.bend`, `region.bend`,
`local.bend`, `primitive.bend`, `worker.bend`, `tree.bend`, `foreign.bend`, `literals.bend`, and
`validate.bend` are Bend2 source. Their input is the checked,
specialized, annotated `KTerm`/`KDef` core. They emit JavaScript; they do not
invoke another compiler.

- `j_compile_error(book)` validates the executable entry before reachability.
- `j_layout_error(context, annotatedDefinitions, roots, stops)` rejects live
  Array operations whose element representation remains open, while retaining
  valid generic identity functions and skipping erased or dead expressions.
- `j_roots(book, library)` and `j_stops(book)` drive shared reachability.
- `j_program_selected(context, definitions)` emits an executable from selected
  annotated definitions, retaining the full book for type normalization.
- `j_library_selected(context, definitions)` emits a library the same way.
- `j_program(book)` emits declarations and the executable entry point.
- `j_library(book)` emits declarations and an exported primitive ABI.
- `j_foreign_paths(selected)` requests live custom foreign sources;
  `j_foreign_error(selected)` rejects missing JavaScript implementations.
- `j_modules(selected, sources)` embeds custom foreign JavaScript modules once each.
  Each source is `KTerm("Source", exactPathName, ..., [KTerm("Text", contents)])`.
- `j_descriptor(book, type, fuel)` emits typed readback metadata. Recursive
  datatypes refer to finite named schemas.

Prepend `src/runtime.mjs` to the output. Erased arguments/fields are null ABI
slots and their expressions are not evaluated. Function and constructor
metadata comes from annotations and constructor telescopes. Applications in
tail position and returned constructor fields use the runtime trampoline.
Non-tail applications pass their fresh literal argument vectors to internal
`callOwned`, avoiding a redundant copy. Partial-prefix concatenation, public
`call`, matcher fields and tail-message vectors retain their existing copying.
Foreign JavaScript uses named
constructor fields and curried functions; runtime marshalling converts layouts
iteratively and preserves trusted inbound values, including opaque fields on
values passed directly between foreign functions.

Use the complete module graph in `src/compiler.json` when building a checked
compiler. The maintained tests can bind its API through `BEND_TYPED_API` and
`tools/backend-test-api.mjs`; `build/js-backend.mjs` is a legacy bootstrap test
input, not the module list for the current backend. The Phase44 qualification
launcher binds a passed attempt, verifies its host dependencies, and runs eight
semantic suites serially with explicit CPU, memory and deadline limits. From the
repository root, with a fresh output directory:

```sh
python3 selfhost/tools/performance/phase44/qualify.py \
  selfhost/build/phase44/checked04 selfhost/build/phase44-local/qualification-NEW
```

`survey.mjs` exercises actual upstream source files through the checked compiler
pipeline and records the compiler API hash.
`test-layout.mjs` checks the shared layout gate using the configured typed API;
`test-string-eq.mjs` compares the equality intrinsic with a pinned Base oracle.

The emitter uses lexical JavaScript variables for core binder IDs. Parallel
`Let` right-hand sides use the outer scope: expression emission evaluates arrow
arguments before binding, while return-position statement emission evaluates
temporaries before opening the source-binding block. Consecutive leading lambdas share one closure; application
batching stops at the proven leading-lambda arity so intermediate computation
still precedes later argument evaluation. Computed globals remain reevaluated thunks; leading lambdas, top-level matcher wrappers and proven record projections share one closure.
`u32.bend` recognizes native U32-to-U32 ordered decision trees with closed literal
leaves before deep lifting. It emits one arity1 worker with unsigned bit tests,
with native ownership checks and an8192-node bound. Other result types, captures
and used structural fields keep generic lowering. It adds no runtime ABI. See
the [Phase26 report](../../../../implementation/phase26/direct-u32-decisions.md)
and `test-u32.mjs` for provenance, budget and valid-native-input boundaries.
`test.mjs` covers partial calls, erased arguments, effect/error evaluation order,
parallel shadowing, and closures that outlive their defining `Let`.

`primitive.bend` emits JavaScript arithmetic for 54 supported native U32/F32
operations at exact saturation. It checks native definition and datatype
identity, the complete scalar telescope, live arguments and arity. Operands
are evaluated once in source order; conditional division, modulo and shifts
bind both operands before testing them. Unsigned wrapping, zero divisors,
large Nat shift counts and F32 rounding follow the existing runtime. Partial
applications, foreign definitions and unsupported signatures use ordinary
application, retaining the native descriptors and their public ABI.

`worker.bend` recognizes a non-native definition with a native Nat
`Zero`/`Succ` matcher and explicit live scalar parameters. Its successor arm
must end in an exactly saturated self call on the captured predecessor, through
only annotations and `Let` bindings. The public matcher and initial partial
descriptor retain their argument demand. After full entry, a private loop
evaluates the next arguments into temporaries and selects the original Zero
body or the next successor iteration. Each iteration has fresh immutable
binder aliases, preserving closures; parallel RHSs precede their new bindings,
and erased RHSs remain unevaluated. Eligibility is limited to 2–32 slots,
8,192 core nodes, no deep closure factories, and native Nat/U32/F32/Bool scalar
parameters and results. All other definitions keep the existing emitter.
These rules add no runtime helpers, datatype representation or public arity.

The later private-region path in `region.bend` can include closed local data.
`local.bend` proves bounded nonrecursive record/Sigma layouts and canonical
`Array<U32>` native signatures. Public roots keep the scalar entry restriction;
private helpers may pass locally created containers. `JNative` emits the existing
array operations. `JUnpack` records the full field telescope and proved input
type, so `emit.bend` can read tuple indices or ordinary `.a` fields in order.
Private helper results complete at their already-required demand point; their
direct callers therefore need no force. The original public callbacks and value
representations remain available when admission or the entry guard fails.
See the [Phase31 design](../../../../design/phase31/checked-local-regions.md),
[private demand proof](../../../../design/phase31/fully-demanded-private-results.md)
and [field-read proof](../../../../design/phase31/direct-private-field-reads.md).

For parser performance comparisons, build both outputs from the same checked
book with `benchmark-build-parser.mjs CANDIDATE_API.mjs`, then run
`benchmark-parser.mjs BASELINE.mjs CANDIDATE.mjs [SOURCE.bend]`. The benchmark
uses ABBA ordering and requires identical parsed output; `BEND_BENCHMARK_REPORT`
selects the report path. `BEND_TYPED_API` selects the baseline compiler API.

Definitions with more than 32 nested closures use flat closure factories with
explicit lexical captures, keeping emitted JavaScript within parser stack
limits. `BEND_JS_REFERENCE` optionally checks byte-equivalence against a prior
backend API in `test.mjs`; use it for migrations intended to preserve printing,
not transformations that deliberately change emitted expressions. The deep
capture fixture and upstream `flatten/literal_rows_cubic.bend` cover the new
path. Benchmark and promotion evidence lives in `experiments/`.

`test-provenance.mjs` compiles a no-Base library that declares ten constructors
with primitive names and verifies that their fields survive construction and
matching. Generated metadata marks Base provenance; absent flags preserve the
legacy runtime ABI. Literal compression also checks the declared result type.

`test-global-initializers.mjs` checks that computed globals still initialize on
every reference. Set `BEND_EXPECT_CACHED_LAM=1` to require leading-lambda caching.
`src/runtime/js/test-apply.mjs` checks argument ownership, mutation isolation,
partial application, oversaturation, and constructor evaluation order. The
backend and runtime tests accept `BEND_JS_RUNTIME` for isolated runtime variants.

## Phase 1 execution improvements

`choice.bend` recognizes a transparent Boolean-choice definition by its core
body and Base Bool/Unit provenance. A fully applied call with two literal lambda
thunks emits a JavaScript conditional. The selected lambda receives Unit (or an
erased null slot), and its body retains the original tail-position flag. Partial
calls, computed thunk arguments, and different bodies use ordinary application.
`test-choice.mjs` compares both branches with pinned upstream and checks dynamic
argument evaluation, condition-before-branch ordering and 50,000 tail calls.

Base `String.contains`, `String.starts_with`, `String.reverse` and
`String.is_empty` preserve the existing native runtime implementation. The same
`j_intrinsic` classification drives stop sets and emission; user definitions
without Base provenance retain their Bend implementation.
`test-string-primitives.mjs` compares wrappers against pinned Base, including
empty, non-BMP and malformed host strings. Run both new tests with an explicit
`BEND_TYPED_API` and `BEND_UPSTREAM`.

Selected emission prepares one persistent `book_context` and reuses it through
annotation, layout validation and emission. Direct backend entry points prepare
an unindexed input themselves. A context is immutable and valid only for the
book from which it was built; specialization must finish before preparation.

To exercise a self-emitted API with the named-field backend fixtures, set both
`BEND_TYPED_API=/absolute/self-emitted.mjs` and
`BEND_JS_BACKEND=$PWD/tools/backend-test-api.mjs`. That adapter uses the same lazy
ABI boundary as ordinary compilation. Bootstrap APIs can still be selected
directly with `BEND_JS_BACKEND`.

`projection.bend` gives pure single-constructor field accessors a one-argument
worker. It proves that the arm consumes the complete live-field telescope and
returns one of those fields. Eta-short arms that apply a function-valued field,
erased-field arms and arbitrary computations retain the generic matcher.
The worker uses the same `project` helper and retains the field-vector copy,
including observable field-read order. `test-projection.mjs` checks those bounds,
function fields, oversaturation, effects, erasure and input ownership.

Top-level `Mat` values also have pure wrapper construction: `j_match` emits
`matcher`/`matcher1` factories whose arm expressions are delayed callbacks.
The wrapper is cached, while arms execute on each call. `Let`, `Rwt`, references
and other computed initializers retain their thunks, including computations
that return a matcher. Application-spine arity is unchanged, so applying a
matcher still completes before evaluating later curried arguments.
`test-global-initializers.mjs` and `test.mjs` cover deferred arms, live global
references, computed matcher effects and intermediate-error ordering.

Single-constructor matches use `matcher1` and an ordinary delayed arm factory.
Projection and the first field-length read precede arm construction; generic
application owns field copying, partial descriptors, saturation and later demand.
Nat loop/tree wrappers use the same matcher and retain exact-entry permission
only for the final private worker callback. Phase30 retired the separate arm
prebinding recognizer and runtime helper after entry-registration overhead
regressed generic workloads. The generic path also restores original observable
application hooks. See the [retirement design](../../../../design/phase30/retire-arm-prebinding.md)
and [runtime attribution](../../../../implementation/phase30/generic-runtime-row-diagnosis.md).

`test-arm.mjs` checks72 matching descriptor/effect/output observations against a
baseline through actual `j_library` emission. It uses synthetic KDefs; ordinary
checked corpus controls cover frontend admission separately. The
[Phase27 report](../../../../implementation/phase27/constructor-arm-prebinding.md)
retains the rejected inline variant, both warmup protocols and the shared helper's
modest measured benefit. Phase30 retires that helper after the later exact-entry
runtime changed its cost. The retained test still checks ordinary descriptor and
effect behavior; it does not require prebinding to be selected.
