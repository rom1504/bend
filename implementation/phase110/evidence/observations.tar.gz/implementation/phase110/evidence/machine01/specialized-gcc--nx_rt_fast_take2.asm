
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402bf0 <nx_rt_fast_take2>:
  402bf0:	movabs $0xffffffffff,%rax
  402bfa:	push   %r12
  402bfc:	and    %rsi,%rax
  402bff:	push   %rbp
  402c00:	push   %rbx
  402c01:	mov    %rdi,%rbx
  402c04:	mov    (%rdi),%rdi
  402c07:	lea    0x0(,%rax,8),%rcx
  402c0f:	mov    0x8(%rbx),%rbp
  402c13:	lea    (%rdi,%rcx,1),%rdx
  402c17:	test   %rsi,%rsi
  402c1a:	js     402c88 <nx_rt_fast_take2+0x98>
  402c1c:	mov    (%rdx),%rdx
  402c1f:	mov    %rdx,0x10(%rbx)
  402c23:	mov    0x8(%rdi,%rcx,1),%rdx
  402c28:	mov    %rdx,0x18(%rbx)
  402c2c:	cmp    $0x310817f,%rax
  402c32:	ja     402c48 <nx_rt_fast_take2+0x58>
  402c34:	movl   $0x3,0x20(%rbx)
  402c3b:	xor    %eax,%eax
  402c3d:	pop    %rbx
  402c3e:	pop    %rbp
  402c3f:	pop    %r12
  402c41:	retq   
  402c42:	nopw   0x0(%rax,%rax,1)
  402c48:	mov    0x8(%rbp),%rdx
  402c4c:	mov    %rdx,(%rdi,%rax,8)
  402c50:	mov    0x3e582(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402c56:	mov    %rax,0x8(%rbp)
  402c5a:	mov    0x108(%rbp),%rax
  402c61:	add    $0x2,%rax
  402c65:	mov    %rax,0x108(%rbp)
  402c6c:	cmp    %rdx,%rax
  402c6f:	jae    40160f <nx_rt_fast_take2.cold>
  402c75:	movl   $0x3,0x20(%rbx)
  402c7c:	xor    %eax,%eax
  402c7e:	pop    %rbx
  402c7f:	pop    %rbp
  402c80:	pop    %r12
  402c82:	retq   
  402c83:	nopl   0x0(%rax,%rax,1)
  402c88:	mov    0x4(%rdx),%ecx
  402c8b:	mov    (%rdx),%r8d
  402c8e:	shl    $0x20,%rcx
  402c92:	or     %r8,%rcx
  402c95:	mov    %rcx,%r12
  402c98:	and    $0xffffff,%ecx
  402c9e:	shr    $0x18,%r12
  402ca2:	lea    0x0(,%r12,8),%r8
  402caa:	lea    (%rdi,%r8,1),%r9
  402cae:	lea    0x8(%rdi,%r8,1),%r8
  402cb3:	cmp    $0x1,%rcx
  402cb7:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  402cbd:	mov    (%rdx),%ecx
  402cbf:	mov    (%r9),%rcx
  402cc2:	mov    %rcx,0x10(%rbx)
  402cc6:	mov    (%r8),%rcx
  402cc9:	mov    %rcx,0x18(%rbx)
  402ccd:	mov    0x0(%rbp),%rcx
  402cd1:	mov    %rcx,(%rdx)
  402cd4:	mov    0x3e4fe(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402cda:	mov    %rax,0x0(%rbp)
  402cde:	mov    0x100(%rbp),%rax
  402ce5:	add    $0x1,%rax
  402ce9:	mov    %rax,0x100(%rbp)
  402cf0:	cmp    %rdx,%rax
  402cf3:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402cf9:	mov    %r12,%rax
  402cfc:	jmpq   402c2c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
