
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004022e0 <nx_rt_id>:
  4022e0:	cmpb   $0x0,0x5e99(%rip)        # 408180 <nx_active>
  4022e7:	je     4022f5 <nx_rt_id+0x15>
  4022e9:	lea    0x5eb0(%rip),%rax        # 4081a0 <nx_context>
  4022f0:	cmp    %rax,%rdi
  4022f3:	je     402308 <nx_rt_id+0x28>
  4022f5:	push   %rax
  4022f6:	lea    0x2d36(%rip),%rdi        # 405033 <_IO_stdin_used+0x33>
  4022fd:	callq  401ac0 <err_fail>
  402302:	nopw   0x0(%rax,%rax,1)
  402308:	mov    0x5e91(%rip),%rdi        # 4081a0 <nx_context>
  40230f:	jmpq   401bf0 <nx_id.isra.0>

Disassembly of section .fini:
