
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/tree-bitonic/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040cb70 <p111_FID_36_100_105_114_101_99_116_46_119_97_114_112_>:
  40cb70:	endbr64 
  40cb74:	push   %rbp
  40cb75:	mov    %rsp,%rbp
  40cb78:	sub    $0x18,%rsp
  40cb7c:	push   %rbx
  40cb7d:	push   %r12
  40cb7f:	push   %r13
  40cb81:	mov    $0x0,%esi
  40cb86:	mov    %rdi,%rbx
  40cb89:	callq  414bd0 <p111_rt_reg_get>
  40cb8e:	mov    %rbx,%rdi
  40cb91:	mov    %rax,%rsi
  40cb94:	mov    %rsi,%r12
  40cb97:	mov    $0x1,%esi
  40cb9c:	mov    %rdi,%rbx
  40cb9f:	callq  414bd0 <p111_rt_reg_get>
  40cba4:	mov    %r12,%rsi
  40cba7:	mov    %rbx,%rdi
  40cbaa:	mov    %rax,%r13
  40cbad:	mov    %rsi,%r12
  40cbb0:	mov    $0x2,%esi
  40cbb5:	mov    %rdi,%rbx
  40cbb8:	callq  414bd0 <p111_rt_reg_get>
  40cbbd:	mov    %r13,%rdx
  40cbc0:	mov    %r12,%rsi
  40cbc3:	mov    %rbx,%rdi
  40cbc6:	mov    %rax,%rcx
  40cbc9:	mov    %rdi,%rbx
  40cbcc:	callq  40cbf0 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_>
  40cbd1:	mov    %rbx,%rdi
  40cbd4:	mov    %rax,-0x8(%rbp)
  40cbd8:	mov    $0x1,%edx
  40cbdd:	lea    -0x8(%rbp),%rsi
  40cbe1:	callq  414a80 <p111_rt_return>
  40cbe6:	pop    %r13
  40cbe8:	pop    %r12
  40cbea:	pop    %rbx
  40cbeb:	leaveq 
  40cbec:	retq   

Disassembly of section .fini:
