
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004024c0 <nx_rt_build2>:
  4024c0:	cmpb   $0x0,0x4cb9(%rip)        # 407180 <nx_active>
  4024c7:	push   %r14
  4024c9:	push   %r13
  4024cb:	push   %r12
  4024cd:	push   %rbp
  4024ce:	push   %rbx
  4024cf:	je     4024dd <nx_rt_build2+0x1d>
  4024d1:	lea    0x4cc8(%rip),%rax        # 4071a0 <nx_context>
  4024d8:	cmp    %rax,%rdi
  4024db:	je     4024f0 <nx_rt_build2+0x30>
  4024dd:	lea    0x1b4f(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4024e4:	callq  4019f0 <err_fail>
  4024e9:	nopl   0x0(%rax)
  4024f0:	mov    0x4ca9(%rip),%r14        # 4071a0 <nx_context>
  4024f7:	mov    %esi,%r12d
  4024fa:	mov    %rdx,%r13
  4024fd:	mov    %rcx,%rbx
  402500:	mov    0x4ca1(%rip),%rbp        # 4071a8 <nx_context+0x8>
  402507:	mov    %r14,%rdi
  40250a:	callq  401c20 <nx_fields.isra.0>
  40250f:	mov    0x8(%rbp),%r9
  402513:	test   %r9,%r9
  402516:	je     402544 <nx_rt_build2+0x84>
  402518:	mov    (%r14,%r9,8),%rax
  40251c:	subq   $0x2,0x108(%rbp)
  402524:	mov    %rax,0x8(%rbp)
  402528:	mov    %rbx,%r8
  40252b:	mov    %r13,%rcx
  40252e:	pop    %rbx
  40252f:	mov    %r12d,%edx
  402532:	mov    %r14,%rdi
  402535:	mov    %rbp,%rsi
  402538:	pop    %rbp
  402539:	pop    %r12
  40253b:	pop    %r13
  40253d:	pop    %r14
  40253f:	jmpq   401cc0 <nx_construct2>
  402544:	jmpq   40154f <nx_rt_build2.cold>

Disassembly of section .fini:
