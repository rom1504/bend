
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004029e0 <nx_rt_fast_field>:
  4029e0:	mov    %esi,%ecx
  4029e2:	mov    $0xfffffffe,%eax
  4029e7:	rol    %cl,%eax
  4029e9:	add    $0x2,%rcx
  4029ed:	and    %eax,0x20(%rdi)
  4029f0:	mov    (%rdi,%rcx,8),%rax
  4029f4:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  4029fc:	retq   

Disassembly of section .fini:
