
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004040b0 <nx_rt_pair_take2>:
  4040b0:	movabs $0xffffffffff,%rax
  4040ba:	push   %r15
  4040bc:	and    %rsi,%rax
  4040bf:	push   %r14
  4040c1:	push   %r13
  4040c3:	lea    0x0(,%rax,8),%rdx
  4040cb:	push   %r12
  4040cd:	push   %rbp
  4040ce:	mov    (%rdi),%rbp
  4040d1:	mov    0x8(%rdi),%r14
  4040d5:	lea    0x0(%rbp,%rdx,1),%rcx
  4040da:	test   %rsi,%rsi
  4040dd:	js     404140 <nx_rt_pair_take2+0x90>
  4040df:	mov    (%rcx),%r13
  4040e2:	mov    0x8(%rbp,%rdx,1),%r12
  4040e7:	cmp    $0x310817f,%rax
  4040ed:	ja     404100 <nx_rt_pair_take2+0x50>
  4040ef:	pop    %rbp
  4040f0:	mov    %r13,%rax
  4040f3:	mov    %r12,%rdx
  4040f6:	pop    %r12
  4040f8:	pop    %r13
  4040fa:	pop    %r14
  4040fc:	pop    %r15
  4040fe:	retq   
  4040ff:	nop
  404100:	mov    0x8(%r14),%rdx
  404104:	mov    %rdx,0x0(%rbp,%rax,8)
  404109:	mov    0x3d0c9(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40410f:	mov    %rax,0x8(%r14)
  404113:	mov    0x108(%r14),%rax
  40411a:	add    $0x2,%rax
  40411e:	mov    %rax,0x108(%r14)
  404125:	cmp    %rdx,%rax
  404128:	jae    401be0 <nx_rt_pair_take2.cold>
  40412e:	pop    %rbp
  40412f:	mov    %r13,%rax
  404132:	mov    %r12,%rdx
  404135:	pop    %r12
  404137:	pop    %r13
  404139:	pop    %r14
  40413b:	pop    %r15
  40413d:	retq   
  40413e:	xchg   %ax,%ax
  404140:	mov    0x4(%rcx),%edx
  404143:	mov    (%rcx),%edi
  404145:	shl    $0x20,%rdx
  404149:	or     %rdi,%rdx
  40414c:	mov    %rdx,%r15
  40414f:	and    $0xffffff,%edx
  404155:	shr    $0x18,%r15
  404159:	lea    0x8(,%r15,8),%rdi
  404161:	lea    0x0(%rbp,%rdi,1),%r8
  404166:	cmp    $0x1,%rdx
  40416a:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  404170:	mov    (%rcx),%edx
  404172:	mov    (%r14),%rdx
  404175:	mov    -0x8(%rbp,%rdi,1),%r13
  40417a:	mov    (%r8),%r12
  40417d:	mov    %rdx,(%rcx)
  404180:	mov    0x3d052(%rip),%edx        # 4411d8 <KEEP_WORDS>
  404186:	mov    %rax,(%r14)
  404189:	mov    0x100(%r14),%rax
  404190:	add    $0x1,%rax
  404194:	mov    %rax,0x100(%r14)
  40419b:	cmp    %rdx,%rax
  40419e:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  4041a4:	mov    %r15,%rax
  4041a7:	jmpq   4040e7 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
