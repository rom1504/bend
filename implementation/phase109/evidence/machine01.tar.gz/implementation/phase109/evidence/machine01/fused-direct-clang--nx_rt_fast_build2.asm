
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402790 <nx_rt_fast_build2>:
  402790:	push   %r15
  402792:	push   %r14
  402794:	push   %r13
  402796:	mov    %rdx,%r13
  402799:	push   %r12
  40279b:	mov    %rcx,%r12
  40279e:	push   %rbp
  40279f:	push   %rbx
  4027a0:	mov    %esi,%ebx
  4027a2:	sub    $0x18,%rsp
  4027a6:	mov    0x8(%rdi),%r14
  4027aa:	mov    (%rdi),%r15
  4027ad:	mov    0x8(%r14),%rbp
  4027b1:	test   %rbp,%rbp
  4027b4:	je     4015f3 <nx_rt_fast_build2.cold+0x40>
  4027ba:	lea    (%r15,%rbp,8),%r8
  4027be:	mov    (%r8),%rax
  4027c1:	subq   $0x2,0x108(%r14)
  4027c9:	mov    %rax,0x8(%r14)
  4027cd:	mov    %r13,%rax
  4027d0:	shr    $0x38,%rax
  4027d4:	and    $0x7f,%eax
  4027d7:	cmp    $0x2,%rax
  4027db:	je     402820 <nx_rt_fast_build2+0x90>
  4027dd:	mov    %r12,%rax
  4027e0:	mov    %r13,(%r8)
  4027e3:	lea    0x8(%r15,%rbp,8),%r13
  4027e8:	shr    $0x38,%rax
  4027ec:	and    $0x7f,%eax
  4027ef:	cmp    $0x2,%rax
  4027f3:	je     402830 <nx_rt_fast_build2+0xa0>
  4027f5:	mov    %rbx,%rax
  4027f8:	mov    %r12,0x0(%r13)
  4027fc:	add    $0x18,%rsp
  402800:	shl    $0x28,%rax
  402804:	pop    %rbx
  402805:	or     %rbp,%rax
  402808:	pop    %rbp
  402809:	pop    %r12
  40280b:	bts    $0x39,%rax
  402810:	pop    %r13
  402812:	pop    %r14
  402814:	pop    %r15
  402816:	retq   
  402817:	nopw   0x0(%rax,%rax,1)
  402820:	test   %r13,%r13
  402823:	js     4027dd <nx_rt_fast_build2+0x4d>
  402825:	jmpq   4015b3 <nx_rt_fast_build2.cold>
  40282a:	nopw   0x0(%rax,%rax,1)
  402830:	test   %r12,%r12
  402833:	js     4027f5 <nx_rt_fast_build2+0x65>
  402835:	jmpq   4015d8 <nx_rt_fast_build2.cold+0x25>

Disassembly of section .fini:
