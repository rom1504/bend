
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/tree-bitonic/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040cbf0 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_>:
  40cbf0:	endbr64 
  40cbf4:	push   %rbp
  40cbf5:	mov    %rsp,%rbp
  40cbf8:	sub    $0x1818,%rsp
  40cbff:	push   %rbx
  40cc00:	push   %r12
  40cc02:	push   %r13
  40cc04:	push   %r14
  40cc06:	push   %r15
  40cc08:	mov    $0x0,%ebx
  40cc0d:	nopl   (%rax)
  40cc10:	mov    %rsi,%r8
  40cc13:	shr    $0x28,%r8
  40cc17:	mov    %r8,%rax
  40cc1a:	and    $0xffff,%rax
  40cc20:	cmp    $0xa4,%rax
  40cc26:	sete   %r10b
  40cc2a:	movzbl %r10b,%r10d
  40cc2e:	mov    %rdx,%r11
  40cc31:	shr    $0x28,%r11
  40cc35:	mov    %rcx,%r15
  40cc38:	mov    %r11,%rcx
  40cc3b:	and    $0x7fffff,%rcx
  40cc42:	mov    %rcx,-0x10(%rbp)
  40cc46:	mov    %rax,%r9
  40cc49:	movabs $0xffffffffff,%rax
  40cc53:	and    %rdx,%rax
  40cc56:	mov    %rax,-0x8(%rbp)
  40cc5a:	mov    %r11,%r12
  40cc5d:	and    $0xffff,%r12
  40cc64:	cmp    $0x0,%r10d
  40cc68:	jne    40ceb1 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2c1>
  40cc6e:	mov    %r9,%rax
  40cc71:	cmp    $0xa5,%rax
  40cc77:	jne    40ce45 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x255>
  40cc7d:	mov    %rdx,%r14
  40cc80:	lea    -0x1810(%rbp),%rdx
  40cc87:	mov    %rdi,%r13
  40cc8a:	callq  41a200 <p125_rt_take2>
  40cc8f:	mov    %r15,%rcx
  40cc92:	mov    %r14,%rdx
  40cc95:	mov    %r13,%rdi
  40cc98:	mov    -0x8(%rbp),%rax
  40cc9c:	mov    %rcx,%r15
  40cc9f:	mov    -0x10(%rbp),%rcx
  40cca3:	mov    -0x1810(%rbp),%rsi
  40ccaa:	mov    -0x1808(%rbp),%r14
  40ccb1:	cmp    $0xa4,%r12
  40ccb8:	je     40cdd5 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1e5>
  40ccbe:	xchg   %ax,%ax
  40ccc0:	cmp    $0xa5,%r12
  40ccc7:	jne    40cd65 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x175>
  40cccd:	cs cs cs mov %rdx,%r12
  40ccd3:	lea    -0x1810(%rbp),%rdx
  40ccda:	mov    %rsi,%r13
  40ccdd:	mov    %r12,%rsi
  40cce0:	mov    %rdi,%r12
  40cce3:	callq  41a200 <p125_rt_take2>
  40cce8:	mov    %r15,%rcx
  40cceb:	mov    %r13,%rsi
  40ccee:	mov    %r12,%rdi
  40ccf1:	mov    -0x1810(%rbp),%rdx
  40ccf8:	mov    -0x1808(%rbp),%rax
  40ccff:	mov    %r14,-0x1810(%rbp)
  40cd06:	mov    %rcx,-0x1808(%rbp)
  40cd0d:	mov    %rax,-0x1800(%rbp)
  40cd14:	mov    0x10(%rdi),%rax
  40cd18:	mov    %r14,(%rax)
  40cd1b:	mov    -0x1808(%rbp),%r8
  40cd22:	mov    %r8,0x8(%rax)
  40cd26:	mov    %rcx,%r15
  40cd29:	mov    -0x1800(%rbp),%rcx
  40cd30:	mov    %rcx,0x10(%rax)
  40cd34:	movq   $0x74,0x18(%rax)
  40cd3c:	add    $0x20,%rax
  40cd40:	mov    %rax,0x10(%rdi)
  40cd44:	add    $0x1,%rbx
  40cd48:	mov    %rsi,-0x1810(%rbp)
  40cd4f:	mov    %rdx,-0x1808(%rbp)
  40cd56:	mov    %r15,-0x1800(%rbp)
  40cd5d:	mov    %r15,%rcx
  40cd60:	jmpq   40cc10 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x20>
  40cd65:	mov    %rdx,%r12
  40cd68:	mov    %r15,%r13
  40cd6b:	mov    %rdi,%rbx
  40cd6e:	callq  414460 <p111_rt_sink>
  40cd73:	mov    %r14,%rsi
  40cd76:	mov    %rbx,%rdi
  40cd79:	mov    %rdi,%rbx
  40cd7c:	callq  414460 <p111_rt_sink>
  40cd81:	mov    %r13,%rcx
  40cd84:	mov    %r12,%rdx
  40cd87:	mov    %rbx,%rdi
  40cd8a:	mov    %rcx,-0x1810(%rbp)
  40cd91:	mov    0x10(%rdi),%rax
  40cd95:	mov    %rcx,(%rax)
  40cd98:	movq   $0x76,0x8(%rax)
  40cda0:	add    $0x10,%rax
  40cda4:	mov    %rax,0x10(%rdi)
  40cda8:	mov    %rdx,-0x1810(%rbp)
  40cdaf:	mov    0x10(%rdi),%rax
  40cdb3:	mov    %rdx,(%rax)
  40cdb6:	movq   $0x77,0x8(%rax)
  40cdbe:	add    $0x10,%rax
  40cdc2:	mov    %rax,0x10(%rdi)
  40cdc6:	mov    $0x4,%esi
  40cdcb:	callq  414bf0 <p111_rt_fail>
  40cdd0:	jmpq   40d11c <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x52c>
  40cdd5:	cmp    $0x100a4,%rcx
  40cddc:	je     40cdfe <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x20e>
  40cdde:	mov    %rdx,%r12
  40cde1:	lea    -0x1810(%rbp),%rdx
  40cde8:	mov    %rsi,%r13
  40cdeb:	mov    %r12,%rsi
  40cdee:	mov    %rdi,%r12
  40cdf1:	callq  419f80 <p125_rt_take1>
  40cdf6:	mov    %r13,%rsi
  40cdf9:	mov    %r12,%rdi
  40cdfc:	jmp    40ce08 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x218>
  40cdfe:	cs cs mov %rax,%cs:-0x1810(%rbp)
  40ce08:	mov    -0x1810(%rbp),%r13
  40ce0f:	mov    %rdi,%r12
  40ce12:	callq  414460 <p111_rt_sink>
  40ce17:	mov    %r14,%rsi
  40ce1a:	mov    %r12,%rdi
  40ce1d:	mov    %rdi,%r12
  40ce20:	callq  414460 <p111_rt_sink>
  40ce25:	mov    %r13,%rsi
  40ce28:	mov    %r12,%rdi
  40ce2b:	mov    %rdi,%r12
  40ce2e:	callq  414460 <p111_rt_sink>
  40ce33:	mov    %r12,%rdi
  40ce36:	movabs $0x100a40000000000,%rax
  40ce40:	jmpq   40d050 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x460>
  40ce45:	mov    %r15,%rcx
  40ce48:	mov    %rcx,-0x1810(%rbp)
  40ce4f:	mov    0x10(%rdi),%rax
  40ce53:	mov    %rcx,(%rax)
  40ce56:	movq   $0x78,0x8(%rax)
  40ce5e:	add    $0x10,%rax
  40ce62:	mov    %rax,0x10(%rdi)
  40ce66:	mov    %rdx,-0x1810(%rbp)
  40ce6d:	mov    0x10(%rdi),%rax
  40ce71:	mov    %rdx,(%rax)
  40ce74:	movq   $0x79,0x8(%rax)
  40ce7c:	add    $0x10,%rax
  40ce80:	mov    %rax,0x10(%rdi)
  40ce84:	mov    %rsi,-0x1810(%rbp)
  40ce8b:	mov    0x10(%rdi),%rax
  40ce8f:	mov    %rsi,(%rax)
  40ce92:	movq   $0x7a,0x8(%rax)
  40ce9a:	add    $0x10,%rax
  40ce9e:	mov    %rax,0x10(%rdi)
  40cea2:	mov    $0x4,%esi
  40cea7:	callq  414bf0 <p111_rt_fail>
  40ceac:	jmpq   40d11c <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x52c>
  40ceb1:	and    $0x7fffff,%r8
  40ceb8:	nopl   0x0(%rax,%rax,1)
  40cec0:	cmp    $0x100a4,%r8
  40cec7:	je     40cef4 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x304>
  40cec9:	mov    %rdx,%r14
  40cecc:	lea    -0x1810(%rbp),%rdx
  40ced3:	mov    %rdi,%r13
  40ced6:	callq  419f80 <p125_rt_take1>
  40cedb:	mov    %r15,%rcx
  40cede:	mov    %r14,%rdx
  40cee1:	mov    %r13,%rdi
  40cee4:	mov    -0x8(%rbp),%rax
  40cee8:	mov    %rcx,%r14
  40ceeb:	mov    -0x10(%rbp),%rcx
  40ceef:	mov    %rdx,%r15
  40cef2:	jmp    40cf19 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x329>
  40cef4:	cs cs cs cs mov %r15,%r14
  40cefb:	cs cs cs cs mov %rdx,%r15
  40cf02:	cs cs cs movabs $0xffffffffff,%rdx
  40cf0f:	and    %rsi,%rdx
  40cf12:	mov    %rdx,-0x1810(%rbp)
  40cf19:	mov    -0x1810(%rbp),%rsi
  40cf20:	cmp    $0xa4,%r12
  40cf27:	je     40cfe5 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x3f5>
  40cf2d:	cs cs cs cs mov %rdi,%r13
  40cf34:	callq  414460 <p111_rt_sink>
  40cf39:	cs mov %r15,%rdx
  40cf3d:	mov    %r13,%rdi
  40cf40:	cmp    $0xa5,%r12
  40cf47:	jne    40cf97 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x3a7>
  40cf49:	mov    %rdx,%r12
  40cf4c:	lea    -0x1810(%rbp),%rdx
  40cf53:	mov    %r12,%rsi
  40cf56:	mov    %rdi,%r12
  40cf59:	callq  41a200 <p125_rt_take2>
  40cf5e:	mov    %r12,%rdi
  40cf61:	mov    -0x1810(%rbp),%rsi
  40cf68:	mov    -0x1808(%rbp),%r13
  40cf6f:	mov    %rdi,%r12
  40cf72:	callq  414460 <p111_rt_sink>
  40cf77:	mov    %r13,%rsi
  40cf7a:	mov    %r12,%rdi
  40cf7d:	mov    %rdi,%r12
  40cf80:	callq  414460 <p111_rt_sink>
  40cf85:	mov    %r12,%rdi
  40cf88:	movabs $0x100a40000000000,%rax
  40cf92:	jmpq   40d050 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x460>
  40cf97:	mov    %r14,%rcx
  40cf9a:	mov    %rcx,-0x1810(%rbp)
  40cfa1:	mov    0x10(%rdi),%rax
  40cfa5:	mov    %rcx,(%rax)
  40cfa8:	movq   $0x72,0x8(%rax)
  40cfb0:	add    $0x10,%rax
  40cfb4:	mov    %rax,0x10(%rdi)
  40cfb8:	mov    %rdx,-0x1810(%rbp)
  40cfbf:	mov    0x10(%rdi),%rax
  40cfc3:	mov    %rdx,(%rax)
  40cfc6:	movq   $0x73,0x8(%rax)
  40cfce:	add    $0x10,%rax
  40cfd2:	mov    %rax,0x10(%rdi)
  40cfd6:	mov    $0x4,%esi
  40cfdb:	callq  414bf0 <p111_rt_fail>
  40cfe0:	jmpq   40d11c <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x52c>
  40cfe5:	mov    %r15,%rdx
  40cfe8:	cmp    $0x100a4,%rcx
  40cfef:	je     40d014 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x424>
  40cff1:	mov    %rdx,%r12
  40cff4:	lea    -0x1810(%rbp),%rdx
  40cffb:	mov    %rsi,%r13
  40cffe:	mov    %r12,%rsi
  40d001:	mov    %rdi,%r12
  40d004:	callq  419f80 <p125_rt_take1>
  40d009:	mov    %r14,%rcx
  40d00c:	mov    %r13,%rsi
  40d00f:	mov    %r12,%rdi
  40d012:	jmp    40d01e <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x42e>
  40d014:	mov    %r14,%rcx
  40d017:	mov    %rax,-0x1810(%rbp)
  40d01e:	mov    -0x1810(%rbp),%rdx
  40d025:	mov    %rsi,-0x1810(%rbp)
  40d02c:	mov    %rdx,-0x1808(%rbp)
  40d033:	mov    %rcx,-0x1800(%rbp)
  40d03a:	mov    %rdi,%r12
  40d03d:	callq  405340 <p112w_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_108_101_97_102_>
  40d042:	mov    %r12,%rdi
  40d045:	mov    %rax,%r9
  40d048:	mov    %r9,%rax
  40d04b:	nopl   0x0(%rax,%rax,1)
  40d050:	cmp    $0x0,%rbx
  40d054:	je     40d11c <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x52c>
  40d05a:	mov    0x10(%rdi),%rcx
  40d05e:	mov    %rcx,%rdx
  40d061:	add    $0xfffffffffffffff8,%rdx
  40d065:	mov    %rdx,0x10(%rdi)
  40d069:	mov    -0x8(%rcx),%rsi
  40d06d:	cmp    $0x74,%rsi
  40d071:	sete   %r8b
  40d075:	movzbl %r8b,%r8d
  40d079:	mov    %rcx,%rdx
  40d07c:	sub    $0x10,%rdx
  40d080:	cmp    $0x0,%r8d
  40d084:	jne    40d0c5 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4d5>
  40d086:	cmp    $0x75,%rsi
  40d08a:	jne    40d0b9 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4c9>
  40d08c:	mov    %rdx,0x10(%rdi)
  40d090:	sub    $0x10,%rcx
  40d094:	mov    (%rcx),%rsi
  40d097:	mov    %rsi,-0x810(%rbp)
  40d09e:	mov    %rax,-0x808(%rbp)
  40d0a5:	mov    %rax,%rdx
  40d0a8:	mov    %rdi,%r12
  40d0ab:	callq  405330 <p112w_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>
  40d0b0:	mov    %r12,%rdi
  40d0b3:	sub    $0x1,%rbx
  40d0b7:	jmp    40d050 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x460>
  40d0b9:	mov    $0x4,%esi
  40d0be:	callq  414bf0 <p111_rt_fail>
  40d0c3:	jmp    40d11c <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x52c>
  40d0c5:	mov    %rax,%r9
  40d0c8:	mov    %rdx,%rax
  40d0cb:	mov    %rcx,%rdx
  40d0ce:	mov    %rdx,%r10
  40d0d1:	sub    $0x20,%r10
  40d0d5:	mov    %r10,0x10(%rdi)
  40d0d9:	mov    (%r10),%rsi
  40d0dc:	mov    %rdx,%r8
  40d0df:	sub    $0x18,%r8
  40d0e3:	mov    (%r8),%rcx
  40d0e6:	sub    $0x10,%rdx
  40d0ea:	mov    (%rdx),%rdx
  40d0ed:	mov    %r9,-0x1010(%rbp)
  40d0f4:	mov    %r9,(%r10)
  40d0f7:	movq   $0x75,(%r8)
  40d0fe:	mov    %rax,0x10(%rdi)
  40d102:	mov    %rsi,-0x1010(%rbp)
  40d109:	mov    %rdx,-0x1008(%rbp)
  40d110:	mov    %rcx,-0x1000(%rbp)
  40d117:	jmpq   40cc10 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x20>
  40d11c:	pop    %r15
  40d11e:	pop    %r14
  40d120:	pop    %r13
  40d122:	pop    %r12
  40d124:	pop    %rbx
  40d125:	leaveq 
  40d126:	retq   

Disassembly of section .fini:
