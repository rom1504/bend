
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004040e0 <nx_rt_pair_take2>:
  4040e0:	movabs $0xffffffffff,%rax
  4040ea:	push   %r15
  4040ec:	and    %rsi,%rax
  4040ef:	push   %r14
  4040f1:	push   %r13
  4040f3:	lea    0x0(,%rax,8),%rdx
  4040fb:	push   %r12
  4040fd:	push   %rbp
  4040fe:	mov    (%rdi),%rbp
  404101:	mov    0x8(%rdi),%r14
  404105:	lea    0x0(%rbp,%rdx,1),%rcx
  40410a:	test   %rsi,%rsi
  40410d:	js     404170 <nx_rt_pair_take2+0x90>
  40410f:	mov    (%rcx),%r13
  404112:	mov    0x8(%rbp,%rdx,1),%r12
  404117:	cmp    $0x310817f,%rax
  40411d:	ja     404130 <nx_rt_pair_take2+0x50>
  40411f:	pop    %rbp
  404120:	mov    %r13,%rax
  404123:	mov    %r12,%rdx
  404126:	pop    %r12
  404128:	pop    %r13
  40412a:	pop    %r14
  40412c:	pop    %r15
  40412e:	retq   
  40412f:	nop
  404130:	mov    0x8(%r14),%rdx
  404134:	mov    %rdx,0x0(%rbp,%rax,8)
  404139:	mov    0x3d099(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40413f:	mov    %rax,0x8(%r14)
  404143:	mov    0x108(%r14),%rax
  40414a:	add    $0x2,%rax
  40414e:	mov    %rax,0x108(%r14)
  404155:	cmp    %rdx,%rax
  404158:	jae    401be0 <nx_rt_pair_take2.cold>
  40415e:	pop    %rbp
  40415f:	mov    %r13,%rax
  404162:	mov    %r12,%rdx
  404165:	pop    %r12
  404167:	pop    %r13
  404169:	pop    %r14
  40416b:	pop    %r15
  40416d:	retq   
  40416e:	xchg   %ax,%ax
  404170:	mov    0x4(%rcx),%edx
  404173:	mov    (%rcx),%edi
  404175:	shl    $0x20,%rdx
  404179:	or     %rdi,%rdx
  40417c:	mov    %rdx,%r15
  40417f:	and    $0xffffff,%edx
  404185:	shr    $0x18,%r15
  404189:	lea    0x8(,%r15,8),%rdi
  404191:	lea    0x0(%rbp,%rdi,1),%r8
  404196:	cmp    $0x1,%rdx
  40419a:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  4041a0:	mov    (%rcx),%edx
  4041a2:	mov    (%r14),%rdx
  4041a5:	mov    -0x8(%rbp,%rdi,1),%r13
  4041aa:	mov    (%r8),%r12
  4041ad:	mov    %rdx,(%rcx)
  4041b0:	mov    0x3d022(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4041b6:	mov    %rax,(%r14)
  4041b9:	mov    0x100(%r14),%rax
  4041c0:	add    $0x1,%rax
  4041c4:	mov    %rax,0x100(%r14)
  4041cb:	cmp    %rdx,%rax
  4041ce:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  4041d4:	mov    %r15,%rax
  4041d7:	jmpq   404117 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
