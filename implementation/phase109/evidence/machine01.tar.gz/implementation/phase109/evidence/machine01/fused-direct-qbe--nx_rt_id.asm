
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004021b0 <nx_rt_id>:
  4021b0:	cmpb   $0x0,0x4fc9(%rip)        # 407180 <nx_active>
  4021b7:	je     4021c5 <nx_rt_id+0x15>
  4021b9:	lea    0x4fe0(%rip),%rax        # 4071a0 <nx_context>
  4021c0:	cmp    %rax,%rdi
  4021c3:	je     4021d8 <nx_rt_id+0x28>
  4021c5:	push   %rax
  4021c6:	lea    0x1e66(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4021cd:	callq  401990 <err_fail>
  4021d2:	nopw   0x0(%rax,%rax,1)
  4021d8:	mov    0x4fc1(%rip),%rdi        # 4071a0 <nx_context>
  4021df:	jmpq   401ac0 <nx_id.isra.0>

Disassembly of section .fini:
