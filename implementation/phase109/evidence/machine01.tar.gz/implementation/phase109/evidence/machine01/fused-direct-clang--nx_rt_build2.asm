
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402420 <nx_rt_build2>:
  402420:	cmpb   $0x0,0x4d59(%rip)        # 407180 <nx_active>
  402427:	push   %r14
  402429:	push   %r13
  40242b:	push   %r12
  40242d:	push   %rbp
  40242e:	push   %rbx
  40242f:	je     40243d <nx_rt_build2+0x1d>
  402431:	lea    0x4d68(%rip),%rax        # 4071a0 <nx_context>
  402438:	cmp    %rax,%rdi
  40243b:	je     402450 <nx_rt_build2+0x30>
  40243d:	lea    0x1bef(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402444:	callq  401950 <err_fail>
  402449:	nopl   0x0(%rax)
  402450:	mov    0x4d49(%rip),%r14        # 4071a0 <nx_context>
  402457:	mov    %esi,%r12d
  40245a:	mov    %rdx,%r13
  40245d:	mov    %rcx,%rbx
  402460:	mov    0x4d41(%rip),%rbp        # 4071a8 <nx_context+0x8>
  402467:	mov    %r14,%rdi
  40246a:	callq  401b80 <nx_fields.isra.0>
  40246f:	mov    0x8(%rbp),%r9
  402473:	test   %r9,%r9
  402476:	je     4024a4 <nx_rt_build2+0x84>
  402478:	mov    (%r14,%r9,8),%rax
  40247c:	subq   $0x2,0x108(%rbp)
  402484:	mov    %rax,0x8(%rbp)
  402488:	mov    %rbx,%r8
  40248b:	mov    %r13,%rcx
  40248e:	pop    %rbx
  40248f:	mov    %r12d,%edx
  402492:	mov    %r14,%rdi
  402495:	mov    %rbp,%rsi
  402498:	pop    %rbp
  402499:	pop    %r12
  40249b:	pop    %r13
  40249d:	pop    %r14
  40249f:	jmpq   401c20 <nx_construct2>
  4024a4:	jmpq   40154f <nx_rt_build2.cold>

Disassembly of section .fini:
