
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401870 <nx_list_reverse>:
  401870:	endbr64 
  401874:	push   %rbp
  401875:	mov    %rsp,%rbp
  401878:	sub    $0x8,%rsp
  40187c:	push   %rbx
  40187d:	push   %r12
  40187f:	push   %r13
  401881:	mov    %rdx,%rax
  401884:	mov    %rax,%rbx
  401887:	nopw   0x0(%rax,%rax,1)
  401890:	mov    %rsi,%r13
  401893:	mov    %rdi,%r12
  401896:	callq  402730 <nx_rt_fast_id>
  40189b:	mov    %r13,%rsi
  40189e:	mov    %r12,%rdi
  4018a1:	cmp    $0x0,%eax
  4018a4:	je     40190c <nx_list_reverse+0x9c>
  4018a6:	cmp    $0x1,%eax
  4018a9:	jne    401900 <nx_list_reverse+0x90>
  4018ab:	mov    %rdi,%r12
  4018ae:	callq  4028c0 <nx_rt_fast_take2>
  4018b3:	mov    %r12,%rdi
  4018b6:	mov    $0x0,%esi
  4018bb:	mov    %rdi,%r12
  4018be:	callq  4029e0 <nx_rt_fast_field>
  4018c3:	mov    %r12,%rdi
  4018c6:	mov    %rax,%r13
  4018c9:	mov    $0x1,%esi
  4018ce:	mov    %rdi,%r12
  4018d1:	callq  4029e0 <nx_rt_fast_field>
  4018d6:	mov    %r13,%rdx
  4018d9:	mov    %r12,%rdi
  4018dc:	mov    %rax,%rsi
  4018df:	mov    %rbx,%rcx
  4018e2:	mov    %rsi,%r12
  4018e5:	mov    $0x1,%esi
  4018ea:	mov    %rdi,%rbx
  4018ed:	callq  402810 <nx_rt_fast_build2>
  4018f2:	mov    %r12,%rsi
  4018f5:	mov    %rbx,%rdi
  4018f8:	mov    %rax,%rdx
  4018fb:	mov    %rdx,%rbx
  4018fe:	jmp    401890 <nx_list_reverse+0x20>
  401900:	mov    $0x1,%esi
  401905:	callq  402230 <nx_rt_fail>
  40190a:	jmp    40190f <nx_list_reverse+0x9f>
  40190c:	mov    %rbx,%rax
  40190f:	pop    %r13
  401911:	pop    %r12
  401913:	pop    %rbx
  401914:	leaveq 
  401915:	retq   

Disassembly of section .fini:
