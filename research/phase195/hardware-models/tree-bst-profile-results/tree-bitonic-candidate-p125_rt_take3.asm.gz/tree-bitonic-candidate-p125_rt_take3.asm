0000000000421f90 <p125_rt_take3>:
  421f90:	mov    rax,rsi
  421f93:	mov    r8,QWORD PTR [rip+0x108d36]        # 52acd0 <p111_program_active>
  421f9a:	push   r12
  421f9c:	shr    rax,0x28
  421fa0:	push   rbp
  421fa1:	movzx  eax,ax
  421fa4:	push   rbx
  421fa5:	cmp    QWORD PTR [r8+0x18],rax
  421fa9:	ja     421fc0 <p125_rt_take3+0x30>
  421fab:	lea    rdi,[rip+0x13b1]        # 423363 <_IO_stdin_used+0x363>
  421fb2:	call   418060 <err_fail>
  421fb7:	nop    WORD PTR [rax+rax*1+0x0]
  421fc0:	mov    rcx,rdx
  421fc3:	mov    rdx,QWORD PTR [r8+0x80]
  421fca:	cmp    BYTE PTR [rdx+rax*1],0x3
  421fce:	jne    421fab <p125_rt_take3+0x1b>
  421fd0:	mov    rax,rsi
  421fd3:	shr    rax,0x38
  421fd7:	and    eax,0x7f
  421fda:	cmp    rax,0x2
  421fde:	jne    42211b <p125_rt_take3+0x18b>
  421fe4:	mov    r9,QWORD PTR [rdi]
  421fe7:	mov    rbx,rdi
  421fea:	movabs rdi,0xffffffffff
  421ff4:	and    rdi,rsi
  421ff7:	test   rsi,rsi
  421ffa:	js     422090 <p125_rt_take3+0x100>
  422000:	lea    rsi,[r9+rdi*8]
  422004:	xor    eax,eax
  422006:	nop    WORD PTR cs:[rax+rax*1+0x0]
  422010:	mov    rdx,QWORD PTR [rsi+rax*1]
  422014:	mov    QWORD PTR [rcx+rax*1],rdx
  422018:	add    rax,0x8
  42201c:	cmp    rax,0x18
  422020:	jne    422010 <p125_rt_take3+0x80>
  422022:	mov    rax,QWORD PTR [r8+0x40]
  422026:	add    rax,0x7f
  42202a:	and    rax,0xffffffffffffff80
  42202e:	add    rax,0x3108200
  422034:	cmp    rax,rdi
  422037:	jbe    422048 <p125_rt_take3+0xb8>
  422039:	pop    rbx
  42203a:	mov    eax,0x3
  42203f:	pop    rbp
  422040:	pop    r12
  422042:	ret    
  422043:	nop    DWORD PTR [rax+rax*1+0x0]
  422048:	mov    rsi,QWORD PTR [rbx+0x8]
  42204c:	mov    r8,QWORD PTR [rbx]
  42204f:	mov    edx,DWORD PTR [rip+0x108d2f]        # 52ad84 <KEEP_WORDS>
  422055:	mov    rax,QWORD PTR [rsi+0x10]
  422059:	mov    QWORD PTR [r8+rdi*8],rax
  42205d:	mov    rax,QWORD PTR [rsi+0x110]
  422064:	mov    QWORD PTR [rsi+0x10],rdi
  422068:	add    rax,0x4
  42206c:	mov    QWORD PTR [rsi+0x110],rax
  422073:	cmp    rax,rdx
  422076:	jae    4050fa <p125_rt_take3.cold+0x37>
  42207c:	pop    rbx
  42207d:	mov    eax,0x3
  422082:	pop    rbp
  422083:	pop    r12
  422085:	ret    
  422086:	nop    WORD PTR cs:[rax+rax*1+0x0]
  422090:	lea    rbp,[r9+rdi*8]
  422094:	mov    r11,QWORD PTR [rbx+0x8]
  422098:	mov    r12d,DWORD PTR [rbp+0x4]
  42209c:	mov    r10d,DWORD PTR [rbp+0x0]
  4220a0:	shl    r12,0x20
  4220a4:	or     r12,r10
  4220a7:	and    r10d,0xffffff
  4220ae:	cmp    r10,0x1
  4220b2:	je     422116 <p125_rt_take3+0x186>
  4220b4:	shr    r12,0x18
  4220b8:	xor    eax,eax
  4220ba:	lea    r8,[r9+r12*8]
  4220be:	xchg   ax,ax
  4220c0:	mov    rdx,QWORD PTR [r8+rax*1]
  4220c4:	mov    QWORD PTR [rcx+rax*1],rdx
  4220c8:	add    rax,0x8
  4220cc:	cmp    rax,0x18
  4220d0:	jne    4220c0 <p125_rt_take3+0x130>
  4220d2:	cmp    r10,0x1
  4220d6:	jne    4050c3 <p125_rt_take3.cold>
  4220dc:	mov    rax,QWORD PTR [r11]
  4220df:	mov    edx,DWORD PTR [rip+0x108c9f]        # 52ad84 <KEEP_WORDS>
  4220e5:	mov    QWORD PTR [rbp+0x0],rax
  4220e9:	mov    rax,QWORD PTR [r11+0x100]
  4220f0:	mov    QWORD PTR [r11],rdi
  4220f3:	add    rax,0x1
  4220f7:	mov    QWORD PTR [r11+0x100],rax
  4220fe:	cmp    rax,rdx
  422101:	jae    4050e8 <p125_rt_take3.cold+0x25>
  422107:	mov    r8,QWORD PTR [rip+0x108bc2]        # 52acd0 <p111_program_active>
  42210e:	mov    rdi,r12
  422111:	jmp    422022 <p125_rt_take3+0x92>
  422116:	mov    eax,DWORD PTR [rbp+0x0]
  422119:	jmp    4220b4 <p125_rt_take3+0x124>
  42211b:	lea    rdi,[rip+0x1dfe]        # 423f20 <_IO_stdin_used+0xf20>
  422122:	call   418060 <err_fail>
  422127:	nop    WORD PTR [rax+rax*1+0x0]

