function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $Str$join$go$(_xs_0, _h_0) {
  if (_xs_0.$ === "Nil") {
    return _h_0;
  } else {
    const _h2_0 = _xs_0["head"];
    const _t2_0 = _xs_0["tail"];
    const _x_0 = ($Str$join$go$(_t2_0, _h2_0));
    const _x_1 = ("," + _x_0);
    return (_h_0 + _x_1);
  }
}

function $Str$join$(_xs_0) {
  if (_xs_0.$ === "Nil") {
    return "";
  } else {
    const _h_0 = _xs_0["head"];
    const _t_0 = _xs_0["tail"];
    return $Str$join$go$(_t_0, _h_0);
  }
}

function $b2u$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $got$(_x_0, _w_0) {
  if (_x_0.$ === "None") {
    return 0;
  } else {
    const _v_0 = _x_0["value"];
    return $b2u$((_v_0 === _w_0));
  }
}

function $is_none$(_x_0) {
  if (_x_0.$ === "None") {
    return 1;
  } else {
    return 0;
  }
}

function $digits$($0, $1) {
  for (;;) {
    {
      const _vs_0 = $0;
      const _acc_0 = $1;
      if (_vs_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _h_0 = _vs_0["head"];
        const _t_0 = _vs_0["tail"];
        const _x_0 = (Math.imul(_acc_0, 10) >>> 0);
        $0 = _t_0;
        $1 = ((_x_0 + _h_0) >>> 0);
        continue;
      }
    }
  }
}

function $m3$() {
  return $Map$from_list$({$: "Con", "head": {$: "Tuple", "fst": "apple", "snd": 1}, "tail": {$: "Con", "head": {$: "Tuple", "fst": "app", "snd": 2}, "tail": {$: "Con", "head": {$: "Tuple", "fst": "banana", "snd": 3}, "tail": {$: "Nil"}}}});
}

function $chk_get$() {
  return $chk_get$s1$(($Map$get$(0, ($m3$()), "apple")));
}

function $chk_get$s4$(_a_0, _b_0, _c_0, _r_0) {
  const _hb_0 = _r_0["snd"];
  const _x_0 = ($b2u$((_a_0 === 1)));
  const _x_1 = ($b2u$((_b_0 === 2)));
  const _x_2 = ($b2u$((_c_0 === 99)));
  const _x_3 = ($b2u$(_hb_0));
  const _x_4 = (Math.imul(_x_0, _x_1) >>> 0);
  const _x_5 = (Math.imul(_x_2, _x_3) >>> 0);
  return (Math.imul(_x_4, _x_5) >>> 0);
}

function $chk_get$s3$(_a_0, _b_0, _r_0) {
  const _m3b_0 = _r_0["fst"];
  const _c_0 = _r_0["snd"];
  return $chk_get$s4$(_a_0, _b_0, _c_0, ($Map$has$(_m3b_0, "banana")));
}

function $chk_get$s2$(_a_0, _r_0) {
  const _m2_0 = _r_0["fst"];
  const _b_0 = _r_0["snd"];
  return $chk_get$s3$(_a_0, _b_0, ($Map$get$(99, _m2_0, "nope")));
}

function $chk_get$s1$(_r_0) {
  const _m1_0 = _r_0["fst"];
  const _a_0 = _r_0["snd"];
  return $chk_get$s2$(_a_0, ($Map$get$(0, _m1_0, "app")));
}

function $chk_del$() {
  return $chk_del$s1$(($Map$has$(($Map$del$(($m3$()), "app")), "app")));
}

function $chk_del$s4$(_h_0, _a_0, _pv_0, _r_0) {
  const _pv2_0 = _r_0["snd"];
  const _x_0 = ($b2u$(($Bool$not$(_h_0))));
  const _x_1 = ($b2u$((_a_0 === 1)));
  const _x_2 = ($got$(_pv_0, 3));
  const _x_3 = ($is_none$(_pv2_0));
  const _x_4 = (Math.imul(_x_0, _x_1) >>> 0);
  const _x_5 = (Math.imul(_x_2, _x_3) >>> 0);
  return (Math.imul(_x_4, _x_5) >>> 0);
}

function $chk_del$s3$(_h_0, _a_0, _r_0) {
  const _m3c_0 = _r_0["fst"];
  const _pv_0 = _r_0["snd"];
  return $chk_del$s4$(_h_0, _a_0, _pv_0, ($Map$pop$(_m3c_0, "banana")));
}

function $chk_del$s2$(_h_0, _r_0) {
  const _m2_0 = _r_0["fst"];
  const _a_0 = _r_0["snd"];
  return $chk_del$s3$(_h_0, _a_0, ($Map$pop$(_m2_0, "banana")));
}

function $chk_del$s1$(_r_0) {
  const _m1_0 = _r_0["fst"];
  const _h_0 = _r_0["snd"];
  return $chk_del$s2$(_h_0, ($Map$get$(0, _m1_0, "apple")));
}

function $chk_union$() {
  return $chk_union$s1$(($Map$get$(0, ($Map$union$(($Map$from_list$({$: "Con", "head": {$: "Tuple", "fst": "a", "snd": 1}, "tail": {$: "Con", "head": {$: "Tuple", "fst": "b", "snd": 2}, "tail": {$: "Nil"}}})), ($Map$from_list$({$: "Con", "head": {$: "Tuple", "fst": "b", "snd": 20}, "tail": {$: "Con", "head": {$: "Tuple", "fst": "c", "snd": 30}, "tail": {$: "Nil"}}})))), "a")));
}

function $chk_union$s3$(_x_0, _y_0, _r_0) {
  const _z_0 = _r_0["snd"];
  const _x_1 = ($b2u$((_x_0 === 1)));
  const _x_2 = ($b2u$((_y_0 === 20)));
  const _x_3 = (Math.imul(_x_1, _x_2) >>> 0);
  const _x_4 = ($b2u$((_z_0 === 30)));
  return (Math.imul(_x_3, _x_4) >>> 0);
}

function $chk_union$s2$(_x_0, _r_0) {
  const _u2_0 = _r_0["fst"];
  const _y_0 = _r_0["snd"];
  return $chk_union$s3$(_x_0, _y_0, ($Map$get$(0, _u2_0, "c")));
}

function $chk_union$s1$(_r_0) {
  const _u1_0 = _r_0["fst"];
  const _x_0 = _r_0["snd"];
  return $chk_union$s2$(_x_0, ($Map$get$(0, _u1_0, "b")));
}

function $chk_order$() {
  const _ks_0 = ($Str$join$(($Map$keys$(($m3$())))));
  const _x_0 = ($digits$(($Map$values$(($m3$()))), 0));
  return $b2u$(($Bool$and$(($String$eq$(_ks_0, "app,apple,banana")), (_x_0 === 213))));
}

function $chk_set$() {
  return $chk_set$s1$(($Set$has$(($Set$add$(($Set$add$(($Set$add$(($Set$new$()), "x")), "y")), "x")), "x")));
}

function $chk_set$s4$(_hx_0, _hz_0, _hy_0, _ks_0, _r_0) {
  const _hx2_0 = _r_0["snd"];
  const _x_0 = ($b2u$(_hx_0));
  const _x_1 = ($b2u$(($Bool$not$(_hz_0))));
  const _x_2 = ($b2u$(($Bool$not$(_hy_0))));
  const _x_3 = ($b2u$(_hx2_0));
  const _x_4 = ($b2u$(($String$eq$(_ks_0, "x,y"))));
  const _x_5 = (Math.imul(_x_2, _x_3) >>> 0);
  const _x_6 = (Math.imul(_x_0, _x_1) >>> 0);
  const _x_7 = (Math.imul(_x_4, _x_5) >>> 0);
  return (Math.imul(_x_6, _x_7) >>> 0);
}

function $chk_set$s3$(_hx_0, _hz_0, _ks_0, _r_0) {
  const _t1_0 = _r_0["fst"];
  const _hy_0 = _r_0["snd"];
  return $chk_set$s4$(_hx_0, _hz_0, _hy_0, _ks_0, ($Set$has$(_t1_0, "x")));
}

function $chk_set$s2$(_hx_0, _r_0) {
  const _s2_0 = _r_0["fst"];
  const _hz_0 = _r_0["snd"];
  const _ks_0 = ($Str$join$(($Set$to_list$(_s2_0))));
  return $chk_set$s3$(_hx_0, _hz_0, _ks_0, ($Set$has$(($Set$del$(($Set$add$(($Set$add$(($Set$new$()), "x")), "y")), "y")), "y")));
}

function $chk_set$s1$(_r_0) {
  const _s1_0 = _r_0["fst"];
  const _hx_0 = _r_0["snd"];
  return $chk_set$s2$(_hx_0, ($Set$has$(_s1_0, "z")));
}

function $main$out$() {
  const _x_0 = ($chk_get$());
  const _x_1 = ($chk_del$());
  const _x_2 = (Math.imul(_x_0, 10000) >>> 0);
  const _x_3 = (Math.imul(_x_1, 1000) >>> 0);
  const _x_4 = ($chk_union$());
  const _x_5 = ($chk_order$());
  const _x_6 = (Math.imul(_x_4, 100) >>> 0);
  const _x_7 = (Math.imul(_x_5, 10) >>> 0);
  const _x_8 = ((_x_6 + _x_7) >>> 0);
  const _x_9 = ($chk_set$());
  const _x_10 = ((_x_2 + _x_3) >>> 0);
  const _x_11 = ((_x_8 + _x_9) >>> 0);
  return ((_x_10 + _x_11) >>> 0);
}

function $Map$from_list$(_kvs_0) {
  return $Map$from_list$go$(_kvs_0, {$: "MTip"});
}

function $Map$get$(_d_0, _m_0, _key_0) {
  if (_m_0.$ === "MTip") {
    return {$: "Tuple", "fst": {$: "MTip"}, "snd": _d_0};
  } else if (_m_0.$ === "MLeaf") {
    const _k_0 = _m_0["key"];
    const _v_0 = _m_0["val"];
    return $Map$get$leaf$(_d_0, _v_0, ($String$cmp$(_key_0, _k_0)));
  } else {
    const _pos_0 = _m_0["pos"];
    const _lo_0 = _m_0["lo"];
    const _hi_0 = _m_0["hi"];
    return $Map$get$go$({$: "MNode", "pos": _pos_0, "lo": _lo_0, "hi": _hi_0}, _d_0, ($Map$bit$(_key_0, _pos_0)));
  }
}

function $Map$has$(_m_0, _key_0) {
  if (_m_0.$ === "MTip") {
    return {$: "Tuple", "fst": {$: "MTip"}, "snd": false};
  } else if (_m_0.$ === "MLeaf") {
    const _k_0 = _m_0["key"];
    const _v_0 = _m_0["val"];
    return $Map$has$leaf$(_v_0, ($String$cmp$(_key_0, _k_0)));
  } else {
    const _pos_0 = _m_0["pos"];
    const _lo_0 = _m_0["lo"];
    const _hi_0 = _m_0["hi"];
    return $Map$has$go$({$: "MNode", "pos": _pos_0, "lo": _lo_0, "hi": _hi_0}, ($Map$bit$(_key_0, _pos_0)));
  }
}

function $Map$del$(_m_0, _key_0) {
  return $Map$del$fin$(($Map$pop$(_m_0, _key_0)));
}

function $Bool$not$(_b_0) {
  if (!_b_0) {
    return true;
  } else {
    return false;
  }
}

function $Map$pop$(_m_0, _key_0) {
  if (_m_0.$ === "MTip") {
    return {$: "Tuple", "fst": {$: "MTip"}, "snd": {$: "None"}};
  } else if (_m_0.$ === "MLeaf") {
    const _k_0 = _m_0["key"];
    const _v_0 = _m_0["val"];
    return $Map$pop$leaf$(_v_0, ($String$cmp$(_key_0, _k_0)));
  } else {
    const _pos_0 = _m_0["pos"];
    const _lo_0 = _m_0["lo"];
    const _hi_0 = _m_0["hi"];
    return $Map$pop$go$({$: "MNode", "pos": _pos_0, "lo": _lo_0, "hi": _hi_0}, ($Map$bit$(_key_0, _pos_0)));
  }
}

function $Map$union$(_m_0, _n_0) {
  return $Map$from_list$go$(($Map$to_list$(_n_0)), _m_0);
}

function $Map$keys$(_m_0) {
  return $Map$keys$go$(_m_0, {$: "Nil"});
}

function $Bool$and$(_a_0, _b_0) {
  if (!_a_0) {
    return false;
  } else {
    return _b_0;
  }
}

function $String$eq$(_a_0, _b_0) {
  return $Cmp$is_eq$(($String$order$(_a_0, _b_0)));
}

function $Map$values$(_m_0) {
  return $Map$values$go$(_m_0, {$: "Nil"});
}

function $Set$has$(_s_0, _key_0) {
  return $Map$has$(_s_0, _key_0);
}

function $Set$add$(_s_0, _key_0) {
  return $Map$set$(_s_0, _key_0, {$: "Unit"});
}

function $Set$new$() {
  return $Map$new$();
}

function $Set$to_list$(_s_0) {
  return $Map$keys$(_s_0);
}

function $Set$del$(_s_0, _key_0) {
  return $Map$del$(_s_0, _key_0);
}

function $Map$from_list$go$($0, $1) {
  for (;;) {
    {
      const _kvs_0 = $0;
      const _m_0 = $1;
      if (_kvs_0.$ === "Nil") {
        return _m_0;
      } else {
        const _t_0 = _kvs_0["head"];
        const _k_0 = _t_0["fst"];
        const _v_0 = _t_0["snd"];
        const _t_1 = _kvs_0["tail"];
        $0 = _t_1;
        $1 = ($Map$set$(_m_0, _k_0, _v_0));
        continue;
      }
    }
  }
}

function $Map$get$leaf$(_d_0, _v_0, _r_0) {
  const _t_0 = _r_0["fst"];
  const _k2_0 = _t_0["snd"];
  const _t_1 = _r_0["snd"];
  if (_t_1.$ === "EQ") {
    return {$: "Tuple", "fst": {$: "MLeaf", "key": _k2_0, "val": _v_0}, "snd": _v_0};
  } else {
    return {$: "Tuple", "fst": {$: "MLeaf", "key": _k2_0, "val": _v_0}, "snd": _d_0};
  }
}

function $String$cmp$(_a_0, _b_0) {
  if (_a_0 === "") {
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": ""}, "snd": {$: "EQ"}};
    } else {
      const _h_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return {$: "Tuple", "fst": {$: "Tuple", "fst": "", "snd": (_h_0 + _t_0)}, "snd": {$: "LT"}};
    }
  } else {
    const _h_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_1 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h_1 + _t_1), "snd": ""}, "snd": {$: "GT"}};
    } else {
      const _h2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _t2_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $String$cmp$fin$(_t_1, _t2_0, ($Char$cmp$(_h_1, _h2_0)));
    }
  }
}

function $Map$get$go$(_node_0, _d_0, _kb_0) {
  if (_node_0.$ === "MNode") {
    const _p_0 = _node_0["pos"];
    const _t_0 = _node_0["lo"];
    if (_t_0.$ === "MTip") {
      const _t_1 = _node_0["hi"];
      if (_t_1.$ === "MTip") {
        const _t_2 = _kb_0["snd"];
        if (!_t_2) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}}, "snd": _d_0};
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}}, "snd": _d_0};
        }
      } else if (_t_1.$ === "MLeaf") {
        const _k_0 = _t_1["key"];
        const _v_0 = _t_1["val"];
        const _key2_1 = _kb_0["fst"];
        const _t_3 = _kb_0["snd"];
        if (!_t_3) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}}, "snd": _d_0};
        } else {
          return $Map$hi$(_p_0, {$: "MTip"}, ($Map$get$leaf$(_d_0, _v_0, ($String$cmp$(_key2_1, _k_0)))));
        }
      } else {
        const _q_0 = _t_1["pos"];
        const _a_0 = _t_1["lo"];
        const _b_0 = _t_1["hi"];
        const _key2_2 = _kb_0["fst"];
        const _t_4 = _kb_0["snd"];
        if (!_t_4) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MNode", "pos": _q_0, "lo": _a_0, "hi": _b_0}}, "snd": _d_0};
        } else {
          return $Map$hi$(_p_0, {$: "MTip"}, ($Map$get$go$({$: "MNode", "pos": _q_0, "lo": _a_0, "hi": _b_0}, _d_0, ($Map$bit$(_key2_2, _q_0)))));
        }
      }
    } else if (_t_0.$ === "MLeaf") {
      const _k_1 = _t_0["key"];
      const _v_1 = _t_0["val"];
      const _t_5 = _node_0["hi"];
      if (_t_5.$ === "MTip") {
        const _key2_3 = _kb_0["fst"];
        const _t_6 = _kb_0["snd"];
        if (!_t_6) {
          return $Map$lo$(_p_0, {$: "MTip"}, ($Map$get$leaf$(_d_0, _v_1, ($String$cmp$(_key2_3, _k_1)))));
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MTip"}}, "snd": _d_0};
        }
      } else if (_t_5.$ === "MLeaf") {
        const _k_2 = _t_5["key"];
        const _v_2 = _t_5["val"];
        const _key2_4 = _kb_0["fst"];
        const _t_7 = _kb_0["snd"];
        if (!_t_7) {
          return $Map$lo$(_p_0, {$: "MLeaf", "key": _k_2, "val": _v_2}, ($Map$get$leaf$(_d_0, _v_1, ($String$cmp$(_key2_4, _k_1)))));
        } else {
          return $Map$hi$(_p_0, {$: "MLeaf", "key": _k_1, "val": _v_1}, ($Map$get$leaf$(_d_0, _v_2, ($String$cmp$(_key2_4, _k_2)))));
        }
      } else {
        const _q_1 = _t_5["pos"];
        const _a_1 = _t_5["lo"];
        const _b_1 = _t_5["hi"];
        const _key2_5 = _kb_0["fst"];
        const _t_8 = _kb_0["snd"];
        if (!_t_8) {
          return $Map$lo$(_p_0, {$: "MNode", "pos": _q_1, "lo": _a_1, "hi": _b_1}, ($Map$get$leaf$(_d_0, _v_1, ($String$cmp$(_key2_5, _k_1)))));
        } else {
          return $Map$hi$(_p_0, {$: "MLeaf", "key": _k_1, "val": _v_1}, ($Map$get$go$({$: "MNode", "pos": _q_1, "lo": _a_1, "hi": _b_1}, _d_0, ($Map$bit$(_key2_5, _q_1)))));
        }
      }
    } else {
      const _q_2 = _t_0["pos"];
      const _a_2 = _t_0["lo"];
      const _b_2 = _t_0["hi"];
      const _t_9 = _node_0["hi"];
      if (_t_9.$ === "MTip") {
        const _key2_6 = _kb_0["fst"];
        const _t_10 = _kb_0["snd"];
        if (!_t_10) {
          return $Map$lo$(_p_0, {$: "MTip"}, ($Map$get$go$({$: "MNode", "pos": _q_2, "lo": _a_2, "hi": _b_2}, _d_0, ($Map$bit$(_key2_6, _q_2)))));
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MNode", "pos": _q_2, "lo": _a_2, "hi": _b_2}, "hi": {$: "MTip"}}, "snd": _d_0};
        }
      } else if (_t_9.$ === "MLeaf") {
        const _k_3 = _t_9["key"];
        const _v_3 = _t_9["val"];
        const _key2_7 = _kb_0["fst"];
        const _t_11 = _kb_0["snd"];
        if (!_t_11) {
          return $Map$lo$(_p_0, {$: "MLeaf", "key": _k_3, "val": _v_3}, ($Map$get$go$({$: "MNode", "pos": _q_2, "lo": _a_2, "hi": _b_2}, _d_0, ($Map$bit$(_key2_7, _q_2)))));
        } else {
          return $Map$hi$(_p_0, {$: "MNode", "pos": _q_2, "lo": _a_2, "hi": _b_2}, ($Map$get$leaf$(_d_0, _v_3, ($String$cmp$(_key2_7, _k_3)))));
        }
      } else {
        const _q_3 = _t_9["pos"];
        const _a_3 = _t_9["lo"];
        const _b_3 = _t_9["hi"];
        const _key2_8 = _kb_0["fst"];
        const _t_12 = _kb_0["snd"];
        if (!_t_12) {
          return $Map$lo$(_p_0, {$: "MNode", "pos": _q_3, "lo": _a_3, "hi": _b_3}, ($Map$get$go$({$: "MNode", "pos": _q_2, "lo": _a_2, "hi": _b_2}, _d_0, ($Map$bit$(_key2_8, _q_2)))));
        } else {
          return $Map$hi$(_p_0, {$: "MNode", "pos": _q_2, "lo": _a_2, "hi": _b_2}, ($Map$get$go$({$: "MNode", "pos": _q_3, "lo": _a_3, "hi": _b_3}, _d_0, ($Map$bit$(_key2_8, _q_3)))));
        }
      }
    }
  } else {
    return {$: "Tuple", "fst": _node_0, "snd": _d_0};
  }
}

function $Map$bit$(_key_0, _pos_0) {
  return $Map$bit$at$(_key_0, nat_divmod(_pos_0, 33));
}

function $Map$has$leaf$(_v_0, _r_0) {
  const _t_0 = _r_0["fst"];
  const _k2_0 = _t_0["snd"];
  const _c_0 = _r_0["snd"];
  return {$: "Tuple", "fst": {$: "MLeaf", "key": _k2_0, "val": _v_0}, "snd": ($Cmp$is_eq$(_c_0))};
}

function $Map$has$go$(_node_0, _kb_0) {
  if (_node_0.$ === "MNode") {
    const _p_0 = _node_0["pos"];
    const _t_0 = _node_0["lo"];
    if (_t_0.$ === "MTip") {
      const _t_1 = _node_0["hi"];
      if (_t_1.$ === "MTip") {
        const _t_2 = _kb_0["snd"];
        if (!_t_2) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}}, "snd": false};
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}}, "snd": false};
        }
      } else if (_t_1.$ === "MLeaf") {
        const _k_0 = _t_1["key"];
        const _v_0 = _t_1["val"];
        const _key_1 = _kb_0["fst"];
        const _t_3 = _kb_0["snd"];
        if (!_t_3) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}}, "snd": false};
        } else {
          return $Map$hi$(_p_0, {$: "MTip"}, ($Map$has$leaf$(_v_0, ($String$cmp$(_key_1, _k_0)))));
        }
      } else {
        const _q_0 = _t_1["pos"];
        const _c_0 = _t_1["lo"];
        const _d_0 = _t_1["hi"];
        const _key_2 = _kb_0["fst"];
        const _t_4 = _kb_0["snd"];
        if (!_t_4) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}}, "snd": false};
        } else {
          return $Map$hi$(_p_0, {$: "MTip"}, ($Map$has$go$({$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}, ($Map$bit$(_key_2, _q_0)))));
        }
      }
    } else if (_t_0.$ === "MLeaf") {
      const _k_1 = _t_0["key"];
      const _v_1 = _t_0["val"];
      const _t_5 = _node_0["hi"];
      if (_t_5.$ === "MTip") {
        const _key_3 = _kb_0["fst"];
        const _t_6 = _kb_0["snd"];
        if (!_t_6) {
          return $Map$lo$(_p_0, {$: "MTip"}, ($Map$has$leaf$(_v_1, ($String$cmp$(_key_3, _k_1)))));
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MTip"}}, "snd": false};
        }
      } else if (_t_5.$ === "MLeaf") {
        const _k_2 = _t_5["key"];
        const _v_2 = _t_5["val"];
        const _key_4 = _kb_0["fst"];
        const _t_7 = _kb_0["snd"];
        if (!_t_7) {
          return $Map$lo$(_p_0, {$: "MLeaf", "key": _k_2, "val": _v_2}, ($Map$has$leaf$(_v_1, ($String$cmp$(_key_4, _k_1)))));
        } else {
          return $Map$hi$(_p_0, {$: "MLeaf", "key": _k_1, "val": _v_1}, ($Map$has$leaf$(_v_2, ($String$cmp$(_key_4, _k_2)))));
        }
      } else {
        const _q_1 = _t_5["pos"];
        const _c_1 = _t_5["lo"];
        const _d_1 = _t_5["hi"];
        const _key_5 = _kb_0["fst"];
        const _t_8 = _kb_0["snd"];
        if (!_t_8) {
          return $Map$lo$(_p_0, {$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}, ($Map$has$leaf$(_v_1, ($String$cmp$(_key_5, _k_1)))));
        } else {
          return $Map$hi$(_p_0, {$: "MLeaf", "key": _k_1, "val": _v_1}, ($Map$has$go$({$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}, ($Map$bit$(_key_5, _q_1)))));
        }
      }
    } else {
      const _q_2 = _t_0["pos"];
      const _c_2 = _t_0["lo"];
      const _d_2 = _t_0["hi"];
      const _t_9 = _node_0["hi"];
      if (_t_9.$ === "MTip") {
        const _key_6 = _kb_0["fst"];
        const _t_10 = _kb_0["snd"];
        if (!_t_10) {
          return $Map$lo$(_p_0, {$: "MTip"}, ($Map$has$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_6, _q_2)))));
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MTip"}}, "snd": false};
        }
      } else if (_t_9.$ === "MLeaf") {
        const _k_3 = _t_9["key"];
        const _v_3 = _t_9["val"];
        const _key_7 = _kb_0["fst"];
        const _t_11 = _kb_0["snd"];
        if (!_t_11) {
          return $Map$lo$(_p_0, {$: "MLeaf", "key": _k_3, "val": _v_3}, ($Map$has$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_7, _q_2)))));
        } else {
          return $Map$hi$(_p_0, {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$has$leaf$(_v_3, ($String$cmp$(_key_7, _k_3)))));
        }
      } else {
        const _q_3 = _t_9["pos"];
        const _c_3 = _t_9["lo"];
        const _d_3 = _t_9["hi"];
        const _key_8 = _kb_0["fst"];
        const _t_12 = _kb_0["snd"];
        if (!_t_12) {
          return $Map$lo$(_p_0, {$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}, ($Map$has$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_8, _q_2)))));
        } else {
          return $Map$hi$(_p_0, {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$has$go$({$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}, ($Map$bit$(_key_8, _q_3)))));
        }
      }
    }
  } else {
    return {$: "Tuple", "fst": _node_0, "snd": false};
  }
}

function $Map$del$fin$(_r_0) {
  const _m2_0 = _r_0["fst"];
  return _m2_0;
}

function $Map$pop$leaf$(_v_0, _r_0) {
  const _t_0 = _r_0["fst"];
  const _k2_0 = _t_0["snd"];
  const _t_1 = _r_0["snd"];
  if (_t_1.$ === "EQ") {
    return {$: "Tuple", "fst": {$: "MTip"}, "snd": {$: "Some", "value": _v_0}};
  } else {
    return {$: "Tuple", "fst": {$: "MLeaf", "key": _k2_0, "val": _v_0}, "snd": {$: "None"}};
  }
}

function $Map$pop$go$(_node_0, _kb_0) {
  if (_node_0.$ === "MNode") {
    const _p_0 = _node_0["pos"];
    const _t_0 = _node_0["lo"];
    if (_t_0.$ === "MTip") {
      const _t_1 = _node_0["hi"];
      if (_t_1.$ === "MTip") {
        const _t_2 = _kb_0["snd"];
        if (!_t_2) {
          return {$: "Tuple", "fst": {$: "MTip"}, "snd": {$: "None"}};
        } else {
          return {$: "Tuple", "fst": {$: "MTip"}, "snd": {$: "None"}};
        }
      } else if (_t_1.$ === "MLeaf") {
        const _k_0 = _t_1["key"];
        const _v_0 = _t_1["val"];
        const _key_1 = _kb_0["fst"];
        const _t_3 = _kb_0["snd"];
        if (!_t_3) {
          return {$: "Tuple", "fst": {$: "MLeaf", "key": _k_0, "val": _v_0}, "snd": {$: "None"}};
        } else {
          return $Map$pop$hi$(_p_0, {$: "MTip"}, ($Map$pop$leaf$(_v_0, ($String$cmp$(_key_1, _k_0)))));
        }
      } else {
        const _q_0 = _t_1["pos"];
        const _c_0 = _t_1["lo"];
        const _d_0 = _t_1["hi"];
        const _key_2 = _kb_0["fst"];
        const _t_4 = _kb_0["snd"];
        if (!_t_4) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}, "snd": {$: "None"}};
        } else {
          return $Map$pop$hi$(_p_0, {$: "MTip"}, ($Map$pop$go$({$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}, ($Map$bit$(_key_2, _q_0)))));
        }
      }
    } else if (_t_0.$ === "MLeaf") {
      const _k_1 = _t_0["key"];
      const _v_1 = _t_0["val"];
      const _t_5 = _node_0["hi"];
      if (_t_5.$ === "MTip") {
        const _key_3 = _kb_0["fst"];
        const _t_6 = _kb_0["snd"];
        if (!_t_6) {
          return $Map$pop$lo$(_p_0, {$: "MTip"}, ($Map$pop$leaf$(_v_1, ($String$cmp$(_key_3, _k_1)))));
        } else {
          return {$: "Tuple", "fst": {$: "MLeaf", "key": _k_1, "val": _v_1}, "snd": {$: "None"}};
        }
      } else if (_t_5.$ === "MLeaf") {
        const _k_2 = _t_5["key"];
        const _v_2 = _t_5["val"];
        const _key_4 = _kb_0["fst"];
        const _t_7 = _kb_0["snd"];
        if (!_t_7) {
          return $Map$pop$lo$(_p_0, {$: "MLeaf", "key": _k_2, "val": _v_2}, ($Map$pop$leaf$(_v_1, ($String$cmp$(_key_4, _k_1)))));
        } else {
          return $Map$pop$hi$(_p_0, {$: "MLeaf", "key": _k_1, "val": _v_1}, ($Map$pop$leaf$(_v_2, ($String$cmp$(_key_4, _k_2)))));
        }
      } else {
        const _q_1 = _t_5["pos"];
        const _c_1 = _t_5["lo"];
        const _d_1 = _t_5["hi"];
        const _key_5 = _kb_0["fst"];
        const _t_8 = _kb_0["snd"];
        if (!_t_8) {
          return $Map$pop$lo$(_p_0, {$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}, ($Map$pop$leaf$(_v_1, ($String$cmp$(_key_5, _k_1)))));
        } else {
          return $Map$pop$hi$(_p_0, {$: "MLeaf", "key": _k_1, "val": _v_1}, ($Map$pop$go$({$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}, ($Map$bit$(_key_5, _q_1)))));
        }
      }
    } else {
      const _q_2 = _t_0["pos"];
      const _c_2 = _t_0["lo"];
      const _d_2 = _t_0["hi"];
      const _t_9 = _node_0["hi"];
      if (_t_9.$ === "MTip") {
        const _key_6 = _kb_0["fst"];
        const _t_10 = _kb_0["snd"];
        if (!_t_10) {
          return $Map$pop$lo$(_p_0, {$: "MTip"}, ($Map$pop$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_6, _q_2)))));
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, "snd": {$: "None"}};
        }
      } else if (_t_9.$ === "MLeaf") {
        const _k_3 = _t_9["key"];
        const _v_3 = _t_9["val"];
        const _key_7 = _kb_0["fst"];
        const _t_11 = _kb_0["snd"];
        if (!_t_11) {
          return $Map$pop$lo$(_p_0, {$: "MLeaf", "key": _k_3, "val": _v_3}, ($Map$pop$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_7, _q_2)))));
        } else {
          return $Map$pop$hi$(_p_0, {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$pop$leaf$(_v_3, ($String$cmp$(_key_7, _k_3)))));
        }
      } else {
        const _q_3 = _t_9["pos"];
        const _c_3 = _t_9["lo"];
        const _d_3 = _t_9["hi"];
        const _key_8 = _kb_0["fst"];
        const _t_12 = _kb_0["snd"];
        if (!_t_12) {
          return $Map$pop$lo$(_p_0, {$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}, ($Map$pop$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_8, _q_2)))));
        } else {
          return $Map$pop$hi$(_p_0, {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$pop$go$({$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}, ($Map$bit$(_key_8, _q_3)))));
        }
      }
    }
  } else {
    return {$: "Tuple", "fst": _node_0, "snd": {$: "None"}};
  }
}

function $Map$to_list$(_m_0) {
  return $Map$to_list$go$(_m_0, {$: "Nil"});
}

function $Map$keys$go$($0, $1) {
  for (;;) {
    {
      const _m_0 = $0;
      const _acc_0 = $1;
      if (_m_0.$ === "MTip") {
        return _acc_0;
      } else if (_m_0.$ === "MLeaf") {
        const _k_0 = _m_0["key"];
        return {$: "Con", "head": _k_0, "tail": _acc_0};
      } else {
        const _lo_0 = _m_0["lo"];
        const _hi_0 = _m_0["hi"];
        $0 = _lo_0;
        $1 = ($Map$keys$go$(_hi_0, _acc_0));
        continue;
      }
    }
  }
}

function $Cmp$is_eq$(_c_0) {
  if (_c_0.$ === "EQ") {
    return true;
  } else {
    return false;
  }
}

function $String$order$(_a_0, _b_0) {
  return $Pair$snd$(($String$cmp$(_a_0, _b_0)));
}

function $Map$values$go$($0, $1) {
  for (;;) {
    {
      const _m_0 = $0;
      const _acc_0 = $1;
      if (_m_0.$ === "MTip") {
        return _acc_0;
      } else if (_m_0.$ === "MLeaf") {
        const _v_0 = _m_0["val"];
        return {$: "Con", "head": _v_0, "tail": _acc_0};
      } else {
        const _lo_0 = _m_0["lo"];
        const _hi_0 = _m_0["hi"];
        $0 = _lo_0;
        $1 = ($Map$values$go$(_hi_0, _acc_0));
        continue;
      }
    }
  }
}

function $Map$set$(_m_0, _key_0, _x_0) {
  return $Map$set$go$(_x_0, ($Map$seek$(_m_0, _key_0)));
}

function $Map$new$() {
  return {$: "MTip"};
}

function $String$cmp$fin$(_t1_0, _t2_0, _hc_0) {
  const _t_0 = _hc_0["fst"];
  const _h1b_0 = _t_0["fst"];
  const _h2b_0 = _t_0["snd"];
  const _t_1 = _hc_0["snd"];
  if (_t_1.$ === "LT") {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "LT"}};
  } else if (_t_1.$ === "EQ") {
    return $String$cmp$rec$(_h1b_0, _h2b_0, ($String$cmp$(_t1_0, _t2_0)));
  } else {
    return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1_0), "snd": (_h2b_0 + _t2_0)}, "snd": {$: "GT"}};
  }
}

function $Char$cmp$(_a_0, _b_0) {
  const _x_0 = _a_0.codePointAt(0);
  const _x_1 = _b_0.codePointAt(0);
  return {$: "Tuple", "fst": {$: "Tuple", "fst": _a_0, "snd": _b_0}, "snd": cmp_new(_x_0, _x_1)};
}

function $Map$hi$(_p2_0, _lo_0, _r0_0) {
  const _hi2_0 = _r0_0["fst"];
  const _r_0 = _r0_0["snd"];
  return {$: "Tuple", "fst": {$: "MNode", "pos": _p2_0, "lo": _lo_0, "hi": _hi2_0}, "snd": _r_0};
}

function $Map$lo$(_p2_0, _hi_0, _r0_0) {
  const _lo2_0 = _r0_0["fst"];
  const _r_0 = _r0_0["snd"];
  return {$: "Tuple", "fst": {$: "MNode", "pos": _p2_0, "lo": _lo2_0, "hi": _hi_0}, "snd": _r_0};
}

function $Map$bit$at$(_key_0, _co_0) {
  const _ci_0 = _co_0["fst"];
  const _off_0 = _co_0["snd"];
  return $Map$bit$go$(_key_0, _ci_0, _off_0);
}

function $Map$pop$hi$(_pos_0, _lo_0, _r0_0) {
  const _t_0 = _r0_0["fst"];
  if (_t_0.$ === "MTip") {
    const _r_0 = _r0_0["snd"];
    return {$: "Tuple", "fst": _lo_0, "snd": _r_0};
  } else {
    const _r_1 = _r0_0["snd"];
    return {$: "Tuple", "fst": {$: "MNode", "pos": _pos_0, "lo": _lo_0, "hi": _t_0}, "snd": _r_1};
  }
}

function $Map$pop$lo$(_pos_0, _hi_0, _r0_0) {
  const _t_0 = _r0_0["fst"];
  if (_t_0.$ === "MTip") {
    const _r_0 = _r0_0["snd"];
    return {$: "Tuple", "fst": _hi_0, "snd": _r_0};
  } else {
    const _r_1 = _r0_0["snd"];
    return {$: "Tuple", "fst": {$: "MNode", "pos": _pos_0, "lo": _t_0, "hi": _hi_0}, "snd": _r_1};
  }
}

function $Map$to_list$go$($0, $1) {
  for (;;) {
    {
      const _m_0 = $0;
      const _acc_0 = $1;
      if (_m_0.$ === "MTip") {
        return _acc_0;
      } else if (_m_0.$ === "MLeaf") {
        const _k_0 = _m_0["key"];
        const _v_0 = _m_0["val"];
        return {$: "Con", "head": {$: "Tuple", "fst": _k_0, "snd": _v_0}, "tail": _acc_0};
      } else {
        const _lo_0 = _m_0["lo"];
        const _hi_0 = _m_0["hi"];
        $0 = _lo_0;
        $1 = ($Map$to_list$go$(_hi_0, _acc_0));
        continue;
      }
    }
  }
}

function $Pair$snd$(_p_0) {
  const _b_0 = _p_0["snd"];
  return _b_0;
}

function $Map$set$go$(_x_0, _r_0) {
  const _m2_0 = _r_0["fst"];
  const _t_0 = _r_0["snd"];
  const _key2_0 = _t_0["fst"];
  const _t_1 = _t_0["snd"];
  if (_t_1.$ === "None") {
    return {$: "MLeaf", "key": _key2_0, "val": _x_0};
  } else {
    const _k_0 = _t_1["value"];
    const _ka_0 = _key2_0;
    return $Map$set$fin$(_m2_0, _ka_0, _x_0, _ka_0, _k_0);
  }
}

function $Map$seek$(_m_0, _key_0) {
  if (_m_0.$ === "MTip") {
    return {$: "Tuple", "fst": {$: "MTip"}, "snd": {$: "Tuple", "fst": _key_0, "snd": {$: "None"}}};
  } else if (_m_0.$ === "MLeaf") {
    const _k_0 = _m_0["key"];
    const _v_0 = _m_0["val"];
    return {$: "Tuple", "fst": {$: "MLeaf", "key": _k_0, "val": _v_0}, "snd": {$: "Tuple", "fst": _key_0, "snd": {$: "Some", "value": _k_0}}};
  } else {
    const _pos_0 = _m_0["pos"];
    const _lo_0 = _m_0["lo"];
    const _hi_0 = _m_0["hi"];
    return $Map$seek$go$({$: "MNode", "pos": _pos_0, "lo": _lo_0, "hi": _hi_0}, ($Map$bit$(_key_0, _pos_0)));
  }
}

function $String$cmp$rec$(_h1b_0, _h2b_0, _rr_0) {
  const _t_0 = _rr_0["fst"];
  const _t1b_0 = _t_0["fst"];
  const _t2b_0 = _t_0["snd"];
  const _r_0 = _rr_0["snd"];
  return {$: "Tuple", "fst": {$: "Tuple", "fst": (_h1b_0 + _t1b_0), "snd": (_h2b_0 + _t2b_0)}, "snd": _r_0};
}

function $Map$bit$go$(_key_0, _ci_0, _off_0) {
  if (_key_0 === "") {
    return {$: "Tuple", "fst": "", "snd": false};
  } else {
    const _c_0 = (_key_0.codePointAt(0) > 0xFFFF ? _key_0.slice(0, 2) : _key_0[0]);
    const _t_0 = (_key_0.codePointAt(0) > 0xFFFF ? _key_0.slice(2) : _key_0.slice(1));
    if (_ci_0 === 0) {
      return $Map$bit$go$chr$(_t_0, ($Map$bit$chr$(_c_0, _off_0)));
    } else {
      const _j_0 = (_ci_0 - 1);
      return $Map$bit$go$rec$(_c_0, ($Map$bit$go$(_t_0, _j_0, _off_0)));
    }
  }
}

function $Map$set$fin$(_m_0, _key_0, _x_0, _keyb_0, _k_0) {
  return $Map$set$fin$go$(_m_0, _key_0, _x_0, ($String$cmp$(_keyb_0, _k_0)));
}

function $Map$seek$go$(_node_0, _kb_0) {
  if (_node_0.$ === "MNode") {
    const _p_0 = _node_0["pos"];
    const _t_0 = _node_0["lo"];
    if (_t_0.$ === "MTip") {
      const _t_1 = _node_0["hi"];
      if (_t_1.$ === "MTip") {
        const _key_0 = _kb_0["fst"];
        const _t_2 = _kb_0["snd"];
        if (!_t_2) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}}, "snd": {$: "Tuple", "fst": _key_0, "snd": {$: "None"}}};
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}}, "snd": {$: "Tuple", "fst": _key_0, "snd": {$: "None"}}};
        }
      } else if (_t_1.$ === "MLeaf") {
        const _k_0 = _t_1["key"];
        const _v_0 = _t_1["val"];
        const _key_1 = _kb_0["fst"];
        const _t_3 = _kb_0["snd"];
        if (!_t_3) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}}, "snd": {$: "Tuple", "fst": _key_1, "snd": {$: "None"}}};
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}}, "snd": {$: "Tuple", "fst": _key_1, "snd": {$: "Some", "value": _k_0}}};
        }
      } else {
        const _q_0 = _t_1["pos"];
        const _c_0 = _t_1["lo"];
        const _d_0 = _t_1["hi"];
        const _key_2 = _kb_0["fst"];
        const _t_4 = _kb_0["snd"];
        if (!_t_4) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}}, "snd": {$: "Tuple", "fst": _key_2, "snd": {$: "None"}}};
        } else {
          return $Map$hi$(_p_0, {$: "MTip"}, ($Map$seek$go$({$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}, ($Map$bit$(_key_2, _q_0)))));
        }
      }
    } else if (_t_0.$ === "MLeaf") {
      const _k_1 = _t_0["key"];
      const _v_1 = _t_0["val"];
      const _t_5 = _node_0["hi"];
      if (_t_5.$ === "MTip") {
        const _key_3 = _kb_0["fst"];
        const _t_6 = _kb_0["snd"];
        if (!_t_6) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MTip"}}, "snd": {$: "Tuple", "fst": _key_3, "snd": {$: "Some", "value": _k_1}}};
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MTip"}}, "snd": {$: "Tuple", "fst": _key_3, "snd": {$: "None"}}};
        }
      } else if (_t_5.$ === "MLeaf") {
        const _k_2 = _t_5["key"];
        const _v_2 = _t_5["val"];
        const _key_4 = _kb_0["fst"];
        const _t_7 = _kb_0["snd"];
        if (!_t_7) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MLeaf", "key": _k_2, "val": _v_2}}, "snd": {$: "Tuple", "fst": _key_4, "snd": {$: "Some", "value": _k_1}}};
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MLeaf", "key": _k_2, "val": _v_2}}, "snd": {$: "Tuple", "fst": _key_4, "snd": {$: "Some", "value": _k_2}}};
        }
      } else {
        const _q_1 = _t_5["pos"];
        const _c_1 = _t_5["lo"];
        const _d_1 = _t_5["hi"];
        const _key_5 = _kb_0["fst"];
        const _t_8 = _kb_0["snd"];
        if (!_t_8) {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}}, "snd": {$: "Tuple", "fst": _key_5, "snd": {$: "Some", "value": _k_1}}};
        } else {
          return $Map$hi$(_p_0, {$: "MLeaf", "key": _k_1, "val": _v_1}, ($Map$seek$go$({$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}, ($Map$bit$(_key_5, _q_1)))));
        }
      }
    } else {
      const _q_2 = _t_0["pos"];
      const _c_2 = _t_0["lo"];
      const _d_2 = _t_0["hi"];
      const _t_9 = _node_0["hi"];
      if (_t_9.$ === "MTip") {
        const _key_6 = _kb_0["fst"];
        const _t_10 = _kb_0["snd"];
        if (!_t_10) {
          return $Map$lo$(_p_0, {$: "MTip"}, ($Map$seek$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_6, _q_2)))));
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MTip"}}, "snd": {$: "Tuple", "fst": _key_6, "snd": {$: "None"}}};
        }
      } else if (_t_9.$ === "MLeaf") {
        const _k_3 = _t_9["key"];
        const _v_3 = _t_9["val"];
        const _key_7 = _kb_0["fst"];
        const _t_11 = _kb_0["snd"];
        if (!_t_11) {
          return $Map$lo$(_p_0, {$: "MLeaf", "key": _k_3, "val": _v_3}, ($Map$seek$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_7, _q_2)))));
        } else {
          return {$: "Tuple", "fst": {$: "MNode", "pos": _p_0, "lo": {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MLeaf", "key": _k_3, "val": _v_3}}, "snd": {$: "Tuple", "fst": _key_7, "snd": {$: "Some", "value": _k_3}}};
        }
      } else {
        const _q_3 = _t_9["pos"];
        const _c_3 = _t_9["lo"];
        const _d_3 = _t_9["hi"];
        const _key_8 = _kb_0["fst"];
        const _t_12 = _kb_0["snd"];
        if (!_t_12) {
          return $Map$lo$(_p_0, {$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}, ($Map$seek$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$bit$(_key_8, _q_2)))));
        } else {
          return $Map$hi$(_p_0, {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, ($Map$seek$go$({$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}, ($Map$bit$(_key_8, _q_3)))));
        }
      }
    }
  } else {
    const _key_9 = _kb_0["fst"];
    return {$: "Tuple", "fst": _node_0, "snd": {$: "Tuple", "fst": _key_9, "snd": {$: "None"}}};
  }
}

function $Map$bit$go$chr$(_t_0, _r_0) {
  const _c2_0 = _r_0["fst"];
  const _b_0 = _r_0["snd"];
  return {$: "Tuple", "fst": (_c2_0 + _t_0), "snd": _b_0};
}

function $Map$bit$chr$(_c_0, _off_0) {
  if (_off_0 === 0) {
    return {$: "Tuple", "fst": _c_0, "snd": true};
  } else {
    const _b_0 = (_off_0 - 1);
    return {$: "Tuple", "fst": _c_0, "snd": ($Map$bit$u$(_c_0.codePointAt(0), (31 < _b_0 ? 0 : 31 - _b_0)))};
  }
}

function $Map$bit$go$rec$(_c_0, _r_0) {
  const _t2_0 = _r_0["fst"];
  const _b_0 = _r_0["snd"];
  return {$: "Tuple", "fst": (_c_0 + _t2_0), "snd": _b_0};
}

function $Map$set$fin$go$(_m_0, _key_0, _x_0, _r_0) {
  const _t_0 = _r_0["fst"];
  const _keyb2_0 = _t_0["fst"];
  const _k2_0 = _t_0["snd"];
  const _t_1 = _r_0["snd"];
  if (_t_1.$ === "EQ") {
    return $Map$put$(_m_0, _key_0, _x_0);
  } else {
    return $Map$ins$(_m_0, _key_0, _x_0, ($Map$diff$(_keyb2_0, _k2_0)));
  }
}

function $Map$bit$u$(_x_0, _k_0) {
  const _x_1 = (_k_0 >= 32 ? 0 : (_x_0 >>> _k_0) >>> 0);
  const _x_2 = ((_x_1 & 1) >>> 0);
  return (_x_2 !== 0);
}

function $Map$put$(_m_0, _key_0, _x_0) {
  if (_m_0.$ === "MTip") {
    return {$: "MLeaf", "key": _key_0, "val": _x_0};
  } else if (_m_0.$ === "MLeaf") {
    const _k_0 = _m_0["key"];
    return {$: "MLeaf", "key": _k_0, "val": _x_0};
  } else {
    const _pos_0 = _m_0["pos"];
    const _lo_0 = _m_0["lo"];
    const _hi_0 = _m_0["hi"];
    return $Map$put$go$({$: "MNode", "pos": _pos_0, "lo": _lo_0, "hi": _hi_0}, _x_0, ($Map$bit$(_key_0, _pos_0)));
  }
}

function $Map$ins$(_m_0, _key_0, _x_0, _p_0) {
  if (_m_0.$ === "MTip") {
    return {$: "MLeaf", "key": _key_0, "val": _x_0};
  } else if (_m_0.$ === "MLeaf") {
    const _k_0 = _m_0["key"];
    const _v_0 = _m_0["val"];
    return $Map$ins$splice$(_p_0, _key_0, _x_0, {$: "MLeaf", "key": _k_0, "val": _v_0});
  } else {
    const _pos_0 = _m_0["pos"];
    const _lo_0 = _m_0["lo"];
    const _hi_0 = _m_0["hi"];
    return $Map$ins$go$({$: "MNode", "pos": _pos_0, "lo": _lo_0, "hi": _hi_0}, _x_0, _p_0, ($Map$bit$(_key_0, _pos_0)), (_pos_0 < _p_0));
  }
}

function $Map$diff$(_a_0, _b_0) {
  if (_a_0 === "") {
    return 0;
  } else {
    const _h_0 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(0, 2) : _a_0[0]);
    const _t_0 = (_a_0.codePointAt(0) > 0xFFFF ? _a_0.slice(2) : _a_0.slice(1));
    if (_b_0 === "") {
      return 0;
    } else {
      const _y_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(0, 2) : _b_0[0]);
      const _yt_0 = (_b_0.codePointAt(0) > 0xFFFF ? _b_0.slice(2) : _b_0.slice(1));
      return $Map$diff$fin$(_t_0, _yt_0, ($Map$diff$step$(_h_0, _y_0)));
    }
  }
}

function $Map$put$go$(_node_0, _x_0, _kb_0) {
  if (_node_0.$ === "MNode") {
    const _p_0 = _node_0["pos"];
    const _t_0 = _node_0["lo"];
    if (_t_0.$ === "MTip") {
      const _t_1 = _node_0["hi"];
      if (_t_1.$ === "MTip") {
        const _key_0 = _kb_0["fst"];
        const _t_2 = _kb_0["snd"];
        if (!_t_2) {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _key_0, "val": _x_0}, "hi": {$: "MTip"}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _key_0, "val": _x_0}};
        }
      } else if (_t_1.$ === "MLeaf") {
        const _k_0 = _t_1["key"];
        const _v_0 = _t_1["val"];
        const _key_1 = _kb_0["fst"];
        const _t_3 = _kb_0["snd"];
        if (!_t_3) {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _key_1, "val": _x_0}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _k_0, "val": _x_0}};
        }
      } else {
        const _q_0 = _t_1["pos"];
        const _c_0 = _t_1["lo"];
        const _d_0 = _t_1["hi"];
        const _key_2 = _kb_0["fst"];
        const _t_4 = _kb_0["snd"];
        if (!_t_4) {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _key_2, "val": _x_0}, "hi": {$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MTip"}, "hi": ($Map$put$go$({$: "MNode", "pos": _q_0, "lo": _c_0, "hi": _d_0}, _x_0, ($Map$bit$(_key_2, _q_0))))};
        }
      }
    } else if (_t_0.$ === "MLeaf") {
      const _k_1 = _t_0["key"];
      const _v_1 = _t_0["val"];
      const _t_5 = _node_0["hi"];
      if (_t_5.$ === "MTip") {
        const _key_3 = _kb_0["fst"];
        const _t_6 = _kb_0["snd"];
        if (!_t_6) {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _x_0}, "hi": {$: "MTip"}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MLeaf", "key": _key_3, "val": _x_0}};
        }
      } else if (_t_5.$ === "MLeaf") {
        const _k_2 = _t_5["key"];
        const _v_2 = _t_5["val"];
        const _t_7 = _kb_0["snd"];
        if (!_t_7) {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _x_0}, "hi": {$: "MLeaf", "key": _k_2, "val": _v_2}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MLeaf", "key": _k_2, "val": _x_0}};
        }
      } else {
        const _q_1 = _t_5["pos"];
        const _c_1 = _t_5["lo"];
        const _d_1 = _t_5["hi"];
        const _key_5 = _kb_0["fst"];
        const _t_8 = _kb_0["snd"];
        if (!_t_8) {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _x_0}, "hi": {$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": ($Map$put$go$({$: "MNode", "pos": _q_1, "lo": _c_1, "hi": _d_1}, _x_0, ($Map$bit$(_key_5, _q_1))))};
        }
      }
    } else {
      const _q_2 = _t_0["pos"];
      const _c_2 = _t_0["lo"];
      const _d_2 = _t_0["hi"];
      const _t_9 = _node_0["hi"];
      if (_t_9.$ === "MTip") {
        const _key_6 = _kb_0["fst"];
        const _t_10 = _kb_0["snd"];
        if (!_t_10) {
          return {$: "MNode", "pos": _p_0, "lo": ($Map$put$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, _x_0, ($Map$bit$(_key_6, _q_2)))), "hi": {$: "MTip"}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MLeaf", "key": _key_6, "val": _x_0}};
        }
      } else if (_t_9.$ === "MLeaf") {
        const _k_3 = _t_9["key"];
        const _v_3 = _t_9["val"];
        const _key_7 = _kb_0["fst"];
        const _t_11 = _kb_0["snd"];
        if (!_t_11) {
          return {$: "MNode", "pos": _p_0, "lo": ($Map$put$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, _x_0, ($Map$bit$(_key_7, _q_2)))), "hi": {$: "MLeaf", "key": _k_3, "val": _v_3}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MLeaf", "key": _k_3, "val": _x_0}};
        }
      } else {
        const _q_3 = _t_9["pos"];
        const _c_3 = _t_9["lo"];
        const _d_3 = _t_9["hi"];
        const _key_8 = _kb_0["fst"];
        const _t_12 = _kb_0["snd"];
        if (!_t_12) {
          return {$: "MNode", "pos": _p_0, "lo": ($Map$put$go$({$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, _x_0, ($Map$bit$(_key_8, _q_2)))), "hi": {$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}};
        } else {
          return {$: "MNode", "pos": _p_0, "lo": {$: "MNode", "pos": _q_2, "lo": _c_2, "hi": _d_2}, "hi": ($Map$put$go$({$: "MNode", "pos": _q_3, "lo": _c_3, "hi": _d_3}, _x_0, ($Map$bit$(_key_8, _q_3))))};
        }
      }
    }
  } else {
    return _node_0;
  }
}

function $Map$ins$splice$(_p_0, _key_0, _x_0, _rest_0) {
  return $Map$ins$splice$bit$(_x_0, _rest_0, _p_0, ($Map$bit$(_key_0, _p_0)));
}

function $Map$ins$go$(_node_0, _x_0, _p_0, _kb_0, _t_0) {
  if (_node_0.$ === "MNode") {
    const _q_0 = _node_0["pos"];
    const _t_1 = _node_0["lo"];
    if (_t_1.$ === "MTip") {
      const _t_2 = _node_0["hi"];
      if (_t_2.$ === "MTip") {
        const _key_0 = _kb_0["fst"];
        const _t_3 = _kb_0["snd"];
        if (!_t_3) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_0, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _key_0, "val": _x_0}, "hi": {$: "MTip"}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_0, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": {$: "MTip"}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _key_0, "val": _x_0}};
          }
        }
      } else if (_t_2.$ === "MLeaf") {
        const _k_0 = _t_2["key"];
        const _v_0 = _t_2["val"];
        const _key_1 = _kb_0["fst"];
        const _t_4 = _kb_0["snd"];
        if (!_t_4) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_1, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _key_1, "val": _x_0}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_1, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": {$: "MLeaf", "key": _k_0, "val": _v_0}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": ($Map$ins$splice$(_p_0, _key_1, _x_0, {$: "MLeaf", "key": _k_0, "val": _v_0}))};
          }
        }
      } else {
        const _r_0 = _t_2["pos"];
        const _c_0 = _t_2["lo"];
        const _d_0 = _t_2["hi"];
        const _key_2 = _kb_0["fst"];
        const _t_5 = _kb_0["snd"];
        if (!_t_5) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_2, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": {$: "MNode", "pos": _r_0, "lo": _c_0, "hi": _d_0}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _key_2, "val": _x_0}, "hi": {$: "MNode", "pos": _r_0, "lo": _c_0, "hi": _d_0}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_2, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": {$: "MNode", "pos": _r_0, "lo": _c_0, "hi": _d_0}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MTip"}, "hi": ($Map$ins$go$({$: "MNode", "pos": _r_0, "lo": _c_0, "hi": _d_0}, _x_0, _p_0, ($Map$bit$(_key_2, _r_0)), (_r_0 < _p_0)))};
          }
        }
      }
    } else if (_t_1.$ === "MLeaf") {
      const _k_1 = _t_1["key"];
      const _v_1 = _t_1["val"];
      const _t_6 = _node_0["hi"];
      if (_t_6.$ === "MTip") {
        const _key_3 = _kb_0["fst"];
        const _t_7 = _kb_0["snd"];
        if (!_t_7) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_3, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MTip"}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": ($Map$ins$splice$(_p_0, _key_3, _x_0, {$: "MLeaf", "key": _k_1, "val": _v_1})), "hi": {$: "MTip"}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_3, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MTip"}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MLeaf", "key": _key_3, "val": _x_0}};
          }
        }
      } else if (_t_6.$ === "MLeaf") {
        const _k_2 = _t_6["key"];
        const _v_2 = _t_6["val"];
        const _key_4 = _kb_0["fst"];
        const _t_8 = _kb_0["snd"];
        if (!_t_8) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_4, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MLeaf", "key": _k_2, "val": _v_2}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": ($Map$ins$splice$(_p_0, _key_4, _x_0, {$: "MLeaf", "key": _k_1, "val": _v_1})), "hi": {$: "MLeaf", "key": _k_2, "val": _v_2}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_4, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MLeaf", "key": _k_2, "val": _v_2}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": ($Map$ins$splice$(_p_0, _key_4, _x_0, {$: "MLeaf", "key": _k_2, "val": _v_2}))};
          }
        }
      } else {
        const _r_1 = _t_6["pos"];
        const _c_1 = _t_6["lo"];
        const _d_1 = _t_6["hi"];
        const _key_5 = _kb_0["fst"];
        const _t_9 = _kb_0["snd"];
        if (!_t_9) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_5, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MNode", "pos": _r_1, "lo": _c_1, "hi": _d_1}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": ($Map$ins$splice$(_p_0, _key_5, _x_0, {$: "MLeaf", "key": _k_1, "val": _v_1})), "hi": {$: "MNode", "pos": _r_1, "lo": _c_1, "hi": _d_1}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_5, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": {$: "MNode", "pos": _r_1, "lo": _c_1, "hi": _d_1}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MLeaf", "key": _k_1, "val": _v_1}, "hi": ($Map$ins$go$({$: "MNode", "pos": _r_1, "lo": _c_1, "hi": _d_1}, _x_0, _p_0, ($Map$bit$(_key_5, _r_1)), (_r_1 < _p_0)))};
          }
        }
      }
    } else {
      const _r_2 = _t_1["pos"];
      const _c_2 = _t_1["lo"];
      const _d_2 = _t_1["hi"];
      const _t_10 = _node_0["hi"];
      if (_t_10.$ === "MTip") {
        const _key_6 = _kb_0["fst"];
        const _t_11 = _kb_0["snd"];
        if (!_t_11) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_6, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MTip"}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": ($Map$ins$go$({$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, _x_0, _p_0, ($Map$bit$(_key_6, _r_2)), (_r_2 < _p_0))), "hi": {$: "MTip"}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_6, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MTip"}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MLeaf", "key": _key_6, "val": _x_0}};
          }
        }
      } else if (_t_10.$ === "MLeaf") {
        const _k_3 = _t_10["key"];
        const _v_3 = _t_10["val"];
        const _key_7 = _kb_0["fst"];
        const _t_12 = _kb_0["snd"];
        if (!_t_12) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_7, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MLeaf", "key": _k_3, "val": _v_3}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": ($Map$ins$go$({$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, _x_0, _p_0, ($Map$bit$(_key_7, _r_2)), (_r_2 < _p_0))), "hi": {$: "MLeaf", "key": _k_3, "val": _v_3}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_7, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MLeaf", "key": _k_3, "val": _v_3}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": ($Map$ins$splice$(_p_0, _key_7, _x_0, {$: "MLeaf", "key": _k_3, "val": _v_3}))};
          }
        }
      } else {
        const _r_3 = _t_10["pos"];
        const _c_3 = _t_10["lo"];
        const _d_3 = _t_10["hi"];
        const _key_8 = _kb_0["fst"];
        const _t_13 = _kb_0["snd"];
        if (!_t_13) {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_8, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MNode", "pos": _r_3, "lo": _c_3, "hi": _d_3}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": ($Map$ins$go$({$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, _x_0, _p_0, ($Map$bit$(_key_8, _r_2)), (_r_2 < _p_0))), "hi": {$: "MNode", "pos": _r_3, "lo": _c_3, "hi": _d_3}};
          }
        } else {
          if (!_t_0) {
            return $Map$ins$splice$(_p_0, _key_8, _x_0, {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": {$: "MNode", "pos": _r_3, "lo": _c_3, "hi": _d_3}});
          } else {
            return {$: "MNode", "pos": _q_0, "lo": {$: "MNode", "pos": _r_2, "lo": _c_2, "hi": _d_2}, "hi": ($Map$ins$go$({$: "MNode", "pos": _r_3, "lo": _c_3, "hi": _d_3}, _x_0, _p_0, ($Map$bit$(_key_8, _r_3)), (_r_3 < _p_0)))};
          }
        }
      }
    }
  } else {
    return _node_0;
  }
}

function $Map$diff$fin$(_xt_0, _yt_0, _rc_0) {
  const _r_0 = _rc_0["fst"];
  const _t_0 = _rc_0["snd"];
  if (_t_0) {
    const _x_0 = ($Map$diff$(_xt_0, _yt_0));
    return nat_chk(33 + _x_0);
  } else {
    return _r_0;
  }
}

function $Map$diff$step$(_x_0, _y_0) {
  const _x_1 = _x_0.codePointAt(0);
  const _x_2 = _y_0.codePointAt(0);
  const _x_3 = _x_0.codePointAt(0);
  const _x_4 = _y_0.codePointAt(0);
  return {$: "Tuple", "fst": ($Map$diff$chr$(((_x_1 ^ _x_2) >>> 0))), "snd": (_x_3 === _x_4)};
}

function $Map$ins$splice$bit$(_x_0, _rest_0, _pb_0, _kb_0) {
  const _key2_0 = _kb_0["fst"];
  const _t_0 = _kb_0["snd"];
  if (!_t_0) {
    return {$: "MNode", "pos": _pb_0, "lo": {$: "MLeaf", "key": _key2_0, "val": _x_0}, "hi": _rest_0};
  } else {
    return {$: "MNode", "pos": _pb_0, "lo": _rest_0, "hi": {$: "MLeaf", "key": _key2_0, "val": _x_0}};
  }
}

function $Map$diff$chr$(_x_0) {
  const _x_1 = ($Map$msb$u$(32, _x_0));
  return (33 < _x_1 ? 0 : 33 - _x_1);
}

function $Map$msb$u$(_n_0, _x_0) {
  if (_n_0 === 0) {
    return 0;
  } else {
    const _p_0 = (_n_0 - 1);
    return $Map$msb$u$if$(_p_0, _x_0, (_x_0 === 0));
  }
}

function $Map$msb$u$if$(_p_0, _x2_0, _z_0) {
  if (_z_0) {
    return 0;
  } else {
    const _x_0 = ($Map$msb$u$(_p_0, ((_x2_0 >>> 1) >>> 0)));
    return nat_chk(1 + _x_0);
  }
}

function $0m0(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "MTip": at[key] = v; return top[0];
      case "MLeaf": at[key] = v; return top[0];
      case "MNode": at = at[key] = {...v, "pos": BigInt(v["pos"]), "lo": $0m0(v["lo"])}; key = "hi"; v = v[key]; continue;
      default: throw "bend: Map has no tag " + v?.$ + " (its tags: MTip, MLeaf, MNode); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m2(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "MTip": at[key] = v; return top[0];
      case "MLeaf": at[key] = v; return top[0];
      case "MNode": at = at[key] = {...v, "pos": nat_host(v["pos"]), "lo": $0m2(v["lo"])}; key = "hi"; v = v[key]; continue;
      default: throw "bend: Map has no tag " + v?.$ + " (its tags: MTip, MLeaf, MNode); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m1(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m4(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "MTip": at[key] = v; return top[0];
      case "MLeaf": at[key] = v; return top[0];
      case "MNode": at = at[key] = {...v, "pos": BigInt(v["pos"]), "lo": $0m4(v["lo"])}; key = "hi"; v = v[key]; continue;
      default: throw "bend: Map has no tag " + v?.$ + " (its tags: MTip, MLeaf, MNode); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m3(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m4(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m5(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m6(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m4(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m7(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m2(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m8(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m4(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m10(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "MTip": at[key] = v; return top[0];
      case "MLeaf": at[key] = v; return top[0];
      case "MNode": at = at[key] = {...v, "pos": nat_host(v["pos"]), "lo": $0m10(v["lo"])}; key = "hi"; v = v[key]; continue;
      default: throw "bend: Map has no tag " + v?.$ + " (its tags: MTip, MLeaf, MNode); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m9(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m10(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m12(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "MTip": at[key] = v; return top[0];
      case "MLeaf": at[key] = v; return top[0];
      case "MNode": at = at[key] = {...v, "pos": BigInt(v["pos"]), "lo": $0m12(v["lo"])}; key = "hi"; v = v[key]; continue;
      default: throw "bend: Map has no tag " + v?.$ + " (its tags: MTip, MLeaf, MNode); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}

function $0m11(v) {
  const top = [v];
  for (let at = top, key = 0;;) {
    switch (v.$) {
      case "Tuple": at = at[key] = {...v, "fst": $0m12(v["fst"])}; return top[0];
      default: throw "bend: Sigma has no tag " + v?.$ + " (its tags: Tuple); a tag names its constructor as the"
      + " loading file sees it, which a later version will make the same"
      + " everywhere (#1105)";
    }
  }
}
export default {
  "Str.join.go": run_lib((a0, a1) => { const r = (run_loop($Str$join$go$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "Str.join": run_lib((a0) => { const r = (run_loop($Str$join$((a0)))); (a0); return r; }, 1),
  "b2u": run_lib((a0) => { const r = (run_loop($b2u$((a0)))); (a0); return r; }, 1),
  "got": run_lib((a0, a1) => { const r = (run_loop($got$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "is_none": run_lib((a0) => { const r = (run_loop($is_none$((a0)))); (a0); return r; }, 1),
  "digits": run_lib((a0, a1) => { const r = (run_loop($digits$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "m3": run_lib(() => { const r = $0m0(run_loop($m3$()));  return r; }, 0),
  "chk_get": run_lib(() => { const r = (run_loop($chk_get$()));  return r; }, 0),
  "chk_get.s4": run_lib((a0, a1, a2, a3) => { const r = (run_loop($chk_get$s4$((a0), (a1), (a2), $0m1(a3)))); (a0); (a1); (a2); $0m3(a3); return r; }, 4),
  "chk_get.s3": run_lib((a0, a1, a2) => { const r = (run_loop($chk_get$s3$((a0), (a1), $0m5(a2)))); (a0); (a1); $0m6(a2); return r; }, 3),
  "chk_get.s2": run_lib((a0, a1) => { const r = (run_loop($chk_get$s2$((a0), $0m5(a1)))); (a0); $0m6(a1); return r; }, 2),
  "chk_get.s1": run_lib((a0) => { const r = (run_loop($chk_get$s1$($0m5(a0)))); $0m6(a0); return r; }, 1),
  "chk_del": run_lib(() => { const r = (run_loop($chk_del$()));  return r; }, 0),
  "chk_del.s4": run_lib((a0, a1, a2, a3) => { const r = (run_loop($chk_del$s4$((a0), (a1), (a2), $0m7(a3)))); (a0); (a1); (a2); $0m8(a3); return r; }, 4),
  "chk_del.s3": run_lib((a0, a1, a2) => { const r = (run_loop($chk_del$s3$((a0), (a1), $0m7(a2)))); (a0); (a1); $0m8(a2); return r; }, 3),
  "chk_del.s2": run_lib((a0, a1) => { const r = (run_loop($chk_del$s2$((a0), $0m5(a1)))); (a0); $0m6(a1); return r; }, 2),
  "chk_del.s1": run_lib((a0) => { const r = (run_loop($chk_del$s1$($0m1(a0)))); $0m3(a0); return r; }, 1),
  "chk_union": run_lib(() => { const r = (run_loop($chk_union$()));  return r; }, 0),
  "chk_union.s3": run_lib((a0, a1, a2) => { const r = (run_loop($chk_union$s3$((a0), (a1), $0m5(a2)))); (a0); (a1); $0m6(a2); return r; }, 3),
  "chk_union.s2": run_lib((a0, a1) => { const r = (run_loop($chk_union$s2$((a0), $0m5(a1)))); (a0); $0m6(a1); return r; }, 2),
  "chk_union.s1": run_lib((a0) => { const r = (run_loop($chk_union$s1$($0m5(a0)))); $0m6(a0); return r; }, 1),
  "chk_order": run_lib(() => { const r = (run_loop($chk_order$()));  return r; }, 0),
  "chk_set": run_lib(() => { const r = (run_loop($chk_set$()));  return r; }, 0),
  "chk_set.s4": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($chk_set$s4$((a0), (a1), (a2), (a3), $0m9(a4)))); (a0); (a1); (a2); (a3); $0m11(a4); return r; }, 5),
  "chk_set.s3": run_lib((a0, a1, a2, a3) => { const r = (run_loop($chk_set$s3$((a0), (a1), (a2), $0m9(a3)))); (a0); (a1); (a2); $0m11(a3); return r; }, 4),
  "chk_set.s2": run_lib((a0, a1) => { const r = (run_loop($chk_set$s2$((a0), $0m9(a1)))); (a0); $0m11(a1); return r; }, 2),
  "chk_set.s1": run_lib((a0) => { const r = (run_loop($chk_set$s1$($0m9(a0)))); $0m11(a0); return r; }, 1),
  "main.out": run_lib(() => { const r = (run_loop($main$out$()));  return r; }, 0),
};
