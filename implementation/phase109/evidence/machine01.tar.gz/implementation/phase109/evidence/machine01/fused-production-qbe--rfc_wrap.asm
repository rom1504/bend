
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401bb0 <rfc_wrap>:
  401bb0:	endbr64 
  401bb4:	push   %rbp
  401bb5:	mov    %rsp,%rbp
  401bb8:	sub    $0x18,%rsp
  401bbc:	push   %rbx
  401bbd:	push   %r12
  401bbf:	push   %r13
  401bc1:	mov    %ecx,%r12d
  401bc4:	mov    %rdx,%r13
  401bc7:	mov    %rdi,-0x10(%rbp)
  401bcb:	mov    %rsi,-0x8(%rbp)
  401bcf:	mov    %r13,%rdi
  401bd2:	callq  401b00 <term_tag>
  401bd7:	cmp    $0x3,%rax
  401bdb:	je     401c3f <rfc_wrap+0x8f>
  401bdd:	mov    %r13,%rdi
  401be0:	callq  401b00 <term_tag>
  401be5:	cmp    $0x5,%rax
  401be9:	je     401c3f <rfc_wrap+0x8f>
  401beb:	mov    $0x0,%edx
  401bf0:	mov    -0x10(%rbp),%rdi
  401bf4:	mov    -0x8(%rbp),%rsi
  401bf8:	callq  4019b0 <heap_alloc>
  401bfd:	mov    %rax,%rbx
  401c00:	mov    %r13,%rdi
  401c03:	callq  401b50 <term_loc>
  401c08:	mov    %rax,%rcx
  401c0b:	mov    %r13,%rax
  401c0e:	shl    $0x18,%rcx
  401c12:	mov    %r12d,%edx
  401c15:	or     %rdx,%rcx
  401c18:	mov    -0x10(%rbp),%rdx
  401c1c:	mov    %rcx,(%rdx,%rbx,8)
  401c20:	movabs $0xffffff0000000000,%rcx
  401c2a:	and    %rcx,%rax
  401c2d:	movabs $0x8000000000000000,%rcx
  401c37:	or     %rcx,%rax
  401c3a:	or     %rbx,%rax
  401c3d:	jmp    401c53 <rfc_wrap+0xa3>
  401c3f:	mov    %r13,%rbx
  401c42:	mov    -0x10(%rbp),%rdi
  401c46:	mov    $0x6,%esi
  401c4b:	callq  401450 <err_post>
  401c50:	mov    %rbx,%rax
  401c53:	pop    %r13
  401c55:	pop    %r12
  401c57:	pop    %rbx
  401c58:	leaveq 
  401c59:	retq   

Disassembly of section .fini:
