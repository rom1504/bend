
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402af0 <nx_rt_rebuild2>:
  402af0:	movabs $0xffffffffff,%r9
  402afa:	push   %r14
  402afc:	push   %r13
  402afe:	and    %rsi,%r9
  402b01:	mov    %edx,%r13d
  402b04:	push   %r12
  402b06:	lea    0x0(,%r9,8),%rdx
  402b0e:	push   %rbp
  402b0f:	mov    %ecx,%ebp
  402b11:	push   %rbx
  402b12:	mov    %rdi,%rbx
  402b15:	sub    $0x20,%rsp
  402b19:	mov    (%rdi),%rdi
  402b1c:	mov    0x8(%rbx),%r12
  402b20:	lea    (%rdi,%rdx,1),%rax
  402b24:	test   %rsi,%rsi
  402b27:	js     402ba8 <nx_rt_rebuild2+0xb8>
  402b29:	mov    (%rax),%rax
  402b2c:	mov    %rax,0x10(%rsp)
  402b31:	mov    0x8(%rdi,%rdx,1),%rax
  402b36:	mov    %rax,0x18(%rsp)
  402b3b:	cmp    $0x310817f,%r9
  402b42:	jbe    402b80 <nx_rt_rebuild2+0x90>
  402b44:	mov    $0x1,%eax
  402b49:	mov    0x10(%rsp,%rbp,8),%rcx
  402b4e:	mov    %r13d,%edx
  402b51:	mov    %r12,%rsi
  402b54:	sub    %ebp,%eax
  402b56:	movq   $0xffffffffffffffff,0x18(%rbx)
  402b5e:	mov    0x10(%rsp,%rax,8),%rax
  402b63:	movl   $0x1,0x20(%rbx)
  402b6a:	mov    %rax,0x10(%rbx)
  402b6e:	add    $0x20,%rsp
  402b72:	pop    %rbx
  402b73:	pop    %rbp
  402b74:	pop    %r12
  402b76:	pop    %r13
  402b78:	pop    %r14
  402b7a:	jmpq   401d90 <nx_construct2>
  402b7f:	nop
  402b80:	mov    0x8(%r12),%r9
  402b85:	test   %r9,%r9
  402b88:	je     401651 <nx_rt_rebuild2.cold>
  402b8e:	mov    (%rdi,%r9,8),%rax
  402b92:	subq   $0x2,0x108(%r12)
  402b9b:	mov    %rax,0x8(%r12)
  402ba0:	jmp    402b44 <nx_rt_rebuild2+0x54>
  402ba2:	nopw   0x0(%rax,%rax,1)
  402ba8:	mov    0x4(%rax),%edx
  402bab:	mov    (%rax),%ecx
  402bad:	shl    $0x20,%rdx
  402bb1:	or     %rcx,%rdx
  402bb4:	mov    %rdx,%r14
  402bb7:	and    $0xffffff,%edx
  402bbd:	shr    $0x18,%r14
  402bc1:	lea    0x0(,%r14,8),%r10
  402bc9:	lea    (%rdi,%r10,1),%r11
  402bcd:	lea    0x8(%rdi,%r10,1),%r10
  402bd2:	cmp    $0x1,%rdx
  402bd6:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402bdc:	mov    (%rax),%edx
  402bde:	mov    (%r11),%rdx
  402be1:	mov    %rdx,0x10(%rsp)
  402be6:	mov    (%r10),%rdx
  402be9:	mov    %rdx,0x18(%rsp)
  402bee:	mov    (%r12),%rdx
  402bf2:	mov    %rdx,(%rax)
  402bf5:	mov    0x100(%r12),%rax
  402bfd:	mov    0x55d5(%rip),%edx        # 4081d8 <KEEP_WORDS>
  402c03:	mov    %r9,(%r12)
  402c07:	add    $0x1,%rax
  402c0b:	mov    %rax,0x100(%r12)
  402c13:	cmp    %rdx,%rax
  402c16:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402c1c:	mov    %r14,%r9
  402c1f:	jmpq   402b3b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
