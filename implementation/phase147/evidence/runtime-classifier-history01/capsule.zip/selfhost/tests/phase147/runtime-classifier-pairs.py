#!/usr/bin/env python3
"""Root-only bounded native exact-controls and four ABBA blocks; no nested guard."""
import argparse,json,os,statistics,sys,time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[3];sys.dont_write_bytecode=True
sys.path.insert(0,str(ROOT/'selfhost/tools/build'))
from common import fresh_output,pin,require,run,verify,write_json,clean_environment

def read(p):return json.loads(Path(p).read_text())
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--preparation',required=True,type=Path);ap.add_argument('--controls',required=True,type=Path);ap.add_argument('--out',required=True,type=Path);a=ap.parse_args()
    require(os.sched_getaffinity(0)=={3},'Root CPU3 guard required');clean_environment()
    plan=read(a.preparation);control=read(a.controls);folder=a.preparation.resolve().parent;buildfile=folder/'native/report.json';build=read(buildfile)
    require(plan['complete']and plan['kind']=='phase147-runtime-classifier-preparation','Preparation required')
    require(control['complete']and control['passed']and control['kind']=='phase147-runtime-classifier-controls','Checked full finite controls required')
    require(build['complete']and not build['changedInputs']and build['request']['source']==plan['nativeSource'],'Exact native source/build required')
    oracle=verify(plan['nativeOracle']).read_bytes();binary=verify(build['binary'])
    require(len(control['rows'])==677 and all(x['passed']for x in control['rows']),'All677 controls required')
    inputs=[pin(__file__),pin(ROOT/'selfhost/tools/build/common.py'),pin(a.preparation),pin(a.controls),pin(buildfile),build['binary'],plan['nativeSource'],plan['nativeOracle'],*control['inputs']]
    for p in inputs:verify(p)
    out=fresh_output(a.out,ROOT);started=time.monotonic();report={'kind':'phase147-runtime-classifier-native-pairs','complete':False,'passed':False,'performanceQualified':False,'inputs':inputs,'calls':[],'blocks':[],'protocol':{'blocks':4,'order':['old','new','new','old'],'minimumCalibrationSeconds':0.15,'sampleScope':'Actualselected-function N111Call symbolfrequencies, notwholecompiler/dynamicprofile','controls':'Complete677Boolean resultstring before/after; zero-repeat and !salt negatives; timedfullcountstdout exact.'}}
    def save():write_json(out/'report.json',report)
    def invoke(mode,count,salt,kind):
        require(time.monotonic()-started<75,'Timing budget exceeded');i=len(report['calls']);d=out/str(i);d.mkdir()
        result=run([str(binary),'--threads','1','--gpu','off','--','classifier',mode,str(count),salt],cwd=ROOT,stdout=d/'stdout',stderr=d/'stderr',seconds=12)
        row={'index':i,'mode':mode,'count':count,'salt':salt,'kind':kind,**result};report['calls'].append(row);save()
        expected=oracle if count=='check' else (str(int(count)*plan['expectedPerIteration']if salt==''else 0)+'\n').encode()
        require(result['complete']and result['exitCode']==0 and (d/'stdout').read_bytes()==expected and not(d/'stderr').read_bytes(),'Exact child output/control failed')
        row['passed']=True;save();return row
    save()
    try:
        for mode in ['old','new']:
            invoke(mode,'check','','complete-controls-before');invoke(mode,0,'','startup');invoke(mode,1,'!','salt-negative')
        count=1
        for attempt in range(9):
            rows=[invoke(m,count,'','calibration')for m in ['old','new']]
            if min(r['seconds']for r in rows)>=0.15:break
            require(count<65536,'Calibration bound exhausted');count=min(count*4,65536)
        else:raise ValueError('Calibration attempts exhausted')
        report['repeats']=count
        for block in range(4):
            rows=[invoke(m,count,'','timed')for m in ['old','new','new','old']]
            med={m:statistics.median(r['seconds']for r in rows if r['mode']==m)for m in ['old','new']}
            report['blocks'].append({'block':block,'calls':[r['index']for r in rows],'medianSeconds':med,'ratio':med['new']/med['old']});save()
        for mode in ['old','new']:invoke(mode,'check','','complete-controls-after')
        timed=[r for r in report['calls']if r['kind']=='timed'];med={m:statistics.median(r['seconds']for r in timed if r['mode']==m)for m in ['old','new']}
        report.update(medianSeconds=med,ratio=med['new']/med['old'],performanceQualified=min(r['seconds']for r in timed)>=0.12)
        for p in inputs:verify(p)
        report['complete']=report['passed']=True
    except BaseException as e:report['error']=repr(e);raise
    finally:report['seconds']=time.monotonic()-started;save()
    print(json.dumps({k:report[k]for k in ['complete','passed','performanceQualified','medianSeconds','ratio']}))
if __name__=='__main__':main()
