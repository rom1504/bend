
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	mov    %rsi,%rax
  401c03:	mov    %rdx,%r8
  401c06:	shr    $0x28,%rax
  401c0a:	and    $0xffff,%eax
  401c0f:	je     401c5e <nx_list_reverse+0x5e>
  401c11:	push   %rbp
  401c12:	mov    %rdi,%rbp
  401c15:	cmp    $0x1,%rax
  401c19:	je     401c26 <nx_list_reverse+0x26>
  401c1b:	jmp    401c50 <nx_list_reverse+0x50>
  401c1d:	nopl   (%rax)
  401c20:	cmp    $0x1,%rax
  401c24:	jne    401c50 <nx_list_reverse+0x50>
  401c26:	mov    %r8,%rdx
  401c29:	mov    %rbp,%rdi
  401c2c:	callq  403470 <nx_rt_pair_rebuild2_c1_k0>
  401c31:	mov    %rax,%r8
  401c34:	mov    %rdx,%rax
  401c37:	mov    %rdx,%rsi
  401c3a:	shr    $0x28,%rax
  401c3e:	and    $0xffff,%eax
  401c43:	jne    401c20 <nx_list_reverse+0x20>
  401c45:	mov    %r8,%rax
  401c48:	pop    %rbp
  401c49:	retq   
  401c4a:	nopw   0x0(%rax,%rax,1)
  401c50:	mov    %rbp,%rdi
  401c53:	mov    $0x1,%esi
  401c58:	pop    %rbp
  401c59:	jmpq   402540 <nx_rt_fail>
  401c5e:	mov    %rdx,%rax
  401c61:	retq   

Disassembly of section .fini:
