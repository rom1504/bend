
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004024f0 <nx_rt_take2>:
  4024f0:	push   %r13
  4024f2:	push   %r12
  4024f4:	sub    $0x8,%rsp
  4024f8:	cmpb   $0x0,0x4c81(%rip)        # 407180 <nx_active>
  4024ff:	je     40250d <nx_rt_take2+0x1d>
  402501:	lea    0x4c98(%rip),%rax        # 4071a0 <nx_context>
  402508:	cmp    %rax,%rdi
  40250b:	je     402520 <nx_rt_take2+0x30>
  40250d:	lea    0x1b1f(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402514:	callq  401990 <err_fail>
  402519:	nopl   0x0(%rax)
  402520:	mov    0x4c9a(%rip),%eax        # 4071c0 <nx_context+0x20>
  402526:	mov    0x4c73(%rip),%rdi        # 4071a0 <nx_context>
  40252d:	test   %eax,%eax
  40252f:	jne    402669 <nx_rt_take2+0x179>
  402535:	mov    %rsi,%r12
  402538:	callq  401ac0 <nx_id.isra.0>
  40253d:	and    $0xfffffffd,%eax
  402540:	cmp    $0x1,%eax
  402543:	jne    40265d <nx_rt_take2+0x16d>
  402549:	mov    0x4c50(%rip),%rdi        # 4071a0 <nx_context>
  402550:	mov    0x4c51(%rip),%rsi        # 4071a8 <nx_context+0x8>
  402557:	movabs $0xffffffffff,%rax
  402561:	and    %r12,%rax
  402564:	lea    0x0(,%rax,8),%rcx
  40256c:	lea    (%rdi,%rcx,1),%rdx
  402570:	test   %r12,%r12
  402573:	js     4025e0 <nx_rt_take2+0xf0>
  402575:	mov    (%rdx),%rdx
  402578:	mov    %rdx,0x4c31(%rip)        # 4071b0 <nx_context+0x10>
  40257f:	mov    0x8(%rdi,%rcx,1),%rdx
  402584:	mov    %rdx,0x4c2d(%rip)        # 4071b8 <nx_context+0x18>
  40258b:	cmp    $0x310817f,%rax
  402591:	ja     4025b0 <nx_rt_take2+0xc0>
  402593:	movl   $0x3,0x4c23(%rip)        # 4071c0 <nx_context+0x20>
  40259d:	add    $0x8,%rsp
  4025a1:	xor    %eax,%eax
  4025a3:	pop    %r12
  4025a5:	pop    %r13
  4025a7:	retq   
  4025a8:	nopl   0x0(%rax,%rax,1)
  4025b0:	mov    0x8(%rsi),%rdx
  4025b4:	mov    %rdx,(%rdi,%rax,8)
  4025b8:	mov    0x4c1a(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4025be:	mov    %rax,0x8(%rsi)
  4025c2:	mov    0x108(%rsi),%rax
  4025c9:	add    $0x2,%rax
  4025cd:	mov    %rax,0x108(%rsi)
  4025d4:	cmp    %rdx,%rax
  4025d7:	jb     402593 <nx_rt_take2+0xa3>
  4025d9:	jmpq   401567 <nx_rt_take2.cold>
  4025de:	xchg   %ax,%ax
  4025e0:	mov    0x4(%rdx),%ecx
  4025e3:	mov    (%rdx),%r8d
  4025e6:	shl    $0x20,%rcx
  4025ea:	or     %r8,%rcx
  4025ed:	mov    %rcx,%r13
  4025f0:	and    $0xffffff,%ecx
  4025f6:	shr    $0x18,%r13
  4025fa:	lea    0x0(,%r13,8),%r8
  402602:	lea    (%rdi,%r8,1),%r9
  402606:	lea    0x8(%rdi,%r8,1),%r8
  40260b:	cmp    $0x1,%rcx
  40260f:	jne    401582 <nx_rt_take2.cold+0x1b>
  402615:	mov    (%rdx),%ecx
  402617:	mov    (%r9),%rcx
  40261a:	mov    %rcx,0x4b8f(%rip)        # 4071b0 <nx_context+0x10>
  402621:	mov    (%r8),%rcx
  402624:	mov    %rcx,0x4b8d(%rip)        # 4071b8 <nx_context+0x18>
  40262b:	mov    (%rsi),%rcx
  40262e:	mov    %rcx,(%rdx)
  402631:	mov    0x4ba1(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402637:	mov    %rax,(%rsi)
  40263a:	mov    0x100(%rsi),%rax
  402641:	add    $0x1,%rax
  402645:	mov    %rax,0x100(%rsi)
  40264c:	cmp    %rdx,%rax
  40264f:	jae    401576 <nx_rt_take2.cold+0xf>
  402655:	mov    %r13,%rax
  402658:	jmpq   40258b <nx_rt_take2+0x9b>
  40265d:	lea    0x1cb4(%rip),%rdi        # 404318 <_IO_stdin_used+0x318>
  402664:	callq  401990 <err_fail>
  402669:	lea    0x1c80(%rip),%rdi        # 4042f0 <_IO_stdin_used+0x2f0>
  402670:	callq  401990 <err_fail>

Disassembly of section .fini:
