
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040154f <nx_rt_build2.cold>:
  40154f:	mov    $0x1,%edx
  401554:	mov    %r14,%rdi
  401557:	mov    %rbp,%rsi
  40155a:	callq  401178 <heap_alloc_miss>
  40155f:	mov    %rax,%r9
  401562:	jmpq   402508 <nx_rt_build2+0x68>

Disassembly of section .fini:
