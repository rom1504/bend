# Changed-batch runtime continuation

`run.py` imports the pinned, unchanged Phase93 `sample`, `guard` and `timing`
functions. It does not modify the active qualification or release methods.
Root executes every target command serially after the selected source passes
qualification and benefit gates.

```sh
python3 -B selfhost/tools/performance/phase99/runtime/run.py acquire \
  --changed-plan selfhost/build/phase99/static-release-plan01/runtime-continuity/changed-plan.json \
  --b1-build selfhost/build/phase99/static-qualification-plan01/b1.json \
  --b2-build selfhost/build/phase99/static-qualification-plan01/b2.json \
  --out selfhost/build/phase99/static-runtime-products01
```

This authenticates the completed 45-case continuity report and changed-plan,
then emits candidate B1 C only for changed cases and requires exact candidate
B2 C. It builds those common files with the original pinned Clang22 recipe:
`-isystem <include/clang> -std=c11 -O3 <source> -o <binary> -lpthread -lm`.
Unchanged C reuses the original products. Both retained upstream products and
retained own products are authenticated. The latter represent Phase98 through
its completed 45/45 full-C continuity receipt, not an assumption that the
compiler executables are unchanged.

The output has both `phase98-products.json` and `upstream-products.json`, each
covering all 45 original fixture identities, plus the original 44 calibration
plans. Only changed C is rebuilt. Changed products have fresh B1/B2 C equality;
unchanged products have fresh candidate B2 continuity and retained original
B1/B2 equality, explicitly labeled without claiming a fresh candidate B1 batch
request. Compilation wall seconds are recorded separately from program times.

For the primary incremental comparison, freshly time changed products against
the exact retained Phase98 products:

```sh
python3 -B selfhost/tools/performance/phase99/runtime/run.py measure \
  --products selfhost/build/phase99/static-runtime-products01/phase98-products.json \
  --out selfhost/build/phase99/static-runtime-phase98-measure01
```

For a fresh complete upstream-relative runtime aggregate, time all 44 measurable
candidate products against the retained upstream products. This avoids mixing
historical samples with fresh samples while preserving exact unchanged products:

```sh
python3 -B selfhost/tools/performance/phase99/runtime/run.py measure --all \
  --products selfhost/build/phase99/static-runtime-products01/upstream-products.json \
  --out selfhost/build/phase99/static-runtime-upstream-all44-measure01
```

Omit `--all` to time only changed cases against upstream instead. An empty
changed subset is rejected before any timing; all44 timing remains available.
The unchanged Phase93 implementation starts with the original per-case counts
and warmups, runs three alternating rounds, compares complete expected values
and counters, and requires every measured interval to reach 100 ms. Its
`own/upstream` field names are legacy labels: `context.json` and `summary.json`
name the actual comparator. For the Phase98 comparison, `upstream` means the
retained Phase98 product. Summaries report point/source geometric means,
per-case medians and observed ranges, with no invented confidence intervals.

If a sample is below 100 ms, both the original failed report and context remain
in place. Do not overwrite or accept that measurement. Run the original
calibration algorithm against the same product manifest, then measure into a
fresh directory with its explicit plan:

```sh
python3 -B selfhost/tools/performance/phase99/runtime/run.py calibrate \
  --products selfhost/build/phase99/static-runtime-products01/phase98-products.json \
  --out selfhost/build/phase99/static-runtime-phase98-calibrate01
python3 -B selfhost/tools/performance/phase99/runtime/run.py measure \
  --products selfhost/build/phase99/static-runtime-products01/phase98-products.json \
  --plans selfhost/build/phase99/static-runtime-phase98-calibrate01/report.json \
  --out selfhost/build/phase99/static-runtime-phase98-measure02
```

For an all44 failure, apply `--all` to calibration and fresh measurement with
the upstream product manifest. Calibration retains the original doubling/cap
rules, 50 ms minimum calibration interval and 250 ms target. Recalibration is
an explicit continuation, not an automatic retry that hides failures.

`scalar-region-0` is always excluded from ratios. If its C changes, acquisition
checks its complete candidate/upstream output once through the unchanged sample
function; this is correctness evidence and does not create a defined runtime
ratio. If its C is unchanged, the original zero-work evidence is retained.

Native inner elapsed milliseconds include loop/result validation and final
counter printing, and exclude compilation, process startup and warmup. Whole
process seconds remain in raw records. None of these are JavaScript-target
timings. The all44 path uses entirely fresh samples; a historical/fresh mixed
aggregate is not produced by this adapter.
