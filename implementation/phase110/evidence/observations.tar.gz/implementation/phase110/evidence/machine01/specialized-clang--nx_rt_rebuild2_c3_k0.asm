
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403770 <nx_rt_rebuild2_c3_k0>:
  403770:	push   %r13
  403772:	mov    %rsi,%r10
  403775:	mov    %rdx,%r8
  403778:	movabs $0xffffffffff,%r9
  403782:	push   %r12
  403784:	and    %r10,%r9
  403787:	push   %rbp
  403788:	lea    0x0(,%r9,8),%rax
  403790:	push   %rbx
  403791:	mov    %rdi,%rbx
  403794:	sub    $0x28,%rsp
  403798:	mov    (%rdi),%rdi
  40379b:	mov    0x8(%rbx),%rsi
  40379f:	lea    (%rdi,%rax,1),%rdx
  4037a3:	test   %r10,%r10
  4037a6:	js     403810 <nx_rt_rebuild2_c3_k0+0xa0>
  4037a8:	mov    (%rdx),%r12
  4037ab:	mov    0x8(%rdi,%rax,1),%rbp
  4037b0:	cmp    $0x310817f,%r9
  4037b7:	jbe    4037e8 <nx_rt_rebuild2_c3_k0+0x78>
  4037b9:	mov    %rbp,0x10(%rbx)
  4037bd:	mov    %r12,%rcx
  4037c0:	mov    $0x3,%edx
  4037c5:	movq   $0xffffffffffffffff,0x18(%rbx)
  4037cd:	movl   $0x1,0x20(%rbx)
  4037d4:	add    $0x28,%rsp
  4037d8:	pop    %rbx
  4037d9:	pop    %rbp
  4037da:	pop    %r12
  4037dc:	pop    %r13
  4037de:	jmpq   401fa0 <nx_construct2>
  4037e3:	nopl   0x0(%rax,%rax,1)
  4037e8:	mov    0x8(%rsi),%r9
  4037ec:	test   %r9,%r9
  4037ef:	je     40188c <nx_rt_rebuild2_c3_k0.cold>
  4037f5:	mov    (%rdi,%r9,8),%rax
  4037f9:	subq   $0x2,0x108(%rsi)
  403801:	mov    %rax,0x8(%rsi)
  403805:	jmp    4037b9 <nx_rt_rebuild2_c3_k0+0x49>
  403807:	nopw   0x0(%rax,%rax,1)
  403810:	mov    0x4(%rdx),%eax
  403813:	mov    (%rdx),%ecx
  403815:	shl    $0x20,%rax
  403819:	or     %rcx,%rax
  40381c:	mov    %rax,%r13
  40381f:	and    $0xffffff,%eax
  403824:	shr    $0x18,%r13
  403828:	lea    0x0(,%r13,8),%r11
  403830:	lea    (%rdi,%r11,1),%rbp
  403834:	lea    0x8(%rdi,%r11,1),%r11
  403839:	cmp    $0x1,%rax
  40383d:	jne    4018d2 <nx_rt_rebuild2_c3_k0.cold+0x46>
  403843:	mov    (%rdx),%eax
  403845:	mov    (%rsi),%rax
  403848:	mov    0x0(%rbp),%r12
  40384c:	mov    (%r11),%rbp
  40384f:	mov    %rax,(%rdx)
  403852:	mov    0x100(%rsi),%rax
  403859:	mov    0x3d979(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40385f:	mov    %r9,(%rsi)
  403862:	add    $0x1,%rax
  403866:	mov    %rax,0x100(%rsi)
  40386d:	cmp    %rdx,%rax
  403870:	jae    4018bc <nx_rt_rebuild2_c3_k0.cold+0x30>
  403876:	mov    %r13,%r9
  403879:	jmpq   4037b0 <nx_rt_rebuild2_c3_k0+0x40>

Disassembly of section .fini:
