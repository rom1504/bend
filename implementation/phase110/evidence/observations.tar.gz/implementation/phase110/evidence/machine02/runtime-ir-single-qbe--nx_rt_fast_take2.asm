
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403370 <nx_rt_fast_take2>:
  403370:	movabs $0xffffffffff,%rax
  40337a:	push   %r12
  40337c:	and    %rsi,%rax
  40337f:	push   %rbp
  403380:	push   %rbx
  403381:	mov    %rdi,%rbx
  403384:	mov    (%rdi),%rdi
  403387:	lea    0x0(,%rax,8),%rcx
  40338f:	mov    0x8(%rbx),%rbp
  403393:	lea    (%rdi,%rcx,1),%rdx
  403397:	test   %rsi,%rsi
  40339a:	js     403408 <nx_rt_fast_take2+0x98>
  40339c:	mov    (%rdx),%rdx
  40339f:	mov    %rdx,0x10(%rbx)
  4033a3:	mov    0x8(%rdi,%rcx,1),%rdx
  4033a8:	mov    %rdx,0x18(%rbx)
  4033ac:	cmp    $0x310817f,%rax
  4033b2:	ja     4033c8 <nx_rt_fast_take2+0x58>
  4033b4:	movl   $0x3,0x20(%rbx)
  4033bb:	xor    %eax,%eax
  4033bd:	pop    %rbx
  4033be:	pop    %rbp
  4033bf:	pop    %r12
  4033c1:	retq   
  4033c2:	nopw   0x0(%rax,%rax,1)
  4033c8:	mov    0x8(%rbp),%rdx
  4033cc:	mov    %rdx,(%rdi,%rax,8)
  4033d0:	mov    0x3ee02(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4033d6:	mov    %rax,0x8(%rbp)
  4033da:	mov    0x108(%rbp),%rax
  4033e1:	add    $0x2,%rax
  4033e5:	mov    %rax,0x108(%rbp)
  4033ec:	cmp    %rdx,%rax
  4033ef:	jae    4015fe <nx_rt_fast_take2.cold>
  4033f5:	movl   $0x3,0x20(%rbx)
  4033fc:	xor    %eax,%eax
  4033fe:	pop    %rbx
  4033ff:	pop    %rbp
  403400:	pop    %r12
  403402:	retq   
  403403:	nopl   0x0(%rax,%rax,1)
  403408:	mov    0x4(%rdx),%ecx
  40340b:	mov    (%rdx),%r8d
  40340e:	shl    $0x20,%rcx
  403412:	or     %r8,%rcx
  403415:	mov    %rcx,%r12
  403418:	and    $0xffffff,%ecx
  40341e:	shr    $0x18,%r12
  403422:	lea    0x0(,%r12,8),%r8
  40342a:	lea    (%rdi,%r8,1),%r9
  40342e:	lea    0x8(%rdi,%r8,1),%r8
  403433:	cmp    $0x1,%rcx
  403437:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  40343d:	mov    (%rdx),%ecx
  40343f:	mov    (%r9),%rcx
  403442:	mov    %rcx,0x10(%rbx)
  403446:	mov    (%r8),%rcx
  403449:	mov    %rcx,0x18(%rbx)
  40344d:	mov    0x0(%rbp),%rcx
  403451:	mov    %rcx,(%rdx)
  403454:	mov    0x3ed7e(%rip),%edx        # 4421d8 <KEEP_WORDS>
  40345a:	mov    %rax,0x0(%rbp)
  40345e:	mov    0x100(%rbp),%rax
  403465:	add    $0x1,%rax
  403469:	mov    %rax,0x100(%rbp)
  403470:	cmp    %rdx,%rax
  403473:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  403479:	mov    %r12,%rax
  40347c:	jmpq   4033ac <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
