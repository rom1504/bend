
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402df0 <nx_rt_fast_take2>:
  402df0:	movabs $0xffffffffff,%rax
  402dfa:	push   %r12
  402dfc:	and    %rsi,%rax
  402dff:	push   %rbp
  402e00:	push   %rbx
  402e01:	mov    %rdi,%rbx
  402e04:	mov    (%rdi),%rdi
  402e07:	lea    0x0(,%rax,8),%rcx
  402e0f:	mov    0x8(%rbx),%rbp
  402e13:	lea    (%rdi,%rcx,1),%rdx
  402e17:	test   %rsi,%rsi
  402e1a:	js     402e88 <nx_rt_fast_take2+0x98>
  402e1c:	mov    (%rdx),%rdx
  402e1f:	mov    %rdx,0x10(%rbx)
  402e23:	mov    0x8(%rdi,%rcx,1),%rdx
  402e28:	mov    %rdx,0x18(%rbx)
  402e2c:	cmp    $0x310817f,%rax
  402e32:	ja     402e48 <nx_rt_fast_take2+0x58>
  402e34:	movl   $0x3,0x20(%rbx)
  402e3b:	xor    %eax,%eax
  402e3d:	pop    %rbx
  402e3e:	pop    %rbp
  402e3f:	pop    %r12
  402e41:	retq   
  402e42:	nopw   0x0(%rax,%rax,1)
  402e48:	mov    0x8(%rbp),%rdx
  402e4c:	mov    %rdx,(%rdi,%rax,8)
  402e50:	mov    0x3e382(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e56:	mov    %rax,0x8(%rbp)
  402e5a:	mov    0x108(%rbp),%rax
  402e61:	add    $0x2,%rax
  402e65:	mov    %rax,0x108(%rbp)
  402e6c:	cmp    %rdx,%rax
  402e6f:	jae    4015fe <nx_rt_fast_take2.cold>
  402e75:	movl   $0x3,0x20(%rbx)
  402e7c:	xor    %eax,%eax
  402e7e:	pop    %rbx
  402e7f:	pop    %rbp
  402e80:	pop    %r12
  402e82:	retq   
  402e83:	nopl   0x0(%rax,%rax,1)
  402e88:	mov    0x4(%rdx),%ecx
  402e8b:	mov    (%rdx),%r8d
  402e8e:	shl    $0x20,%rcx
  402e92:	or     %r8,%rcx
  402e95:	mov    %rcx,%r12
  402e98:	and    $0xffffff,%ecx
  402e9e:	shr    $0x18,%r12
  402ea2:	lea    0x0(,%r12,8),%r8
  402eaa:	lea    (%rdi,%r8,1),%r9
  402eae:	lea    0x8(%rdi,%r8,1),%r8
  402eb3:	cmp    $0x1,%rcx
  402eb7:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  402ebd:	mov    (%rdx),%ecx
  402ebf:	mov    (%r9),%rcx
  402ec2:	mov    %rcx,0x10(%rbx)
  402ec6:	mov    (%r8),%rcx
  402ec9:	mov    %rcx,0x18(%rbx)
  402ecd:	mov    0x0(%rbp),%rcx
  402ed1:	mov    %rcx,(%rdx)
  402ed4:	mov    0x3e2fe(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402eda:	mov    %rax,0x0(%rbp)
  402ede:	mov    0x100(%rbp),%rax
  402ee5:	add    $0x1,%rax
  402ee9:	mov    %rax,0x100(%rbp)
  402ef0:	cmp    %rdx,%rax
  402ef3:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  402ef9:	mov    %r12,%rax
  402efc:	jmpq   402e2c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
