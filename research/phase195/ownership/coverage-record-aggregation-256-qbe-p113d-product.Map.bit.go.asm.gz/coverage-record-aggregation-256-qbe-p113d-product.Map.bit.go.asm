
/home/ai/bend2/build/publish/bend/selfhost/build/phase186/release-native45-acquire01/coverage-record-aggregation-256/phase186-qbe-n2/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000406070 <p113d_FID_36_112_114_111_100_117_99_116_46_77_97_112_46_98_105_116_46_103_111_>:
  406070:	endbr64 
  406074:	push   %rbp
  406075:	mov    %rsp,%rbp
  406078:	push   %rbx
  406079:	push   %r12
  40607b:	mov    %rdx,%r12
  40607e:	mov    %rcx,%rdx
  406081:	mov    %r8,%rcx
  406084:	mov    %rsi,%rbx
  406087:	mov    %r12,%rsi
  40608a:	callq  405e60 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_77_97_112_46_98_105_116_46_103_111_>
  40608f:	mov    %r12,%rdx
  406092:	mov    %rbx,%rsi
  406095:	mov    %rdx,(%rsi)
  406098:	mov    %rax,0x8(%rsi)
  40609c:	mov    $0x0,%eax
  4060a1:	pop    %r12
  4060a3:	pop    %rbx
  4060a4:	leaveq 
  4060a5:	retq   

Disassembly of section .fini:
