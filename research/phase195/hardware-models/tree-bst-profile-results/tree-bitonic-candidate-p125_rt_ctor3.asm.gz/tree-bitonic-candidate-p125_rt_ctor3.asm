0000000000421ec0 <p125_rt_ctor3>:
  421ec0:	push   r15
  421ec2:	mov    rax,rdi
  421ec5:	push   r14
  421ec7:	push   r13
  421ec9:	push   r12
  421ecb:	mov    r12,rdx
  421ece:	push   rbp
  421ecf:	push   rbx
  421ed0:	mov    ebx,esi
  421ed2:	sub    rsp,0x18
  421ed6:	mov    r14,QWORD PTR [rax+0x8]
  421eda:	mov    rdi,QWORD PTR [rdi]
  421edd:	mov    r13,QWORD PTR [r14+0x10]
  421ee1:	test   r13,r13
  421ee4:	je     405085 <p125_rt_ctor3.cold>
  421eea:	mov    rax,QWORD PTR [rdi+r13*8]
  421eee:	sub    QWORD PTR [r14+0x110],0x4
  421ef6:	mov    QWORD PTR [r14+0x10],rax
  421efa:	mov    rax,QWORD PTR [rip+0x108dcf]        # 52acd0 <p111_program_active>
  421f01:	test   BYTE PTR [rax+0x58],0x8
  421f05:	je     421f14 <p125_rt_ctor3+0x54>
  421f07:	mov    rax,QWORD PTR [rax+0x88]
  421f0e:	cmp    BYTE PTR [rax+rbx*1],0x0
  421f12:	je     421f70 <p125_rt_ctor3+0xb0>
  421f14:	lea    r15,[rdi+r13*8]
  421f18:	xor    ebp,ebp
  421f1a:	mov    rdx,QWORD PTR [r12+rbp*1]
  421f1e:	mov    rax,rdx
  421f21:	shr    rax,0x38
  421f25:	and    eax,0x7f
  421f28:	cmp    rax,0x2
  421f2c:	je     421f60 <p125_rt_ctor3+0xa0>
  421f2e:	mov    QWORD PTR [r15+rbp*1],rdx
  421f32:	add    rbp,0x8
  421f36:	cmp    rbp,0x18
  421f3a:	jne    421f1a <p125_rt_ctor3+0x5a>
  421f3c:	mov    rax,rbx
  421f3f:	add    rsp,0x18
  421f43:	shl    rax,0x28
  421f47:	pop    rbx
  421f48:	pop    rbp
  421f49:	or     rax,r13
  421f4c:	pop    r12
  421f4e:	pop    r13
  421f50:	bts    rax,0x39
  421f55:	pop    r14
  421f57:	pop    r15
  421f59:	ret    
  421f5a:	nop    WORD PTR [rax+rax*1+0x0]
  421f60:	test   rdx,rdx
  421f63:	js     421f2e <p125_rt_ctor3+0x6e>
  421f65:	jmp    4050a4 <p125_rt_ctor3.cold+0x1f>
  421f6a:	nop    WORD PTR [rax+rax*1+0x0]
  421f70:	lea    rcx,[rdi+r13*8]
  421f74:	xor    eax,eax
  421f76:	mov    rdx,QWORD PTR [r12+rax*1]
  421f7a:	mov    QWORD PTR [rcx+rax*1],rdx
  421f7e:	add    rax,0x8
  421f82:	cmp    rax,0x18
  421f86:	jne    421f76 <p125_rt_ctor3+0xb6>
  421f88:	jmp    421f3c <p125_rt_ctor3+0x7c>
  421f8a:	nop    WORD PTR [rax+rax*1+0x0]

