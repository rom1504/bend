
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ec0 <nx_rt_rebuild2>:
  402ec0:	push   %r15
  402ec2:	push   %r14
  402ec4:	push   %r13
  402ec6:	mov    %ecx,%r13d
  402ec9:	push   %r12
  402ecb:	mov    %rdi,%r12
  402ece:	push   %rbp
  402ecf:	movabs $0xffffffffff,%rbp
  402ed9:	push   %rbx
  402eda:	and    %rsi,%rbp
  402edd:	mov    %edx,%ebx
  402edf:	lea    0x0(,%rbp,8),%rdx
  402ee7:	sub    $0x28,%rsp
  402eeb:	mov    (%rdi),%r14
  402eee:	mov    0x8(%rdi),%r15
  402ef2:	lea    (%r14,%rdx,1),%rax
  402ef6:	test   %rsi,%rsi
  402ef9:	js     402fe0 <nx_rt_rebuild2+0x120>
  402eff:	mov    (%rax),%rax
  402f02:	mov    %rax,0x10(%rsp)
  402f07:	mov    0x8(%r14,%rdx,1),%rax
  402f0c:	mov    %rax,0x18(%rsp)
  402f11:	cmp    $0x310817f,%rbp
  402f18:	jbe    402fb8 <nx_rt_rebuild2+0xf8>
  402f1e:	lea    (%r14,%rbp,8),%r9
  402f22:	mov    $0x1,%eax
  402f27:	mov    0x10(%rsp,%r13,8),%rdx
  402f2c:	movq   $0xffffffffffffffff,0x18(%r12)
  402f35:	movl   $0x1,0x20(%r12)
  402f3e:	sub    %r13d,%eax
  402f41:	mov    0x10(%rsp,%rax,8),%rax
  402f46:	mov    %rax,0x10(%r12)
  402f4b:	mov    %rdx,%rax
  402f4e:	shr    $0x38,%rax
  402f52:	and    $0x7f,%eax
  402f55:	cmp    $0x2,%rax
  402f59:	je     402f98 <nx_rt_rebuild2+0xd8>
  402f5b:	mov    %r8,%rax
  402f5e:	mov    %rdx,(%r9)
  402f61:	lea    0x8(%r14,%rbp,8),%r12
  402f66:	shr    $0x38,%rax
  402f6a:	and    $0x7f,%eax
  402f6d:	cmp    $0x2,%rax
  402f71:	je     402fa8 <nx_rt_rebuild2+0xe8>
  402f73:	mov    %rbx,%rax
  402f76:	mov    %r8,(%r12)
  402f7a:	add    $0x28,%rsp
  402f7e:	shl    $0x28,%rax
  402f82:	pop    %rbx
  402f83:	or     %rbp,%rax
  402f86:	pop    %rbp
  402f87:	pop    %r12
  402f89:	bts    $0x39,%rax
  402f8e:	pop    %r13
  402f90:	pop    %r14
  402f92:	pop    %r15
  402f94:	retq   
  402f95:	nopl   (%rax)
  402f98:	test   %rdx,%rdx
  402f9b:	js     402f5b <nx_rt_rebuild2+0x9b>
  402f9d:	jmpq   401640 <nx_rt_rebuild2.cold>
  402fa2:	nopw   0x0(%rax,%rax,1)
  402fa8:	test   %r8,%r8
  402fab:	js     402f73 <nx_rt_rebuild2+0xb3>
  402fad:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  402fb2:	nopw   0x0(%rax,%rax,1)
  402fb8:	mov    0x8(%r15),%rbp
  402fbc:	test   %rbp,%rbp
  402fbf:	je     401685 <nx_rt_rebuild2.cold+0x45>
  402fc5:	lea    (%r14,%rbp,8),%r9
  402fc9:	mov    (%r9),%rax
  402fcc:	subq   $0x2,0x108(%r15)
  402fd4:	mov    %rax,0x8(%r15)
  402fd8:	jmpq   402f22 <nx_rt_rebuild2+0x62>
  402fdd:	nopl   (%rax)
  402fe0:	mov    0x4(%rax),%edx
  402fe3:	mov    (%rax),%ecx
  402fe5:	shl    $0x20,%rdx
  402fe9:	or     %rcx,%rdx
  402fec:	mov    %rdx,%rcx
  402fef:	and    $0xffffff,%edx
  402ff5:	shr    $0x18,%rcx
  402ff9:	lea    0x0(,%rcx,8),%rdi
  403001:	lea    (%r14,%rdi,1),%r9
  403005:	lea    0x8(%r14,%rdi,1),%rdi
  40300a:	cmp    $0x1,%rdx
  40300e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403014:	mov    (%rax),%edx
  403016:	mov    (%r9),%rdx
  403019:	mov    %rdx,0x10(%rsp)
  40301e:	mov    (%rdi),%rdx
  403021:	mov    %rdx,0x18(%rsp)
  403026:	mov    (%r15),%rdx
  403029:	mov    %rdx,(%rax)
  40302c:	mov    0x100(%r15),%rax
  403033:	mov    0x3e19f(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403039:	mov    %rbp,(%r15)
  40303c:	add    $0x1,%rax
  403040:	mov    %rax,0x100(%r15)
  403047:	cmp    %rdx,%rax
  40304a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  403050:	mov    %rcx,%rbp
  403053:	jmpq   402f11 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
