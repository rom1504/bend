
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404130 <nx_rt_pair_rebuild2_c3_k0>:
  404130:	push   %r15
  404132:	push   %r14
  404134:	push   %r13
  404136:	push   %r12
  404138:	mov    %rdx,%r12
  40413b:	push   %rbp
  40413c:	push   %rbx
  40413d:	movabs $0xffffffffff,%rbx
  404147:	and    %rsi,%rbx
  40414a:	lea    0x0(,%rbx,8),%rdx
  404152:	sub    $0x18,%rsp
  404156:	mov    (%rdi),%rbp
  404159:	mov    0x8(%rdi),%r15
  40415d:	lea    0x0(%rbp,%rdx,1),%rax
  404162:	test   %rsi,%rsi
  404165:	js     404220 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  40416b:	mov    (%rax),%r14
  40416e:	mov    0x8(%rbp,%rdx,1),%r13
  404173:	cmp    $0x310817f,%rbx
  40417a:	jbe    4041f0 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  40417c:	lea    0x0(%rbp,%rbx,8),%r8
  404181:	mov    %r14,%rax
  404184:	shr    $0x38,%rax
  404188:	and    $0x7f,%eax
  40418b:	cmp    $0x2,%rax
  40418f:	je     4041d0 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  404191:	mov    %r12,%rax
  404194:	mov    %r14,(%r8)
  404197:	lea    0x8(%rbp,%rbx,8),%r14
  40419c:	shr    $0x38,%rax
  4041a0:	and    $0x7f,%eax
  4041a3:	cmp    $0x2,%rax
  4041a7:	je     4041e0 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  4041a9:	movabs $0x200030000000000,%rax
  4041b3:	mov    %r12,(%r14)
  4041b6:	mov    %r13,%rdx
  4041b9:	add    $0x18,%rsp
  4041bd:	or     %rbx,%rax
  4041c0:	pop    %rbx
  4041c1:	pop    %rbp
  4041c2:	pop    %r12
  4041c4:	pop    %r13
  4041c6:	pop    %r14
  4041c8:	pop    %r15
  4041ca:	retq   
  4041cb:	nopl   0x0(%rax,%rax,1)
  4041d0:	test   %r14,%r14
  4041d3:	js     404191 <nx_rt_pair_rebuild2_c3_k0+0x61>
  4041d5:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  4041da:	nopw   0x0(%rax,%rax,1)
  4041e0:	test   %r12,%r12
  4041e3:	js     4041a9 <nx_rt_pair_rebuild2_c3_k0+0x79>
  4041e5:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  4041ea:	nopw   0x0(%rax,%rax,1)
  4041f0:	mov    0x8(%r15),%rbx
  4041f4:	test   %rbx,%rbx
  4041f7:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  4041fd:	lea    0x0(%rbp,%rbx,8),%r8
  404202:	mov    (%r8),%rax
  404205:	subq   $0x2,0x108(%r15)
  40420d:	mov    %rax,0x8(%r15)
  404211:	jmpq   404181 <nx_rt_pair_rebuild2_c3_k0+0x51>
  404216:	nopw   %cs:0x0(%rax,%rax,1)
  404220:	mov    0x4(%rax),%edx
  404223:	mov    (%rax),%ecx
  404225:	shl    $0x20,%rdx
  404229:	or     %rcx,%rdx
  40422c:	mov    %rdx,%rcx
  40422f:	and    $0xffffff,%edx
  404235:	shr    $0x18,%rcx
  404239:	lea    0x8(,%rcx,8),%rdi
  404241:	lea    0x0(%rbp,%rdi,1),%r8
  404246:	lea    -0x8(%rbp,%rdi,1),%rdi
  40424b:	cmp    $0x1,%rdx
  40424f:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  404255:	mov    (%rax),%edx
  404257:	mov    (%r15),%rdx
  40425a:	mov    (%rdi),%r14
  40425d:	mov    (%r8),%r13
  404260:	mov    %rdx,(%rax)
  404263:	mov    0x100(%r15),%rax
  40426a:	mov    0x3df68(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404270:	mov    %rbx,(%r15)
  404273:	add    $0x1,%rax
  404277:	mov    %rax,0x100(%r15)
  40427e:	cmp    %rdx,%rax
  404281:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  404287:	mov    %rcx,%rbx
  40428a:	jmpq   404173 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
