
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004021f0 <nx_rt_id>:
  4021f0:	cmpb   $0x0,0x4f89(%rip)        # 407180 <nx_active>
  4021f7:	je     402205 <nx_rt_id+0x15>
  4021f9:	lea    0x4fa0(%rip),%rax        # 4071a0 <nx_context>
  402200:	cmp    %rax,%rdi
  402203:	je     402218 <nx_rt_id+0x28>
  402205:	push   %rax
  402206:	lea    0x1e26(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  40220d:	callq  4019d0 <err_fail>
  402212:	nopw   0x0(%rax,%rax,1)
  402218:	mov    0x4f81(%rip),%rdi        # 4071a0 <nx_context>
  40221f:	jmpq   401b00 <nx_id.isra.0>

Disassembly of section .fini:
