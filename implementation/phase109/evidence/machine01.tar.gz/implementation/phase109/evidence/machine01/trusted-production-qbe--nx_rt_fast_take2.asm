
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403270 <nx_rt_fast_take2>:
  403270:	endbr64 
  403274:	push   %rbp
  403275:	mov    %rsp,%rbp
  403278:	callq  402fa0 <nx_take2>
  40327d:	mov    $0x0,%eax
  403282:	leaveq 
  403283:	retq   

Disassembly of section .fini:
