
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401900 <nx_string_reverse>:
  401900:	endbr64 
  401904:	push   %rbp
  401905:	mov    %rsp,%rbp
  401908:	sub    $0x8,%rsp
  40190c:	push   %rbx
  40190d:	push   %r12
  40190f:	push   %r13
  401911:	mov    %rdx,%rax
  401914:	mov    %rax,%r13
  401917:	nopw   0x0(%rax,%rax,1)
  401920:	mov    %rsi,%r12
  401923:	mov    %rdi,%rbx
  401926:	callq  4026f0 <nx_rt_fast_id>
  40192b:	mov    %r13,%rdx
  40192e:	mov    %r12,%rsi
  401931:	mov    %rbx,%rdi
  401934:	cmp    $0x2,%eax
  401937:	je     401980 <nx_string_reverse+0x80>
  401939:	cmp    $0x3,%eax
  40193c:	jne    401974 <nx_string_reverse+0x74>
  40193e:	mov    %rdx,%r8
  401941:	mov    $0x0,%ecx
  401946:	mov    $0x3,%edx
  40194b:	mov    %rdi,%rbx
  40194e:	callq  4029c0 <nx_rt_rebuild2>
  401953:	mov    %rbx,%rdi
  401956:	mov    %rax,%r12
  401959:	mov    $0x0,%esi
  40195e:	mov    %rdi,%rbx
  401961:	callq  4029a0 <nx_rt_fast_field>
  401966:	mov    %r12,%rdx
  401969:	mov    %rbx,%rdi
  40196c:	mov    %rax,%rsi
  40196f:	mov    %rdx,%r13
  401972:	jmp    401920 <nx_string_reverse+0x20>
  401974:	mov    $0x1,%esi
  401979:	callq  4021f0 <nx_rt_fail>
  40197e:	jmp    401983 <nx_string_reverse+0x83>
  401980:	mov    %rdx,%rax
  401983:	pop    %r13
  401985:	pop    %r12
  401987:	pop    %rbx
  401988:	leaveq 
  401989:	retq   

Disassembly of section .fini:
