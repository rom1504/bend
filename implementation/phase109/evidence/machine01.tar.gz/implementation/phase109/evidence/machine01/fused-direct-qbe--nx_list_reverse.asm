
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401870 <nx_list_reverse>:
  401870:	endbr64 
  401874:	push   %rbp
  401875:	mov    %rsp,%rbp
  401878:	sub    $0x8,%rsp
  40187c:	push   %rbx
  40187d:	push   %r12
  40187f:	push   %r13
  401881:	mov    %rdx,%rax
  401884:	mov    %rax,%r13
  401887:	nopw   0x0(%rax,%rax,1)
  401890:	mov    %rsi,%r12
  401893:	mov    %rdi,%rbx
  401896:	callq  4026f0 <nx_rt_fast_id>
  40189b:	mov    %r13,%rdx
  40189e:	mov    %r12,%rsi
  4018a1:	mov    %rbx,%rdi
  4018a4:	cmp    $0x0,%eax
  4018a7:	je     4018f0 <nx_list_reverse+0x80>
  4018a9:	cmp    $0x1,%eax
  4018ac:	jne    4018e4 <nx_list_reverse+0x74>
  4018ae:	mov    %rdx,%r8
  4018b1:	mov    $0x0,%ecx
  4018b6:	mov    $0x1,%edx
  4018bb:	mov    %rdi,%rbx
  4018be:	callq  4029c0 <nx_rt_rebuild2>
  4018c3:	mov    %rbx,%rdi
  4018c6:	mov    %rax,%r12
  4018c9:	mov    $0x0,%esi
  4018ce:	mov    %rdi,%rbx
  4018d1:	callq  4029a0 <nx_rt_fast_field>
  4018d6:	mov    %r12,%rdx
  4018d9:	mov    %rbx,%rdi
  4018dc:	mov    %rax,%rsi
  4018df:	mov    %rdx,%r13
  4018e2:	jmp    401890 <nx_list_reverse+0x20>
  4018e4:	mov    $0x1,%esi
  4018e9:	callq  4021f0 <nx_rt_fail>
  4018ee:	jmp    4018f3 <nx_list_reverse+0x83>
  4018f0:	mov    %rdx,%rax
  4018f3:	pop    %r13
  4018f5:	pop    %r12
  4018f7:	pop    %rbx
  4018f8:	leaveq 
  4018f9:	retq   

Disassembly of section .fini:
