    97e0:	push   %rax
    97e1:	mov    %rcx,%r9
    97e4:	mov    %rdx,%r8
    97e7:	mov    %rsi,%rcx
    97ea:	mov    %rsp,%rdx
    97ed:	mov    %r12,%rdi
    97f0:	mov    %r13,%rsi
    97f3:	callq  f400 <NF_FID_112_49_57_52_46_107_101_114_110_101_108_>
    97f8:	test   %rax,%rax
    97fb:	je     981c <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x3c>
    97fd:	mov    (%rsp),%rsi
    9801:	mov    -0x8(%r14),%eax
    9805:	add    $0xfffffffffffffff8,%r14
    9809:	lea    0xa1a0(%rip),%rcx        # 139b0 <wl_tab>
    9810:	mov    (%rcx,%rax,8),%rax
    9814:	mov    $0x1,%edi
    9819:	pop    %rcx
    981a:	jmpq   *%rax
    981c:	xor    %eax,%eax
    981e:	pop    %rcx
    981f:	retq   
