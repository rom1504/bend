
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004033c0 <nx_string_reverse>:
  4033c0:	push   %r15
  4033c2:	lea    0x4dd7(%rip),%rax        # 4081a0 <nx_context>
  4033c9:	push   %r14
  4033cb:	push   %r13
  4033cd:	push   %r12
  4033cf:	push   %rbp
  4033d0:	push   %rbx
  4033d1:	sub    $0x18,%rsp
  4033d5:	cmp    %rdi,%rax
  4033d8:	jne    4033e3 <nx_string_reverse+0x23>
  4033da:	cmpb   $0x0,0x4d9f(%rip)        # 408180 <nx_active>
  4033e1:	jne    4033f0 <nx_string_reverse+0x30>
  4033e3:	lea    0x1c49(%rip),%rdi        # 405033 <_IO_stdin_used+0x33>
  4033ea:	callq  401ac0 <err_fail>
  4033ef:	nop
  4033f0:	mov    %rsi,%rax
  4033f3:	mov    %rdx,%r14
  4033f6:	mov    0x4da3(%rip),%r12        # 4081a0 <nx_context>
  4033fd:	mov    %rsi,%r13
  403400:	shr    $0x28,%rax
  403404:	mov    0x4d9d(%rip),%rbp        # 4081a8 <nx_context+0x8>
  40340b:	movzwl %ax,%edx
  40340e:	cmp    $0x2,%ax
  403412:	je     4035b5 <nx_string_reverse+0x1f5>
  403418:	cmp    $0x3,%rdx
  40341c:	jne    4035c7 <nx_string_reverse+0x207>
  403422:	movabs $0xffffffffff,%r9
  40342c:	movabs $0x200030000000000,%r8
  403436:	jmp    403483 <nx_string_reverse+0xc3>
  403438:	nopl   0x0(%rax,%rax,1)
  403440:	mov    %r14,%rax
  403443:	mov    %r10,(%r15)
  403446:	lea    0x8(%r12,%rbx,8),%r15
  40344b:	shr    $0x38,%rax
  40344f:	and    $0x7f,%eax
  403452:	cmp    $0x2,%rax
  403456:	je     403500 <nx_string_reverse+0x140>
  40345c:	mov    %r13,%rax
  40345f:	or     %r8,%rbx
  403462:	mov    %r14,(%r15)
  403465:	shr    $0x28,%rax
  403469:	mov    %rbx,%r14
  40346c:	movzwl %ax,%edx
  40346f:	cmp    $0x2,%ax
  403473:	je     4035b5 <nx_string_reverse+0x1f5>
  403479:	cmp    $0x3,%rdx
  40347d:	jne    4035c7 <nx_string_reverse+0x207>
  403483:	mov    %r13,%rax
  403486:	and    %r9,%rax
  403489:	lea    0x0(,%rax,8),%rcx
  403491:	lea    (%r12,%rcx,1),%rdx
  403495:	test   %r13,%r13
  403498:	js     403548 <nx_string_reverse+0x188>
  40349e:	mov    (%rdx),%r10
  4034a1:	mov    0x8(%r12,%rcx,1),%r13
  4034a6:	mov    0x8(%rbp),%rbx
  4034aa:	cmp    $0x310817f,%rax
  4034b0:	ja     403510 <nx_string_reverse+0x150>
  4034b2:	test   %rbx,%rbx
  4034b5:	je     4018dc <nx_string_reverse.cold+0x108>
  4034bb:	mov    0x108(%rbp),%rax
  4034c2:	lea    (%r12,%rbx,8),%r15
  4034c6:	lea    -0x2(%rax),%rdx
  4034ca:	mov    (%r15),%rax
  4034cd:	mov    %rdx,0x108(%rbp)
  4034d4:	mov    %rax,0x8(%rbp)
  4034d8:	mov    %r10,%rax
  4034db:	shr    $0x38,%rax
  4034df:	and    $0x7f,%eax
  4034e2:	cmp    $0x2,%rax
  4034e6:	jne    403440 <nx_string_reverse+0x80>
  4034ec:	test   %r10,%r10
  4034ef:	js     403440 <nx_string_reverse+0x80>
  4034f5:	jmpq   4018ad <nx_string_reverse.cold+0xd9>
  4034fa:	nopw   0x0(%rax,%rax,1)
  403500:	test   %r14,%r14
  403503:	js     40345c <nx_string_reverse+0x9c>
  403509:	jmpq   40187e <nx_string_reverse.cold+0xaa>
  40350e:	xchg   %ax,%ax
  403510:	lea    (%r12,%rax,8),%r15
  403514:	mov    0x4cbe(%rip),%esi        # 4081d8 <KEEP_WORDS>
  40351a:	mov    %rbx,(%r15)
  40351d:	mov    0x108(%rbp),%rdx
  403524:	mov    %rax,0x8(%rbp)
  403528:	lea    0x2(%rdx),%rcx
  40352c:	mov    %rcx,0x108(%rbp)
  403533:	cmp    %rsi,%rcx
  403536:	jae    401847 <nx_string_reverse.cold+0x73>
  40353c:	mov    %rax,%rbx
  40353f:	jmp    4034ca <nx_string_reverse+0x10a>
  403541:	nopl   0x0(%rax)
  403548:	mov    0x4(%rdx),%ecx
  40354b:	mov    (%rdx),%esi
  40354d:	shl    $0x20,%rcx
  403551:	or     %rsi,%rcx
  403554:	mov    %rcx,%rbx
  403557:	and    $0xffffff,%ecx
  40355d:	shr    $0x18,%rbx
  403561:	lea    0x8(,%rbx,8),%rsi
  403569:	lea    (%r12,%rsi,1),%rdi
  40356d:	cmp    $0x1,%rcx
  403571:	jne    4017d4 <nx_string_reverse.cold>
  403577:	mov    (%rdx),%ecx
  403579:	mov    0x0(%rbp),%rcx
  40357d:	mov    -0x8(%r12,%rsi,1),%r10
  403582:	mov    (%rdi),%r13
  403585:	mov    %rcx,(%rdx)
  403588:	mov    0x4c4a(%rip),%edx        # 4081d8 <KEEP_WORDS>
  40358e:	mov    %rax,0x0(%rbp)
  403592:	mov    0x100(%rbp),%rax
  403599:	add    $0x1,%rax
  40359d:	mov    %rax,0x100(%rbp)
  4035a4:	cmp    %rdx,%rax
  4035a7:	jae    401817 <nx_string_reverse.cold+0x43>
  4035ad:	mov    %rbx,%rax
  4035b0:	jmpq   4034a6 <nx_string_reverse+0xe6>
  4035b5:	add    $0x18,%rsp
  4035b9:	mov    %r14,%rax
  4035bc:	pop    %rbx
  4035bd:	pop    %rbp
  4035be:	pop    %r12
  4035c0:	pop    %r13
  4035c2:	pop    %r14
  4035c4:	pop    %r15
  4035c6:	retq   
  4035c7:	mov    %r13,%rax
  4035ca:	shr    $0x38,%rax
  4035ce:	test   $0x7e,%al
  4035d0:	je     4035fb <nx_string_reverse+0x23b>
  4035d2:	cmp    $0xffffffffffffffff,%r13
  4035d6:	je     4035fb <nx_string_reverse+0x23b>
  4035d8:	movabs $0xffffffffff,%rax
  4035e2:	and    %r13,%rax
  4035e5:	cmp    $0x310817f,%rax
  4035eb:	jbe    4035fb <nx_string_reverse+0x23b>
  4035ed:	mov    %r13,%rdx
  4035f0:	mov    %r12,%rdi
  4035f3:	mov    %rbp,%rsi
  4035f6:	callq  401e10 <term_drop>
  4035fb:	mov    %r14,%rax
  4035fe:	shr    $0x38,%rax
  403602:	test   $0x7e,%al
  403604:	je     40362f <nx_string_reverse+0x26f>
  403606:	cmp    $0xffffffffffffffff,%r14
  40360a:	je     40362f <nx_string_reverse+0x26f>
  40360c:	movabs $0xffffffffff,%rax
  403616:	and    %r14,%rax
  403619:	cmp    $0x310817f,%rax
  40361f:	jbe    40362f <nx_string_reverse+0x26f>
  403621:	mov    %r14,%rdx
  403624:	mov    %r12,%rdi
  403627:	mov    %rbp,%rsi
  40362a:	callq  401e10 <term_drop>
  40362f:	lea    0x1e82(%rip),%rdi        # 4054b8 <_IO_stdin_used+0x4b8>
  403636:	callq  401ac0 <err_fail>

Disassembly of section .fini:
