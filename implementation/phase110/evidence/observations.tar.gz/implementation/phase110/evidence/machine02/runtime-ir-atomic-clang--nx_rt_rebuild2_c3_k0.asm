
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403fc0 <nx_rt_rebuild2_c3_k0>:
  403fc0:	push   %r15
  403fc2:	push   %r14
  403fc4:	push   %r13
  403fc6:	push   %r12
  403fc8:	mov    %rdx,%r12
  403fcb:	push   %rbp
  403fcc:	mov    %rdi,%rbp
  403fcf:	push   %rbx
  403fd0:	movabs $0xffffffffff,%rbx
  403fda:	and    %rsi,%rbx
  403fdd:	lea    0x0(,%rbx,8),%rdx
  403fe5:	sub    $0x18,%rsp
  403fe9:	mov    (%rdi),%r13
  403fec:	mov    0x8(%rdi),%r15
  403ff0:	lea    0x0(%r13,%rdx,1),%rax
  403ff5:	test   %rsi,%rsi
  403ff8:	js     4040c0 <nx_rt_rebuild2_c3_k0+0x100>
  403ffe:	mov    (%rax),%r14
  404001:	mov    0x8(%r13,%rdx,1),%r9
  404006:	cmp    $0x310817f,%rbx
  40400d:	jbe    404098 <nx_rt_rebuild2_c3_k0+0xd8>
  404013:	lea    0x0(%r13,%rbx,8),%r8
  404018:	mov    %r14,%rax
  40401b:	mov    %r9,0x10(%rbp)
  40401f:	shr    $0x38,%rax
  404023:	movq   $0xffffffffffffffff,0x18(%rbp)
  40402b:	and    $0x7f,%eax
  40402e:	movl   $0x1,0x20(%rbp)
  404035:	cmp    $0x2,%rax
  404039:	je     404078 <nx_rt_rebuild2_c3_k0+0xb8>
  40403b:	mov    %r12,%rax
  40403e:	mov    %r14,(%r8)
  404041:	lea    0x8(%r13,%rbx,8),%rbp
  404046:	shr    $0x38,%rax
  40404a:	and    $0x7f,%eax
  40404d:	cmp    $0x2,%rax
  404051:	je     404088 <nx_rt_rebuild2_c3_k0+0xc8>
  404053:	movabs $0x200030000000000,%rax
  40405d:	mov    %r12,0x0(%rbp)
  404061:	add    $0x18,%rsp
  404065:	or     %rbx,%rax
  404068:	pop    %rbx
  404069:	pop    %rbp
  40406a:	pop    %r12
  40406c:	pop    %r13
  40406e:	pop    %r14
  404070:	pop    %r15
  404072:	retq   
  404073:	nopl   0x0(%rax,%rax,1)
  404078:	test   %r14,%r14
  40407b:	js     40403b <nx_rt_rebuild2_c3_k0+0x7b>
  40407d:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  404082:	nopw   0x0(%rax,%rax,1)
  404088:	test   %r12,%r12
  40408b:	js     404053 <nx_rt_rebuild2_c3_k0+0x93>
  40408d:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  404092:	nopw   0x0(%rax,%rax,1)
  404098:	mov    0x8(%r15),%rbx
  40409c:	test   %rbx,%rbx
  40409f:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  4040a5:	lea    0x0(%r13,%rbx,8),%r8
  4040aa:	mov    (%r8),%rax
  4040ad:	subq   $0x2,0x108(%r15)
  4040b5:	mov    %rax,0x8(%r15)
  4040b9:	jmpq   404018 <nx_rt_rebuild2_c3_k0+0x58>
  4040be:	xchg   %ax,%ax
  4040c0:	mov    0x4(%rax),%edx
  4040c3:	mov    (%rax),%ecx
  4040c5:	shl    $0x20,%rdx
  4040c9:	or     %rcx,%rdx
  4040cc:	mov    %rdx,%rcx
  4040cf:	and    $0xffffff,%edx
  4040d5:	shr    $0x18,%rcx
  4040d9:	lea    0x8(,%rcx,8),%rdi
  4040e1:	lea    0x0(%r13,%rdi,1),%r8
  4040e6:	lea    -0x8(%r13,%rdi,1),%rdi
  4040eb:	cmp    $0x1,%rdx
  4040ef:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  4040f5:	mov    (%rax),%edx
  4040f7:	mov    (%r15),%rdx
  4040fa:	mov    (%rdi),%r14
  4040fd:	mov    (%r8),%r9
  404100:	mov    %rdx,(%rax)
  404103:	mov    0x100(%r15),%rax
  40410a:	mov    0x3e0c8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404110:	mov    %rbx,(%r15)
  404113:	add    $0x1,%rax
  404117:	mov    %rax,0x100(%r15)
  40411e:	cmp    %rdx,%rax
  404121:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  404127:	mov    %rcx,%rbx
  40412a:	jmpq   404006 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
