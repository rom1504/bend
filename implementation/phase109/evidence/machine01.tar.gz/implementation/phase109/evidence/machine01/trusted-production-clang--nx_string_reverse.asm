
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402bc0 <nx_string_reverse>:
  402bc0:	push   %rbp
  402bc1:	push   %r15
  402bc3:	push   %r14
  402bc5:	push   %r13
  402bc7:	push   %r12
  402bc9:	push   %rbx
  402bca:	push   %rax
  402bcb:	lea    0x45b6(%rip),%rax        # 407188 <nx_context>
  402bd2:	cmp    %rax,%rdi
  402bd5:	jne    402ebc <nx_string_reverse+0x2fc>
  402bdb:	testb  $0x1,0x459e(%rip)        # 407180 <nx_active>
  402be2:	je     402ebc <nx_string_reverse+0x2fc>
  402be8:	mov    %rdx,%rbx
  402beb:	mov    %rsi,%r8
  402bee:	movabs $0xff00000000000000,%r13
  402bf8:	movabs $0xffffffff80,%rax
  402c02:	mov    0x457f(%rip),%r14        # 407188 <nx_context>
  402c09:	mov    0x4580(%rip),%r15        # 407190 <nx_context+0x8>
  402c10:	lea    0x7f(%rax),%rdi
  402c14:	movabs $0x200000000000000,%r12
  402c1e:	movabs $0x200030000000000,%rbp
  402c28:	mov    %rdi,(%rsp)
  402c2c:	jmp    402c3b <nx_string_reverse+0x7b>
  402c2e:	xchg   %ax,%ax
  402c30:	mov    %rbx,0x8(%r14,%r10,8)
  402c35:	or     %rbp,%r10
  402c38:	mov    %r10,%rbx
  402c3b:	mov    %r8,%rax
  402c3e:	shr    $0x28,%rax
  402c42:	cmp    $0x3,%ax
  402c46:	jne    402e1b <nx_string_reverse+0x25b>
  402c4c:	mov    %r8,%rax
  402c4f:	and    %rdi,%rax
  402c52:	test   %r8,%r8
  402c55:	js     402c80 <nx_string_reverse+0xc0>
  402c57:	mov    (%r14,%rax,8),%r9
  402c5b:	mov    0x8(%r14,%rax,8),%r8
  402c60:	mov    %rax,%rcx
  402c63:	cmp    $0x3108180,%rcx
  402c6a:	jae    402cef <nx_string_reverse+0x12f>
  402c70:	jmpq   402d26 <nx_string_reverse+0x166>
  402c75:	data16 nopw %cs:0x0(%rax,%rax,1)
  402c80:	mov    0x4(%r14,%rax,8),%ecx
  402c85:	mov    (%r14,%rax,8),%edx
  402c89:	mov    %edx,%esi
  402c8b:	and    $0xffffff,%esi
  402c91:	cmp    $0x1,%esi
  402c94:	jne    402dca <nx_string_reverse+0x20a>
  402c9a:	mov    (%r14,%rax,8),%esi
  402c9e:	shl    $0x20,%rcx
  402ca2:	or     %rdx,%rcx
  402ca5:	shr    $0x18,%rcx
  402ca9:	mov    (%r14,%rcx,8),%r9
  402cad:	mov    0x8(%r14,%rcx,8),%r8
  402cb2:	mov    (%r15),%rdx
  402cb5:	mov    %rdx,(%r14,%rax,8)
  402cb9:	mov    %rax,(%r15)
  402cbc:	mov    0x100(%r15),%rax
  402cc3:	inc    %rax
  402cc6:	mov    %rax,0x100(%r15)
  402ccd:	cmpb   $0x1,0x1c82c(%rip)        # 41f500 <KEEP_WORDS>
  402cd4:	jne    402df8 <nx_string_reverse+0x238>
  402cda:	cmp    $0x8000,%rax
  402ce0:	jae    402df8 <nx_string_reverse+0x238>
  402ce6:	cmp    $0x3108180,%rcx
  402ced:	jb     402d26 <nx_string_reverse+0x166>
  402cef:	mov    0x8(%r15),%rax
  402cf3:	mov    %rax,(%r14,%rcx,8)
  402cf7:	mov    %rcx,0x8(%r15)
  402cfb:	mov    0x108(%r15),%rax
  402d02:	add    $0x2,%rax
  402d06:	mov    %rax,0x108(%r15)
  402d0d:	cmpb   $0x1,0x1c7ec(%rip)        # 41f500 <KEEP_WORDS>
  402d14:	jne    402db1 <nx_string_reverse+0x1f1>
  402d1a:	cmp    $0x8000,%rax
  402d20:	jae    402db1 <nx_string_reverse+0x1f1>
  402d26:	mov    0x8(%r15),%r10
  402d2a:	test   %r10,%r10
  402d2d:	je     402d7c <nx_string_reverse+0x1bc>
  402d2f:	mov    (%r14,%r10,8),%rax
  402d33:	mov    %rax,0x8(%r15)
  402d37:	addq   $0xfffffffffffffffe,0x108(%r15)
  402d3f:	mov    %r9,%rax
  402d42:	and    %r13,%rax
  402d45:	cmp    %r12,%rax
  402d48:	je     402d95 <nx_string_reverse+0x1d5>
  402d4a:	mov    %r9,(%r14,%r10,8)
  402d4e:	mov    %rbx,%rax
  402d51:	and    %r13,%rax
  402d54:	cmp    %r12,%rax
  402d57:	jne    402c30 <nx_string_reverse+0x70>
  402d5d:	mov    %r14,%rdi
  402d60:	mov    %r15,%rsi
  402d63:	mov    %rbx,%rdx
  402d66:	mov    $0x1,%ecx
  402d6b:	callq  401168 <rfc_wrap>
  402d70:	mov    (%rsp),%rdi
  402d74:	mov    %rax,%rbx
  402d77:	jmpq   402c30 <nx_string_reverse+0x70>
  402d7c:	mov    %r14,%rdi
  402d7f:	mov    %r15,%rsi
  402d82:	mov    $0x1,%edx
  402d87:	callq  401279 <heap_alloc_miss>
  402d8c:	mov    (%rsp),%rdi
  402d90:	mov    %rax,%r10
  402d93:	jmp    402d3f <nx_string_reverse+0x17f>
  402d95:	mov    %r14,%rdi
  402d98:	mov    %r15,%rsi
  402d9b:	mov    %r9,%rdx
  402d9e:	mov    $0x1,%ecx
  402da3:	callq  401168 <rfc_wrap>
  402da8:	mov    (%rsp),%rdi
  402dac:	mov    %rax,%r9
  402daf:	jmp    402d4a <nx_string_reverse+0x18a>
  402db1:	mov    %r14,%rdi
  402db4:	mov    %r15,%rsi
  402db7:	mov    $0x1,%edx
  402dbc:	callq  4011e8 <heap_hand>
  402dc1:	mov    (%rsp),%rdi
  402dc5:	jmpq   402d26 <nx_string_reverse+0x166>
  402dca:	shl    $0x20,%rcx
  402dce:	or     %rdx,%rcx
  402dd1:	shr    $0x18,%rcx
  402dd5:	mov    (%r14,%rcx,8),%r9
  402dd9:	mov    0x8(%r14,%rcx,8),%rax
  402dde:	mov    %r14,%rdi
  402de1:	mov    %r15,%rsi
  402de4:	mov    %r8,%rdx
  402de7:	callq  40157f <span_fade>
  402dec:	mov    (%rsp),%rdi
  402df0:	mov    %rax,%r8
  402df3:	jmpq   402d26 <nx_string_reverse+0x166>
  402df8:	mov    %r14,%rdi
  402dfb:	mov    %r15,%rsi
  402dfe:	xor    %edx,%edx
  402e00:	callq  4011e8 <heap_hand>
  402e05:	mov    (%rsp),%rdi
  402e09:	cmp    $0x3108180,%rcx
  402e10:	jae    402cef <nx_string_reverse+0x12f>
  402e16:	jmpq   402d26 <nx_string_reverse+0x166>
  402e1b:	movzwl %ax,%eax
  402e1e:	cmp    $0x2,%eax
  402e21:	jne    402e35 <nx_string_reverse+0x275>
  402e23:	mov    %rbx,%rax
  402e26:	add    $0x8,%rsp
  402e2a:	pop    %rbx
  402e2b:	pop    %r12
  402e2d:	pop    %r13
  402e2f:	pop    %r14
  402e31:	pop    %r15
  402e33:	pop    %rbp
  402e34:	retq   
  402e35:	movabs $0x7e00000000000000,%r12
  402e3f:	test   %r12,%r8
  402e42:	sete   %al
  402e45:	cmp    $0xffffffffffffffff,%r8
  402e49:	sete   %cl
  402e4c:	or     %al,%cl
  402e4e:	mov    %r8,%rax
  402e51:	movabs $0xffffffff80,%rdx
  402e5b:	and    %rdx,%rax
  402e5e:	cmp    $0x3108180,%rax
  402e64:	setb   %al
  402e67:	or     %cl,%al
  402e69:	jne    402e79 <nx_string_reverse+0x2b9>
  402e6b:	mov    %r14,%rdi
  402e6e:	mov    %r15,%rsi
  402e71:	mov    %r8,%rdx
  402e74:	callq  402ed0 <term_drop>
  402e79:	test   %r12,%rbx
  402e7c:	sete   %al
  402e7f:	cmp    $0xffffffffffffffff,%rbx
  402e83:	sete   %cl
  402e86:	or     %al,%cl
  402e88:	movabs $0xffffffff80,%rax
  402e92:	and    %rbx,%rax
  402e95:	cmp    $0x3108180,%rax
  402e9b:	setb   %al
  402e9e:	or     %cl,%al
  402ea0:	jne    402eb0 <nx_string_reverse+0x2f0>
  402ea2:	mov    %r14,%rdi
  402ea5:	mov    %r15,%rsi
  402ea8:	mov    %rbx,%rdx
  402eab:	callq  402ed0 <term_drop>
  402eb0:	lea    0x14ce(%rip),%rdi        # 404385 <_IO_stdin_used+0x385>
  402eb7:	callq  401130 <err_fail>
  402ebc:	lea    0x1451(%rip),%rdi        # 404314 <_IO_stdin_used+0x314>
  402ec3:	callq  401130 <err_fail>

Disassembly of section .fini:
