
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402480 <nx_rt_build2>:
  402480:	cmpb   $0x0,0x4cf9(%rip)        # 407180 <nx_active>
  402487:	push   %r14
  402489:	push   %r13
  40248b:	push   %r12
  40248d:	push   %rbp
  40248e:	push   %rbx
  40248f:	je     40249d <nx_rt_build2+0x1d>
  402491:	lea    0x4d08(%rip),%rax        # 4071a0 <nx_context>
  402498:	cmp    %rax,%rdi
  40249b:	je     4024b0 <nx_rt_build2+0x30>
  40249d:	lea    0x1b8f(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4024a4:	callq  4019b0 <err_fail>
  4024a9:	nopl   0x0(%rax)
  4024b0:	mov    0x4ce9(%rip),%r14        # 4071a0 <nx_context>
  4024b7:	mov    %esi,%r12d
  4024ba:	mov    %rdx,%r13
  4024bd:	mov    %rcx,%rbx
  4024c0:	mov    0x4ce1(%rip),%rbp        # 4071a8 <nx_context+0x8>
  4024c7:	mov    %r14,%rdi
  4024ca:	callq  401be0 <nx_fields.isra.0>
  4024cf:	mov    0x8(%rbp),%r9
  4024d3:	test   %r9,%r9
  4024d6:	je     402504 <nx_rt_build2+0x84>
  4024d8:	mov    (%r14,%r9,8),%rax
  4024dc:	subq   $0x2,0x108(%rbp)
  4024e4:	mov    %rax,0x8(%rbp)
  4024e8:	mov    %rbx,%r8
  4024eb:	mov    %r13,%rcx
  4024ee:	pop    %rbx
  4024ef:	mov    %r12d,%edx
  4024f2:	mov    %r14,%rdi
  4024f5:	mov    %rbp,%rsi
  4024f8:	pop    %rbp
  4024f9:	pop    %r12
  4024fb:	pop    %r13
  4024fd:	pop    %r14
  4024ff:	jmpq   401c80 <nx_construct2>
  402504:	jmpq   40154f <nx_rt_build2.cold>

Disassembly of section .fini:
