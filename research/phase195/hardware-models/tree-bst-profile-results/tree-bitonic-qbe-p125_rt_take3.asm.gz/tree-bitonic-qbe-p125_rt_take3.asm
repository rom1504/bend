000000000041a460 <p125_rt_take3>:
  41a460:	mov    rax,rsi
  41a463:	mov    r8,QWORD PTR [rip+0x108866]        # 522cd0 <p111_program_active>
  41a46a:	push   r12
  41a46c:	shr    rax,0x28
  41a470:	push   rbp
  41a471:	movzx  eax,ax
  41a474:	push   rbx
  41a475:	cmp    QWORD PTR [r8+0x18],rax
  41a479:	ja     41a490 <p125_rt_take3+0x30>
  41a47b:	lea    rdi,[rip+0xedd]        # 41b35f <_IO_stdin_used+0x35f>
  41a482:	call   410530 <err_fail>
  41a487:	nop    WORD PTR [rax+rax*1+0x0]
  41a490:	mov    rcx,rdx
  41a493:	mov    rdx,QWORD PTR [r8+0x80]
  41a49a:	cmp    BYTE PTR [rdx+rax*1],0x3
  41a49e:	jne    41a47b <p125_rt_take3+0x1b>
  41a4a0:	mov    rax,rsi
  41a4a3:	shr    rax,0x38
  41a4a7:	and    eax,0x7f
  41a4aa:	cmp    rax,0x2
  41a4ae:	jne    41a5eb <p125_rt_take3+0x18b>
  41a4b4:	mov    r9,QWORD PTR [rdi]
  41a4b7:	mov    rbx,rdi
  41a4ba:	movabs rdi,0xffffffffff
  41a4c4:	and    rdi,rsi
  41a4c7:	test   rsi,rsi
  41a4ca:	js     41a560 <p125_rt_take3+0x100>
  41a4d0:	lea    rsi,[r9+rdi*8]
  41a4d4:	xor    eax,eax
  41a4d6:	nop    WORD PTR cs:[rax+rax*1+0x0]
  41a4e0:	mov    rdx,QWORD PTR [rsi+rax*1]
  41a4e4:	mov    QWORD PTR [rcx+rax*1],rdx
  41a4e8:	add    rax,0x8
  41a4ec:	cmp    rax,0x18
  41a4f0:	jne    41a4e0 <p125_rt_take3+0x80>
  41a4f2:	mov    rax,QWORD PTR [r8+0x40]
  41a4f6:	add    rax,0x7f
  41a4fa:	and    rax,0xffffffffffffff80
  41a4fe:	add    rax,0x3108200
  41a504:	cmp    rax,rdi
  41a507:	jbe    41a518 <p125_rt_take3+0xb8>
  41a509:	pop    rbx
  41a50a:	mov    eax,0x3
  41a50f:	pop    rbp
  41a510:	pop    r12
  41a512:	ret    
  41a513:	nop    DWORD PTR [rax+rax*1+0x0]
  41a518:	mov    rsi,QWORD PTR [rbx+0x8]
  41a51c:	mov    r8,QWORD PTR [rbx]
  41a51f:	mov    edx,DWORD PTR [rip+0x10885f]        # 522d84 <KEEP_WORDS>
  41a525:	mov    rax,QWORD PTR [rsi+0x10]
  41a529:	mov    QWORD PTR [r8+rdi*8],rax
  41a52d:	mov    rax,QWORD PTR [rsi+0x110]
  41a534:	mov    QWORD PTR [rsi+0x10],rdi
  41a538:	add    rax,0x4
  41a53c:	mov    QWORD PTR [rsi+0x110],rax
  41a543:	cmp    rax,rdx
  41a546:	jae    40510a <p125_rt_take3.cold+0x37>
  41a54c:	pop    rbx
  41a54d:	mov    eax,0x3
  41a552:	pop    rbp
  41a553:	pop    r12
  41a555:	ret    
  41a556:	nop    WORD PTR cs:[rax+rax*1+0x0]
  41a560:	lea    rbp,[r9+rdi*8]
  41a564:	mov    r11,QWORD PTR [rbx+0x8]
  41a568:	mov    r12d,DWORD PTR [rbp+0x4]
  41a56c:	mov    r10d,DWORD PTR [rbp+0x0]
  41a570:	shl    r12,0x20
  41a574:	or     r12,r10
  41a577:	and    r10d,0xffffff
  41a57e:	cmp    r10,0x1
  41a582:	je     41a5e6 <p125_rt_take3+0x186>
  41a584:	shr    r12,0x18
  41a588:	xor    eax,eax
  41a58a:	lea    r8,[r9+r12*8]
  41a58e:	xchg   ax,ax
  41a590:	mov    rdx,QWORD PTR [r8+rax*1]
  41a594:	mov    QWORD PTR [rcx+rax*1],rdx
  41a598:	add    rax,0x8
  41a59c:	cmp    rax,0x18
  41a5a0:	jne    41a590 <p125_rt_take3+0x130>
  41a5a2:	cmp    r10,0x1
  41a5a6:	jne    4050d3 <p125_rt_take3.cold>
  41a5ac:	mov    rax,QWORD PTR [r11]
  41a5af:	mov    edx,DWORD PTR [rip+0x1087cf]        # 522d84 <KEEP_WORDS>
  41a5b5:	mov    QWORD PTR [rbp+0x0],rax
  41a5b9:	mov    rax,QWORD PTR [r11+0x100]
  41a5c0:	mov    QWORD PTR [r11],rdi
  41a5c3:	add    rax,0x1
  41a5c7:	mov    QWORD PTR [r11+0x100],rax
  41a5ce:	cmp    rax,rdx
  41a5d1:	jae    4050f8 <p125_rt_take3.cold+0x25>
  41a5d7:	mov    r8,QWORD PTR [rip+0x1086f2]        # 522cd0 <p111_program_active>
  41a5de:	mov    rdi,r12
  41a5e1:	jmp    41a4f2 <p125_rt_take3+0x92>
  41a5e6:	mov    eax,DWORD PTR [rbp+0x0]
  41a5e9:	jmp    41a584 <p125_rt_take3+0x124>
  41a5eb:	lea    rdi,[rip+0x192e]        # 41bf20 <_IO_stdin_used+0xf20>
  41a5f2:	call   410530 <err_fail>
  41a5f7:	nop    WORD PTR [rax+rax*1+0x0]

