
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404500 <nx_rt_pair_take2>:
  404500:	movabs $0xffffffffff,%rax
  40450a:	push   %r15
  40450c:	and    %rsi,%rax
  40450f:	push   %r14
  404511:	push   %r13
  404513:	lea    0x0(,%rax,8),%rdx
  40451b:	push   %r12
  40451d:	push   %rbp
  40451e:	mov    (%rdi),%rbp
  404521:	mov    0x8(%rdi),%r14
  404525:	lea    0x0(%rbp,%rdx,1),%rcx
  40452a:	test   %rsi,%rsi
  40452d:	js     404590 <nx_rt_pair_take2+0x90>
  40452f:	mov    (%rcx),%r13
  404532:	mov    0x8(%rbp,%rdx,1),%r12
  404537:	cmp    $0x310817f,%rax
  40453d:	ja     404550 <nx_rt_pair_take2+0x50>
  40453f:	pop    %rbp
  404540:	mov    %r13,%rax
  404543:	mov    %r12,%rdx
  404546:	pop    %r12
  404548:	pop    %r13
  40454a:	pop    %r14
  40454c:	pop    %r15
  40454e:	retq   
  40454f:	nop
  404550:	mov    0x8(%r14),%rdx
  404554:	mov    %rdx,0x0(%rbp,%rax,8)
  404559:	mov    0x3dc79(%rip),%edx        # 4421d8 <KEEP_WORDS>
  40455f:	mov    %rax,0x8(%r14)
  404563:	mov    0x108(%r14),%rax
  40456a:	add    $0x2,%rax
  40456e:	mov    %rax,0x108(%r14)
  404575:	cmp    %rdx,%rax
  404578:	jae    401be0 <nx_rt_pair_take2.cold>
  40457e:	pop    %rbp
  40457f:	mov    %r13,%rax
  404582:	mov    %r12,%rdx
  404585:	pop    %r12
  404587:	pop    %r13
  404589:	pop    %r14
  40458b:	pop    %r15
  40458d:	retq   
  40458e:	xchg   %ax,%ax
  404590:	mov    0x4(%rcx),%edx
  404593:	mov    (%rcx),%edi
  404595:	shl    $0x20,%rdx
  404599:	or     %rdi,%rdx
  40459c:	mov    %rdx,%r15
  40459f:	and    $0xffffff,%edx
  4045a5:	shr    $0x18,%r15
  4045a9:	lea    0x8(,%r15,8),%rdi
  4045b1:	lea    0x0(%rbp,%rdi,1),%r8
  4045b6:	cmp    $0x1,%rdx
  4045ba:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  4045c0:	mov    (%rcx),%edx
  4045c2:	mov    (%r14),%rdx
  4045c5:	mov    -0x8(%rbp,%rdi,1),%r13
  4045ca:	mov    (%r8),%r12
  4045cd:	mov    %rdx,(%rcx)
  4045d0:	mov    0x3dc02(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4045d6:	mov    %rax,(%r14)
  4045d9:	mov    0x100(%r14),%rax
  4045e0:	add    $0x1,%rax
  4045e4:	mov    %rax,0x100(%r14)
  4045eb:	cmp    %rdx,%rax
  4045ee:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  4045f4:	mov    %r15,%rax
  4045f7:	jmpq   404537 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
