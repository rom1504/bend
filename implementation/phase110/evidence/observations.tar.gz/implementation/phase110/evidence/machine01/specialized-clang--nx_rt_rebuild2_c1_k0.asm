
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403350 <nx_rt_rebuild2_c1_k0>:
  403350:	push   %r13
  403352:	mov    %rsi,%r10
  403355:	mov    %rdx,%r8
  403358:	movabs $0xffffffffff,%r9
  403362:	push   %r12
  403364:	and    %r10,%r9
  403367:	push   %rbp
  403368:	lea    0x0(,%r9,8),%rax
  403370:	push   %rbx
  403371:	mov    %rdi,%rbx
  403374:	sub    $0x28,%rsp
  403378:	mov    (%rdi),%rdi
  40337b:	mov    0x8(%rbx),%rsi
  40337f:	lea    (%rdi,%rax,1),%rdx
  403383:	test   %r10,%r10
  403386:	js     4033f0 <nx_rt_rebuild2_c1_k0+0xa0>
  403388:	mov    (%rdx),%r12
  40338b:	mov    0x8(%rdi,%rax,1),%rbp
  403390:	cmp    $0x310817f,%r9
  403397:	jbe    4033c8 <nx_rt_rebuild2_c1_k0+0x78>
  403399:	mov    %rbp,0x10(%rbx)
  40339d:	mov    %r12,%rcx
  4033a0:	mov    $0x1,%edx
  4033a5:	movq   $0xffffffffffffffff,0x18(%rbx)
  4033ad:	movl   $0x1,0x20(%rbx)
  4033b4:	add    $0x28,%rsp
  4033b8:	pop    %rbx
  4033b9:	pop    %rbp
  4033ba:	pop    %r12
  4033bc:	pop    %r13
  4033be:	jmpq   401fa0 <nx_construct2>
  4033c3:	nopl   0x0(%rax,%rax,1)
  4033c8:	mov    0x8(%rsi),%r9
  4033cc:	test   %r9,%r9
  4033cf:	je     4016c4 <nx_rt_rebuild2_c1_k0.cold>
  4033d5:	mov    (%rdi,%r9,8),%rax
  4033d9:	subq   $0x2,0x108(%rsi)
  4033e1:	mov    %rax,0x8(%rsi)
  4033e5:	jmp    403399 <nx_rt_rebuild2_c1_k0+0x49>
  4033e7:	nopw   0x0(%rax,%rax,1)
  4033f0:	mov    0x4(%rdx),%eax
  4033f3:	mov    (%rdx),%ecx
  4033f5:	shl    $0x20,%rax
  4033f9:	or     %rcx,%rax
  4033fc:	mov    %rax,%r13
  4033ff:	and    $0xffffff,%eax
  403404:	shr    $0x18,%r13
  403408:	lea    0x0(,%r13,8),%r11
  403410:	lea    (%rdi,%r11,1),%rbp
  403414:	lea    0x8(%rdi,%r11,1),%r11
  403419:	cmp    $0x1,%rax
  40341d:	jne    40170a <nx_rt_rebuild2_c1_k0.cold+0x46>
  403423:	mov    (%rdx),%eax
  403425:	mov    (%rsi),%rax
  403428:	mov    0x0(%rbp),%r12
  40342c:	mov    (%r11),%rbp
  40342f:	mov    %rax,(%rdx)
  403432:	mov    0x100(%rsi),%rax
  403439:	mov    0x3dd99(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40343f:	mov    %r9,(%rsi)
  403442:	add    $0x1,%rax
  403446:	mov    %rax,0x100(%rsi)
  40344d:	cmp    %rdx,%rax
  403450:	jae    4016f4 <nx_rt_rebuild2_c1_k0.cold+0x30>
  403456:	mov    %r13,%r9
  403459:	jmpq   403390 <nx_rt_rebuild2_c1_k0+0x40>

Disassembly of section .fini:
