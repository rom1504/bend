#!/usr/bin/env python3
"""Preserve the annotated arity source experiment without running targets."""
from pathlib import Path
import datetime,difflib,hashlib,json
out=Path(__file__).resolve().parent;root=out.parents[3]
src=root/'selfhost/src/back/js/direct/model.bend';old=out/'model.before.bend'
def identity(p):
 b=p.read_bytes();return {'path':str(p),'sha256':hashlib.sha256(b).hexdigest(),'bytes':len(b)}
def fresh(p,b):
 with p.open('xb') as f:f.write(b)
b=old.read_bytes();a=src.read_bytes()
assert hashlib.sha256(b).hexdigest()=='22c66ed470e59392954320f31e98b66c2666c31ff2109945bc297ff7fd4a35bf'
assert hashlib.sha256(a).hexdigest()=='dc48e335d8dc1bdc58aeaca26cdadfd53e952e975f85c3a529719905deb25aaf'
inputs=[identity(Path(__file__)),identity(src),identity(old),identity(out/'original.json')]
label='selfhost/src/back/js/direct/model.bend'
patch=''.join(difflib.unified_diff(b.decode().splitlines(True),a.decode().splitlines(True),fromfile='a/'+label,tofile='b/'+label))
fresh(out/'model.after.bend',a);fresh(out/'annotated-arity.patch',patch.encode())
r={'kind':'phase55-annotated-arity-source-proposal-v1','createdAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'inputs':inputs,'outputs':[identity(out/'model.after.bend'),identity(out/'annotated-arity.patch')],'physicalLines':{'before':len(b.splitlines()),'after':len(a.splitlines())},'contract':'Direct emission consumes checked annotated source: constructor names unique, matcher expected-type owner proven. Forged raw Ann books violating checker invariants are outside this private ABI.','unchanged':['common j_find_ctor','jd_raise_arm signed residual','unannotated/global fallback','unknown expected-type fallback','runtime and host ABI'],'targetsExecuted':False}
assert all(identity(Path(i['path']))==i for i in inputs);r['inputsUnchanged']=True
fresh(out/'proposal.json',(json.dumps(r,indent=2)+'\n').encode());print(json.dumps(identity(out/'proposal.json')))
