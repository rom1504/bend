#define NATIVE_READONLY_OBSERVERS 1
#define NATIVE_PACK_CTORS 1
#define NATIVE_COLD_CTORS 1
#define NATIVE_FIELD32_CID__CTOR_73_110_73_100__0 1
#define NATIVE_FIELD32_CID__CTOR_73_110_78_109__0 1
#define NATIVE_TYPED_SCALARS 1
#define NATIVE_COLD_USER_CTORS 1
#define NATIVE_SCALAR_ARRAYS 1
#define NATIVE_UNSHARED_ARRAYS 1

// Imports
// =======

#pragma clang fp contract(off)

#ifdef __METAL_VERSION__
#include <metal_stdlib>
using namespace metal;
#elif !defined(__CUDACC_RTC__)
#ifndef __APPLE__
#define _GNU_SOURCE
#endif
#include <stdint.h>
#include <stdbool.h>
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sched.h>
#include <stdatomic.h>
#include <unistd.h>
#include <signal.h>
#include <sys/mman.h>
#include <time.h>
#include <poll.h>
#ifdef __APPLE__
#include <mach-o/dyld.h>
#endif
#ifdef __OBJC__
// #include, not #import: bend -o reads an #import as an effect's framework
#include <Metal/Metal.h>
#include <Foundation/Foundation.h>
#elif BEND_CUDA
#include <cuda.h>
#include <nvrtc.h>
#include <fcntl.h>
#include <sys/stat.h>
#endif
#endif

// Dialect
// =======

#ifdef __METAL_VERSION__
// coherent(device) (MSL 3.2): M1-class parts else lose stores across
// threadgroups within a dispatch
#if __METAL_VERSION__ >= 320
#define DEV     coherent(device) device
#define DEVL    coherent(device) device
#else
#define DEV     device
#define DEVL    device
#endif
#define GA32    threadgroup atomic_uint
#define THR     thread
#define INLINE  inline
#define OUTLINE static
#define CONSTV  constant
#define DEVICE  1
#define CLZ(x)  clz(x)
#define A32(p)  ((DEV atomic_uint*)(p))
#define RLX     memory_order_relaxed
#define FENCE() atomic_thread_fence(mem_flags::mem_device, memory_order_seq_cst)
#define BAR()   threadgroup_barrier(mem_flags::mem_threadgroup)
#define BARD()  threadgroup_barrier(mem_flags::mem_device \
  | mem_flags::mem_threadgroup)

#define g32_ini(p)    atomic_store_explicit(p, 0, RLX)
#define g32_add(p, v) atomic_fetch_add_explicit(p, v, RLX)
#define g32_get(p)    atomic_load_explicit(p, RLX)
#else
#define DEVL
#define THR
#define INLINE  static inline
#define CONSTV  static const

#define g32_ini(p)    a32_store(p, 0)
#define g32_add(p, v) a32_add(p, v)
#define g32_get(p)    a32_load(p)
#ifdef __CUDACC_RTC__
// plain data stays L1-cacheable: cross-lane handoffs go through a32 + FENCE
#define DEV
#define GA32    __shared__ u32
#define OUTLINE static __attribute__((noinline))
#define DEVICE  1
#define CLZ(x)  (u32)__clz((int)(x))
#define FENCE() __threadfence()
#define BAR()   __syncthreads()
#define BARD()  \
  { __threadfence(); __syncthreads(); }
#else
#define DEV
// only clang 19+ has both, and only it compiles preserve_most soundly
#if __has_attribute(preserve_none) && __has_attribute(preserve_most) \
  && defined(__OPTIMIZE__)
#define PRESERVE(A) __attribute__((A))
#else
#define PRESERVE(A)
#endif
#define OUTLINE static __attribute__((noinline, cold)) PRESERVE(preserve_most)
#define DEVICE  0
#define CLZ(x)  (u32)__builtin_clz(x)
#endif
#endif
#define FAR static __attribute__((noinline))

// A segment: a case of the device's switch; on the host, a preserve_none
// function (WL_SIG) left by a musttail call, its words fresh at WL_OPEN.
#if DEVICE
#define LOCK(l)
#define UNLOCK(l)
#define WL_CASE(F) case F:
#define WL_OPEN    {
#define WL_JMP(F)  { fid = (F); break; }
#define WL_DYN     WL_JMP
#else
#define LOCK(l)    while (__atomic_exchange_n(&(l), 1, __ATOMIC_ACQUIRE)) {}
#define UNLOCK(l)  __atomic_store_n(&(l), 0, __ATOMIC_RELEASE)
#define WL_FN      static PRESERVE(preserve_none) __attribute__((noinline)) Reply
#define WL_CASE(F) WL_FN WL_##F(WL_SIG)
#define WL_OPEN    { WL_BANK u32 rn;
#define WL_JMP(F)  __attribute__((musttail)) return WL_##F(WL_ALL)
#define WL_DYN(F)  __attribute__((musttail)) return wl_tab[F](WL_ALL)
#endif
#define WL_SPIN     for (;;) { if (err_spun(e.mem, &wpoll)) { return 0; }
#define WL_SPUN     } break;
#define WL_AGAIN(F) continue
#define WL_POP()    { sp -= LANE_STEP; WL_DYN((Fid)STK(0)); }

#define LANE_STEP (DEVICE ? (int64_t)CUBE : 1)
#define STK(I)    sp[(int64_t)(I) * LANE_STEP]

#define WL_RETN(N)  { rn = (N); WL_POP(); }
#define WL_CONT     STK(-3)
#define WL_IDX      STK(-2)
#define WL_POPN(N)  sp -= N * LANE_STEP
#define WL_PUSHN(N) sp += N * LANE_STEP
#define WL_FRAME(T) \
  Loc wtl = task_tail(T); \
  u64 wtw = e.mem[wtl + 1]; \
  STK(0) = e.mem[wtl]; \
  STK(1) = (wtw >> 32) & 0xFFFF; \
  STK(2) = FID_EXIT; \
  sp += 3 * LANE_STEP;
#define WL_ARGS(A, N) \
  for (u32 wi = 0; wi + 1 < N; wi += 1) { \
    STK(wi) = e.mem[A + wi]; \
  } \
  sp += (N - 1) * LANE_STEP;
#define WL_ROOM(N) \
  if (DEVICE && sp + (N) * CUBE >= e.mem + HEAP_OFF + CUBE) { \
    err_post(e.mem, ERR_DEEP); \
    return 0; \
  }

// Types
// =====

#ifdef __METAL_VERSION__
typedef ulong u64;
typedef uint  u32;
typedef uchar u8;
typedef float f32;
#elif defined(__CUDACC_RTC__)
typedef unsigned long long u64;
typedef long long          int64_t;
typedef unsigned int       u32;
typedef unsigned char      u8;
typedef float              f32;
#else
typedef uint64_t u64;
typedef uint32_t u32;
typedef uint8_t  u8;
typedef float    f32;
#endif

typedef u64 Loc;
#define LOC_MASK ((1ull << 40) - 1)

typedef u32 Cls;
typedef u32 Fid;

typedef u64 Term;
#define TAG_PAK 1ull
#define TAG_CTR 2ull
#define TAG_CLO 3ull
#define TAG_BUF 4ull
#define TAG_TSK 5ull
#define TAG_ARR 6ull

#define TERM_HOLE (~0ull)

#define RFC_BIT  (1ull << 63)
#define RFC_CNT  ((1u << 24) - 1)

typedef Term Reply;

typedef u32 Err;
#define ERR_RING 1
#define ERR_TAGS 2
#define ERR_HEAP 3
#define ERR_FIDS 4
#define ERR_NATS 5
#define ERR_RFCS 6
#define ERR_DEEP 7
#define ERR_ARRS 8

typedef u32 Ring;

typedef DEV u64* Corpus;

typedef struct {
  Corpus   mem;
  DEV u64* alc;
} Env;

typedef struct {
  u64 off;
  u32 rd;
  u32 wr;
  u32 top;
} Bank;

typedef DEVL Term* Stk;

typedef Term Nat;
#define NAT_IMM ((1ull << 48) - 1)

typedef Term U32;

#if DEVICE
typedef u32 u32a;
#else
typedef u32 __attribute__((may_alias)) u32a;
#endif

#ifdef __METAL_VERSION__
typedef threadgroup atomic_uint* Cur;
#else
typedef u32* Cur;
#endif

// Constants
// =========

#define LINE      16
#define PAGE_BITS 7
#define PAGE_LEN  (1ull << PAGE_BITS)
#define CUBE_T    128
#define CUBE      ((u64)CUBE_T * CUBE_T)
#define CUBE_G    (1u << CUBE_LOG)
#define LANES     ((u64)CUBE_T << CUBE_LOG)
#define RING_LOG  (17 - CUBE_LOG)
#define RING_LEN  (1ull << RING_LOG)
#define STAK_LEN  (1ull << 11)
#define NCLS      8
#define NCLS_ALL  32
#define IO_HELP   64

#define ALC_WORDS NCLS_ALL
#define TG_HOLD   2304
#define CHUNK     256
#define CAP_WORDS 32768
#define QUANTUM   (DEVICE ? PAGE_LEN \
  : KEEP_WORDS < 32 * PAGE_LEN ? KEEP_WORDS : 32 * PAGE_LEN)
#if DEVICE
#define KEEP_WORDS CHUNK
#endif
#define RING_WORDS ((1ull << 10) + 2)

#define H_BUMP       0
#define H_CAP        1
#define H_CURSOR     LINE
#define H_ROOT_DONE  (2 * LINE)
#define H_ERROR_CODE (3 * LINE)
#define H_ROOT_WORD  (4 * LINE)
#define H_BANK       (H_ROOT_WORD + WL_RESW)

#define PAGE_UP(n) (((n) + PAGE_LEN - 1) & ~(PAGE_LEN - 1))
#define ALC_OFF  PAGE_UP(H_BANK + 3 * NCLS_ALL)
#define RING_OFF (ALC_OFF + CUBE * 2 * ALC_WORDS)
#define STAK_OFF (RING_OFF + CUBE * RING_WORDS)
#define STAT_OFF (STAK_OFF + CUBE * STAK_LEN)
#define HEAP_OFF (STAT_OFF + PAGE_UP(STAT_LEN))

// Globals
// =======

#if !DEVICE

typedef pthread_mutex_t lock;

static Corpus CORPUS;
static u64    ALC[CUBE_T + 1][3 * ALC_WORDS] __attribute__((aligned(128)));
static u32    KEEP_WORDS;
// the bag: 2^CUBE_LOG groups of CUBE_T lanes (a -D constant on the device)
static u32    CUBE_LOG = 7;
static u32    bank_lock;

static u32            pool_size;
static _Atomic u32    pool_row;
static bool           pool_grow;
static _Atomic u64    pool_tick;
static _Atomic u32    pool_done;
static lock           pool_lock = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t pool_wake = PTHREAD_COND_INITIALIZER;

// The device program compiles from the binary's own text.
#if BEND_METAL || BEND_CUDA
#pragma clang diagnostic ignored "-Wc23-extensions"
static const char BEND_SRC[] = {
#embed __FILE__
, 0 };
#endif

#ifdef __OBJC__
static id<MTLDevice>               gpu_dev;
static id<MTLCommandQueue>         gpu_que;
static id<MTLComputePipelineState> gpu_pso;
static id<MTLBuffer>               gpu_buf;
static id<MTLComputeCommandEncoder> gpu_enc;
#elif BEND_CUDA
static CUdevice   gpu_dev;
static CUmodule   gpu_lib;
static CUfunction gpu_pso;
#endif
static bool io_gpu;
static Stk  io_stk;

static const char* CLI_HELP =
  "usage: %s [options] [arguments]\n"
  "  --threads N       worker threads, 1 to 128 (default: the CPU count)\n"
  "  --gpu on|off|4GB  run ! calls on the GPU, over this much of its memory\n"
  "                    (default: on if present, over 2GB on Metal)\n"
  "  --gpu-build       write the GPU program and exit\n"
  "  --help            show this text\n"
  "  --                the rest are the program's arguments (IO.args)\n";

#endif

// Tables
// ======

#define FID_109_97_105_110_ 0
#define FID_110_97_116_105_118_101_95_107_95_49_48_50_54_ 1
#define FID_110_97_116_105_118_101_95_107_95_49_48_50_55_ 2
#define FID_110_97_116_105_118_101_95_107_95_49_48_50_57_ 3
#define FID_110_97_116_105_118_101_95_107_95_49_48_51_50_ 4
#define FID_110_97_116_105_118_101_95_107_95_49_48_51_53_ 5
#define FID_110_97_116_105_118_101_95_107_95_49_48_51_54_ 6
#define FID_73_79_46_112_114_105_110_116_ 7
#define FID_110_97_116_105_118_101_95_107_95_50_48_54_49_ 8
#define FID_110_97_116_105_118_101_95_107_95_50_48_54_50_ 9
#define FID_36_100_105_114_101_99_116_46_73_79_46_112_114_105_110_116_ 10
#define FID_85_51_50_46_115_104_111_119_ 11
#define FID_110_97_116_105_118_101_95_107_95_51_48_57_51_ 12
#define FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_ 13
#define FID_85_51_50_46_115_104_111_119_46_105_102_ 14
#define FID_110_97_116_105_118_101_95_107_95_52_49_50_52_ 15
#define FID_110_97_116_105_118_101_95_107_95_52_49_50_53_ 16
#define FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_105_102_ 17
#define FID_110_97_116_105_118_101_95_107_95_52_49_51_52_ 18
#define FID_85_51_50_46_115_104_111_119_46_103_111_ 19
#define FID_110_97_116_105_118_101_95_107_95_53_49_54_50_ 20
#define FID_110_97_116_105_118_101_95_107_95_53_49_54_51_ 21
#define FID_110_97_116_105_118_101_95_107_95_53_49_54_52_ 22
#define FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_103_111_ 23
#define FID_110_97_116_105_118_101_95_107_95_53_49_56_52_ 24
#define FID_110_97_116_105_118_101_95_107_95_53_49_56_55_ 25
#define FID_110_97_116_105_118_101_95_107_95_53_49_57_48_ 26
#define FID_85_51_50_46_115_104_111_119_46_102_105_110_ 27
#define FID_110_97_116_105_118_101_95_107_95_54_50_49_57_ 28
#define FID_110_97_116_105_118_101_95_107_95_54_50_50_48_ 29
#define FID_110_97_116_105_118_101_95_107_95_54_50_50_49_ 30
#define FID_110_97_116_105_118_101_95_107_95_54_50_50_50_ 31
#define FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_102_105_110_ 32
#define FID_110_97_116_105_118_101_95_107_95_54_50_52_53_ 33
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_100_105_118_ 34
#define FID_110_97_116_105_118_101_95_107_95_55_50_55_48_ 35
#define FID_110_97_116_105_118_101_95_107_95_55_50_55_49_ 36
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_100_105_118_ 37
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_97_100_100_ 38
#define FID_110_97_116_105_118_101_95_107_95_56_50_57_57_ 39
#define FID_110_97_116_105_118_101_95_107_95_56_51_48_48_ 40
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_97_100_100_ 41
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_109_111_100_ 42
#define FID_110_97_116_105_118_101_95_107_95_57_51_50_56_ 43
#define FID_110_97_116_105_118_101_95_107_95_57_51_50_57_ 44
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_109_111_100_ 45
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_122_101_114_111_ 46
#define FID_110_97_116_105_118_101_95_107_95_49_48_51_53_55_ 47
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_122_101_114_111_ 48
#define FID_98_97_116_99_104_ 49
#define FID_110_97_116_105_118_101_95_107_95_49_49_51_56_52_ 50
#define FID_110_97_116_105_118_101_95_107_95_49_49_51_56_53_ 51
#define FID_110_97_116_105_118_101_95_107_95_49_49_51_56_56_ 52
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_48_49_ 53
#define FID_110_97_116_105_118_101_95_107_95_49_49_51_56_57_ 54
#define FID_110_97_116_105_118_101_95_107_95_49_49_51_57_48_ 55
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_48_53_ 56
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_48_57_ 57
#define FID_36_100_105_114_101_99_116_46_98_97_116_99_104_ 58
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_51_56_ 59
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_50_54_ 60
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_50_55_ 61
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_ 62
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_52_54_ 63
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_ 64
#define FID_110_97_116_105_118_101_95_107_95_49_49_52_53_57_ 65
#define FID_108_105_110_101_ 66
#define FID_110_97_116_105_118_101_95_107_95_49_50_52_56_53_ 67
#define FID_36_100_105_114_101_99_116_46_108_105_110_101_ 68
#define FID_110_97_116_105_118_101_95_107_95_49_50_52_56_57_ 69
#define FID_110_97_116_105_118_101_95_107_95_49_50_52_57_51_ 70
#define FID_110_97_116_105_118_101_95_107_95_49_50_52_57_52_ 71
#define FID_108_101_120_ 72
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_50_50_ 73
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_50_51_ 74
#define FID_36_100_105_114_101_99_116_46_108_101_120_ 75
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_51_53_ 76
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_52_56_ 77
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_53_52_ 78
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_53_55_ 79
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_54_48_ 80
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_54_51_ 81
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_54_54_ 82
#define FID_110_97_116_105_118_101_95_107_95_49_51_53_54_57_ 83
#define FID_102_108_117_115_104_ 84
#define FID_110_97_116_105_118_101_95_107_95_49_52_53_57_54_ 85
#define FID_110_97_116_105_118_101_95_107_95_49_52_53_57_55_ 86
#define FID_36_100_105_114_101_99_116_46_102_108_117_115_104_ 87
#define FID_110_97_116_105_118_101_95_107_95_49_52_54_49_55_ 88
#define FID_110_97_116_105_118_101_95_107_95_49_52_54_50_48_ 89
#define FID_109_105_120_ 90
#define FID_110_97_116_105_118_101_95_107_95_49_53_54_52_56_ 91
#define FID_110_97_116_105_118_101_95_107_95_49_53_54_52_57_ 92
#define FID_110_97_116_105_118_101_95_107_95_49_53_54_53_48_ 93
#define FID_36_100_105_114_101_99_116_46_109_105_120_ 94
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_120_111_114_ 95
#define FID_110_97_116_105_118_101_95_107_95_49_54_54_56_56_ 96
#define FID_110_97_116_105_118_101_95_107_95_49_54_54_56_57_ 97
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_120_111_114_ 98
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_109_117_108_ 99
#define FID_110_97_116_105_118_101_95_107_95_49_55_55_49_55_ 100
#define FID_110_97_116_105_118_101_95_107_95_49_55_55_49_56_ 101
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_109_117_108_ 102
#define FID_115_116_101_112_ 103
#define FID_110_97_116_105_118_101_95_107_95_49_56_55_52_57_ 104
#define FID_110_97_116_105_118_101_95_107_95_49_56_55_53_48_ 105
#define FID_110_97_116_105_118_101_95_107_95_49_56_55_53_49_ 106
#define FID_36_100_105_114_101_99_116_46_115_116_101_112_ 107
#define FID_110_97_116_105_118_101_95_107_95_49_56_55_54_49_ 108
#define FID_115_116_101_112_46_97_116_ 109
#define FID_110_97_116_105_118_101_95_107_95_49_57_55_57_49_ 110
#define FID_110_97_116_105_118_101_95_107_95_49_57_55_57_50_ 111
#define FID_110_97_116_105_118_101_95_107_95_49_57_55_57_51_ 112
#define FID_110_97_116_105_118_101_95_107_95_49_57_55_57_52_ 113
#define FID_36_100_105_114_101_99_116_46_115_116_101_112_46_97_116_ 114
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_49_50_ 115
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_51_56_ 116
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_52_53_ 117
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_52_56_ 118
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_53_49_ 119
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_54_51_ 120
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_55_55_ 121
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_56_55_ 122
#define FID_110_97_116_105_118_101_95_107_95_49_57_56_57_55_ 123
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_48_50_ 124
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_48_56_ 125
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_49_49_ 126
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_49_52_ 127
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_50_54_ 128
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_50_56_ 129
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_53_52_ 130
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_54_52_ 131
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_54_57_ 132
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_55_53_ 133
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_55_56_ 134
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_56_49_ 135
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_56_52_ 136
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_56_55_ 137
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_57_48_ 138
#define FID_110_97_116_105_118_101_95_107_95_49_57_57_57_51_ 139
#define FID_102_110_118_ 140
#define FID_110_97_116_105_118_101_95_107_95_50_49_48_50_48_ 141
#define FID_110_97_116_105_118_101_95_107_95_50_49_48_50_49_ 142
#define FID_36_100_105_114_101_99_116_46_102_110_118_ 143
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_115_117_98_ 144
#define FID_110_97_116_105_118_101_95_107_95_50_50_48_53_51_ 145
#define FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_ 146
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_117_98_ 147
#define FID_99_108_115_ 148
#define FID_110_97_116_105_118_101_95_107_95_50_51_48_56_51_ 149
#define FID_36_100_105_114_101_99_116_46_99_108_115_ 150
#define FID_110_97_116_105_118_101_95_107_95_50_51_48_56_56_ 151
#define FID_110_97_116_105_118_101_95_107_95_50_51_48_56_57_ 152
#define FID_99_108_115_46_103_111_ 153
#define FID_110_97_116_105_118_101_95_107_95_50_52_49_51_49_ 154
#define FID_110_97_116_105_118_101_95_107_95_50_52_49_51_50_ 155
#define FID_110_97_116_105_118_101_95_107_95_50_52_49_51_51_ 156
#define FID_36_100_105_114_101_99_116_46_99_108_115_46_103_111_ 157
#define FID_66_111_111_108_46_97_110_100_ 158
#define FID_110_97_116_105_118_101_95_107_95_50_53_49_55_50_ 159
#define FID_110_97_116_105_118_101_95_107_95_50_53_49_55_51_ 160
#define FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_ 161
#define FID_110_97_116_105_118_101_95_107_95_50_53_49_56_51_ 162
#define FID_110_97_116_105_118_101_95_107_95_50_53_49_56_54_ 163
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_108_101_ 164
#define FID_110_97_116_105_118_101_95_107_95_50_54_50_49_49_ 165
#define FID_110_97_116_105_118_101_95_107_95_50_54_50_49_50_ 166
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_108_101_ 167
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_ 168
#define FID_110_97_116_105_118_101_95_107_95_50_55_50_52_48_ 169
#define FID_110_97_116_105_118_101_95_107_95_50_55_50_52_49_ 170
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_ 171
#define FID_103_101_110_ 172
#define FID_110_97_116_105_118_101_95_107_95_50_56_50_55_50_ 173
#define FID_110_97_116_105_118_101_95_107_95_50_56_50_55_51_ 174
#define FID_110_97_116_105_118_101_95_107_95_50_56_50_55_52_ 175
#define FID_36_100_105_114_101_99_116_46_103_101_110_ 176
#define FID_110_97_116_105_118_101_95_107_95_50_56_50_57_54_ 177
#define FID_110_97_116_105_118_101_95_107_95_50_56_50_57_55_ 178
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_48_55_ 179
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_49_48_ 180
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_49_51_ 181
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_49_54_ 182
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_49_57_ 183
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_50_50_ 184
#define FID_110_97_116_105_118_101_95_107_95_50_56_51_50_53_ 185
#define FID_103_101_110_46_97_116_ 186
#define FID_110_97_116_105_118_101_95_107_95_50_57_51_53_51_ 187
#define FID_110_97_116_105_118_101_95_107_95_50_57_51_53_52_ 188
#define FID_110_97_116_105_118_101_95_107_95_50_57_51_53_53_ 189
#define FID_36_100_105_114_101_99_116_46_103_101_110_46_97_116_ 190
#define FID_110_97_116_105_118_101_95_107_95_50_57_51_54_53_ 191
#define FID_101_120_112_97_110_100_ 192
#define FID_110_97_116_105_118_101_95_107_95_51_48_51_57_53_ 193
#define FID_110_97_116_105_118_101_95_107_95_51_48_51_57_54_ 194
#define FID_110_97_116_105_118_101_95_107_95_51_48_51_57_55_ 195
#define FID_110_97_116_105_118_101_95_107_95_51_48_51_57_56_ 196
#define FID_36_100_105_114_101_99_116_46_101_120_112_97_110_100_ 197
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_52_54_ 198
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_52_57_ 199
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_53_50_ 200
#define FID_110_97_116_105_118_101_95_107_95_51_48_52_53_53_ 201
#define FID_105_100_101_110_116_ 202
#define FID_110_97_116_105_118_101_95_107_95_51_49_52_56_51_ 203
#define FID_110_97_116_105_118_101_95_107_95_51_49_52_56_52_ 204
#define FID_110_97_116_105_118_101_95_107_95_51_49_52_56_53_ 205
#define FID_36_100_105_114_101_99_116_46_105_100_101_110_116_ 206
#define FID_110_97_116_105_118_101_95_107_95_51_49_52_57_56_ 207
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_ 208
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_49_52_ 209
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_49_55_ 210
#define FID_110_97_116_105_118_101_95_107_95_51_49_53_50_48_ 211
#define FID_112_114_110_103_ 212
#define FID_110_97_116_105_118_101_95_107_95_51_50_53_52_54_ 213
#define FID_36_100_105_114_101_99_116_46_112_114_110_103_ 214
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_115_104_108_110_ 215
#define FID_110_97_116_105_118_101_95_107_95_51_51_53_56_52_ 216
#define FID_110_97_116_105_118_101_95_107_95_51_51_53_56_53_ 217
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_104_108_110_ 218
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_115_104_114_110_ 219
#define FID_110_97_116_105_118_101_95_107_95_51_52_54_49_51_ 220
#define FID_110_97_116_105_118_101_95_107_95_51_52_54_49_52_ 221
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_104_114_110_ 222
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_116_111_95_110_97_116_ 223
#define FID_110_97_116_105_118_101_95_107_95_51_53_54_52_50_ 224
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_116_111_95_110_97_116_ 225
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_97_110_100_ 226
#define FID_110_97_116_105_118_101_95_107_95_51_54_54_54_56_ 227
#define FID_110_97_116_105_118_101_95_107_95_51_54_54_54_57_ 228
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_97_110_100_ 229
#define FID_110_117_109_ 230
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_48_48_ 231
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_48_49_ 232
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_48_50_ 233
#define FID_36_100_105_114_101_99_116_46_110_117_109_ 234
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_49_53_ 235
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_50_51_ 236
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_51_49_ 237
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_51_52_ 238
#define FID_110_97_116_105_118_101_95_107_95_51_55_55_51_55_ 239
#define FID_111_112_ 240
#define FID_110_97_116_105_118_101_95_107_95_51_56_55_54_52_ 241
#define FID_110_97_116_105_118_101_95_107_95_51_56_55_54_53_ 242
#define FID_36_100_105_114_101_99_116_46_111_112_ 243
#define FID_110_97_116_105_118_101_95_107_95_51_56_55_55_49_ 244
#define FID_111_112_46_112_105_99_107_ 245
#define FID_110_97_116_105_118_101_95_107_95_51_57_56_48_57_ 246
#define FID_110_97_116_105_118_101_95_107_95_51_57_56_49_48_ 247
#define FID_36_100_105_114_101_99_116_46_111_112_46_112_105_99_107_ 248
#define FID_110_97_116_105_118_101_95_107_95_51_57_56_49_56_ 249
#define FID_110_97_116_105_118_101_95_107_95_51_57_56_50_51_ 250
#define FID_110_97_116_105_118_101_95_107_95_51_57_56_50_54_ 251
#define FID_110_97_116_105_118_101_95_107_95_51_57_56_50_57_ 252
#define FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_110_101_ 253
#define FID_110_97_116_105_118_101_95_107_95_52_48_56_53_52_ 254
#define FID_110_97_116_105_118_101_95_107_95_52_48_56_53_53_ 255
#define FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_110_101_ 256
#define FID_115_108_111_116_ 257
#define FID_110_97_116_105_118_101_95_107_95_52_49_56_56_52_ 258
#define FID_36_100_105_114_101_99_116_46_115_108_111_116_ 259
#define FID_115_108_111_116_46_103_111_ 260
#define FID_110_97_116_105_118_101_95_107_95_52_50_57_50_50_ 261
#define FID_110_97_116_105_118_101_95_107_95_52_50_57_50_51_ 262
#define FID_110_97_116_105_118_101_95_107_95_52_50_57_50_52_ 263
#define FID_36_100_105_114_101_99_116_46_115_108_111_116_46_103_111_ 264
#define FID_115_97_108_116_ 265
#define FID_110_97_116_105_118_101_95_107_95_52_51_57_54_51_ 266
#define FID_110_97_116_105_118_101_95_107_95_52_51_57_54_52_ 267
#define FID_36_100_105_114_101_99_116_46_115_97_108_116_ 268
#define FID_116_112_108_ 269
#define FID_115_101_101_100_ 270
#define FID_110_97_116_105_118_101_95_107_95_52_54_48_50_50_ 271
#define FID_36_100_105_114_101_99_116_46_115_101_101_100_ 272
#define FID_115_105_122_101_46_98_105_103_ 273
#define FID_IO_EMIT 274
#define BEND_CLO_APPLY 275
#define FID_EXIT 276
#define FID_ENTER 277
#define CID_UNIT 0
#define CID_FALSE 1
#define CID_TRUE 2
#define CID_LT 3
#define CID_EQ 4
#define CID_GT 5
#define CID_INL 6
#define CID_INR 7
#define CID_TUPLE 8
#define CID_ZERO 9
#define CID_SUCC 10
#define CID_NONE 11
#define CID_SOME 12
#define CID_FAIL 13
#define CID_DONE 14
#define CID_READY 15
#define CID_WAIT 16
#define CID_NIL 17
#define CID_CON 18
#define CID_WNIL 19
#define CID_WCON 20
#define CID_U32 21
#define CID_F32 22
#define CID_CHR 23
#define CID_SNIL 24
#define CID_SCON 25
#define CID_ALEAF 26
#define CID_ANODE 27
#define CID_PIX 28
#define CID_QUA 29
#define CID_KEY 30
#define CID_MOUSE 31
#define CID_MOVE 32
#define CID_LOOK 33
#define CID_SCROLL 34
#define CID_CLOSE 35
#define CID_MTIP 36
#define CID_MLEAF 37
#define CID_MNODE 38
#define CID_FILE 39
#define CID_SOCKET 40
#define CID_LISTENER 41
#define CID_WINDOW 42
#define CID_AUDIO 43
#define CID_CHAN 44
#define CID_EMIT 45
#define CID_HALT 46
#define CID_APP 47
#define CID_IO_PRINT 48
#define CID_IO_WRITE 49
#define CID_IO_PRINT_ERR 50
#define CID_IO_GET_ENV 51
#define CID_IO_ARGS 52
#define CID_PROCESS_RUN 53
#define CID_IO_RANDOM_U32 54
#define CID_IO_SPAWN 55
#define CID_IO_SLEEP 56
#define CID_IO_NOW 57
#define CID_IO_THREAD_COUNT 58
#define CID_CHAN_NEW 59
#define CID_CHAN_SEND 60
#define CID_CHAN_RECV 61
#define CID_CHAN_TRY_SEND 62
#define CID_CHAN_TRY_RECV 63
#define CID_CHAN_CLOSE 64
#define CID_FILE_OPEN 65
#define CID_FILE_READ 66
#define CID_FILE_READ_BYTES 67
#define CID_FILE_READ_AT 68
#define CID_FILE_SIZE 69
#define CID_FILE_WRITE 70
#define CID_FILE_WRITE_BYTES 71
#define CID_FILE_CLOSE 72
#define CID_TCP_LISTEN 73
#define CID_TCP_ACCEPT 74
#define CID_TCP_TRY_ACCEPT 75
#define CID_TCP_CONNECT 76
#define CID_TCP_SEND 77
#define CID_TCP_TRY_SEND 78
#define CID_TCP_RECV 79
#define CID_TCP_TRY_RECV 80
#define CID_TCP_SEND_BYTES 81
#define CID_TCP_TRY_SEND_BYTES 82
#define CID_TCP_RECV_BYTES 83
#define CID_TCP_TRY_RECV_BYTES 84
#define CID_UDP_BIND 85
#define CID_UDP_SEND_TO 86
#define CID_UDP_TRY_SEND_TO 87
#define CID_UDP_SEND_BYTES_TO 88
#define CID_UDP_TRY_SEND_BYTES_TO 89
#define CID_UDP_RECV_FROM 90
#define CID_UDP_TRY_RECV_FROM 91
#define CID_UDP_RECV_BYTES_FROM 92
#define CID_UDP_TRY_RECV_BYTES_FROM 93
#define CID_SOCKET_CLOSE 94
#define CID_LISTENER_CLOSE 95
#define CID_WINDOW_OPEN 96
#define CID_WINDOW_FRAME 97
#define CID_WINDOW_SET_TITLE 98
#define CID_WINDOW_GRAB 99
#define CID_WINDOW_CLOSE 100
#define CID_AUDIO_OPEN 101
#define CID_AUDIO_WRITE 102
#define CID_AUDIO_CLOSE 103
#define CID_U32_TO_F32 104
#define CID_F32_TO_U32 105
#define CID_F32_ADD 106
#define CID_F32_SUB 107
#define CID_F32_MUL 108
#define CID_F32_DIV 109
#define CID_F32_MOD 110
#define CID_F32_POW 111
#define CID_F32_ATAN2 112
#define CID_F32_NEG 113
#define CID_F32_ABS 114
#define CID_F32_SQRT 115
#define CID_F32_EXP 116
#define CID_F32_LOG 117
#define CID_F32_LOG2 118
#define CID_F32_LOG10 119
#define CID_F32_SIN 120
#define CID_F32_COS 121
#define CID_F32_TAN 122
#define CID_F32_ASIN 123
#define CID_F32_ACOS 124
#define CID_F32_ATAN 125
#define CID_F32_SINH 126
#define CID_F32_COSH 127
#define CID_F32_TANH 128
#define CID_F32_FLOOR 129
#define CID_F32_CEIL 130
#define CID_F32_TRUNC 131
#define CID_F32_IS_EQ 132
#define CID_F32_IS_NE 133
#define CID_F32_IS_LT 134
#define CID_F32_IS_LE 135
#define CID_F32_IS_GT 136
#define CID_F32_IS_GE 137
#define CID_F32_SHOW 138
#define CID_F32_BITS 139
#define CID_F32_READ 140
#define CID_ARRAY_ATOMIC_ADD 141
#define CID_ARRAY_ATOMIC_MIN 142
#define CID_ARRAY_ATOMIC_MAX 143
#define CID_ARRAY_ATOMIC_AND 144
#define CID_ARRAY_ATOMIC_OR 145
#define CID_ARRAY_ATOMIC_XOR 146
#define CID_ARRAY_ATOMIC_EXCH 147
#define CID_ARRAY_ATOMIC_CAS 148
#define CID_ARRAY_ATOMIC_FADD 149
#define CID__CTOR_73_100_ 150
#define CID__CTOR_78_109_ 151
#define CID__CTOR_79_112_ 152
#define CID__CTOR_76_105_116_ 153
#define CID__CTOR_76_101_116_116_101_114_ 154
#define CID__CTOR_68_105_103_105_116_ 155
#define CID__CTOR_83_112_97_99_101_ 156
#define CID__CTOR_80_117_110_99_116_ 157
#define CID__CTOR_71_97_112_ 158
#define CID__CTOR_73_110_73_100_ 159
#define CID__CTOR_73_110_78_109_ 160
#define WL_RESW 1
#define BANGS 16
#define WL_BANK Term r0, r1, r2, r3, r4;
#define WL_LOAD(A, N) \
  do { \
    if ((N) <= 0) break; r0 = e.mem[(A) + 0]; \
    if ((N) <= 1) break; r1 = e.mem[(A) + 1]; \
    if ((N) <= 2) break; r2 = e.mem[(A) + 2]; \
    if ((N) <= 3) break; r3 = e.mem[(A) + 3]; \
    if ((N) <= 4) break; r4 = e.mem[(A) + 4]; \
  } while (0);
#define WL_LAST(X) \
  switch (war) { \
    case 0: r0 = (X); break; \
    case 1: r1 = (X); break; \
    case 2: r2 = (X); break; \
    case 3: r3 = (X); break; \
    case 4: r4 = (X); break; \
  }
#define WL_SAVE(V) (V)[0] = r0; 
#define WL_TAKE(V) r0 = (V)[0]; 
#define WL_SIG Env e, Stk sp, u32 seq, u32 rn, Term r0, Term r1, Term r2, Term r3, Term r4
#define WL_ALL e, sp, seq, rn, r0, r1, r2, r3, r4
CONSTV u8 FID_ARITY_T[] = { 0, 1, 2, 1, 1, 1, 2, 0, 1, 2, 2, 0, 1, 1, 0, 1, 2, 2, 2, 0, 1, 2, 3, 3, 2, 2, 2, 0, 1, 2, 3, 4, 4, 2, 0, 1, 2, 2, 0, 1, 2, 2, 0, 1, 2, 2, 0, 1, 1, 0, 1, 1, 2, 2, 3, 2, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2, 0, 1, 1, 1, 2, 2, 0, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 1, 2, 2, 2, 2, 0, 1, 2, 3, 3, 0, 1, 2, 2, 0, 1, 2, 2, 0, 1, 2, 3, 3, 4, 0, 1, 2, 3, 4, 4, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 3, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 1, 2, 2, 0, 1, 2, 2, 0, 1, 1, 2, 3, 0, 1, 2, 3, 3, 0, 1, 2, 2, 2, 2, 0, 1, 2, 2, 0, 1, 2, 2, 0, 1, 2, 3, 3, 5, 3, 2, 2, 2, 2, 2, 2, 2, 0, 1, 2, 3, 3, 4, 0, 1, 2, 3, 4, 4, 2, 2, 2, 2, 0, 1, 2, 3, 3, 3, 2, 2, 2, 2, 0, 1, 1, 0, 1, 2, 2, 0, 1, 2, 2, 0, 1, 1, 0, 1, 2, 2, 0, 1, 2, 3, 3, 3, 2, 2, 2, 2, 0, 1, 2, 2, 2, 0, 1, 2, 2, 2, 2, 2, 2, 0, 1, 2, 2, 0, 1, 1, 0, 1, 2, 3, 3, 0, 1, 2, 2, 0, 0, 1, 1, 0, 1, 2 };
CONSTV u8 FID_FLAG_T[] = { 0, 0, 0, 0, 0, 0, 0, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 0 };
CONSTV u8 FID_RESW_T[] = { 0, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 0, 1, 1, 1, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0 };
CONSTV u8 CID_ARITY_T[] = { 0, 0, 0, 0, 0, 0, 1, 1, 2, 0, 1, 0, 1, 1, 1, 1, 1, 0, 2, 0, 2, 1, 1, 1, 0, 2, 1, 2, 1, 4, 2, 4, 2, 2, 4, 0, 0, 2, 3, 0, 0, 0, 0, 0, 0, 1, 2, 2, 2, 2, 2, 2, 1, 6, 1, 2, 2, 1, 1, 2, 3, 2, 4, 3, 2, 3, 3, 3, 4, 2, 3, 3, 2, 3, 2, 3, 3, 3, 4, 3, 4, 3, 4, 3, 4, 3, 5, 6, 5, 6, 3, 4, 3, 4, 2, 2, 4, 3, 3, 3, 2, 2, 3, 2, 1, 1, 2, 2, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 2, 2, 1, 1, 1, 3, 3, 3, 3, 3, 3, 3, 4, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 1, 0 };
CONSTV u8 CID_HOT_T[] = { 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0 };
#define STAT_LEN 82
#define WL_TABLE WL_X(FID_109_97_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_50_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_50_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_50_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_51_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_51_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_51_54_) WL_X(FID_73_79_46_112_114_105_110_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_54_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_48_54_50_) WL_X(FID_36_100_105_114_101_99_116_46_73_79_46_112_114_105_110_116_) WL_X(FID_85_51_50_46_115_104_111_119_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_57_51_) WL_X(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_) WL_X(FID_85_51_50_46_115_104_111_119_46_105_102_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_50_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_50_53_) WL_X(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_105_102_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_51_52_) WL_X(FID_85_51_50_46_115_104_111_119_46_103_111_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_54_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_54_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_54_52_) WL_X(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_103_111_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_56_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_56_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_53_49_57_48_) WL_X(FID_85_51_50_46_115_104_111_119_46_102_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_49_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_50_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_50_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_50_50_) WL_X(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_102_105_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_54_50_52_53_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_100_105_118_) WL_X(FID_110_97_116_105_118_101_95_107_95_55_50_55_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_55_50_55_49_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_100_105_118_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_97_100_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_56_50_57_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_56_51_48_48_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_97_100_100_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_109_111_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_57_51_50_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_57_51_50_57_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_109_111_100_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_122_101_114_111_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_48_51_53_55_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_122_101_114_111_) WL_X(FID_98_97_116_99_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_51_57_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_57_) WL_X(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_57_) WL_X(FID_108_105_110_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_50_52_56_53_) WL_X(FID_36_100_105_114_101_99_116_46_108_105_110_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_50_52_56_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_50_52_57_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_50_52_57_52_) WL_X(FID_108_101_120_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_50_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_50_51_) WL_X(FID_36_100_105_114_101_99_116_46_108_101_120_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_51_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_52_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_53_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_53_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_57_) WL_X(FID_102_108_117_115_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_53_57_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_53_57_55_) WL_X(FID_36_100_105_114_101_99_116_46_102_108_117_115_104_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_54_49_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_52_54_50_48_) WL_X(FID_109_105_120_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_53_54_52_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_53_54_52_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_53_54_53_48_) WL_X(FID_36_100_105_114_101_99_116_46_109_105_120_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_120_111_114_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_54_56_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_54_54_56_57_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_120_111_114_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_109_117_108_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_55_49_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_55_55_49_56_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_109_117_108_) WL_X(FID_115_116_101_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_56_55_52_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_56_55_53_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_56_55_53_49_) WL_X(FID_36_100_105_114_101_99_116_46_115_116_101_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_56_55_54_49_) WL_X(FID_115_116_101_112_46_97_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_52_) WL_X(FID_36_100_105_114_101_99_116_46_115_116_101_112_46_97_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_49_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_51_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_52_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_52_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_53_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_54_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_55_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_56_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_56_57_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_48_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_48_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_49_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_49_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_50_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_50_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_53_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_54_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_54_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_55_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_55_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_57_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_49_57_57_57_51_) WL_X(FID_102_110_118_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_49_48_50_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_49_48_50_49_) WL_X(FID_36_100_105_114_101_99_116_46_102_110_118_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_115_117_98_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_117_98_) WL_X(FID_99_108_115_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_51_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_115_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_57_) WL_X(FID_99_108_115_46_103_111_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_51_) WL_X(FID_36_100_105_114_101_99_116_46_99_108_115_46_103_111_) WL_X(FID_66_111_111_108_46_97_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_49_55_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_49_55_51_) WL_X(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_49_56_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_53_49_56_54_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_108_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_54_50_49_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_54_50_49_50_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_108_101_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_55_50_52_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_55_50_52_49_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_) WL_X(FID_103_101_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_52_) WL_X(FID_36_100_105_114_101_99_116_46_103_101_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_50_57_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_50_57_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_48_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_50_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_56_51_50_53_) WL_X(FID_103_101_110_46_97_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_53_) WL_X(FID_36_100_105_114_101_99_116_46_103_101_110_46_97_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_50_57_51_54_53_) WL_X(FID_101_120_112_97_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_56_) WL_X(FID_36_100_105_114_101_99_116_46_101_120_112_97_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_52_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_52_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_53_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_48_52_53_53_) WL_X(FID_105_100_101_110_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_53_) WL_X(FID_36_100_105_114_101_99_116_46_105_100_101_110_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_52_57_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_55_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_49_53_50_48_) WL_X(FID_112_114_110_103_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_50_53_52_54_) WL_X(FID_36_100_105_114_101_99_116_46_112_114_110_103_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_115_104_108_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_51_53_56_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_51_53_56_53_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_104_108_110_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_115_104_114_110_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_54_49_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_52_54_49_52_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_104_114_110_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_116_111_95_110_97_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_53_54_52_50_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_116_111_95_110_97_116_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_97_110_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_54_54_54_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_54_54_54_57_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_97_110_100_) WL_X(FID_110_117_109_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_48_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_50_) WL_X(FID_36_100_105_114_101_99_116_46_110_117_109_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_49_53_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_50_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_49_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_55_) WL_X(FID_111_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_56_55_54_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_56_55_54_53_) WL_X(FID_36_100_105_114_101_99_116_46_111_112_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_56_55_55_49_) WL_X(FID_111_112_46_112_105_99_107_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_56_48_57_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_56_49_48_) WL_X(FID_36_100_105_114_101_99_116_46_111_112_46_112_105_99_107_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_56_49_56_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_54_) WL_X(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_57_) WL_X(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_110_101_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_56_53_52_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_48_56_53_53_) WL_X(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_110_101_) WL_X(FID_115_108_111_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_49_56_56_52_) WL_X(FID_36_100_105_114_101_99_116_46_115_108_111_116_) WL_X(FID_115_108_111_116_46_103_111_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_50_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_52_) WL_X(FID_36_100_105_114_101_99_116_46_115_108_111_116_46_103_111_) WL_X(FID_115_97_108_116_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_51_57_54_51_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_51_57_54_52_) WL_X(FID_36_100_105_114_101_99_116_46_115_97_108_116_) WL_X(FID_116_112_108_) WL_X(FID_115_101_101_100_) WL_X(FID_110_97_116_105_118_101_95_107_95_52_54_48_50_50_) WL_X(FID_36_100_105_114_101_99_116_46_115_101_101_100_) WL_X(FID_115_105_122_101_46_98_105_103_) WL_X(FID_IO_EMIT) WL_X(BEND_CLO_APPLY) WL_X(FID_EXIT)
#define MAIN_FID FID_109_97_105_110_
#define MAIN_PURE 0
#if !DEVICE
static const u32 SHOW_DESC[] = { 0 };
static const char* SHOW_NAMES[] = {"False", "True", "Unit"};
#endif


#define TAB_AT(T, S, I) T[S < I ? S : I]

// Fid
// ===

#define fid_arity(x) ((u32)FID_ARITY_T[x])

#define fid_bangs(x) ((bool)(FID_FLAG_T[x] & 1))

#define fid_nofk(x) ((bool)(FID_FLAG_T[x] & 2))

#define fid_seqk(x) (fid_resw(x) != 0)

#define fid_resw(x) ((u32)FID_RESW_T[x])

// Cid
// ===

#define cid_arity(x) ((u32)CID_ARITY_T[x])
#define cid_hot(x) ((bool)CID_HOT_T[x])

// A32
// ===

#ifdef __METAL_VERSION__

// via a volatile local: else the M1 backend folds the zext into the atomic
// load, cannot legalize it, and the pipeline build dies
#define a32_load(p)      \
  ({ volatile thread u32 _a32v = atomic_load_explicit(A32(p), RLX); _a32v; })
#define a32_store(p, v)  atomic_store_explicit(A32(p), v, RLX)
#define a32_add(p, v)    atomic_fetch_add_explicit(A32(p), v, RLX)
#define a32_sub(p, v)    atomic_fetch_sub_explicit(A32(p), v, RLX)
#define a32_swp(p, e, v) \
  atomic_compare_exchange_weak_explicit(A32(p), e, v, RLX, RLX)

#elif defined(__CUDACC_RTC__)

#define a32_load(p)     (*(volatile u32*)(p))
#define a32_store(p, v) (*(volatile u32*)(p) = (v))
#define a32_add(p, v)   atomicAdd((u32*)(p), v)
#define a32_sub(p, v)   atomicSub((u32*)(p), v)

INLINE bool a32_swp(DEV u32* p, u32* e, u32 v) {
  u32 x = *e;
  *e = atomicCAS((u32*)p, x, v);
  return *e == x;
}

#endif

#if DEVICE

INLINE u32 a32_sub_rel(DEV u32* p, u32 v) {
  FENCE();
  return a32_sub(p, v);
}

INLINE void a32_store_rel(DEV u32* p, u32 v) {
  FENCE();
  a32_store(p, v);
}

INLINE u32 a32_load_acq(DEV u32* p) {
  u32 v = a32_load(p);
  FENCE();
  return v;
}

#define a32_acq(p) FENCE()

INLINE bool a32_cas(DEV u32* p, THR u32* e, u32 v) {
  FENCE();
  bool ok = a32_swp(p, e, v);
  FENCE();
  return ok;
}

#else

#define a32_load(p)         __atomic_load_n(p, __ATOMIC_RELAXED)
#define a32_store(p, v)     __atomic_store_n(p, v, __ATOMIC_RELAXED)
#define a32_add(p, v)       __atomic_fetch_add(p, v, __ATOMIC_RELAXED)
#define a32_sub(p, v)       __atomic_fetch_sub(p, v, __ATOMIC_RELAXED)
#define a32_sub_rel(p, v)   __atomic_fetch_sub(p, v, __ATOMIC_RELEASE)
#define a32_store_rel(p, v) __atomic_store_n(p, v, __ATOMIC_RELEASE)
#define a32_load_acq(p)     __atomic_load_n(p, __ATOMIC_ACQUIRE)
#define a32_acq(p)          ((void)a32_load_acq(p))

INLINE bool a32_cas(u32* p, u32* e, u32 v) {
  return __atomic_compare_exchange_n(
    p, e, v, 1, __ATOMIC_ACQ_REL, __ATOMIC_ACQUIRE);
}

#endif

#define a32_at(H, word) ((DEV u32*)&(H)[word])

// Err
// ===

#if DEVICE

INLINE void err_post(Corpus H, Err code) {
  u32 seen = 0;
  while (seen == 0 && !a32_cas(a32_at(H, H_ERROR_CODE), &seen, code)) {}
}

#else

static const char* ERR_TEXT[] = { "", "runtime fail-stop", "runtime fail-stop", "out of memory: run again with a bigger span, as in --gpu 8GB", "a function the device does not hold", "a Nat past the largest immediate 2^48-1", "runtime fail-stop", "memory fault (machine stack overflow?)", "an array past the deepest block class 31" };

static void err_fail(const char* msg) {
  fflush(stdout);
  fprintf(stderr, "bend: %s\n", msg);
  _exit(1);
}

static void err_post(Corpus H, Err code) {
  err_fail(ERR_TEXT[code]);
}

static void err_trap(int sig) {
  // A machine stack fault can interrupt stdio or exhaust the handler's small
  // alternate stack. Only async-signal-safe operations may run here.
  static const char message[] = "bend: memory fault (machine stack overflow?)\n";
  (void)write(STDERR_FILENO, message, sizeof(message) - 1);
  _exit(1);
}

#endif

#define err_seen(H)    (DEVICE && a32_load(a32_at(H, H_ERROR_CODE)) != 0)
#define err_spun(H, n) ((++*(n) & 4095) == 0 && err_seen(H))

#ifdef __METAL_VERSION__
// Metal's atan2 is NaN at the origin; libm answers +-0 or +-pi there
INLINE f32 atan2_c99(f32 y, f32 x) {
  return y == 0.0f && x == x
    ? copysign(signbit(x) ? M_PI_F : 0.0f, y) : atan2(y, x);
}
#define sqrt  precise::sqrt
#define exp   precise::exp
#define log   precise::log
#define log2  precise::log2
#define log10 precise::log10
#define sin   fast::sin
#define cos   fast::cos
#define tan   fast::tan
#define pow   precise::pow
#define fmod  precise::fmod
#define atan2 atan2_c99
#endif

#define U32_BIN(a, o, b) ((u64)((u32)(a) o (u32)(b)))

// Metal folds a constant dividend within 128 of 2^32 through an f32: divide
// its half, then fix the odd bit.
#define U32_QUO(a, b) \
  ((a) / 2 / (b) * 2 + ((a) - (a) / 2 / (b) * 2 * (b) >= (b)))

INLINE f32 f32_unbox(u64 x) {
  union { u32 u; f32 f; } p = { (u32)x };
  return p.f;
}

INLINE u64 f32_rewrap(f32 x) {
  union { f32 f; u32 u; } p = { x };
  return p.u;
}

INLINE U32 f32_to_u32(U32 a) {
  f32 v = f32_unbox(a);
  return v >= 0.0f && v < 4294967296.0f ? (u32)v : 0;
}

INLINE Nat nat_chk(Env e, Nat n) {
  if (n > NAT_IMM) {
    err_post(e.mem, ERR_NATS);
    return NAT_IMM;
  }
  return n;
}

INLINE Nat nat_mul(Env e, Nat a, Nat b) {
  return nat_chk(e, b != 0 && a > NAT_IMM / b ? NAT_IMM + 1 : a * b);
}

#if DEVICE

#define f32_show(e, x) (err_post(e.mem, ERR_FIDS), 0)
#define f32_read(e, s) (err_post(e.mem, ERR_FIDS), 0)

#else

static Term f32_show(Env e, Term x);
static Term f32_read(Env e, Term s);

#endif

// Cls
// ===

INLINE Cls cls_fit(u32 words) {
  return words > 1 ? 32 - CLZ(words - 1) : 0;
}

// Bank
// ====

// One stack of exact generations per class; 2 heap_words / max(CHUNK,
// 2^c) entries cover the old ones plus a pass of returns. The host
// pops and pushes at rd under bank_lock; a device pass pops down from
// rd and pushes above top, and the host then compacts [top, wr) onto
// rd, so a pass never sees what it handed.

#define bank_at(H, c) ((DEV Bank*)((H) + H_BANK) + (c))

INLINE Loc bank_pop(Corpus H, Cls c) {
  DEV Bank* b = bank_at(H, c);
  Loc got = 0;
  LOCK(bank_lock);
  u32 t = a32_sub(&b->rd, 1);
  if ((int)t > 0) {
    got = H[b->off + t - 1];
  } else {
    a32_add(&b->rd, 1);
  }
  if (!DEVICE) {
    b->wr = b->top = b->rd;
  }
  UNLOCK(bank_lock);
  return got;
}

INLINE void bank_push(Corpus H, Cls c, Loc head) {
  DEV Bank* b = bank_at(H, c);
  LOCK(bank_lock);
  H[b->off + a32_add(&b->wr, 1)] = head;
  if (!DEVICE) {
    b->rd = b->top = b->wr;
  }
  UNLOCK(bank_lock);
}

// Heap
// ====

// Per lane and class (a tile row on the device): HOT, a LIFO chain of
// free slots (word 0 the head it replaced); LEN, its exact length in
// words, off the chain; on the host COLD, one generation. A free is a
// push and an add. A host free at KEEP_WORDS (a slot for a wide class)
// runs heap_hand: COLD to the bank, HOT parked as COLD, generations
// exact. A miss takes COLD, else a bank entry, else a quantum of at
// most a generation, and sets LEN to what it took: no adoption past a
// generation, no list re-aged. A device lane keeps its frees for the
// pass; at the kernel end dev_cut hands its complete generations,
// walking only those. KEEP_WORDS is CAP_WORDS, or CHUNK with the GPU
// (fixed at boot), so a device lane may adopt every host entry.
// Bounds: a host lane and class under 2 max(KEEP_WORDS, 2^c) words, a
// device one under max(CHUNK, 2^c) after each kernel plus its own
// frees within one, bank entries exact. The bump grows only when this
// lane's HOT and COLD and the class's bank are empty. A zero row is an
// empty lane.

#define ALC_AT(e, i)   (e).alc[(i) * LANE_STEP]
#define ALC_LEN(e, c)  ALC_AT(e, ALC_WORDS + (c))
#define ALC_COLD(e, c) ALC_AT(e, 2 * ALC_WORDS + (c))
#define KEEP(c)        (KEEP_WORDS >> (c) ? KEEP_WORDS >> (c) : 1)

OUTLINE void heap_hand(Env e, Cls cls) {
  Loc cold = ALC_COLD(e, cls);
  if (cold) {
    bank_push(e.mem, cls, cold);
  }
  ALC_COLD(e, cls) = ALC_AT(e, cls);
  ALC_AT(e, cls)   = 0;
  ALC_LEN(e, cls)  = 0;
}

#if DEVICE
#define corpus_grow(H, n) false
#else
static bool corpus_grow(Corpus H, u64 need);
#endif

OUTLINE Loc heap_alloc_miss(Env e, Cls cls) {
  Corpus H = e.mem;
  Loc  got = 0;
  if (!DEVICE) {
    got = ALC_COLD(e, cls);
    ALC_COLD(e, cls) = 0;
  }
  if (!got) {
    got = bank_pop(H, cls);
  }
  u32 n = got ? KEEP(cls) : cls < NCLS ? QUANTUM >> cls : 1;
  if (!got) {
    u32 pages = (n << cls) >> PAGE_BITS;
    u32 p     = a32_add(a32_at(H, H_BUMP), pages);
    if ((u64)p + pages > a32_load_acq(a32_at(H, H_CAP))
      && !corpus_grow(H, (u64)p + pages)) {
      err_post(H, ERR_HEAP);
      p = 0;
    }
    got = HEAP_OFF + ((u64)p << PAGE_BITS);
    for (u32 i = 1; i <= n; i += 1) {
      H[got + ((u64)(i - 1) << cls)] = i < n ? got + ((u64)i << cls) : 0;
    }
  }
  ALC_AT(e, cls)  = H[got];
  ALC_LEN(e, cls) = (u64)(n - 1) << cls;
  return got;
}

INLINE Loc heap_alloc(Env e, Cls cls) {
  Loc h = ALC_AT(e, cls);
  if (h) {
    ALC_AT(e, cls)   = e.mem[h];
    ALC_LEN(e, cls) -= 1ull << cls;
    return h;
  }
  return heap_alloc_miss(e, cls);
}

INLINE void heap_free(Env e, Cls cls, Loc loc) {
  if (err_seen(e.mem)) {
    return;
  }
  e.mem[loc]       = ALC_AT(e, cls);
  ALC_AT(e, cls)   = loc;
  ALC_LEN(e, cls) += 1ull << cls;
  if (!DEVICE && ALC_LEN(e, cls) >= KEEP_WORDS) {
    heap_hand(e, cls);
  }
}

// Spare
// =====

INLINE void spare_free(Env e, Cls cls, Loc loc) {
  if (loc >= HEAP_OFF) {
    heap_free(e, cls, loc);
  }
}

// Term
// ====

#define term_make(tag, aux, loc) \
  (((u64)(tag) << 56) | ((u64)(aux) << 40) | (u64)(loc))

#define term_ctr(cid, loc) term_make(TAG_CTR, cid, loc)
#define term_pak(cid, loc) term_make(TAG_PAK, cid, loc)
#define term_clo(fid, loc) term_make(TAG_CLO, fid, loc)
#define term_buf(cls, loc) term_make(TAG_BUF, cls, loc)
#define term_tsk(fid, loc) term_make(TAG_TSK, fid, loc)

INLINE Term term_blk(bool arr, Cls cls, Loc loc) {
  return term_buf(cls, loc) | ((u64)arr << 57);
}

INLINE u64 term_tag(Term t) {
  return (t >> 56) & 0x7f;
}

INLINE bool term_rfc(Term t) {
  return (t & RFC_BIT) != 0;
}

INLINE u64 term_aux(Term t) {
  return (t >> 40) & 0xFFFF;
}

INLINE Loc term_loc(Term t) {
  return t & LOC_MASK;
}

// A static node (below the heap) is trivial, as is a captureless closure.
INLINE bool term_triv(Term t) {
  return term_tag(t) <= TAG_PAK || t == TERM_HOLE || term_loc(t) < HEAP_OFF;
}

OUTLINE Term rfc_wrap(Env e, Term t, u32 cnt) {
  if (term_tag(t) == TAG_CLO || term_tag(t) == TAG_TSK) {
    err_post(e.mem, ERR_RFCS);
    return t;
  }
  Loc r = heap_alloc(e, 0);
  e.mem[r] = ((u64)term_loc(t) << 24) | cnt;
  return (t & ~LOC_MASK) | RFC_BIT | r;
}

INLINE Term rfc_seal(Env e, Term t) {
  if (term_tag(t) != TAG_CTR || term_rfc(t)) {
    return t;
  }
  return rfc_wrap(e, t, 1);
}

INLINE u64 rfc_view(Env e, Loc r) {
  DEV u32* w = a32_at(e.mem, r);
  u64 cell = ((u64)a32_load(w + 1) << 32) | a32_load(w);
  if ((cell & RFC_CNT) == 1) {
    a32_acq(w);
  }
  return cell;
}

INLINE void rfc_bump(Env e, Loc r, u32 k) {
  u32 c = a32_add(a32_at(e.mem, r), k);
  if ((c & RFC_CNT) >= RFC_CNT - k) {
    err_post(e.mem, ERR_RFCS);
  }
}

INLINE Term term_keep(Env e, Term t) {
  if (term_rfc(t)) {
    rfc_bump(e, term_loc(t), 1);
    return t;
  }
  if (term_triv(t)) {
    return t;
  }
  return rfc_wrap(e, t, 2);
}

INLINE Loc term_peek(Env e, Term t) {
  if (term_rfc(t)) {
    return rfc_view(e, term_loc(t)) >> 24;
  }
  return term_loc(t);
}

INLINE Cls blk_cls(Term t) {
  return (u32)term_aux(t) & 31;
}

#define buf_wcls(c) ((c) == 0 ? 0 : (c) - 1)

INLINE Cls blk_span(Term t) {
  Cls c = blk_cls(t);
  return term_tag(t) == TAG_ARR ? c : buf_wcls(c);
}

FAR void term_drop(Env e, Term t);

INLINE void blk_free(Env e, Term t) {
  if (term_rfc(t)) {
    term_drop(e, t);
  } else {
    heap_free(e, blk_span(t), term_loc(t));
  }
}

FAR void term_drop(Env e, Term t) {
  Corpus H = e.mem;
  u64  cur = 0;
  Term c0  = 0;
  u32  step = 0;
  for (;;) {
    if (!term_triv(t) && term_rfc(t)) {
      Loc      r = term_loc(t);
      DEV u32* p = a32_at(H, r);
      if ((a32_sub_rel(p, 1) & RFC_CNT) != 1) {
        t = 0;
      } else {
        a32_acq(p);
        t = (t & ~(RFC_BIT | LOC_MASK)) | (H[r] >> 24);
        heap_free(e, 0, r);
      }
    }
    if (!term_triv(t)) {
      u64 tag = term_tag(t);
      if (tag == TAG_BUF) {
        blk_free(e, t);
      } else {
        u32 aux = (u32)term_aux(t);
        Loc loc = term_loc(t);
        u32 n   = 0;
        Cls cls;
        if (tag == TAG_ARR) {
          cls = 64 | blk_cls(t);
        } else {
          u32 ar;
          if (tag == TAG_CTR) {
            ar = cid_arity(aux);
          } else if (tag == TAG_CLO) {
            ar = fid_arity(aux) - 1;
          } else {
            ar = fid_arity(aux);
          }
          n   = ar;
          cls = cls_fit(tag == TAG_TSK ? ar + 2 : ar);
        }
        c0 = H[loc];
        H[loc] = cur;
        cur = loc | ((u64)n << 48) | ((u64)cls << 56);
      }
    }
    for (;;) {
      if (err_spun(H, &step)) {
        return;
      }
      if (cur == 0) {
        return;
      }
      Loc  loc = cur & LOC_MASK;
      u32  i   = (u8)(cur >> 40);
      u32  n   = (u8)(cur >> 48);
      Cls  cls = (u32)(cur >> 56);
      bool arr = cls > 63;
      u32  j   = i;
      if (arr) {
        cls &= 63;
        n   = 1u << cls;
        if (i == 2) {
          j = (u32)H[loc + 1];
        }
      }
      if (j < n) {
        Term c = j == 0 ? c0 : H[loc + j];
        if (arr && j > 0) {
          H[loc + 1] = j + 1;
        }
        if (!arr || i < 2) {
          cur += 1ull << 40;
        }
        if (!term_triv(c)) {
          t = c;
          break;
        }
      } else {
        u64 up = H[loc];
        heap_free(e, cls, loc);
        cur = up;
      }
    }
  }
}

INLINE void term_sink(Env e, Term t) {
  if (!term_triv(t)) {
    term_drop(e, t);
  }
}

OUTLINE void span_fade(Env e, Term t, Loc src, u32 n) {
  for (u32 j = 0; j < n; j += 1) {
    Term f = e.mem[src + j];
    if (term_rfc(f)) {
      rfc_bump(e, term_loc(f), 1);
    } else if (!term_triv(f)) {
      err_post(e.mem, ERR_RFCS);
    }
  }
  term_drop(e, t);
}

INLINE Loc ctr_take(Env e, Term t, u32 n, THR Term* out) {
  Corpus H = e.mem;
  if (!term_rfc(t)) {
    for (u32 j = 0; j < n; j += 1) {
      out[j] = H[term_loc(t) + j];
    }
    return term_loc(t);
  }
  Loc r    = term_loc(t);
  u64 cell = rfc_view(e, r);
  Loc src  = cell >> 24;
  for (u32 j = 0; j < n; j += 1) {
    out[j] = H[src + j];
  }
  if ((cell & RFC_CNT) == 1) {
    heap_free(e, 0, r);
    return src;
  }
  span_fade(e, t, src, n);
  return 0;
}

INLINE Term term_word(Env e, Term w) {
  u32 x = 0;
  Term t = w;
  for (u32 i = 0; i < 32 && term_aux(t) == CID_WCON; i += 1) {
    Loc l = term_peek(e, t);
    x |= (u32)(e.mem[l] & 1) << i;
    t = e.mem[l + 1];
  }
  term_sink(e, w);
  return x;
}

// Blk
// ===

#ifndef NATIVE_SCALAR_ARRAYS
#define NATIVE_SCALAR_ARRAYS 0
#endif
#ifndef NATIVE_UNSHARED_ARRAYS
#define NATIVE_UNSHARED_ARRAYS 0
#endif

// A block owns one allocation in its physical class (an ARR of class
// c 2^c Terms in 2^c words, a BUF 2^c u32 in 2^buf_wcls(c) words) and
// blk_free returns it there. A match on ANode is blk_half twice: each
// half allocated in its class and copied, the source freed shallow by
// the high call (its elements moved; the emitter binds the low half
// first). ANode{l, r} is blk_node: the merged class, l and r copied
// and freed shallow. Shared handles instead retain copied ARR elements and
// decrement their RFC; Array.clone keeps the original first and a fresh copy
// second. A match to the leaves copies
// O(n log n) words where a view copied none; get, set, swap, size and
// new open no half.

#define BLK_ALLOC(n, w) \
  Loc n = heap_alloc(e, w); \
  if (err_seen(e.mem)) { \
    return term_buf(0, n); \
  }

INLINE DEV u32a* blk_ptr(Corpus H, Loc loc, u32 i) {
  return (DEV u32a*)(H + loc) + i;
}

INLINE Term blk_read(Corpus H, bool arr, Loc loc, u32 i) {
  if (arr) {
    return H[loc + i];
  }
  return (u64)*blk_ptr(H, loc, i);
}

INLINE void blk_write(Corpus H, bool arr, Loc loc, u32 i, Term v) {
  if (arr) {
    H[loc + i] = v;
  } else {
    *blk_ptr(H, loc, i) = (u32)v;
  }
}

INLINE u32 blk_at(Term a, U32 i, u32 lgs) {
  return ((u32)i & (u32)((1ull << (blk_cls(a) - lgs)) - 1)) << lgs;
}

INLINE Term blk_keep(Env e, Loc at) {
  Term w = e.mem[at];
  Term v = term_keep(e, w);
  if (v != w) {
    e.mem[at] = v;
  }
  return v;
}

// A shared leaf gives its caller a retained element before dropping the handle.
INLINE Term blk_leaf(Env e, Term a) {
  Loc at = term_peek(e, a);
  if (term_tag(a) == TAG_BUF) return blk_read(e.mem, false, at, 0);
  return term_rfc(a) ? blk_keep(e, at) : e.mem[at];
}

// Packed arrays use adjacent U32 slots; uniform arrays use each word's low half.
// Existing a32 operations provide a single atomic update for every backend.
INLINE u64 array_atomic(Env e, Term a, u32 i, u32 v, u32 x, u32 op) {
  Loc loc = term_peek(e, a);
  u32 at = blk_at(a, i, 0);
  DEV u32* p = a32_at(e.mem, loc) + (term_tag(a) == TAG_BUF ? at : 2 * at);
  u32 old = a32_load(p);
  for (;;) {
    u32 next = v;
    switch (op) {
      case 1: next = old + v; break;
      case 2: next = old < v ? old : v; break;
      case 3: next = old > v ? old : v; break;
      case 4: next = old & v; break;
      case 5: next = old | v; break;
      case 6: next = old ^ v; break;
      case 8: next = old == v ? x : old; break;
      case 9: next = (u32)f32_rewrap(f32_unbox(old) + f32_unbox(v)); break;
    }
    u32 expected = old;
    if (a32_cas(p, &expected, next)) {
      return old;
    }
    old = expected;
  }
}

OUTLINE Term blk_copy(Env e, Term a) {
  Corpus H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  Cls cls = blk_span(a);
  Loc src = term_peek(e, a);
  BLK_ALLOC(dst, cls)
  for (u64 j = 0; j < (1ull << cls); j += 1) {
    H[dst + j] = arr ? blk_keep(e, src + j) : H[src + j];
  }
  return term_blk(arr, blk_cls(a), dst);
}

INLINE Term blk_node(Env e, Term l, Term r) {
  Corpus H = e.mem;
  bool arr = term_tag(l) == TAG_ARR;
  Cls c = blk_cls(l);
  if (c != blk_cls(r) || c + 1 >= NCLS_ALL) {
    err_post(H, ERR_TAGS);
    return l;
  }
  Loc pl = term_peek(e, l);
  Loc pr = term_peek(e, r);
  BLK_ALLOC(n, arr ? c + 1 : c)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, pl, 0) | ((u64)*blk_ptr(H, pr, 0) << 32);
  } else {
    u64 cw = 1ull << blk_span(l);
    for (u64 w = 0; w < cw; w += 1) {
      H[n + w]      = arr && term_rfc(l) ? blk_keep(e, pl + w) : H[pl + w];
      H[n + cw + w] = arr && term_rfc(r) ? blk_keep(e, pr + w) : H[pr + w];
    }
  }
  blk_free(e, l);
  blk_free(e, r);
  return term_blk(arr, c + 1, n);
}

INLINE Term blk_half(Env e, Term a, u32 hi) {
  Corpus H = e.mem;
  bool arr = term_tag(a) == TAG_ARR;
  Cls c = blk_cls(a);
  if (c == 0) {
    err_post(H, ERR_TAGS);
    return a;
  }
  c -= 1;
  Cls cw = arr ? c : buf_wcls(c);
  BLK_ALLOC(n, cw)
  if (!arr && c == 0) {
    H[n] = (u64)*blk_ptr(H, term_peek(e, a), hi);
  } else {
    Loc src = term_peek(e, a) + ((u64)hi << cw);
    for (u64 w = 0; w < (1ull << cw); w += 1) {
      H[n + w] = arr && term_rfc(a) ? blk_keep(e, src + w) : H[src + w];
    }
  }
  if (hi) {
    blk_free(e, a);
  }
  return term_blk(arr, c, n);
}

INLINE Term blk_new(Env e, bool arr, Nat d, u32 lgs, u32 n, THR Term* v) {
  Corpus H = e.mem;
  if (d + lgs > 31) {
    err_post(H, ERR_ARRS);
    d = 0;
  }
  Cls c = (u32)d + lgs;
  BLK_ALLOC(l, arr ? c : buf_wcls(c))
  for (u32 j = 0; j < n; j += 1) {
    Term w = v[j];
    if (arr && d > 0 && !term_triv(w)) {
      if (d >= 24) {
        err_post(H, ERR_RFCS);
      } else if (term_rfc(w)) {
        rfc_bump(e, term_loc(w), (1u << d) - 1);
      } else {
        w = rfc_wrap(e, w, 1u << d);
      }
    }
    v[j] = w;
  }
  for (u64 i = 0; i < (1ull << c); i += 1) {
    blk_write(H, arr, l, (u32)i, i % (1u << lgs) < n ? v[i % (1u << lgs)] : 0);
  }
  return term_blk(arr, c, l);
}

// The checked compiler may select one scalar layout for all reachable arrays.
// Raw/unknown programs retain the uniform word ABI. Handle sharing is independent.
INLINE Term native_array_get(Env e, Term a, u32 i) {
  u32 at = blk_at(a, i, 0);
  Loc loc = NATIVE_UNSHARED_ARRAYS ? term_loc(a) : term_peek(e, a);
  return NATIVE_SCALAR_ARRAYS ? blk_read(e.mem, false, loc, at) : blk_keep(e, loc + at);
}

INLINE Term native_array_swap(Env e, Term a, u32 i, Term value) {
  u32 at = blk_at(a, i, 0);
  Loc loc = NATIVE_UNSHARED_ARRAYS ? term_loc(a) : term_peek(e, a);
  Term old = blk_read(e.mem, !NATIVE_SCALAR_ARRAYS, loc, at);
  blk_write(e.mem, !NATIVE_SCALAR_ARRAYS, loc, at, NATIVE_SCALAR_ARRAYS ? value : rfc_seal(e, value));
  return old;
}

INLINE void native_array_set(Env e, Term a, u32 i, Term value) {
  u32 at = blk_at(a, i, 0);
  Loc loc = NATIVE_UNSHARED_ARRAYS ? term_loc(a) : term_peek(e, a);
  if (!NATIVE_SCALAR_ARRAYS) term_sink(e, blk_read(e.mem, true, loc, at));
  blk_write(e.mem, !NATIVE_SCALAR_ARRAYS, loc, at, NATIVE_SCALAR_ARRAYS ? value : rfc_seal(e, value));
}

// Ring
// ====

// planes LANES wide: a smaller bag has deeper rings in the same region
#define ring_word(H, r, w) ((H) + RING_OFF + (w) * LANES + (r))
#define ring_slot(H, r, p) ring_word(H, r, (p) & (RING_LEN - 1))
#define ring_get(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN))
#define ring_put(H, r)     ((DEV u32*)ring_word(H, r, RING_LEN + 1))

INLINE u32 ring_lap(u32 pos) {
  return ~(u32)(pos / RING_LEN) & 1;
}

INLINE void ring_push(Corpus H, Ring r, Term tsk) {
  u32 pos = a32_add(ring_put(H, r), 1);
  if (pos - a32_load(ring_get(H, r)) >= RING_LEN) {
    err_post(H, ERR_RING);
    return;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, r, pos);
  a32_store(lo, (u32)tsk);
  a32_store_rel(lo + 1, (u32)(tsk >> 32) | (ring_lap(pos) << 31));
}

INLINE Ring ring_flip(u32 i) {
  return (i % CUBE_T << CUBE_LOG) + i / CUBE_T;
}

#define ring_pick(b, s, c) ((b) + (s) * (g32_add(c, 1) & (CUBE_T - 1)))

// Task
// ====

INLINE Loc task_node(Env e, Fid fid, Term cont, u32 idx, u32 rem) {
  u32 ar  = fid_arity(fid);
  Loc loc = heap_alloc(e, cls_fit(ar + 2));
  for (u32 i = 0; rem && i < ar; i += 1) {
    e.mem[loc + i] = TERM_HOLE;
  }
  e.mem[loc + ar]     = cont;
  e.mem[loc + ar + 1] = ((u64)idx << 32) | rem;
  return loc;
}

INLINE Loc task_tail(Term t) {
  return term_loc(t) + fid_arity((u32)term_aux(t));
}

INLINE Term task_deliver(Corpus H, Term cont, u32 idx, THR Term* v, u32 n) {
  Loc at = cont == TERM_HOLE ? H_ROOT_WORD : term_loc(cont) + idx;
  for (u32 j = 0; j < WL_RESW; j += 1) {
    if (j < n) {
      H[at + j] = v[j];
    }
  }
  if (cont == TERM_HOLE) {
    a32_store_rel(a32_at(H, H_ROOT_DONE), n + 1);
    return 0;
  }
  Loc tl = task_tail(cont);
  if (a32_sub_rel(a32_at(H, tl + 1), 1) == 1) {
    a32_acq(a32_at(H, tl + 1));
    return cont;
  }
  return 0;
}

INLINE void task_deal(Corpus H, Term join, u32 base, u32 stride, Cur cur) {
  Loc loc = term_loc(join);
  u32 ar  = fid_arity((u32)term_aux(join));
  u32 g   = 0;
  if (stride == 0) {
    u32 rem = (u32)H[loc + ar + 1];
    g = a32_add(a32_at(H, H_CURSOR), rem);
  }
  for (u32 i = 0; i < ar; i += 1) {
    Term k = H[loc + i];
    if (term_tag(k) == TAG_TSK) {
      H[loc + i] = TERM_HOLE;
      Ring to;
      if (stride != 0) {
        to = ring_pick(base, stride, cur);
      } else {
        to = ring_flip(g & (u32)(LANES - 1));
        g += 1;
      }
      ring_push(H, to, k);
    }
  }
}

// Root
// ====

INLINE bool root_done(Corpus H) {
  return a32_load_acq(a32_at(H, H_ROOT_DONE)) != 0;
}

static u32 root_take(Corpus H, THR Term* v) {
  u32 n = a32_load_acq(a32_at(H, H_ROOT_DONE)) - 1;
  for (u32 j = 0; j < n; j += 1) {
    v[j] = H[H_ROOT_WORD + j];
  }
  a32_store(a32_at(H, H_ROOT_DONE), 0);
  return n;
}

// Spins
// =====

CONSTV u64 STAT_IMG[] = { 59ull, term_pak(CID_SNIL, 0), 32ull, term_ctr(CID_SCON, STAT_OFF + 0), 41ull, term_ctr(CID_SCON, STAT_OFF + 2), 32ull, term_ctr(CID_SCON, STAT_OFF + 4), 105ull, term_ctr(CID_SCON, STAT_OFF + 6), 32ull, term_ctr(CID_SCON, STAT_OFF + 8), 111ull, term_ctr(CID_SCON, STAT_OFF + 10), 32ull, term_ctr(CID_SCON, STAT_OFF + 12), 110ull, term_ctr(CID_SCON, STAT_OFF + 14), 32ull, term_ctr(CID_SCON, STAT_OFF + 16), 40ull, term_ctr(CID_SCON, STAT_OFF + 18), 32ull, term_ctr(CID_SCON, STAT_OFF + 20), 111ull, term_ctr(CID_SCON, STAT_OFF + 22), 32ull, term_ctr(CID_SCON, STAT_OFF + 24), 41ull, term_ctr(CID_SCON, STAT_OFF + 26), 32ull, term_ctr(CID_SCON, STAT_OFF + 28), 105ull, term_ctr(CID_SCON, STAT_OFF + 30), 32ull, term_ctr(CID_SCON, STAT_OFF + 32), 111ull, term_ctr(CID_SCON, STAT_OFF + 34), 32ull, term_ctr(CID_SCON, STAT_OFF + 36), 110ull, term_ctr(CID_SCON, STAT_OFF + 38), 32ull, term_ctr(CID_SCON, STAT_OFF + 40), 40ull, term_ctr(CID_SCON, STAT_OFF + 42), 32ull, term_ctr(CID_SCON, STAT_OFF + 44), 111ull, term_ctr(CID_SCON, STAT_OFF + 46), 32ull, term_ctr(CID_SCON, STAT_OFF + 48), 41ull, term_ctr(CID_SCON, STAT_OFF + 50), 32ull, term_ctr(CID_SCON, STAT_OFF + 52), 105ull, term_ctr(CID_SCON, STAT_OFF + 54), 32ull, term_ctr(CID_SCON, STAT_OFF + 56), 111ull, term_ctr(CID_SCON, STAT_OFF + 58), 32ull, term_ctr(CID_SCON, STAT_OFF + 60), 110ull, term_ctr(CID_SCON, STAT_OFF + 62), 32ull, term_ctr(CID_SCON, STAT_OFF + 64), 40ull, term_ctr(CID_SCON, STAT_OFF + 66), 32ull, term_ctr(CID_SCON, STAT_OFF + 68), 61ull, term_ctr(CID_SCON, STAT_OFF + 70), 32ull, term_ctr(CID_SCON, STAT_OFF + 72), 105ull, term_ctr(CID_SCON, STAT_OFF + 74), term_pak(CID__CTOR_71_97_112_, 0), 0ull, 48ull, term_pak(CID_SNIL, 0) };
INLINE bool native_bool(Term t) { return t == 1 || (term_tag(t) == TAG_PAK && term_aux(t) == CID_TRUE); }
INLINE Term native_word(Env e, u32 x) {
  Term w = term_pak(CID_WNIL, 0);
  for (u32 i = 32; i > 0; i--) {
    Loc p = heap_alloc(e, 1);
    e.mem[p] = (x >> (i - 1)) & 1;
    e.mem[p + 1] = rfc_seal(e, w);
    w = term_ctr(CID_WCON, p);
  }
  return w;
}
#if !DEVICE
#if NATIVE_TYPED_SCALARS
#define NF_SCALAR u32
#else
#define NF_SCALAR Term
#endif
#if defined(__GNUC__) || defined(__clang__)
#define NF_INLINE INLINE __attribute__((always_inline))
#else
#define NF_INLINE INLINE
#endif
/* Experimental private cache of one uniquely transferred constructor cell.
 * ctr_take's returned cell has no remaining owner. Its fields have already
 * moved to ordinary local Terms. Shared inputs return zero; static inputs
 * may return a read-only location below HEAP_OFF and must never be cached.
 * The public wrapper frees any unused cell before publishing its result.
 */
INLINE void p102_trmc_keep_cell(Env e, Term* state, Cls cls, Loc cell) {
  if (cell < HEAP_OFF) return;
  if (state[2]) spare_free(e, (Cls)state[3], (Loc)state[2]);
  state[2] = cell;
  state[3] = cls;
}

INLINE Loc p102_trmc_take_cell(Env e, Term* state, Cls cls) {
  if (state[2] && state[3] == cls) {
    Loc cell = (Loc)state[2];
    state[2] = 0;
    return cell;
  }
  return heap_alloc(e, cls);
}
NF_INLINE Term NF_FID_115_105_122_101_46_98_105_103_(Env e, bool seq, Term* nf_out);
NF_INLINE Term NF_FID_115_101_101_100_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295);
NF_INLINE Term NF_FID_116_112_108_(Env e, bool seq, Term* nf_out);
NF_INLINE Term NF_FID_115_97_108_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294);
NF_INLINE Term NF_FID_115_108_111_116_46_103_111_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293);
NF_INLINE Term NF_FID_115_108_111_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295);
NF_INLINE Term NF_FID_111_112_46_112_105_99_107_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294);
NF_INLINE Term NF_FID_111_112_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, Term v_4294967294);
NF_INLINE Term NF_FID_110_117_109_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293);
NF_INLINE Term NF_FID_112_114_110_103_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295);
NF_INLINE Term NF_FID_105_100_101_110_116_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293);
NF_INLINE Term NF_FID_101_120_112_97_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293, Term v_4294967292);
INLINE Term NF_FID_103_101_110_46_97_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293);
NF_INLINE Term NF_FID_66_111_111_108_46_97_110_100_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294);
NF_INLINE Term NF_FID_99_108_115_46_103_111_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293);
NF_INLINE Term NF_FID_99_108_115_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295);
NF_INLINE Term NF_FID_102_110_118_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294);
INLINE Term NF_FID_115_116_101_112_46_97_116_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294, NF_SCALAR v_4294967293, NF_SCALAR v_4294967292);
INLINE Term NF_FID_115_116_101_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293);
NF_INLINE Term NF_FID_109_105_120_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293);
NF_INLINE Term NF_FID_102_108_117_115_104_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294);
INLINE Term NF_FID_108_101_120_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294);
INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_46_97_116_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294, NF_SCALAR v_4294967293, NF_SCALAR v_4294967292);
INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293);
INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_108_101_120_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967293, Term v_4294967292);
NF_INLINE Term NF_FID_115_105_122_101_46_98_105_103_(Env e, bool seq, Term* nf_out) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
nf_out[0] = 23ull;
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_115_101_101_100_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967294;
{
Term v_4294967291;
{
Term v_4294967287;
{
v_4294967287 = v_4294967295;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967286;
{
v_4294967286 = 1ull;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967291 = U32_BIN(v_4294967287, +, v_4294967286);
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = 2654435761ull;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967294 = U32_BIN(v_4294967291, *, v_4294967290);
goto nf_join_2;
}
nf_join_2:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_3[1];
if (!NF_FID_112_114_110_103_(e, seq, nq_result_3, v_4294967294)) { return 0; }
nf_out[0] = nq_result_3[0];
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_116_112_108_(Env e, bool seq, Term* nf_out) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
nf_out[0] = term_ctr(CID_SCON, STAT_OFF + 76);
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_115_97_108_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
Term v_4294967290;
{
v_4294967290 = v_4294967295;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
Term v_4294967286;
{
v_4294967286 = v_4294967294;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967285;
{
v_4294967285 = 2654435761ull;
goto nf_join_12;
}
nf_join_12:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967289 = U32_BIN(v_4294967286, *, v_4294967285);
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967293 = U32_BIN(v_4294967290, ^, v_4294967289);
goto nf_join_3;
}
nf_join_3:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_4[1];
if (!NF_FID_112_114_110_103_(e, seq, nq_result_4, v_4294967293)) { return 0; }
nf_out[0] = nq_result_4[0];
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_115_108_111_116_46_103_111_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967292;
{
v_4294967292 = v_4294967295;
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
v_4294967291 = v_4294967294;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967292)) {
Term v_4294967286;
{
v_4294967286 = v_4294967291;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967285;
{
v_4294967285 = v_4294967290;
goto nf_join_12;
}
nf_join_12:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967286)) {
if (native_bool(v_4294967285)) {
nf_out[0] = term_pak(CID__CTOR_73_100_, 0);
return 1;
} else {
term_sink(e, v_4294967285);
nf_out[0] = term_pak(CID__CTOR_73_100_, 0);
return 1;
}
} else {
term_sink(e, v_4294967286);
if (native_bool(v_4294967285)) {
nf_out[0] = term_pak(CID__CTOR_73_100_, 0);
return 1;
} else {
term_sink(e, v_4294967285);
nf_out[0] = term_pak(CID__CTOR_73_100_, 0);
return 1;
}
}
} else {
term_sink(e, v_4294967292);
Term v_4294967282;
{
v_4294967282 = v_4294967291;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = v_4294967290;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967282)) {
if (native_bool(v_4294967281)) {
nf_out[0] = term_pak(CID__CTOR_78_109_, 0);
return 1;
} else {
term_sink(e, v_4294967281);
nf_out[0] = term_pak(CID__CTOR_78_109_, 0);
return 1;
}
} else {
term_sink(e, v_4294967282);
if (native_bool(v_4294967281)) {
nf_out[0] = term_pak(CID__CTOR_79_112_, 0);
return 1;
} else {
term_sink(e, v_4294967281);
nf_out[0] = term_pak(CID__CTOR_76_105_116_, 0);
return 1;
}
}
}
}
return 0;
}
NF_INLINE Term NF_FID_115_108_111_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967294;
{
Term v_4294967279;
{
v_4294967279 = v_4294967295;
goto nf_join_18;
}
nf_join_18:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967278;
{
v_4294967278 = 105ull;
goto nf_join_19;
}
nf_join_19:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967294 = U32_BIN(v_4294967279, ==, v_4294967278);
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967293;
{
Term v_4294967283;
{
v_4294967283 = v_4294967295;
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
v_4294967282 = 110ull;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967293 = U32_BIN(v_4294967283, ==, v_4294967282);
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
Term v_4294967287;
{
v_4294967287 = v_4294967295;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967286;
{
v_4294967286 = 111ull;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967292 = U32_BIN(v_4294967287, ==, v_4294967286);
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_7[1];
if (!NF_FID_115_108_111_116_46_103_111_(e, seq, nq_result_7, v_4294967294, v_4294967293, v_4294967292)) { return 0; }
nf_out[0] = nq_result_7[0];
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_111_112_46_112_105_99_107_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((!native_bool(v_4294967293))) {
if ((!native_bool(v_4294967292))) {
nf_out[0] = 43ull;
return 1;
} else {
if (native_bool(v_4294967292)) {
nf_out[0] = 45ull;
return 1;
} else {
term_sink(e, v_4294967292);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967289)) {
if ((!native_bool(v_4294967288))) {
nf_out[0] = 42ull;
return 1;
} else {
if (native_bool(v_4294967288)) {
nf_out[0] = 47ull;
return 1;
} else {
term_sink(e, v_4294967288);
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
term_sink(e, v_4294967289);
term_sink(e, v_4294967288);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_111_112_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967288;
{
Term v_4294967275;
{
Term v_4294967271;
{
v_4294967271 = v_4294967295;
goto nf_join_26;
}
nf_join_26:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967270;
{
v_4294967270 = 2ull;
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967275 = U32_BIN(v_4294967271, &, v_4294967270);
goto nf_join_22;
}
nf_join_22:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967274;
{
v_4294967274 = 0ull;
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967288 = U32_BIN(v_4294967275, !=, v_4294967274);
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967287;
{
Term v_4294967283;
{
Term v_4294967279;
{
v_4294967279 = v_4294967295;
goto nf_join_18;
}
nf_join_18:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967278;
{
v_4294967278 = 1ull;
goto nf_join_19;
}
nf_join_19:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967283 = U32_BIN(v_4294967279, &, v_4294967278);
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
v_4294967282 = 0ull;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967287 = U32_BIN(v_4294967283, !=, v_4294967282);
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_11[1];
if (!NF_FID_111_112_46_112_105_99_107_(e, seq, nq_result_11, v_4294967288, v_4294967287)) { return 0; }
v_4294967293 = nq_result_11[0];
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_6 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_6 + 0] = v_4294967293;
e.mem[nd_6 + 1] = v_4294967292;
#else
e.mem[nd_6 + 0] = rfc_seal(e, v_4294967293);
e.mem[nd_6 + 1] = rfc_seal(e, v_4294967292);
#endif
nf_out[0] = term_ctr(CID_SCON, nd_6);
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_110_117_109__trmc(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967292;
{
v_4294967292 = v_4294967295;
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
v_4294967291 = v_4294967294;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294967292 == 0)) {
term_sink(e, v_4294967291);
if (nf_out[1] != 0) { e.mem[nf_out[1]] = nf_out[4] ? rfc_seal(e, v_4294967290) : v_4294967290; } else { nf_out[0] = v_4294967290; }
return 1;
} else {
Term v_4294967286;
{
v_4294967286 = v_4294967292;
goto nf_join_12;
}
nf_join_12:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967285;
{
v_4294967285 = v_4294967291;
goto nf_join_13;
}
nf_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967284;
{
v_4294967284 = v_4294967290;
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294967286 != 0)) {
#if !DEVICE && NATIVE_FIELD32_CID_SUCC_0
u32
#else
Term
#endif
v_4294967280 = (v_4294967286 - 1);
Term v_3500;
{
Term v_4294967258;
{
v_4294967258 = v_4294967285;
goto nf_join_38;
}
nf_join_38:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_39[1];
if (!NF_FID_112_114_110_103_(e, seq, nq_result_39, v_4294967258)) { return 0; }
v_3500 = nq_result_39[0];
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
v_3500 = term_keep(e, v_3500);
Term v_4294967278;
{
Term v_4294967268;
{
Term v_4294967266;
{
v_4294967266 = 48ull;
goto nf_join_31;
}
nf_join_31:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967265;
{
Term v_4294967262;
{
v_4294967262 = v_3500;
goto nf_join_35;
}
nf_join_35:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967261;
{
v_4294967261 = 10ull;
goto nf_join_36;
}
nf_join_36:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967265 = ((u32)(v_4294967261) == 0 ? v_4294967262 : U32_BIN(v_4294967262, -, U32_QUO((u32)(v_4294967262), (u32)(v_4294967261)) * v_4294967261));
goto nf_join_32;
}
nf_join_32:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967268 = U32_BIN(v_4294967266, +, v_4294967265);
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967278 = v_4294967268;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967277;
{
v_4294967277 = v_4294967280;
goto nf_join_22;
}
nf_join_22:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967276;
{
v_4294967276 = v_3500;
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967275;
{
v_4294967275 = v_4294967284;
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_25 = p102_trmc_take_cell(e, nf_out, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_25 + 0] = v_4294967278;
e.mem[nd_25 + 1] = TERM_HOLE;
#else
e.mem[nd_25 + 0] = rfc_seal(e, v_4294967278);
e.mem[nd_25 + 1] = rfc_seal(e, TERM_HOLE);
#endif
Term ntr_node_26 = term_ctr(CID_SCON, nd_25);
if (nf_out[1] != 0) { e.mem[nf_out[1]] = nf_out[4] ? rfc_seal(e, ntr_node_26) : ntr_node_26; } else { nf_out[0] = ntr_node_26; }
nf_out[1] = term_loc(ntr_node_26) + 1;
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
nf_out[4] = 0;
#else
nf_out[4] = 1;
#endif
{
Term nf_arg_0 = v_4294967277;
Term nf_arg_1 = v_4294967276;
Term nf_arg_2 = v_4294967275;
v_4294967295 = nf_arg_0;
v_4294967294 = nf_arg_1;
v_4294967293 = nf_arg_2;
goto nf_again;
}
} else {
term_sink(e, v_4294967286);
term_sink(e, v_4294967285);
term_sink(e, v_4294967284);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_110_117_109_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293) {
Term ntr_state[5] = { TERM_HOLE, 0, 0, 0, 0 };
Term ntr_ok = NF_FID_110_117_109__trmc(e, seq, ntr_state, v_4294967295, v_4294967294, v_4294967293);
if (ntr_state[2]) spare_free(e, (Cls)ntr_state[3], (Loc)ntr_state[2]);
if (!ntr_ok) { term_sink(e, ntr_state[0]); return 0; }
nf_out[0] = ntr_state[0];
return 1;
}
NF_INLINE Term NF_FID_112_114_110_103_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_3469;
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967276;
{
v_4294967276 = v_4294967295;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967275;
{
Term v_4294967272;
{
v_4294967272 = v_4294967295;
goto nf_join_25;
}
nf_join_25:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967271;
{
v_4294967271 = 13ull;
goto nf_join_26;
}
nf_join_26:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967275 = (v_4294967271 >= 32 ? 0 : U32_BIN(v_4294967272, <<, v_4294967271));
goto nf_join_22;
}
nf_join_22:;
if (!seq && err_seen(e.mem)) { return 0; }
v_3469 = U32_BIN(v_4294967276, ^, v_4294967275);
goto nf_join_1;
}
nf_join_1:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_3470;
{
v_3469 = term_keep(e, v_3469);
Term v_4294967284;
{
v_4294967284 = v_3469;
goto nf_join_13;
}
nf_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967283;
{
Term v_4294967280;
{
v_4294967280 = v_3469;
goto nf_join_17;
}
nf_join_17:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967279;
{
v_4294967279 = 17ull;
goto nf_join_18;
}
nf_join_18:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967283 = (v_4294967279 >= 32 ? 0 : U32_BIN(v_4294967280, >>, v_4294967279));
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
v_3470 = U32_BIN(v_4294967284, ^, v_4294967283);
goto nf_join_2;
}
nf_join_2:;
if (!seq && err_seen(e.mem)) { return 0; }
v_3470 = term_keep(e, v_3470);
Term v_4294967292;
{
v_4294967292 = v_3470;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
Term v_4294967288;
{
v_4294967288 = v_3470;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967287;
{
v_4294967287 = 5ull;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967291 = (v_4294967287 >= 32 ? 0 : U32_BIN(v_4294967288, <<, v_4294967287));
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = U32_BIN(v_4294967292, ^, v_4294967291);
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_105_100_101_110_116__trmc(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967292;
{
v_4294967292 = v_4294967295;
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
v_4294967291 = v_4294967294;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294967292 == 0)) {
term_sink(e, v_4294967291);
if (nf_out[1] != 0) { e.mem[nf_out[1]] = nf_out[4] ? rfc_seal(e, v_4294967290) : v_4294967290; } else { nf_out[0] = v_4294967290; }
return 1;
} else {
Term v_4294967286;
{
v_4294967286 = v_4294967292;
goto nf_join_12;
}
nf_join_12:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967285;
{
v_4294967285 = v_4294967291;
goto nf_join_13;
}
nf_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967284;
{
v_4294967284 = v_4294967290;
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294967286 != 0)) {
#if !DEVICE && NATIVE_FIELD32_CID_SUCC_0
u32
#else
Term
#endif
v_4294967280 = (v_4294967286 - 1);
Term v_3491;
{
Term v_4294967258;
{
v_4294967258 = v_4294967285;
goto nf_join_38;
}
nf_join_38:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_39[1];
if (!NF_FID_112_114_110_103_(e, seq, nq_result_39, v_4294967258)) { return 0; }
v_3491 = nq_result_39[0];
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
v_3491 = term_keep(e, v_3491);
Term v_4294967278;
{
Term v_4294967268;
{
Term v_4294967266;
{
v_4294967266 = 97ull;
goto nf_join_31;
}
nf_join_31:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967265;
{
Term v_4294967262;
{
v_4294967262 = v_3491;
goto nf_join_35;
}
nf_join_35:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967261;
{
v_4294967261 = 26ull;
goto nf_join_36;
}
nf_join_36:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967265 = ((u32)(v_4294967261) == 0 ? v_4294967262 : U32_BIN(v_4294967262, -, U32_QUO((u32)(v_4294967262), (u32)(v_4294967261)) * v_4294967261));
goto nf_join_32;
}
nf_join_32:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967268 = U32_BIN(v_4294967266, +, v_4294967265);
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967278 = v_4294967268;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967277;
{
v_4294967277 = v_4294967280;
goto nf_join_22;
}
nf_join_22:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967276;
{
v_4294967276 = v_3491;
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967275;
{
v_4294967275 = v_4294967284;
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_25 = p102_trmc_take_cell(e, nf_out, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_25 + 0] = v_4294967278;
e.mem[nd_25 + 1] = TERM_HOLE;
#else
e.mem[nd_25 + 0] = rfc_seal(e, v_4294967278);
e.mem[nd_25 + 1] = rfc_seal(e, TERM_HOLE);
#endif
Term ntr_node_26 = term_ctr(CID_SCON, nd_25);
if (nf_out[1] != 0) { e.mem[nf_out[1]] = nf_out[4] ? rfc_seal(e, ntr_node_26) : ntr_node_26; } else { nf_out[0] = ntr_node_26; }
nf_out[1] = term_loc(ntr_node_26) + 1;
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
nf_out[4] = 0;
#else
nf_out[4] = 1;
#endif
{
Term nf_arg_0 = v_4294967277;
Term nf_arg_1 = v_4294967276;
Term nf_arg_2 = v_4294967275;
v_4294967295 = nf_arg_0;
v_4294967294 = nf_arg_1;
v_4294967293 = nf_arg_2;
goto nf_again;
}
} else {
term_sink(e, v_4294967286);
term_sink(e, v_4294967285);
term_sink(e, v_4294967284);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_105_100_101_110_116_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293) {
Term ntr_state[5] = { TERM_HOLE, 0, 0, 0, 0 };
Term ntr_ok = NF_FID_105_100_101_110_116__trmc(e, seq, ntr_state, v_4294967295, v_4294967294, v_4294967293);
if (ntr_state[2]) spare_free(e, (Cls)ntr_state[3], (Loc)ntr_state[2]);
if (!ntr_ok) { term_sink(e, ntr_state[0]); return 0; }
nf_out[0] = ntr_state[0];
return 1;
}
NF_INLINE Term NF_FID_101_120_112_97_110_100_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293, Term v_4294967292) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967291;
{
v_4294967291 = v_4294967295;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967294;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967291) == CID__CTOR_73_100_)) {
term_sink(e, v_4294967290);
v_4294967289 = term_keep(e, v_4294967289);
Term v_4294967283;
{
Term v_4294967276;
{
Term v_4294967274;
{
v_4294967274 = 1ull;
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967273;
{
Term v_4294967270;
{
v_4294967270 = v_4294967289;
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967269;
{
v_4294967269 = 7ull;
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967273 = U32_BIN(v_4294967270, &, v_4294967269);
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967276 = U32_BIN(v_4294967274, +, v_4294967273);
goto nf_join_20;
}
nf_join_20:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967283 = ((u64)v_4294967276);
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
v_4294967282 = v_4294967289;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = v_4294967288;
goto nf_join_17;
}
nf_join_17:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_18[1];
if (!NF_FID_105_100_101_110_116_(e, seq, nq_result_18, v_4294967283, v_4294967282, v_4294967281)) { return 0; }
nf_out[0] = nq_result_18[0];
return 1;
} else {
Term v_4294967266;
{
v_4294967266 = v_4294967291;
goto nf_join_33;
}
nf_join_33:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967265;
{
v_4294967265 = v_4294967290;
goto nf_join_34;
}
nf_join_34:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967264;
{
v_4294967264 = v_4294967289;
goto nf_join_35;
}
nf_join_35:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967263;
{
v_4294967263 = v_4294967288;
goto nf_join_36;
}
nf_join_36:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967266) == CID__CTOR_78_109_)) {
term_sink(e, v_4294967265);
v_4294967264 = term_keep(e, v_4294967264);
Term v_4294967258;
{
Term v_4294967251;
{
Term v_4294967249;
{
v_4294967249 = 1ull;
goto nf_join_48;
}
nf_join_48:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967248;
{
Term v_4294967245;
{
v_4294967245 = v_4294967264;
goto nf_join_52;
}
nf_join_52:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967244;
{
v_4294967244 = 6ull;
goto nf_join_53;
}
nf_join_53:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967248 = ((u32)(v_4294967244) == 0 ? v_4294967245 : U32_BIN(v_4294967245, -, U32_QUO((u32)(v_4294967245), (u32)(v_4294967244)) * v_4294967244));
goto nf_join_49;
}
nf_join_49:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967251 = U32_BIN(v_4294967249, +, v_4294967248);
goto nf_join_45;
}
nf_join_45:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967258 = ((u64)v_4294967251);
goto nf_join_40;
}
nf_join_40:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967257;
{
v_4294967257 = v_4294967264;
goto nf_join_41;
}
nf_join_41:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967256;
{
v_4294967256 = v_4294967263;
goto nf_join_42;
}
nf_join_42:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_43[1];
if (!NF_FID_110_117_109_(e, seq, nq_result_43, v_4294967258, v_4294967257, v_4294967256)) { return 0; }
nf_out[0] = nq_result_43[0];
return 1;
} else {
Term v_4294967241;
{
v_4294967241 = v_4294967266;
goto nf_join_58;
}
nf_join_58:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967240;
{
v_4294967240 = v_4294967265;
goto nf_join_59;
}
nf_join_59:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967239;
{
v_4294967239 = v_4294967264;
goto nf_join_60;
}
nf_join_60:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967238;
{
v_4294967238 = v_4294967263;
goto nf_join_61;
}
nf_join_61:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967241) == CID__CTOR_79_112_)) {
term_sink(e, v_4294967240);
Term v_4294967233;
{
v_4294967233 = v_4294967239;
goto nf_join_64;
}
nf_join_64:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967232;
{
v_4294967232 = v_4294967238;
goto nf_join_65;
}
nf_join_65:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_66[1];
if (!NF_FID_111_112_(e, seq, nq_result_66, v_4294967233, v_4294967232)) { return 0; }
nf_out[0] = nq_result_66[0];
return 1;
} else {
Term v_4294967228;
{
v_4294967228 = v_4294967241;
goto nf_join_71;
}
nf_join_71:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967227;
{
v_4294967227 = v_4294967240;
goto nf_join_72;
}
nf_join_72:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967226;
{
v_4294967226 = v_4294967239;
goto nf_join_73;
}
nf_join_73:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967225;
{
v_4294967225 = v_4294967238;
goto nf_join_74;
}
nf_join_74:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967228) == CID__CTOR_76_105_116_)) {
term_sink(e, v_4294967226);
Term v_4294967220;
{
Term v_4294967215;
{
v_4294967215 = v_4294967227;
goto nf_join_81;
}
nf_join_81:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967220 = v_4294967215;
goto nf_join_77;
}
nf_join_77:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967219;
{
v_4294967219 = v_4294967225;
goto nf_join_78;
}
nf_join_78:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_79 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_79 + 0] = v_4294967220;
e.mem[nd_79 + 1] = v_4294967219;
#else
e.mem[nd_79 + 0] = rfc_seal(e, v_4294967220);
e.mem[nd_79 + 1] = rfc_seal(e, v_4294967219);
#endif
nf_out[0] = term_ctr(CID_SCON, nd_79);
return 1;
} else {
term_sink(e, v_4294967228);
term_sink(e, v_4294967227);
term_sink(e, v_4294967226);
term_sink(e, v_4294967225);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
}
return 0;
}
INLINE Term NF_FID_103_101_110_46_97_116_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, Term v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967292;
{
Term v_4294967283;
{
v_4294967283 = v_4294967295;
goto nf_join_13;
}
nf_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_14[1];
if (!NF_FID_115_108_111_116_(e, seq, nq_result_14, v_4294967283)) { return 0; }
v_4294967292 = nq_result_14[0];
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
v_4294967291 = v_4294967295;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967294;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_11[1];
if (!NF_FID_101_120_112_97_110_100_(e, seq, nq_result_11, v_4294967292, v_4294967291, v_4294967290, v_4294967289)) { return 0; }
nf_out[0] = nq_result_11[0];
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_66_111_111_108_46_97_110_100_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((!native_bool(v_4294967293))) {
term_sink(e, v_4294967292);
nf_out[0] = 0ull;
return 1;
} else {
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967289)) {
nf_out[0] = v_4294967288;
return 1;
} else {
term_sink(e, v_4294967289);
term_sink(e, v_4294967288);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
NF_INLINE Term NF_FID_99_108_115_46_103_111_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967292;
{
v_4294967292 = v_4294967295;
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
v_4294967291 = v_4294967294;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967292)) {
Term v_4294967286;
{
v_4294967286 = v_4294967291;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967285;
{
v_4294967285 = v_4294967290;
goto nf_join_12;
}
nf_join_12:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967286)) {
if (native_bool(v_4294967285)) {
nf_out[0] = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
return 1;
} else {
term_sink(e, v_4294967285);
nf_out[0] = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
return 1;
}
} else {
term_sink(e, v_4294967286);
if (native_bool(v_4294967285)) {
nf_out[0] = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
return 1;
} else {
term_sink(e, v_4294967285);
nf_out[0] = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
return 1;
}
}
} else {
term_sink(e, v_4294967292);
Term v_4294967282;
{
v_4294967282 = v_4294967291;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = v_4294967290;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294967282)) {
if (native_bool(v_4294967281)) {
nf_out[0] = term_pak(CID__CTOR_68_105_103_105_116_, 0);
return 1;
} else {
term_sink(e, v_4294967281);
nf_out[0] = term_pak(CID__CTOR_68_105_103_105_116_, 0);
return 1;
}
} else {
term_sink(e, v_4294967282);
if (native_bool(v_4294967281)) {
nf_out[0] = term_pak(CID__CTOR_83_112_97_99_101_, 0);
return 1;
} else {
term_sink(e, v_4294967281);
nf_out[0] = term_pak(CID__CTOR_80_117_110_99_116_, 0);
return 1;
}
}
}
}
return 0;
}
NF_INLINE Term NF_FID_99_108_115_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967294;
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967270;
{
Term v_4294967261;
{
v_4294967261 = 97ull;
goto nf_join_36;
}
nf_join_36:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967260;
{
v_4294967260 = v_4294967295;
goto nf_join_37;
}
nf_join_37:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967270 = U32_BIN(v_4294967261, <=, v_4294967260);
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967269;
{
Term v_4294967265;
{
v_4294967265 = v_4294967295;
goto nf_join_32;
}
nf_join_32:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967264;
{
v_4294967264 = 122ull;
goto nf_join_33;
}
nf_join_33:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967269 = U32_BIN(v_4294967265, <=, v_4294967264);
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_29[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nq_result_29, v_4294967270, v_4294967269)) { return 0; }
v_4294967294 = nq_result_29[0];
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967293;
{
v_4294967295 = term_keep(e, v_4294967295);
Term v_4294967283;
{
Term v_4294967274;
{
v_4294967274 = 48ull;
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967273;
{
v_4294967273 = v_4294967295;
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967283 = U32_BIN(v_4294967274, <=, v_4294967273);
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
Term v_4294967278;
{
v_4294967278 = v_4294967295;
goto nf_join_19;
}
nf_join_19:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967277;
{
v_4294967277 = 57ull;
goto nf_join_20;
}
nf_join_20:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967282 = U32_BIN(v_4294967278, <=, v_4294967277);
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_16[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nq_result_16, v_4294967283, v_4294967282)) { return 0; }
v_4294967293 = nq_result_16[0];
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
Term v_4294967287;
{
v_4294967287 = v_4294967295;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967286;
{
v_4294967286 = 32ull;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967292 = U32_BIN(v_4294967287, ==, v_4294967286);
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_7[1];
if (!NF_FID_99_108_115_46_103_111_(e, seq, nq_result_7, v_4294967294, v_4294967293, v_4294967292)) { return 0; }
nf_out[0] = nq_result_7[0];
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_102_110_118_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
Term v_4294967289;
{
v_4294967289 = v_4294967295;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967294;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967293 = U32_BIN(v_4294967289, ^, v_4294967288);
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = 16777619ull;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = U32_BIN(v_4294967293, *, v_4294967292);
return 1;
}
return 0;
}
INLINE Term NF_FID_115_116_101_112_46_97_116_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294, NF_SCALAR v_4294967293, NF_SCALAR v_4294967292) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967291;
{
v_4294967291 = v_4294967295;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967294;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967291) == CID__CTOR_71_97_112_)) {
Term v_4294967283;
{
v_4294967283 = v_4294967290;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
v_4294967282 = v_4294967289;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = v_4294967288;
goto nf_join_17;
}
nf_join_17:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967283) == CID__CTOR_76_101_116_116_101_114_)) {
Term v_4294967277;
{
Term v_4294967272;
{
Term v_4294967269;
{
v_4294967269 = 2166136261ull;
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967268;
{
v_4294967268 = v_4294967282;
goto nf_join_29;
}
nf_join_29:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_30[1];
if (!NF_FID_102_110_118_(e, seq, nq_result_30, v_4294967269, v_4294967268)) { return 0; }
v_4294967272 = nq_result_30[0];
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_25 = v_4294967272;
Term pk_25;
#if NATIVE_PACK_CTORS
if ((pf_25 & ~LOC_MASK) == 0) {
pk_25 = term_pak(CID__CTOR_73_110_73_100_, pf_25);
} else
#endif
{
u64 nd_25 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_25 + 0] = pf_25;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_25 + 0] = pf_25;
#else
e.mem[nd_25 + 0] = rfc_seal(e, pf_25);
#endif
#endif
pk_25 = term_ctr(CID__CTOR_73_110_73_100_, nd_25);
}
v_4294967277 = pk_25;
goto nf_join_20;
}
nf_join_20:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967276;
{
v_4294967276 = v_4294967281;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_22 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_22 + 0] = v_4294967277;
e.mem[nd_22 + 1] = v_4294967276;
#else
e.mem[nd_22 + 0] = rfc_seal(e, v_4294967277);
e.mem[nd_22 + 1] = rfc_seal(e, v_4294967276);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_22);
return 1;
} else {
Term v_4294967264;
{
v_4294967264 = v_4294967283;
goto nf_join_34;
}
nf_join_34:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967263;
{
v_4294967263 = v_4294967282;
goto nf_join_35;
}
nf_join_35:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967262;
{
v_4294967262 = v_4294967281;
goto nf_join_36;
}
nf_join_36:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967264) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294967258;
{
Term v_4294967253;
{
Term v_4294967250;
{
v_4294967250 = v_4294967263;
goto nf_join_47;
}
nf_join_47:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967249;
{
v_4294967249 = 48ull;
goto nf_join_48;
}
nf_join_48:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967253 = U32_BIN(v_4294967250, -, v_4294967249);
goto nf_join_43;
}
nf_join_43:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_44 = v_4294967253;
Term pk_44;
#if NATIVE_PACK_CTORS
if ((pf_44 & ~LOC_MASK) == 0) {
pk_44 = term_pak(CID__CTOR_73_110_78_109_, pf_44);
} else
#endif
{
u64 nd_44 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_44 + 0] = pf_44;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_44 + 0] = pf_44;
#else
e.mem[nd_44 + 0] = rfc_seal(e, pf_44);
#endif
#endif
pk_44 = term_ctr(CID__CTOR_73_110_78_109_, nd_44);
}
v_4294967258 = pk_44;
goto nf_join_39;
}
nf_join_39:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967257;
{
v_4294967257 = v_4294967262;
goto nf_join_40;
}
nf_join_40:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_41 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_41 + 0] = v_4294967258;
e.mem[nd_41 + 1] = v_4294967257;
#else
e.mem[nd_41 + 0] = rfc_seal(e, v_4294967258);
e.mem[nd_41 + 1] = rfc_seal(e, v_4294967257);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_41);
return 1;
} else {
Term v_4294967246;
{
v_4294967246 = v_4294967264;
goto nf_join_52;
}
nf_join_52:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967245;
{
v_4294967245 = v_4294967263;
goto nf_join_53;
}
nf_join_53:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967244;
{
v_4294967244 = v_4294967262;
goto nf_join_54;
}
nf_join_54:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967246) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294967245);
Term v_4294967240;
{
v_4294967240 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_57;
}
nf_join_57:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967239;
{
v_4294967239 = v_4294967244;
goto nf_join_58;
}
nf_join_58:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_59 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_59 + 0] = v_4294967240;
e.mem[nd_59 + 1] = v_4294967239;
#else
e.mem[nd_59 + 0] = rfc_seal(e, v_4294967240);
e.mem[nd_59 + 1] = rfc_seal(e, v_4294967239);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_59);
return 1;
} else {
Term v_4294967235;
{
v_4294967235 = v_4294967246;
goto nf_join_63;
}
nf_join_63:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967234;
{
v_4294967234 = v_4294967245;
goto nf_join_64;
}
nf_join_64:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967233;
{
v_4294967233 = v_4294967244;
goto nf_join_65;
}
nf_join_65:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967235) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294967229;
{
v_4294967229 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_68;
}
nf_join_68:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967228;
{
Term v_4294967224;
{
v_4294967224 = v_4294967233;
goto nf_join_74;
}
nf_join_74:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967223;
{
v_4294967223 = 3ull;
goto nf_join_75;
}
nf_join_75:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967222;
{
v_4294967222 = v_4294967234;
goto nf_join_76;
}
nf_join_76:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_77[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_77, v_4294967224, v_4294967223, v_4294967222)) { return 0; }
v_4294967228 = nq_result_77[0];
goto nf_join_69;
}
nf_join_69:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_70 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_70 + 0] = v_4294967229;
e.mem[nd_70 + 1] = v_4294967228;
#else
e.mem[nd_70 + 0] = rfc_seal(e, v_4294967229);
e.mem[nd_70 + 1] = rfc_seal(e, v_4294967228);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_70);
return 1;
} else {
term_sink(e, v_4294967235);
term_sink(e, v_4294967234);
term_sink(e, v_4294967233);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
Term v_4294967217;
{
v_4294967217 = v_4294967291;
goto nf_join_82;
}
nf_join_82:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967216;
{
v_4294967216 = v_4294967290;
goto nf_join_83;
}
nf_join_83:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967215;
{
v_4294967215 = v_4294967289;
goto nf_join_84;
}
nf_join_84:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967214;
{
v_4294967214 = v_4294967288;
goto nf_join_85;
}
nf_join_85:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967217) == CID__CTOR_73_110_73_100_)) {
Term fields[1];
if (term_tag(v_4294967217) == TAG_PAK) { fields[0] = term_loc(v_4294967217); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294967217, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_73_100__0
u32
#else
Term
#endif
v_4294967209 = fields[0];
Term v_4294967208;
{
v_4294967208 = v_4294967216;
goto nf_join_90;
}
nf_join_90:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967207;
{
v_4294967207 = v_4294967215;
goto nf_join_91;
}
nf_join_91:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967206;
{
v_4294967206 = v_4294967214;
goto nf_join_92;
}
nf_join_92:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967208) == CID__CTOR_76_101_116_116_101_114_)) {
Term v_4294967202;
{
Term v_4294967197;
{
Term v_4294967194;
{
v_4294967194 = v_4294967209;
goto nf_join_103;
}
nf_join_103:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967193;
{
v_4294967193 = v_4294967207;
goto nf_join_104;
}
nf_join_104:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_105[1];
if (!NF_FID_102_110_118_(e, seq, nq_result_105, v_4294967194, v_4294967193)) { return 0; }
v_4294967197 = nq_result_105[0];
goto nf_join_99;
}
nf_join_99:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_100 = v_4294967197;
Term pk_100;
#if NATIVE_PACK_CTORS
if ((pf_100 & ~LOC_MASK) == 0) {
pk_100 = term_pak(CID__CTOR_73_110_73_100_, pf_100);
} else
#endif
{
u64 nd_100 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_100 + 0] = pf_100;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_100 + 0] = pf_100;
#else
e.mem[nd_100 + 0] = rfc_seal(e, pf_100);
#endif
#endif
pk_100 = term_ctr(CID__CTOR_73_110_73_100_, nd_100);
}
v_4294967202 = pk_100;
goto nf_join_95;
}
nf_join_95:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967201;
{
v_4294967201 = v_4294967206;
goto nf_join_96;
}
nf_join_96:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_97 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_97 + 0] = v_4294967202;
e.mem[nd_97 + 1] = v_4294967201;
#else
e.mem[nd_97 + 0] = rfc_seal(e, v_4294967202);
e.mem[nd_97 + 1] = rfc_seal(e, v_4294967201);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_97);
return 1;
} else {
Term v_4294967189;
{
v_4294967189 = v_4294967208;
goto nf_join_109;
}
nf_join_109:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967188;
{
v_4294967188 = v_4294967207;
goto nf_join_110;
}
nf_join_110:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967187;
{
v_4294967187 = v_4294967206;
goto nf_join_111;
}
nf_join_111:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967189) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294967183;
{
Term v_4294967171;
{
Term v_4294967168;
{
v_4294967168 = v_4294967188;
goto nf_join_129;
}
nf_join_129:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967167;
{
v_4294967167 = 48ull;
goto nf_join_130;
}
nf_join_130:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967171 = U32_BIN(v_4294967168, -, v_4294967167);
goto nf_join_125;
}
nf_join_125:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_126 = v_4294967171;
Term pk_126;
#if NATIVE_PACK_CTORS
if ((pf_126 & ~LOC_MASK) == 0) {
pk_126 = term_pak(CID__CTOR_73_110_78_109_, pf_126);
} else
#endif
{
u64 nd_126 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_126 + 0] = pf_126;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_126 + 0] = pf_126;
#else
e.mem[nd_126 + 0] = rfc_seal(e, pf_126);
#endif
#endif
pk_126 = term_ctr(CID__CTOR_73_110_78_109_, nd_126);
}
v_4294967183 = pk_126;
goto nf_join_114;
}
nf_join_114:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967182;
{
Term v_4294967178;
{
v_4294967178 = v_4294967187;
goto nf_join_120;
}
nf_join_120:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967177;
{
v_4294967177 = 1ull;
goto nf_join_121;
}
nf_join_121:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967176;
{
v_4294967176 = v_4294967209;
goto nf_join_122;
}
nf_join_122:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_123[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_123, v_4294967178, v_4294967177, v_4294967176)) { return 0; }
v_4294967182 = nq_result_123[0];
goto nf_join_115;
}
nf_join_115:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_116 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_116 + 0] = v_4294967183;
e.mem[nd_116 + 1] = v_4294967182;
#else
e.mem[nd_116 + 0] = rfc_seal(e, v_4294967183);
e.mem[nd_116 + 1] = rfc_seal(e, v_4294967182);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_116);
return 1;
} else {
Term v_4294967164;
{
v_4294967164 = v_4294967189;
goto nf_join_134;
}
nf_join_134:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967163;
{
v_4294967163 = v_4294967188;
goto nf_join_135;
}
nf_join_135:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967162;
{
v_4294967162 = v_4294967187;
goto nf_join_136;
}
nf_join_136:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967164) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294967163);
Term v_4294967158;
{
v_4294967158 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_139;
}
nf_join_139:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967157;
{
Term v_4294967153;
{
v_4294967153 = v_4294967162;
goto nf_join_145;
}
nf_join_145:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967152;
{
v_4294967152 = 1ull;
goto nf_join_146;
}
nf_join_146:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967151;
{
v_4294967151 = v_4294967209;
goto nf_join_147;
}
nf_join_147:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_148[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_148, v_4294967153, v_4294967152, v_4294967151)) { return 0; }
v_4294967157 = nq_result_148[0];
goto nf_join_140;
}
nf_join_140:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_141 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_141 + 0] = v_4294967158;
e.mem[nd_141 + 1] = v_4294967157;
#else
e.mem[nd_141 + 0] = rfc_seal(e, v_4294967158);
e.mem[nd_141 + 1] = rfc_seal(e, v_4294967157);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_141);
return 1;
} else {
Term v_4294967146;
{
v_4294967146 = v_4294967164;
goto nf_join_152;
}
nf_join_152:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967145;
{
v_4294967145 = v_4294967163;
goto nf_join_153;
}
nf_join_153:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967144;
{
v_4294967144 = v_4294967162;
goto nf_join_154;
}
nf_join_154:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967146) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294967140;
{
v_4294967140 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_157;
}
nf_join_157:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967139;
{
Term v_4294967135;
{
Term v_4294967128;
{
v_4294967128 = v_4294967144;
goto nf_join_170;
}
nf_join_170:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967127;
{
v_4294967127 = 1ull;
goto nf_join_171;
}
nf_join_171:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967126;
{
v_4294967126 = v_4294967209;
goto nf_join_172;
}
nf_join_172:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_173[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_173, v_4294967128, v_4294967127, v_4294967126)) { return 0; }
v_4294967135 = nq_result_173[0];
goto nf_join_163;
}
nf_join_163:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967134;
{
v_4294967134 = 3ull;
goto nf_join_164;
}
nf_join_164:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967133;
{
v_4294967133 = v_4294967145;
goto nf_join_165;
}
nf_join_165:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_166[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_166, v_4294967135, v_4294967134, v_4294967133)) { return 0; }
v_4294967139 = nq_result_166[0];
goto nf_join_158;
}
nf_join_158:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_159 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_159 + 0] = v_4294967140;
e.mem[nd_159 + 1] = v_4294967139;
#else
e.mem[nd_159 + 0] = rfc_seal(e, v_4294967140);
e.mem[nd_159 + 1] = rfc_seal(e, v_4294967139);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_159);
return 1;
} else {
term_sink(e, v_4294967209);
term_sink(e, v_4294967146);
term_sink(e, v_4294967145);
term_sink(e, v_4294967144);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
Term v_4294967121;
{
v_4294967121 = v_4294967217;
goto nf_join_178;
}
nf_join_178:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967120;
{
v_4294967120 = v_4294967216;
goto nf_join_179;
}
nf_join_179:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967119;
{
v_4294967119 = v_4294967215;
goto nf_join_180;
}
nf_join_180:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967118;
{
v_4294967118 = v_4294967214;
goto nf_join_181;
}
nf_join_181:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967121) == CID__CTOR_73_110_78_109_)) {
Term fields[1];
if (term_tag(v_4294967121) == TAG_PAK) { fields[0] = term_loc(v_4294967121); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294967121, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_78_109__0
u32
#else
Term
#endif
v_4294967113 = fields[0];
Term v_4294967112;
{
v_4294967112 = v_4294967120;
goto nf_join_186;
}
nf_join_186:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967111;
{
v_4294967111 = v_4294967119;
goto nf_join_187;
}
nf_join_187:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967110;
{
v_4294967110 = v_4294967118;
goto nf_join_188;
}
nf_join_188:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967112) == CID__CTOR_76_101_116_116_101_114_)) {
Term v_4294967106;
{
Term v_4294967094;
{
Term v_4294967091;
{
v_4294967091 = 2166136261ull;
goto nf_join_206;
}
nf_join_206:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967090;
{
v_4294967090 = v_4294967111;
goto nf_join_207;
}
nf_join_207:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_208[1];
if (!NF_FID_102_110_118_(e, seq, nq_result_208, v_4294967091, v_4294967090)) { return 0; }
v_4294967094 = nq_result_208[0];
goto nf_join_202;
}
nf_join_202:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_203 = v_4294967094;
Term pk_203;
#if NATIVE_PACK_CTORS
if ((pf_203 & ~LOC_MASK) == 0) {
pk_203 = term_pak(CID__CTOR_73_110_73_100_, pf_203);
} else
#endif
{
u64 nd_203 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_203 + 0] = pf_203;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_203 + 0] = pf_203;
#else
e.mem[nd_203 + 0] = rfc_seal(e, pf_203);
#endif
#endif
pk_203 = term_ctr(CID__CTOR_73_110_73_100_, nd_203);
}
v_4294967106 = pk_203;
goto nf_join_191;
}
nf_join_191:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967105;
{
Term v_4294967101;
{
v_4294967101 = v_4294967110;
goto nf_join_197;
}
nf_join_197:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967100;
{
v_4294967100 = 2ull;
goto nf_join_198;
}
nf_join_198:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967099;
{
v_4294967099 = v_4294967113;
goto nf_join_199;
}
nf_join_199:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_200[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_200, v_4294967101, v_4294967100, v_4294967099)) { return 0; }
v_4294967105 = nq_result_200[0];
goto nf_join_192;
}
nf_join_192:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_193 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_193 + 0] = v_4294967106;
e.mem[nd_193 + 1] = v_4294967105;
#else
e.mem[nd_193 + 0] = rfc_seal(e, v_4294967106);
e.mem[nd_193 + 1] = rfc_seal(e, v_4294967105);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_193);
return 1;
} else {
Term v_4294967086;
{
v_4294967086 = v_4294967112;
goto nf_join_212;
}
nf_join_212:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967085;
{
v_4294967085 = v_4294967111;
goto nf_join_213;
}
nf_join_213:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967084;
{
v_4294967084 = v_4294967110;
goto nf_join_214;
}
nf_join_214:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967086) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294967080;
{
Term v_4294967075;
{
Term v_4294967072;
{
Term v_4294967064;
{
v_4294967064 = v_4294967113;
goto nf_join_233;
}
nf_join_233:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967063;
{
v_4294967063 = 10ull;
goto nf_join_234;
}
nf_join_234:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967072 = U32_BIN(v_4294967064, *, v_4294967063);
goto nf_join_225;
}
nf_join_225:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967071;
{
Term v_4294967068;
{
v_4294967068 = v_4294967085;
goto nf_join_229;
}
nf_join_229:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967067;
{
v_4294967067 = 48ull;
goto nf_join_230;
}
nf_join_230:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967071 = U32_BIN(v_4294967068, -, v_4294967067);
goto nf_join_226;
}
nf_join_226:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967075 = U32_BIN(v_4294967072, +, v_4294967071);
goto nf_join_221;
}
nf_join_221:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_222 = v_4294967075;
Term pk_222;
#if NATIVE_PACK_CTORS
if ((pf_222 & ~LOC_MASK) == 0) {
pk_222 = term_pak(CID__CTOR_73_110_78_109_, pf_222);
} else
#endif
{
u64 nd_222 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_222 + 0] = pf_222;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_222 + 0] = pf_222;
#else
e.mem[nd_222 + 0] = rfc_seal(e, pf_222);
#endif
#endif
pk_222 = term_ctr(CID__CTOR_73_110_78_109_, nd_222);
}
v_4294967080 = pk_222;
goto nf_join_217;
}
nf_join_217:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967079;
{
v_4294967079 = v_4294967084;
goto nf_join_218;
}
nf_join_218:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_219 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_219 + 0] = v_4294967080;
e.mem[nd_219 + 1] = v_4294967079;
#else
e.mem[nd_219 + 0] = rfc_seal(e, v_4294967080);
e.mem[nd_219 + 1] = rfc_seal(e, v_4294967079);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_219);
return 1;
} else {
Term v_4294967060;
{
v_4294967060 = v_4294967086;
goto nf_join_238;
}
nf_join_238:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967059;
{
v_4294967059 = v_4294967085;
goto nf_join_239;
}
nf_join_239:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967058;
{
v_4294967058 = v_4294967084;
goto nf_join_240;
}
nf_join_240:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967060) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294967059);
Term v_4294967054;
{
v_4294967054 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_243;
}
nf_join_243:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967053;
{
Term v_4294967049;
{
v_4294967049 = v_4294967058;
goto nf_join_249;
}
nf_join_249:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967048;
{
v_4294967048 = 2ull;
goto nf_join_250;
}
nf_join_250:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967047;
{
v_4294967047 = v_4294967113;
goto nf_join_251;
}
nf_join_251:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_252[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_252, v_4294967049, v_4294967048, v_4294967047)) { return 0; }
v_4294967053 = nq_result_252[0];
goto nf_join_244;
}
nf_join_244:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_245 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_245 + 0] = v_4294967054;
e.mem[nd_245 + 1] = v_4294967053;
#else
e.mem[nd_245 + 0] = rfc_seal(e, v_4294967054);
e.mem[nd_245 + 1] = rfc_seal(e, v_4294967053);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_245);
return 1;
} else {
Term v_4294967042;
{
v_4294967042 = v_4294967060;
goto nf_join_256;
}
nf_join_256:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967041;
{
v_4294967041 = v_4294967059;
goto nf_join_257;
}
nf_join_257:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967040;
{
v_4294967040 = v_4294967058;
goto nf_join_258;
}
nf_join_258:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967042) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294967036;
{
v_4294967036 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_261;
}
nf_join_261:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967035;
{
Term v_4294967031;
{
Term v_4294967024;
{
v_4294967024 = v_4294967040;
goto nf_join_274;
}
nf_join_274:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967023;
{
v_4294967023 = 2ull;
goto nf_join_275;
}
nf_join_275:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967022;
{
v_4294967022 = v_4294967113;
goto nf_join_276;
}
nf_join_276:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_277[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_277, v_4294967024, v_4294967023, v_4294967022)) { return 0; }
v_4294967031 = nq_result_277[0];
goto nf_join_267;
}
nf_join_267:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967030;
{
v_4294967030 = 3ull;
goto nf_join_268;
}
nf_join_268:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967029;
{
v_4294967029 = v_4294967041;
goto nf_join_269;
}
nf_join_269:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_270[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_270, v_4294967031, v_4294967030, v_4294967029)) { return 0; }
v_4294967035 = nq_result_270[0];
goto nf_join_262;
}
nf_join_262:;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_263 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_263 + 0] = v_4294967036;
e.mem[nd_263 + 1] = v_4294967035;
#else
e.mem[nd_263 + 0] = rfc_seal(e, v_4294967036);
e.mem[nd_263 + 1] = rfc_seal(e, v_4294967035);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_263);
return 1;
} else {
term_sink(e, v_4294967113);
term_sink(e, v_4294967042);
term_sink(e, v_4294967041);
term_sink(e, v_4294967040);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
term_sink(e, v_4294967121);
term_sink(e, v_4294967120);
term_sink(e, v_4294967119);
term_sink(e, v_4294967118);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
return 0;
}
INLINE Term NF_FID_115_116_101_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967292;
{
v_4294967292 = v_4294967295;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967294 = term_keep(e, v_4294967294);
Term v_4294967291;
{
Term v_4294967282;
{
v_4294967282 = v_4294967294;
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_15[1];
if (!NF_FID_99_108_115_(e, seq, nq_result_15, v_4294967282)) { return 0; }
v_4294967291 = nq_result_15[0];
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967294;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_11[2];
if (!NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_46_97_116_(e, seq, nq_result_11, v_4294967292, v_4294967291, v_4294967290, v_4294967289)) { return 0; }
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
nq_result_11[0] = (u32)nq_result_11[0];
#endif
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
nq_result_11[1] = (u32)nq_result_11[1];
#endif
u64 nd_12 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_12 + 0] = nq_result_11[0];
e.mem[nd_12 + 1] = nq_result_11[1];
#else
e.mem[nd_12 + 0] = rfc_seal(e, nq_result_11[0]);
e.mem[nd_12 + 1] = rfc_seal(e, nq_result_11[1]);
#endif
nf_out[0] = term_ctr(CID_TUPLE, nd_12);
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_109_105_120_(Env e, bool seq, Term* nf_out, NF_SCALAR v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967292;
{
Term v_4294967280;
{
v_4294967280 = v_4294967295;
goto nf_join_17;
}
nf_join_17:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967279;
{
v_4294967279 = 2654435761ull;
goto nf_join_18;
}
nf_join_18:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967292 = U32_BIN(v_4294967280, *, v_4294967279);
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967291;
{
Term v_4294967288;
{
Term v_4294967284;
{
v_4294967284 = v_4294967294;
goto nf_join_13;
}
nf_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967283;
{
v_4294967283 = 40503ull;
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967288 = U32_BIN(v_4294967284, *, v_4294967283);
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967287;
{
v_4294967287 = v_4294967293;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967291 = U32_BIN(v_4294967288, +, v_4294967287);
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = U32_BIN(v_4294967292, ^, v_4294967291);
return 1;
}
return 0;
}
NF_INLINE Term NF_FID_102_108_117_115_104_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967293) == CID__CTOR_71_97_112_)) {
nf_out[0] = v_4294967292;
return 1;
} else {
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967289) == CID__CTOR_73_110_73_100_)) {
Term fields[1];
if (term_tag(v_4294967289) == TAG_PAK) { fields[0] = term_loc(v_4294967289); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294967289, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_73_100__0
u32
#else
Term
#endif
v_4294967285 = fields[0];
Term v_4294967284;
{
v_4294967284 = v_4294967288;
goto nf_join_14;
}
nf_join_14:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967283;
{
v_4294967283 = 1ull;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
v_4294967282 = v_4294967285;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_17[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_17, v_4294967284, v_4294967283, v_4294967282)) { return 0; }
nf_out[0] = nq_result_17[0];
return 1;
} else {
Term v_4294967277;
{
v_4294967277 = v_4294967289;
goto nf_join_20;
}
nf_join_20:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967276;
{
v_4294967276 = v_4294967288;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967277) == CID__CTOR_73_110_78_109_)) {
Term fields[1];
if (term_tag(v_4294967277) == TAG_PAK) { fields[0] = term_loc(v_4294967277); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294967277, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_78_109__0
u32
#else
Term
#endif
v_4294967273 = fields[0];
Term v_4294967272;
{
v_4294967272 = v_4294967276;
goto nf_join_26;
}
nf_join_26:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967271;
{
v_4294967271 = 2ull;
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967270;
{
v_4294967270 = v_4294967273;
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_29[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_29, v_4294967272, v_4294967271, v_4294967270)) { return 0; }
nf_out[0] = nq_result_29[0];
return 1;
} else {
term_sink(e, v_4294967277);
term_sink(e, v_4294967276);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
return 0;
}
INLINE Term NF_FID_108_101_120_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967293;
{
v_4294967293 = v_4294967295;
goto nf_join_4;
}
nf_join_4:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967292;
{
v_4294967292 = v_4294967294;
goto nf_join_5;
}
nf_join_5:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967293) == CID_SNIL)) {
if ((term_aux(v_4294967292) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967292, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294967289 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294967288 = fields[1];
Term v_4294967287;
{
v_4294967287 = v_4294967289;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967286;
{
v_4294967286 = v_4294967288;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_12[1];
if (!NF_FID_102_108_117_115_104_(e, seq, nq_result_12, v_4294967287, v_4294967286)) { return 0; }
nf_out[0] = nq_result_12[0];
return 1;
} else {
term_sink(e, v_4294967292);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
Term v_4294967282;
{
v_4294967282 = v_4294967293;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = v_4294967292;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967282) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967282, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294967278 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294967277 = fields[1];
Term v_4294967276;
{
v_4294967276 = v_4294967278;
goto nf_join_22;
}
nf_join_22:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967275;
{
v_4294967275 = v_4294967277;
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967274;
{
v_4294967274 = v_4294967281;
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294967270 = v_4294967276;
if ((term_aux(v_4294967274) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967274, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294967269 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294967268 = fields[1];
Term v_4294967267;
{
v_4294967267 = v_4294967275;
goto nf_join_30;
}
nf_join_30:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967264;
Term v_4294967263;
{
Term v_4294967261;
{
v_4294967261 = v_4294967269;
goto nf_join_37;
}
nf_join_37:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967260;
{
v_4294967260 = v_4294967270;
goto nf_join_38;
}
nf_join_38:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967259;
{
v_4294967259 = v_4294967268;
goto nf_join_39;
}
nf_join_39:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_40[2];
if (!NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_(e, seq, nq_result_40, v_4294967261, v_4294967260, v_4294967259)) { return 0; }
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
nq_result_40[0] = (u32)nq_result_40[0];
#endif
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
nq_result_40[1] = (u32)nq_result_40[1];
#endif
v_4294967264 = nq_result_40[0];
v_4294967263 = nq_result_40[1];
goto nq_join_31;
}
nq_join_31:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_33[1];
if (!NF_FID_36_112_114_111_100_117_99_116_46_108_101_120_(e, seq, nq_result_33, v_4294967267, v_4294967264, v_4294967263)) { return 0; }
nf_out[0] = nq_result_33[0];
return 1;
} else {
term_sink(e, v_4294967275);
term_sink(e, v_4294967270);
term_sink(e, v_4294967274);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294967276);
term_sink(e, v_4294967275);
term_sink(e, v_4294967274);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294967282);
term_sink(e, v_4294967281);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_46_97_116_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967294, NF_SCALAR v_4294967293, NF_SCALAR v_4294967292) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967291;
{
v_4294967291 = v_4294967295;
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967294;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
{
v_4294967288 = v_4294967292;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967291) == CID__CTOR_71_97_112_)) {
Term v_4294967283;
{
v_4294967283 = v_4294967290;
goto nf_join_15;
}
nf_join_15:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967282;
{
v_4294967282 = v_4294967289;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967281;
{
v_4294967281 = v_4294967288;
goto nf_join_17;
}
nf_join_17:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967283) == CID__CTOR_76_101_116_116_101_114_)) {
Term v_4294967277;
{
Term v_4294967273;
{
Term v_4294967270;
{
v_4294967270 = 2166136261ull;
goto nf_join_27;
}
nf_join_27:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967269;
{
v_4294967269 = v_4294967282;
goto nf_join_28;
}
nf_join_28:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_29[1];
if (!NF_FID_102_110_118_(e, seq, nq_result_29, v_4294967270, v_4294967269)) { return 0; }
v_4294967273 = nq_result_29[0];
goto nf_join_23;
}
nf_join_23:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_24 = v_4294967273;
Term pk_24;
#if NATIVE_PACK_CTORS
if ((pf_24 & ~LOC_MASK) == 0) {
pk_24 = term_pak(CID__CTOR_73_110_73_100_, pf_24);
} else
#endif
{
u64 nd_24 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_24 + 0] = pf_24;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_24 + 0] = pf_24;
#else
e.mem[nd_24 + 0] = rfc_seal(e, pf_24);
#endif
#endif
pk_24 = term_ctr(CID__CTOR_73_110_73_100_, nd_24);
}
v_4294967277 = pk_24;
goto nf_join_20;
}
nf_join_20:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967276;
{
v_4294967276 = v_4294967281;
goto nf_join_21;
}
nf_join_21:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967277;
nf_out[1] = v_4294967276;
return 1;
} else {
Term v_4294967265;
{
v_4294967265 = v_4294967283;
goto nf_join_33;
}
nf_join_33:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967264;
{
v_4294967264 = v_4294967282;
goto nf_join_34;
}
nf_join_34:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967263;
{
v_4294967263 = v_4294967281;
goto nf_join_35;
}
nf_join_35:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967265) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294967259;
{
Term v_4294967255;
{
Term v_4294967252;
{
v_4294967252 = v_4294967264;
goto nf_join_45;
}
nf_join_45:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967251;
{
v_4294967251 = 48ull;
goto nf_join_46;
}
nf_join_46:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967255 = U32_BIN(v_4294967252, -, v_4294967251);
goto nf_join_41;
}
nf_join_41:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_42 = v_4294967255;
Term pk_42;
#if NATIVE_PACK_CTORS
if ((pf_42 & ~LOC_MASK) == 0) {
pk_42 = term_pak(CID__CTOR_73_110_78_109_, pf_42);
} else
#endif
{
u64 nd_42 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_42 + 0] = pf_42;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_42 + 0] = pf_42;
#else
e.mem[nd_42 + 0] = rfc_seal(e, pf_42);
#endif
#endif
pk_42 = term_ctr(CID__CTOR_73_110_78_109_, nd_42);
}
v_4294967259 = pk_42;
goto nf_join_38;
}
nf_join_38:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967258;
{
v_4294967258 = v_4294967263;
goto nf_join_39;
}
nf_join_39:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967259;
nf_out[1] = v_4294967258;
return 1;
} else {
Term v_4294967248;
{
v_4294967248 = v_4294967265;
goto nf_join_50;
}
nf_join_50:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967247;
{
v_4294967247 = v_4294967264;
goto nf_join_51;
}
nf_join_51:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967246;
{
v_4294967246 = v_4294967263;
goto nf_join_52;
}
nf_join_52:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967248) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294967247);
Term v_4294967242;
{
v_4294967242 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_55;
}
nf_join_55:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967241;
{
v_4294967241 = v_4294967246;
goto nf_join_56;
}
nf_join_56:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967242;
nf_out[1] = v_4294967241;
return 1;
} else {
Term v_4294967238;
{
v_4294967238 = v_4294967248;
goto nf_join_60;
}
nf_join_60:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967237;
{
v_4294967237 = v_4294967247;
goto nf_join_61;
}
nf_join_61:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967236;
{
v_4294967236 = v_4294967246;
goto nf_join_62;
}
nf_join_62:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967238) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294967232;
{
v_4294967232 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_65;
}
nf_join_65:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967231;
{
Term v_4294967228;
{
v_4294967228 = v_4294967236;
goto nf_join_70;
}
nf_join_70:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967227;
{
v_4294967227 = 3ull;
goto nf_join_71;
}
nf_join_71:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967226;
{
v_4294967226 = v_4294967237;
goto nf_join_72;
}
nf_join_72:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_73[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_73, v_4294967228, v_4294967227, v_4294967226)) { return 0; }
v_4294967231 = nq_result_73[0];
goto nf_join_66;
}
nf_join_66:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967232;
nf_out[1] = v_4294967231;
return 1;
} else {
term_sink(e, v_4294967238);
term_sink(e, v_4294967237);
term_sink(e, v_4294967236);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
Term v_4294967221;
{
v_4294967221 = v_4294967291;
goto nf_join_78;
}
nf_join_78:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967220;
{
v_4294967220 = v_4294967290;
goto nf_join_79;
}
nf_join_79:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967219;
{
v_4294967219 = v_4294967289;
goto nf_join_80;
}
nf_join_80:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967218;
{
v_4294967218 = v_4294967288;
goto nf_join_81;
}
nf_join_81:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967221) == CID__CTOR_73_110_73_100_)) {
Term fields[1];
if (term_tag(v_4294967221) == TAG_PAK) { fields[0] = term_loc(v_4294967221); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294967221, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_73_100__0
u32
#else
Term
#endif
v_4294967213 = fields[0];
Term v_4294967212;
{
v_4294967212 = v_4294967220;
goto nf_join_86;
}
nf_join_86:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967211;
{
v_4294967211 = v_4294967219;
goto nf_join_87;
}
nf_join_87:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967210;
{
v_4294967210 = v_4294967218;
goto nf_join_88;
}
nf_join_88:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967212) == CID__CTOR_76_101_116_116_101_114_)) {
Term v_4294967206;
{
Term v_4294967202;
{
Term v_4294967199;
{
v_4294967199 = v_4294967213;
goto nf_join_98;
}
nf_join_98:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967198;
{
v_4294967198 = v_4294967211;
goto nf_join_99;
}
nf_join_99:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_100[1];
if (!NF_FID_102_110_118_(e, seq, nq_result_100, v_4294967199, v_4294967198)) { return 0; }
v_4294967202 = nq_result_100[0];
goto nf_join_94;
}
nf_join_94:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_95 = v_4294967202;
Term pk_95;
#if NATIVE_PACK_CTORS
if ((pf_95 & ~LOC_MASK) == 0) {
pk_95 = term_pak(CID__CTOR_73_110_73_100_, pf_95);
} else
#endif
{
u64 nd_95 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_95 + 0] = pf_95;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_95 + 0] = pf_95;
#else
e.mem[nd_95 + 0] = rfc_seal(e, pf_95);
#endif
#endif
pk_95 = term_ctr(CID__CTOR_73_110_73_100_, nd_95);
}
v_4294967206 = pk_95;
goto nf_join_91;
}
nf_join_91:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967205;
{
v_4294967205 = v_4294967210;
goto nf_join_92;
}
nf_join_92:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967206;
nf_out[1] = v_4294967205;
return 1;
} else {
Term v_4294967194;
{
v_4294967194 = v_4294967212;
goto nf_join_104;
}
nf_join_104:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967193;
{
v_4294967193 = v_4294967211;
goto nf_join_105;
}
nf_join_105:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967192;
{
v_4294967192 = v_4294967210;
goto nf_join_106;
}
nf_join_106:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967194) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294967188;
{
Term v_4294967177;
{
Term v_4294967174;
{
v_4294967174 = v_4294967193;
goto nf_join_123;
}
nf_join_123:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967173;
{
v_4294967173 = 48ull;
goto nf_join_124;
}
nf_join_124:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967177 = U32_BIN(v_4294967174, -, v_4294967173);
goto nf_join_119;
}
nf_join_119:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_120 = v_4294967177;
Term pk_120;
#if NATIVE_PACK_CTORS
if ((pf_120 & ~LOC_MASK) == 0) {
pk_120 = term_pak(CID__CTOR_73_110_78_109_, pf_120);
} else
#endif
{
u64 nd_120 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_120 + 0] = pf_120;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_120 + 0] = pf_120;
#else
e.mem[nd_120 + 0] = rfc_seal(e, pf_120);
#endif
#endif
pk_120 = term_ctr(CID__CTOR_73_110_78_109_, nd_120);
}
v_4294967188 = pk_120;
goto nf_join_109;
}
nf_join_109:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967187;
{
Term v_4294967184;
{
v_4294967184 = v_4294967192;
goto nf_join_114;
}
nf_join_114:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967183;
{
v_4294967183 = 1ull;
goto nf_join_115;
}
nf_join_115:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967182;
{
v_4294967182 = v_4294967213;
goto nf_join_116;
}
nf_join_116:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_117[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_117, v_4294967184, v_4294967183, v_4294967182)) { return 0; }
v_4294967187 = nq_result_117[0];
goto nf_join_110;
}
nf_join_110:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967188;
nf_out[1] = v_4294967187;
return 1;
} else {
Term v_4294967170;
{
v_4294967170 = v_4294967194;
goto nf_join_128;
}
nf_join_128:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967169;
{
v_4294967169 = v_4294967193;
goto nf_join_129;
}
nf_join_129:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967168;
{
v_4294967168 = v_4294967192;
goto nf_join_130;
}
nf_join_130:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967170) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294967169);
Term v_4294967164;
{
v_4294967164 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_133;
}
nf_join_133:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967163;
{
Term v_4294967160;
{
v_4294967160 = v_4294967168;
goto nf_join_138;
}
nf_join_138:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967159;
{
v_4294967159 = 1ull;
goto nf_join_139;
}
nf_join_139:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967158;
{
v_4294967158 = v_4294967213;
goto nf_join_140;
}
nf_join_140:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_141[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_141, v_4294967160, v_4294967159, v_4294967158)) { return 0; }
v_4294967163 = nq_result_141[0];
goto nf_join_134;
}
nf_join_134:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967164;
nf_out[1] = v_4294967163;
return 1;
} else {
Term v_4294967153;
{
v_4294967153 = v_4294967170;
goto nf_join_145;
}
nf_join_145:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967152;
{
v_4294967152 = v_4294967169;
goto nf_join_146;
}
nf_join_146:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967151;
{
v_4294967151 = v_4294967168;
goto nf_join_147;
}
nf_join_147:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967153) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294967147;
{
v_4294967147 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_150;
}
nf_join_150:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967146;
{
Term v_4294967143;
{
Term v_4294967136;
{
v_4294967136 = v_4294967151;
goto nf_join_162;
}
nf_join_162:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967135;
{
v_4294967135 = 1ull;
goto nf_join_163;
}
nf_join_163:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967134;
{
v_4294967134 = v_4294967213;
goto nf_join_164;
}
nf_join_164:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_165[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_165, v_4294967136, v_4294967135, v_4294967134)) { return 0; }
v_4294967143 = nq_result_165[0];
goto nf_join_155;
}
nf_join_155:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967142;
{
v_4294967142 = 3ull;
goto nf_join_156;
}
nf_join_156:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967141;
{
v_4294967141 = v_4294967152;
goto nf_join_157;
}
nf_join_157:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_158[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_158, v_4294967143, v_4294967142, v_4294967141)) { return 0; }
v_4294967146 = nq_result_158[0];
goto nf_join_151;
}
nf_join_151:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967147;
nf_out[1] = v_4294967146;
return 1;
} else {
term_sink(e, v_4294967213);
term_sink(e, v_4294967153);
term_sink(e, v_4294967152);
term_sink(e, v_4294967151);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
Term v_4294967129;
{
v_4294967129 = v_4294967221;
goto nf_join_170;
}
nf_join_170:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967128;
{
v_4294967128 = v_4294967220;
goto nf_join_171;
}
nf_join_171:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967127;
{
v_4294967127 = v_4294967219;
goto nf_join_172;
}
nf_join_172:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967126;
{
v_4294967126 = v_4294967218;
goto nf_join_173;
}
nf_join_173:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967129) == CID__CTOR_73_110_78_109_)) {
Term fields[1];
if (term_tag(v_4294967129) == TAG_PAK) { fields[0] = term_loc(v_4294967129); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294967129, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_78_109__0
u32
#else
Term
#endif
v_4294967121 = fields[0];
Term v_4294967120;
{
v_4294967120 = v_4294967128;
goto nf_join_178;
}
nf_join_178:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967119;
{
v_4294967119 = v_4294967127;
goto nf_join_179;
}
nf_join_179:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967118;
{
v_4294967118 = v_4294967126;
goto nf_join_180;
}
nf_join_180:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967120) == CID__CTOR_76_101_116_116_101_114_)) {
Term v_4294967114;
{
Term v_4294967103;
{
Term v_4294967100;
{
v_4294967100 = 2166136261ull;
goto nf_join_197;
}
nf_join_197:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967099;
{
v_4294967099 = v_4294967119;
goto nf_join_198;
}
nf_join_198:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_199[1];
if (!NF_FID_102_110_118_(e, seq, nq_result_199, v_4294967100, v_4294967099)) { return 0; }
v_4294967103 = nq_result_199[0];
goto nf_join_193;
}
nf_join_193:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_194 = v_4294967103;
Term pk_194;
#if NATIVE_PACK_CTORS
if ((pf_194 & ~LOC_MASK) == 0) {
pk_194 = term_pak(CID__CTOR_73_110_73_100_, pf_194);
} else
#endif
{
u64 nd_194 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_194 + 0] = pf_194;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_194 + 0] = pf_194;
#else
e.mem[nd_194 + 0] = rfc_seal(e, pf_194);
#endif
#endif
pk_194 = term_ctr(CID__CTOR_73_110_73_100_, nd_194);
}
v_4294967114 = pk_194;
goto nf_join_183;
}
nf_join_183:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967113;
{
Term v_4294967110;
{
v_4294967110 = v_4294967118;
goto nf_join_188;
}
nf_join_188:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967109;
{
v_4294967109 = 2ull;
goto nf_join_189;
}
nf_join_189:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967108;
{
v_4294967108 = v_4294967121;
goto nf_join_190;
}
nf_join_190:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_191[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_191, v_4294967110, v_4294967109, v_4294967108)) { return 0; }
v_4294967113 = nq_result_191[0];
goto nf_join_184;
}
nf_join_184:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967114;
nf_out[1] = v_4294967113;
return 1;
} else {
Term v_4294967095;
{
v_4294967095 = v_4294967120;
goto nf_join_203;
}
nf_join_203:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967094;
{
v_4294967094 = v_4294967119;
goto nf_join_204;
}
nf_join_204:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967093;
{
v_4294967093 = v_4294967118;
goto nf_join_205;
}
nf_join_205:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967095) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294967089;
{
Term v_4294967085;
{
Term v_4294967082;
{
Term v_4294967074;
{
v_4294967074 = v_4294967121;
goto nf_join_223;
}
nf_join_223:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967073;
{
v_4294967073 = 10ull;
goto nf_join_224;
}
nf_join_224:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967082 = U32_BIN(v_4294967074, *, v_4294967073);
goto nf_join_215;
}
nf_join_215:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967081;
{
Term v_4294967078;
{
v_4294967078 = v_4294967094;
goto nf_join_219;
}
nf_join_219:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967077;
{
v_4294967077 = 48ull;
goto nf_join_220;
}
nf_join_220:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967081 = U32_BIN(v_4294967078, -, v_4294967077);
goto nf_join_216;
}
nf_join_216:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967085 = U32_BIN(v_4294967082, +, v_4294967081);
goto nf_join_211;
}
nf_join_211:;
if (!seq && err_seen(e.mem)) { return 0; }
Term pf_212 = v_4294967085;
Term pk_212;
#if NATIVE_PACK_CTORS
if ((pf_212 & ~LOC_MASK) == 0) {
pk_212 = term_pak(CID__CTOR_73_110_78_109_, pf_212);
} else
#endif
{
u64 nd_212 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_212 + 0] = pf_212;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_212 + 0] = pf_212;
#else
e.mem[nd_212 + 0] = rfc_seal(e, pf_212);
#endif
#endif
pk_212 = term_ctr(CID__CTOR_73_110_78_109_, nd_212);
}
v_4294967089 = pk_212;
goto nf_join_208;
}
nf_join_208:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967088;
{
v_4294967088 = v_4294967093;
goto nf_join_209;
}
nf_join_209:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967089;
nf_out[1] = v_4294967088;
return 1;
} else {
Term v_4294967070;
{
v_4294967070 = v_4294967095;
goto nf_join_228;
}
nf_join_228:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967069;
{
v_4294967069 = v_4294967094;
goto nf_join_229;
}
nf_join_229:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967068;
{
v_4294967068 = v_4294967093;
goto nf_join_230;
}
nf_join_230:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967070) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294967069);
Term v_4294967064;
{
v_4294967064 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_233;
}
nf_join_233:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967063;
{
Term v_4294967060;
{
v_4294967060 = v_4294967068;
goto nf_join_238;
}
nf_join_238:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967059;
{
v_4294967059 = 2ull;
goto nf_join_239;
}
nf_join_239:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967058;
{
v_4294967058 = v_4294967121;
goto nf_join_240;
}
nf_join_240:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_241[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_241, v_4294967060, v_4294967059, v_4294967058)) { return 0; }
v_4294967063 = nq_result_241[0];
goto nf_join_234;
}
nf_join_234:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967064;
nf_out[1] = v_4294967063;
return 1;
} else {
Term v_4294967053;
{
v_4294967053 = v_4294967070;
goto nf_join_245;
}
nf_join_245:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967052;
{
v_4294967052 = v_4294967069;
goto nf_join_246;
}
nf_join_246:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967051;
{
v_4294967051 = v_4294967068;
goto nf_join_247;
}
nf_join_247:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967053) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294967047;
{
v_4294967047 = term_pak(CID__CTOR_71_97_112_, 0);
goto nf_join_250;
}
nf_join_250:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967046;
{
Term v_4294967043;
{
Term v_4294967036;
{
v_4294967036 = v_4294967051;
goto nf_join_262;
}
nf_join_262:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967035;
{
v_4294967035 = 2ull;
goto nf_join_263;
}
nf_join_263:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967034;
{
v_4294967034 = v_4294967121;
goto nf_join_264;
}
nf_join_264:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_265[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_265, v_4294967036, v_4294967035, v_4294967034)) { return 0; }
v_4294967043 = nq_result_265[0];
goto nf_join_255;
}
nf_join_255:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967042;
{
v_4294967042 = 3ull;
goto nf_join_256;
}
nf_join_256:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967041;
{
v_4294967041 = v_4294967052;
goto nf_join_257;
}
nf_join_257:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_258[1];
if (!NF_FID_109_105_120_(e, seq, nq_result_258, v_4294967043, v_4294967042, v_4294967041)) { return 0; }
v_4294967046 = nq_result_258[0];
goto nf_join_251;
}
nf_join_251:;
if (!seq && err_seen(e.mem)) { return 0; }
nf_out[0] = v_4294967047;
nf_out[1] = v_4294967046;
return 1;
} else {
term_sink(e, v_4294967121);
term_sink(e, v_4294967053);
term_sink(e, v_4294967052);
term_sink(e, v_4294967051);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
term_sink(e, v_4294967129);
term_sink(e, v_4294967128);
term_sink(e, v_4294967127);
term_sink(e, v_4294967126);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
return 0;
}
INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_(Env e, bool seq, Term* nf_out, Term v_4294967295, NF_SCALAR v_4294967294, NF_SCALAR v_4294967293) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
Term v_4294967292;
{
v_4294967292 = v_4294967295;
goto nf_join_7;
}
nf_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294967294 = term_keep(e, v_4294967294);
Term v_4294967291;
{
Term v_4294967283;
{
v_4294967283 = v_4294967294;
goto nf_join_13;
}
nf_join_13:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_14[1];
if (!NF_FID_99_108_115_(e, seq, nq_result_14, v_4294967283)) { return 0; }
v_4294967291 = nq_result_14[0];
goto nf_join_8;
}
nf_join_8:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967290;
{
v_4294967290 = v_4294967294;
goto nf_join_9;
}
nf_join_9:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967289;
{
v_4294967289 = v_4294967293;
goto nf_join_10;
}
nf_join_10:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_11[2];
if (!NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_46_97_116_(e, seq, nq_result_11, v_4294967292, v_4294967291, v_4294967290, v_4294967289)) { return 0; }
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
nq_result_11[0] = (u32)nq_result_11[0];
#endif
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
nq_result_11[1] = (u32)nq_result_11[1];
#endif
nf_out[0] = nq_result_11[0];
nf_out[1] = nq_result_11[1];
return 1;
}
return 0;
}
INLINE Term NF_FID_36_112_114_111_100_117_99_116_46_108_101_120_(Env e, bool seq, Term* nf_out, Term v_4294967295, Term v_4294967293, Term v_4294967292) {
u32 nf_poll = 0;
nf_again:;
if (err_spun(e.mem, &nf_poll)) { return 0; }
{
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
v_4294967293 = (u32)v_4294967293;
#endif
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
v_4294967292 = (u32)v_4294967292;
#endif
Term v_4294967291;
{
v_4294967291 = v_4294967295;
goto nf_join_6;
}
nf_join_6:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967288;
Term v_4294967287;
{
v_4294967288 = v_4294967293;
v_4294967287 = v_4294967292;
goto nq_join_7;
}
nq_join_7:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967291) == CID_SNIL)) {
Term v_4294967286;
{
v_4294967286 = v_4294967288;
goto nf_join_11;
}
nf_join_11:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967285;
{
v_4294967285 = v_4294967287;
goto nf_join_12;
}
nf_join_12:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_13[1];
if (!NF_FID_102_108_117_115_104_(e, seq, nq_result_13, v_4294967286, v_4294967285)) { return 0; }
nf_out[0] = nq_result_13[0];
return 1;
} else {
Term v_4294967281;
{
v_4294967281 = v_4294967291;
goto nf_join_16;
}
nf_join_16:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967278;
Term v_4294967277;
{
v_4294967278 = v_4294967288;
v_4294967277 = v_4294967287;
goto nq_join_17;
}
nq_join_17:;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294967281) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294967281, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294967276 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294967275 = fields[1];
Term v_4294967274;
{
v_4294967274 = v_4294967276;
goto nf_join_24;
}
nf_join_24:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967273;
{
v_4294967273 = v_4294967275;
goto nf_join_25;
}
nf_join_25:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967269;
Term v_4294967268;
{
v_4294967269 = v_4294967278;
v_4294967268 = v_4294967277;
goto nq_join_26;
}
nq_join_26:;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294967267 = v_4294967274;
Term v_4294967266;
{
v_4294967266 = v_4294967273;
goto nf_join_31;
}
nf_join_31:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967263;
Term v_4294967262;
{
Term v_4294967261;
{
v_4294967261 = v_4294967269;
goto nf_join_37;
}
nf_join_37:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967260;
{
v_4294967260 = v_4294967267;
goto nf_join_38;
}
nf_join_38:;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294967259;
{
v_4294967259 = v_4294967268;
goto nf_join_39;
}
nf_join_39:;
if (!seq && err_seen(e.mem)) { return 0; }
Term nq_result_40[2];
if (!NF_FID_36_112_114_111_100_117_99_116_46_115_116_101_112_(e, seq, nq_result_40, v_4294967261, v_4294967260, v_4294967259)) { return 0; }
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
nq_result_40[0] = (u32)nq_result_40[0];
#endif
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
nq_result_40[1] = (u32)nq_result_40[1];
#endif
v_4294967263 = nq_result_40[0];
v_4294967262 = nq_result_40[1];
goto nq_join_32;
}
nq_join_32:;
if (!seq && err_seen(e.mem)) { return 0; }
{
Term nf_arg_0 = v_4294967266;
Term nf_arg_1 = v_4294967263;
Term nf_arg_2 = v_4294967262;
v_4294967295 = nf_arg_0;
v_4294967293 = nf_arg_1;
v_4294967292 = nf_arg_2;
goto nf_again;
}
} else {
term_sink(e, v_4294967274);
term_sink(e, v_4294967273);
term_sink(e, v_4294967269);
term_sink(e, v_4294967268);
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
term_sink(e, v_4294967281);
term_sink(e, v_4294967278);
term_sink(e, v_4294967277);
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
return 0;
}
#undef NF_INLINE
#undef NF_SCALAR
#endif


// Work
// ====

// A host self-jump is a tail call: as a loop, MachineLICM hoisted eleven
// constants into symreg's entry (3.05 s against 2.51 s).
#if !DEVICE
#undef  WL_SPIN
#undef  WL_SPUN
#undef  WL_AGAIN
#define WL_SPIN
#define WL_SPUN
#define WL_AGAIN(F) __attribute__((musttail)) return WL_##F(WL_ALL)

typedef Reply (PRESERVE(preserve_none) *WlFn)(WL_SIG);
#define WL_X(F) WL_FN WL_##F(WL_SIG);
WL_TABLE WL_X(FID_ENTER)
#undef WL_X
#define WL_X(F) WL_##F,
static const WlFn wl_tab[] = { WL_TABLE };
#undef WL_X
#if FID_ENTER >= 4096
// Keep the shared dispatch table out of each segment's LLVM reference graph.
FAR PRESERVE(preserve_most) WlFn wl_target(Fid id) { return wl_tab[id]; }
#undef WL_DYN
#define WL_DYN(F) __attribute__((musttail)) return wl_target(F)(WL_ALL)
#endif
#endif

static Reply work_loop(Env e, Stk sp, Term t, bool seq) {
  WL_BANK
  u32 rn = 0;
  r0 = t;
#if DEVICE
  Fid fid   = FID_ENTER;
  u32 wpoll = 0;
  for (;;) {
  if (err_spun(e.mem, &wpoll)) {
    return 0;
  }
  switch (fid) {
#else
  return WL_FID_ENTER(WL_ALL);
}
#endif

// Segments
// ========

  WL_CASE(FID_109_97_105_110_)
  {
    WL_OPEN
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_48_50_54_;
WL_PUSHN(1);
} else {
u64 task_1037 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_50_54_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_50_54_, task_1037);
WL_IDX = 0;
}
WL_JMP(FID_73_79_46_112_114_105_110_116_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_50_54_)
  {
    Term v_4294966271 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294966271;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_48_50_55_;
WL_PUSHN(2);
} else {
u64 task_1037 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_50_55_, WL_CONT, WL_IDX, 1);
e.mem[task_1037 + 0] = v_4294966271;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_50_55_, task_1037);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_48_50_57_;
WL_PUSHN(1);
} else {
u64 task_1037 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_50_57_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_50_57_, task_1037);
WL_IDX = 0;
}
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_48_51_50_;
WL_PUSHN(1);
} else {
u64 task_1037 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_51_50_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_51_50_, task_1037);
WL_IDX = 0;
}
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_48_51_53_;
WL_PUSHN(1);
} else {
u64 task_1037 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_51_53_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_51_53_, task_1037);
WL_IDX = 0;
}
WL_JMP(FID_98_97_116_99_104_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_50_55_)
  {
    WL_POPN(1);
    Term v_4294966271 = STK(0);
    Term v_4294966270 = r0;
    WL_OPEN
{ Term fn = v_4294966271; Term arg = v_4294966270;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_50_57_)
  {
    Term v_4294966267 = r0;
    WL_OPEN
r0 = v_4294966267;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_51_50_)
  {
    Term v_4294966265 = r0;
    WL_OPEN
Term v_4294966264 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294966265; Term arg = v_4294966264;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_51_53_)
  {
    Term v_4294966262 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294966262;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_48_51_54_;
WL_PUSHN(2);
} else {
u64 task_1037 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_48_51_54_, WL_CONT, WL_IDX, 1);
e.mem[task_1037 + 0] = v_4294966262;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_48_51_54_, task_1037);
WL_IDX = 1;
}
WL_JMP(FID_115_105_122_101_46_98_105_103_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_51_54_)
  {
    WL_POPN(1);
    Term v_4294966262 = STK(0);
    Term v_4294966261 = r0;
    WL_OPEN
{ Term fn = v_4294966262; Term arg = v_4294966261;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_73_79_46_112_114_105_110_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_48_54_49_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_54_49_)
  {
    Term v_4294966258 = r0;
    WL_OPEN
u64 cl_2064 = heap_alloc(e, cls_fit(1));
e.mem[cl_2064 + 0] = v_4294966258;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_48_54_50_, cl_2064);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_48_54_50_)
  {
    Term v_4294966258 = r0;
    Term v_4294966256 = r1;
    WL_OPEN
u64 nd_2063 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_IO_PRINT
e.mem[nd_2063 + 0] = v_4294966258;
e.mem[nd_2063 + 1] = v_4294966256;
#else
e.mem[nd_2063 + 0] = rfc_seal(e, v_4294966258);
e.mem[nd_2063 + 1] = rfc_seal(e, v_4294966256);
#endif
r0 = term_ctr(CID_IO_PRINT, nd_2063);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_73_79_46_112_114_105_110_116_)
  {
    Term v_4294965230 = r0;
    Term v_4294965229 = r1;
    WL_OPEN
u64 nd_2067 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_IO_PRINT
e.mem[nd_2067 + 0] = v_4294965230;
e.mem[nd_2067 + 1] = v_4294965229;
#else
e.mem[nd_2067 + 0] = rfc_seal(e, v_4294965230);
e.mem[nd_2067 + 1] = rfc_seal(e, v_4294965229);
#endif
r0 = term_ctr(CID_IO_PRINT, nd_2067);
WL_RETN(1);

  }}

  WL_CASE(FID_85_51_50_46_115_104_111_119_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_57_51_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_57_51_)
  {
    Term v_4294964203 = r0;
    WL_OPEN
r0 = v_4294964203;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294964201 = r0;
    WL_OPEN
Term v_1960 = v_4294964201;
if (!seq && err_seen(e.mem)) { return 0; }
v_1960 = term_keep(e, v_1960);
Term v_4294964200 = v_1960;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294964198 = v_1960;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294964199 = U32_BIN(v_4294964198, ==, 0);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294964200;
r1 = v_4294964199;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_105_102_);

  }}

  WL_CASE(FID_85_51_50_46_115_104_111_119_46_105_102_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_50_52_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_50_52_)
  {
    Term v_4294963173 = r0;
    WL_OPEN
u64 cl_4126 = heap_alloc(e, cls_fit(1));
e.mem[cl_4126 + 0] = v_4294963173;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_50_53_, cl_4126);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_50_53_)
  {
    Term v_4294963173 = r0;
    Term v_4294963172 = r1;
    WL_OPEN
r0 = v_4294963173;
r1 = v_4294963172;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_105_102_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_105_102_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294963168 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294963167 = r1;
    WL_OPEN
if (native_bool(v_4294963167)) {
term_sink(e, v_4294963168);
r0 = term_ctr(CID_SCON, STAT_OFF + 80);
WL_RETN(1);
} else {
if ((!native_bool(v_4294963167))) {
Term v_4294963166 = 10ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294963165 = v_4294963168;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294963164 = term_pak(CID_SNIL, 0);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294963166;
r1 = v_4294963165;
r2 = v_4294963164;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_103_111_);
} else {
term_sink(e, v_4294963168);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294963167;
STK(1) = FID_110_97_116_105_118_101_95_107_95_52_49_51_52_;
WL_PUSHN(2);
} else {
u64 task_4135 = task_node(e, FID_110_97_116_105_118_101_95_107_95_52_49_51_52_, WL_CONT, WL_IDX, 1);
e.mem[task_4135 + 0] = v_4294963167;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_52_49_51_52_, task_4135);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_51_52_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294963167 = STK(0);
    Term v_4294963163 = r0;
    WL_OPEN
Term v_4294963162 = v_4294963167;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294963163; Term arg = v_4294963162;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_85_51_50_46_115_104_111_119_46_103_111_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_54_50_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_54_50_)
  {
    Term v_4294962136 = r0;
    WL_OPEN
u64 cl_5166 = heap_alloc(e, cls_fit(1));
e.mem[cl_5166 + 0] = v_4294962136;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_54_51_, cl_5166);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_54_51_)
  {
    Term v_4294962136 = r0;
    Term v_4294962135 = r1;
    WL_OPEN
u64 cl_5165 = heap_alloc(e, cls_fit(2));
e.mem[cl_5165 + 0] = v_4294962136;
e.mem[cl_5165 + 1] = v_4294962135;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_53_49_54_52_, cl_5165);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_54_52_)
  {
    Term v_4294962136 = r0;
    Term v_4294962135 = r1;
    Term v_4294962134 = r2;
    WL_OPEN
r0 = v_4294962136;
r1 = v_4294962135;
r2 = v_4294962134;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_103_111_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_103_111_)
  {
    Term v_4294962128 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294962127 = r1;
    Term v_4294962126 = r2;
    WL_OPEN
Term v_4294962125 = v_4294962128;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962124 = v_4294962127;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962123 = v_4294962126;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294962125 == 0)) {
term_sink(e, v_4294962124);
r0 = v_4294962123;
WL_RETN(1);
} else {
Term v_4294962122 = v_4294962125;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962121 = v_4294962124;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962120 = v_4294962123;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294962122 != 0)) {
#if !DEVICE && NATIVE_FIELD32_CID_SUCC_0
u32
#else
Term
#endif
v_4294962119 = (v_4294962122 - 1);
Term v_4294962118 = v_4294962119;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962117 = v_4294962120;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294962121 = term_keep(e, v_4294962121);
Term v_4294962116 = v_4294962121;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962114 = v_4294962121;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294962115 = U32_BIN(v_4294962114, ==, 0);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294962118;
r1 = v_4294962117;
r2 = v_4294962116;
r3 = v_4294962115;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_102_105_110_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294962120;
STK(1) = FID_110_97_116_105_118_101_95_107_95_53_49_56_52_;
WL_PUSHN(2);
} else {
u64 task_5191 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_49_56_52_, WL_CONT, WL_IDX, 1);
e.mem[task_5191 + 0] = v_4294962120;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_49_56_52_, task_5191);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294962121;
STK(1) = FID_110_97_116_105_118_101_95_107_95_53_49_56_55_;
WL_PUSHN(2);
} else {
u64 task_5191 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_49_56_55_, WL_CONT, WL_IDX, 1);
e.mem[task_5191 + 0] = v_4294962121;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_49_56_55_, task_5191);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294962122;
STK(1) = FID_110_97_116_105_118_101_95_107_95_53_49_57_48_;
WL_PUSHN(2);
} else {
u64 task_5191 = task_node(e, FID_110_97_116_105_118_101_95_107_95_53_49_57_48_, WL_CONT, WL_IDX, 1);
e.mem[task_5191 + 0] = v_4294962122;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_53_49_57_48_, task_5191);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_56_52_)
  {
    WL_POPN(1);
    Term v_4294962120 = STK(0);
    Term v_4294962113 = r0;
    WL_OPEN
Term v_4294962112 = v_4294962120;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294962113; Term arg = v_4294962112;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_56_55_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294962121 = STK(0);
    Term v_4294962110 = r0;
    WL_OPEN
Term v_4294962109 = v_4294962121;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294962110; Term arg = v_4294962109;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_53_49_57_48_)
  {
    WL_POPN(1);
    Term v_4294962122 = STK(0);
    Term v_4294962107 = r0;
    WL_OPEN
Term v_4294962106 = v_4294962122;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294962107; Term arg = v_4294962106;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_85_51_50_46_115_104_111_119_46_102_105_110_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_54_50_49_57_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_49_57_)
  {
    Term v_4294961080 = r0;
    WL_OPEN
u64 cl_6225 = heap_alloc(e, cls_fit(1));
e.mem[cl_6225 + 0] = v_4294961080;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_54_50_50_48_, cl_6225);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_50_48_)
  {
    Term v_4294961080 = r0;
    Term v_4294961079 = r1;
    WL_OPEN
u64 cl_6224 = heap_alloc(e, cls_fit(2));
e.mem[cl_6224 + 0] = v_4294961080;
e.mem[cl_6224 + 1] = v_4294961079;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_54_50_50_49_, cl_6224);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_50_49_)
  {
    Term v_4294961080 = r0;
    Term v_4294961079 = r1;
    Term v_4294961078 = r2;
    WL_OPEN
u64 cl_6223 = heap_alloc(e, cls_fit(3));
e.mem[cl_6223 + 0] = v_4294961080;
e.mem[cl_6223 + 1] = v_4294961079;
e.mem[cl_6223 + 2] = v_4294961078;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_54_50_50_50_, cl_6223);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_50_50_)
  {
    Term v_4294961080 = r0;
    Term v_4294961079 = r1;
    Term v_4294961078 = r2;
    Term v_4294961077 = r3;
    WL_OPEN
r0 = v_4294961080;
r1 = v_4294961079;
r2 = v_4294961078;
r3 = v_4294961077;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_102_105_110_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_102_105_110_)
  {
    Term v_4294961069 = r0;
    Term v_4294961068 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294961067 = r2;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294961066 = r3;
    WL_OPEN
if (native_bool(v_4294961066)) {
term_sink(e, v_4294961069);
term_sink(e, v_4294961067);
r0 = v_4294961068;
WL_RETN(1);
} else {
if ((!native_bool(v_4294961066))) {
Term v_4294961065 = v_4294961069;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294961067 = term_keep(e, v_4294961067);
Term v_4294961062 = v_4294961067;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961061 = 10ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961064 = ((u32)(v_4294961061) == 0 ? 0 : (u64)U32_QUO((u32)(v_4294961062), (u32)(v_4294961061)));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961057 = 48ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961055 = v_4294961067;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961054 = 10ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961056 = ((u32)(v_4294961054) == 0 ? v_4294961055 : U32_BIN(v_4294961055, -, U32_QUO((u32)(v_4294961055), (u32)(v_4294961054)) * v_4294961054));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961058 = U32_BIN(v_4294961057, +, v_4294961056);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961060;
{
v_4294961060 = v_4294961058;
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961059 = v_4294961068;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294961063;
{
u64 nd_6242 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_6242 + 0] = v_4294961060;
e.mem[nd_6242 + 1] = v_4294961059;
#else
e.mem[nd_6242 + 0] = rfc_seal(e, v_4294961060);
e.mem[nd_6242 + 1] = rfc_seal(e, v_4294961059);
#endif
v_4294961063 = term_ctr(CID_SCON, nd_6242);
}
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294961065;
r1 = v_4294961064;
r2 = v_4294961063;
WL_JMP(FID_36_100_105_114_101_99_116_46_85_51_50_46_115_104_111_119_46_103_111_);
} else {
term_sink(e, v_4294961069);
term_sink(e, v_4294961068);
term_sink(e, v_4294961067);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294961066;
STK(1) = FID_110_97_116_105_118_101_95_107_95_54_50_52_53_;
WL_PUSHN(2);
} else {
u64 task_6246 = task_node(e, FID_110_97_116_105_118_101_95_107_95_54_50_52_53_, WL_CONT, WL_IDX, 1);
e.mem[task_6246 + 0] = v_4294961066;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_54_50_52_53_, task_6246);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_54_50_52_53_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294961066 = STK(0);
    Term v_4294961052 = r0;
    WL_OPEN
Term v_4294961051 = v_4294961066;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294961052; Term arg = v_4294961051;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_100_105_118_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_55_50_55_48_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_55_50_55_48_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_7272 = heap_alloc(e, cls_fit(1));
e.mem[cl_7272 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_55_50_55_49_, cl_7272);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_55_50_55_49_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = ((u32)(v_4000000001) == 0 ? 0 : (u64)U32_QUO((u32)(v_4000000000), (u32)(v_4000000001)));
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_100_105_118_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294960022 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294960021 = r1;
    WL_OPEN
r0 = ((u32)(v_4294960021) == 0 ? 0 : (u64)U32_QUO((u32)(v_4294960022), (u32)(v_4294960021)));
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_97_100_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_56_50_57_57_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_56_50_57_57_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_8301 = heap_alloc(e, cls_fit(1));
e.mem[cl_8301 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_56_51_48_48_, cl_8301);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_56_51_48_48_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, +, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_97_100_100_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294958993 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294958992 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294958993, +, v_4294958992);
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_109_111_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_57_51_50_56_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_57_51_50_56_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_9330 = heap_alloc(e, cls_fit(1));
e.mem[cl_9330 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_57_51_50_57_, cl_9330);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_57_51_50_57_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = ((u32)(v_4000000001) == 0 ? v_4000000000 : U32_BIN(v_4000000000, -, U32_QUO((u32)(v_4000000000), (u32)(v_4000000001)) * v_4000000001));
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_109_111_100_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294957964 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294957963 = r1;
    WL_OPEN
r0 = ((u32)(v_4294957963) == 0 ? v_4294957964 : U32_BIN(v_4294957964, -, U32_QUO((u32)(v_4294957964), (u32)(v_4294957963)) * v_4294957963));
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_122_101_114_111_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_48_51_53_55_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_48_51_53_55_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
r0 = U32_BIN(v_4000000000, ==, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_122_101_114_111_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294956937 = r0;
    WL_OPEN
r0 = U32_BIN(v_4294956937, ==, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_98_97_116_99_104_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_52_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_52_)
  {
    Term v_4294955912 = r0;
    WL_OPEN
if (v_4294955912 == 0ull) {
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_53_, 0);
WL_RETN(1);
} else {
Term v_4294955908 = (v_4294955912 - 1ull);
u64 cl_11417 = heap_alloc(e, cls_fit(1));
e.mem[cl_11417 + 0] = v_4294955908;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_56_, cl_11417);
WL_RETN(1);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_53_)
  {
    Term v_3621 = r0;
    WL_OPEN
Term v_4294955909 = v_3621;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955909;
WL_JMP(FID_36_100_105_114_101_99_116_46_108_105_110_101_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_56_)
  {
    Term v_4294955908 = r0;
    Term v_3623 = r1;
    WL_OPEN
if (!seq) {
v_4294955908 = term_keep(e, v_4294955908);
v_3623 = term_keep(e, v_3623);
u64 task_11404 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_48_49_, WL_CONT, WL_IDX, 2);
u64 task_11408 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_48_53_, term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_49_, task_11404), 0, 0);
e.mem[task_11408 + 0] = v_4294955908;
e.mem[task_11408 + 1] = v_3623;
e.mem[task_11404 + 0] = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_53_, task_11408);
u64 task_11416 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_48_57_, term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_49_, task_11404), 1, 0);
e.mem[task_11416 + 0] = v_4294955908;
e.mem[task_11416 + 1] = v_3623;
e.mem[task_11404 + 1] = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_57_, task_11416);
return term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_49_, task_11404);
}
v_4294955908 = term_keep(e, v_4294955908);
v_3623 = term_keep(e, v_3623);
if (seq) {
WL_ROOM(3);
STK(0) = v_4294955908;
STK(1) = v_3623;
STK(2) = FID_110_97_116_105_118_101_95_107_95_49_49_51_56_57_;
WL_PUSHN(3);
} else {
u64 task_11401 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_51_56_57_, WL_CONT, WL_IDX, 1);
e.mem[task_11401 + 0] = v_4294955908;
e.mem[task_11401 + 1] = v_3623;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_57_, task_11401);
WL_IDX = 2;
}
Term v_4294955896 = v_4294955908;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955895 = v_3623;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955896;
r1 = v_4294955895;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_49_)
  {
    Term v_3624 = r0;
    Term v_3625 = r1;
    WL_OPEN
Term v_4294955893 = v_3624;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955892 = v_3625;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294955893, +, v_4294955892);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_51_56_57_)
  {
    WL_POPN(2);
    Term v_4294955908 = STK(0);
    Term v_3623 = STK(1);
    Term v_3624 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_3624;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_51_57_48_;
WL_PUSHN(2);
} else {
u64 task_11399 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_51_57_48_, WL_CONT, WL_IDX, 1);
e.mem[task_11399 + 0] = v_3624;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_51_57_48_, task_11399);
WL_IDX = 1;
}
v_4294955908 = term_keep(e, v_4294955908);
Term v_4294955902 = v_4294955908;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955900 = v_3623;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955898 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955897 = v_4294955908;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955899 = (v_4294955897 >= 32 ? 0 : U32_BIN(v_4294955898, <<, v_4294955897));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955901 = U32_BIN(v_4294955900, +, v_4294955899);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955902;
r1 = v_4294955901;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_51_57_48_)
  {
    WL_POPN(1);
    Term v_3624 = STK(0);
    Term v_3625 = r0;
    WL_OPEN
Term v_4294955904 = v_3624;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955903 = v_3625;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294955904, +, v_4294955903);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_53_)
  {
    Term v_4294955908 = r0;
    Term v_3623 = r1;
    WL_OPEN
Term v_4294955889 = v_4294955908;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955888 = v_3623;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955889;
r1 = v_4294955888;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_48_57_)
  {
    Term v_4294955908 = r0;
    Term v_3623 = r1;
    WL_OPEN
v_4294955908 = term_keep(e, v_4294955908);
Term v_4294955885 = v_4294955908;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955883 = v_3623;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955881 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955880 = v_4294955908;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955882 = (v_4294955880 >= 32 ? 0 : U32_BIN(v_4294955881, <<, v_4294955880));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955884 = U32_BIN(v_4294955883, +, v_4294955882);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955885;
r1 = v_4294955884;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_)
  {
    Term v_4294955877 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294955876 = r1;
    WL_OPEN
Term v_4294955875 = v_4294955877;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955874 = v_4294955876;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294955875 == 0)) {
Term v_4294955873 = v_4294955874;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955873;
WL_JMP(FID_36_100_105_114_101_99_116_46_108_105_110_101_);
} else {
Term v_4294955872 = v_4294955875;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955871 = v_4294955874;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294955872 != 0)) {
#if !DEVICE && NATIVE_FIELD32_CID_SUCC_0
u32
#else
Term
#endif
v_4294955870 = (v_4294955872 - 1);
if (!seq) {
v_4294955871 = term_keep(e, v_4294955871);
v_4294955870 = term_keep(e, v_4294955870);
u64 task_11441 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_51_56_, WL_CONT, WL_IDX, 2);
u64 task_11445 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_, term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_56_, task_11441), 0, 0);
e.mem[task_11445 + 0] = v_4294955871;
e.mem[task_11445 + 1] = v_4294955870;
e.mem[task_11441 + 0] = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_, task_11445);
u64 task_11453 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_52_54_, term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_56_, task_11441), 1, 0);
e.mem[task_11453 + 0] = v_4294955871;
e.mem[task_11453 + 1] = v_4294955870;
e.mem[task_11441 + 1] = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_54_, task_11453);
return term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_56_, task_11441);
}
v_4294955871 = term_keep(e, v_4294955871);
v_4294955870 = term_keep(e, v_4294955870);
if (seq) {
WL_ROOM(3);
STK(0) = v_4294955871;
STK(1) = v_4294955870;
STK(2) = FID_110_97_116_105_118_101_95_107_95_49_49_52_50_54_;
WL_PUSHN(3);
} else {
u64 task_11438 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_50_54_, WL_CONT, WL_IDX, 1);
e.mem[task_11438 + 0] = v_4294955871;
e.mem[task_11438 + 1] = v_4294955870;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_54_, task_11438);
WL_IDX = 2;
}
Term v_4294955859 = v_4294955870;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955858 = v_4294955871;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955859;
r1 = v_4294955858;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955871;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_;
WL_PUSHN(2);
} else {
u64 task_11460 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_, WL_CONT, WL_IDX, 1);
e.mem[task_11460 + 0] = v_4294955871;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_, task_11460);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294955872;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_53_57_;
WL_PUSHN(2);
} else {
u64 task_11460 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_53_57_, WL_CONT, WL_IDX, 1);
e.mem[task_11460 + 0] = v_4294955872;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_57_, task_11460);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_51_56_)
  {
    Term v_3624 = r0;
    Term v_3625 = r1;
    WL_OPEN
Term v_4294955856 = v_3624;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955855 = v_3625;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294955856, +, v_4294955855);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_54_)
  {
    WL_POPN(2);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294955871 = STK(0);
    Term v_4294955870 = STK(1);
    Term v_3624 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_3624;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_49_52_50_55_;
WL_PUSHN(2);
} else {
u64 task_11436 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_49_52_50_55_, WL_CONT, WL_IDX, 1);
e.mem[task_11436 + 0] = v_3624;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_55_, task_11436);
WL_IDX = 1;
}
v_4294955870 = term_keep(e, v_4294955870);
Term v_4294955865 = v_4294955870;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955863 = v_4294955871;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955861 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955860 = v_4294955870;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955862 = (v_4294955860 >= 32 ? 0 : U32_BIN(v_4294955861, <<, v_4294955860));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955864 = U32_BIN(v_4294955863, +, v_4294955862);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955865;
r1 = v_4294955864;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_50_55_)
  {
    WL_POPN(1);
    Term v_3624 = STK(0);
    Term v_3625 = r0;
    WL_OPEN
Term v_4294955867 = v_3624;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955866 = v_3625;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294955867, +, v_4294955866);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_50_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294955871 = r0;
    Term v_4294955870 = r1;
    WL_OPEN
Term v_4294955852 = v_4294955870;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955851 = v_4294955871;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955852;
r1 = v_4294955851;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_52_54_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294955871 = r0;
    Term v_4294955870 = r1;
    WL_OPEN
v_4294955870 = term_keep(e, v_4294955870);
Term v_4294955848 = v_4294955870;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955846 = v_4294955871;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955844 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955843 = v_4294955870;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955845 = (v_4294955843 >= 32 ? 0 : U32_BIN(v_4294955844, <<, v_4294955843));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294955847 = U32_BIN(v_4294955846, +, v_4294955845);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294955848;
r1 = v_4294955847;
WL_JMP(FID_36_100_105_114_101_99_116_46_98_97_116_99_104_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_54_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294955871 = STK(0);
    Term v_4294955841 = r0;
    WL_OPEN
Term v_4294955840 = v_4294955871;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294955841; Term arg = v_4294955840;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_49_52_53_57_)
  {
    WL_POPN(1);
    Term v_4294955872 = STK(0);
    Term v_4294955838 = r0;
    WL_OPEN
Term v_4294955837 = v_4294955872;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294955838; Term arg = v_4294955837;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_108_105_110_101_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_50_52_56_53_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_50_52_56_53_)
  {
    Term v_4294954811 = r0;
    WL_OPEN
r0 = v_4294954811;
WL_JMP(FID_36_100_105_114_101_99_116_46_108_105_110_101_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_108_105_110_101_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294954809 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(1);
STK(0) = FID_110_97_116_105_118_101_95_107_95_49_50_52_56_57_;
WL_PUSHN(1);
} else {
u64 task_12496 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_50_52_56_57_, WL_CONT, WL_IDX, 1);
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_50_52_56_57_, task_12496);
WL_IDX = 0;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294954809;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_50_52_57_51_;
WL_PUSHN(2);
} else {
u64 task_12496 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_50_52_57_51_, WL_CONT, WL_IDX, 1);
e.mem[task_12496 + 0] = v_4294954809;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_50_52_57_51_, task_12496);
WL_IDX = 1;
}
WL_JMP(FID_116_112_108_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_50_52_56_57_)
  {
    Term v_4294954808 = r0;
    WL_OPEN
Term v_4294954807 = term_ctr(CID_TUPLE, STAT_OFF + 78);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294954808;
r1 = v_4294954807;
WL_JMP(FID_36_100_105_114_101_99_116_46_108_101_120_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_50_52_57_51_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294954809 = STK(0);
    Term v_4294954805 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(2);
STK(0) = v_4294954805;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_50_52_57_52_;
WL_PUSHN(2);
} else {
u64 task_12496 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_50_52_57_52_, WL_CONT, WL_IDX, 1);
e.mem[task_12496 + 0] = v_4294954805;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_50_52_57_52_, task_12496);
WL_IDX = 1;
}
Term v_4294954800 = v_4294954809;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294954800;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_101_101_100_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_50_52_57_52_)
  {
    WL_POPN(1);
    Term v_4294954805 = STK(0);
    Term v_4294954804 = r0;
    WL_OPEN
Term v_4294954803 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294954805;
r1 = v_4294954804;
r2 = v_4294954803;
WL_JMP(FID_36_100_105_114_101_99_116_46_103_101_110_);

  }}

  WL_CASE(FID_108_101_120_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_51_53_50_50_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_50_50_)
  {
    Term v_4294953775 = r0;
    WL_OPEN
u64 cl_13524 = heap_alloc(e, cls_fit(1));
e.mem[cl_13524 + 0] = v_4294953775;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_51_53_50_51_, cl_13524);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_50_51_)
  {
    Term v_4294953775 = r0;
    Term v_4294953774 = r1;
    WL_OPEN
r0 = v_4294953775;
r1 = v_4294953774;
WL_JMP(FID_36_100_105_114_101_99_116_46_108_101_120_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_108_101_120_)
  {
    Term v_4294953770 = r0;
    Term v_4294953769 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_108_101_120_(e, seq, nq_result, v_4294953770, v_4294953769)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294953768 = v_4294953770;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953767 = v_4294953769;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294953768) == CID_SNIL)) {
if ((term_aux(v_4294953767) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294953767, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294953766 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294953765 = fields[1];
Term v_4294953764 = v_4294953766;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953763 = v_4294953765;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294953764;
r1 = v_4294953763;
WL_JMP(FID_36_100_105_114_101_99_116_46_102_108_117_115_104_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953767;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_51_53_;
WL_PUSHN(2);
} else {
u64 task_13536 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_51_53_, WL_CONT, WL_IDX, 1);
e.mem[task_13536 + 0] = v_4294953767;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_51_53_, task_13536);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
Term v_4294953759 = v_4294953768;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953758 = v_4294953767;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294953759) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294953759, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294953757 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294953756 = fields[1];
Term v_4294953755 = v_4294953757;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953754 = v_4294953756;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953753 = v_4294953758;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294953752 = v_4294953755;
if ((term_aux(v_4294953753) == CID_TUPLE)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294953753, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_0
u32
#else
Term
#endif
v_4294953751 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_TUPLE_1
u32
#else
Term
#endif
v_4294953750 = fields[1];
Term v_4294953749 = v_4294953754;
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953749;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_52_56_;
WL_PUSHN(2);
} else {
u64 task_13552 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_52_56_, WL_CONT, WL_IDX, 1);
e.mem[task_13552 + 0] = v_4294953749;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_52_56_, task_13552);
WL_IDX = 1;
}
Term v_4294953746 = v_4294953751;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953745 = v_4294953752;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294953744 = v_4294953750;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294953746;
r1 = v_4294953745;
r2 = v_4294953744;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_116_101_112_);
} else {
term_sink(e, v_4294953754);
term_sink(e, v_4294953752);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953753;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_53_52_;
WL_PUSHN(2);
} else {
u64 task_13555 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_53_52_, WL_CONT, WL_IDX, 1);
e.mem[task_13555 + 0] = v_4294953753;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_53_52_, task_13555);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953753;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_53_55_;
WL_PUSHN(2);
} else {
u64 task_13564 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_53_55_, WL_CONT, WL_IDX, 1);
e.mem[task_13564 + 0] = v_4294953753;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_53_55_, task_13564);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953754;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_54_48_;
WL_PUSHN(2);
} else {
u64 task_13564 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_54_48_, WL_CONT, WL_IDX, 1);
e.mem[task_13564 + 0] = v_4294953754;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_48_, task_13564);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953755;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_54_51_;
WL_PUSHN(2);
} else {
u64 task_13564 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_54_51_, WL_CONT, WL_IDX, 1);
e.mem[task_13564 + 0] = v_4294953755;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_51_, task_13564);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953758;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_54_54_;
WL_PUSHN(2);
} else {
u64 task_13570 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_54_54_, WL_CONT, WL_IDX, 1);
e.mem[task_13570 + 0] = v_4294953758;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_54_, task_13570);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294953759;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_51_53_54_57_;
WL_PUSHN(2);
} else {
u64 task_13570 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_51_53_54_57_, WL_CONT, WL_IDX, 1);
e.mem[task_13570 + 0] = v_4294953759;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_57_, task_13570);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_51_53_)
  {
    WL_POPN(1);
    Term v_4294953767 = STK(0);
    Term v_4294953762 = r0;
    WL_OPEN
Term v_4294953761 = v_4294953767;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953762; Term arg = v_4294953761;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_52_56_)
  {
    WL_POPN(1);
    Term v_4294953749 = STK(0);
    Term v_4294953748 = r0;
    WL_OPEN
r0 = v_4294953749;
r1 = v_4294953748;
WL_JMP(FID_36_100_105_114_101_99_116_46_108_101_120_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_53_52_)
  {
    WL_POPN(1);
    Term v_4294953753 = STK(0);
    Term v_4294953743 = r0;
    WL_OPEN
Term v_4294953742 = v_4294953753;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953743; Term arg = v_4294953742;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_53_55_)
  {
    WL_POPN(1);
    Term v_4294953753 = STK(0);
    Term v_4294953740 = r0;
    WL_OPEN
Term v_4294953739 = v_4294953753;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953740; Term arg = v_4294953739;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_48_)
  {
    WL_POPN(1);
    Term v_4294953754 = STK(0);
    Term v_4294953737 = r0;
    WL_OPEN
Term v_4294953736 = v_4294953754;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953737; Term arg = v_4294953736;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_51_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294953755 = STK(0);
    Term v_4294953734 = r0;
    WL_OPEN
Term v_4294953733 = v_4294953755;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953734; Term arg = v_4294953733;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_54_)
  {
    WL_POPN(1);
    Term v_4294953758 = STK(0);
    Term v_4294953731 = r0;
    WL_OPEN
Term v_4294953730 = v_4294953758;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953731; Term arg = v_4294953730;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_51_53_54_57_)
  {
    WL_POPN(1);
    Term v_4294953759 = STK(0);
    Term v_4294953728 = r0;
    WL_OPEN
Term v_4294953727 = v_4294953759;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294953728; Term arg = v_4294953727;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_102_108_117_115_104_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_52_53_57_54_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_53_57_54_)
  {
    Term v_4294952701 = r0;
    WL_OPEN
u64 cl_14598 = heap_alloc(e, cls_fit(1));
e.mem[cl_14598 + 0] = v_4294952701;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_52_53_57_55_, cl_14598);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_53_57_55_)
  {
    Term v_4294952701 = r0;
    Term v_4294952700 = r1;
    WL_OPEN
r0 = v_4294952701;
r1 = v_4294952700;
WL_JMP(FID_36_100_105_114_101_99_116_46_102_108_117_115_104_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_102_108_117_115_104_)
  {
    Term v_4294952696 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294952695 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_102_108_117_115_104_(e, seq, nq_result, v_4294952696, v_4294952695)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294952694 = v_4294952696;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952693 = v_4294952695;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294952694) == CID__CTOR_71_97_112_)) {
r0 = v_4294952693;
WL_RETN(1);
} else {
Term v_4294952692 = v_4294952694;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952691 = v_4294952693;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294952692) == CID__CTOR_73_110_73_100_)) {
Term fields[1];
if (term_tag(v_4294952692) == TAG_PAK) { fields[0] = term_loc(v_4294952692); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294952692, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_73_100__0
u32
#else
Term
#endif
v_4294952690 = fields[0];
Term v_4294952689 = v_4294952691;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952688 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952687 = v_4294952690;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294952689;
r1 = v_4294952688;
r2 = v_4294952687;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
Term v_4294952686 = v_4294952692;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952685 = v_4294952691;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294952686) == CID__CTOR_73_110_78_109_)) {
Term fields[1];
if (term_tag(v_4294952686) == TAG_PAK) { fields[0] = term_loc(v_4294952686); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294952686, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_78_109__0
u32
#else
Term
#endif
v_4294952684 = fields[0];
Term v_4294952683 = v_4294952685;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952682 = 2ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294952681 = v_4294952684;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294952683;
r1 = v_4294952682;
r2 = v_4294952681;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294952685;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_52_54_49_55_;
WL_PUSHN(2);
} else {
u64 task_14621 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_52_54_49_55_, WL_CONT, WL_IDX, 1);
e.mem[task_14621 + 0] = v_4294952685;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_52_54_49_55_, task_14621);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294952686;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_52_54_50_48_;
WL_PUSHN(2);
} else {
u64 task_14621 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_52_54_50_48_, WL_CONT, WL_IDX, 1);
e.mem[task_14621 + 0] = v_4294952686;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_52_54_50_48_, task_14621);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_54_49_55_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294952685 = STK(0);
    Term v_4294952680 = r0;
    WL_OPEN
Term v_4294952679 = v_4294952685;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294952680; Term arg = v_4294952679;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_52_54_50_48_)
  {
    WL_POPN(1);
    Term v_4294952686 = STK(0);
    Term v_4294952677 = r0;
    WL_OPEN
Term v_4294952676 = v_4294952686;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294952677; Term arg = v_4294952676;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_109_105_120_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_53_54_52_56_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_53_54_52_56_)
  {
    Term v_4294951650 = r0;
    WL_OPEN
u64 cl_15652 = heap_alloc(e, cls_fit(1));
e.mem[cl_15652 + 0] = v_4294951650;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_53_54_52_57_, cl_15652);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_53_54_52_57_)
  {
    Term v_4294951650 = r0;
    Term v_4294951649 = r1;
    WL_OPEN
u64 cl_15651 = heap_alloc(e, cls_fit(2));
e.mem[cl_15651 + 0] = v_4294951650;
e.mem[cl_15651 + 1] = v_4294951649;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_53_54_53_48_, cl_15651);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_53_54_53_48_)
  {
    Term v_4294951650 = r0;
    Term v_4294951649 = r1;
    Term v_4294951648 = r2;
    WL_OPEN
r0 = v_4294951650;
r1 = v_4294951649;
r2 = v_4294951648;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_109_105_120_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294951642 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294951641 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294951640 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_109_105_120_(e, seq, nq_result, v_4294951642, v_4294951641, v_4294951640)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294951637 = v_4294951642;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951636 = 2654435761ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951639 = U32_BIN(v_4294951637, *, v_4294951636);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951633 = v_4294951641;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951632 = 40503ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951635 = U32_BIN(v_4294951633, *, v_4294951632);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951634 = v_4294951640;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294951638 = U32_BIN(v_4294951635, +, v_4294951634);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294951639, ^, v_4294951638);
WL_RETN(1);
#endif

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_120_111_114_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_54_54_56_56_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_54_56_56_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_16690 = heap_alloc(e, cls_fit(1));
e.mem[cl_16690 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_54_54_56_57_, cl_16690);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_54_54_56_57_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, ^, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_120_111_114_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294950604 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294950603 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294950604, ^, v_4294950603);
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_109_117_108_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_55_55_49_55_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_55_49_55_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_17719 = heap_alloc(e, cls_fit(1));
e.mem[cl_17719 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_55_55_49_56_, cl_17719);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_55_55_49_56_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, *, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_109_117_108_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294949575 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294949574 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294949575, *, v_4294949574);
WL_RETN(1);

  }}

  WL_CASE(FID_115_116_101_112_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_56_55_52_57_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_56_55_52_57_)
  {
    Term v_4294948549 = r0;
    WL_OPEN
u64 cl_18753 = heap_alloc(e, cls_fit(1));
e.mem[cl_18753 + 0] = v_4294948549;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_56_55_53_48_, cl_18753);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_56_55_53_48_)
  {
    Term v_4294948549 = r0;
    Term v_4294948548 = r1;
    WL_OPEN
u64 cl_18752 = heap_alloc(e, cls_fit(2));
e.mem[cl_18752 + 0] = v_4294948549;
e.mem[cl_18752 + 1] = v_4294948548;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_56_55_53_49_, cl_18752);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_56_55_53_49_)
  {
    Term v_4294948549 = r0;
    Term v_4294948548 = r1;
    Term v_4294948547 = r2;
    WL_OPEN
r0 = v_4294948549;
r1 = v_4294948548;
r2 = v_4294948547;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_116_101_112_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_115_116_101_112_)
  {
    Term v_4294948541 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294948540 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294948539 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_115_116_101_112_(e, seq, nq_result, v_4294948541, v_4294948540, v_4294948539)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294948538 = v_4294948541;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294948540 = term_keep(e, v_4294948540);
if (seq) {
WL_ROOM(4);
STK(0) = v_4294948540;
STK(1) = v_4294948539;
STK(2) = v_4294948538;
STK(3) = FID_110_97_116_105_118_101_95_107_95_49_56_55_54_49_;
WL_PUSHN(4);
} else {
u64 task_18763 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_56_55_54_49_, WL_CONT, WL_IDX, 1);
e.mem[task_18763 + 0] = v_4294948540;
e.mem[task_18763 + 1] = v_4294948539;
e.mem[task_18763 + 2] = v_4294948538;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_56_55_54_49_, task_18763);
WL_IDX = 3;
}
Term v_4294948533 = v_4294948540;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294948533;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_115_);
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_56_55_54_49_)
  {
    WL_POPN(3);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294948540 = STK(0);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294948539 = STK(1);
    Term v_4294948538 = STK(2);
    Term v_4294948537 = r0;
    WL_OPEN
Term v_4294948536 = v_4294948540;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294948535 = v_4294948539;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294948538;
r1 = v_4294948537;
r2 = v_4294948536;
r3 = v_4294948535;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_116_101_112_46_97_116_);

  }}

  WL_CASE(FID_115_116_101_112_46_97_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_49_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_49_)
  {
    Term v_4294947508 = r0;
    WL_OPEN
u64 cl_19797 = heap_alloc(e, cls_fit(1));
e.mem[cl_19797 + 0] = v_4294947508;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_50_, cl_19797);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_50_)
  {
    Term v_4294947508 = r0;
    Term v_4294947507 = r1;
    WL_OPEN
u64 cl_19796 = heap_alloc(e, cls_fit(2));
e.mem[cl_19796 + 0] = v_4294947508;
e.mem[cl_19796 + 1] = v_4294947507;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_51_, cl_19796);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_51_)
  {
    Term v_4294947508 = r0;
    Term v_4294947507 = r1;
    Term v_4294947506 = r2;
    WL_OPEN
u64 cl_19795 = heap_alloc(e, cls_fit(3));
e.mem[cl_19795 + 0] = v_4294947508;
e.mem[cl_19795 + 1] = v_4294947507;
e.mem[cl_19795 + 2] = v_4294947506;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_52_, cl_19795);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_55_57_52_)
  {
    Term v_4294947508 = r0;
    Term v_4294947507 = r1;
    Term v_4294947506 = r2;
    Term v_4294947505 = r3;
    WL_OPEN
r0 = v_4294947508;
r1 = v_4294947507;
r2 = v_4294947506;
r3 = v_4294947505;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_116_101_112_46_97_116_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_115_116_101_112_46_97_116_)
  {
    Term v_4294947497 = r0;
    Term v_4294947496 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947495 = r2;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947494 = r3;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_115_116_101_112_46_97_116_(e, seq, nq_result, v_4294947497, v_4294947496, v_4294947495, v_4294947494)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294947493 = v_4294947497;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947492 = v_4294947496;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947491 = v_4294947495;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947490 = v_4294947494;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947493) == CID__CTOR_71_97_112_)) {
Term v_4294947489 = v_4294947492;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947488 = v_4294947491;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947487 = v_4294947490;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947489) == CID__CTOR_76_101_116_116_101_114_)) {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947487;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_49_50_;
WL_PUSHN(2);
} else {
u64 task_19817 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_49_50_, WL_CONT, WL_IDX, 1);
e.mem[task_19817 + 0] = v_4294947487;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_49_50_, task_19817);
WL_IDX = 1;
}
Term v_4294947480 = 2166136261ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947479 = v_4294947488;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947480;
r1 = v_4294947479;
WL_JMP(FID_36_100_105_114_101_99_116_46_102_110_118_);
} else {
Term v_4294947478 = v_4294947489;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947477 = v_4294947488;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947476 = v_4294947487;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947478) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294947472 = v_4294947477;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947471 = 48ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947473 = U32_BIN(v_4294947472, -, v_4294947471);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947475;
{
Term pf_19825 = v_4294947473;
Term pk_19825;
#if NATIVE_PACK_CTORS
if ((pf_19825 & ~LOC_MASK) == 0) {
pk_19825 = term_pak(CID__CTOR_73_110_78_109_, pf_19825);
} else
#endif
{
u64 nd_19825 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_19825 + 0] = pf_19825;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_19825 + 0] = pf_19825;
#else
e.mem[nd_19825 + 0] = rfc_seal(e, pf_19825);
#endif
#endif
pk_19825 = term_ctr(CID__CTOR_73_110_78_109_, nd_19825);
}
v_4294947475 = pk_19825;
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947474 = v_4294947476;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_19826 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19826 + 0] = v_4294947475;
e.mem[nd_19826 + 1] = v_4294947474;
#else
e.mem[nd_19826 + 0] = rfc_seal(e, v_4294947475);
e.mem[nd_19826 + 1] = rfc_seal(e, v_4294947474);
#endif
r0 = term_ctr(CID_TUPLE, nd_19826);
WL_RETN(1);
} else {
Term v_4294947468 = v_4294947478;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947467 = v_4294947477;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947466 = v_4294947476;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947468) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294947467);
Term v_4294947465 = term_pak(CID__CTOR_71_97_112_, 0);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947464 = v_4294947466;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_19832 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19832 + 0] = v_4294947465;
e.mem[nd_19832 + 1] = v_4294947464;
#else
e.mem[nd_19832 + 0] = rfc_seal(e, v_4294947465);
e.mem[nd_19832 + 1] = rfc_seal(e, v_4294947464);
#endif
r0 = term_ctr(CID_TUPLE, nd_19832);
WL_RETN(1);
} else {
Term v_4294947462 = v_4294947468;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947461 = v_4294947467;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947460 = v_4294947466;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947462) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294947459 = term_pak(CID__CTOR_71_97_112_, 0);
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947459;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_51_56_;
WL_PUSHN(2);
} else {
u64 task_19843 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_51_56_, WL_CONT, WL_IDX, 1);
e.mem[task_19843 + 0] = v_4294947459;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_51_56_, task_19843);
WL_IDX = 1;
}
Term v_4294947455 = v_4294947460;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947454 = 3ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947453 = v_4294947461;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947455;
r1 = v_4294947454;
r2 = v_4294947453;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947460;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_52_53_;
WL_PUSHN(2);
} else {
u64 task_19852 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_52_53_, WL_CONT, WL_IDX, 1);
e.mem[task_19852 + 0] = v_4294947460;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_52_53_, task_19852);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947461;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_52_56_;
WL_PUSHN(2);
} else {
u64 task_19852 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_52_56_, WL_CONT, WL_IDX, 1);
e.mem[task_19852 + 0] = v_4294947461;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_52_56_, task_19852);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947462;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_53_49_;
WL_PUSHN(2);
} else {
u64 task_19852 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_53_49_, WL_CONT, WL_IDX, 1);
e.mem[task_19852 + 0] = v_4294947462;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_53_49_, task_19852);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
Term v_4294947443 = v_4294947493;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947442 = v_4294947492;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947441 = v_4294947491;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947440 = v_4294947490;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947443) == CID__CTOR_73_110_73_100_)) {
Term fields[1];
if (term_tag(v_4294947443) == TAG_PAK) { fields[0] = term_loc(v_4294947443); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294947443, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_73_100__0
u32
#else
Term
#endif
v_4294947439 = fields[0];
Term v_4294947438 = v_4294947442;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947437 = v_4294947441;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947436 = v_4294947440;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947438) == CID__CTOR_76_101_116_116_101_114_)) {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947436;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_54_51_;
WL_PUSHN(2);
} else {
u64 task_19868 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_54_51_, WL_CONT, WL_IDX, 1);
e.mem[task_19868 + 0] = v_4294947436;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_54_51_, task_19868);
WL_IDX = 1;
}
Term v_4294947429 = v_4294947439;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947428 = v_4294947437;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947429;
r1 = v_4294947428;
WL_JMP(FID_36_100_105_114_101_99_116_46_102_110_118_);
} else {
Term v_4294947427 = v_4294947438;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947426 = v_4294947437;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947425 = v_4294947436;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947427) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294947421 = v_4294947426;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947420 = 48ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947422 = U32_BIN(v_4294947421, -, v_4294947420);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947424;
{
Term pf_19876 = v_4294947422;
Term pk_19876;
#if NATIVE_PACK_CTORS
if ((pf_19876 & ~LOC_MASK) == 0) {
pk_19876 = term_pak(CID__CTOR_73_110_78_109_, pf_19876);
} else
#endif
{
u64 nd_19876 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_19876 + 0] = pf_19876;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_19876 + 0] = pf_19876;
#else
e.mem[nd_19876 + 0] = rfc_seal(e, pf_19876);
#endif
#endif
pk_19876 = term_ctr(CID__CTOR_73_110_78_109_, nd_19876);
}
v_4294947424 = pk_19876;
}
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947424;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_55_55_;
WL_PUSHN(2);
} else {
u64 task_19882 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_55_55_, WL_CONT, WL_IDX, 1);
e.mem[task_19882 + 0] = v_4294947424;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_55_55_, task_19882);
WL_IDX = 1;
}
Term v_4294947416 = v_4294947425;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947415 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947414 = v_4294947439;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947416;
r1 = v_4294947415;
r2 = v_4294947414;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
Term v_4294947413 = v_4294947427;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947412 = v_4294947426;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947411 = v_4294947425;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947413) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294947412);
Term v_4294947410 = term_pak(CID__CTOR_71_97_112_, 0);
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947410;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_56_55_;
WL_PUSHN(2);
} else {
u64 task_19892 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_56_55_, WL_CONT, WL_IDX, 1);
e.mem[task_19892 + 0] = v_4294947410;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_56_55_, task_19892);
WL_IDX = 1;
}
Term v_4294947406 = v_4294947411;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947405 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947404 = v_4294947439;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947406;
r1 = v_4294947405;
r2 = v_4294947404;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
Term v_4294947403 = v_4294947413;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947402 = v_4294947412;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947401 = v_4294947411;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947403) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294947400 = term_pak(CID__CTOR_71_97_112_, 0);
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947400;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_56_57_55_;
WL_PUSHN(2);
} else {
u64 task_19906 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_56_57_55_, WL_CONT, WL_IDX, 1);
e.mem[task_19906 + 0] = v_4294947400;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_56_57_55_, task_19906);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947402;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_48_50_;
WL_PUSHN(2);
} else {
u64 task_19906 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_48_50_, WL_CONT, WL_IDX, 1);
e.mem[task_19906 + 0] = v_4294947402;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_48_50_, task_19906);
WL_IDX = 1;
}
Term v_4294947392 = v_4294947401;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947391 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947390 = v_4294947439;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947392;
r1 = v_4294947391;
r2 = v_4294947390;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
term_sink(e, v_4294947439);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947401;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_48_56_;
WL_PUSHN(2);
} else {
u64 task_19915 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_48_56_, WL_CONT, WL_IDX, 1);
e.mem[task_19915 + 0] = v_4294947401;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_48_56_, task_19915);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947402;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_49_49_;
WL_PUSHN(2);
} else {
u64 task_19915 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_49_49_, WL_CONT, WL_IDX, 1);
e.mem[task_19915 + 0] = v_4294947402;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_49_49_, task_19915);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947403;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_49_52_;
WL_PUSHN(2);
} else {
u64 task_19915 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_49_52_, WL_CONT, WL_IDX, 1);
e.mem[task_19915 + 0] = v_4294947403;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_49_52_, task_19915);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
Term v_4294947380 = v_4294947443;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947379 = v_4294947442;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947378 = v_4294947441;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947377 = v_4294947440;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947380) == CID__CTOR_73_110_78_109_)) {
Term fields[1];
if (term_tag(v_4294947380) == TAG_PAK) { fields[0] = term_loc(v_4294947380); } else {
spare_free(e, cls_fit(1), ctr_take(e, v_4294947380, 1, fields));
}
#if !DEVICE && NATIVE_FIELD32_CID__CTOR_73_110_78_109__0
u32
#else
Term
#endif
v_4294947376 = fields[0];
Term v_4294947375 = v_4294947379;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947374 = v_4294947378;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947373 = v_4294947377;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947375) == CID__CTOR_76_101_116_116_101_114_)) {
if (seq) {
WL_ROOM(3);
STK(0) = v_4294947376;
STK(1) = v_4294947373;
STK(2) = FID_110_97_116_105_118_101_95_107_95_49_57_57_50_54_;
WL_PUSHN(3);
} else {
u64 task_19935 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_50_54_, WL_CONT, WL_IDX, 1);
e.mem[task_19935 + 0] = v_4294947376;
e.mem[task_19935 + 1] = v_4294947373;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_50_54_, task_19935);
WL_IDX = 2;
}
Term v_4294947362 = 2166136261ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947361 = v_4294947374;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947362;
r1 = v_4294947361;
WL_JMP(FID_36_100_105_114_101_99_116_46_102_110_118_);
} else {
Term v_4294947360 = v_4294947375;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947359 = v_4294947374;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947358 = v_4294947373;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947360) == CID__CTOR_68_105_103_105_116_)) {
Term v_4294947352 = v_4294947376;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947351 = 10ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947354 = U32_BIN(v_4294947352, *, v_4294947351);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947350 = v_4294947359;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947349 = 48ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947353 = U32_BIN(v_4294947350, -, v_4294947349);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947355 = U32_BIN(v_4294947354, +, v_4294947353);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947357;
{
Term pf_19947 = v_4294947355;
Term pk_19947;
#if NATIVE_PACK_CTORS
if ((pf_19947 & ~LOC_MASK) == 0) {
pk_19947 = term_pak(CID__CTOR_73_110_78_109_, pf_19947);
} else
#endif
{
u64 nd_19947 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_78_109_
e.mem[nd_19947 + 0] = pf_19947;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_19947 + 0] = pf_19947;
#else
e.mem[nd_19947 + 0] = rfc_seal(e, pf_19947);
#endif
#endif
pk_19947 = term_ctr(CID__CTOR_73_110_78_109_, nd_19947);
}
v_4294947357 = pk_19947;
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947356 = v_4294947358;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_19948 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19948 + 0] = v_4294947357;
e.mem[nd_19948 + 1] = v_4294947356;
#else
e.mem[nd_19948 + 0] = rfc_seal(e, v_4294947357);
e.mem[nd_19948 + 1] = rfc_seal(e, v_4294947356);
#endif
r0 = term_ctr(CID_TUPLE, nd_19948);
WL_RETN(1);
} else {
Term v_4294947346 = v_4294947360;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947345 = v_4294947359;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947344 = v_4294947358;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947346) == CID__CTOR_83_112_97_99_101_)) {
term_sink(e, v_4294947345);
Term v_4294947343 = term_pak(CID__CTOR_71_97_112_, 0);
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947343;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_53_52_;
WL_PUSHN(2);
} else {
u64 task_19959 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_53_52_, WL_CONT, WL_IDX, 1);
e.mem[task_19959 + 0] = v_4294947343;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_53_52_, task_19959);
WL_IDX = 1;
}
Term v_4294947339 = v_4294947344;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947338 = 2ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947337 = v_4294947376;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947339;
r1 = v_4294947338;
r2 = v_4294947337;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
Term v_4294947336 = v_4294947346;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947335 = v_4294947345;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947334 = v_4294947344;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294947336) == CID__CTOR_80_117_110_99_116_)) {
Term v_4294947333 = term_pak(CID__CTOR_71_97_112_, 0);
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947333;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_54_52_;
WL_PUSHN(2);
} else {
u64 task_19973 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_54_52_, WL_CONT, WL_IDX, 1);
e.mem[task_19973 + 0] = v_4294947333;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_54_52_, task_19973);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947335;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_54_57_;
WL_PUSHN(2);
} else {
u64 task_19973 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_54_57_, WL_CONT, WL_IDX, 1);
e.mem[task_19973 + 0] = v_4294947335;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_54_57_, task_19973);
WL_IDX = 1;
}
Term v_4294947325 = v_4294947334;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947324 = 2ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947323 = v_4294947376;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947325;
r1 = v_4294947324;
r2 = v_4294947323;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);
} else {
term_sink(e, v_4294947376);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947334;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_55_53_;
WL_PUSHN(2);
} else {
u64 task_19982 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_55_53_, WL_CONT, WL_IDX, 1);
e.mem[task_19982 + 0] = v_4294947334;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_55_53_, task_19982);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947335;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_55_56_;
WL_PUSHN(2);
} else {
u64 task_19982 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_55_56_, WL_CONT, WL_IDX, 1);
e.mem[task_19982 + 0] = v_4294947335;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_55_56_, task_19982);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947336;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_56_49_;
WL_PUSHN(2);
} else {
u64 task_19982 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_56_49_, WL_CONT, WL_IDX, 1);
e.mem[task_19982 + 0] = v_4294947336;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_49_, task_19982);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947377;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_56_52_;
WL_PUSHN(2);
} else {
u64 task_19994 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_56_52_, WL_CONT, WL_IDX, 1);
e.mem[task_19994 + 0] = v_4294947377;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_52_, task_19994);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947378;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_56_55_;
WL_PUSHN(2);
} else {
u64 task_19994 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_56_55_, WL_CONT, WL_IDX, 1);
e.mem[task_19994 + 0] = v_4294947378;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_55_, task_19994);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947379;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_57_48_;
WL_PUSHN(2);
} else {
u64 task_19994 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_57_48_, WL_CONT, WL_IDX, 1);
e.mem[task_19994 + 0] = v_4294947379;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_57_48_, task_19994);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947380;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_57_51_;
WL_PUSHN(2);
} else {
u64 task_19994 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_57_51_, WL_CONT, WL_IDX, 1);
e.mem[task_19994 + 0] = v_4294947380;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_57_51_, task_19994);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_49_50_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947487 = STK(0);
    Term v_4294947484 = r0;
    WL_OPEN
Term v_4294947486;
{
Term pf_19813 = v_4294947484;
Term pk_19813;
#if NATIVE_PACK_CTORS
if ((pf_19813 & ~LOC_MASK) == 0) {
pk_19813 = term_pak(CID__CTOR_73_110_73_100_, pf_19813);
} else
#endif
{
u64 nd_19813 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_19813 + 0] = pf_19813;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_19813 + 0] = pf_19813;
#else
e.mem[nd_19813 + 0] = rfc_seal(e, pf_19813);
#endif
#endif
pk_19813 = term_ctr(CID__CTOR_73_110_73_100_, nd_19813);
}
v_4294947486 = pk_19813;
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947485 = v_4294947487;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_19814 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19814 + 0] = v_4294947486;
e.mem[nd_19814 + 1] = v_4294947485;
#else
e.mem[nd_19814 + 0] = rfc_seal(e, v_4294947486);
e.mem[nd_19814 + 1] = rfc_seal(e, v_4294947485);
#endif
r0 = term_ctr(CID_TUPLE, nd_19814);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_51_56_)
  {
    WL_POPN(1);
    Term v_4294947459 = STK(0);
    Term v_4294947458 = r0;
    WL_OPEN
u64 nd_19839 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19839 + 0] = v_4294947459;
e.mem[nd_19839 + 1] = v_4294947458;
#else
e.mem[nd_19839 + 0] = rfc_seal(e, v_4294947459);
e.mem[nd_19839 + 1] = rfc_seal(e, v_4294947458);
#endif
r0 = term_ctr(CID_TUPLE, nd_19839);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_52_53_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947460 = STK(0);
    Term v_4294947452 = r0;
    WL_OPEN
Term v_4294947451 = v_4294947460;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947452; Term arg = v_4294947451;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_52_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947461 = STK(0);
    Term v_4294947449 = r0;
    WL_OPEN
Term v_4294947448 = v_4294947461;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947449; Term arg = v_4294947448;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_53_49_)
  {
    WL_POPN(1);
    Term v_4294947462 = STK(0);
    Term v_4294947446 = r0;
    WL_OPEN
Term v_4294947445 = v_4294947462;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947446; Term arg = v_4294947445;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_54_51_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947436 = STK(0);
    Term v_4294947433 = r0;
    WL_OPEN
Term v_4294947435;
{
Term pf_19864 = v_4294947433;
Term pk_19864;
#if NATIVE_PACK_CTORS
if ((pf_19864 & ~LOC_MASK) == 0) {
pk_19864 = term_pak(CID__CTOR_73_110_73_100_, pf_19864);
} else
#endif
{
u64 nd_19864 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_19864 + 0] = pf_19864;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_19864 + 0] = pf_19864;
#else
e.mem[nd_19864 + 0] = rfc_seal(e, pf_19864);
#endif
#endif
pk_19864 = term_ctr(CID__CTOR_73_110_73_100_, nd_19864);
}
v_4294947435 = pk_19864;
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947434 = v_4294947436;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_19865 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19865 + 0] = v_4294947435;
e.mem[nd_19865 + 1] = v_4294947434;
#else
e.mem[nd_19865 + 0] = rfc_seal(e, v_4294947435);
e.mem[nd_19865 + 1] = rfc_seal(e, v_4294947434);
#endif
r0 = term_ctr(CID_TUPLE, nd_19865);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_55_55_)
  {
    WL_POPN(1);
    Term v_4294947424 = STK(0);
    Term v_4294947423 = r0;
    WL_OPEN
u64 nd_19878 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19878 + 0] = v_4294947424;
e.mem[nd_19878 + 1] = v_4294947423;
#else
e.mem[nd_19878 + 0] = rfc_seal(e, v_4294947424);
e.mem[nd_19878 + 1] = rfc_seal(e, v_4294947423);
#endif
r0 = term_ctr(CID_TUPLE, nd_19878);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_56_55_)
  {
    WL_POPN(1);
    Term v_4294947410 = STK(0);
    Term v_4294947409 = r0;
    WL_OPEN
u64 nd_19888 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19888 + 0] = v_4294947410;
e.mem[nd_19888 + 1] = v_4294947409;
#else
e.mem[nd_19888 + 0] = rfc_seal(e, v_4294947410);
e.mem[nd_19888 + 1] = rfc_seal(e, v_4294947409);
#endif
r0 = term_ctr(CID_TUPLE, nd_19888);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_56_57_55_)
  {
    WL_POPN(1);
    Term v_4294947400 = STK(0);
    Term v_4294947399 = r0;
    WL_OPEN
u64 nd_19898 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19898 + 0] = v_4294947400;
e.mem[nd_19898 + 1] = v_4294947399;
#else
e.mem[nd_19898 + 0] = rfc_seal(e, v_4294947400);
e.mem[nd_19898 + 1] = rfc_seal(e, v_4294947399);
#endif
r0 = term_ctr(CID_TUPLE, nd_19898);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_48_50_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947402 = STK(0);
    Term v_4294947396 = r0;
    WL_OPEN
Term v_4294947395 = 3ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947394 = v_4294947402;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947396;
r1 = v_4294947395;
r2 = v_4294947394;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_48_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947401 = STK(0);
    Term v_4294947389 = r0;
    WL_OPEN
Term v_4294947388 = v_4294947401;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947389; Term arg = v_4294947388;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_49_49_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947402 = STK(0);
    Term v_4294947386 = r0;
    WL_OPEN
Term v_4294947385 = v_4294947402;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947386; Term arg = v_4294947385;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_49_52_)
  {
    WL_POPN(1);
    Term v_4294947403 = STK(0);
    Term v_4294947383 = r0;
    WL_OPEN
Term v_4294947382 = v_4294947403;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947383; Term arg = v_4294947382;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_50_54_)
  {
    WL_POPN(2);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947376 = STK(0);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947373 = STK(1);
    Term v_4294947370 = r0;
    WL_OPEN
Term v_4294947372;
{
Term pf_19927 = v_4294947370;
Term pk_19927;
#if NATIVE_PACK_CTORS
if ((pf_19927 & ~LOC_MASK) == 0) {
pk_19927 = term_pak(CID__CTOR_73_110_73_100_, pf_19927);
} else
#endif
{
u64 nd_19927 = heap_alloc(e, cls_fit(1));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID__CTOR_73_110_73_100_
e.mem[nd_19927 + 0] = pf_19927;
#else
#if NATIVE_COLD_USER_CTORS
e.mem[nd_19927 + 0] = pf_19927;
#else
e.mem[nd_19927 + 0] = rfc_seal(e, pf_19927);
#endif
#endif
pk_19927 = term_ctr(CID__CTOR_73_110_73_100_, nd_19927);
}
v_4294947372 = pk_19927;
}
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294947372;
STK(1) = FID_110_97_116_105_118_101_95_107_95_49_57_57_50_56_;
WL_PUSHN(2);
} else {
u64 task_19933 = task_node(e, FID_110_97_116_105_118_101_95_107_95_49_57_57_50_56_, WL_CONT, WL_IDX, 1);
e.mem[task_19933 + 0] = v_4294947372;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_49_57_57_50_56_, task_19933);
WL_IDX = 1;
}
Term v_4294947365 = v_4294947373;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947364 = 2ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947363 = v_4294947376;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947365;
r1 = v_4294947364;
r2 = v_4294947363;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_50_56_)
  {
    WL_POPN(1);
    Term v_4294947372 = STK(0);
    Term v_4294947371 = r0;
    WL_OPEN
u64 nd_19929 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19929 + 0] = v_4294947372;
e.mem[nd_19929 + 1] = v_4294947371;
#else
e.mem[nd_19929 + 0] = rfc_seal(e, v_4294947372);
e.mem[nd_19929 + 1] = rfc_seal(e, v_4294947371);
#endif
r0 = term_ctr(CID_TUPLE, nd_19929);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_53_52_)
  {
    WL_POPN(1);
    Term v_4294947343 = STK(0);
    Term v_4294947342 = r0;
    WL_OPEN
u64 nd_19955 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19955 + 0] = v_4294947343;
e.mem[nd_19955 + 1] = v_4294947342;
#else
e.mem[nd_19955 + 0] = rfc_seal(e, v_4294947343);
e.mem[nd_19955 + 1] = rfc_seal(e, v_4294947342);
#endif
r0 = term_ctr(CID_TUPLE, nd_19955);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_54_52_)
  {
    WL_POPN(1);
    Term v_4294947333 = STK(0);
    Term v_4294947332 = r0;
    WL_OPEN
u64 nd_19965 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_TUPLE
e.mem[nd_19965 + 0] = v_4294947333;
e.mem[nd_19965 + 1] = v_4294947332;
#else
e.mem[nd_19965 + 0] = rfc_seal(e, v_4294947333);
e.mem[nd_19965 + 1] = rfc_seal(e, v_4294947332);
#endif
r0 = term_ctr(CID_TUPLE, nd_19965);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_54_57_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947335 = STK(0);
    Term v_4294947329 = r0;
    WL_OPEN
Term v_4294947328 = 3ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294947327 = v_4294947335;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294947329;
r1 = v_4294947328;
r2 = v_4294947327;
WL_JMP(FID_36_100_105_114_101_99_116_46_109_105_120_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_55_53_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947334 = STK(0);
    Term v_4294947322 = r0;
    WL_OPEN
Term v_4294947321 = v_4294947334;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947322; Term arg = v_4294947321;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_55_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947335 = STK(0);
    Term v_4294947319 = r0;
    WL_OPEN
Term v_4294947318 = v_4294947335;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947319; Term arg = v_4294947318;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_49_)
  {
    WL_POPN(1);
    Term v_4294947336 = STK(0);
    Term v_4294947316 = r0;
    WL_OPEN
Term v_4294947315 = v_4294947336;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947316; Term arg = v_4294947315;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_52_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947377 = STK(0);
    Term v_4294947313 = r0;
    WL_OPEN
Term v_4294947312 = v_4294947377;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947313; Term arg = v_4294947312;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_56_55_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294947378 = STK(0);
    Term v_4294947310 = r0;
    WL_OPEN
Term v_4294947309 = v_4294947378;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947310; Term arg = v_4294947309;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_57_48_)
  {
    WL_POPN(1);
    Term v_4294947379 = STK(0);
    Term v_4294947307 = r0;
    WL_OPEN
Term v_4294947306 = v_4294947379;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947307; Term arg = v_4294947306;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_49_57_57_57_51_)
  {
    WL_POPN(1);
    Term v_4294947380 = STK(0);
    Term v_4294947304 = r0;
    WL_OPEN
Term v_4294947303 = v_4294947380;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294947304; Term arg = v_4294947303;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_102_110_118_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_49_48_50_48_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_49_48_50_48_)
  {
    Term v_4294946277 = r0;
    WL_OPEN
u64 cl_21022 = heap_alloc(e, cls_fit(1));
e.mem[cl_21022 + 0] = v_4294946277;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_49_48_50_49_, cl_21022);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_49_48_50_49_)
  {
    Term v_4294946277 = r0;
    Term v_4294946276 = r1;
    WL_OPEN
r0 = v_4294946277;
r1 = v_4294946276;
WL_JMP(FID_36_100_105_114_101_99_116_46_102_110_118_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_102_110_118_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294946272 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294946271 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_102_110_118_(e, seq, nq_result, v_4294946272, v_4294946271)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294946268 = v_4294946272;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294946267 = v_4294946271;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294946270 = U32_BIN(v_4294946268, ^, v_4294946267);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294946269 = 16777619ull;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294946270, *, v_4294946269);
WL_RETN(1);
#endif

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_115_117_98_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_51_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_51_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_22055 = heap_alloc(e, cls_fit(1));
e.mem[cl_22055 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_, cl_22055);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_50_48_53_52_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, -, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_117_98_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294945239 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294945238 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294945239, -, v_4294945238);
WL_RETN(1);

  }}

  WL_CASE(FID_99_108_115_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_51_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_51_)
  {
    Term v_4294944213 = r0;
    WL_OPEN
r0 = v_4294944213;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_115_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_115_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294944211 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_99_108_115_(e, seq, nq_result, v_4294944211)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
v_4294944211 = term_keep(e, v_4294944211);
if (seq) {
WL_ROOM(2);
STK(0) = v_4294944211;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_51_48_56_56_;
WL_PUSHN(2);
} else {
u64 task_23104 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_51_48_56_56_, WL_CONT, WL_IDX, 1);
e.mem[task_23104 + 0] = v_4294944211;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_56_, task_23104);
WL_IDX = 1;
}
Term v_4294944195 = 97ull;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294944211 = term_keep(e, v_4294944211);
Term v_4294944194 = v_4294944211;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944197 = U32_BIN(v_4294944195, <=, v_4294944194);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944193 = v_4294944211;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944192 = 122ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944196 = U32_BIN(v_4294944193, <=, v_4294944192);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294944197;
r1 = v_4294944196;
WL_JMP(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_);
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294944211 = STK(0);
    Term v_4294944210 = r0;
    WL_OPEN
v_4294944211 = term_keep(e, v_4294944211);
if (seq) {
WL_ROOM(3);
STK(0) = v_4294944211;
STK(1) = v_4294944210;
STK(2) = FID_110_97_116_105_118_101_95_107_95_50_51_48_56_57_;
WL_PUSHN(3);
} else {
u64 task_23098 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_51_48_56_57_, WL_CONT, WL_IDX, 1);
e.mem[task_23098 + 0] = v_4294944211;
e.mem[task_23098 + 1] = v_4294944210;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_57_, task_23098);
WL_IDX = 2;
}
Term v_4294944201 = 48ull;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294944211 = term_keep(e, v_4294944211);
Term v_4294944200 = v_4294944211;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944203 = U32_BIN(v_4294944201, <=, v_4294944200);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944199 = v_4294944211;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944198 = 57ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944202 = U32_BIN(v_4294944199, <=, v_4294944198);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294944203;
r1 = v_4294944202;
WL_JMP(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_51_48_56_57_)
  {
    WL_POPN(2);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294944211 = STK(0);
    Term v_4294944210 = STK(1);
    Term v_4294944209 = r0;
    WL_OPEN
Term v_4294944205 = v_4294944211;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944204 = 32ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294944208 = U32_BIN(v_4294944205, ==, v_4294944204);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294944210;
r1 = v_4294944209;
r2 = v_4294944208;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_115_46_103_111_);

  }}

  WL_CASE(FID_99_108_115_46_103_111_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_49_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_49_)
  {
    Term v_4294943167 = r0;
    WL_OPEN
u64 cl_24135 = heap_alloc(e, cls_fit(1));
e.mem[cl_24135 + 0] = v_4294943167;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_50_, cl_24135);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_50_)
  {
    Term v_4294943167 = r0;
    Term v_4294943166 = r1;
    WL_OPEN
u64 cl_24134 = heap_alloc(e, cls_fit(2));
e.mem[cl_24134 + 0] = v_4294943167;
e.mem[cl_24134 + 1] = v_4294943166;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_51_, cl_24134);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_52_49_51_51_)
  {
    Term v_4294943167 = r0;
    Term v_4294943166 = r1;
    Term v_4294943165 = r2;
    WL_OPEN
r0 = v_4294943167;
r1 = v_4294943166;
r2 = v_4294943165;
WL_JMP(FID_36_100_105_114_101_99_116_46_99_108_115_46_103_111_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_99_108_115_46_103_111_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294943159 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294943158 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294943157 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_99_108_115_46_103_111_(e, seq, nq_result, v_4294943159, v_4294943158, v_4294943157)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294943156 = v_4294943159;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943155 = v_4294943158;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943154 = v_4294943157;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294943156)) {
Term v_4294943153 = v_4294943155;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943152 = v_4294943154;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294943153)) {
if (native_bool(v_4294943152)) {
r0 = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294943152);
r0 = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
WL_RETN(1);
}
} else {
term_sink(e, v_4294943153);
if (native_bool(v_4294943152)) {
r0 = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294943152);
r0 = term_pak(CID__CTOR_76_101_116_116_101_114_, 0);
WL_RETN(1);
}
}
} else {
term_sink(e, v_4294943156);
Term v_4294943151 = v_4294943155;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294943150 = v_4294943154;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294943151)) {
if (native_bool(v_4294943150)) {
r0 = term_pak(CID__CTOR_68_105_103_105_116_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294943150);
r0 = term_pak(CID__CTOR_68_105_103_105_116_, 0);
WL_RETN(1);
}
} else {
term_sink(e, v_4294943151);
if (native_bool(v_4294943150)) {
r0 = term_pak(CID__CTOR_83_112_97_99_101_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294943150);
r0 = term_pak(CID__CTOR_80_117_110_99_116_, 0);
WL_RETN(1);
}
}
}
#endif

  }}

  WL_CASE(FID_66_111_111_108_46_97_110_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_53_49_55_50_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_49_55_50_)
  {
    Term v_4294942125 = r0;
    WL_OPEN
u64 cl_25174 = heap_alloc(e, cls_fit(1));
e.mem[cl_25174 + 0] = v_4294942125;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_53_49_55_51_, cl_25174);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_49_55_51_)
  {
    Term v_4294942125 = r0;
    Term v_4294942124 = r1;
    WL_OPEN
r0 = v_4294942125;
r1 = v_4294942124;
WL_JMP(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_66_111_111_108_46_97_110_100_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294942120 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294942119 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_66_111_111_108_46_97_110_100_(e, seq, nq_result, v_4294942120, v_4294942119)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294942118 = v_4294942120;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942117 = v_4294942119;
if (!seq && err_seen(e.mem)) { return 0; }
if ((!native_bool(v_4294942118))) {
term_sink(e, v_4294942117);
r0 = 0ull;
WL_RETN(1);
} else {
Term v_4294942116 = v_4294942118;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294942115 = v_4294942117;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294942116)) {
r0 = v_4294942115;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294942115;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_53_49_56_51_;
WL_PUSHN(2);
} else {
u64 task_25187 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_53_49_56_51_, WL_CONT, WL_IDX, 1);
e.mem[task_25187 + 0] = v_4294942115;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_53_49_56_51_, task_25187);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294942116;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_53_49_56_54_;
WL_PUSHN(2);
} else {
u64 task_25187 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_53_49_56_54_, WL_CONT, WL_IDX, 1);
e.mem[task_25187 + 0] = v_4294942116;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_53_49_56_54_, task_25187);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_49_56_51_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294942115 = STK(0);
    Term v_4294942114 = r0;
    WL_OPEN
Term v_4294942113 = v_4294942115;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294942114; Term arg = v_4294942113;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_53_49_56_54_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294942116 = STK(0);
    Term v_4294942111 = r0;
    WL_OPEN
Term v_4294942110 = v_4294942116;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294942111; Term arg = v_4294942110;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_108_101_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_54_50_49_49_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_54_50_49_49_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_26213 = heap_alloc(e, cls_fit(1));
e.mem[cl_26213 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_54_50_49_50_, cl_26213);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_54_50_49_50_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, <=, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_108_101_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294941081 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294941080 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294941081, <=, v_4294941080);
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_55_50_52_48_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_55_50_52_48_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_27242 = heap_alloc(e, cls_fit(1));
e.mem[cl_27242 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_55_50_52_49_, cl_27242);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_55_50_52_49_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, ==, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_101_113_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294940052 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294940051 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294940052, ==, v_4294940051);
WL_RETN(1);

  }}

  WL_CASE(FID_103_101_110_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_50_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_50_)
  {
    Term v_4294939026 = r0;
    WL_OPEN
u64 cl_28276 = heap_alloc(e, cls_fit(1));
e.mem[cl_28276 + 0] = v_4294939026;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_51_, cl_28276);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_51_)
  {
    Term v_4294939026 = r0;
    Term v_4294939025 = r1;
    WL_OPEN
u64 cl_28275 = heap_alloc(e, cls_fit(2));
e.mem[cl_28275 + 0] = v_4294939026;
e.mem[cl_28275 + 1] = v_4294939025;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_52_, cl_28275);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_50_55_52_)
  {
    Term v_4294939026 = r0;
    Term v_4294939025 = r1;
    Term v_4294939024 = r2;
    WL_OPEN
r0 = v_4294939026;
r1 = v_4294939025;
r2 = v_4294939024;
WL_JMP(FID_36_100_105_114_101_99_116_46_103_101_110_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_103_101_110_)
  {
    Term v_4294939018 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939017 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939016 = r2;
    WL_OPEN
Term v_4294939015 = v_4294939018;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294939014 = v_4294939017;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294939013 = v_4294939016;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294939015) == CID_SNIL)) {
term_sink(e, v_4294939014);
term_sink(e, v_4294939013);
r0 = term_pak(CID_SNIL, 0);
WL_RETN(1);
} else {
Term v_4294939012 = v_4294939015;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294939011 = v_4294939014;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294939010 = v_4294939013;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294939012) == CID_SCON)) {
Term fields[2];
spare_free(e, cls_fit(2), ctr_take(e, v_4294939012, 2, fields));
#if !DEVICE && NATIVE_FIELD32_CID_SCON_0
u32
#else
Term
#endif
v_4294939009 = fields[0];
#if !DEVICE && NATIVE_FIELD32_CID_SCON_1
u32
#else
Term
#endif
v_4294939008 = fields[1];
Term v_4294939007 = v_4294939009;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294939006 = v_4294939008;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294939005 = v_4294939011;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294939004 = v_4294939010;
if (!seq && err_seen(e.mem)) { return 0; }
if (1) {
#if !DEVICE && NATIVE_FIELD32_CID_CHR_0
u32
#else
Term
#endif
v_4294939003 = v_4294939007;
Term v_4294939002 = v_4294939003;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294939005 = term_keep(e, v_4294939005);
v_4294939004 = term_keep(e, v_4294939004);
if (seq) {
WL_ROOM(5);
STK(0) = v_4294939006;
STK(1) = v_4294939005;
STK(2) = v_4294939004;
STK(3) = v_4294939002;
STK(4) = FID_110_97_116_105_118_101_95_107_95_50_56_50_57_54_;
WL_PUSHN(5);
} else {
u64 task_28305 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_50_57_54_, WL_CONT, WL_IDX, 1);
e.mem[task_28305 + 0] = v_4294939006;
e.mem[task_28305 + 1] = v_4294939005;
e.mem[task_28305 + 2] = v_4294939004;
e.mem[task_28305 + 3] = v_4294939002;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_50_57_54_, task_28305);
WL_IDX = 4;
}
Term v_4294938992 = v_4294939005;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294938991 = v_4294939004;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294938992;
r1 = v_4294938991;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_97_108_116_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294939004;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_48_55_;
WL_PUSHN(2);
} else {
u64 task_28317 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_48_55_, WL_CONT, WL_IDX, 1);
e.mem[task_28317 + 0] = v_4294939004;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_48_55_, task_28317);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294939005;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_49_48_;
WL_PUSHN(2);
} else {
u64 task_28317 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_49_48_, WL_CONT, WL_IDX, 1);
e.mem[task_28317 + 0] = v_4294939005;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_48_, task_28317);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294939006;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_49_51_;
WL_PUSHN(2);
} else {
u64 task_28317 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_49_51_, WL_CONT, WL_IDX, 1);
e.mem[task_28317 + 0] = v_4294939006;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_51_, task_28317);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294939007;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_49_54_;
WL_PUSHN(2);
} else {
u64 task_28317 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_49_54_, WL_CONT, WL_IDX, 1);
e.mem[task_28317 + 0] = v_4294939007;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_54_, task_28317);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294939010;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_49_57_;
WL_PUSHN(2);
} else {
u64 task_28326 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_49_57_, WL_CONT, WL_IDX, 1);
e.mem[task_28326 + 0] = v_4294939010;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_57_, task_28326);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294939011;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_50_50_;
WL_PUSHN(2);
} else {
u64 task_28326 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_50_50_, WL_CONT, WL_IDX, 1);
e.mem[task_28326 + 0] = v_4294939011;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_50_50_, task_28326);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294939012;
STK(1) = FID_110_97_116_105_118_101_95_107_95_50_56_51_50_53_;
WL_PUSHN(2);
} else {
u64 task_28326 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_51_50_53_, WL_CONT, WL_IDX, 1);
e.mem[task_28326 + 0] = v_4294939012;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_51_50_53_, task_28326);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_50_57_54_)
  {
    WL_POPN(4);
    Term v_4294939006 = STK(0);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939005 = STK(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939004 = STK(2);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939002 = STK(3);
    Term v_4294939001 = r0;
    WL_OPEN
if (seq) {
WL_ROOM(3);
STK(0) = v_4294939002;
STK(1) = v_4294939001;
STK(2) = FID_110_97_116_105_118_101_95_107_95_50_56_50_57_55_;
WL_PUSHN(3);
} else {
u64 task_28303 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_56_50_57_55_, WL_CONT, WL_IDX, 1);
e.mem[task_28303 + 0] = v_4294939002;
e.mem[task_28303 + 1] = v_4294939001;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_56_50_57_55_, task_28303);
WL_IDX = 2;
}
Term v_4294938997 = v_4294939006;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294938996 = v_4294939005;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294938994 = v_4294939004;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294938993 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294938995 = U32_BIN(v_4294938994, +, v_4294938993);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294938997;
r1 = v_4294938996;
r2 = v_4294938995;
WL_JMP(FID_36_100_105_114_101_99_116_46_103_101_110_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_50_57_55_)
  {
    WL_POPN(2);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939002 = STK(0);
    Term v_4294939001 = STK(1);
    Term v_4294939000 = r0;
    WL_OPEN
r0 = v_4294939002;
r1 = v_4294939001;
r2 = v_4294939000;
WL_JMP(FID_36_100_105_114_101_99_116_46_103_101_110_46_97_116_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_48_55_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939004 = STK(0);
    Term v_4294938990 = r0;
    WL_OPEN
Term v_4294938989 = v_4294939004;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938990; Term arg = v_4294938989;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_48_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939005 = STK(0);
    Term v_4294938987 = r0;
    WL_OPEN
Term v_4294938986 = v_4294939005;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938987; Term arg = v_4294938986;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_51_)
  {
    WL_POPN(1);
    Term v_4294939006 = STK(0);
    Term v_4294938984 = r0;
    WL_OPEN
Term v_4294938983 = v_4294939006;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938984; Term arg = v_4294938983;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_54_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939007 = STK(0);
    Term v_4294938981 = r0;
    WL_OPEN
Term v_4294938980 = v_4294939007;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938981; Term arg = v_4294938980;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_49_57_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939010 = STK(0);
    Term v_4294938978 = r0;
    WL_OPEN
Term v_4294938977 = v_4294939010;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938978; Term arg = v_4294938977;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_50_50_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294939011 = STK(0);
    Term v_4294938975 = r0;
    WL_OPEN
Term v_4294938974 = v_4294939011;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938975; Term arg = v_4294938974;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_56_51_50_53_)
  {
    WL_POPN(1);
    Term v_4294939012 = STK(0);
    Term v_4294938972 = r0;
    WL_OPEN
Term v_4294938971 = v_4294939012;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294938972; Term arg = v_4294938971;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_103_101_110_46_97_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_51_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_51_)
  {
    Term v_4294937945 = r0;
    WL_OPEN
u64 cl_29357 = heap_alloc(e, cls_fit(1));
e.mem[cl_29357 + 0] = v_4294937945;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_52_, cl_29357);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_52_)
  {
    Term v_4294937945 = r0;
    Term v_4294937944 = r1;
    WL_OPEN
u64 cl_29356 = heap_alloc(e, cls_fit(2));
e.mem[cl_29356 + 0] = v_4294937945;
e.mem[cl_29356 + 1] = v_4294937944;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_53_, cl_29356);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_51_53_53_)
  {
    Term v_4294937945 = r0;
    Term v_4294937944 = r1;
    Term v_4294937943 = r2;
    WL_OPEN
r0 = v_4294937945;
r1 = v_4294937944;
r2 = v_4294937943;
WL_JMP(FID_36_100_105_114_101_99_116_46_103_101_110_46_97_116_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_103_101_110_46_97_116_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294937937 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294937936 = r1;
    Term v_4294937935 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_103_101_110_46_97_116_(e, seq, nq_result, v_4294937937, v_4294937936, v_4294937935)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
v_4294937937 = term_keep(e, v_4294937937);
if (seq) {
WL_ROOM(4);
STK(0) = v_4294937937;
STK(1) = v_4294937936;
STK(2) = v_4294937935;
STK(3) = FID_110_97_116_105_118_101_95_107_95_50_57_51_54_53_;
WL_PUSHN(4);
} else {
u64 task_29367 = task_node(e, FID_110_97_116_105_118_101_95_107_95_50_57_51_54_53_, WL_CONT, WL_IDX, 1);
e.mem[task_29367 + 0] = v_4294937937;
e.mem[task_29367 + 1] = v_4294937936;
e.mem[task_29367 + 2] = v_4294937935;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_50_57_51_54_53_, task_29367);
WL_IDX = 3;
}
Term v_4294937929 = v_4294937937;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294937929;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_108_111_116_);
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_50_57_51_54_53_)
  {
    WL_POPN(3);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294937937 = STK(0);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294937936 = STK(1);
    Term v_4294937935 = STK(2);
    Term v_4294937934 = r0;
    WL_OPEN
Term v_4294937933 = v_4294937937;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294937932 = v_4294937936;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294937931 = v_4294937935;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294937934;
r1 = v_4294937933;
r2 = v_4294937932;
r3 = v_4294937931;
WL_JMP(FID_36_100_105_114_101_99_116_46_101_120_112_97_110_100_);

  }}

  WL_CASE(FID_101_120_112_97_110_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_53_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_53_)
  {
    Term v_4294936904 = r0;
    WL_OPEN
u64 cl_30401 = heap_alloc(e, cls_fit(1));
e.mem[cl_30401 + 0] = v_4294936904;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_54_, cl_30401);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_54_)
  {
    Term v_4294936904 = r0;
    Term v_4294936903 = r1;
    WL_OPEN
u64 cl_30400 = heap_alloc(e, cls_fit(2));
e.mem[cl_30400 + 0] = v_4294936904;
e.mem[cl_30400 + 1] = v_4294936903;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_55_, cl_30400);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_55_)
  {
    Term v_4294936904 = r0;
    Term v_4294936903 = r1;
    Term v_4294936902 = r2;
    WL_OPEN
u64 cl_30399 = heap_alloc(e, cls_fit(3));
e.mem[cl_30399 + 0] = v_4294936904;
e.mem[cl_30399 + 1] = v_4294936903;
e.mem[cl_30399 + 2] = v_4294936902;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_56_, cl_30399);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_51_57_56_)
  {
    Term v_4294936904 = r0;
    Term v_4294936903 = r1;
    Term v_4294936902 = r2;
    Term v_4294936901 = r3;
    WL_OPEN
r0 = v_4294936904;
r1 = v_4294936903;
r2 = v_4294936902;
r3 = v_4294936901;
WL_JMP(FID_36_100_105_114_101_99_116_46_101_120_112_97_110_100_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_101_120_112_97_110_100_)
  {
    Term v_4294936893 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294936892 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294936891 = r2;
    Term v_4294936890 = r3;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_101_120_112_97_110_100_(e, seq, nq_result, v_4294936893, v_4294936892, v_4294936891, v_4294936890)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294936889 = v_4294936893;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936888 = v_4294936892;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936887 = v_4294936891;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936886 = v_4294936890;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294936889) == CID__CTOR_73_100_)) {
term_sink(e, v_4294936888);
Term v_4294936881 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294936887 = term_keep(e, v_4294936887);
Term v_4294936879 = v_4294936887;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936878 = 7ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936880 = U32_BIN(v_4294936879, &, v_4294936878);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936882 = U32_BIN(v_4294936881, +, v_4294936880);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936885 = ((u64)v_4294936882);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936884 = v_4294936887;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936883 = v_4294936886;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294936885;
r1 = v_4294936884;
r2 = v_4294936883;
WL_JMP(FID_36_100_105_114_101_99_116_46_105_100_101_110_116_);
} else {
Term v_4294936877 = v_4294936889;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936876 = v_4294936888;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936875 = v_4294936887;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936874 = v_4294936886;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294936877) == CID__CTOR_78_109_)) {
term_sink(e, v_4294936876);
Term v_4294936869 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
v_4294936875 = term_keep(e, v_4294936875);
Term v_4294936867 = v_4294936875;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936866 = 6ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936868 = ((u32)(v_4294936866) == 0 ? v_4294936867 : U32_BIN(v_4294936867, -, U32_QUO((u32)(v_4294936867), (u32)(v_4294936866)) * v_4294936866));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936870 = U32_BIN(v_4294936869, +, v_4294936868);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936873 = ((u64)v_4294936870);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936872 = v_4294936875;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936871 = v_4294936874;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294936873;
r1 = v_4294936872;
r2 = v_4294936871;
WL_JMP(FID_36_100_105_114_101_99_116_46_110_117_109_);
} else {
Term v_4294936865 = v_4294936877;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936864 = v_4294936876;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936863 = v_4294936875;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936862 = v_4294936874;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294936865) == CID__CTOR_79_112_)) {
term_sink(e, v_4294936864);
Term v_4294936861 = v_4294936863;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936860 = v_4294936862;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294936861;
r1 = v_4294936860;
WL_JMP(FID_36_100_105_114_101_99_116_46_111_112_);
} else {
Term v_4294936859 = v_4294936865;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936858 = v_4294936864;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936857 = v_4294936863;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936856 = v_4294936862;
if (!seq && err_seen(e.mem)) { return 0; }
if ((term_aux(v_4294936859) == CID__CTOR_76_105_116_)) {
term_sink(e, v_4294936857);
Term v_4294936853 = v_4294936858;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936855;
{
v_4294936855 = v_4294936853;
}
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294936854 = v_4294936856;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_30443 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_30443 + 0] = v_4294936855;
e.mem[nd_30443 + 1] = v_4294936854;
#else
e.mem[nd_30443 + 0] = rfc_seal(e, v_4294936855);
e.mem[nd_30443 + 1] = rfc_seal(e, v_4294936854);
#endif
r0 = term_ctr(CID_SCON, nd_30443);
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294936856;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_48_52_52_54_;
WL_PUSHN(2);
} else {
u64 task_30456 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_48_52_52_54_, WL_CONT, WL_IDX, 1);
e.mem[task_30456 + 0] = v_4294936856;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_48_52_52_54_, task_30456);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294936857;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_48_52_52_57_;
WL_PUSHN(2);
} else {
u64 task_30456 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_48_52_52_57_, WL_CONT, WL_IDX, 1);
e.mem[task_30456 + 0] = v_4294936857;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_48_52_52_57_, task_30456);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294936858;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_48_52_53_50_;
WL_PUSHN(2);
} else {
u64 task_30456 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_48_52_53_50_, WL_CONT, WL_IDX, 1);
e.mem[task_30456 + 0] = v_4294936858;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_48_52_53_50_, task_30456);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294936859;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_48_52_53_53_;
WL_PUSHN(2);
} else {
u64 task_30456 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_48_52_53_53_, WL_CONT, WL_IDX, 1);
e.mem[task_30456 + 0] = v_4294936859;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_48_52_53_53_, task_30456);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_52_54_)
  {
    WL_POPN(1);
    Term v_4294936856 = STK(0);
    Term v_4294936851 = r0;
    WL_OPEN
Term v_4294936850 = v_4294936856;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294936851; Term arg = v_4294936850;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_52_57_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294936857 = STK(0);
    Term v_4294936848 = r0;
    WL_OPEN
Term v_4294936847 = v_4294936857;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294936848; Term arg = v_4294936847;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_53_50_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294936858 = STK(0);
    Term v_4294936845 = r0;
    WL_OPEN
Term v_4294936844 = v_4294936858;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294936845; Term arg = v_4294936844;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_48_52_53_53_)
  {
    WL_POPN(1);
    Term v_4294936859 = STK(0);
    Term v_4294936842 = r0;
    WL_OPEN
Term v_4294936841 = v_4294936859;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294936842; Term arg = v_4294936841;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_105_100_101_110_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_51_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_51_)
  {
    Term v_4294935815 = r0;
    WL_OPEN
u64 cl_31487 = heap_alloc(e, cls_fit(1));
e.mem[cl_31487 + 0] = v_4294935815;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_52_, cl_31487);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_52_)
  {
    Term v_4294935815 = r0;
    Term v_4294935814 = r1;
    WL_OPEN
u64 cl_31486 = heap_alloc(e, cls_fit(2));
e.mem[cl_31486 + 0] = v_4294935815;
e.mem[cl_31486 + 1] = v_4294935814;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_53_, cl_31486);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_52_56_53_)
  {
    Term v_4294935815 = r0;
    Term v_4294935814 = r1;
    Term v_4294935813 = r2;
    WL_OPEN
r0 = v_4294935815;
r1 = v_4294935814;
r2 = v_4294935813;
WL_JMP(FID_36_100_105_114_101_99_116_46_105_100_101_110_116_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_105_100_101_110_116_)
  {
    Term v_4294935807 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294935806 = r1;
    Term v_4294935805 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_105_100_101_110_116_(e, seq, nq_result, v_4294935807, v_4294935806, v_4294935805)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294935804 = v_4294935807;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935803 = v_4294935806;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935802 = v_4294935805;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294935804 == 0)) {
term_sink(e, v_4294935803);
r0 = v_4294935802;
WL_RETN(1);
} else {
Term v_4294935801 = v_4294935804;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935800 = v_4294935803;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935799 = v_4294935802;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294935801 != 0)) {
#if !DEVICE && NATIVE_FIELD32_CID_SUCC_0
u32
#else
Term
#endif
v_4294935798 = (v_4294935801 - 1);
if (seq) {
WL_ROOM(3);
STK(0) = v_4294935799;
STK(1) = v_4294935798;
STK(2) = FID_110_97_116_105_118_101_95_107_95_51_49_52_57_56_;
WL_PUSHN(3);
} else {
u64 task_31512 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_52_57_56_, WL_CONT, WL_IDX, 1);
e.mem[task_31512 + 0] = v_4294935799;
e.mem[task_31512 + 1] = v_4294935798;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_52_57_56_, task_31512);
WL_IDX = 2;
}
Term v_4294935784 = v_4294935800;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294935784;
WL_JMP(FID_36_100_105_114_101_99_116_46_112_114_110_103_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935799;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_49_52_;
WL_PUSHN(2);
} else {
u64 task_31521 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_49_52_, WL_CONT, WL_IDX, 1);
e.mem[task_31521 + 0] = v_4294935799;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_52_, task_31521);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935800;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_49_55_;
WL_PUSHN(2);
} else {
u64 task_31521 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_49_55_, WL_CONT, WL_IDX, 1);
e.mem[task_31521 + 0] = v_4294935800;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_55_, task_31521);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935801;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_50_48_;
WL_PUSHN(2);
} else {
u64 task_31521 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_50_48_, WL_CONT, WL_IDX, 1);
e.mem[task_31521 + 0] = v_4294935801;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_50_48_, task_31521);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_52_57_56_)
  {
    WL_POPN(2);
    Term v_4294935799 = STK(0);
    Term v_4294935798 = STK(1);
    Term v_3491 = r0;
    WL_OPEN
Term v_4294935793 = 97ull;
if (!seq && err_seen(e.mem)) { return 0; }
v_3491 = term_keep(e, v_3491);
Term v_4294935791 = v_3491;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935790 = 26ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935792 = ((u32)(v_4294935790) == 0 ? v_4294935791 : U32_BIN(v_4294935791, -, U32_QUO((u32)(v_4294935791), (u32)(v_4294935790)) * v_4294935790));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935794 = U32_BIN(v_4294935793, +, v_4294935792);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935796;
{
v_4294935796 = v_4294935794;
}
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294935796;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_;
WL_PUSHN(2);
} else {
u64 task_31511 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_, WL_CONT, WL_IDX, 1);
e.mem[task_31511 + 0] = v_4294935796;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_, task_31511);
WL_IDX = 1;
}
Term v_4294935787 = v_4294935798;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935786 = v_3491;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294935785 = v_4294935799;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294935787;
r1 = v_4294935786;
r2 = v_4294935785;
WL_JMP(FID_36_100_105_114_101_99_116_46_105_100_101_110_116_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_48_54_)
  {
    WL_POPN(1);
    Term v_4294935796 = STK(0);
    Term v_4294935795 = r0;
    WL_OPEN
u64 nd_31507 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_31507 + 0] = v_4294935796;
e.mem[nd_31507 + 1] = v_4294935795;
#else
e.mem[nd_31507 + 0] = rfc_seal(e, v_4294935796);
e.mem[nd_31507 + 1] = rfc_seal(e, v_4294935795);
#endif
r0 = term_ctr(CID_SCON, nd_31507);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_52_)
  {
    WL_POPN(1);
    Term v_4294935799 = STK(0);
    Term v_4294935783 = r0;
    WL_OPEN
Term v_4294935782 = v_4294935799;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294935783; Term arg = v_4294935782;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_49_55_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294935800 = STK(0);
    Term v_4294935780 = r0;
    WL_OPEN
Term v_4294935779 = v_4294935800;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294935780; Term arg = v_4294935779;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_49_53_50_48_)
  {
    WL_POPN(1);
    Term v_4294935801 = STK(0);
    Term v_4294935777 = r0;
    WL_OPEN
Term v_4294935776 = v_4294935801;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294935777; Term arg = v_4294935776;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_112_114_110_103_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_50_53_52_54_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_50_53_52_54_)
  {
    Term v_4294934750 = r0;
    WL_OPEN
r0 = v_4294934750;
WL_JMP(FID_36_100_105_114_101_99_116_46_112_114_110_103_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_112_114_110_103_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294934748 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_112_114_110_103_(e, seq, nq_result, v_4294934748)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
v_4294934748 = term_keep(e, v_4294934748);
Term v_4294934747 = v_4294934748;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934745 = v_4294934748;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934744 = 13ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934746 = (v_4294934744 >= 32 ? 0 : U32_BIN(v_4294934745, <<, v_4294934744));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_3469 = U32_BIN(v_4294934747, ^, v_4294934746);
if (!seq && err_seen(e.mem)) { return 0; }
v_3469 = term_keep(e, v_3469);
Term v_4294934743 = v_3469;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934741 = v_3469;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934740 = 17ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934742 = (v_4294934740 >= 32 ? 0 : U32_BIN(v_4294934741, >>, v_4294934740));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_3470 = U32_BIN(v_4294934743, ^, v_4294934742);
if (!seq && err_seen(e.mem)) { return 0; }
v_3470 = term_keep(e, v_3470);
Term v_4294934739 = v_3470;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934737 = v_3470;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934736 = 5ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294934738 = (v_4294934736 >= 32 ? 0 : U32_BIN(v_4294934737, <<, v_4294934736));
if (!seq && err_seen(e.mem)) { return 0; }
r0 = U32_BIN(v_4294934739, ^, v_4294934738);
WL_RETN(1);
#endif

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_115_104_108_110_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_51_53_56_52_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_51_53_56_52_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_33586 = heap_alloc(e, cls_fit(1));
e.mem[cl_33586 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_51_53_56_53_, cl_33586);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_51_53_56_53_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = (v_4000000001 >= 32 ? 0 : U32_BIN(v_4000000000, <<, v_4000000001));
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_104_108_110_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294933708 = r0;
    Term v_4294933707 = r1;
    WL_OPEN
r0 = (v_4294933707 >= 32 ? 0 : U32_BIN(v_4294933708, <<, v_4294933707));
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_115_104_114_110_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_52_54_49_51_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_54_49_51_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_34615 = heap_alloc(e, cls_fit(1));
e.mem[cl_34615 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_52_54_49_52_, cl_34615);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_52_54_49_52_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = (v_4000000001 >= 32 ? 0 : U32_BIN(v_4000000000, >>, v_4000000001));
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_115_104_114_110_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294932679 = r0;
    Term v_4294932678 = r1;
    WL_OPEN
r0 = (v_4294932678 >= 32 ? 0 : U32_BIN(v_4294932679, >>, v_4294932678));
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_116_111_95_110_97_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_53_54_52_50_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_53_54_52_50_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
r0 = ((u64)v_4000000000);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_116_111_95_110_97_116_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294931652 = r0;
    WL_OPEN
r0 = ((u64)v_4294931652);
WL_RETN(1);

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_97_110_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_54_54_54_56_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_54_54_54_56_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_36670 = heap_alloc(e, cls_fit(1));
e.mem[cl_36670 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_54_54_54_57_, cl_36670);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_54_54_54_57_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, &, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_97_110_100_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294930624 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294930623 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294930624, &, v_4294930623);
WL_RETN(1);

  }}

  WL_CASE(FID_110_117_109_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_48_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_48_)
  {
    Term v_4294929598 = r0;
    WL_OPEN
u64 cl_37704 = heap_alloc(e, cls_fit(1));
e.mem[cl_37704 + 0] = v_4294929598;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_49_, cl_37704);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_49_)
  {
    Term v_4294929598 = r0;
    Term v_4294929597 = r1;
    WL_OPEN
u64 cl_37703 = heap_alloc(e, cls_fit(2));
e.mem[cl_37703 + 0] = v_4294929598;
e.mem[cl_37703 + 1] = v_4294929597;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_50_, cl_37703);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_48_50_)
  {
    Term v_4294929598 = r0;
    Term v_4294929597 = r1;
    Term v_4294929596 = r2;
    WL_OPEN
r0 = v_4294929598;
r1 = v_4294929597;
r2 = v_4294929596;
WL_JMP(FID_36_100_105_114_101_99_116_46_110_117_109_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_110_117_109_)
  {
    Term v_4294929590 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294929589 = r1;
    Term v_4294929588 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_110_117_109_(e, seq, nq_result, v_4294929590, v_4294929589, v_4294929588)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294929587 = v_4294929590;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929586 = v_4294929589;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929585 = v_4294929588;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294929587 == 0)) {
term_sink(e, v_4294929586);
r0 = v_4294929585;
WL_RETN(1);
} else {
Term v_4294929584 = v_4294929587;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929583 = v_4294929586;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929582 = v_4294929585;
if (!seq && err_seen(e.mem)) { return 0; }
if ((v_4294929584 != 0)) {
#if !DEVICE && NATIVE_FIELD32_CID_SUCC_0
u32
#else
Term
#endif
v_4294929581 = (v_4294929584 - 1);
if (seq) {
WL_ROOM(3);
STK(0) = v_4294929582;
STK(1) = v_4294929581;
STK(2) = FID_110_97_116_105_118_101_95_107_95_51_55_55_49_53_;
WL_PUSHN(3);
} else {
u64 task_37729 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_55_55_49_53_, WL_CONT, WL_IDX, 1);
e.mem[task_37729 + 0] = v_4294929582;
e.mem[task_37729 + 1] = v_4294929581;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_55_55_49_53_, task_37729);
WL_IDX = 2;
}
Term v_4294929567 = v_4294929583;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294929567;
WL_JMP(FID_36_100_105_114_101_99_116_46_112_114_110_103_);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294929582;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_55_55_51_49_;
WL_PUSHN(2);
} else {
u64 task_37738 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_55_55_51_49_, WL_CONT, WL_IDX, 1);
e.mem[task_37738 + 0] = v_4294929582;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_49_, task_37738);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294929583;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_55_55_51_52_;
WL_PUSHN(2);
} else {
u64 task_37738 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_55_55_51_52_, WL_CONT, WL_IDX, 1);
e.mem[task_37738 + 0] = v_4294929583;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_52_, task_37738);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294929584;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_55_55_51_55_;
WL_PUSHN(2);
} else {
u64 task_37738 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_55_55_51_55_, WL_CONT, WL_IDX, 1);
e.mem[task_37738 + 0] = v_4294929584;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_55_, task_37738);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_49_53_)
  {
    WL_POPN(2);
    Term v_4294929582 = STK(0);
    Term v_4294929581 = STK(1);
    Term v_3500 = r0;
    WL_OPEN
Term v_4294929576 = 48ull;
if (!seq && err_seen(e.mem)) { return 0; }
v_3500 = term_keep(e, v_3500);
Term v_4294929574 = v_3500;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929573 = 10ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929575 = ((u32)(v_4294929573) == 0 ? v_4294929574 : U32_BIN(v_4294929574, -, U32_QUO((u32)(v_4294929574), (u32)(v_4294929573)) * v_4294929573));
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929577 = U32_BIN(v_4294929576, +, v_4294929575);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929579;
{
v_4294929579 = v_4294929577;
}
if (!seq && err_seen(e.mem)) { return 0; }
if (seq) {
WL_ROOM(2);
STK(0) = v_4294929579;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_55_55_50_51_;
WL_PUSHN(2);
} else {
u64 task_37728 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_55_55_50_51_, WL_CONT, WL_IDX, 1);
e.mem[task_37728 + 0] = v_4294929579;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_55_55_50_51_, task_37728);
WL_IDX = 1;
}
Term v_4294929570 = v_4294929581;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929569 = v_3500;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294929568 = v_4294929582;
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294929570;
r1 = v_4294929569;
r2 = v_4294929568;
WL_JMP(FID_36_100_105_114_101_99_116_46_110_117_109_);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_50_51_)
  {
    WL_POPN(1);
    Term v_4294929579 = STK(0);
    Term v_4294929578 = r0;
    WL_OPEN
u64 nd_37724 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_37724 + 0] = v_4294929579;
e.mem[nd_37724 + 1] = v_4294929578;
#else
e.mem[nd_37724 + 0] = rfc_seal(e, v_4294929579);
e.mem[nd_37724 + 1] = rfc_seal(e, v_4294929578);
#endif
r0 = term_ctr(CID_SCON, nd_37724);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_49_)
  {
    WL_POPN(1);
    Term v_4294929582 = STK(0);
    Term v_4294929566 = r0;
    WL_OPEN
Term v_4294929565 = v_4294929582;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294929566; Term arg = v_4294929565;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_52_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294929583 = STK(0);
    Term v_4294929563 = r0;
    WL_OPEN
Term v_4294929562 = v_4294929583;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294929563; Term arg = v_4294929562;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_55_55_51_55_)
  {
    WL_POPN(1);
    Term v_4294929584 = STK(0);
    Term v_4294929560 = r0;
    WL_OPEN
Term v_4294929559 = v_4294929584;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294929560; Term arg = v_4294929559;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_111_112_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_56_55_54_52_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_56_55_54_52_)
  {
    Term v_4294928533 = r0;
    WL_OPEN
u64 cl_38766 = heap_alloc(e, cls_fit(1));
e.mem[cl_38766 + 0] = v_4294928533;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_56_55_54_53_, cl_38766);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_56_55_54_53_)
  {
    Term v_4294928533 = r0;
    Term v_4294928532 = r1;
    WL_OPEN
r0 = v_4294928533;
r1 = v_4294928532;
WL_JMP(FID_36_100_105_114_101_99_116_46_111_112_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_111_112_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294928528 = r0;
    Term v_4294928527 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_111_112_(e, seq, nq_result, v_4294928528, v_4294928527)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
if (seq) {
WL_ROOM(2);
STK(0) = v_4294928527;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_56_55_55_49_;
WL_PUSHN(2);
} else {
u64 task_38783 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_56_55_55_49_, WL_CONT, WL_IDX, 1);
e.mem[task_38783 + 0] = v_4294928527;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_56_55_55_49_, task_38783);
WL_IDX = 1;
}
v_4294928528 = term_keep(e, v_4294928528);
Term v_4294928518 = v_4294928528;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928517 = 2ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928520 = U32_BIN(v_4294928518, &, v_4294928517);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928519 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928522 = U32_BIN(v_4294928520, !=, v_4294928519);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928514 = v_4294928528;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928513 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928516 = U32_BIN(v_4294928514, &, v_4294928513);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928515 = 0ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294928521 = U32_BIN(v_4294928516, !=, v_4294928515);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294928522;
r1 = v_4294928521;
WL_JMP(FID_36_100_105_114_101_99_116_46_111_112_46_112_105_99_107_);
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_56_55_55_49_)
  {
    WL_POPN(1);
    Term v_4294928527 = STK(0);
    Term v_4294928526 = r0;
    WL_OPEN
Term v_4294928525 = v_4294928527;
if (!seq && err_seen(e.mem)) { return 0; }
u64 nd_38772 = heap_alloc(e, cls_fit(2));
#if !DEVICE && NATIVE_COLD_CTORS && !NATIVE_HOT_CID_SCON
e.mem[nd_38772 + 0] = v_4294928526;
e.mem[nd_38772 + 1] = v_4294928525;
#else
e.mem[nd_38772 + 0] = rfc_seal(e, v_4294928526);
e.mem[nd_38772 + 1] = rfc_seal(e, v_4294928525);
#endif
r0 = term_ctr(CID_SCON, nd_38772);
WL_RETN(1);

  }}

  WL_CASE(FID_111_112_46_112_105_99_107_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_57_56_48_57_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_56_48_57_)
  {
    Term v_4294927488 = r0;
    WL_OPEN
u64 cl_39811 = heap_alloc(e, cls_fit(1));
e.mem[cl_39811 + 0] = v_4294927488;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_51_57_56_49_48_, cl_39811);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_56_49_48_)
  {
    Term v_4294927488 = r0;
    Term v_4294927487 = r1;
    WL_OPEN
r0 = v_4294927488;
r1 = v_4294927487;
WL_JMP(FID_36_100_105_114_101_99_116_46_111_112_46_112_105_99_107_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_111_112_46_112_105_99_107_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927483 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927482 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_111_112_46_112_105_99_107_(e, seq, nq_result, v_4294927483, v_4294927482)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294927481 = v_4294927483;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927480 = v_4294927482;
if (!seq && err_seen(e.mem)) { return 0; }
if ((!native_bool(v_4294927481))) {
if ((!native_bool(v_4294927480))) {
r0 = 43ull;
WL_RETN(1);
} else {
if (native_bool(v_4294927480)) {
r0 = 45ull;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927480;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_56_49_56_;
WL_PUSHN(2);
} else {
u64 task_39819 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_56_49_56_, WL_CONT, WL_IDX, 1);
e.mem[task_39819 + 0] = v_4294927480;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_56_49_56_, task_39819);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
Term v_4294927476 = v_4294927481;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294927475 = v_4294927480;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294927476)) {
if ((!native_bool(v_4294927475))) {
r0 = 42ull;
WL_RETN(1);
} else {
if (native_bool(v_4294927475)) {
r0 = 47ull;
WL_RETN(1);
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927475;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_56_50_51_;
WL_PUSHN(2);
} else {
u64 task_39824 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_56_50_51_, WL_CONT, WL_IDX, 1);
e.mem[task_39824 + 0] = v_4294927475;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_51_, task_39824);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
} else {
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927475;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_56_50_54_;
WL_PUSHN(2);
} else {
u64 task_39830 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_56_50_54_, WL_CONT, WL_IDX, 1);
e.mem[task_39830 + 0] = v_4294927475;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_54_, task_39830);
WL_IDX = 1;
}
if (seq) {
WL_ROOM(2);
STK(0) = v_4294927476;
STK(1) = FID_110_97_116_105_118_101_95_107_95_51_57_56_50_57_;
WL_PUSHN(2);
} else {
u64 task_39830 = task_node(e, FID_110_97_116_105_118_101_95_107_95_51_57_56_50_57_, WL_CONT, WL_IDX, 1);
e.mem[task_39830 + 0] = v_4294927476;
WL_CONT = term_tsk(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_57_, task_39830);
WL_IDX = 1;
}
err_post(e.mem, ERR_FIDS); return 0;
}
}
#endif

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_56_49_56_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927480 = STK(0);
    Term v_4294927479 = r0;
    WL_OPEN
Term v_4294927478 = v_4294927480;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927479; Term arg = v_4294927478;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_51_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927475 = STK(0);
    Term v_4294927474 = r0;
    WL_OPEN
Term v_4294927473 = v_4294927475;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927474; Term arg = v_4294927473;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_54_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927475 = STK(0);
    Term v_4294927471 = r0;
    WL_OPEN
Term v_4294927470 = v_4294927475;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927471; Term arg = v_4294927470;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_51_57_56_50_57_)
  {
    WL_POPN(1);
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294927476 = STK(0);
    Term v_4294927468 = r0;
    WL_OPEN
Term v_4294927467 = v_4294927476;
if (!seq && err_seen(e.mem)) { return 0; }
{ Term fn = v_4294927468; Term arg = v_4294927467;
Fid f = (Fid)term_aux(fn);
if (!seq && fid_bangs(f)) {
  u32 war = fid_arity(f) - 1;
  Loc src = term_loc(fn);
  Loc dst = task_node(e, f, WL_CONT, WL_IDX, 0);
  for (u32 j = 0; j < war; ++j) e.mem[dst + j] = e.mem[src + j];
  e.mem[dst + war] = arg;
  spare_free(e, cls_fit(war), src);
  return term_tsk(f, dst);
}
r0 = fn; r1 = arg; WL_JMP(BEND_CLO_APPLY);
}

  }}

  WL_CASE(FID_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_110_101_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_48_56_53_52_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_56_53_52_)
  {
    Term v_4000000000 = r0;
    WL_OPEN
u64 cl_40856 = heap_alloc(e, cls_fit(1));
e.mem[cl_40856 + 0] = v_4000000000;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_48_56_53_53_, cl_40856);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_48_56_53_53_)
  {
    Term v_4000000000 = r0;
    Term v_4000000001 = r1;
    WL_OPEN
r0 = U32_BIN(v_4000000000, !=, v_4000000001);
WL_RETN(1);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_36_110_97_116_105_118_101_46_85_51_50_46_105_115_95_110_101_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294926438 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294926437 = r1;
    WL_OPEN
r0 = U32_BIN(v_4294926438, !=, v_4294926437);
WL_RETN(1);

  }}

  WL_CASE(FID_115_108_111_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_49_56_56_52_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_49_56_56_52_)
  {
    Term v_4294925412 = r0;
    WL_OPEN
r0 = v_4294925412;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_108_111_116_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_115_108_111_116_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294925410 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_115_108_111_116_(e, seq, nq_result, v_4294925410)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
v_4294925410 = term_keep(e, v_4294925410);
Term v_4294925406 = v_4294925410;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925405 = 105ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925409 = U32_BIN(v_4294925406, ==, v_4294925405);
if (!seq && err_seen(e.mem)) { return 0; }
v_4294925410 = term_keep(e, v_4294925410);
Term v_4294925404 = v_4294925410;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925403 = 110ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925408 = U32_BIN(v_4294925404, ==, v_4294925403);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925402 = v_4294925410;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925401 = 111ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294925407 = U32_BIN(v_4294925402, ==, v_4294925401);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294925409;
r1 = v_4294925408;
r2 = v_4294925407;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_108_111_116_46_103_111_);
#endif

  }}

  WL_CASE(FID_115_108_111_116_46_103_111_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_50_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_50_)
  {
    Term v_4294924376 = r0;
    WL_OPEN
u64 cl_42926 = heap_alloc(e, cls_fit(1));
e.mem[cl_42926 + 0] = v_4294924376;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_51_, cl_42926);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_51_)
  {
    Term v_4294924376 = r0;
    Term v_4294924375 = r1;
    WL_OPEN
u64 cl_42925 = heap_alloc(e, cls_fit(2));
e.mem[cl_42925 + 0] = v_4294924376;
e.mem[cl_42925 + 1] = v_4294924375;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_52_, cl_42925);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_50_57_50_52_)
  {
    Term v_4294924376 = r0;
    Term v_4294924375 = r1;
    Term v_4294924374 = r2;
    WL_OPEN
r0 = v_4294924376;
r1 = v_4294924375;
r2 = v_4294924374;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_108_111_116_46_103_111_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_115_108_111_116_46_103_111_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924368 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924367 = r1;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294924366 = r2;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_115_108_111_116_46_103_111_(e, seq, nq_result, v_4294924368, v_4294924367, v_4294924366)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294924365 = v_4294924368;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294924364 = v_4294924367;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294924363 = v_4294924366;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294924365)) {
Term v_4294924362 = v_4294924364;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294924361 = v_4294924363;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294924362)) {
if (native_bool(v_4294924361)) {
r0 = term_pak(CID__CTOR_73_100_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294924361);
r0 = term_pak(CID__CTOR_73_100_, 0);
WL_RETN(1);
}
} else {
term_sink(e, v_4294924362);
if (native_bool(v_4294924361)) {
r0 = term_pak(CID__CTOR_73_100_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294924361);
r0 = term_pak(CID__CTOR_73_100_, 0);
WL_RETN(1);
}
}
} else {
term_sink(e, v_4294924365);
Term v_4294924360 = v_4294924364;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294924359 = v_4294924363;
if (!seq && err_seen(e.mem)) { return 0; }
if (native_bool(v_4294924360)) {
if (native_bool(v_4294924359)) {
r0 = term_pak(CID__CTOR_78_109_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294924359);
r0 = term_pak(CID__CTOR_78_109_, 0);
WL_RETN(1);
}
} else {
term_sink(e, v_4294924360);
if (native_bool(v_4294924359)) {
r0 = term_pak(CID__CTOR_79_112_, 0);
WL_RETN(1);
} else {
term_sink(e, v_4294924359);
r0 = term_pak(CID__CTOR_76_105_116_, 0);
WL_RETN(1);
}
}
}
#endif

  }}

  WL_CASE(FID_115_97_108_116_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_51_57_54_51_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_51_57_54_51_)
  {
    Term v_4294923334 = r0;
    WL_OPEN
u64 cl_43965 = heap_alloc(e, cls_fit(1));
e.mem[cl_43965 + 0] = v_4294923334;
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_51_57_54_52_, cl_43965);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_51_57_54_52_)
  {
    Term v_4294923334 = r0;
    Term v_4294923333 = r1;
    WL_OPEN
r0 = v_4294923334;
r1 = v_4294923333;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_97_108_116_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_115_97_108_116_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294923329 = r0;
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294923328 = r1;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_115_97_108_116_(e, seq, nq_result, v_4294923329, v_4294923328)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294923326 = v_4294923329;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294923324 = v_4294923328;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294923323 = 2654435761ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294923325 = U32_BIN(v_4294923324, *, v_4294923323);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294923327 = U32_BIN(v_4294923326, ^, v_4294923325);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294923327;
WL_JMP(FID_36_100_105_114_101_99_116_46_112_114_110_103_);
#endif

  }}

  WL_CASE(FID_116_112_108_)
  {
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_116_112_108_(e, seq, nq_result)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
r0 = term_ctr(CID_SCON, STAT_OFF + 76);
WL_RETN(1);
#endif

  }}

  WL_CASE(FID_115_101_101_100_)
  {
    WL_OPEN
r0 = term_clo(FID_110_97_116_105_118_101_95_107_95_52_54_48_50_50_, 0);
WL_RETN(1);

  }}

  WL_CASE(FID_110_97_116_105_118_101_95_107_95_52_54_48_50_50_)
  {
    Term v_4294921274 = r0;
    WL_OPEN
r0 = v_4294921274;
WL_JMP(FID_36_100_105_114_101_99_116_46_115_101_101_100_);

  }}

  WL_CASE(FID_36_100_105_114_101_99_116_46_115_101_101_100_)
  {
    #if !DEVICE && NATIVE_TYPED_SCALARS
u32
#else
Term
#endif
 v_4294921272 = r0;
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_115_101_101_100_(e, seq, nq_result, v_4294921272)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
Term v_4294921268 = v_4294921272;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294921267 = 1ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294921270 = U32_BIN(v_4294921268, +, v_4294921267);
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294921269 = 2654435761ull;
if (!seq && err_seen(e.mem)) { return 0; }
Term v_4294921271 = U32_BIN(v_4294921270, *, v_4294921269);
if (!seq && err_seen(e.mem)) { return 0; }
r0 = v_4294921271;
WL_JMP(FID_36_100_105_114_101_99_116_46_112_114_110_103_);
#endif

  }}

  WL_CASE(FID_115_105_122_101_46_98_105_103_)
  {
    WL_OPEN
#if !DEVICE
{
Term nq_result[1];
if (!NF_FID_115_105_122_101_46_98_105_103_(e, seq, nq_result)) { return 0; }
r0 = nq_result[0];
WL_RETN(1);
}
#else
r0 = 23ull;
WL_RETN(1);
#endif

  }}



// A task enters through its words: a continuation's results ride r0.. and
// its parameters the stack; any other segment's parameters ride r0...
  WL_CASE(FID_ENTER)
  {
    Term t = r0;
    WL_OPEN
    Fid f   = (u32)term_aux(t);
    Loc a   = term_loc(t);
    u32 war = fid_arity(f);
    WL_FRAME(t)
    if (fid_seqk(f)) {
      u32 rw = fid_resw(f);
      WL_LOAD(a + war - rw, rw)
      WL_ARGS(a, war - rw + 1)
    } else {
      WL_LOAD(a, war)
    }
    heap_free(e, cls_fit(war + 2), a);
    WL_DYN(f);
  }}

  WL_CASE(FID_IO_EMIT)
  {
    Term x = r0;
    WL_OPEN
    Loc l = heap_alloc(e, 0);
    e.mem[l] = x;
    r0 = term_ctr(CID_EMIT, l);
    WL_RETN(1);
  }}

  WL_CASE(BEND_CLO_APPLY)
  {
    Term fun = r0;
    Term arg = r1;
    WL_OPEN
    Fid f    = (Fid)term_aux(fun);
    u32 war  = fid_arity(f) - 1;
    Loc a    = term_loc(fun);
    WL_LOAD(a, war)
    spare_free(e, cls_fit(war), a);
    WL_LAST(arg)
    WL_DYN(f);
  }}

  WL_CASE(FID_EXIT)
  {
    u32  n = rn;
    Term rv[WL_RESW];
    WL_SAVE(rv)
    WL_OPEN
    if (err_seen(e.mem)) {
      return 0;
    }
    sp -= 2 * LANE_STEP;
    Term cont = STK(0);
    u32  idx  = (u32)STK(1);
    if (cont != TERM_HOLE && fid_seqk((u32)term_aux(cont))) {
      Fid wf = (u32)term_aux(cont);
      Loc wa = term_loc(cont);
      u32 wn = fid_arity(wf);
      WL_FRAME(cont)
      WL_ARGS(wa, wn - n + 1)
      heap_free(e, cls_fit(wn + 2), wa);
      WL_TAKE(rv)
      WL_DYN(wf);
    }
    return task_deliver(e.mem, cont, idx, rv, n);
  }}

#if DEVICE
  default: {
    err_post(e.mem, ERR_FIDS);
    return 0;
  }
  }
  }
}
#endif

// Monk
// ====

// One turn on a ring: its head task below put0 runs (a growing lane skips
// a fork-free one). The host grows a row ring by ring and works a ring
// until it drains; a device lane does both.
INLINE u32 monk_step(Env e, Stk stk, Ring rg, u32 put0, bool seq, u32 base,
  u32 stride, Cur cur) {
  Corpus   H   = e.mem;
  DEV u32* get = ring_get(H, rg);
  if (*get == put0) {
    return 0;
  }
  DEV u32* lo = (DEV u32*)ring_slot(H, rg, *get);
  u32      hi = a32_load_acq(lo + 1);
  Term     t  = (((u64)hi << 32) | a32_load(lo)) & ~RFC_BIT;
  if ((hi >> 31) != ring_lap(*get) || (!seq && fid_nofk((u32)term_aux(t)))) {
    return 0;
  }
  a32_store(get, *get + 1);
  u32 spin = 0;
  for (;;) {
    Reply r = work_loop(e, stk, t, seq);
    if (r == 0) {
      return 2;
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      if (err_spun(H, &spin)) {
        return 2;
      }
      if (stride != 0 && fid_nofk((u32)term_aux(r))) {
        ring_push(H, ring_pick(base, stride, cur), r);
        return 2;
      }
      t      = r;
      seq    = false;
      stride = 0;
      continue;
    }
    task_deal(H, r, base, stride, cur);
    return 1;
  }
}

// Dev
// ===

// TG_HOLD words of threadgroup memory (lane 0's write keeps them) hold
// one group per Apple core: without them bitonic runs 1.35x, kmeans
// 1.19x, matmul 1.13x. A grow pass runs at most CUBE_T rounds, so a group
// that never fills still cuts at a kernel end.

#if DEVICE

INLINE void dev_cut(Env e) {
  if (err_seen(e.mem)) {
    return;
  }
  for (Cls c = 0; c < NCLS_ALL; c += 1) {
    u64 gen = (u64)KEEP(c) << c;
    while (ALC_LEN(e, c) >= gen) {
      Loc head = ALC_AT(e, c);
      Loc tail = head;
      for (u32 i = KEEP(c); --i;) {
        tail = e.mem[tail];
      }
      ALC_AT(e, c)    = e.mem[tail];
      ALC_LEN(e, c)  -= gen;
      e.mem[tail]     = 0;
      bank_push(e.mem, c, head);
    }
  }
}

// Pass 2, one group: each bank's [top, wr) slides onto rd, CUBE_T entries
// a step (loads, barrier, stores: rd <= top), off the host's pages.
INLINE void bank_pack(Corpus H, u32 lane) {
  for (Cls c = 0; c < NCLS_ALL; c += 1) {
    DEV Bank* b  = bank_at(H, c);
    u32       rd = b->rd;
    u32       n  = b->wr - b->top;
    for (u32 i = 0; i < n; i += CUBE_T) {
      Term v = i + lane < n ? H[b->off + b->top + i + lane] : 0;
      BAR();
      if (i + lane < n) {
        H[b->off + rd + i + lane] = v;
      }
    }
    BAR();
    if (lane == 0) {
      b->rd = b->wr = b->top = rd + n;
    }
  }
}

// One kernel, one pipeline: pass 0 grows the frontier (a task a lane a
// turn, votes between barriers), pass 1 works it (a lane drains its
// ring), pass 2 packs the banks; one call of monk_step, so the program
// compiles once.
#ifdef __METAL_VERSION__
kernel void bend_dev(Corpus H [[buffer(0)]], constant u32& pass [[buffer(1)]],
  threadgroup volatile u64* hold [[threadgroup(0)]],
  u32 grids [[threadgroups_per_grid]],
  u32 row [[threadgroup_position_in_grid]],
  u32 lane [[thread_position_in_threadgroup]]) {
#else
extern "C" __global__ void bend_dev(Corpus H, u32 pass) {
  extern __shared__ volatile u64 hold[];
  u32 grids = gridDim.x;
  u32 row   = blockIdx.x;
  u32 lane  = threadIdx.x;
#endif
  if (pass == 2) {
    bank_pack(H, lane);
    return;
  }
  u32  stride = grids == 1 ? CUBE_G : 1;
  u32  me     = row * CUBE_T + stride * lane;
  Ring rg     = pass ? ring_flip(me) : me;
  Env  e      = { H, H + ALC_OFF + me };
  Stk  stk    = (Stk)(H + STAK_OFF + me);
  if (lane == 0) {
    hold[0] = 0;
  }
  GA32 tg_cur, tg_grew, tg_has;
  g32_ini(&tg_cur);
  g32_ini(&tg_grew);
  g32_ini(&tg_has);
  BAR();
  u32 put0      = a32_load(ring_put(H, rg));
  u32 seen_has  = 0;
  u32 seen_grew = 0;
  for (u32 turn = 0; pass || turn < CUBE_T; turn += 1) {
    if (pass) {
      if (*ring_get(H, rg) == put0 || err_seen(H)) {
        break;
      }
    } else {
      put0 = a32_load(ring_put(H, rg));
      u32 vote = put0 != a32_load(ring_get(H, rg));
      if (lane == 0 && (err_seen(H) || root_done(H))) {
        vote = CUBE_T;
      }
      g32_add(&tg_has, vote);
      BAR();
      u32 has = g32_get(&tg_has);
      if (has - seen_has >= CUBE_T) {
        break;
      }
      seen_has = has;
    }
    u32 ran = monk_step(e, stk, rg, put0, pass, pass ? rg : row * CUBE_T,
      pass ? 0 : stride, &tg_cur);
    if (!pass) {
      if (ran == 1) {
        g32_add(&tg_grew, 1);
      }
      BARD();
      u32 grew = g32_get(&tg_grew);
      if (grew == seen_grew) {
        break;
      }
      seen_grew = grew;
    }
  }
  dev_cut(e);
}

#endif

// Window
// ======

// The Linux kit's fill, the Mac's window_msl in the runtime's dialect:
// a ! build carries window_dev in its cubin, a host build walks the
// pixels itself. An Image is a quadtree over 2^k x 2^k: a Qua at level
// i splits its square in four (tl, tr, bl, br), a Qua under the pixels
// follows tl, a Pix is 0xRRGGBB.
#if defined(__linux__) || defined(__CUDACC_RTC__)

INLINE u32 window_pix(Corpus H, Term t, u32 k, u32 x, u32 y) {
  for (u32 i = k; term_tag(t) == TAG_CTR;) {
    u32 j = 0;
    if (i > 0) {
      i -= 1;
      j = ((y >> i) & 1) * 2 + ((x >> i) & 1);
    }
    Loc l = term_rfc(t) ? H[term_loc(t)] >> 24 : term_loc(t);
    t = H[l + j];
  }
  return (u32)term_loc(t) & 0xFFFFFF;
}

#ifdef __CUDACC_RTC__
extern "C" __global__ void window_dev(Corpus H, Term root, u32 w, u32 h,
  u32 k, u32* out) {
  u32 x = blockIdx.x * blockDim.x + threadIdx.x;
  u32 y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x < w && y < h) {
    out[y * w + x] = window_pix(H, root, k, x, y);
  }
}
#endif

#endif

#if !DEVICE

// Row
// ===

static void row_grow(Env e, Stk stk, u32 base, u32 stride, u32 want) {
  Corpus H = e.mem;
  u32 cur = 0;
  for (;;) {
    u32 put0[CUBE_T];
    u32 has = 0;
    for (u32 i = 0; i < CUBE_T; i += 1) {
      put0[i] = *ring_put(H, base + i * stride);
      has += put0[i] != *ring_get(H, base + i * stride);
    }
    if (root_done(H) || has >= want) {
      return;
    }
    u32 grew = 0;
    u32 ran  = 0;
    for (u32 i = 0; i < CUBE_T && ran != 2; i += 1) {
      ran   = monk_step(e, stk, base + i * stride, put0[i], false, base,
        stride, &cur);
      grew += ran == 1;
    }
    if (grew == 0) {
      return;
    }
  }
}

// Pool
// ====

static void* pool_try(void* at, u64 bytes) {
  return mmap(at, bytes, PROT_READ | PROT_WRITE,
    MAP_PRIVATE | MAP_ANON | MAP_NORESERVE, -1, 0);
}

static void* pool_mmap(u64 bytes) {
  void* p = pool_try(NULL, bytes);
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static Term* pool_stack(void) {
  u64   len = 1ull << 31;
  char* p   = pool_mmap(len + 16384 + SIGSTKSZ);
  if (mprotect(p + len, 16384, PROT_NONE) != 0) {
    err_fail("stack guard failed");
  }
  stack_t ss = { .ss_sp = p + len + 16384, .ss_size = SIGSTKSZ };
  sigaltstack(&ss, NULL);
  struct sigaction sa = { .sa_handler = err_trap, .sa_flags = SA_ONSTACK };
  sigaction(SIGSEGV, &sa, NULL);
  sigaction(SIGBUS, &sa, NULL);
  return (Term*)p;
}

static void* pool_work(void* arg) {
  Term* stk  = pool_stack();
  u64   seen = 0;
  for (;;) {
    pthread_mutex_lock(&pool_lock);
    while (atomic_load_explicit(&pool_tick, memory_order_acquire) == seen) {
      pthread_cond_wait(&pool_wake, &pool_lock);
    }
    pthread_mutex_unlock(&pool_lock);
    seen = atomic_load_explicit(&pool_tick, memory_order_acquire);
    Env e = { CORPUS, ALC[1 + (u32)(uintptr_t)arg] };
    for (;;) {
      u32 r = atomic_fetch_add_explicit(&pool_row, 1, memory_order_relaxed);
      if (r >= (pool_grow ? CUBE_G : LANES / LINE)) {
        break;
      }
      if (pool_grow) {
        row_grow(e, stk, r * CUBE_T, 1, CUBE_T);
      } else {
        for (u32 i = 0; i < LINE; i += 1) {
          Ring rg   = r * LINE + i;
          u32  put0 = a32_load(ring_put(e.mem, rg));
          while (*ring_get(e.mem, rg) != put0 && !err_seen(e.mem)) {
            monk_step(e, stk, rg, put0, true, rg, 0, NULL);
          }
        }
      }
    }
    u32 done = atomic_fetch_add_explicit(&pool_done, 1, memory_order_release);
    if (done + 1 == pool_size) {
      pthread_mutex_lock(&pool_lock);
      pthread_cond_broadcast(&pool_wake);
      pthread_mutex_unlock(&pool_lock);
    }
  }
}

OUTLINE void pool_open(void) {
  static bool up;
  if (up) {
    return;
  }
  up = true;
  for (u32 w = 0; w < pool_size; w += 1) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, pool_work, (void*)(uintptr_t)w)) {
      err_fail("pthread_create");
    }
  }
}

// The CPUs this process may use: affinity mask under the cgroup quota
static int cpu_read(const char* path, long* a, long* b) {
  FILE* f = fopen(path, "r");
  int   n = f == NULL ? 0 : fscanf(f, "%ld %ld", a, b);
  if (f != NULL) {
    fclose(f);
  }
  return n;
}

static long cpu_count(void) {
  long n = sysconf(_SC_NPROCESSORS_ONLN);
#ifdef __linux__
  cpu_set_t set;
  if (sched_getaffinity(0, sizeof set, &set) == 0) {
    n = CPU_COUNT(&set);
  }
  long q = 0;
  long p = 0;
  if (cpu_read("/sys/fs/cgroup/cpu.max", &q, &p) != 2) {
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_quota_us", &q, &p);
    cpu_read("/sys/fs/cgroup/cpu/cpu.cfs_period_us", &p, &p);
  }
  if (q > 0 && p > 0 && (q + p - 1) / p < n) {
    n = (q + p - 1) / p;
  }
#endif
  return n;
}

OUTLINE void pool_turn(bool grow) {
  pool_grow = grow;
  atomic_store_explicit(&pool_row, 0, memory_order_relaxed);
  atomic_store_explicit(&pool_done, 0, memory_order_relaxed);
  pthread_mutex_lock(&pool_lock);
  atomic_fetch_add_explicit(&pool_tick, 1, memory_order_release);
  pthread_cond_broadcast(&pool_wake);
  while (atomic_load_explicit(&pool_done, memory_order_acquire) < pool_size) {
    pthread_cond_wait(&pool_wake, &pool_lock);
  }
  pthread_mutex_unlock(&pool_lock);
}

// Gpu
// ===

// gpu_make compiles the device program and, given a path, writes it as
// <binary>.gpu (--gpu-build, run by bend -o): Metal's binary archive
// of the pipeline (keyed by the compiled function, so a wrong file
// misses), CUDA's cubin behind a hash of the text. A launch loads it,
// else notes and compiles (Metal's OS cache keeps that pipeline; CUDA
// writes the file).

static const char* gpu_path(void) {
  static char path[4096];
  u32 n = sizeof path - 8;
#ifdef __APPLE__
  _NSGetExecutablePath(path, &n);
#else
  path[readlink("/proc/self/exe", path, n)] = 0;
#endif
  return strcat(path, ".gpu");
}

static void gpu_note(const char* path) {
  fprintf(stderr, "bend: compiling the GPU program (%s is missing or"
    " stale)\n", path);
}

#if !BEND_CUDA
#define gpu_map pool_mmap
#endif

#if BEND_METAL || BEND_CUDA

static void gpu_kernel(u32 pass, u32 groups);

static void gpu_run(u32 f) {
  if (f < CUBE_T) {
    gpu_kernel(0, 1);
  }
  if (f < LANES) {
    gpu_kernel(0, CUBE_G);
  }
  gpu_kernel(1, CUBE_G);
  gpu_kernel(2, 1);
}

#endif

#if BEND_METAL

static bool gpu_probe(void) {
  return (gpu_dev = MTLCreateSystemDefaultDevice()) != nil;
}

static MTLComputePipelineDescriptor* gpu_desc(void) {
  NSError* err = nil;
  MTLCompileOptions* opts = [MTLCompileOptions new];
  opts.mathMode = MTLMathModeSafe;
  opts.preprocessorMacros = @{ @"CUBE_LOG": @(CUBE_LOG) };
  id<MTLLibrary> lib = [gpu_dev newLibraryWithSource:@(BEND_SRC) options:opts
    error:&err];
  if (!lib) {
    err_fail([[err localizedDescription] UTF8String]);
  }
  MTLComputePipelineDescriptor* d = [MTLComputePipelineDescriptor new];
  d.computeFunction = [lib newFunctionWithName:@"bend_dev"];
  return d;
}

static bool gpu_make(const char* path) {
  NSError* err = nil;
  id<MTLBinaryArchive> ar = [gpu_dev
    newBinaryArchiveWithDescriptor:[MTLBinaryArchiveDescriptor new] error:&err];
  if (![ar addComputePipelineFunctionsWithDescriptor:gpu_desc() error:&err]) {
    err_fail([[err localizedDescription] UTF8String]);
  }
  return [ar serializeToURL:[NSURL fileURLWithPath:@(path)] error:&err];
}

static id<MTLComputePipelineState> gpu_pipe(MTLComputePipelineDescriptor* d,
  id<MTLBinaryArchive> ar) {
  NSError* err = nil;
  d.binaryArchives = ar ? @[ar] : @[];
  id<MTLComputePipelineState> pso = [gpu_dev
    newComputePipelineStateWithDescriptor:d
    options:ar ? MTLPipelineOptionFailOnBinaryArchiveMiss : 0 reflection:nil
    error:&err];
  if (!pso && !ar) {
    err_fail([[err localizedDescription] UTF8String]);
  }
  return pso;
}

static u64 gpu_span(void) {
  u64 span = [gpu_dev recommendedMaxWorkingSetSize];
  u64 most = [gpu_dev maxBufferLength];
  span = span < most ? span : most;
  return span < (2ull << 30) ? span : 2ull << 30;
}

static void gpu_load(u64 bytes) {
  gpu_buf = [gpu_dev newBufferWithBytesNoCopy:CORPUS length:bytes
    options:MTLResourceStorageModeShared
      | MTLResourceHazardTrackingModeUntracked deallocator:nil];
  if (!gpu_buf) {
    err_fail("the GPU span is more than the device has");
  }
  @autoreleasepool {
    gpu_que = [gpu_dev newCommandQueue];
    const char* path = gpu_path();
    MTLBinaryArchiveDescriptor* ad = [MTLBinaryArchiveDescriptor new];
    ad.url = [NSURL fileURLWithPath:@(path)];
    MTLComputePipelineDescriptor* d = gpu_desc();
    id<MTLBinaryArchive> ar = [gpu_dev newBinaryArchiveWithDescriptor:ad
      error:nil];
    gpu_pso = ar ? gpu_pipe(d, ar) : nil;
    if (!gpu_pso) {
      gpu_note(path);
      gpu_pso = gpu_pipe(d, nil);
    }
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  [gpu_enc setComputePipelineState:gpu_pso];
  [gpu_enc setBuffer:gpu_buf offset:0 atIndex:0];
  [gpu_enc setBytes:&pass length:sizeof pass atIndex:1];
  [gpu_enc setThreadgroupMemoryLength:TG_HOLD * 8 atIndex:0];
  [gpu_enc dispatchThreadgroups:MTLSizeMake(groups, 1, 1)
    threadsPerThreadgroup:MTLSizeMake(CUBE_T, 1, 1)];
  [gpu_enc memoryBarrierWithScope:MTLBarrierScopeBuffers];
}

static void gpu_pass(u32 f) {
  @autoreleasepool {
    id<MTLCommandBuffer> cb = [gpu_que commandBuffer];
    gpu_enc = [cb computeCommandEncoder];
    gpu_run(f);
    [gpu_enc endEncoding];
    [cb commit];
    [cb waitUntilCompleted];
    if ([cb error]) {
      err_fail([[[cb error] localizedDescription] UTF8String]);
    }
  }
}

#elif BEND_CUDA

// the bag from the device: a group of 128 lanes per 64 KB of L2, a power of
// two from 16 to 128 groups. Apple keeps the 128 the bag was tuned on: on an
// M4 (10 cores) 32 groups ran bitonic 1.85 -> 1.29 s, but the light one-pass
// benches 1.25x, their lanes four times fewer.
static void gpu_shape(int units) {
  CUBE_LOG = 31 - CLZ(units < 16 ? 16 : units > 128 ? 128 : units);
}

static bool gpu_probe(void) {
  int       managed = 0;
  CUcontext ctx;
  // one stream, so one hardware queue: the default 8 each cost a channel
  // at context creation and teardown, about half of the startup
  setenv("CUDA_DEVICE_MAX_CONNECTIONS", "1", 0);
  if (cuInit(0) == CUDA_SUCCESS && cuDeviceGet(&gpu_dev, 0) == CUDA_SUCCESS) {
    cuDeviceGetAttribute(&managed,
      CU_DEVICE_ATTRIBUTE_CONCURRENT_MANAGED_ACCESS, gpu_dev);
  }
  int l2 = 1 << 23;
  cuDeviceGetAttribute(&l2, CU_DEVICE_ATTRIBUTE_L2_CACHE_SIZE, gpu_dev);
  gpu_shape(l2 >> 16);
  return managed != 0
    && cuDevicePrimaryCtxRetain(&ctx, gpu_dev) == CUDA_SUCCESS
    && cuCtxSetCurrent(ctx) == CUDA_SUCCESS;
}

static Corpus gpu_map(u64 bytes) {
  CUdeviceptr p = 0;
  if (cuMemAllocManaged(&p, bytes, CU_MEM_ATTACH_GLOBAL) != CUDA_SUCCESS) {
    err_fail("corpus reservation failed");
  }
#if CUDA_VERSION >= 13000
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION,
    (CUmemLocation){ CU_MEM_LOCATION_TYPE_DEVICE, gpu_dev });
#else
  cuMemAdvise(p, bytes, CU_MEM_ADVISE_SET_PREFERRED_LOCATION, gpu_dev);
#endif
  return (Corpus)(uintptr_t)p;
}

static u64 gpu_hash(void) {
  u64 key = 14695981039346656037ull ^ CUBE_LOG;
  for (const char* p = BEND_SRC; *p != 0; p += 1) {
    key = (key ^ (u8)*p) * 1099511628211ull;
  }
  return key;
}

static bool gpu_make(const char* path) {
  int cc[2] = {0, 0};
  cuDeviceGetAttribute(cc,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MAJOR, gpu_dev);
  cuDeviceGetAttribute(cc + 1,
    CU_DEVICE_ATTRIBUTE_COMPUTE_CAPABILITY_MINOR, gpu_dev);
  char arch[40];
  char bag[24];
  snprintf(arch, sizeof arch, "--gpu-architecture=sm_%d%d", cc[0], cc[1]);
  snprintf(bag, sizeof bag, "-DCUBE_LOG=%u", CUBE_LOG);
  const char* opts[] = { arch, bag, "--fmad=false", "-default-device" };
  nvrtcProgram prog;
  if (nvrtcCreateProgram(&prog, BEND_SRC, "bend.cu", 0, NULL, NULL)
    != NVRTC_SUCCESS) {
    err_fail("cannot compile the CUDA library");
  }
  if (nvrtcCompileProgram(prog, 4, opts) != NVRTC_SUCCESS) {
    size_t n = 0;
    nvrtcGetProgramLogSize(prog, &n);
    char* log = calloc(n + 1, 1);
    if (log != NULL && nvrtcGetProgramLog(prog, log) == NVRTC_SUCCESS) {
      fprintf(stderr, "%s\n", log);
    }
    err_fail("cannot compile the CUDA library");
  }
  size_t len = 0;
  nvrtcGetCUBINSize(prog, &len);
  char* bin = malloc(len);
  if (bin == NULL || nvrtcGetCUBIN(prog, bin) != NVRTC_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  nvrtcDestroyProgram(&prog);
  u64   key = gpu_hash();
  FILE* out = path == NULL ? NULL : fopen(path, "wb");
  bool  ok  = out != NULL && fwrite(&key, 8, 1, out) == 1
    && fwrite(bin, 1, len, out) == len && fclose(out) == 0;
  if (cuModuleLoadData(&gpu_lib, bin) != CUDA_SUCCESS) {
    err_fail("cannot load the CUDA library");
  }
  free(bin);
  return path == NULL || ok;
}

static u64 gpu_span(void) {
  size_t span = 0;
  cuDeviceTotalMem(&span, gpu_dev);
  return span;
}

static void gpu_load(u64 bytes) {
  const char* path = gpu_path();
  int         fd   = open(path, O_RDONLY);
  struct stat st   = { 0 };
  u64         key  = 0;
  char*       bin  = fd < 0 || fstat(fd, &st) != 0 || st.st_size <= 8 ? NULL
    : mmap(NULL, st.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
  if (bin != NULL && bin != MAP_FAILED) {
    memcpy(&key, bin, 8);
  }
  if (key != gpu_hash()
    || cuModuleLoadData(&gpu_lib, bin + 8) != CUDA_SUCCESS) {
    gpu_note(path);
    gpu_make(path);
  }
  if (cuModuleGetFunction(&gpu_pso, gpu_lib, "bend_dev") != CUDA_SUCCESS) {
    err_fail("cannot load the GPU program");
  }
}

static void gpu_kernel(u32 pass, u32 groups) {
  void* args[] = { &CORPUS, &pass };
  if (cuLaunchKernel(gpu_pso, groups, 1, 1, CUBE_T, 1, 1, TG_HOLD * 8, NULL,
    args, NULL) != CUDA_SUCCESS) {
    err_fail("device launch failed");
  }
}

static void gpu_pass(u32 f) {
  gpu_run(f);
  if (cuCtxSynchronize() != CUDA_SUCCESS) {
    err_fail("device fault");
  }
}

#else

#define gpu_probe() false
#define gpu_make(p) true
#define gpu_span()  0
#define gpu_load(b)
#define gpu_pass(f)

#endif

// Cube
// ====

static void cube_run(Corpus H, bool gpu) {
  for (;;) {
    u32 f = a32_load(a32_at(H, H_CURSOR));
    a32_store(a32_at(H, H_CURSOR), 0);
    if (root_done(H)) {
      return;
    }
    if (f == 0) {
      err_fail("frontier drained without a result");
    }
    if (gpu) {
      gpu_pass(f);
    } else {
      // Each worker needs a row; a row has CUBE_T / LINE units.
      if (f < pool_size) {
        row_grow((Env){ H, ALC[0] }, io_stk, 0, CUBE_G, pool_size);
      }
      if (f < CUBE) {
        pool_turn(true);
      }
      pool_turn(false);
    }
    u32 ec = a32_load(a32_at(H, H_ERROR_CODE));
    if (ec != 0) {
      err_post(H, ec);
    }
  }
}

// Corpus
// ======

// The cores map 8 GiB at a high base and double it in place, a hint then
// a check (MAP_FIXED would replace a neighbour), so one base holds every
// Loc and a run pays for the room it reaches. The banks lie past the pages
// and move up at each step. The GPU maps its whole span once.

static u64 corpus_size;

static void* corpus_map(u64 size) {
  u64   hint = 1ull << 45;
  void* p    = pool_try((void*)hint, size);
  while (p != (void*)hint && hint > size) {
    if (p != MAP_FAILED) {
      munmap(p, size);
    }
    hint /= 2;
    p     = pool_try((void*)hint, size);
  }
  if (p == MAP_FAILED) {
    err_fail("reservation failed");
  }
  return p;
}

static void corpus_lay(Corpus H, u64 size) {
  u64 span = size / 8;
  u64 cap  = span > HEAP_OFF ? (span - HEAP_OFF) / (PAGE_LEN + 10) : 0;
  if (cap <= CUBE) {
    err_fail("the GPU span is under the rings, stacks and a page per lane");
  }
  cap = cap < ~0u ? cap : ~0u - 1;
  u64 at = HEAP_OFF + (cap << PAGE_BITS);
  for (u32 c = 0; c < NCLS_ALL; c += 1) {
    Bank* b = bank_at(H, c);
    memcpy(H + at, H + b->off, b->wr * sizeof(u64));
    b->off  = at;
    at     += 2 * (cap >> ((c < NCLS ? NCLS : c) - PAGE_BITS));
  }
  corpus_size = size;
  a32_store_rel(a32_at(H, H_CAP), (u32)cap);
}

static bool corpus_grow(Corpus H, u64 need) {
  bool ok = true;
  LOCK(bank_lock);
  while (ok && need > a32_load(a32_at(H, H_CAP))) {
    u64   more = corpus_size;
    char* at   = (char*)H + more;
    void* got  = io_gpu || more >= 1ull << 43 ? MAP_FAILED
      : pool_try(at, more);
    ok = got == at;
    if (ok) {
      corpus_lay(H, more * 2);
    } else if (got != MAP_FAILED) {
      munmap(got, more);
    }
  }
  UNLOCK(bank_lock);
  return ok;
}

static Corpus corpus_setup(bool gpu, long threads, u64 bytes) {
  io_gpu     = gpu;
  KEEP_WORDS = gpu ? CHUNK : CAP_WORDS;
  u64 dflt   = gpu ? gpu_span() : 1ull << 33;
  u64 size   = (gpu && bytes != 0 ? bytes : dflt) & ~16383ull;
  CORPUS     = gpu ? gpu_map(size) : corpus_map(size);
  Corpus H   = CORPUS;
#if BEND_CUDA
  if (gpu) {
    cuMemsetD8((CUdeviceptr)(uintptr_t)H, 0, STAK_OFF * 8);
    cuCtxSynchronize();
  }
#endif
  memcpy(H + STAT_OFF, STAT_IMG, STAT_LEN * sizeof(u64));
  corpus_lay(H, size);
  a32_store(a32_at(H, H_BUMP), 1);
  if (gpu) {
    gpu_load(size);
  }
  pool_size = threads < 1 ? 1 : threads < CUBE_T ? threads : CUBE_T;
  return H;
}

OUTLINE Term corpus_eval(Corpus H, Term t) {
  Env  e = { H, ALC[0] };
  Term rv[WL_RESW];
  for (;;) {
    Reply r = work_loop(e, io_stk, t, !BANGS
      && (pool_size == 1 || fid_nofk((u32)term_aux(t))));
    if (r == 0) {
      if (root_done(H)) {
        break;
      }
      err_fail("solo delivery lost");
    }
    if ((u32)H[task_tail(r) + 1] == 0) {
      t = r;
      if (io_gpu && fid_bangs((u32)term_aux(t))) {
        Loc  tl   = task_tail(t);
        Term cont = H[tl];
        u32  idx  = (u32)(H[tl + 1] >> 32) & 0xFFFF;
        H[tl]     = TERM_HOLE;
        a32_store(a32_at(H, H_CURSOR), 1);
        ring_push(H, 0, t);
        cube_run(H, true);
        Term p = task_deliver(H, cont, idx, rv, root_take(H, rv));
        if (root_done(H)) {
          break;
        }
        if (p == 0) {
          err_fail("seam delivery lost");
        }
        t = p;
      }
      continue;
    }
    task_deal(H, r, 0, 0, (Cur)0);
    pool_open();
    cube_run(H, false);
    break;
  }
  root_take(H, rv);
  return rv[0];
}

// Io
// ==

#include <arpa/inet.h>
#include <errno.h>
#include <fcntl.h>
#include <netinet/in.h>
#include <sys/socket.h>

#define IO_READ 1
#define IO_TIME 2
#define IO_PARK TERM_HOLE

// A handle is its host value, a descriptor or a pointer, packed in one
// word (a pointer split over the aux and loc bits). Its type is a law of
// base, opaque and linear: a program cannot forge, copy or reuse one, so
// nothing stands between the value and the host.
#define io_hand(v)   term_make(TAG_PAK, (u64)(v) >> 40, (u64)(v) & LOC_MASK)
#define io_hand_v(t) (((u64)term_aux(t) << 40) | term_loc(t))

struct IoWork;
typedef void (*IoCall)(struct IoWork* w);
typedef Term (*IoPack)(Env e, struct IoWork* w);

// IoWork ::=
//   | IoWork(hand, made, word, size, data, text, code, call, pack)
typedef struct IoWork {
  intptr_t hand;
  intptr_t made;
  u32      word;
  u64      size;
  char*    data;
  char*    text;
  u32      code;
  IoCall   call;
  IoPack   pack;
} IoWork;

typedef Term (*Effect)(Env e, Term* f, IoWork* w);

// IoEff ::=
//   | IoEff(run, ask)
typedef struct {
  Effect run;
  u32    ask;
} IoEff;

static IoEff io_eff_rows[1 << 16];
static u32   io_live;

static u64 io_tick(void) {
  struct timespec ts;
  clock_gettime(CLOCK_MONOTONIC, &ts);
  return (u64)ts.tv_sec * 1000000000ull + (u64)ts.tv_nsec;
}

OUTLINE void* io_mem(void* mem) {
  if (mem == NULL) {
    err_fail("host allocation failed");
  }
  return mem;
}

static int io_sys_addr(const char* host, u32 port, struct sockaddr_in* at) {
  memset(at, 0, sizeof(*at));
  at->sin_family = AF_INET;
  at->sin_port   = htons((uint16_t)port);
  for (const char* p = host; *p != 0; p += 1) {
    bool zero = *p == '0' && p[1] >= '0' && p[1] <= '9';
    if ((p == host || p[-1] == '.') && zero) {
      return -1;
    }
  }
  return port > 65535 || inet_pton(AF_INET, host, &at->sin_addr) != 1
    ? -1 : 0;
}

// The program's arguments (IO.args).
static int    io_argc = 0;
static char** io_argv = NULL;

static void io_eff(u32 cid, Effect run, u32 need) {
  IoEff row = { run, need };
  io_eff_rows[cid] = row;
}

static u64 io_sys_end(IoWork* w, ssize_t n) {
  w->code = n < 0 ? (u32)errno : 0;
  return n < 0 ? 0 : (u64)n;
}

// A computation's activation for its whole life: cont over item is its
// next request; parked, work.word and time are its fd and deadline, evts
// what the fd must be ready for, and work.pack resumes it (io_exec runs
// cont, the request); work leads, so an effect's IoWork* is its activation.
// IoAct ::=
//   | IoAct(work, cont, item, time, evts, next)
typedef struct IoAct {
  IoWork        work;
  Term          cont;
  Term          item;
  u64           time;
  short         evts;
  struct IoAct* next;
} IoAct;

// IoQue ::=
//   | IoQue(head, last)
typedef struct {
  IoAct* head;
  IoAct* last;
} IoQue;

static IoQue io_runs;
static IoQue io_park;
static IoQue io_jobs;

static void io_push(IoQue* q, IoAct* a) {
  a->next = NULL;
  *(q->head == NULL ? &q->head : &q->last->next) = a;
  q->last = a;
}

static IoAct* io_pop(IoQue* q) {
  IoAct* a = q->head;
  q->head  = a->next;
  return a;
}

static void io_spawn(Term m) {
  IoAct* a = io_mem(calloc(1, sizeof(IoAct)));
  a->cont  = m;
  a->item  = term_clo(FID_IO_EMIT, 0);
  io_push(&io_runs, a);
  io_live += 1;
}

// Parks the effect's activation until fd is ready for evts (POLLIN or
// POLLOUT; 0 for no fd), or until time (a tick; 0 for no deadline),
// whichever comes first; the loop then calls more on its thread, whose
// value readies the activation, or IO_PARK, a re-park.
static Term io_wait_on(IoWork* w, int fd, short evts, u64 time, IoPack more) {
  IoAct* a     = (IoAct*)w;
  a->work.word = (u32)fd;
  a->work.pack = more;
  a->time      = time;
  a->evts      = evts;
  io_push(&io_park, a);
  return IO_PARK;
}

// the deadline a parked activation waits for (0 for none)
static u64 io_wait_time(IoWork* w) {
  return ((IoAct*)w)->time;
}

OUTLINE void io_out(FILE* h, const char* data, u64 len) {
  if (fwrite(data, 1, len, h) != len) {
    err_fail("a short write on a standard stream");
  }
}

OUTLINE void io_sync(void) {
  if (fflush(stdout) != 0) {
    err_fail("a short write on a standard stream");
  }
}

// the edge is UTF-8
static u64 io_utf8(char* buf, u64 c) {
  u64 k = c < 0x80 ? 1 : c < 0x800 ? 2 : c < 0x10000 ? 3 : 4;
  for (u64 i = k; i > 1; i -= 1) {
    buf[i - 1] = (char)(0x80 | (c & 0x3F));
    c >>= 6;
  }
  buf[0] = (char)(k == 1 ? c : (0xF00 >> k) | c);
  return k;
}

// io_cbuf writes a String (cons SCon) as UTF-8, or a List (cons Con) as
// its bytes, with no UTF-8: NULL if a value is past 255.
OUTLINE char* io_cbuf(Env e, Term s, u64* len, u64 cons) {
  u64   cap = 64;
  u64   n   = 0;
  u64   bad = 0;
  char* buf = io_mem(malloc(cap));
  while (term_aux(s) == cons) {
    Term fb[2];
    spare_free(e, cls_fit(2), ctr_take(e, s, 2, fb));
    if (n + 5 > cap) {
      cap *= 2;
      buf = io_mem(realloc(buf, cap));
    }
    if (cons == CID_SCON) {
      n += io_utf8(buf + n, fb[0]);
    } else {
      bad |= fb[0] > 255;
      buf[n++] = (char)fb[0];
    }
    s = fb[1];
  }
  buf[n] = 0;
  *len = n;
  if (bad) {
    free(buf);
    return NULL;
  }
  return buf;
}

#define io_cstr(e, s, len) io_cbuf(e, s, len, CID_SCON)

OUTLINE void io_errs(Env e, Term s) {
  u64   n    = 0;
  char* text = io_cstr(e, s, &n);
  io_sync();
  io_out(stderr, text, n);
  io_out(stderr, "\n", 1);
  free(text);
}

#define io_nul(s, n) (strlen(s) != (n))

#define io_seal(e, t, cid) (cid_hot(cid) ? rfc_seal(e, t) : (t))

static Term io_node(Env e, u64 cid, Term a, Term b) {
  Loc l = heap_alloc(e, 1);
  e.mem[l]     = io_seal(e, a, cid);
  e.mem[l + 1] = io_seal(e, b, cid);
  return term_ctr(cid, l);
}

// Bytes cross the IO boundary without UTF-8 decoding.
static Term io_list(Env e, const char* p, u64 n) {
  Term xs = term_pak(CID_NIL, 0);
  for (u64 i = n; i > 0; i -= 1) {
    xs = io_node(e, CID_CON, (uint8_t)p[i - 1], xs);
  }
  return xs;
}

// io_str decodes UTF-8 as WHATWG does: the lead byte sets the count of
// continuation bytes and the range of the second; a byte that breaks the
// sequence (or the end) yields one U+FFFD and is read again as a lead.
static Term io_str(Env e, const char* p, u64 n) {
  Term s    = term_pak(CID_SNIL, 0);
  Loc  hole = 0;
  u64  c = 0, need = 0, lo = 0x80, hi = 0xBF;
  for (u64 i = 0; i < n || need > 0; i += 1) {
    u64 b = i < n ? (uint8_t)p[i] : 0x100;
    if (need > 0 && (b < lo || b > hi)) {
      need = 0;
      c    = 0xFFFD;
      i   -= 1;
    } else if (need > 0) {
      lo = 0x80;
      hi = 0xBF;
      c  = (c << 6) | (b & 0x3F);
      if (--need > 0) {
        continue;
      }
    } else if (b < 0x80) {
      c = b;
    } else if (b < 0xC2 || b > 0xF4) {
      c = 0xFFFD;
    } else {
      need = b < 0xE0 ? 1 : b < 0xF0 ? 2 : 3;
      lo   = b == 0xE0 ? 0xA0 : b == 0xF0 ? 0x90 : 0x80;
      hi   = b == 0xED ? 0x9F : b == 0xF4 ? 0x8F : 0xBF;
      c    = b & (0x3F >> need);
      continue;
    }
    Loc  l = heap_alloc(e, 1);
    Term t = term_ctr(CID_SCON, l);
    e.mem[l] = c;
    if (hole == 0) {
      s = t;
    } else {
      e.mem[hole] = io_seal(e, t, CID_SCON);
    }
    hole = l + 1;
  }
  if (hole != 0) {
    e.mem[hole] = io_seal(e, term_pak(CID_SNIL, 0), CID_SCON);
  }
  return s;
}

#define io_tup(e, a, b) io_node(e, CID_TUPLE, a, b)
#define io_done(e, v)   io_box(e, CID_DONE, v)

static Term io_box(Env e, u64 cid, Term v) {
  Loc l = heap_alloc(e, 0);
  e.mem[l] = io_seal(e, v, cid);
  return term_ctr(cid, l);
}

static Term io_err(Env e, u32 code, const char* text) {
  const char* s = text != NULL ? text : strerror((int)code);
  return io_tup(e, code, io_str(e, s, strlen(s)));
}

static Term io_fail(Env e, u32 code, const char* text) {
  return io_box(e, CID_FAIL, io_err(e, code, text));
}

static lock           io_gate = PTHREAD_MUTEX_INITIALIZER;
static pthread_cond_t io_bell = PTHREAD_COND_INITIALIZER;
static u32            io_busy;
static u32            io_size;
static int            io_wake_fd[2];

static void io_take(Env e) {
  IoAct*  acts[64];
  ssize_t n;
  while ((n = read(io_wake_fd[0], acts, sizeof acts)) > 0) {
    for (u32 i = 0; i < (u32)n / sizeof(IoAct*); i += 1) {
      IoAct* a = acts[i];
      a->item  = a->work.pack(e, &a->work);
      io_push(&io_runs, a);
      io_busy -= 1;
    }
  }
}

static void* io_help(void* arg) {
  for (;;) {
    pthread_mutex_lock(&io_gate);
    while (io_jobs.head == NULL) {
      pthread_cond_wait(&io_bell, &io_gate);
    }
    IoAct* a = io_pop(&io_jobs);
    pthread_mutex_unlock(&io_gate);
    a->work.call(&a->work);
    while (write(io_wake_fd[1], &a, sizeof a) != sizeof a) {
    }
  }
}

// A helper takes the effect's activation: call on its thread, then pack
// on the loop's, whose value readies the activation.
static Term io_work(IoWork* w, IoCall call, IoPack pack) {
  w->call  = call;
  w->pack  = pack;
  io_busy += 1;
  if (io_busy > io_size && io_size < IO_HELP) {
    pthread_t tid;
    if (pthread_create(&tid, NULL, io_help, NULL)) {
      err_fail("pthread_create");
    }
    pthread_detach(tid);
    io_size += 1;
  }
  pthread_mutex_lock(&io_gate);
  io_push(&io_jobs, (IoAct*)w);
  pthread_cond_signal(&io_bell);
  pthread_mutex_unlock(&io_gate);
  return IO_PARK;
}

// Runs the request in cont: the effect takes its fields (the node goes)
// and answers a value, which readies the activation, or IO_PARK, a moved.
static Term io_exec(Env e, IoWork* w) {
  IoAct* a = (IoAct*)w;
  Term   fs[256];
  u32    c = (u32)term_aux(a->cont);
  u32    n = cid_arity(c);
  spare_free(e, cls_fit(n), ctr_take(e, a->cont, n, fs));
  a->cont = fs[n - 1];
  return io_eff_rows[c].run(e, fs, w);
}

static void io_wait(Env e) {
  struct pollfd* fds = io_mem(malloc((io_live + 1) * sizeof *fds));
  u32 n    = 1;
  u64 soon = 0;
  int ms   = -1;
  fds[0].fd     = io_wake_fd[0];
  fds[0].events = POLLIN;
  for (IoAct* a = io_park.head; a != NULL; a = a->next) {
    if (a->time != 0) {
      soon = soon == 0 || a->time < soon ? a->time : soon;
    }
    if (a->evts != 0) {
      fds[n].fd     = (int)a->work.word;
      fds[n].events = a->evts;
      n += 1;
    }
  }
  if (soon != 0) {
    u64 now = io_tick();
    u64 gap = soon > now ? (soon - now) / 1000000 + 1 : 0;
    ms = gap > 0x7fffffff ? 0x7fffffff : (int)gap;
  }
  io_sync();
  while (poll(fds, n, ms) < 0) {
    if (errno != EINTR) {
      err_fail("the poller failed");
    }
  }
  if (fds[0].revents != 0) {
    io_take(e);
  }
  u64   now  = io_tick();
  u32   i    = 1;
  IoQue todo = io_park;
  io_park.head = NULL;
  io_park.last = NULL;
  while (todo.head != NULL) {
    IoAct* a   = io_pop(&todo);
    bool   due = (a->evts != 0 && fds[i].revents != 0)
      || (a->time != 0 && a->time <= now);
    i += a->evts != 0;
    if (!due) {
      io_push(&io_park, a);
      continue;
    }
    Term x = a->work.pack(e, &a->work);
    if (x != IO_PARK) {
      a->item = x;
      io_push(&io_runs, a);
    }
  }
  free(fds);
}

static int f32_text(char* buf, f32 v) {
  int n = 0;
  int p = 0;
  if (v != v) {
    return sprintf(buf, "nan");
  }
  for (; p < 9; p += 1) {
    n = snprintf(buf, 40, "%.*e", p, (double)v);
    if (strtof(buf, NULL) == v) {
      break;
    }
  }
  char* ep = strchr(buf, 'e');
  if (ep == NULL) {
    return n;
  }
  int ex = atoi(ep + 1);
  if (ex >= 21 || ex <= -7) {
    n = (int)(ep - buf) + sprintf(ep, "e%c%d", ex < 0 ? '-' : '+', abs(ex));
  } else if (ex <= p) {
    n = snprintf(buf, 40, "%.*f", p - ex, (double)v);
  } else {
    int s = *buf == '-';
    memmove(buf + s + 1, buf + s + 2, p);
    memset(buf + s + 1 + p, '0', ex - p);
    n = s + 1 + ex;
  }
  return n;
}

static Term f32_show(Env e, Term x) {
  char buf[40];
  return io_str(e, buf, f32_text(buf, f32_unbox(x)));
}

static Term f32_read(Env e, Term s) {
  u64 n = 0;
  char* text = io_cstr(e, s, &n);
  char* end;
  f32 v = strtof(text, &end);
  Term out = n > 0 && (u64)(end - text) == n && strpbrk(text, "xX(") == NULL
    ? io_box(e, CID_SOME, f32_rewrap(v)) : term_pak(CID_NONE, 0);
  free(text);
  return out;
}

// Show
// ====

#if MAIN_PURE

// A pure main's value, spelled as term_show spells it: d is a node of
// SHOW_DESC (see show_main), w the value's words. A boxed Data reads its
// arm by cid off a Term (packed, or a node), an inline one by tag off
// its words.
static void show_val(Env e, u32 d, const Term* w, char chain);

// char_show: an escape, a \u{hex}, else the code point in UTF-8
static void show_chr(u64 c, char q) {
  char b[4];
  int  k = c == 10 ? 'n' : c == 9 ? 't' : c == 13 ? 'r' : c == 0 ? '0'
    : c == 92 || c == (u64)q ? (int)c : 0;
  if (k != 0) {
    printf("\\%c", k);
  } else if (c < 32 || c == 127 || (c >= 0xD800 && c <= 0xDFFF)
    || c > 0x10FFFF) {
    printf("\\u{%llx}", (unsigned long long)c);
  } else {
    fwrite(b, 1, io_utf8(b, c), stdout);
  }
}

// The shortest text that reads back, as a literal: a point before an e
static void show_f32(u32 x) {
  char  buf[40];
  int   n  = f32_text(buf, f32_unbox(x));
  char* ep = memchr(buf, 'e', n);
  int   m  = ep == NULL ? n : (int)(ep - buf);
  buf[n] = 0;
  if (strpbrk(buf, ".ni") == NULL) {
    printf("%.*s.0%s", m, buf, buf + m);
  } else {
    fputs(buf, stdout);
  }
}

static void show_arr(Env e, u32 d, Term t, u32 lo, u32 c) {
  if (c > SHOW_DESC[d + 2]) {
    c -= 1;
    show_arr(e, d, t, lo, c);
    fputs(", ", stdout);
    show_arr(e, d, t, lo + (1u << c), c);
  } else {
    Term v[1u << c];
    for (u32 j = 0; j < 1u << c; j += 1) {
      v[j] = blk_read(e.mem, term_tag(t) == TAG_ARR, term_peek(e, t), lo + j);
    }
    show_val(e, SHOW_DESC[d + 1], v, 0);
  }
}

// chain is the bracket of the [a, b] or (a, b) this value continues, or
// 0: a Con or Nil spells a list, a Tuple a tuple, their tails continue
static void show_val(Env e, u32 d, const Term* w, char chain) {
  const u32* D = SHOW_DESC;
  Term one;
  char zs[4];
  u32  zn = 0;
  for (bool tail = true; tail;) switch (tail = false, D[d]) {
    case 0: printf("%u", (u32)w[0]); break;
    case 1: show_f32((u32)w[0]); break;
    case 2: printf("%llun", (unsigned long long)w[0]); break;
    case 3:
      putchar('\'');
      show_chr(D[d + 1] != 0 ? term_loc(w[0]) : w[0], '\'');
      putchar('\'');
      break;
    case 4:
      putchar('"');
      for (Term s = w[0]; term_aux(s) == CID_SCON;) {
        Loc l = term_peek(e, s);
        show_chr(e.mem[l], '"');
        s = e.mem[l + 1];
      }
      putchar('"');
      break;
    case 5: fputs("{==}", stdout); break;
    case 6:
      putchar('[');
      show_arr(e, d, w[0], 0, blk_cls(w[0]));
      putchar(']');
      break;
    default: {
      Term t   = w[0];
      bool box = D[d + 1] != 0;
      u32  key = box ? (u32)term_aux(t) : D[d + 2] > 1 ? (u32)t : 0;
      u32  a   = d + 3;
      for (u32 i = 0; box ? D[a + 1] != key : i != key; i += 1) {
        a += 3 + 2 * D[a + 2];
      }
      if (box) {
        one = term_loc(t);
        w   = term_tag(t) == TAG_PAK ? &one : e.mem + term_peek(e, t);
      }
      const char* k = SHOW_NAMES[D[a]];
      char o = '{';
      char z = '}';
      if (strcmp(k, "Con") == 0 || strcmp(k, "Nil") == 0) {
        o = '[';
        z = ']';
      } else if (strcmp(k, "Tuple") == 0) {
        o = '(';
        z = ')';
      }
      if (o == '{') {
        printf("%s{", k);
      } else if (chain != o) {
        putchar(o);
      }
      if (o == '{' || chain != o) {
        zs[zn++] = z;
      }
      for (u32 j = 0; j < D[a + 2]; j += 1) {
        if (o == '[' ? j == 0 && chain == o : j > 0) {
          fputs(", ", stdout);
        }
        if (j == 1 && o != '{') {
          tail  = true;
          chain = o;
          d     = D[a + 4 + 2 * j];
          w     = w + D[a + 3 + 2 * j];
        } else {
          show_val(e, D[a + 4 + 2 * j], w + D[a + 3 + 2 * j], 0);
        }
      }
    }
  }
  while (zn > 0) {
    putchar(zs[--zn]);
  }
}

#endif

// Current Base additions not yet implemented by this retained scheduler.
// Refuse on actual dispatch, before consuming any payload.
static const char* io_unavailable(u32 cid) {
  switch (cid) {
#ifdef CID_CHAN_TRY_SEND
    case CID_CHAN_TRY_SEND: return "native Chan.try_send is not implemented by the retained IO runtime";
#endif
#ifdef CID_CHAN_TRY_RECV
    case CID_CHAN_TRY_RECV: return "native Chan.try_recv is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_ACCEPT
    case CID_TCP_TRY_ACCEPT: return "native TCP.try_accept is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_SEND
    case CID_TCP_TRY_SEND: return "native TCP.try_send is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_SEND_BYTES
    case CID_TCP_TRY_SEND_BYTES: return "native TCP.try_send_bytes is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_RECV
    case CID_TCP_TRY_RECV: return "native TCP.try_recv is not implemented by the retained IO runtime";
#endif
#ifdef CID_TCP_TRY_RECV_BYTES
    case CID_TCP_TRY_RECV_BYTES: return "native TCP.try_recv_bytes is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_SEND_TO
    case CID_UDP_TRY_SEND_TO: return "native UDP.try_send_to is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_SEND_BYTES_TO
    case CID_UDP_TRY_SEND_BYTES_TO: return "native UDP.try_send_bytes_to is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_RECV_FROM
    case CID_UDP_TRY_RECV_FROM: return "native UDP.try_recv_from is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_TRY_RECV_BYTES_FROM
    case CID_UDP_TRY_RECV_BYTES_FROM: return "native UDP.try_recv_bytes_from is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_SEND_BYTES_TO
    case CID_UDP_SEND_BYTES_TO: return "native UDP.send_bytes_to is not implemented by the retained IO runtime";
#endif
#ifdef CID_UDP_RECV_BYTES_FROM
    case CID_UDP_RECV_BYTES_FROM: return "native UDP.recv_bytes_from is not implemented by the retained IO runtime";
#endif
    default: return "an alien request";
  }
}

// The continuation applied to the item is the next request.
static int io_step(Env e, IoAct* a) {
  // Yield only after a completed effect: the activation owns its next item.
  u64 deadline = io_tick() + 4000000ull;
  for (;;) {
    Loc  ap  = task_node(e, BEND_CLO_APPLY, TERM_HOLE, 0, 0);
    e.mem[ap]     = a->cont;
    e.mem[ap + 1] = a->item;
    Term req = corpus_eval(e.mem, term_tsk(BEND_CLO_APPLY, ap));
    u32  c   = (u32)term_aux(req);
    Loc  at  = term_peek(e, req);
    if (c == CID_EMIT) {
      term_drop(e, req);
      free(a);
      io_live -= 1;
      return -1;
    }
    if (c == CID_HALT) {
      io_errs(e, e.mem[at + 1]);
      return (int)(u32)e.mem[at];
    }
    if (io_eff_rows[c].run == NULL) {
      err_fail(io_unavailable(c));
    }
    u32 need = io_eff_rows[c].ask;
    u32 word = (u32)(need & IO_READ ? io_hand_v(e.mem[at]) : e.mem[at]);
    a->cont  = req;
    if (need != 0) {
      io_wait_on(&a->work, (int)word, need & IO_READ ? POLLIN : 0,
        need & IO_TIME ? io_tick() + (u64)word * 1000000ull : 0, io_exec);
      return -1;
    }
    Term x = io_exec(e, &a->work);
    if (x == IO_PARK) {
      return -1;
    }
    a->item = x;
    if (io_tick() >= deadline) {
      io_push(&io_runs, a);
      return -1;
    }
  }
}

OUTLINE int io_loop(Corpus H) {
  Env e = { H, ALC[0] };
  io_stk = pool_stack();
  signal(SIGPIPE, SIG_IGN);
  if (pipe(io_wake_fd) | fcntl(io_wake_fd[0], F_SETFL, O_NONBLOCK)) {
    err_fail("the event loop failed to open");
  }
  Term m = corpus_eval(H, term_tsk(MAIN_FID, task_node(e, MAIN_FID,
    TERM_HOLE, 0, 0)));
#if MAIN_PURE
  show_val(e, 0, H + H_ROOT_WORD, 0);
  putchar('\n');
  return 0;
#endif
  io_spawn(m);
  for (u32 n = 0;; n += 1) {
    if (io_runs.head == NULL) {
      if (io_live == 0) {
        return 0;
      }
      if (io_park.head == NULL && io_busy == 0) {
        io_sync();
        fprintf(stderr, "bend: deadlock: every computation waits on a"
          " channel\n");
        return 1;
      }
      io_wait(e);
      continue;
    }
    if (io_busy != 0) {
      io_take(e);
    }
    int code = io_step(e, io_pop(&io_runs));
    if (code >= 0) {
      return code;
    }
  }
}

// Chan
// ====

// ChanRow ::=
//   | ChanRow(gen, next, room, size, head, live, shut, ring, wait)
typedef struct {
  u32   gen;
  u32   next;
  u32   room;
  u32   size;
  u32   head;
  u32   live;
  u32   shut;
  Term* ring;
  IoQue wait;
} ChanRow;

// A channel is Data: its handle is copied and may outlive the row, so it
// names the row by index and generation, a freed row waits on a list and
// comes back one generation up, and a stale copy finds no row (closed).
static ChanRow* chan_rows;
static u32      chan_len;
static u32      chan_idle = ~0u;

#define chan_some(e, v) io_box(e, CID_SOME, v)
#define chan_done(e)    io_done(e, term_pak(CID_UNIT, 0))

static Term chan_open(u32 room) {
  u32 i = chan_idle;
  if (i != ~0u) {
    chan_idle = chan_rows[i].next;
  } else {
    if (chan_len == 1u << 24) {
      err_fail("more than 16777216 channels at once");
    }
    if ((chan_len & (chan_len - 1)) == 0) {
      chan_rows = io_mem(realloc(chan_rows,
        (chan_len == 0 ? 1 : 2 * chan_len) * sizeof(ChanRow)));
    }
    i = chan_len;
    chan_len += 1;
    chan_rows[i].gen = 0;
  }
  ChanRow* row = &chan_rows[i];
  row->gen  += 1;
  row->room  = room;
  row->size  = 0;
  row->head  = 0;
  row->live  = 1;
  row->shut  = 0;
  row->ring  = room == 0 ? NULL : io_mem(malloc(room * sizeof(Term)));
  row->wait.head = NULL;
  row->wait.last = NULL;
  return io_hand(((u64)row->gen << 24) | i);
}

static ChanRow* chan_at(Term t) {
  u64      v   = io_hand_v(t);
  u32      i   = (u32)v & 0xFFFFFF;
  ChanRow* row = i < chan_len ? &chan_rows[i] : NULL;
  return row != NULL && row->live && row->gen == (u32)(v >> 24) ? row : NULL;
}

// Parks the effect's activation on row with item: a sent value, or
// TERM_HOLE for a receiver.
static Term chan_park(ChanRow* row, IoWork* w, Term item) {
  IoAct* a = (IoAct*)w;
  a->item  = item;
  io_push(&row->wait, a);
  return IO_PARK;
}

static Term chan_wake(ChanRow* row, Term x) {
  IoAct* a  = io_pop(&row->wait);
  Term item = a->item;
  a->item   = x;
  io_push(&io_runs, a);
  return item;
}

static Term chan_take(Env e, ChanRow* row) {
  Term v = row->ring[row->head];
  row->head = (row->head + 1) % row->room;
  row->size -= 1;
  if (row->wait.head != NULL) {
    Term item = chan_wake(row, chan_done(e));
    row->ring[(row->head + row->size) % row->room] = item;
    row->size += 1;
  }
  return v;
}

static void chan_free(ChanRow* row) {
  free(row->ring);
  row->live = 0;
  row->next = chan_idle;
  chan_idle = (u32)(row - chan_rows);
}

static void chan_shut(Env e, ChanRow* row) {
  row->shut = 1;
  while (row->wait.head != NULL) {
    Term item = row->wait.head->item;
    Term x = item == TERM_HOLE ? term_pak(CID_NONE, 0)
      : io_box(e, CID_FAIL, item);
    chan_wake(row, x);
  }
  if (row->size == 0) {
    chan_free(row);
  }
}

// Foreign C ABI: current helpers coexist with the retained runtime's API.
// This section is host-only; device code and prior runtime calls keep their
// original Env-based helper. Only mem is read by term_peek/rfc_view.
INLINE Loc term_peek_corpus(Corpus H, Term t) {
  Env e = { H, NULL };
  return term_peek(e, t);
}
#define term_peek(H, t) _Generic((H), Env: term_peek, default: term_peek_corpus)((H), (t))
// This runtime permits shared blocks, so always follow its redirect cell.
#define blk_loc(H, t) term_peek((H), (t))

// New foreign sources register immediate effects with two arguments; the
// third argument is retained for existing vendored readiness/timer effects.
static void io_eff_default(u32 cid, Effect run) {
  io_eff(cid, run, 0);
}
#define BEND_IO_EFF_PICK(_1, _2, _3, F, ...) F
#define io_eff(...) BEND_IO_EFF_PICK(__VA_ARGS__, io_eff, io_eff_default, 0)(__VA_ARGS__)

// Requests
// ========

// IO
// ==

void io_print(const char* data, uint64_t len) {
  io_out(stdout, data, len);
  io_out(stdout, "\n", 1);
}

Term io_print_run(Env e, Term* f, IoWork* w) {
  uint64_t n = 0;
  char* text = io_cstr(e, f[0], &n);
  io_print(text, n);
  free(text);
  return term_pak(CID_UNIT, 0);
}

static void __attribute__((constructor)) io_print_use(void) {
  io_eff(CID_IO_PRINT, io_print_run, 0);
}


// Cli
// ===

static void cli_fail(const char* msg, const char* arg) {
  fprintf(stderr, "bend: %s%s\n", msg, arg != NULL ? arg : "");
  exit(1);
}

// Main
// ====

int main(int argc, char** argv) {
  long thr = 0;
  int  gpu = -1;
  u64  mem = 0;
  io_argv = argv + 1;
  for (int i = 1; i < argc; i += 1) {
    const char* a = argv[i];
    const char* v = i + 1 < argc ? argv[i + 1] : NULL;
    if (strcmp(a, "--") == 0) {
      while (i + 1 < argc) {
        io_argv[io_argc++] = argv[++i];
      }
    } else if (strcmp(a, "--help") == 0) {
      printf(CLI_HELP, argv[0]);
      return 0;
    } else if (strcmp(a, "--gpu-build") == 0) {
      if (gpu_probe() && !gpu_make(gpu_path())) {
        cli_fail("cannot write ", gpu_path());
      }
      return 0;
    } else if (strcmp(a, "--threads") == 0) {
      char* end = NULL;
      thr = v != NULL ? strtol(v, &end, 10) : 0;
      if (thr < 1 || end == NULL || *end != '\0') {
        cli_fail("expected a thread count of 1 or more after --threads", NULL);
      }
      i += 1;
    } else if (strcmp(a, "--gpu") == 0) {
      char*  end = NULL;
      double n   = v != NULL ? strtod(v, &end) : 0;
      u64    mul = end == NULL ? 0 : strcmp(end, "GB") == 0 ? 1ull << 30
        : strcmp(end, "MB") == 0 ? 1ull << 20 : 0;
      if (v != NULL && strcmp(v, "off") == 0) {
        gpu = 0;
      } else if (v != NULL && (strcmp(v, "on") == 0 || (mul != 0 && n > 0))) {
        gpu = 1;
        mem = (u64)(n * (double)mul);
      } else {
        cli_fail("expected on, off or a size like 4GB after --gpu", NULL);
      }
      i += 1;
    } else {
      io_argv[io_argc++] = argv[i];
    }
  }
  bool dev = gpu != 0 && BANGS != 0 && gpu_probe();
  if (gpu == 1 && BANGS != 0 && !dev) {
    cli_fail("--gpu on, but this binary found no GPU device", NULL);
  }
  Corpus H  = corpus_setup(dev, thr > 0 ? thr : cpu_count(), mem);
  int code  = io_loop(H);
  io_sync();
  return code;
}

#endif
