
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401be0 <nx_rt_pair_take2.cold>:
  401be0:	mov    $0x1,%edx
  401be5:	mov    %rbp,%rdi
  401be8:	mov    %r14,%rsi
  401beb:	callq  401100 <heap_hand>
  401bf0:	jmpq   40453f <nx_rt_pair_take2+0x3f>
  401bf5:	xor    %edx,%edx
  401bf7:	mov    %rbp,%rdi
  401bfa:	mov    %r14,%rsi
  401bfd:	callq  401100 <heap_hand>
  401c02:	jmpq   4045f4 <nx_rt_pair_take2+0xf4>
  401c07:	mov    -0x8(%rbp,%rdi,1),%r13
  401c0c:	mov    %rsi,%rdx
  401c0f:	mov    %r15,%rcx
  401c12:	mov    %rbp,%rdi
  401c15:	mov    %r14,%rsi
  401c18:	mov    (%r8),%r12
  401c1b:	callq  401471 <span_fade.constprop.0>
  401c20:	jmpq   40453f <nx_rt_pair_take2+0x3f>

Disassembly of section .fini:
