
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e10 <nx_list_reverse>:
  401e10:	endbr64 
  401e14:	push   %rbp
  401e15:	mov    %rsp,%rbp
  401e18:	sub    $0x38,%rsp
  401e1c:	push   %rbx
  401e1d:	push   %r12
  401e1f:	push   %r13
  401e21:	push   %r14
  401e23:	push   %r15
  401e25:	mov    %rdx,%rbx
  401e28:	mov    %rsi,%r14
  401e2b:	mov    %rdi,%r12
  401e2e:	callq  404600 <nx_rt_ir_heap>
  401e33:	mov    %r12,%rdi
  401e36:	mov    %rax,%r12
  401e39:	mov    %rdi,%r13
  401e3c:	callq  404670 <nx_rt_ir_alc>
  401e41:	mov    %r14,%rsi
  401e44:	mov    %r13,%rdi
  401e47:	xchg   %rax,%rbx
  401e49:	mov    %rax,%r15
  401e4c:	nopl   0x0(%rax)
  401e50:	mov    %rsi,-0x10(%rbp)
  401e54:	mov    %rsi,%rax
  401e57:	shr    $0x28,%rax
  401e5b:	and    $0xffff,%rax
  401e61:	cmp    $0x0,%rax
  401e65:	je     402077 <nx_list_reverse+0x267>
  401e6b:	cmp    $0x1,%rax
  401e6f:	jne    40206b <nx_list_reverse+0x25b>
  401e75:	movabs $0xffffffffff,%rax
  401e7f:	mov    %rsi,%r13
  401e82:	and    %rax,%r13
  401e85:	mov    %rsi,%r8
  401e88:	shr    $0x3f,%r8
  401e8c:	mov    %r8,-0x8(%rbp)
  401e90:	cmp    $0x1,%r8
  401e94:	je     401eab <nx_list_reverse+0x9b>
  401e96:	cmp    $0x310817f,%r13
  401e9d:	seta   %al
  401ea0:	movzbl %al,%eax
  401ea3:	mov    %r15,%rdx
  401ea6:	mov    %r13,%r15
  401ea9:	jmp    401f01 <nx_list_reverse+0xf1>
  401eab:	mov    %r13,%rsi
  401eae:	mov    %rdi,%r14
  401eb1:	callq  4046e0 <nx_rt_ir_view>
  401eb6:	mov    %r15,%rdx
  401eb9:	mov    %r14,%rdi
  401ebc:	mov    -0x10(%rbp),%rsi
  401ec0:	mov    -0x8(%rbp),%r8
  401ec4:	mov    %rax,%rcx
  401ec7:	and    $0xffffff,%rcx
  401ece:	cmp    $0x1,%rcx
  401ed2:	sete   %r9b
  401ed6:	movzbl %r9b,%r9d
  401eda:	mov    %rax,%rcx
  401edd:	shr    $0x18,%rcx
  401ee1:	cmp    $0x310817f,%rcx
  401ee8:	seta   %al
  401eeb:	movzbl %al,%eax
  401eee:	cmp    $0x0,%r9d
  401ef2:	mov    %r13,%r15
  401ef5:	cmovne %rcx,%r13
  401ef9:	mov    $0x0,%ecx
  401efe:	cmove  %ecx,%eax
  401f01:	mov    %r13,-0x30(%rbp)
  401f05:	cmp    $0x0,%eax
  401f08:	jne    401f33 <nx_list_reverse+0x123>
  401f0a:	mov    %rdi,%r13
  401f0d:	callq  4039c0 <nx_rt_rebuild2_c1_k0>
  401f12:	mov    %r13,%rdi
  401f15:	mov    %rax,%r14
  401f18:	mov    $0x0,%esi
  401f1d:	mov    %rdi,%r13
  401f20:	callq  4032f0 <nx_rt_fast_field>
  401f25:	mov    %r14,%rdx
  401f28:	mov    %r13,%rdi
  401f2b:	mov    %rax,%rsi
  401f2e:	jmpq   402063 <nx_list_reverse+0x253>
  401f33:	mov    %r13,%r14
  401f36:	shl    $0x3,%r14
  401f3a:	mov    %r12,%rax
  401f3d:	add    %r14,%rax
  401f40:	mov    %rax,-0x28(%rbp)
  401f44:	mov    (%r12,%r14,1),%rcx
  401f48:	mov    %rcx,-0x20(%rbp)
  401f4c:	mov    0x8(%r12,%r14,1),%rsi
  401f51:	mov    %rsi,-0x18(%rbp)
  401f55:	cmp    $0x1,%r8
  401f59:	jne    401fad <nx_list_reverse+0x19d>
  401f5b:	mov    (%rbx),%r8
  401f5e:	mov    %r15,%r9
  401f61:	shl    $0x3,%r9
  401f65:	mov    %r8,(%r12,%r9,1)
  401f69:	mov    %r15,(%rbx)
  401f6c:	mov    %rdx,%r15
  401f6f:	mov    0x100(%rbx),%rdx
  401f76:	add    $0x1,%rdx
  401f7a:	mov    %rdx,0x100(%rbx)
  401f81:	cmp    $0x8000,%rdx
  401f88:	jb     401faa <nx_list_reverse+0x19a>
  401f8a:	mov    %rdi,%r13
  401f8d:	callq  401c36 <nx_rt_ir_hand0>
  401f92:	mov    %r15,%rdx
  401f95:	mov    %r13,%rdi
  401f98:	mov    -0x30(%rbp),%r13
  401f9c:	mov    -0x18(%rbp),%rsi
  401fa0:	mov    -0x20(%rbp),%rcx
  401fa4:	mov    -0x28(%rbp),%rax
  401fa8:	jmp    401fad <nx_list_reverse+0x19d>
  401faa:	mov    %r15,%rdx
  401fad:	mov    %rdx,%r8
  401fb0:	shr    $0x38,%r8
  401fb4:	cmp    $0x2,%r8
  401fb8:	jne    40204b <nx_list_reverse+0x23b>
  401fbe:	mov    (%rbx),%r8
  401fc1:	cmp    $0x0,%r8
  401fc5:	je     401fef <nx_list_reverse+0x1df>
  401fc7:	mov    %r8,%r9
  401fca:	shl    $0x3,%r9
  401fce:	mov    (%r12,%r9,1),%r9
  401fd2:	mov    %r9,(%rbx)
  401fd5:	mov    %rdx,%r15
  401fd8:	mov    0x100(%rbx),%rdx
  401fdf:	sub    $0x1,%rdx
  401fe3:	mov    %rdx,0x100(%rbx)
  401fea:	mov    %r15,%rdx
  401fed:	jmp    402013 <nx_list_reverse+0x203>
  401fef:	mov    %rdx,%r15
  401ff2:	mov    %rdi,%r13
  401ff5:	callq  401c25 <nx_rt_ir_alloc0>
  401ffa:	mov    %r15,%rdx
  401ffd:	mov    %r13,%rdi
  402000:	mov    %rax,%r8
  402003:	mov    -0x30(%rbp),%r13
  402007:	mov    -0x18(%rbp),%rsi
  40200b:	mov    -0x20(%rbp),%rcx
  40200f:	mov    -0x28(%rbp),%rax
  402013:	mov    %r8,%r10
  402016:	shl    $0x3,%r10
  40201a:	movabs $0xffffffffff,%r9
  402024:	and    %rdx,%r9
  402027:	shl    $0x18,%r9
  40202b:	or     $0x1,%r9
  40202f:	mov    %r9,(%r12,%r10,1)
  402033:	shr    $0x28,%rdx
  402037:	shl    $0x28,%rdx
  40203b:	movabs $0x8000000000000000,%r9
  402045:	or     %r9,%rdx
  402048:	or     %r8,%rdx
  40204b:	mov    %rcx,(%r12,%r14,1)
  40204f:	mov    %rdx,0x8(%rax)
  402053:	movabs $0x200010000000000,%rax
  40205d:	mov    %r13,%rdx
  402060:	or     %rax,%rdx
  402063:	mov    %rdx,%r15
  402066:	jmpq   401e50 <nx_list_reverse+0x40>
  40206b:	mov    $0x1,%esi
  402070:	callq  402af0 <nx_rt_fail>
  402075:	jmp    40207a <nx_list_reverse+0x26a>
  402077:	mov    %r15,%rax
  40207a:	pop    %r15
  40207c:	pop    %r14
  40207e:	pop    %r13
  402080:	pop    %r12
  402082:	pop    %rbx
  402083:	leaveq 
  402084:	retq   

Disassembly of section .fini:
