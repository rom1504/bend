
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004028b0 <nx_list_reverse>:
  4028b0:	push   %rbp
  4028b1:	push   %r15
  4028b3:	push   %r14
  4028b5:	push   %r13
  4028b7:	push   %r12
  4028b9:	push   %rbx
  4028ba:	push   %rax
  4028bb:	lea    0x48c6(%rip),%rax        # 407188 <nx_context>
  4028c2:	cmp    %rax,%rdi
  4028c5:	jne    402bab <nx_list_reverse+0x2fb>
  4028cb:	testb  $0x1,0x48ae(%rip)        # 407180 <nx_active>
  4028d2:	je     402bab <nx_list_reverse+0x2fb>
  4028d8:	mov    %rdx,%rbx
  4028db:	mov    %rsi,%r8
  4028de:	movabs $0xff00000000000000,%r13
  4028e8:	movabs $0xffffffff80,%rax
  4028f2:	mov    0x488f(%rip),%r14        # 407188 <nx_context>
  4028f9:	mov    0x4890(%rip),%r15        # 407190 <nx_context+0x8>
  402900:	lea    0x7f(%rax),%rdi
  402904:	movabs $0x200000000000000,%r12
  40290e:	movabs $0x200010000000000,%rbp
  402918:	mov    %rdi,(%rsp)
  40291c:	jmp    40292b <nx_list_reverse+0x7b>
  40291e:	xchg   %ax,%ax
  402920:	mov    %rbx,0x8(%r14,%r10,8)
  402925:	or     %rbp,%r10
  402928:	mov    %r10,%rbx
  40292b:	mov    %r8,%rax
  40292e:	shr    $0x28,%rax
  402932:	cmp    $0x1,%ax
  402936:	jne    402b0b <nx_list_reverse+0x25b>
  40293c:	mov    %r8,%rax
  40293f:	and    %rdi,%rax
  402942:	test   %r8,%r8
  402945:	js     402970 <nx_list_reverse+0xc0>
  402947:	mov    (%r14,%rax,8),%r9
  40294b:	mov    0x8(%r14,%rax,8),%r8
  402950:	mov    %rax,%rcx
  402953:	cmp    $0x3108180,%rcx
  40295a:	jae    4029df <nx_list_reverse+0x12f>
  402960:	jmpq   402a16 <nx_list_reverse+0x166>
  402965:	data16 nopw %cs:0x0(%rax,%rax,1)
  402970:	mov    0x4(%r14,%rax,8),%ecx
  402975:	mov    (%r14,%rax,8),%edx
  402979:	mov    %edx,%esi
  40297b:	and    $0xffffff,%esi
  402981:	cmp    $0x1,%esi
  402984:	jne    402aba <nx_list_reverse+0x20a>
  40298a:	mov    (%r14,%rax,8),%esi
  40298e:	shl    $0x20,%rcx
  402992:	or     %rdx,%rcx
  402995:	shr    $0x18,%rcx
  402999:	mov    (%r14,%rcx,8),%r9
  40299d:	mov    0x8(%r14,%rcx,8),%r8
  4029a2:	mov    (%r15),%rdx
  4029a5:	mov    %rdx,(%r14,%rax,8)
  4029a9:	mov    %rax,(%r15)
  4029ac:	mov    0x100(%r15),%rax
  4029b3:	inc    %rax
  4029b6:	mov    %rax,0x100(%r15)
  4029bd:	cmpb   $0x1,0x1cb3c(%rip)        # 41f500 <KEEP_WORDS>
  4029c4:	jne    402ae8 <nx_list_reverse+0x238>
  4029ca:	cmp    $0x8000,%rax
  4029d0:	jae    402ae8 <nx_list_reverse+0x238>
  4029d6:	cmp    $0x3108180,%rcx
  4029dd:	jb     402a16 <nx_list_reverse+0x166>
  4029df:	mov    0x8(%r15),%rax
  4029e3:	mov    %rax,(%r14,%rcx,8)
  4029e7:	mov    %rcx,0x8(%r15)
  4029eb:	mov    0x108(%r15),%rax
  4029f2:	add    $0x2,%rax
  4029f6:	mov    %rax,0x108(%r15)
  4029fd:	cmpb   $0x1,0x1cafc(%rip)        # 41f500 <KEEP_WORDS>
  402a04:	jne    402aa1 <nx_list_reverse+0x1f1>
  402a0a:	cmp    $0x8000,%rax
  402a10:	jae    402aa1 <nx_list_reverse+0x1f1>
  402a16:	mov    0x8(%r15),%r10
  402a1a:	test   %r10,%r10
  402a1d:	je     402a6c <nx_list_reverse+0x1bc>
  402a1f:	mov    (%r14,%r10,8),%rax
  402a23:	mov    %rax,0x8(%r15)
  402a27:	addq   $0xfffffffffffffffe,0x108(%r15)
  402a2f:	mov    %r9,%rax
  402a32:	and    %r13,%rax
  402a35:	cmp    %r12,%rax
  402a38:	je     402a85 <nx_list_reverse+0x1d5>
  402a3a:	mov    %r9,(%r14,%r10,8)
  402a3e:	mov    %rbx,%rax
  402a41:	and    %r13,%rax
  402a44:	cmp    %r12,%rax
  402a47:	jne    402920 <nx_list_reverse+0x70>
  402a4d:	mov    %r14,%rdi
  402a50:	mov    %r15,%rsi
  402a53:	mov    %rbx,%rdx
  402a56:	mov    $0x1,%ecx
  402a5b:	callq  401168 <rfc_wrap>
  402a60:	mov    (%rsp),%rdi
  402a64:	mov    %rax,%rbx
  402a67:	jmpq   402920 <nx_list_reverse+0x70>
  402a6c:	mov    %r14,%rdi
  402a6f:	mov    %r15,%rsi
  402a72:	mov    $0x1,%edx
  402a77:	callq  401279 <heap_alloc_miss>
  402a7c:	mov    (%rsp),%rdi
  402a80:	mov    %rax,%r10
  402a83:	jmp    402a2f <nx_list_reverse+0x17f>
  402a85:	mov    %r14,%rdi
  402a88:	mov    %r15,%rsi
  402a8b:	mov    %r9,%rdx
  402a8e:	mov    $0x1,%ecx
  402a93:	callq  401168 <rfc_wrap>
  402a98:	mov    (%rsp),%rdi
  402a9c:	mov    %rax,%r9
  402a9f:	jmp    402a3a <nx_list_reverse+0x18a>
  402aa1:	mov    %r14,%rdi
  402aa4:	mov    %r15,%rsi
  402aa7:	mov    $0x1,%edx
  402aac:	callq  4011e8 <heap_hand>
  402ab1:	mov    (%rsp),%rdi
  402ab5:	jmpq   402a16 <nx_list_reverse+0x166>
  402aba:	shl    $0x20,%rcx
  402abe:	or     %rdx,%rcx
  402ac1:	shr    $0x18,%rcx
  402ac5:	mov    (%r14,%rcx,8),%r9
  402ac9:	mov    0x8(%r14,%rcx,8),%rax
  402ace:	mov    %r14,%rdi
  402ad1:	mov    %r15,%rsi
  402ad4:	mov    %r8,%rdx
  402ad7:	callq  40157f <span_fade>
  402adc:	mov    (%rsp),%rdi
  402ae0:	mov    %rax,%r8
  402ae3:	jmpq   402a16 <nx_list_reverse+0x166>
  402ae8:	mov    %r14,%rdi
  402aeb:	mov    %r15,%rsi
  402aee:	xor    %edx,%edx
  402af0:	callq  4011e8 <heap_hand>
  402af5:	mov    (%rsp),%rdi
  402af9:	cmp    $0x3108180,%rcx
  402b00:	jae    4029df <nx_list_reverse+0x12f>
  402b06:	jmpq   402a16 <nx_list_reverse+0x166>
  402b0b:	movzwl %ax,%eax
  402b0e:	test   %eax,%eax
  402b10:	jne    402b24 <nx_list_reverse+0x274>
  402b12:	mov    %rbx,%rax
  402b15:	add    $0x8,%rsp
  402b19:	pop    %rbx
  402b1a:	pop    %r12
  402b1c:	pop    %r13
  402b1e:	pop    %r14
  402b20:	pop    %r15
  402b22:	pop    %rbp
  402b23:	retq   
  402b24:	movabs $0x7e00000000000000,%r12
  402b2e:	test   %r12,%r8
  402b31:	sete   %al
  402b34:	cmp    $0xffffffffffffffff,%r8
  402b38:	sete   %cl
  402b3b:	or     %al,%cl
  402b3d:	mov    %r8,%rax
  402b40:	movabs $0xffffffff80,%rdx
  402b4a:	and    %rdx,%rax
  402b4d:	cmp    $0x3108180,%rax
  402b53:	setb   %al
  402b56:	or     %cl,%al
  402b58:	jne    402b68 <nx_list_reverse+0x2b8>
  402b5a:	mov    %r14,%rdi
  402b5d:	mov    %r15,%rsi
  402b60:	mov    %r8,%rdx
  402b63:	callq  402ed0 <term_drop>
  402b68:	test   %r12,%rbx
  402b6b:	sete   %al
  402b6e:	cmp    $0xffffffffffffffff,%rbx
  402b72:	sete   %cl
  402b75:	or     %al,%cl
  402b77:	movabs $0xffffffff80,%rax
  402b81:	and    %rbx,%rax
  402b84:	cmp    $0x3108180,%rax
  402b8a:	setb   %al
  402b8d:	or     %cl,%al
  402b8f:	jne    402b9f <nx_list_reverse+0x2ef>
  402b91:	mov    %r14,%rdi
  402b94:	mov    %r15,%rsi
  402b97:	mov    %rbx,%rdx
  402b9a:	callq  402ed0 <term_drop>
  402b9f:	lea    0x17df(%rip),%rdi        # 404385 <_IO_stdin_used+0x385>
  402ba6:	callq  401130 <err_fail>
  402bab:	lea    0x1762(%rip),%rdi        # 404314 <_IO_stdin_used+0x314>
  402bb2:	callq  401130 <err_fail>

Disassembly of section .fini:
