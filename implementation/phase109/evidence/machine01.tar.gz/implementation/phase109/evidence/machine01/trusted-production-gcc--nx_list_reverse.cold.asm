
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004016c4 <nx_list_reverse.cold>:
  4016c4:	mov    -0x8(%rdi,%rsi,1),%r9
  4016c9:	mov    (%r10),%r15
  4016cc:	mov    %rbx,%rcx
  4016cf:	mov    %r12,%rdx
  4016d2:	mov    %rbp,%rsi
  4016d5:	mov    %rdi,(%rsp)
  4016d9:	mov    %r9,0x8(%rsp)
  4016de:	mov    %r15,%r12
  4016e1:	callq  4014c6 <span_fade.constprop.0>
  4016e6:	mov    0x8(%rbp),%rbx
  4016ea:	mov    (%rsp),%rdi
  4016ee:	movabs $0xffffffffff,%r8
  4016f8:	mov    0x8(%rsp),%r9
  4016fd:	jmpq   403230 <nx_list_reverse+0xf0>
  401702:	xor    %edx,%edx
  401704:	mov    %rbp,%rsi
  401707:	mov    %r9,(%rsp)
  40170b:	callq  401100 <heap_hand>
  401710:	mov    (%rsp),%r9
  401714:	movabs $0xffffffffff,%r8
  40171e:	jmpq   40332d <nx_list_reverse+0x1ed>
  401723:	mov    $0x1,%edx
  401728:	mov    %rbp,%rsi
  40172b:	mov    %r9,(%rsp)
  40172f:	callq  401100 <heap_hand>
  401734:	mov    0x8(%rbp),%rbx
  401738:	mov    (%rsp),%r9
  40173c:	movabs $0xffffffffff,%r8
  401746:	jmpq   403230 <nx_list_reverse+0xf0>
  40174b:	mov    %r13,%rdx
  40174e:	mov    $0x1,%ecx
  401753:	mov    %rbp,%rsi
  401756:	mov    %rdi,(%rsp)
  40175a:	callq  401397 <rfc_wrap>
  40175f:	mov    (%rsp),%rdi
  401763:	movabs $0xffffffffff,%r8
  40176d:	mov    %rax,%r13
  401770:	jmpq   4031dc <nx_list_reverse+0x9c>
  401775:	mov    %r9,%rdx
  401778:	mov    $0x1,%ecx
  40177d:	mov    %rbp,%rsi
  401780:	mov    %rdi,(%rsp)
  401784:	callq  401397 <rfc_wrap>
  401789:	mov    (%rsp),%rdi
  40178d:	movabs $0xffffffffff,%r8
  401797:	mov    %rax,%r9
  40179a:	jmpq   4031c0 <nx_list_reverse+0x80>
  40179f:	mov    $0x1,%edx
  4017a4:	mov    %rbp,%rsi
  4017a7:	mov    %r9,0x8(%rsp)
  4017ac:	mov    %rdi,(%rsp)
  4017b0:	callq  401178 <heap_alloc_miss>
  4017b5:	mov    (%rsp),%rdi
  4017b9:	mov    0x8(%rsp),%r9
  4017be:	movabs $0xffffffffff,%r8
  4017c8:	mov    %rax,%rbx
  4017cb:	lea    (%rdi,%rax,8),%r15
  4017cf:	jmpq   403256 <nx_list_reverse+0x116>

Disassembly of section .fini:
