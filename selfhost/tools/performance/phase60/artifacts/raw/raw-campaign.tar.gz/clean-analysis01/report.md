# Phase60 clean compilation population

Compilation of 23 sources, mapped to 45 retained runtime points; no new runtime execution. Full population statistics require all 138 workers. Each source has one GM weight. Ratio of sums is TS-time-weighted arithmetic, not the equal-source GM. Later calls remain still warming. Fresh process and primed disk cache, not cold filesystem. No diagnostic profile times or cross-campaign pooling.

Coverage: 138/138 successful workers; 23/23 complete source pairs; 45 inherited runtime points.

| Source | Bytes | Points | B2 first+startup ms | TS first+startup ms | B2/TS | Gap ms | B2 later median ms | TS later median ms |
|---|---:|---:|---:|---:|---:|---:|---:|---:|
| mandelbrot | 6576 | 1 | 1801.696 | 670.281 | 2.6880 | 1131.416 | 781.395 | 288.476 |
| editdist | 5874 | 3 | 1613.347 | 645.120 | 2.5008 | 968.227 | 674.418 | 253.246 |
| tree-bitonic | 4633 | 3 | 1543.812 | 626.006 | 2.4661 | 917.806 | 617.553 | 253.815 |
| lexer | 7134 | 3 | 1665.776 | 674.283 | 2.4704 | 991.493 | 700.257 | 284.729 |
| symreg | 5406 | 3 | 1624.658 | 640.198 | 2.5377 | 984.460 | 639.661 | 245.098 |
| test-morning-program | 3077 | 1 | 2106.293 | 824.657 | 2.5541 | 1281.636 | 1026.840 | 374.326 |
| test-evening-program | 2152 | 1 | 2284.859 | 941.776 | 2.4261 | 1343.082 | 1095.781 | 438.556 |
| test-rle-roundtrip | 2743 | 1 | 1513.923 | 675.679 | 2.2406 | 838.244 | 665.026 | 277.254 |
| test-map-set-ops | 5266 | 1 | 2779.290 | 911.639 | 3.0487 | 1867.651 | 1402.476 | 416.170 |
| raytrace | 14223 | 1 | 2131.866 | 832.761 | 2.5600 | 1299.105 | 1016.324 | 374.855 |
| local-row | 6245 | 2 | 1626.345 | 657.619 | 2.4731 | 968.727 | 669.316 | 256.150 |
| local-fold | 768 | 3 | 1310.642 | 604.086 | 2.1696 | 706.556 | 511.549 | 221.687 |
| scalar-region | 1496 | 2 | 1448.655 | 614.303 | 2.3582 | 834.352 | 600.903 | 246.362 |
| mandelbrot-grid | 7395 | 2 | 1850.237 | 681.196 | 2.7162 | 1169.042 | 785.879 | 298.974 |
| raytrace-active | 14680 | 2 | 2150.523 | 823.869 | 2.6103 | 1326.654 | 1034.880 | 405.708 |
| closures | 1392 | 2 | 1336.921 | 597.761 | 2.2365 | 739.160 | 517.966 | 218.220 |
| list-pipeline | 3249 | 2 | 1940.691 | 762.786 | 2.5442 | 1177.905 | 780.409 | 368.867 |
| bst | 3051 | 2 | 1493.262 | 626.186 | 2.3847 | 867.077 | 642.808 | 261.264 |
| unicode-text | 5277 | 2 | 1658.812 | 669.382 | 2.4781 | 989.430 | 708.139 | 266.670 |
| expression | 1522 | 2 | 1381.826 | 601.923 | 2.2957 | 779.904 | 513.750 | 241.088 |
| map-churn | 1703 | 2 | 2004.164 | 861.074 | 2.3275 | 1143.089 | 867.480 | 392.611 |
| numeric-recurrence | 556 | 2 | 1247.551 | 593.293 | 2.1028 | 654.258 | 529.424 | 209.545 |
| record-aggregation | 1651 | 2 | 2005.006 | 771.071 | 2.6003 | 1233.934 | 831.519 | 399.040 |

Population metrics (same campaign, one value per source):

- importApiAndFirstMs: equal-source GM 2.461297; ratio of summed medians 2.484840; min/median/max ratios 2.102756/2.473082/3.048674.
- firstRequestMs: equal-source GM 3.794260; ratio of summed medians 3.779166; min/median/max ratios 3.227896/3.834330/4.252291.
- warmRequestMedianMs: equal-source GM 2.495000; ratio of summed medians 2.518874; min/median/max ratios 2.083802/2.498609/3.369956.
