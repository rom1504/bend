000000000040e69f <p111_FID_105_110_111_114_100_101_114_>:
  40e69f:	push   rbp
  40e6a0:	mov    rbp,rsp
  40e6a3:	sub    rsp,0x930
  40e6aa:	mov    QWORD PTR [rbp-0x10],r12
  40e6ae:	mov    rax,rdi
  40e6b1:	mov    r12,rax
  40e6b4:	mov    rdi,r12
  40e6b7:	movabs rsi,0x45
  40e6c1:	mov    esi,esi
  40e6c3:	lea    rdx,[rbp-0x830]
  40e6ca:	movabs rcx,0x0
  40e6d4:	mov    ecx,ecx
  40e6d6:	xor    eax,eax
  40e6d8:	call   418230 <p111_rt_closure>
  40e6dd:	mov    rdi,rax
  40e6e0:	lea    r10,[rbp-0x830]
  40e6e7:	mov    r11,rdi
  40e6ea:	mov    QWORD PTR [r10],r11
  40e6ed:	lea    r10,[rip+0x1734c]        # 425a40 <p111_program>
  40e6f4:	movabs rdi,0x4
  40e6fe:	and    rdi,QWORD PTR [r10+0x58]
  40e702:	mov    r10,rdi
  40e705:	test   r10d,r10d
  40e708:	je     40e75c <p111_FID_105_110_111_114_100_101_114_+0xbd>
  40e70e:	lea    r10,[rbp-0x830]
  40e715:	mov    rdi,QWORD PTR [r10]
  40e718:	mov    QWORD PTR [r12+0x28],rdi
  40e71d:	mov    r10,r12
  40e720:	movabs r11,0x1
  40e72a:	mov    DWORD PTR [r10+0x1c],r11d
  40e72e:	mov    rdi,QWORD PTR [r12+0x10]
  40e733:	movabs r11,0xfffffffffffffff8
  40e73d:	add    rdi,r11
  40e740:	mov    QWORD PTR [r12+0x10],rdi
  40e745:	mov    rdi,QWORD PTR [rdi]
  40e748:	mov    DWORD PTR [r12+0x20],edi
  40e74d:	movabs rdi,0x0
  40e757:	jmp    40e77c <p111_FID_105_110_111_114_100_101_114_+0xdd>
  40e75c:	mov    rdi,r12
  40e75f:	lea    rsi,[rbp-0x830]
  40e766:	movabs rdx,0x1
  40e770:	mov    edx,edx
  40e772:	xor    eax,eax
  40e774:	call   418440 <p111_rt_return>
  40e779:	mov    rdi,rax
  40e77c:	mov    rax,rdi
  40e77f:	mov    r12,QWORD PTR [rbp-0x10]
  40e783:	mov    rsp,rbp
  40e786:	pop    rbp
  40e787:	ret    

