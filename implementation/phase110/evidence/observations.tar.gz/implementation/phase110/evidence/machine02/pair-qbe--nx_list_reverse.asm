
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	endbr64 
  401df4:	push   %rbp
  401df5:	mov    %rsp,%rbp
  401df8:	sub    $0x18,%rsp
  401dfc:	push   %rbx
  401dfd:	mov    %rdx,%rax
  401e00:	mov    %rax,%rdx
  401e03:	data16 nopw %cs:0x0(%rax,%rax,1)
  401e0e:	xchg   %ax,%ax
  401e10:	mov    %rsi,%rax
  401e13:	shr    $0x28,%rax
  401e17:	and    $0xffff,%rax
  401e1d:	cmp    $0x0,%rax
  401e21:	je     401e58 <nx_list_reverse+0x68>
  401e23:	cmp    $0x1,%rax
  401e27:	jne    401e4c <nx_list_reverse+0x5c>
  401e29:	mov    %rdi,%rbx
  401e2c:	callq  4036f0 <nx_rt_pair_rebuild2_c1_k0>
  401e31:	mov    %rbx,%rdi
  401e34:	mov    %rax,%rcx
  401e37:	mov    %rdx,%rax
  401e3a:	mov    %rcx,-0x10(%rbp)
  401e3e:	mov    %rax,-0x8(%rbp)
  401e42:	mov    -0x10(%rbp),%rdx
  401e46:	mov    -0x8(%rbp),%rsi
  401e4a:	jmp    401e10 <nx_list_reverse+0x20>
  401e4c:	mov    $0x1,%esi
  401e51:	callq  4026b0 <nx_rt_fail>
  401e56:	jmp    401e5b <nx_list_reverse+0x6b>
  401e58:	mov    %rdx,%rax
  401e5b:	pop    %rbx
  401e5c:	leaveq 
  401e5d:	retq   

Disassembly of section .fini:
