
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401870 <nx_list_reverse>:
  401870:	push   %r15
  401872:	push   %r14
  401874:	push   %r12
  401876:	push   %rbx
  401877:	push   %rax
  401878:	mov    %rdx,%r14
  40187b:	mov    %rsi,%r15
  40187e:	mov    %rdi,%rbx
  401881:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  401890:	mov    %rbx,%rdi
  401893:	mov    %r15,%rsi
  401896:	callq  402710 <nx_rt_fast_id>
  40189b:	cmp    $0x1,%eax
  40189e:	jne    4018e0 <nx_list_reverse+0x70>
  4018a0:	mov    %rbx,%rdi
  4018a3:	mov    %r15,%rsi
  4018a6:	callq  4028a0 <nx_rt_fast_take2>
  4018ab:	mov    %rbx,%rdi
  4018ae:	xor    %esi,%esi
  4018b0:	callq  4029c0 <nx_rt_fast_field>
  4018b5:	mov    %rax,%r12
  4018b8:	mov    %rbx,%rdi
  4018bb:	mov    $0x1,%esi
  4018c0:	callq  4029c0 <nx_rt_fast_field>
  4018c5:	mov    %rax,%r15
  4018c8:	mov    %rbx,%rdi
  4018cb:	mov    $0x1,%esi
  4018d0:	mov    %r12,%rdx
  4018d3:	mov    %r14,%rcx
  4018d6:	callq  4027f0 <nx_rt_fast_build2>
  4018db:	mov    %rax,%r14
  4018de:	jmp    401890 <nx_list_reverse+0x20>
  4018e0:	test   %eax,%eax
  4018e2:	jne    4018f3 <nx_list_reverse+0x83>
  4018e4:	mov    %r14,%rax
  4018e7:	add    $0x8,%rsp
  4018eb:	pop    %rbx
  4018ec:	pop    %r12
  4018ee:	pop    %r14
  4018f0:	pop    %r15
  4018f2:	retq   
  4018f3:	mov    %rbx,%rdi
  4018f6:	mov    $0x1,%esi
  4018fb:	add    $0x8,%rsp
  4018ff:	pop    %rbx
  401900:	pop    %r12
  401902:	pop    %r14
  401904:	pop    %r15
  401906:	jmpq   402210 <nx_rt_fail>

Disassembly of section .fini:
