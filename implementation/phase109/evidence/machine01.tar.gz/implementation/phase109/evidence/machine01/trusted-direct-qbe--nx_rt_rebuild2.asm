
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402a00 <nx_rt_rebuild2>:
  402a00:	movabs $0xffffffffff,%r9
  402a0a:	push   %r14
  402a0c:	push   %r13
  402a0e:	and    %rsi,%r9
  402a11:	mov    %edx,%r13d
  402a14:	push   %r12
  402a16:	lea    0x0(,%r9,8),%rdx
  402a1e:	push   %rbp
  402a1f:	mov    %ecx,%ebp
  402a21:	push   %rbx
  402a22:	mov    %rdi,%rbx
  402a25:	sub    $0x20,%rsp
  402a29:	mov    (%rdi),%rdi
  402a2c:	mov    0x8(%rbx),%r12
  402a30:	lea    (%rdi,%rdx,1),%rax
  402a34:	test   %rsi,%rsi
  402a37:	js     402ab8 <nx_rt_rebuild2+0xb8>
  402a39:	mov    (%rax),%rax
  402a3c:	mov    %rax,0x10(%rsp)
  402a41:	mov    0x8(%rdi,%rdx,1),%rax
  402a46:	mov    %rax,0x18(%rsp)
  402a4b:	cmp    $0x310817f,%r9
  402a52:	jbe    402a90 <nx_rt_rebuild2+0x90>
  402a54:	mov    $0x1,%eax
  402a59:	mov    0x10(%rsp,%rbp,8),%rcx
  402a5e:	mov    %r13d,%edx
  402a61:	mov    %r12,%rsi
  402a64:	sub    %ebp,%eax
  402a66:	movq   $0xffffffffffffffff,0x18(%rbx)
  402a6e:	mov    0x10(%rsp,%rax,8),%rax
  402a73:	movl   $0x1,0x20(%rbx)
  402a7a:	mov    %rax,0x10(%rbx)
  402a7e:	add    $0x20,%rsp
  402a82:	pop    %rbx
  402a83:	pop    %rbp
  402a84:	pop    %r12
  402a86:	pop    %r13
  402a88:	pop    %r14
  402a8a:	jmpq   401ca0 <nx_construct2>
  402a8f:	nop
  402a90:	mov    0x8(%r12),%r9
  402a95:	test   %r9,%r9
  402a98:	je     401651 <nx_rt_rebuild2.cold>
  402a9e:	mov    (%rdi,%r9,8),%rax
  402aa2:	subq   $0x2,0x108(%r12)
  402aab:	mov    %rax,0x8(%r12)
  402ab0:	jmp    402a54 <nx_rt_rebuild2+0x54>
  402ab2:	nopw   0x0(%rax,%rax,1)
  402ab8:	mov    0x4(%rax),%edx
  402abb:	mov    (%rax),%ecx
  402abd:	shl    $0x20,%rdx
  402ac1:	or     %rcx,%rdx
  402ac4:	mov    %rdx,%r14
  402ac7:	and    $0xffffff,%edx
  402acd:	shr    $0x18,%r14
  402ad1:	lea    0x0(,%r14,8),%r10
  402ad9:	lea    (%rdi,%r10,1),%r11
  402add:	lea    0x8(%rdi,%r10,1),%r10
  402ae2:	cmp    $0x1,%rdx
  402ae6:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402aec:	mov    (%rax),%edx
  402aee:	mov    (%r11),%rdx
  402af1:	mov    %rdx,0x10(%rsp)
  402af6:	mov    (%r10),%rdx
  402af9:	mov    %rdx,0x18(%rsp)
  402afe:	mov    (%r12),%rdx
  402b02:	mov    %rdx,(%rax)
  402b05:	mov    0x100(%r12),%rax
  402b0d:	mov    0x46c5(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402b13:	mov    %r9,(%r12)
  402b17:	add    $0x1,%rax
  402b1b:	mov    %rax,0x100(%r12)
  402b23:	cmp    %rdx,%rax
  402b26:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402b2c:	mov    %r14,%r9
  402b2f:	jmpq   402a4b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
