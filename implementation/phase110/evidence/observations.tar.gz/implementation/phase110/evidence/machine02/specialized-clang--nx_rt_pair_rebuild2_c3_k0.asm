
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403c80 <nx_rt_pair_rebuild2_c3_k0>:
  403c80:	push   %r15
  403c82:	push   %r14
  403c84:	push   %r13
  403c86:	push   %r12
  403c88:	mov    %rdx,%r12
  403c8b:	push   %rbp
  403c8c:	push   %rbx
  403c8d:	movabs $0xffffffffff,%rbx
  403c97:	and    %rsi,%rbx
  403c9a:	lea    0x0(,%rbx,8),%rdx
  403ca2:	sub    $0x18,%rsp
  403ca6:	mov    (%rdi),%rbp
  403ca9:	mov    0x8(%rdi),%r15
  403cad:	lea    0x0(%rbp,%rdx,1),%rax
  403cb2:	test   %rsi,%rsi
  403cb5:	js     403d70 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  403cbb:	mov    (%rax),%r14
  403cbe:	mov    0x8(%rbp,%rdx,1),%r13
  403cc3:	cmp    $0x310817f,%rbx
  403cca:	jbe    403d40 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  403ccc:	lea    0x0(%rbp,%rbx,8),%r8
  403cd1:	mov    %r14,%rax
  403cd4:	shr    $0x38,%rax
  403cd8:	and    $0x7f,%eax
  403cdb:	cmp    $0x2,%rax
  403cdf:	je     403d20 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  403ce1:	mov    %r12,%rax
  403ce4:	mov    %r14,(%r8)
  403ce7:	lea    0x8(%rbp,%rbx,8),%r14
  403cec:	shr    $0x38,%rax
  403cf0:	and    $0x7f,%eax
  403cf3:	cmp    $0x2,%rax
  403cf7:	je     403d30 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  403cf9:	movabs $0x200030000000000,%rax
  403d03:	mov    %r12,(%r14)
  403d06:	mov    %r13,%rdx
  403d09:	add    $0x18,%rsp
  403d0d:	or     %rbx,%rax
  403d10:	pop    %rbx
  403d11:	pop    %rbp
  403d12:	pop    %r12
  403d14:	pop    %r13
  403d16:	pop    %r14
  403d18:	pop    %r15
  403d1a:	retq   
  403d1b:	nopl   0x0(%rax,%rax,1)
  403d20:	test   %r14,%r14
  403d23:	js     403ce1 <nx_rt_pair_rebuild2_c3_k0+0x61>
  403d25:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  403d2a:	nopw   0x0(%rax,%rax,1)
  403d30:	test   %r12,%r12
  403d33:	js     403cf9 <nx_rt_pair_rebuild2_c3_k0+0x79>
  403d35:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  403d3a:	nopw   0x0(%rax,%rax,1)
  403d40:	mov    0x8(%r15),%rbx
  403d44:	test   %rbx,%rbx
  403d47:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  403d4d:	lea    0x0(%rbp,%rbx,8),%r8
  403d52:	mov    (%r8),%rax
  403d55:	subq   $0x2,0x108(%r15)
  403d5d:	mov    %rax,0x8(%r15)
  403d61:	jmpq   403cd1 <nx_rt_pair_rebuild2_c3_k0+0x51>
  403d66:	nopw   %cs:0x0(%rax,%rax,1)
  403d70:	mov    0x4(%rax),%edx
  403d73:	mov    (%rax),%ecx
  403d75:	shl    $0x20,%rdx
  403d79:	or     %rcx,%rdx
  403d7c:	mov    %rdx,%rcx
  403d7f:	and    $0xffffff,%edx
  403d85:	shr    $0x18,%rcx
  403d89:	lea    0x8(,%rcx,8),%rdi
  403d91:	lea    0x0(%rbp,%rdi,1),%r8
  403d96:	lea    -0x8(%rbp,%rdi,1),%rdi
  403d9b:	cmp    $0x1,%rdx
  403d9f:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  403da5:	mov    (%rax),%edx
  403da7:	mov    (%r15),%rdx
  403daa:	mov    (%rdi),%r14
  403dad:	mov    (%r8),%r13
  403db0:	mov    %rdx,(%rax)
  403db3:	mov    0x100(%r15),%rax
  403dba:	mov    0x3d418(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403dc0:	mov    %rbx,(%r15)
  403dc3:	add    $0x1,%rax
  403dc7:	mov    %rax,0x100(%r15)
  403dce:	cmp    %rdx,%rax
  403dd1:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  403dd7:	mov    %rcx,%rbx
  403dda:	jmpq   403cc3 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
