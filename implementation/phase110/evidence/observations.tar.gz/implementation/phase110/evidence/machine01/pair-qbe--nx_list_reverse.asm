
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	endbr64 
  401c04:	push   %rbp
  401c05:	mov    %rsp,%rbp
  401c08:	sub    $0x18,%rsp
  401c0c:	push   %rbx
  401c0d:	mov    %rdx,%rax
  401c10:	mov    %rax,%rdx
  401c13:	data16 nopw %cs:0x0(%rax,%rax,1)
  401c1e:	xchg   %ax,%ax
  401c20:	mov    %rsi,%rax
  401c23:	shr    $0x28,%rax
  401c27:	and    $0xffff,%rax
  401c2d:	cmp    $0x0,%rax
  401c31:	je     401c68 <nx_list_reverse+0x68>
  401c33:	cmp    $0x1,%rax
  401c37:	jne    401c5c <nx_list_reverse+0x5c>
  401c39:	mov    %rdi,%rbx
  401c3c:	callq  403470 <nx_rt_pair_rebuild2_c1_k0>
  401c41:	mov    %rbx,%rdi
  401c44:	mov    %rax,%rcx
  401c47:	mov    %rdx,%rax
  401c4a:	mov    %rcx,-0x10(%rbp)
  401c4e:	mov    %rax,-0x8(%rbp)
  401c52:	mov    -0x10(%rbp),%rdx
  401c56:	mov    -0x8(%rbp),%rsi
  401c5a:	jmp    401c20 <nx_list_reverse+0x20>
  401c5c:	mov    $0x1,%esi
  401c61:	callq  402540 <nx_rt_fail>
  401c66:	jmp    401c6b <nx_list_reverse+0x6b>
  401c68:	mov    %rdx,%rax
  401c6b:	pop    %rbx
  401c6c:	leaveq 
  401c6d:	retq   

Disassembly of section .fini:
