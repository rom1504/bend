
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	endbr64 
  401df4:	push   %rbp
  401df5:	mov    %rsp,%rbp
  401df8:	sub    $0x38,%rsp
  401dfc:	push   %rbx
  401dfd:	push   %r12
  401dff:	push   %r13
  401e01:	push   %r14
  401e03:	push   %r15
  401e05:	mov    %rdx,%rbx
  401e08:	mov    %rsi,%r14
  401e0b:	mov    %rdi,%r12
  401e0e:	callq  4047a0 <nx_rt_ir_heap>
  401e13:	mov    %r12,%rdi
  401e16:	mov    %rax,%r12
  401e19:	mov    %rdi,%r13
  401e1c:	callq  404810 <nx_rt_ir_alc>
  401e21:	mov    %r14,%rsi
  401e24:	mov    %r13,%rdi
  401e27:	xchg   %rax,%rbx
  401e29:	mov    %rax,%rdx
  401e2c:	nopl   0x0(%rax)
  401e30:	mov    %rsi,%rax
  401e33:	shr    $0x28,%rax
  401e37:	and    $0xffff,%rax
  401e3d:	cmp    $0x0,%rax
  401e41:	je     402139 <nx_list_reverse+0x349>
  401e47:	cmp    $0x1,%rax
  401e4b:	jne    40212d <nx_list_reverse+0x33d>
  401e51:	movabs $0xffffffffff,%rax
  401e5b:	and    %rsi,%rax
  401e5e:	mov    %rsi,%r9
  401e61:	shr    $0x3f,%r9
  401e65:	cmp    $0x1,%r9
  401e69:	sete   %cl
  401e6c:	movzbl %cl,%ecx
  401e6f:	mov    %rax,%r10
  401e72:	shl    $0x3,%r10
  401e76:	cmp    $0x0,%ecx
  401e79:	jne    401e95 <nx_list_reverse+0xa5>
  401e7b:	cmp    $0x3108180,%rax
  401e81:	setb   %cl
  401e84:	movzbl %cl,%ecx
  401e87:	cmp    $0x0,%ecx
  401e8a:	sete   %cl
  401e8d:	movzbl %cl,%ecx
  401e90:	mov    %rax,%r8
  401e93:	jmp    401ed8 <nx_list_reverse+0xe8>
  401e95:	mov    %rax,%r8
  401e98:	mov    (%r12,%r10,1),%rax
  401e9c:	mov    %rax,%rcx
  401e9f:	and    $0xffffff,%rcx
  401ea6:	cmp    $0x1,%rcx
  401eaa:	sete   %cl
  401ead:	movzbl %cl,%ecx
  401eb0:	cmp    $0x0,%ecx
  401eb3:	jne    401ebf <nx_list_reverse+0xcf>
  401eb5:	mov    $0x0,%ecx
  401eba:	mov    %r8,%rax
  401ebd:	jmp    401ed8 <nx_list_reverse+0xe8>
  401ebf:	shr    $0x18,%rax
  401ec3:	cmp    $0x3108180,%rax
  401ec9:	setb   %cl
  401ecc:	movzbl %cl,%ecx
  401ecf:	cmp    $0x0,%ecx
  401ed2:	sete   %cl
  401ed5:	movzbl %cl,%ecx
  401ed8:	mov    %rax,-0x30(%rbp)
  401edc:	cmp    $0x0,%ecx
  401edf:	jne    401f0a <nx_list_reverse+0x11a>
  401ee1:	mov    %rdi,%r13
  401ee4:	callq  403b60 <nx_rt_rebuild2_c1_k0>
  401ee9:	mov    %r13,%rdi
  401eec:	mov    %rax,%r14
  401eef:	mov    $0x0,%esi
  401ef4:	mov    %rdi,%r13
  401ef7:	callq  403490 <nx_rt_fast_field>
  401efc:	mov    %r14,%rdx
  401eff:	mov    %r13,%rdi
  401f02:	mov    %rax,%rsi
  401f05:	jmpq   401e30 <nx_list_reverse+0x40>
  401f0a:	mov    %rax,%r14
  401f0d:	shl    $0x3,%r14
  401f11:	mov    %r14,-0x10(%rbp)
  401f15:	mov    %r12,%rcx
  401f18:	add    %r14,%rcx
  401f1b:	mov    %rcx,-0x20(%rbp)
  401f1f:	mov    (%r12,%r14,1),%r13
  401f23:	mov    0x8(%r12,%r14,1),%rsi
  401f28:	mov    %rsi,-0x18(%rbp)
  401f2c:	cmp    $0x1,%r9
  401f30:	jne    401f86 <nx_list_reverse+0x196>
  401f32:	mov    (%rbx),%r9
  401f35:	mov    %r9,(%r12,%r10,1)
  401f39:	mov    %r8,(%rbx)
  401f3c:	mov    0x100(%rbx),%r8
  401f43:	add    $0x1,%r8
  401f47:	mov    %r8,0x100(%rbx)
  401f4e:	cmp    $0x8000,%r8
  401f55:	mov    %rdx,%r15
  401f58:	setb   %dl
  401f5b:	movzbl %dl,%edx
  401f5e:	cmp    $0x0,%edx
  401f61:	jne    401f83 <nx_list_reverse+0x193>
  401f63:	mov    %rdi,%r14
  401f66:	callq  401c36 <nx_rt_ir_hand0>
  401f6b:	mov    %r15,%rdx
  401f6e:	mov    %r14,%rdi
  401f71:	mov    -0x30(%rbp),%rax
  401f75:	mov    -0x18(%rbp),%rsi
  401f79:	mov    -0x20(%rbp),%rcx
  401f7d:	mov    -0x10(%rbp),%r14
  401f81:	jmp    401f86 <nx_list_reverse+0x196>
  401f83:	mov    %r15,%rdx
  401f86:	mov    %r13,%r8
  401f89:	shr    $0x38,%r8
  401f8d:	and    $0x7f,%r8
  401f91:	cmp    $0x2,%r8
  401f95:	sete   %r8b
  401f99:	movzbl %r8b,%r8d
  401f9d:	mov    %r13,%r9
  401fa0:	shr    $0x3f,%r9
  401fa4:	cmp    $0x0,%r9
  401fa8:	sete   %r9b
  401fac:	movzbl %r9b,%r9d
  401fb0:	test   %r8d,%r9d
  401fb3:	je     40204c <nx_list_reverse+0x25c>
  401fb9:	mov    (%rbx),%r9
  401fbc:	cmp    $0x0,%r9
  401fc0:	je     401fea <nx_list_reverse+0x1fa>
  401fc2:	mov    %r9,%r8
  401fc5:	shl    $0x3,%r8
  401fc9:	mov    (%r12,%r8,1),%r8
  401fcd:	mov    %r8,(%rbx)
  401fd0:	mov    %rdx,%r15
  401fd3:	mov    0x100(%rbx),%rdx
  401fda:	sub    $0x1,%rdx
  401fde:	mov    %rdx,0x100(%rbx)
  401fe5:	mov    %r15,%rdx
  401fe8:	jmp    40200e <nx_list_reverse+0x21e>
  401fea:	mov    %rdx,%r15
  401fed:	mov    %rdi,%r14
  401ff0:	callq  401c25 <nx_rt_ir_alloc0>
  401ff5:	mov    %r15,%rdx
  401ff8:	mov    %r14,%rdi
  401ffb:	mov    %rax,%r9
  401ffe:	mov    -0x30(%rbp),%rax
  402002:	mov    -0x18(%rbp),%rsi
  402006:	mov    -0x20(%rbp),%rcx
  40200a:	mov    -0x10(%rbp),%r14
  40200e:	mov    %r9,%r10
  402011:	shl    $0x3,%r10
  402015:	movabs $0xffffffffff,%r8
  40201f:	and    %r13,%r8
  402022:	shl    $0x18,%r8
  402026:	or     $0x1,%r8
  40202a:	mov    %r8,(%r12,%r10,1)
  40202e:	mov    %r13,%r8
  402031:	shr    $0x28,%r8
  402035:	shl    $0x28,%r8
  402039:	movabs $0x8000000000000000,%r10
  402043:	or     %r10,%r8
  402046:	mov    %r8,%r13
  402049:	or     %r9,%r13
  40204c:	mov    %r13,-0x28(%rbp)
  402050:	mov    %rdx,%r8
  402053:	shr    $0x38,%r8
  402057:	and    $0x7f,%r8
  40205b:	cmp    $0x2,%r8
  40205f:	sete   %r8b
  402063:	movzbl %r8b,%r8d
  402067:	mov    %rdx,%r9
  40206a:	shr    $0x3f,%r9
  40206e:	cmp    $0x0,%r9
  402072:	sete   %r9b
  402076:	movzbl %r9b,%r9d
  40207a:	test   %r8d,%r9d
  40207d:	je     402110 <nx_list_reverse+0x320>
  402083:	mov    (%rbx),%r8
  402086:	cmp    $0x0,%r8
  40208a:	je     4020b4 <nx_list_reverse+0x2c4>
  40208c:	mov    %r8,%r9
  40208f:	shl    $0x3,%r9
  402093:	mov    (%r12,%r9,1),%r9
  402097:	mov    %r9,(%rbx)
  40209a:	mov    %rdx,%r15
  40209d:	mov    0x100(%rbx),%rdx
  4020a4:	sub    $0x1,%rdx
  4020a8:	mov    %rdx,0x100(%rbx)
  4020af:	mov    %r15,%rdx
  4020b2:	jmp    4020d8 <nx_list_reverse+0x2e8>
  4020b4:	mov    %rdx,%r15
  4020b7:	mov    %rdi,%r13
  4020ba:	callq  401c25 <nx_rt_ir_alloc0>
  4020bf:	mov    %r15,%rdx
  4020c2:	mov    %r13,%rdi
  4020c5:	mov    %rax,%r8
  4020c8:	mov    -0x28(%rbp),%r13
  4020cc:	mov    -0x30(%rbp),%rax
  4020d0:	mov    -0x18(%rbp),%rsi
  4020d4:	mov    -0x20(%rbp),%rcx
  4020d8:	mov    %r8,%r10
  4020db:	shl    $0x3,%r10
  4020df:	movabs $0xffffffffff,%r9
  4020e9:	and    %rdx,%r9
  4020ec:	shl    $0x18,%r9
  4020f0:	or     $0x1,%r9
  4020f4:	mov    %r9,(%r12,%r10,1)
  4020f8:	shr    $0x28,%rdx
  4020fc:	shl    $0x28,%rdx
  402100:	movabs $0x8000000000000000,%r9
  40210a:	or     %r9,%rdx
  40210d:	or     %r8,%rdx
  402110:	mov    %r13,(%r12,%r14,1)
  402114:	mov    %rdx,0x8(%rcx)
  402118:	movabs $0x200010000000000,%rcx
  402122:	mov    %rax,%rdx
  402125:	or     %rcx,%rdx
  402128:	jmpq   401e30 <nx_list_reverse+0x40>
  40212d:	mov    $0x1,%esi
  402132:	callq  402c90 <nx_rt_fail>
  402137:	jmp    40213c <nx_list_reverse+0x34c>
  402139:	mov    %rdx,%rax
  40213c:	pop    %r15
  40213e:	pop    %r14
  402140:	pop    %r13
  402142:	pop    %r12
  402144:	pop    %rbx
  402145:	leaveq 
  402146:	retq   

Disassembly of section .fini:
