
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403570 <nx_rt_rebuild2_c1_k0>:
  403570:	push   %r15
  403572:	push   %r14
  403574:	push   %r13
  403576:	push   %r12
  403578:	mov    %rdx,%r12
  40357b:	push   %rbp
  40357c:	mov    %rdi,%rbp
  40357f:	push   %rbx
  403580:	movabs $0xffffffffff,%rbx
  40358a:	and    %rsi,%rbx
  40358d:	lea    0x0(,%rbx,8),%rdx
  403595:	sub    $0x18,%rsp
  403599:	mov    (%rdi),%r13
  40359c:	mov    0x8(%rdi),%r15
  4035a0:	lea    0x0(%r13,%rdx,1),%rax
  4035a5:	test   %rsi,%rsi
  4035a8:	js     403670 <nx_rt_rebuild2_c1_k0+0x100>
  4035ae:	mov    (%rax),%r14
  4035b1:	mov    0x8(%r13,%rdx,1),%r9
  4035b6:	cmp    $0x310817f,%rbx
  4035bd:	jbe    403648 <nx_rt_rebuild2_c1_k0+0xd8>
  4035c3:	lea    0x0(%r13,%rbx,8),%r8
  4035c8:	mov    %r14,%rax
  4035cb:	mov    %r9,0x10(%rbp)
  4035cf:	shr    $0x38,%rax
  4035d3:	movq   $0xffffffffffffffff,0x18(%rbp)
  4035db:	and    $0x7f,%eax
  4035de:	movl   $0x1,0x20(%rbp)
  4035e5:	cmp    $0x2,%rax
  4035e9:	je     403628 <nx_rt_rebuild2_c1_k0+0xb8>
  4035eb:	mov    %r12,%rax
  4035ee:	mov    %r14,(%r8)
  4035f1:	lea    0x8(%r13,%rbx,8),%rbp
  4035f6:	shr    $0x38,%rax
  4035fa:	and    $0x7f,%eax
  4035fd:	cmp    $0x2,%rax
  403601:	je     403638 <nx_rt_rebuild2_c1_k0+0xc8>
  403603:	movabs $0x200010000000000,%rax
  40360d:	mov    %r12,0x0(%rbp)
  403611:	add    $0x18,%rsp
  403615:	or     %rbx,%rax
  403618:	pop    %rbx
  403619:	pop    %rbp
  40361a:	pop    %r12
  40361c:	pop    %r13
  40361e:	pop    %r14
  403620:	pop    %r15
  403622:	retq   
  403623:	nopl   0x0(%rax,%rax,1)
  403628:	test   %r14,%r14
  40362b:	js     4035eb <nx_rt_rebuild2_c1_k0+0x7b>
  40362d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403632:	nopw   0x0(%rax,%rax,1)
  403638:	test   %r12,%r12
  40363b:	js     403603 <nx_rt_rebuild2_c1_k0+0x93>
  40363d:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403642:	nopw   0x0(%rax,%rax,1)
  403648:	mov    0x8(%r15),%rbx
  40364c:	test   %rbx,%rbx
  40364f:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  403655:	lea    0x0(%r13,%rbx,8),%r8
  40365a:	mov    (%r8),%rax
  40365d:	subq   $0x2,0x108(%r15)
  403665:	mov    %rax,0x8(%r15)
  403669:	jmpq   4035c8 <nx_rt_rebuild2_c1_k0+0x58>
  40366e:	xchg   %ax,%ax
  403670:	mov    0x4(%rax),%edx
  403673:	mov    (%rax),%ecx
  403675:	shl    $0x20,%rdx
  403679:	or     %rcx,%rdx
  40367c:	mov    %rdx,%rcx
  40367f:	and    $0xffffff,%edx
  403685:	shr    $0x18,%rcx
  403689:	lea    0x8(,%rcx,8),%rdi
  403691:	lea    0x0(%r13,%rdi,1),%r8
  403696:	lea    -0x8(%r13,%rdi,1),%rdi
  40369b:	cmp    $0x1,%rdx
  40369f:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  4036a5:	mov    (%rax),%edx
  4036a7:	mov    (%r15),%rdx
  4036aa:	mov    (%rdi),%r14
  4036ad:	mov    (%r8),%r9
  4036b0:	mov    %rdx,(%rax)
  4036b3:	mov    0x100(%r15),%rax
  4036ba:	mov    0x3db18(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4036c0:	mov    %rbx,(%r15)
  4036c3:	add    $0x1,%rax
  4036c7:	mov    %rax,0x100(%r15)
  4036ce:	cmp    %rdx,%rax
  4036d1:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  4036d7:	mov    %rcx,%rbx
  4036da:	jmpq   4035b6 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
