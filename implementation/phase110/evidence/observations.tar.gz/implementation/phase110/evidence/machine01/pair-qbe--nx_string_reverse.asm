
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c70 <nx_string_reverse>:
  401c70:	endbr64 
  401c74:	push   %rbp
  401c75:	mov    %rsp,%rbp
  401c78:	sub    $0x18,%rsp
  401c7c:	push   %rbx
  401c7d:	mov    %rdx,%rax
  401c80:	mov    %rax,%rdx
  401c83:	data16 nopw %cs:0x0(%rax,%rax,1)
  401c8e:	xchg   %ax,%ax
  401c90:	mov    %rsi,%rax
  401c93:	shr    $0x28,%rax
  401c97:	and    $0xffff,%rax
  401c9d:	cmp    $0x2,%rax
  401ca1:	je     401cd8 <nx_string_reverse+0x68>
  401ca3:	cmp    $0x3,%rax
  401ca7:	jne    401ccc <nx_string_reverse+0x5c>
  401ca9:	mov    %rdi,%rbx
  401cac:	callq  403890 <nx_rt_pair_rebuild2_c3_k0>
  401cb1:	mov    %rbx,%rdi
  401cb4:	mov    %rax,%rcx
  401cb7:	mov    %rdx,%rax
  401cba:	mov    %rcx,-0x10(%rbp)
  401cbe:	mov    %rax,-0x8(%rbp)
  401cc2:	mov    -0x10(%rbp),%rdx
  401cc6:	mov    -0x8(%rbp),%rsi
  401cca:	jmp    401c90 <nx_string_reverse+0x20>
  401ccc:	mov    $0x1,%esi
  401cd1:	callq  402540 <nx_rt_fail>
  401cd6:	jmp    401cdb <nx_string_reverse+0x6b>
  401cd8:	mov    %rdx,%rax
  401cdb:	pop    %rbx
  401cdc:	leaveq 
  401cdd:	retq   

Disassembly of section .fini:
