
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401ea0 <nx_string_reverse>:
  401ea0:	endbr64 
  401ea4:	push   %rbp
  401ea5:	mov    %rsp,%rbp
  401ea8:	sub    $0x8,%rsp
  401eac:	push   %rbx
  401ead:	push   %r12
  401eaf:	push   %r13
  401eb1:	mov    %rdx,%rax
  401eb4:	mov    %rax,%r13
  401eb7:	nopw   0x0(%rax,%rax,1)
  401ec0:	mov    %rsi,%r12
  401ec3:	mov    %rdi,%rbx
  401ec6:	callq  402c60 <nx_rt_fast_id>
  401ecb:	mov    %r13,%rdx
  401ece:	mov    %r12,%rsi
  401ed1:	mov    %rbx,%rdi
  401ed4:	cmp    $0x2,%eax
  401ed7:	je     401f20 <nx_string_reverse+0x80>
  401ed9:	cmp    $0x3,%eax
  401edc:	jne    401f14 <nx_string_reverse+0x74>
  401ede:	mov    %rdx,%r8
  401ee1:	mov    $0x0,%ecx
  401ee6:	mov    $0x3,%edx
  401eeb:	mov    %rdi,%rbx
  401eee:	callq  402f30 <nx_rt_rebuild2>
  401ef3:	mov    %rbx,%rdi
  401ef6:	mov    %rax,%r12
  401ef9:	mov    $0x0,%esi
  401efe:	mov    %rdi,%rbx
  401f01:	callq  402f10 <nx_rt_fast_field>
  401f06:	mov    %r12,%rdx
  401f09:	mov    %rbx,%rdi
  401f0c:	mov    %rax,%rsi
  401f0f:	mov    %rdx,%r13
  401f12:	jmp    401ec0 <nx_string_reverse+0x20>
  401f14:	mov    $0x1,%esi
  401f19:	callq  402710 <nx_rt_fail>
  401f1e:	jmp    401f23 <nx_string_reverse+0x83>
  401f20:	mov    %rdx,%rax
  401f23:	pop    %r13
  401f25:	pop    %r12
  401f27:	pop    %rbx
  401f28:	leaveq 
  401f29:	retq   

Disassembly of section .fini:
