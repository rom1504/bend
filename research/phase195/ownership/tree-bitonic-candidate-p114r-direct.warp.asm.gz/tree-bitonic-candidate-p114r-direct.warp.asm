
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/tree-bitonic/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000411e47 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_>:
  411e47:	push   %rbp
  411e48:	mov    %rsp,%rbp
  411e4b:	sub    $0x1b60,%rsp
  411e52:	mov    %r12,-0x10(%rbp)
  411e56:	mov    %rbx,-0x8(%rbp)
  411e5a:	mov    %r13,-0x18(%rbp)
  411e5e:	mov    %r14,-0x20(%rbp)
  411e62:	mov    %r15,-0x28(%rbp)
  411e66:	mov    %rdi,%rax
  411e69:	mov    %rax,%r12
  411e6c:	mov    %rsi,%rax
  411e6f:	mov    %rax,%r13
  411e72:	mov    %rdx,%rax
  411e75:	mov    %rax,%rbx
  411e78:	mov    %rcx,%rax
  411e7b:	mov    %rax,%r14
  411e7e:	mov    %r8,%rax
  411e81:	mov    %rax,%rdi
  411e84:	mov    %r9,%rax
  411e87:	mov    %rax,%r15
  411e8a:	mov    0x10(%rbp),%rax
  411e8e:	mov    %rax,-0x58(%rbp)
  411e92:	mov    %rdi,%r10
  411e95:	test   %r10d,%r10d
  411e98:	je     41205d <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x216>
  411e9e:	cmp    $0x0,%r15
  411ea5:	je     412040 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1f9>
  411eab:	sub    $0x1,%r15
  411eb2:	mov    0x10(%r12),%rdi
  411eb7:	movabs $0xfffffffffffffff8,%r11
  411ec1:	add    %r11,%rdi
  411ec4:	mov    %rdi,0x10(%r12)
  411ec9:	mov    0x10(%r12),%rdi
  411ece:	mov    (%rdi),%rdi
  411ed1:	movabs $0x74,%r11
  411edb:	cmp    %r11,%rdi
  411ede:	jne    411f95 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x14e>
  411ee4:	mov    0x10(%r12),%rdi
  411ee9:	movabs $0xffffffffffffffe8,%r11
  411ef3:	add    %r11,%rdi
  411ef6:	mov    %rdi,0x10(%r12)
  411efb:	mov    0x10(%r12),%rdi
  411f00:	mov    (%rdi),%r13
  411f03:	mov    0x10(%r12),%rdi
  411f08:	mov    0x8(%rdi),%r14
  411f0c:	mov    0x10(%r12),%rdi
  411f11:	mov    0x10(%rdi),%rbx
  411f15:	lea    -0x10d8(%rbp),%r10
  411f1c:	mov    -0x58(%rbp),%r11
  411f20:	mov    %r11,(%r10)
  411f23:	mov    %r12,%rdi
  411f26:	movabs $0x75,%rsi
  411f30:	mov    %esi,%esi
  411f32:	lea    -0x10d8(%rbp),%rdx
  411f39:	movabs $0x1,%rcx
  411f43:	mov    %ecx,%ecx
  411f45:	xor    %eax,%eax
  411f47:	callq  41c4e0 <p111_rt_frame>
  411f4c:	mov    %rax,-0x1950(%rbp)
  411f53:	add    $0x1,%r15
  411f5a:	lea    -0x10d8(%rbp),%r10
  411f61:	mov    %r13,%r11
  411f64:	mov    %r11,(%r10)
  411f67:	lea    -0x10d8(%rbp),%r10
  411f6e:	mov    %rbx,%r11
  411f71:	mov    %r11,0x8(%r10)
  411f75:	lea    -0x10d8(%rbp),%r10
  411f7c:	mov    %r14,%r11
  411f7f:	mov    %r11,0x10(%r10)
  411f83:	movabs $0x0,%r10
  411f8d:	mov    %r10,%rdi
  411f90:	jmpq   411e92 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  411f95:	movabs $0x75,%r11
  411f9f:	cmp    %r11,%rdi
  411fa2:	jne    41200a <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x1c3>
  411fa8:	mov    0x10(%r12),%rdi
  411fad:	movabs $0xfffffffffffffff8,%r11
  411fb7:	add    %r11,%rdi
  411fba:	mov    %rdi,0x10(%r12)
  411fbf:	mov    0x10(%r12),%rdi
  411fc4:	mov    %rdi,%r10
  411fc7:	mov    (%r10),%r10
  411fca:	mov    %r10,-0x1970(%rbp)
  411fd1:	mov    %r12,%rdi
  411fd4:	mov    -0x1970(%rbp),%rsi
  411fdb:	mov    -0x58(%rbp),%rdx
  411fdf:	xor    %eax,%eax
  411fe1:	callq  40886b <p112w_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>
  411fe6:	mov    %rax,-0x1978(%rbp)
  411fed:	movabs $0x1,%r10
  411ff7:	mov    %r10,%rdi
  411ffa:	mov    -0x1978(%rbp),%r10
  412001:	mov    %r10,-0x58(%rbp)
  412005:	jmpq   411e92 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  41200a:	mov    %r12,%rdi
  41200d:	movabs $0x4,%rsi
  412017:	mov    %esi,%esi
  412019:	xor    %eax,%eax
  41201b:	callq  41c730 <p111_rt_fail>
  412020:	mov    %rax,-0x1980(%rbp)
  412027:	mov    -0x10(%rbp),%r12
  41202b:	mov    -0x8(%rbp),%rbx
  41202f:	mov    -0x18(%rbp),%r13
  412033:	mov    -0x20(%rbp),%r14
  412037:	mov    -0x28(%rbp),%r15
  41203b:	mov    %rbp,%rsp
  41203e:	pop    %rbp
  41203f:	retq   
  412040:	mov    -0x58(%rbp),%rax
  412044:	mov    -0x10(%rbp),%r12
  412048:	mov    -0x8(%rbp),%rbx
  41204c:	mov    -0x18(%rbp),%r13
  412050:	mov    -0x20(%rbp),%r14
  412054:	mov    -0x28(%rbp),%r15
  412058:	mov    %rbp,%rsp
  41205b:	pop    %rbp
  41205c:	retq   
  41205d:	mov    %r13,%rdi
  412060:	shr    $0x28,%rdi
  412064:	and    $0xffff,%rdi
  41206b:	movabs $0xa4,%r11
  412075:	cmp    %r11,%rdi
  412078:	jne    41241f <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x5d8>
  41207e:	mov    %r13,%r10
  412081:	shr    $0x28,%r10
  412085:	mov    %r10,-0x1998(%rbp)
  41208c:	and    $0x7fffff,%r10
  412093:	mov    %r10,-0x19a0(%rbp)
  41209a:	movabs $0xa4,%r10
  4120a4:	or     $0x10000,%r10
  4120ab:	mov    %r10,-0x19a8(%rbp)
  4120b2:	mov    -0x19a0(%rbp),%r10
  4120b9:	mov    -0x19a8(%rbp),%r11
  4120c0:	cmp    %r11,%r10
  4120c3:	jne    4120f6 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2af>
  4120c9:	mov    %r13,%r10
  4120cc:	movabs $0xffffffffff,%r11
  4120d6:	and    %r11,%r10
  4120d9:	mov    %r10,-0x19b8(%rbp)
  4120e0:	lea    -0x860(%rbp),%r10
  4120e7:	mov    -0x19b8(%rbp),%r11
  4120ee:	mov    %r11,(%r10)
  4120f1:	jmpq   412111 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x2ca>
  4120f6:	mov    %r12,%rdi
  4120f9:	mov    %r13,%rsi
  4120fc:	lea    -0x860(%rbp),%rdx
  412103:	xor    %eax,%eax
  412105:	callq  421ac0 <p125_rt_take1>
  41210a:	mov    %rax,-0x19c0(%rbp)
  412111:	lea    -0x860(%rbp),%r10
  412118:	mov    (%r10),%r10
  41211b:	mov    %r10,-0x19c8(%rbp)
  412122:	mov    %rbx,%rdi
  412125:	shr    $0x28,%rdi
  412129:	and    $0xffff,%rdi
  412130:	movabs $0xa4,%r11
  41213a:	cmp    %r11,%rdi
  41213d:	jne    412270 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x429>
  412143:	mov    %rbx,%r10
  412146:	shr    $0x28,%r10
  41214a:	mov    %r10,-0x19d0(%rbp)
  412151:	and    $0x7fffff,%r10
  412158:	mov    %r10,-0x19d8(%rbp)
  41215f:	movabs $0xa4,%r10
  412169:	or     $0x10000,%r10
  412170:	mov    %r10,-0x19e0(%rbp)
  412177:	mov    -0x19d8(%rbp),%r10
  41217e:	mov    -0x19e0(%rbp),%r11
  412185:	cmp    %r11,%r10
  412188:	jne    4121bb <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x374>
  41218e:	mov    %rbx,%r10
  412191:	movabs $0xffffffffff,%r11
  41219b:	and    %r11,%r10
  41219e:	mov    %r10,-0x19f0(%rbp)
  4121a5:	lea    -0x860(%rbp),%r10
  4121ac:	mov    -0x19f0(%rbp),%r11
  4121b3:	mov    %r11,(%r10)
  4121b6:	jmpq   4121d6 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x38f>
  4121bb:	mov    %r12,%rdi
  4121be:	mov    %rbx,%rsi
  4121c1:	lea    -0x860(%rbp),%rdx
  4121c8:	xor    %eax,%eax
  4121ca:	callq  421ac0 <p125_rt_take1>
  4121cf:	mov    %rax,-0x19c0(%rbp)
  4121d6:	lea    -0x860(%rbp),%r10
  4121dd:	mov    (%r10),%rdi
  4121e0:	lea    -0x860(%rbp),%r10
  4121e7:	mov    -0x19c8(%rbp),%r11
  4121ee:	mov    %r11,(%r10)
  4121f1:	lea    -0x860(%rbp),%r10
  4121f8:	mov    %rdi,%r11
  4121fb:	mov    %r11,0x8(%r10)
  4121ff:	lea    -0x860(%rbp),%r10
  412206:	mov    %r14,%r11
  412209:	mov    %r11,0x10(%r10)
  41220d:	mov    %r12,%r10
  412210:	mov    %r10,0x20(%rsp)
  412215:	mov    -0x19c8(%rbp),%r10
  41221c:	mov    %r10,0x28(%rsp)
  412221:	mov    %rdi,%r10
  412224:	mov    %r10,0x30(%rsp)
  412229:	mov    %r14,%r10
  41222c:	mov    %r10,0x38(%rsp)
  412231:	mov    0x20(%rsp),%rdi
  412236:	mov    0x28(%rsp),%rsi
  41223b:	mov    0x30(%rsp),%rdx
  412240:	mov    0x38(%rsp),%rcx
  412245:	xor    %eax,%eax
  412247:	callq  408e9c <p112w_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_108_101_97_102_>
  41224c:	mov    %rax,-0x1a00(%rbp)
  412253:	movabs $0x1,%r10
  41225d:	mov    %r10,%rdi
  412260:	mov    -0x1a00(%rbp),%r10
  412267:	mov    %r10,-0x58(%rbp)
  41226b:	jmpq   411e92 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  412270:	mov    %r12,%rdi
  412273:	mov    -0x19c8(%rbp),%rsi
  41227a:	xor    %eax,%eax
  41227c:	callq  41bfa0 <p111_rt_sink>
  412281:	mov    %rax,-0x19c0(%rbp)
  412288:	mov    %rbx,%rdi
  41228b:	shr    $0x28,%rdi
  41228f:	and    $0xffff,%rdi
  412296:	movabs $0xa5,%r11
  4122a0:	cmp    %r11,%rdi
  4122a3:	jne    412337 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4f0>
  4122a9:	mov    %r12,%rdi
  4122ac:	mov    %rbx,%rsi
  4122af:	lea    -0x860(%rbp),%rdx
  4122b6:	xor    %eax,%eax
  4122b8:	callq  421d40 <p125_rt_take2>
  4122bd:	mov    %rax,-0x19c0(%rbp)
  4122c4:	lea    -0x860(%rbp),%r10
  4122cb:	mov    (%r10),%r10
  4122ce:	mov    %r10,-0x1a08(%rbp)
  4122d5:	lea    -0x860(%rbp),%r10
  4122dc:	mov    0x8(%r10),%r10
  4122e0:	mov    %r10,-0x1a10(%rbp)
  4122e7:	mov    %r12,%rdi
  4122ea:	mov    -0x1a08(%rbp),%rsi
  4122f1:	xor    %eax,%eax
  4122f3:	callq  41bfa0 <p111_rt_sink>
  4122f8:	mov    %rax,-0x19c0(%rbp)
  4122ff:	mov    %r12,%rdi
  412302:	mov    -0x1a10(%rbp),%rsi
  412309:	xor    %eax,%eax
  41230b:	callq  41bfa0 <p111_rt_sink>
  412310:	mov    %rax,-0x19c0(%rbp)
  412317:	movabs $0x1,%r10
  412321:	mov    %r10,%rdi
  412324:	movabs $0x100a40000000000,%r10
  41232e:	mov    %r10,-0x58(%rbp)
  412332:	jmpq   411e92 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  412337:	lea    -0x860(%rbp),%r10
  41233e:	mov    %r14,%r11
  412341:	mov    %r11,(%r10)
  412344:	mov    %r12,%r10
  412347:	mov    0x10(%r10),%r10
  41234b:	mov    %r10,-0x1a18(%rbp)
  412352:	mov    %r14,%r11
  412355:	mov    %r11,(%r10)
  412358:	mov    -0x1a18(%rbp),%r10
  41235f:	movabs $0x72,%r11
  412369:	mov    %r11,0x8(%r10)
  41236d:	mov    -0x1a18(%rbp),%r10
  412374:	add    $0x10,%r10
  41237b:	mov    %r10,-0x1a20(%rbp)
  412382:	mov    %r12,%r10
  412385:	mov    -0x1a20(%rbp),%r11
  41238c:	mov    %r11,0x10(%r10)
  412390:	lea    -0x860(%rbp),%r10
  412397:	mov    %rbx,%r11
  41239a:	mov    %r11,(%r10)
  41239d:	mov    %r12,%r10
  4123a0:	mov    0x10(%r10),%r10
  4123a4:	mov    %r10,-0x1a28(%rbp)
  4123ab:	mov    %rbx,%r11
  4123ae:	mov    %r11,(%r10)
  4123b1:	mov    -0x1a28(%rbp),%r10
  4123b8:	movabs $0x73,%r11
  4123c2:	mov    %r11,0x8(%r10)
  4123c6:	mov    -0x1a28(%rbp),%r10
  4123cd:	add    $0x10,%r10
  4123d4:	mov    %r10,-0x1a30(%rbp)
  4123db:	mov    %r12,%r10
  4123de:	mov    -0x1a30(%rbp),%r11
  4123e5:	mov    %r11,0x10(%r10)
  4123e9:	mov    %r12,%rdi
  4123ec:	movabs $0x4,%rsi
  4123f6:	mov    %esi,%esi
  4123f8:	xor    %eax,%eax
  4123fa:	callq  41c730 <p111_rt_fail>
  4123ff:	mov    %rax,-0x1a38(%rbp)
  412406:	mov    -0x10(%rbp),%r12
  41240a:	mov    -0x8(%rbp),%rbx
  41240e:	mov    -0x18(%rbp),%r13
  412412:	mov    -0x20(%rbp),%r14
  412416:	mov    -0x28(%rbp),%r15
  41241a:	mov    %rbp,%rsp
  41241d:	pop    %rbp
  41241e:	retq   
  41241f:	mov    %r13,%rdi
  412422:	shr    $0x28,%rdi
  412426:	and    $0xffff,%rdi
  41242d:	movabs $0xa5,%r11
  412437:	cmp    %r11,%rdi
  41243a:	jne    4127fc <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x9b5>
  412440:	mov    %r12,%rdi
  412443:	mov    %r13,%rsi
  412446:	lea    -0x860(%rbp),%rdx
  41244d:	xor    %eax,%eax
  41244f:	callq  421d40 <p125_rt_take2>
  412454:	mov    %rax,-0x19c0(%rbp)
  41245b:	lea    -0x860(%rbp),%r10
  412462:	mov    (%r10),%r10
  412465:	mov    %r10,-0x1a40(%rbp)
  41246c:	lea    -0x860(%rbp),%r10
  412473:	mov    0x8(%r10),%r10
  412477:	mov    %r10,-0x1a48(%rbp)
  41247e:	mov    %rbx,%rdi
  412481:	shr    $0x28,%rdi
  412485:	and    $0xffff,%rdi
  41248c:	movabs $0xa4,%r11
  412496:	cmp    %r11,%rdi
  412499:	jne    4125ab <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x764>
  41249f:	mov    %rbx,%r10
  4124a2:	shr    $0x28,%r10
  4124a6:	mov    %r10,-0x1a50(%rbp)
  4124ad:	and    $0x7fffff,%r10
  4124b4:	mov    %r10,-0x1a58(%rbp)
  4124bb:	movabs $0xa4,%r10
  4124c5:	or     $0x10000,%r10
  4124cc:	mov    %r10,-0x1a60(%rbp)
  4124d3:	mov    -0x1a58(%rbp),%r10
  4124da:	mov    -0x1a60(%rbp),%r11
  4124e1:	cmp    %r11,%r10
  4124e4:	jne    412517 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6d0>
  4124ea:	mov    %rbx,%r10
  4124ed:	movabs $0xffffffffff,%r11
  4124f7:	and    %r11,%r10
  4124fa:	mov    %r10,-0x1a70(%rbp)
  412501:	lea    -0x860(%rbp),%r10
  412508:	mov    -0x1a70(%rbp),%r11
  41250f:	mov    %r11,(%r10)
  412512:	jmpq   412532 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x6eb>
  412517:	mov    %r12,%rdi
  41251a:	mov    %rbx,%rsi
  41251d:	lea    -0x860(%rbp),%rdx
  412524:	xor    %eax,%eax
  412526:	callq  421ac0 <p125_rt_take1>
  41252b:	mov    %rax,-0x19c0(%rbp)
  412532:	lea    -0x860(%rbp),%r10
  412539:	mov    (%r10),%r10
  41253c:	mov    %r10,-0x1a78(%rbp)
  412543:	mov    %r12,%rdi
  412546:	mov    -0x1a40(%rbp),%rsi
  41254d:	xor    %eax,%eax
  41254f:	callq  41bfa0 <p111_rt_sink>
  412554:	mov    %rax,-0x19c0(%rbp)
  41255b:	mov    %r12,%rdi
  41255e:	mov    -0x1a48(%rbp),%rsi
  412565:	xor    %eax,%eax
  412567:	callq  41bfa0 <p111_rt_sink>
  41256c:	mov    %rax,-0x19c0(%rbp)
  412573:	mov    %r12,%rdi
  412576:	mov    -0x1a78(%rbp),%rsi
  41257d:	xor    %eax,%eax
  41257f:	callq  41bfa0 <p111_rt_sink>
  412584:	mov    %rax,-0x19c0(%rbp)
  41258b:	movabs $0x1,%r10
  412595:	mov    %r10,%rdi
  412598:	movabs $0x100a40000000000,%r10
  4125a2:	mov    %r10,-0x58(%rbp)
  4125a6:	jmpq   411e92 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  4125ab:	mov    %rbx,%rdi
  4125ae:	shr    $0x28,%rdi
  4125b2:	and    $0xffff,%rdi
  4125b9:	movabs $0xa5,%r11
  4125c3:	cmp    %r11,%rdi
  4125c6:	jne    4126e4 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x89d>
  4125cc:	mov    %r12,%rdi
  4125cf:	mov    %rbx,%rsi
  4125d2:	lea    -0x860(%rbp),%rdx
  4125d9:	xor    %eax,%eax
  4125db:	callq  421d40 <p125_rt_take2>
  4125e0:	mov    %rax,-0x19c0(%rbp)
  4125e7:	lea    -0x860(%rbp),%r10
  4125ee:	mov    (%r10),%rbx
  4125f1:	lea    -0x860(%rbp),%r10
  4125f8:	mov    0x8(%r10),%r10
  4125fc:	mov    %r10,-0x1a88(%rbp)
  412603:	lea    -0x860(%rbp),%r10
  41260a:	mov    -0x1a48(%rbp),%r11
  412611:	mov    %r11,(%r10)
  412614:	lea    -0x860(%rbp),%r10
  41261b:	mov    %r14,%r11
  41261e:	mov    %r11,0x8(%r10)
  412622:	lea    -0x860(%rbp),%r10
  412629:	mov    -0x1a88(%rbp),%r11
  412630:	mov    %r11,0x10(%r10)
  412634:	mov    0x10(%r12),%rdi
  412639:	mov    %rdi,%r10
  41263c:	mov    -0x1a48(%rbp),%r11
  412643:	mov    %r11,(%r10)
  412646:	lea    -0x860(%rbp),%r10
  41264d:	mov    0x8(%r10),%rsi
  412651:	mov    %rsi,0x8(%rdi)
  412655:	lea    -0x860(%rbp),%r10
  41265c:	mov    0x10(%r10),%rsi
  412660:	mov    %rsi,0x10(%rdi)
  412664:	mov    %rdi,%r10
  412667:	movabs $0x74,%r11
  412671:	mov    %r11,0x18(%r10)
  412675:	mov    %rdi,%r10
  412678:	add    $0x20,%r10
  41267f:	mov    %r10,-0x1aa0(%rbp)
  412686:	mov    %r12,%r10
  412689:	mov    -0x1aa0(%rbp),%r11
  412690:	mov    %r11,0x10(%r10)
  412694:	add    $0x1,%r15
  41269b:	lea    -0x860(%rbp),%r10
  4126a2:	mov    -0x1a40(%rbp),%r11
  4126a9:	mov    %r11,(%r10)
  4126ac:	lea    -0x860(%rbp),%r10
  4126b3:	mov    %rbx,%r11
  4126b6:	mov    %r11,0x8(%r10)
  4126ba:	lea    -0x860(%rbp),%r10
  4126c1:	mov    %r14,%r11
  4126c4:	mov    %r11,0x10(%r10)
  4126c8:	mov    -0x1a40(%rbp),%r10
  4126cf:	mov    %r10,%r13
  4126d2:	movabs $0x0,%r10
  4126dc:	mov    %r10,%rdi
  4126df:	jmpq   411e92 <p114r_FID_36_100_105_114_101_99_116_46_119_97_114_112_+0x4b>
  4126e4:	mov    %r12,%rdi
  4126e7:	mov    -0x1a40(%rbp),%rsi
  4126ee:	xor    %eax,%eax
  4126f0:	callq  41bfa0 <p111_rt_sink>
  4126f5:	mov    %rax,-0x19c0(%rbp)
  4126fc:	mov    %r12,%rdi
  4126ff:	mov    -0x1a48(%rbp),%rsi
  412706:	xor    %eax,%eax
  412708:	callq  41bfa0 <p111_rt_sink>
  41270d:	mov    %rax,-0x19c0(%rbp)
  412714:	lea    -0x860(%rbp),%r10
  41271b:	mov    %r14,%r11
  41271e:	mov    %r11,(%r10)
  412721:	mov    %r12,%r10
  412724:	mov    0x10(%r10),%r10
  412728:	mov    %r10,-0x1aa8(%rbp)
  41272f:	mov    %r14,%r11
  412732:	mov    %r11,(%r10)
  412735:	mov    -0x1aa8(%rbp),%r10
  41273c:	movabs $0x76,%r11
  412746:	mov    %r11,0x8(%r10)
  41274a:	mov    -0x1aa8(%rbp),%r10
  412751:	add    $0x10,%r10
  412758:	mov    %r10,-0x1ab0(%rbp)
  41275f:	mov    %r12,%r10
  412762:	mov    -0x1ab0(%rbp),%r11
  412769:	mov    %r11,0x10(%r10)
  41276d:	lea    -0x860(%rbp),%r10
  412774:	mov    %rbx,%r11
  412777:	mov    %r11,(%r10)
  41277a:	mov    %r12,%r10
  41277d:	mov    0x10(%r10),%r10
  412781:	mov    %r10,-0x1ab8(%rbp)
  412788:	mov    %rbx,%r11
  41278b:	mov    %r11,(%r10)
  41278e:	mov    -0x1ab8(%rbp),%r10
  412795:	movabs $0x77,%r11
  41279f:	mov    %r11,0x8(%r10)
  4127a3:	mov    -0x1ab8(%rbp),%r10
  4127aa:	add    $0x10,%r10
  4127b1:	mov    %r10,-0x1ac0(%rbp)
  4127b8:	mov    %r12,%r10
  4127bb:	mov    -0x1ac0(%rbp),%r11
  4127c2:	mov    %r11,0x10(%r10)
  4127c6:	mov    %r12,%rdi
  4127c9:	movabs $0x4,%rsi
  4127d3:	mov    %esi,%esi
  4127d5:	xor    %eax,%eax
  4127d7:	callq  41c730 <p111_rt_fail>
  4127dc:	mov    %rax,-0x1a38(%rbp)
  4127e3:	mov    -0x10(%rbp),%r12
  4127e7:	mov    -0x8(%rbp),%rbx
  4127eb:	mov    -0x18(%rbp),%r13
  4127ef:	mov    -0x20(%rbp),%r14
  4127f3:	mov    -0x28(%rbp),%r15
  4127f7:	mov    %rbp,%rsp
  4127fa:	pop    %rbp
  4127fb:	retq   
  4127fc:	lea    -0x860(%rbp),%r10
  412803:	mov    %r14,%r11
  412806:	mov    %r11,(%r10)
  412809:	mov    %r12,%r10
  41280c:	mov    0x10(%r10),%r10
  412810:	mov    %r10,-0x1ac8(%rbp)
  412817:	mov    %r14,%r11
  41281a:	mov    %r11,(%r10)
  41281d:	mov    -0x1ac8(%rbp),%r10
  412824:	movabs $0x78,%r11
  41282e:	mov    %r11,0x8(%r10)
  412832:	mov    -0x1ac8(%rbp),%r10
  412839:	add    $0x10,%r10
  412840:	mov    %r10,-0x1ad0(%rbp)
  412847:	mov    %r12,%r10
  41284a:	mov    -0x1ad0(%rbp),%r11
  412851:	mov    %r11,0x10(%r10)
  412855:	lea    -0x860(%rbp),%r10
  41285c:	mov    %rbx,%r11
  41285f:	mov    %r11,(%r10)
  412862:	mov    %r12,%r10
  412865:	mov    0x10(%r10),%r10
  412869:	mov    %r10,-0x1ad8(%rbp)
  412870:	mov    %rbx,%r11
  412873:	mov    %r11,(%r10)
  412876:	mov    -0x1ad8(%rbp),%r10
  41287d:	movabs $0x79,%r11
  412887:	mov    %r11,0x8(%r10)
  41288b:	mov    -0x1ad8(%rbp),%r10
  412892:	add    $0x10,%r10
  412899:	mov    %r10,-0x1ae0(%rbp)
  4128a0:	mov    %r12,%r10
  4128a3:	mov    -0x1ae0(%rbp),%r11
  4128aa:	mov    %r11,0x10(%r10)
  4128ae:	lea    -0x860(%rbp),%r10
  4128b5:	mov    %r13,%r11
  4128b8:	mov    %r11,(%r10)
  4128bb:	mov    %r12,%r10
  4128be:	mov    0x10(%r10),%r10
  4128c2:	mov    %r10,-0x1ae8(%rbp)
  4128c9:	mov    %r13,%r11
  4128cc:	mov    %r11,(%r10)
  4128cf:	mov    -0x1ae8(%rbp),%r10
  4128d6:	movabs $0x7a,%r11
  4128e0:	mov    %r11,0x8(%r10)
  4128e4:	mov    -0x1ae8(%rbp),%r10
  4128eb:	add    $0x10,%r10
  4128f2:	mov    %r10,-0x1af0(%rbp)
  4128f9:	mov    %r12,%r10
  4128fc:	mov    -0x1af0(%rbp),%r11
  412903:	mov    %r11,0x10(%r10)
  412907:	mov    %r12,%rdi
  41290a:	movabs $0x4,%rsi
  412914:	mov    %esi,%esi
  412916:	xor    %eax,%eax
  412918:	callq  41c730 <p111_rt_fail>
  41291d:	mov    %rax,-0x1a38(%rbp)
  412924:	mov    -0x10(%rbp),%r12
  412928:	mov    -0x8(%rbp),%rbx
  41292c:	mov    -0x18(%rbp),%r13
  412930:	mov    -0x20(%rbp),%r14
  412934:	mov    -0x28(%rbp),%r15
  412938:	mov    %rbp,%rsp
  41293b:	pop    %rbp
  41293c:	retq   

Disassembly of section .fini:
