
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402f60 <nx_rt_fast_id>:
  402f60:	shr    $0x28,%rsi
  402f64:	movzwl %si,%eax
  402f67:	retq   

Disassembly of section .fini:
