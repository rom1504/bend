
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004030a0 <nx_rt_fast_id>:
  4030a0:	shr    $0x28,%rsi
  4030a4:	movzwl %si,%eax
  4030a7:	retq   

Disassembly of section .fini:
