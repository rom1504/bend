
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004046e0 <nx_rt_pair_take2>:
  4046e0:	movabs $0xffffffffff,%rax
  4046ea:	push   %r15
  4046ec:	and    %rsi,%rax
  4046ef:	push   %r14
  4046f1:	push   %r13
  4046f3:	lea    0x0(,%rax,8),%rdx
  4046fb:	push   %r12
  4046fd:	push   %rbp
  4046fe:	mov    (%rdi),%rbp
  404701:	mov    0x8(%rdi),%r14
  404705:	lea    0x0(%rbp,%rdx,1),%rcx
  40470a:	test   %rsi,%rsi
  40470d:	js     404770 <nx_rt_pair_take2+0x90>
  40470f:	mov    (%rcx),%r13
  404712:	mov    0x8(%rbp,%rdx,1),%r12
  404717:	cmp    $0x310817f,%rax
  40471d:	ja     404730 <nx_rt_pair_take2+0x50>
  40471f:	pop    %rbp
  404720:	mov    %r13,%rax
  404723:	mov    %r12,%rdx
  404726:	pop    %r12
  404728:	pop    %r13
  40472a:	pop    %r14
  40472c:	pop    %r15
  40472e:	retq   
  40472f:	nop
  404730:	mov    0x8(%r14),%rdx
  404734:	mov    %rdx,0x0(%rbp,%rax,8)
  404739:	mov    0x3da99(%rip),%edx        # 4421d8 <KEEP_WORDS>
  40473f:	mov    %rax,0x8(%r14)
  404743:	mov    0x108(%r14),%rax
  40474a:	add    $0x2,%rax
  40474e:	mov    %rax,0x108(%r14)
  404755:	cmp    %rdx,%rax
  404758:	jae    401be0 <nx_rt_pair_take2.cold>
  40475e:	pop    %rbp
  40475f:	mov    %r13,%rax
  404762:	mov    %r12,%rdx
  404765:	pop    %r12
  404767:	pop    %r13
  404769:	pop    %r14
  40476b:	pop    %r15
  40476d:	retq   
  40476e:	xchg   %ax,%ax
  404770:	mov    0x4(%rcx),%edx
  404773:	mov    (%rcx),%edi
  404775:	shl    $0x20,%rdx
  404779:	or     %rdi,%rdx
  40477c:	mov    %rdx,%r15
  40477f:	and    $0xffffff,%edx
  404785:	shr    $0x18,%r15
  404789:	lea    0x8(,%r15,8),%rdi
  404791:	lea    0x0(%rbp,%rdi,1),%r8
  404796:	cmp    $0x1,%rdx
  40479a:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  4047a0:	mov    (%rcx),%edx
  4047a2:	mov    (%r14),%rdx
  4047a5:	mov    -0x8(%rbp,%rdi,1),%r13
  4047aa:	mov    (%r8),%r12
  4047ad:	mov    %rdx,(%rcx)
  4047b0:	mov    0x3da22(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4047b6:	mov    %rax,(%r14)
  4047b9:	mov    0x100(%r14),%rax
  4047c0:	add    $0x1,%rax
  4047c4:	mov    %rax,0x100(%r14)
  4047cb:	cmp    %rdx,%rax
  4047ce:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  4047d4:	mov    %r15,%rax
  4047d7:	jmpq   404717 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
