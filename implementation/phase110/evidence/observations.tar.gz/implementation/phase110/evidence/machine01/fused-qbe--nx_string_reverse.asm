
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c90 <nx_string_reverse>:
  401c90:	endbr64 
  401c94:	push   %rbp
  401c95:	mov    %rsp,%rbp
  401c98:	sub    $0x8,%rsp
  401c9c:	push   %rbx
  401c9d:	push   %r12
  401c9f:	push   %r13
  401ca1:	mov    %rdx,%rax
  401ca4:	mov    %rax,%r13
  401ca7:	nopw   0x0(%rax,%rax,1)
  401cb0:	mov    %rsi,%r12
  401cb3:	mov    %rdi,%rbx
  401cb6:	callq  402a80 <nx_rt_fast_id>
  401cbb:	mov    %r13,%rdx
  401cbe:	mov    %r12,%rsi
  401cc1:	mov    %rbx,%rdi
  401cc4:	cmp    $0x2,%eax
  401cc7:	je     401d10 <nx_string_reverse+0x80>
  401cc9:	cmp    $0x3,%eax
  401ccc:	jne    401d04 <nx_string_reverse+0x74>
  401cce:	mov    %rdx,%r8
  401cd1:	mov    $0x0,%ecx
  401cd6:	mov    $0x3,%edx
  401cdb:	mov    %rdi,%rbx
  401cde:	callq  402d50 <nx_rt_rebuild2>
  401ce3:	mov    %rbx,%rdi
  401ce6:	mov    %rax,%r12
  401ce9:	mov    $0x0,%esi
  401cee:	mov    %rdi,%rbx
  401cf1:	callq  402d30 <nx_rt_fast_field>
  401cf6:	mov    %r12,%rdx
  401cf9:	mov    %rbx,%rdi
  401cfc:	mov    %rax,%rsi
  401cff:	mov    %rdx,%r13
  401d02:	jmp    401cb0 <nx_string_reverse+0x20>
  401d04:	mov    $0x1,%esi
  401d09:	callq  402580 <nx_rt_fail>
  401d0e:	jmp    401d13 <nx_string_reverse+0x83>
  401d10:	mov    %rdx,%rax
  401d13:	pop    %r13
  401d15:	pop    %r12
  401d17:	pop    %rbx
  401d18:	leaveq 
  401d19:	retq   

Disassembly of section .fini:
