
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e50 <nx_string_reverse>:
  401e50:	push   %r14
  401e52:	push   %rbx
  401e53:	push   %rax
  401e54:	mov    %rdx,%r14
  401e57:	mov    %rdi,%rbx
  401e5a:	nopw   0x0(%rax,%rax,1)
  401e60:	mov    %rsi,%rax
  401e63:	shr    $0x28,%rax
  401e67:	cmp    $0x3,%ax
  401e6b:	jne    401e8a <nx_string_reverse+0x3a>
  401e6d:	mov    %rbx,%rdi
  401e70:	mov    %r14,%rdx
  401e73:	callq  403b10 <nx_rt_rebuild2_c3_k0>
  401e78:	mov    %rax,%r14
  401e7b:	mov    %rbx,%rdi
  401e7e:	xor    %esi,%esi
  401e80:	callq  402ea0 <nx_rt_fast_field>
  401e85:	mov    %rax,%rsi
  401e88:	jmp    401e60 <nx_string_reverse+0x10>
  401e8a:	movzwl %ax,%eax
  401e8d:	cmp    $0x2,%eax
  401e90:	jne    401e9d <nx_string_reverse+0x4d>
  401e92:	mov    %r14,%rax
  401e95:	add    $0x8,%rsp
  401e99:	pop    %rbx
  401e9a:	pop    %r14
  401e9c:	retq   
  401e9d:	mov    %rbx,%rdi
  401ea0:	mov    $0x1,%esi
  401ea5:	add    $0x8,%rsp
  401ea9:	pop    %rbx
  401eaa:	pop    %r14
  401eac:	jmpq   4026a0 <nx_rt_fail>

Disassembly of section .fini:
