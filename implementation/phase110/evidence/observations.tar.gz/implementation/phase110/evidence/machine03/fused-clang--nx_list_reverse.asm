
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e10 <nx_list_reverse>:
  401e10:	push   %r15
  401e12:	push   %r14
  401e14:	push   %rbx
  401e15:	mov    %rdx,%r14
  401e18:	mov    %rsi,%r15
  401e1b:	mov    %rdi,%rbx
  401e1e:	xchg   %ax,%ax
  401e20:	mov    %rbx,%rdi
  401e23:	mov    %r15,%rsi
  401e26:	callq  402c20 <nx_rt_fast_id>
  401e2b:	cmp    $0x1,%eax
  401e2e:	jne    401e57 <nx_list_reverse+0x47>
  401e30:	mov    %rbx,%rdi
  401e33:	mov    %r15,%rsi
  401e36:	mov    $0x1,%edx
  401e3b:	xor    %ecx,%ecx
  401e3d:	mov    %r14,%r8
  401e40:	callq  402ef0 <nx_rt_rebuild2>
  401e45:	mov    %rax,%r14
  401e48:	mov    %rbx,%rdi
  401e4b:	xor    %esi,%esi
  401e4d:	callq  402ed0 <nx_rt_fast_field>
  401e52:	mov    %rax,%r15
  401e55:	jmp    401e20 <nx_list_reverse+0x10>
  401e57:	test   %eax,%eax
  401e59:	jne    401e64 <nx_list_reverse+0x54>
  401e5b:	mov    %r14,%rax
  401e5e:	pop    %rbx
  401e5f:	pop    %r14
  401e61:	pop    %r15
  401e63:	retq   
  401e64:	mov    %rbx,%rdi
  401e67:	mov    $0x1,%esi
  401e6c:	pop    %rbx
  401e6d:	pop    %r14
  401e6f:	pop    %r15
  401e71:	jmpq   4026d0 <nx_rt_fail>

Disassembly of section .fini:
