
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004026a0 <nx_rt_field>:
  4026a0:	sub    $0x8,%rsp
  4026a4:	cmpb   $0x0,0x4ad5(%rip)        # 407180 <nx_active>
  4026ab:	je     4026b9 <nx_rt_field+0x19>
  4026ad:	lea    0x4aec(%rip),%rdx        # 4071a0 <nx_context>
  4026b4:	cmp    %rdx,%rdi
  4026b7:	je     4026c8 <nx_rt_field+0x28>
  4026b9:	lea    0x1973(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  4026c0:	callq  4019b0 <err_fail>
  4026c5:	nopl   (%rax)
  4026c8:	mov    %esi,%ecx
  4026ca:	cmp    $0x1,%ecx
  4026cd:	jbe    4026e0 <nx_rt_field+0x40>
  4026cf:	lea    0x1c72(%rip),%rdi        # 404348 <_IO_stdin_used+0x348>
  4026d6:	callq  4019b0 <err_fail>
  4026db:	nopl   0x0(%rax,%rax,1)
  4026e0:	mov    $0x1,%eax
  4026e5:	mov    0x4ad5(%rip),%esi        # 4071c0 <nx_context+0x20>
  4026eb:	shl    %cl,%eax
  4026ed:	test   %eax,%esi
  4026ef:	je     4026cf <nx_rt_field+0x2f>
  4026f1:	not    %eax
  4026f3:	add    $0x2,%rcx
  4026f7:	and    %esi,%eax
  4026f9:	mov    %eax,0x4ac1(%rip)        # 4071c0 <nx_context+0x20>
  4026ff:	mov    (%rdx,%rcx,8),%rax
  402703:	movq   $0xffffffffffffffff,(%rdx,%rcx,8)
  40270b:	add    $0x8,%rsp
  40270f:	retq   

Disassembly of section .fini:
