function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $bst$pick$(_l_0, _v_0, _r_0, _path_0, _z_0) {
  if (_z_0) {
    return {$: "Tuple", "fst": _l_0, "snd": {$: "Con", "head": {$: "BF", "v": _v_0, "other": _r_0, "left": true}, "tail": _path_0}};
  } else {
    return {$: "Tuple", "fst": _r_0, "snd": {$: "Con", "head": {$: "BF", "v": _v_0, "other": _l_0, "left": false}, "tail": _path_0}};
  }
}

function $bst$step$(_x_0, _st_0) {
  const _t_0 = _st_0["fst"];
  if (_t_0.$ === "BLeaf") {
    const _path_0 = _st_0["snd"];
    return {$: "Tuple", "fst": {$: "BLeaf"}, "snd": _path_0};
  } else {
    const _l_0 = _t_0["l"];
    const _v0_0 = _t_0["v"];
    const _r_0 = _t_0["r"];
    const _path_1 = _st_0["snd"];
    const _v_0 = _v0_0;
    return $bst$pick$(_l_0, _v_0, _r_0, _path_1, (_x_0 < _v_0));
  }
}

function $bst$down$($0, $1, $2) {
  for (;;) {
    {
      const _fuel_0 = $0;
      const _x_0 = $1;
      const _st_0 = $2;
      if (_fuel_0 === 0) {
        return _st_0;
      } else {
        const _f_0 = (_fuel_0 - 1);
        $0 = _f_0;
        $1 = _x_0;
        $2 = ($bst$step$(_x_0, _st_0));
        continue;
      }
    }
  }
}

function $bst$up$($0, $1) {
  for (;;) {
    {
      const _path_0 = $0;
      const _acc_0 = $1;
      if (_path_0.$ === "Nil") {
        return _acc_0;
      } else {
        const _t_0 = _path_0["head"];
        const _v_0 = _t_0["v"];
        const _other_0 = _t_0["other"];
        const _t_1 = _t_0["left"];
        if (_t_1) {
          const _rest_0 = _path_0["tail"];
          $0 = _rest_0;
          $1 = {$: "BNode", "l": _acc_0, "v": _v_0, "r": _other_0};
          continue;
        } else {
          const _rest_1 = _path_0["tail"];
          $0 = _rest_1;
          $1 = {$: "BNode", "l": _other_0, "v": _v_0, "r": _acc_0};
          continue;
        }
      }
    }
  }
}

function $insert$fin$(_x_0, _st_0) {
  const _t_0 = _st_0["fst"];
  if (_t_0.$ === "BLeaf") {
    const _path_0 = _st_0["snd"];
    return $bst$up$(_path_0, {$: "BNode", "l": {$: "BLeaf"}, "v": _x_0, "r": {$: "BLeaf"}});
  } else {
    const _l_0 = _t_0["l"];
    const _v_0 = _t_0["v"];
    const _r_0 = _t_0["r"];
    const _path_1 = _st_0["snd"];
    return $bst$up$(_path_1, {$: "BNode", "l": _l_0, "v": _v_0, "r": _r_0});
  }
}

function $insert$(_x_0, _t_0) {
  return $insert$fin$(_x_0, ($bst$down$(8, _x_0, {$: "Tuple", "fst": _t_0, "snd": {$: "Nil"}})));
}

function $inorder$($0, $1) {
  for (;;) {
    {
      const _t_0 = $0;
      const _acc_0 = $1;
      if (_t_0.$ === "BLeaf") {
        return _acc_0;
      } else {
        const _l_0 = _t_0["l"];
        const _v_0 = _t_0["v"];
        const _r_0 = _t_0["r"];
        const _x_0 = ($inorder$(_l_0, _acc_0));
        const _x_1 = (Math.imul(_x_0, 10) >>> 0);
        $0 = _r_0;
        $1 = ((_x_1 + _v_0) >>> 0);
        continue;
      }
    }
  }
}

function $main$out$() {
  const _t0_0 = {$: "BLeaf"};
  const _t1_0 = ($insert$(5, _t0_0));
  const _t2_0 = ($insert$(2, _t1_0));
  const _t3_0 = ($insert$(8, _t2_0));
  const _t4_0 = ($insert$(1, _t3_0));
  const _t5_0 = ($insert$(9, _t4_0));
  return $inorder$(_t5_0, 0);
}

function $p37$bst$insert$(_fuel_0, _x_0, _tree_0) {
  return $insert$fin$(_x_0, ($bst$down$(_fuel_0, _x_0, {$: "Tuple", "fst": _tree_0, "snd": {$: "Nil"}})));
}

function $p37$bst$build$($0, $1, $2, $3, $4) {
  for (;;) {
    {
      const _n_0 = $0;
      const _fuel_0 = $1;
      const _i_0 = $2;
      const _seed_0 = $3;
      const _tree_0 = $4;
      if (_n_0 === 0) {
        return _tree_0;
      } else {
        const _p_0 = (_n_0 - 1);
        const _x_0 = (Math.imul(_seed_0, 2) >>> 0);
        const _x_1 = ((_x_0 + 1) >>> 0);
        const _x_2 = (Math.imul(_i_0, _x_1) >>> 0);
        const _x_3 = ((_x_2 + _seed_0) >>> 0);
        const _x_4 = (257 === 0 ? _x_3 : _x_3 % 257);
        $0 = _p_0;
        $1 = _fuel_0;
        $2 = ((_i_0 + 1) >>> 0);
        $3 = _seed_0;
        $4 = ($p37$bst$insert$(_fuel_0, _x_4, _tree_0));
        continue;
      }
    }
  }
}

function $bench$(_size_0, _seed_0) {
  return $inorder$(($p37$bst$build$(_size_0, nat_chk(_size_0 + 1), 0, _seed_0, {$: "BLeaf"})), 0);
}
export default {
  "bst.pick": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($bst$pick$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "bst.step": run_lib((a0, a1) => { const r = (run_loop($bst$step$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "bst.down": run_lib((a0, a1, a2) => { const r = (run_loop($bst$down$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "bst.up": run_lib((a0, a1) => { const r = (run_loop($bst$up$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "insert.fin": run_lib((a0, a1) => { const r = (run_loop($insert$fin$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "insert": run_lib((a0, a1) => { const r = (run_loop($insert$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "inorder": run_lib((a0, a1) => { const r = (run_loop($inorder$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "main.out": run_lib(() => { const r = (run_loop($main$out$()));  return r; }, 0),
  "p37.bst.insert": run_lib((a0, a1, a2) => { const r = (run_loop($p37$bst$insert$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "p37.bst.build": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($p37$bst$build$(nat_host(a0), nat_host(a1), (a2), (a3), (a4)))); BigInt(a0); BigInt(a1); (a2); (a3); (a4); return r; }, 5),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
};
