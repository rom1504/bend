
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/fused-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c70 <nx_string_reverse>:
  401c70:	push   %r13
  401c72:	mov    %rdi,%r13
  401c75:	push   %r12
  401c77:	mov    %rdx,%r12
  401c7a:	push   %rbp
  401c7b:	mov    %rsi,%rbp
  401c7e:	jmp    401caa <nx_string_reverse+0x3a>
  401c80:	cmp    $0x3,%eax
  401c83:	jne    401cc8 <nx_string_reverse+0x58>
  401c85:	mov    %r12,%r8
  401c88:	mov    %rbp,%rsi
  401c8b:	xor    %ecx,%ecx
  401c8d:	mov    $0x3,%edx
  401c92:	mov    %r13,%rdi
  401c95:	callq  402d10 <nx_rt_rebuild2>
  401c9a:	xor    %esi,%esi
  401c9c:	mov    %r13,%rdi
  401c9f:	mov    %rax,%r12
  401ca2:	callq  402cf0 <nx_rt_fast_field>
  401ca7:	mov    %rax,%rbp
  401caa:	mov    %rbp,%rsi
  401cad:	mov    %r13,%rdi
  401cb0:	callq  402a40 <nx_rt_fast_id>
  401cb5:	cmp    $0x2,%eax
  401cb8:	jne    401c80 <nx_string_reverse+0x10>
  401cba:	mov    %r12,%rax
  401cbd:	pop    %rbp
  401cbe:	pop    %r12
  401cc0:	pop    %r13
  401cc2:	retq   
  401cc3:	nopl   0x0(%rax,%rax,1)
  401cc8:	pop    %rbp
  401cc9:	mov    %r13,%rdi
  401ccc:	pop    %r12
  401cce:	mov    $0x1,%esi
  401cd3:	pop    %r13
  401cd5:	jmpq   402540 <nx_rt_fail>

Disassembly of section .fini:
