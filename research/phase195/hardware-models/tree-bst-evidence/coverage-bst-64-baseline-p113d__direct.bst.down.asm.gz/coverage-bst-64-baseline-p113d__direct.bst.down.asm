0000000000408edc <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_>:
  408edc:	push   rbp
  408edd:	mov    rbp,rsp
  408ee0:	sub    rsp,0x920
  408ee7:	mov    QWORD PTR [rbp-0x10],r12
  408eeb:	mov    QWORD PTR [rbp-0x8],rbx
  408eef:	mov    QWORD PTR [rbp-0x18],r13
  408ef3:	mov    rax,rdi
  408ef6:	mov    r12,rax
  408ef9:	mov    rax,rsi
  408efc:	mov    rdi,rax
  408eff:	mov    rax,rdx
  408f02:	mov    rbx,rax
  408f05:	mov    rax,rcx
  408f08:	mov    rdx,rax
  408f0b:	cmp    rdi,0x0
  408f12:	jne    408f2c <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x50>
  408f18:	mov    rax,rdx
  408f1b:	mov    r12,QWORD PTR [rbp-0x10]
  408f1f:	mov    rbx,QWORD PTR [rbp-0x8]
  408f23:	mov    r13,QWORD PTR [rbp-0x18]
  408f27:	mov    rsp,rbp
  408f2a:	pop    rbp
  408f2b:	ret    
  408f2c:	mov    r13,rdi
  408f2f:	sub    r13,0x1
  408f36:	mov    r10,r12
  408f39:	mov    QWORD PTR [rsp+0x18],r10
  408f3e:	mov    r10,rbx
  408f41:	mov    QWORD PTR [rsp+0x20],r10
  408f46:	mov    r10,rdx
  408f49:	mov    QWORD PTR [rsp+0x28],r10
  408f4e:	mov    rdi,QWORD PTR [rsp+0x18]
  408f53:	mov    rsi,QWORD PTR [rsp+0x20]
  408f58:	mov    rdx,QWORD PTR [rsp+0x28]
  408f5d:	xor    eax,eax
  408f5f:	call   40891c <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_>
  408f64:	mov    rdx,rax
  408f67:	mov    rdi,r13
  408f6a:	jmp    408f0b <p113d_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2f>

