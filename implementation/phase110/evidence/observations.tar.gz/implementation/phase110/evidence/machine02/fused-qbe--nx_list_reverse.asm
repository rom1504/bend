
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	endbr64 
  401df4:	push   %rbp
  401df5:	mov    %rsp,%rbp
  401df8:	sub    $0x8,%rsp
  401dfc:	push   %rbx
  401dfd:	push   %r12
  401dff:	push   %r13
  401e01:	mov    %rdx,%rax
  401e04:	mov    %rax,%r13
  401e07:	nopw   0x0(%rax,%rax,1)
  401e10:	mov    %rsi,%r12
  401e13:	mov    %rdi,%rbx
  401e16:	callq  402c40 <nx_rt_fast_id>
  401e1b:	mov    %r13,%rdx
  401e1e:	mov    %r12,%rsi
  401e21:	mov    %rbx,%rdi
  401e24:	cmp    $0x0,%eax
  401e27:	je     401e70 <nx_list_reverse+0x80>
  401e29:	cmp    $0x1,%eax
  401e2c:	jne    401e64 <nx_list_reverse+0x74>
  401e2e:	mov    %rdx,%r8
  401e31:	mov    $0x0,%ecx
  401e36:	mov    $0x1,%edx
  401e3b:	mov    %rdi,%rbx
  401e3e:	callq  402f10 <nx_rt_rebuild2>
  401e43:	mov    %rbx,%rdi
  401e46:	mov    %rax,%r12
  401e49:	mov    $0x0,%esi
  401e4e:	mov    %rdi,%rbx
  401e51:	callq  402ef0 <nx_rt_fast_field>
  401e56:	mov    %r12,%rdx
  401e59:	mov    %rbx,%rdi
  401e5c:	mov    %rax,%rsi
  401e5f:	mov    %rdx,%r13
  401e62:	jmp    401e10 <nx_list_reverse+0x20>
  401e64:	mov    $0x1,%esi
  401e69:	callq  4026f0 <nx_rt_fail>
  401e6e:	jmp    401e73 <nx_list_reverse+0x83>
  401e70:	mov    %rdx,%rax
  401e73:	pop    %r13
  401e75:	pop    %r12
  401e77:	pop    %rbx
  401e78:	leaveq 
  401e79:	retq   

Disassembly of section .fini:
