
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d30 <nx_rt_rebuild2>:
  402d30:	movabs $0xffffffffff,%r9
  402d3a:	push   %r14
  402d3c:	push   %r13
  402d3e:	and    %rsi,%r9
  402d41:	mov    %edx,%r13d
  402d44:	push   %r12
  402d46:	lea    0x0(,%r9,8),%rdx
  402d4e:	push   %rbp
  402d4f:	mov    %ecx,%ebp
  402d51:	push   %rbx
  402d52:	mov    %rdi,%rbx
  402d55:	sub    $0x20,%rsp
  402d59:	mov    (%rdi),%rdi
  402d5c:	mov    0x8(%rbx),%r12
  402d60:	lea    (%rdi,%rdx,1),%rax
  402d64:	test   %rsi,%rsi
  402d67:	js     402de8 <nx_rt_rebuild2+0xb8>
  402d69:	mov    (%rax),%rax
  402d6c:	mov    %rax,0x10(%rsp)
  402d71:	mov    0x8(%rdi,%rdx,1),%rax
  402d76:	mov    %rax,0x18(%rsp)
  402d7b:	cmp    $0x310817f,%r9
  402d82:	jbe    402dc0 <nx_rt_rebuild2+0x90>
  402d84:	mov    $0x1,%eax
  402d89:	mov    0x10(%rsp,%rbp,8),%rcx
  402d8e:	mov    %r13d,%edx
  402d91:	mov    %r12,%rsi
  402d94:	sub    %ebp,%eax
  402d96:	movq   $0xffffffffffffffff,0x18(%rbx)
  402d9e:	mov    0x10(%rsp,%rax,8),%rax
  402da3:	movl   $0x1,0x20(%rbx)
  402daa:	mov    %rax,0x10(%rbx)
  402dae:	add    $0x20,%rsp
  402db2:	pop    %rbx
  402db3:	pop    %rbp
  402db4:	pop    %r12
  402db6:	pop    %r13
  402db8:	pop    %r14
  402dba:	jmpq   401fd0 <nx_construct2>
  402dbf:	nop
  402dc0:	mov    0x8(%r12),%r9
  402dc5:	test   %r9,%r9
  402dc8:	je     401651 <nx_rt_rebuild2.cold>
  402dce:	mov    (%rdi,%r9,8),%rax
  402dd2:	subq   $0x2,0x108(%r12)
  402ddb:	mov    %rax,0x8(%r12)
  402de0:	jmp    402d84 <nx_rt_rebuild2+0x54>
  402de2:	nopw   0x0(%rax,%rax,1)
  402de8:	mov    0x4(%rax),%edx
  402deb:	mov    (%rax),%ecx
  402ded:	shl    $0x20,%rdx
  402df1:	or     %rcx,%rdx
  402df4:	mov    %rdx,%r14
  402df7:	and    $0xffffff,%edx
  402dfd:	shr    $0x18,%r14
  402e01:	lea    0x0(,%r14,8),%r10
  402e09:	lea    (%rdi,%r10,1),%r11
  402e0d:	lea    0x8(%rdi,%r10,1),%r10
  402e12:	cmp    $0x1,%rdx
  402e16:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402e1c:	mov    (%rax),%edx
  402e1e:	mov    (%r11),%rdx
  402e21:	mov    %rdx,0x10(%rsp)
  402e26:	mov    (%r10),%rdx
  402e29:	mov    %rdx,0x18(%rsp)
  402e2e:	mov    (%r12),%rdx
  402e32:	mov    %rdx,(%rax)
  402e35:	mov    0x100(%r12),%rax
  402e3d:	mov    0x3e395(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e43:	mov    %r9,(%r12)
  402e47:	add    $0x1,%rax
  402e4b:	mov    %rax,0x100(%r12)
  402e53:	cmp    %rdx,%rax
  402e56:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402e5c:	mov    %r14,%r9
  402e5f:	jmpq   402d7b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
