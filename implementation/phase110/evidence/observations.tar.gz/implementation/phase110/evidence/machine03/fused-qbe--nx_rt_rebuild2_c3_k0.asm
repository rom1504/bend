
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403b80 <nx_rt_rebuild2_c3_k0>:
  403b80:	push   %r15
  403b82:	push   %r14
  403b84:	push   %r13
  403b86:	push   %r12
  403b88:	mov    %rdx,%r12
  403b8b:	push   %rbp
  403b8c:	mov    %rdi,%rbp
  403b8f:	push   %rbx
  403b90:	movabs $0xffffffffff,%rbx
  403b9a:	and    %rsi,%rbx
  403b9d:	lea    0x0(,%rbx,8),%rdx
  403ba5:	sub    $0x18,%rsp
  403ba9:	mov    (%rdi),%r13
  403bac:	mov    0x8(%rdi),%r15
  403bb0:	lea    0x0(%r13,%rdx,1),%rax
  403bb5:	test   %rsi,%rsi
  403bb8:	js     403c80 <nx_rt_rebuild2_c3_k0+0x100>
  403bbe:	mov    (%rax),%r14
  403bc1:	mov    0x8(%r13,%rdx,1),%r9
  403bc6:	cmp    $0x310817f,%rbx
  403bcd:	jbe    403c58 <nx_rt_rebuild2_c3_k0+0xd8>
  403bd3:	lea    0x0(%r13,%rbx,8),%r8
  403bd8:	mov    %r14,%rax
  403bdb:	mov    %r9,0x10(%rbp)
  403bdf:	shr    $0x38,%rax
  403be3:	movq   $0xffffffffffffffff,0x18(%rbp)
  403beb:	and    $0x7f,%eax
  403bee:	movl   $0x1,0x20(%rbp)
  403bf5:	cmp    $0x2,%rax
  403bf9:	je     403c38 <nx_rt_rebuild2_c3_k0+0xb8>
  403bfb:	mov    %r12,%rax
  403bfe:	mov    %r14,(%r8)
  403c01:	lea    0x8(%r13,%rbx,8),%rbp
  403c06:	shr    $0x38,%rax
  403c0a:	and    $0x7f,%eax
  403c0d:	cmp    $0x2,%rax
  403c11:	je     403c48 <nx_rt_rebuild2_c3_k0+0xc8>
  403c13:	movabs $0x200030000000000,%rax
  403c1d:	mov    %r12,0x0(%rbp)
  403c21:	add    $0x18,%rsp
  403c25:	or     %rbx,%rax
  403c28:	pop    %rbx
  403c29:	pop    %rbp
  403c2a:	pop    %r12
  403c2c:	pop    %r13
  403c2e:	pop    %r14
  403c30:	pop    %r15
  403c32:	retq   
  403c33:	nopl   0x0(%rax,%rax,1)
  403c38:	test   %r14,%r14
  403c3b:	js     403bfb <nx_rt_rebuild2_c3_k0+0x7b>
  403c3d:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  403c42:	nopw   0x0(%rax,%rax,1)
  403c48:	test   %r12,%r12
  403c4b:	js     403c13 <nx_rt_rebuild2_c3_k0+0x93>
  403c4d:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  403c52:	nopw   0x0(%rax,%rax,1)
  403c58:	mov    0x8(%r15),%rbx
  403c5c:	test   %rbx,%rbx
  403c5f:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  403c65:	lea    0x0(%r13,%rbx,8),%r8
  403c6a:	mov    (%r8),%rax
  403c6d:	subq   $0x2,0x108(%r15)
  403c75:	mov    %rax,0x8(%r15)
  403c79:	jmpq   403bd8 <nx_rt_rebuild2_c3_k0+0x58>
  403c7e:	xchg   %ax,%ax
  403c80:	mov    0x4(%rax),%edx
  403c83:	mov    (%rax),%ecx
  403c85:	shl    $0x20,%rdx
  403c89:	or     %rcx,%rdx
  403c8c:	mov    %rdx,%rcx
  403c8f:	and    $0xffffff,%edx
  403c95:	shr    $0x18,%rcx
  403c99:	lea    0x8(,%rcx,8),%rdi
  403ca1:	lea    0x0(%r13,%rdi,1),%r8
  403ca6:	lea    -0x8(%r13,%rdi,1),%rdi
  403cab:	cmp    $0x1,%rdx
  403caf:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  403cb5:	mov    (%rax),%edx
  403cb7:	mov    (%r15),%rdx
  403cba:	mov    (%rdi),%r14
  403cbd:	mov    (%r8),%r9
  403cc0:	mov    %rdx,(%rax)
  403cc3:	mov    0x100(%r15),%rax
  403cca:	mov    0x3d508(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403cd0:	mov    %rbx,(%r15)
  403cd3:	add    $0x1,%rax
  403cd7:	mov    %rax,0x100(%r15)
  403cde:	cmp    %rdx,%rax
  403ce1:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  403ce7:	mov    %rcx,%rbx
  403cea:	jmpq   403bc6 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
