from pathlib import Path
import shutil,json,datetime
root=Path('/home/ai/bend2/build/publish/bend'); project=root/'selfhost'; dest=project/'build/phase6/campaign/diagnostics'
dest.mkdir(parents=True,exist_ok=True)
p=dest/'lexer-project';p.mkdir()
for d in ['src','tools/conformance','tools/development','tests/frontend/phase2-rules']:shutil.copytree(project/d,p/d)
for n in ['typed-driver','stage0-library','assemble','compiler-abi','native-build','node-resource-args']:shutil.copyfile(project/f'tools/{n}.mjs',p/f'tools/{n}.mjs')
s=p/'src/front/lexer.bend';v=s.read_text();old='u => f_lex(rest, l, U32.add(c, size), d, Con{FToken{word, l, c, k}, acc}))';new='u => f_choose(List<&2,FToken>, U32.is_eq(k, 2), u => f_lex_quote_end(word, rest, l, c, d, Con{FToken{word, l, c, k}, acc}), u => f_lex(rest, l, U32.add(c, size), d, Con{FToken{word, l, c, k}, acc})))';assert v.count(old)==1;v=v.replace(old,new)
v+='''
# Quoted words may contain physical newlines. Account for the actual consumed
# codepoints before continuing lexing; escaped n remains two ordinary columns.
law f_lex_quote_end:
  for +word: String
  for +rest: String
  for +line: U32
  for +column: U32
  for +depth: U32
  for +tokens: List<&2,FToken>
  List<&2,FToken>

@unsafe
def f_lex_quote_end(word, rest, line, column, depth, tokens):
  match word:
    case SNil{}: f_lex(rest, line, column, depth, tokens)
    case SCon{head, tail}: f_choose(List<&2,FToken>, Char.is_eq(head, '\\n'), u => f_lex_quote_end(tail, rest, U32.add(line, 1), 0, depth, tokens), u => f_lex_quote_end(tail, rest, line, U32.add(column, 1), depth, tokens))
''';s.write_text(v)
fixtures=dest/'lexer-fixtures';fixtures.mkdir()
cases=[]
for name,text,ok in [
 ('original','import Base\ndef main() -> String:\n  "a\n?"\n?\n',False),
 ('valid','import Base\ndef main() -> String:\n  "a\n?"\n',True),
 ('two-newlines','import Base\ndef main() -> String:\n  "a\nb\n?"\n?\n',False),
 ('escaped-n','import Base\ndef main() -> String:\n  "a\\n?"\n?\n',False),
 ('unicode','import Base\ndef main() -> String:\n  "🙂\nλ"\n?\n',False),
 ('escaped-physical-newline','import Base\ndef main() -> String:\n  "a\\\n?"\n?\n',False),
 ('same-line-tail','import Base\ndef main() -> String:\n  "a\n?" ?\n',False),
 ('following-definition','import Base\ndef first() -> String:\n  "a\nb"\ndef main() -> U32:\n  42\n',True),
 ('character-newline',"import Base\ndef main() -> Char:\n  '\n'\n?\n",False),
 ('first-error','import Base\ndef main() -> String:\n  "a\n?"\n?\ndef bad() -> Bool:\n  0\n',False),
]:
 f=fixtures/(name+'.bend');f.write_text(text);cases.append({'id':'phase6-lexer/'+name,'file':str(f),'lanes':['parse','check'],'accept':ok,**({}if ok else {'rejectPhase':'parse'})})
(fixtures/'cases.json').write_text(json.dumps({'cases':cases},indent=2)+'\n')
config={'project':str(p),'upstream':str(project/'.bootstrap/upstream'),'selection':str(fixtures/'cases.json'),'profile':'equality','cpu':'2','jobs':1,'timeoutMs':30000,'phaseTimeoutMs':180000,'heapMb':4096}
(dest/'lexer-config.json').write_text(json.dumps(config,indent=2)+'\n')
print(dest)
