
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403cb0 <nx_rt_pair_rebuild2_c3_k0>:
  403cb0:	push   %r15
  403cb2:	push   %r14
  403cb4:	push   %r13
  403cb6:	push   %r12
  403cb8:	mov    %rdx,%r12
  403cbb:	push   %rbp
  403cbc:	push   %rbx
  403cbd:	movabs $0xffffffffff,%rbx
  403cc7:	and    %rsi,%rbx
  403cca:	lea    0x0(,%rbx,8),%rdx
  403cd2:	sub    $0x18,%rsp
  403cd6:	mov    (%rdi),%rbp
  403cd9:	mov    0x8(%rdi),%r15
  403cdd:	lea    0x0(%rbp,%rdx,1),%rax
  403ce2:	test   %rsi,%rsi
  403ce5:	js     403da0 <nx_rt_pair_rebuild2_c3_k0+0xf0>
  403ceb:	mov    (%rax),%r14
  403cee:	mov    0x8(%rbp,%rdx,1),%r13
  403cf3:	cmp    $0x310817f,%rbx
  403cfa:	jbe    403d70 <nx_rt_pair_rebuild2_c3_k0+0xc0>
  403cfc:	lea    0x0(%rbp,%rbx,8),%r8
  403d01:	mov    %r14,%rax
  403d04:	shr    $0x38,%rax
  403d08:	and    $0x7f,%eax
  403d0b:	cmp    $0x2,%rax
  403d0f:	je     403d50 <nx_rt_pair_rebuild2_c3_k0+0xa0>
  403d11:	mov    %r12,%rax
  403d14:	mov    %r14,(%r8)
  403d17:	lea    0x8(%rbp,%rbx,8),%r14
  403d1c:	shr    $0x38,%rax
  403d20:	and    $0x7f,%eax
  403d23:	cmp    $0x2,%rax
  403d27:	je     403d60 <nx_rt_pair_rebuild2_c3_k0+0xb0>
  403d29:	movabs $0x200030000000000,%rax
  403d33:	mov    %r12,(%r14)
  403d36:	mov    %r13,%rdx
  403d39:	add    $0x18,%rsp
  403d3d:	or     %rbx,%rax
  403d40:	pop    %rbx
  403d41:	pop    %rbp
  403d42:	pop    %r12
  403d44:	pop    %r13
  403d46:	pop    %r14
  403d48:	pop    %r15
  403d4a:	retq   
  403d4b:	nopl   0x0(%rax,%rax,1)
  403d50:	test   %r14,%r14
  403d53:	js     403d11 <nx_rt_pair_rebuild2_c3_k0+0x61>
  403d55:	jmpq   401a14 <nx_rt_pair_rebuild2_c3_k0.cold>
  403d5a:	nopw   0x0(%rax,%rax,1)
  403d60:	test   %r12,%r12
  403d63:	js     403d29 <nx_rt_pair_rebuild2_c3_k0+0x79>
  403d65:	jmpq   401a39 <nx_rt_pair_rebuild2_c3_k0.cold+0x25>
  403d6a:	nopw   0x0(%rax,%rax,1)
  403d70:	mov    0x8(%r15),%rbx
  403d74:	test   %rbx,%rbx
  403d77:	je     401a54 <nx_rt_pair_rebuild2_c3_k0.cold+0x40>
  403d7d:	lea    0x0(%rbp,%rbx,8),%r8
  403d82:	mov    (%r8),%rax
  403d85:	subq   $0x2,0x108(%r15)
  403d8d:	mov    %rax,0x8(%r15)
  403d91:	jmpq   403d01 <nx_rt_pair_rebuild2_c3_k0+0x51>
  403d96:	nopw   %cs:0x0(%rax,%rax,1)
  403da0:	mov    0x4(%rax),%edx
  403da3:	mov    (%rax),%ecx
  403da5:	shl    $0x20,%rdx
  403da9:	or     %rcx,%rdx
  403dac:	mov    %rdx,%rcx
  403daf:	and    $0xffffff,%edx
  403db5:	shr    $0x18,%rcx
  403db9:	lea    0x8(,%rcx,8),%rdi
  403dc1:	lea    0x0(%rbp,%rdi,1),%r8
  403dc6:	lea    -0x8(%rbp,%rdi,1),%rdi
  403dcb:	cmp    $0x1,%rdx
  403dcf:	jne    401a8d <nx_rt_pair_rebuild2_c3_k0.cold+0x79>
  403dd5:	mov    (%rax),%edx
  403dd7:	mov    (%r15),%rdx
  403dda:	mov    (%rdi),%r14
  403ddd:	mov    (%r8),%r13
  403de0:	mov    %rdx,(%rax)
  403de3:	mov    0x100(%r15),%rax
  403dea:	mov    0x3d3e8(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403df0:	mov    %rbx,(%r15)
  403df3:	add    $0x1,%rax
  403df7:	mov    %rax,0x100(%r15)
  403dfe:	cmp    %rdx,%rax
  403e01:	jae    401a71 <nx_rt_pair_rebuild2_c3_k0.cold+0x5d>
  403e07:	mov    %rcx,%rbx
  403e0a:	jmpq   403cf3 <nx_rt_pair_rebuild2_c3_k0+0x43>

Disassembly of section .fini:
