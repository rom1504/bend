
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404420 <nx_rt_pair_take2>:
  404420:	movabs $0xffffffffff,%rax
  40442a:	push   %r15
  40442c:	and    %rsi,%rax
  40442f:	push   %r14
  404431:	push   %r13
  404433:	lea    0x0(,%rax,8),%rdx
  40443b:	push   %r12
  40443d:	push   %rbp
  40443e:	mov    (%rdi),%rbp
  404441:	mov    0x8(%rdi),%r14
  404445:	lea    0x0(%rbp,%rdx,1),%rcx
  40444a:	test   %rsi,%rsi
  40444d:	js     4044b0 <nx_rt_pair_take2+0x90>
  40444f:	mov    (%rcx),%r13
  404452:	mov    0x8(%rbp,%rdx,1),%r12
  404457:	cmp    $0x310817f,%rax
  40445d:	ja     404470 <nx_rt_pair_take2+0x50>
  40445f:	pop    %rbp
  404460:	mov    %r13,%rax
  404463:	mov    %r12,%rdx
  404466:	pop    %r12
  404468:	pop    %r13
  40446a:	pop    %r14
  40446c:	pop    %r15
  40446e:	retq   
  40446f:	nop
  404470:	mov    0x8(%r14),%rdx
  404474:	mov    %rdx,0x0(%rbp,%rax,8)
  404479:	mov    0x3dd59(%rip),%edx        # 4421d8 <KEEP_WORDS>
  40447f:	mov    %rax,0x8(%r14)
  404483:	mov    0x108(%r14),%rax
  40448a:	add    $0x2,%rax
  40448e:	mov    %rax,0x108(%r14)
  404495:	cmp    %rdx,%rax
  404498:	jae    401be0 <nx_rt_pair_take2.cold>
  40449e:	pop    %rbp
  40449f:	mov    %r13,%rax
  4044a2:	mov    %r12,%rdx
  4044a5:	pop    %r12
  4044a7:	pop    %r13
  4044a9:	pop    %r14
  4044ab:	pop    %r15
  4044ad:	retq   
  4044ae:	xchg   %ax,%ax
  4044b0:	mov    0x4(%rcx),%edx
  4044b3:	mov    (%rcx),%edi
  4044b5:	shl    $0x20,%rdx
  4044b9:	or     %rdi,%rdx
  4044bc:	mov    %rdx,%r15
  4044bf:	and    $0xffffff,%edx
  4044c5:	shr    $0x18,%r15
  4044c9:	lea    0x8(,%r15,8),%rdi
  4044d1:	lea    0x0(%rbp,%rdi,1),%r8
  4044d6:	cmp    $0x1,%rdx
  4044da:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  4044e0:	mov    (%rcx),%edx
  4044e2:	mov    (%r14),%rdx
  4044e5:	mov    -0x8(%rbp,%rdi,1),%r13
  4044ea:	mov    (%r8),%r12
  4044ed:	mov    %rdx,(%rcx)
  4044f0:	mov    0x3dce2(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4044f6:	mov    %rax,(%r14)
  4044f9:	mov    0x100(%r14),%rax
  404500:	add    $0x1,%rax
  404504:	mov    %rax,0x100(%r14)
  40450b:	cmp    %rdx,%rax
  40450e:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  404514:	mov    %r15,%rax
  404517:	jmpq   404457 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
