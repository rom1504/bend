  41c10a:	lea    0x117f7(%rip),%rdx        # 42d908 <p111_program>
  41c111:	jmpq   4228c0 <p111_rt_main>
  41c116:	nopw   %cs:0x0(%rax,%rax,1)
