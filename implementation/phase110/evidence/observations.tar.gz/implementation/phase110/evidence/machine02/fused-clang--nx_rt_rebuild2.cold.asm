
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401640 <nx_rt_rebuild2.cold>:
  401640:	mov    $0x1,%ecx
  401645:	mov    %r14,%rdi
  401648:	mov    %r15,%rsi
  40164b:	mov    %r8,0x8(%rsp)
  401650:	mov    %r9,(%rsp)
  401654:	callq  401397 <rfc_wrap>
  401659:	mov    (%rsp),%r9
  40165d:	mov    0x8(%rsp),%r8
  401662:	mov    %rax,%rdx
  401665:	jmpq   402f6b <nx_rt_rebuild2+0x9b>
  40166a:	mov    %r8,%rdx
  40166d:	mov    $0x1,%ecx
  401672:	mov    %r14,%rdi
  401675:	mov    %r15,%rsi
  401678:	callq  401397 <rfc_wrap>
  40167d:	mov    %rax,%r8
  401680:	jmpq   402f83 <nx_rt_rebuild2+0xb3>
  401685:	mov    $0x1,%edx
  40168a:	mov    %r14,%rdi
  40168d:	mov    %r15,%rsi
  401690:	mov    %r8,(%rsp)
  401694:	callq  401178 <heap_alloc_miss>
  401699:	mov    (%rsp),%r8
  40169d:	mov    %rax,%rbp
  4016a0:	lea    (%r14,%rax,8),%r9
  4016a4:	jmpq   402f32 <nx_rt_rebuild2+0x62>
  4016a9:	xor    %edx,%edx
  4016ab:	mov    %r14,%rdi
  4016ae:	mov    %r15,%rsi
  4016b1:	mov    %r8,0x8(%rsp)
  4016b6:	mov    %rcx,(%rsp)
  4016ba:	callq  401100 <heap_hand>
  4016bf:	mov    (%rsp),%rcx
  4016c3:	mov    0x8(%rsp),%r8
  4016c8:	jmpq   403060 <nx_rt_rebuild2+0x190>
  4016cd:	mov    (%r9),%rax
  4016d0:	mov    %rsi,%rdx
  4016d3:	mov    %r15,%rsi
  4016d6:	mov    %r8,(%rsp)
  4016da:	mov    %rax,0x10(%rsp)
  4016df:	mov    (%rdi),%rax
  4016e2:	mov    %r14,%rdi
  4016e5:	mov    %rax,0x18(%rsp)
  4016ea:	callq  401471 <span_fade.constprop.0>
  4016ef:	mov    (%rsp),%r8
  4016f3:	jmpq   402fc8 <nx_rt_rebuild2+0xf8>

Disassembly of section .fini:
