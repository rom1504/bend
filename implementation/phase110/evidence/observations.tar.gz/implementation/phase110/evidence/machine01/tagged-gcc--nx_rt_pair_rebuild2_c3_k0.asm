
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004038d0 <nx_rt_pair_rebuild2_c3_k0>:
  4038d0:	push   %r14
  4038d2:	mov    %rsi,%r10
  4038d5:	mov    %rdx,%r8
  4038d8:	movabs $0xffffffffff,%r9
  4038e2:	push   %r13
  4038e4:	and    %r10,%r9
  4038e7:	push   %r12
  4038e9:	lea    0x0(,%r9,8),%rax
  4038f1:	push   %rbp
  4038f2:	sub    $0x18,%rsp
  4038f6:	mov    (%rdi),%rbp
  4038f9:	mov    0x8(%rdi),%rsi
  4038fd:	lea    0x0(%rbp,%rax,1),%rdx
  403902:	test   %r10,%r10
  403905:	js     403960 <nx_rt_pair_rebuild2_c3_k0+0x90>
  403907:	mov    (%rdx),%r13
  40390a:	mov    0x8(%rbp,%rax,1),%r12
  40390f:	cmp    $0x310817f,%r9
  403916:	jbe    403940 <nx_rt_pair_rebuild2_c3_k0+0x70>
  403918:	mov    %r13,%rcx
  40391b:	mov    $0x3,%edx
  403920:	mov    %rbp,%rdi
  403923:	callq  401ff0 <nx_construct2>
  403928:	add    $0x18,%rsp
  40392c:	mov    %r12,%rdx
  40392f:	pop    %rbp
  403930:	pop    %r12
  403932:	pop    %r13
  403934:	pop    %r14
  403936:	retq   
  403937:	nopw   0x0(%rax,%rax,1)
  403940:	mov    0x8(%rsi),%r9
  403944:	test   %r9,%r9
  403947:	je     401907 <nx_rt_pair_rebuild2_c3_k0.cold>
  40394d:	mov    0x0(%rbp,%r9,8),%rax
  403952:	subq   $0x2,0x108(%rsi)
  40395a:	mov    %rax,0x8(%rsi)
  40395e:	jmp    403918 <nx_rt_pair_rebuild2_c3_k0+0x48>
  403960:	mov    0x4(%rdx),%eax
  403963:	mov    (%rdx),%ecx
  403965:	shl    $0x20,%rax
  403969:	or     %rcx,%rax
  40396c:	mov    %rax,%r14
  40396f:	and    $0xffffff,%eax
  403974:	shr    $0x18,%r14
  403978:	lea    0x0(,%r14,8),%rcx
  403980:	lea    0x8(%rbp,%rcx,1),%rdi
  403985:	add    %rbp,%rcx
  403988:	cmp    $0x1,%rax
  40398c:	jne    401945 <nx_rt_pair_rebuild2_c3_k0.cold+0x3e>
  403992:	mov    (%rdx),%eax
  403994:	mov    (%rsi),%rax
  403997:	mov    (%rcx),%r13
  40399a:	mov    (%rdi),%r12
  40399d:	mov    %rax,(%rdx)
  4039a0:	mov    0x100(%rsi),%rax
  4039a7:	mov    0x3d82b(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4039ad:	mov    %r9,(%rsi)
  4039b0:	add    $0x1,%rax
  4039b4:	mov    %rax,0x100(%rsi)
  4039bb:	cmp    %rdx,%rax
  4039be:	jae    40192e <nx_rt_pair_rebuild2_c3_k0.cold+0x27>
  4039c4:	mov    %r14,%r9
  4039c7:	jmpq   40390f <nx_rt_pair_rebuild2_c3_k0+0x3f>

Disassembly of section .fini:
