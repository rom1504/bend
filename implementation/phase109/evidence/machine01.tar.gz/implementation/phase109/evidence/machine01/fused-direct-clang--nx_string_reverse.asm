
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004018e0 <nx_string_reverse>:
  4018e0:	push   %r15
  4018e2:	push   %r14
  4018e4:	push   %rbx
  4018e5:	mov    %rdx,%r14
  4018e8:	mov    %rsi,%r15
  4018eb:	mov    %rdi,%rbx
  4018ee:	xchg   %ax,%ax
  4018f0:	mov    %rbx,%rdi
  4018f3:	mov    %r15,%rsi
  4018f6:	callq  4026b0 <nx_rt_fast_id>
  4018fb:	cmp    $0x3,%eax
  4018fe:	jne    401927 <nx_string_reverse+0x47>
  401900:	mov    %rbx,%rdi
  401903:	mov    %r15,%rsi
  401906:	mov    $0x3,%edx
  40190b:	xor    %ecx,%ecx
  40190d:	mov    %r14,%r8
  401910:	callq  402980 <nx_rt_rebuild2>
  401915:	mov    %rax,%r14
  401918:	mov    %rbx,%rdi
  40191b:	xor    %esi,%esi
  40191d:	callq  402960 <nx_rt_fast_field>
  401922:	mov    %rax,%r15
  401925:	jmp    4018f0 <nx_string_reverse+0x10>
  401927:	cmp    $0x2,%eax
  40192a:	jne    401935 <nx_string_reverse+0x55>
  40192c:	mov    %r14,%rax
  40192f:	pop    %rbx
  401930:	pop    %r14
  401932:	pop    %r15
  401934:	retq   
  401935:	mov    %rbx,%rdi
  401938:	mov    $0x1,%esi
  40193d:	pop    %rbx
  40193e:	pop    %r14
  401940:	pop    %r15
  401942:	jmpq   4021b0 <nx_rt_fail>

Disassembly of section .fini:
