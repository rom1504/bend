
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403a20 <nx_rt_rebuild2_c1_k0>:
  403a20:	push   %r15
  403a22:	push   %r14
  403a24:	push   %r13
  403a26:	push   %r12
  403a28:	mov    %rdx,%r12
  403a2b:	push   %rbp
  403a2c:	mov    %rdi,%rbp
  403a2f:	push   %rbx
  403a30:	movabs $0xffffffffff,%rbx
  403a3a:	and    %rsi,%rbx
  403a3d:	lea    0x0(,%rbx,8),%rdx
  403a45:	sub    $0x18,%rsp
  403a49:	mov    (%rdi),%r13
  403a4c:	mov    0x8(%rdi),%r15
  403a50:	lea    0x0(%r13,%rdx,1),%rax
  403a55:	test   %rsi,%rsi
  403a58:	js     403b20 <nx_rt_rebuild2_c1_k0+0x100>
  403a5e:	mov    (%rax),%r14
  403a61:	mov    0x8(%r13,%rdx,1),%r9
  403a66:	cmp    $0x310817f,%rbx
  403a6d:	jbe    403af8 <nx_rt_rebuild2_c1_k0+0xd8>
  403a73:	lea    0x0(%r13,%rbx,8),%r8
  403a78:	mov    %r14,%rax
  403a7b:	mov    %r9,0x10(%rbp)
  403a7f:	shr    $0x38,%rax
  403a83:	movq   $0xffffffffffffffff,0x18(%rbp)
  403a8b:	and    $0x7f,%eax
  403a8e:	movl   $0x1,0x20(%rbp)
  403a95:	cmp    $0x2,%rax
  403a99:	je     403ad8 <nx_rt_rebuild2_c1_k0+0xb8>
  403a9b:	mov    %r12,%rax
  403a9e:	mov    %r14,(%r8)
  403aa1:	lea    0x8(%r13,%rbx,8),%rbp
  403aa6:	shr    $0x38,%rax
  403aaa:	and    $0x7f,%eax
  403aad:	cmp    $0x2,%rax
  403ab1:	je     403ae8 <nx_rt_rebuild2_c1_k0+0xc8>
  403ab3:	movabs $0x200010000000000,%rax
  403abd:	mov    %r12,0x0(%rbp)
  403ac1:	add    $0x18,%rsp
  403ac5:	or     %rbx,%rax
  403ac8:	pop    %rbx
  403ac9:	pop    %rbp
  403aca:	pop    %r12
  403acc:	pop    %r13
  403ace:	pop    %r14
  403ad0:	pop    %r15
  403ad2:	retq   
  403ad3:	nopl   0x0(%rax,%rax,1)
  403ad8:	test   %r14,%r14
  403adb:	js     403a9b <nx_rt_rebuild2_c1_k0+0x7b>
  403add:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403ae2:	nopw   0x0(%rax,%rax,1)
  403ae8:	test   %r12,%r12
  403aeb:	js     403ab3 <nx_rt_rebuild2_c1_k0+0x93>
  403aed:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403af2:	nopw   0x0(%rax,%rax,1)
  403af8:	mov    0x8(%r15),%rbx
  403afc:	test   %rbx,%rbx
  403aff:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  403b05:	lea    0x0(%r13,%rbx,8),%r8
  403b0a:	mov    (%r8),%rax
  403b0d:	subq   $0x2,0x108(%r15)
  403b15:	mov    %rax,0x8(%r15)
  403b19:	jmpq   403a78 <nx_rt_rebuild2_c1_k0+0x58>
  403b1e:	xchg   %ax,%ax
  403b20:	mov    0x4(%rax),%edx
  403b23:	mov    (%rax),%ecx
  403b25:	shl    $0x20,%rdx
  403b29:	or     %rcx,%rdx
  403b2c:	mov    %rdx,%rcx
  403b2f:	and    $0xffffff,%edx
  403b35:	shr    $0x18,%rcx
  403b39:	lea    0x8(,%rcx,8),%rdi
  403b41:	lea    0x0(%r13,%rdi,1),%r8
  403b46:	lea    -0x8(%r13,%rdi,1),%rdi
  403b4b:	cmp    $0x1,%rdx
  403b4f:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  403b55:	mov    (%rax),%edx
  403b57:	mov    (%r15),%rdx
  403b5a:	mov    (%rdi),%r14
  403b5d:	mov    (%r8),%r9
  403b60:	mov    %rdx,(%rax)
  403b63:	mov    0x100(%r15),%rax
  403b6a:	mov    0x3e668(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403b70:	mov    %rbx,(%r15)
  403b73:	add    $0x1,%rax
  403b77:	mov    %rax,0x100(%r15)
  403b7e:	cmp    %rdx,%rax
  403b81:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  403b87:	mov    %rcx,%rbx
  403b8a:	jmpq   403a66 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
