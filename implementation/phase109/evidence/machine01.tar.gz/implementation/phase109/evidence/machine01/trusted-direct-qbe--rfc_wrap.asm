
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401397 <rfc_wrap>:
  401397:	mov    %rdx,%rax
  40139a:	push   %r12
  40139c:	shr    $0x38,%rax
  4013a0:	push   %rbp
  4013a1:	and    $0x7f,%eax
  4013a4:	push   %rbx
  4013a5:	sub    $0x3,%rax
  4013a9:	test   $0xfffffffffffffffd,%rax
  4013af:	jne    4013bd <rfc_wrap+0x26>
  4013b1:	lea    0x2c56(%rip),%rdi        # 40400e <_IO_stdin_used+0xe>
  4013b8:	callq  4019d0 <err_fail>
  4013bd:	mov    %rdx,%rbx
  4013c0:	mov    (%rsi),%rdx
  4013c3:	mov    %rdi,%rbp
  4013c6:	mov    %ecx,%r12d
  4013c9:	test   %rdx,%rdx
  4013cc:	je     4013de <rfc_wrap+0x47>
  4013ce:	mov    (%rdi,%rdx,8),%rax
  4013d2:	decq   0x100(%rsi)
  4013d9:	mov    %rax,(%rsi)
  4013dc:	jmp    4013e8 <rfc_wrap+0x51>
  4013de:	xor    %edx,%edx
  4013e0:	callq  401178 <heap_alloc_miss>
  4013e5:	mov    %rax,%rdx
  4013e8:	mov    %rbx,%rax
  4013eb:	shl    $0x18,%rax
  4013ef:	or     %rax,%r12
  4013f2:	mov    $0x7fffff,%eax
  4013f7:	shl    $0x28,%rax
  4013fb:	mov    %r12,0x0(%rbp,%rdx,8)
  401400:	and    %rbx,%rax
  401403:	pop    %rbx
  401404:	pop    %rbp
  401405:	or     %rdx,%rax
  401408:	pop    %r12
  40140a:	bts    $0x3f,%rax
  40140f:	retq   

Disassembly of section .fini:
