
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402ed0 <nx_rt_rebuild2>:
  402ed0:	push   %r15
  402ed2:	push   %r14
  402ed4:	push   %r13
  402ed6:	mov    %ecx,%r13d
  402ed9:	push   %r12
  402edb:	mov    %rdi,%r12
  402ede:	push   %rbp
  402edf:	movabs $0xffffffffff,%rbp
  402ee9:	push   %rbx
  402eea:	and    %rsi,%rbp
  402eed:	mov    %edx,%ebx
  402eef:	lea    0x0(,%rbp,8),%rdx
  402ef7:	sub    $0x28,%rsp
  402efb:	mov    (%rdi),%r14
  402efe:	mov    0x8(%rdi),%r15
  402f02:	lea    (%r14,%rdx,1),%rax
  402f06:	test   %rsi,%rsi
  402f09:	js     402ff0 <nx_rt_rebuild2+0x120>
  402f0f:	mov    (%rax),%rax
  402f12:	mov    %rax,0x10(%rsp)
  402f17:	mov    0x8(%r14,%rdx,1),%rax
  402f1c:	mov    %rax,0x18(%rsp)
  402f21:	cmp    $0x310817f,%rbp
  402f28:	jbe    402fc8 <nx_rt_rebuild2+0xf8>
  402f2e:	lea    (%r14,%rbp,8),%r9
  402f32:	mov    $0x1,%eax
  402f37:	mov    0x10(%rsp,%r13,8),%rdx
  402f3c:	movq   $0xffffffffffffffff,0x18(%r12)
  402f45:	movl   $0x1,0x20(%r12)
  402f4e:	sub    %r13d,%eax
  402f51:	mov    0x10(%rsp,%rax,8),%rax
  402f56:	mov    %rax,0x10(%r12)
  402f5b:	mov    %rdx,%rax
  402f5e:	shr    $0x38,%rax
  402f62:	and    $0x7f,%eax
  402f65:	cmp    $0x2,%rax
  402f69:	je     402fa8 <nx_rt_rebuild2+0xd8>
  402f6b:	mov    %r8,%rax
  402f6e:	mov    %rdx,(%r9)
  402f71:	lea    0x8(%r14,%rbp,8),%r12
  402f76:	shr    $0x38,%rax
  402f7a:	and    $0x7f,%eax
  402f7d:	cmp    $0x2,%rax
  402f81:	je     402fb8 <nx_rt_rebuild2+0xe8>
  402f83:	mov    %rbx,%rax
  402f86:	mov    %r8,(%r12)
  402f8a:	add    $0x28,%rsp
  402f8e:	shl    $0x28,%rax
  402f92:	pop    %rbx
  402f93:	or     %rbp,%rax
  402f96:	pop    %rbp
  402f97:	pop    %r12
  402f99:	bts    $0x39,%rax
  402f9e:	pop    %r13
  402fa0:	pop    %r14
  402fa2:	pop    %r15
  402fa4:	retq   
  402fa5:	nopl   (%rax)
  402fa8:	test   %rdx,%rdx
  402fab:	js     402f6b <nx_rt_rebuild2+0x9b>
  402fad:	jmpq   401640 <nx_rt_rebuild2.cold>
  402fb2:	nopw   0x0(%rax,%rax,1)
  402fb8:	test   %r8,%r8
  402fbb:	js     402f83 <nx_rt_rebuild2+0xb3>
  402fbd:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  402fc2:	nopw   0x0(%rax,%rax,1)
  402fc8:	mov    0x8(%r15),%rbp
  402fcc:	test   %rbp,%rbp
  402fcf:	je     401685 <nx_rt_rebuild2.cold+0x45>
  402fd5:	lea    (%r14,%rbp,8),%r9
  402fd9:	mov    (%r9),%rax
  402fdc:	subq   $0x2,0x108(%r15)
  402fe4:	mov    %rax,0x8(%r15)
  402fe8:	jmpq   402f32 <nx_rt_rebuild2+0x62>
  402fed:	nopl   (%rax)
  402ff0:	mov    0x4(%rax),%edx
  402ff3:	mov    (%rax),%ecx
  402ff5:	shl    $0x20,%rdx
  402ff9:	or     %rcx,%rdx
  402ffc:	mov    %rdx,%rcx
  402fff:	and    $0xffffff,%edx
  403005:	shr    $0x18,%rcx
  403009:	lea    0x0(,%rcx,8),%rdi
  403011:	lea    (%r14,%rdi,1),%r9
  403015:	lea    0x8(%r14,%rdi,1),%rdi
  40301a:	cmp    $0x1,%rdx
  40301e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403024:	mov    (%rax),%edx
  403026:	mov    (%r9),%rdx
  403029:	mov    %rdx,0x10(%rsp)
  40302e:	mov    (%rdi),%rdx
  403031:	mov    %rdx,0x18(%rsp)
  403036:	mov    (%r15),%rdx
  403039:	mov    %rdx,(%rax)
  40303c:	mov    0x100(%r15),%rax
  403043:	mov    0x3e18f(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403049:	mov    %rbp,(%r15)
  40304c:	add    $0x1,%rax
  403050:	mov    %rax,0x100(%r15)
  403057:	cmp    %rdx,%rax
  40305a:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  403060:	mov    %rcx,%rbp
  403063:	jmpq   402f21 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
