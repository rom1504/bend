
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402c60 <nx_rt_fast_id>:
  402c60:	shr    $0x28,%rsi
  402c64:	movzwl %si,%eax
  402c67:	retq   

Disassembly of section .fini:
