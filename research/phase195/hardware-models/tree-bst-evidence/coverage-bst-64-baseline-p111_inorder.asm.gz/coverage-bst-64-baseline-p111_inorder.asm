000000000040e6a1 <p111_FID_105_110_111_114_100_101_114_>:
  40e6a1:	push   rbp
  40e6a2:	mov    rbp,rsp
  40e6a5:	sub    rsp,0x930
  40e6ac:	mov    QWORD PTR [rbp-0x10],r12
  40e6b0:	mov    rax,rdi
  40e6b3:	mov    r12,rax
  40e6b6:	mov    rdi,r12
  40e6b9:	movabs rsi,0x45
  40e6c3:	mov    esi,esi
  40e6c5:	lea    rdx,[rbp-0x830]
  40e6cc:	movabs rcx,0x0
  40e6d6:	mov    ecx,ecx
  40e6d8:	xor    eax,eax
  40e6da:	call   418230 <p111_rt_closure>
  40e6df:	mov    rdi,rax
  40e6e2:	lea    r10,[rbp-0x830]
  40e6e9:	mov    r11,rdi
  40e6ec:	mov    QWORD PTR [r10],r11
  40e6ef:	lea    r10,[rip+0x1734a]        # 425a40 <p111_program>
  40e6f6:	movabs rdi,0x4
  40e700:	and    rdi,QWORD PTR [r10+0x58]
  40e704:	mov    r10,rdi
  40e707:	test   r10d,r10d
  40e70a:	je     40e75e <p111_FID_105_110_111_114_100_101_114_+0xbd>
  40e710:	lea    r10,[rbp-0x830]
  40e717:	mov    rdi,QWORD PTR [r10]
  40e71a:	mov    QWORD PTR [r12+0x28],rdi
  40e71f:	mov    r10,r12
  40e722:	movabs r11,0x1
  40e72c:	mov    DWORD PTR [r10+0x1c],r11d
  40e730:	mov    rdi,QWORD PTR [r12+0x10]
  40e735:	movabs r11,0xfffffffffffffff8
  40e73f:	add    rdi,r11
  40e742:	mov    QWORD PTR [r12+0x10],rdi
  40e747:	mov    rdi,QWORD PTR [rdi]
  40e74a:	mov    DWORD PTR [r12+0x20],edi
  40e74f:	movabs rdi,0x0
  40e759:	jmp    40e77e <p111_FID_105_110_111_114_100_101_114_+0xdd>
  40e75e:	mov    rdi,r12
  40e761:	lea    rsi,[rbp-0x830]
  40e768:	movabs rdx,0x1
  40e772:	mov    edx,edx
  40e774:	xor    eax,eax
  40e776:	call   418440 <p111_rt_return>
  40e77b:	mov    rdi,rax
  40e77e:	mov    rax,rdi
  40e781:	mov    r12,QWORD PTR [rbp-0x10]
  40e785:	mov    rsp,rbp
  40e788:	pop    rbp
  40e789:	ret    

