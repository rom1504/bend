
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c60 <nx_construct2>:
  401c60:	push   %r12
  401c62:	mov    %rcx,%rax
  401c65:	push   %rbp
  401c66:	shr    $0x38,%rax
  401c6a:	lea    0x0(,%r9,8),%rbp
  401c72:	push   %rbx
  401c73:	and    $0x7f,%eax
  401c76:	mov    %edx,%ebx
  401c78:	lea    (%rdi,%rbp,1),%r12
  401c7c:	mov    %rcx,%rdx
  401c7f:	sub    $0x20,%rsp
  401c83:	cmp    $0x2,%rax
  401c87:	je     401cc0 <nx_construct2+0x60>
  401c89:	mov    %r8,%rax
  401c8c:	mov    %rdx,(%r12)
  401c90:	lea    0x8(%rbp,%rdi,1),%rbp
  401c95:	shr    $0x38,%rax
  401c99:	and    $0x7f,%eax
  401c9c:	cmp    $0x2,%rax
  401ca0:	je     401cd0 <nx_construct2+0x70>
  401ca2:	mov    %rbx,%rax
  401ca5:	mov    %r8,0x0(%rbp)
  401ca9:	add    $0x20,%rsp
  401cad:	shl    $0x28,%rax
  401cb1:	pop    %rbx
  401cb2:	pop    %rbp
  401cb3:	or     %r9,%rax
  401cb6:	pop    %r12
  401cb8:	bts    $0x39,%rax
  401cbd:	retq   
  401cbe:	xchg   %ax,%ax
  401cc0:	test   %rcx,%rcx
  401cc3:	js     401c89 <nx_construct2+0x29>
  401cc5:	jmpq   401410 <nx_construct2.cold>
  401cca:	nopw   0x0(%rax,%rax,1)
  401cd0:	test   %r8,%r8
  401cd3:	js     401ca2 <nx_construct2+0x42>
  401cd5:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
