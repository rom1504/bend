  408fbc:	push   %rbp
  408fbd:	mov    %rsp,%rbp
  408fc0:	sub    $0x930,%rsp
  408fc7:	mov    %r12,-0x10(%rbp)
  408fcb:	mov    %rbx,-0x8(%rbp)
  408fcf:	mov    %r13,-0x18(%rbp)
  408fd3:	mov    %r14,-0x20(%rbp)
  408fd7:	mov    %rdi,%rax
  408fda:	mov    %rax,%r12
  408fdd:	mov    %rsi,%rax
  408fe0:	mov    %rax,%rdi
  408fe3:	mov    %rdx,%rax
  408fe6:	mov    %rax,%rdx
  408fe9:	mov    %rcx,%rax
  408fec:	mov    %rax,%rbx
  408fef:	cmp    $0x0,%rdi
  408ff6:	jne    409014 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x58>
  408ffc:	mov    %rbx,%rax
  408fff:	mov    -0x10(%rbp),%r12
  409003:	mov    -0x8(%rbp),%rbx
  409007:	mov    -0x18(%rbp),%r13
  40900b:	mov    -0x20(%rbp),%r14
  40900f:	mov    %rbp,%rsp
  409012:	pop    %rbp
  409013:	retq   
  409014:	mov    %rdi,%r13
  409017:	sub    $0x1,%r13
  40901e:	mov    %edx,%edi
  409020:	mov    %rdi,%r14
  409023:	add    $0x1,%r14d
  40902a:	mov    %r12,%r10
  40902d:	mov    %r10,0x18(%rsp)
  409032:	mov    %rbx,%r10
  409035:	mov    %r10,0x20(%rsp)
  40903a:	mov    %rdx,%r10
  40903d:	mov    %r10,0x28(%rsp)
  409042:	mov    0x18(%rsp),%rdi
  409047:	mov    0x20(%rsp),%rsi
  40904c:	mov    0x28(%rsp),%rdx
  409051:	xor    %eax,%eax
  409053:	callq  408f51 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_115_116_101_112_>
  409058:	mov    %rax,%rbx
  40905b:	mov    %r13,%rdi
  40905e:	mov    %r14,%rdx
  409061:	jmpq   408fef <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x33>
