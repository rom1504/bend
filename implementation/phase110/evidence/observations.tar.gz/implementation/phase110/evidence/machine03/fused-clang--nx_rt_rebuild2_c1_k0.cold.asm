
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004016f8 <nx_rt_rebuild2_c1_k0.cold>:
  4016f8:	mov    %r14,%rdx
  4016fb:	mov    $0x1,%ecx
  401700:	mov    %r13,%rdi
  401703:	mov    %r15,%rsi
  401706:	mov    %r8,(%rsp)
  40170a:	callq  401397 <rfc_wrap>
  40170f:	mov    (%rsp),%r8
  401713:	mov    %rax,%r14
  401716:	jmpq   40361b <nx_rt_rebuild2_c1_k0+0x7b>
  40171b:	mov    %r12,%rdx
  40171e:	mov    $0x1,%ecx
  401723:	mov    %r13,%rdi
  401726:	mov    %r15,%rsi
  401729:	callq  401397 <rfc_wrap>
  40172e:	mov    %rax,%r12
  401731:	jmpq   403633 <nx_rt_rebuild2_c1_k0+0x93>
  401736:	mov    $0x1,%edx
  40173b:	mov    %r13,%rdi
  40173e:	mov    %r15,%rsi
  401741:	mov    %r9,(%rsp)
  401745:	callq  401178 <heap_alloc_miss>
  40174a:	mov    (%rsp),%r9
  40174e:	mov    %rax,%rbx
  401751:	lea    0x0(%r13,%rax,8),%r8
  401756:	jmpq   4035f8 <nx_rt_rebuild2_c1_k0+0x58>
  40175b:	xor    %edx,%edx
  40175d:	mov    %r13,%rdi
  401760:	mov    %r15,%rsi
  401763:	mov    %rcx,0x8(%rsp)
  401768:	mov    %r9,(%rsp)
  40176c:	callq  401100 <heap_hand>
  401771:	mov    (%rsp),%r9
  401775:	mov    0x8(%rsp),%rcx
  40177a:	jmpq   403707 <nx_rt_rebuild2_c1_k0+0x167>
  40177f:	mov    (%r8),%r9
  401782:	mov    (%rdi),%r14
  401785:	mov    %rsi,%rdx
  401788:	mov    %r13,%rdi
  40178b:	mov    %r15,%rsi
  40178e:	mov    %r9,(%rsp)
  401792:	callq  401471 <span_fade.constprop.0>
  401797:	mov    (%rsp),%r9
  40179b:	jmpq   403678 <nx_rt_rebuild2_c1_k0+0xd8>

Disassembly of section .fini:
