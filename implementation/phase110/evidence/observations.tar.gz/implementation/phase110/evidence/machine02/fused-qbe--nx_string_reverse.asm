
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401e80 <nx_string_reverse>:
  401e80:	endbr64 
  401e84:	push   %rbp
  401e85:	mov    %rsp,%rbp
  401e88:	sub    $0x8,%rsp
  401e8c:	push   %rbx
  401e8d:	push   %r12
  401e8f:	push   %r13
  401e91:	mov    %rdx,%rax
  401e94:	mov    %rax,%r13
  401e97:	nopw   0x0(%rax,%rax,1)
  401ea0:	mov    %rsi,%r12
  401ea3:	mov    %rdi,%rbx
  401ea6:	callq  402c40 <nx_rt_fast_id>
  401eab:	mov    %r13,%rdx
  401eae:	mov    %r12,%rsi
  401eb1:	mov    %rbx,%rdi
  401eb4:	cmp    $0x2,%eax
  401eb7:	je     401f00 <nx_string_reverse+0x80>
  401eb9:	cmp    $0x3,%eax
  401ebc:	jne    401ef4 <nx_string_reverse+0x74>
  401ebe:	mov    %rdx,%r8
  401ec1:	mov    $0x0,%ecx
  401ec6:	mov    $0x3,%edx
  401ecb:	mov    %rdi,%rbx
  401ece:	callq  402f10 <nx_rt_rebuild2>
  401ed3:	mov    %rbx,%rdi
  401ed6:	mov    %rax,%r12
  401ed9:	mov    $0x0,%esi
  401ede:	mov    %rdi,%rbx
  401ee1:	callq  402ef0 <nx_rt_fast_field>
  401ee6:	mov    %r12,%rdx
  401ee9:	mov    %rbx,%rdi
  401eec:	mov    %rax,%rsi
  401eef:	mov    %rdx,%r13
  401ef2:	jmp    401ea0 <nx_string_reverse+0x20>
  401ef4:	mov    $0x1,%esi
  401ef9:	callq  4026f0 <nx_rt_fail>
  401efe:	jmp    401f03 <nx_string_reverse+0x83>
  401f00:	mov    %rdx,%rax
  401f03:	pop    %r13
  401f05:	pop    %r12
  401f07:	pop    %rbx
  401f08:	leaveq 
  401f09:	retq   

Disassembly of section .fini:
