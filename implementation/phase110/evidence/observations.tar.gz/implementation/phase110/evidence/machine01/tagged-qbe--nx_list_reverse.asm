
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	endbr64 
  401c04:	push   %rbp
  401c05:	mov    %rsp,%rbp
  401c08:	push   %rbx
  401c09:	push   %r12
  401c0b:	mov    %rdx,%rax
  401c0e:	mov    %rax,%rdx
  401c11:	data16 nopw %cs:0x0(%rax,%rax,1)
  401c1c:	nopl   0x0(%rax)
  401c20:	mov    %rsi,%rax
  401c23:	shr    $0x28,%rax
  401c27:	and    $0xffff,%rax
  401c2d:	cmp    $0x0,%rax
  401c31:	je     401c78 <nx_list_reverse+0x78>
  401c33:	cmp    $0x1,%rax
  401c37:	jne    401c6c <nx_list_reverse+0x6c>
  401c39:	mov    %rdx,%r8
  401c3c:	mov    $0x0,%ecx
  401c41:	mov    $0x1,%edx
  401c46:	mov    %rdi,%rbx
  401c49:	callq  402d30 <nx_rt_rebuild2>
  401c4e:	mov    %rbx,%rdi
  401c51:	mov    %rax,%r12
  401c54:	mov    $0x0,%esi
  401c59:	mov    %rdi,%rbx
  401c5c:	callq  402d10 <nx_rt_fast_field>
  401c61:	mov    %r12,%rdx
  401c64:	mov    %rbx,%rdi
  401c67:	mov    %rax,%rsi
  401c6a:	jmp    401c20 <nx_list_reverse+0x20>
  401c6c:	mov    $0x1,%esi
  401c71:	callq  402560 <nx_rt_fail>
  401c76:	jmp    401c7b <nx_list_reverse+0x7b>
  401c78:	mov    %rdx,%rax
  401c7b:	pop    %r12
  401c7d:	pop    %rbx
  401c7e:	leaveq 
  401c7f:	retq   

Disassembly of section .fini:
