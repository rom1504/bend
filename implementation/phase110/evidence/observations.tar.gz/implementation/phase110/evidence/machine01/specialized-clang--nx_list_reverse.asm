
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	push   %r14
  401c02:	push   %rbx
  401c03:	push   %rax
  401c04:	mov    %rdx,%r14
  401c07:	mov    %rdi,%rbx
  401c0a:	nopw   0x0(%rax,%rax,1)
  401c10:	mov    %rsi,%rax
  401c13:	shr    $0x28,%rax
  401c17:	cmp    $0x1,%ax
  401c1b:	jne    401c3a <nx_list_reverse+0x3a>
  401c1d:	mov    %rbx,%rdi
  401c20:	mov    %r14,%rdx
  401c23:	callq  403350 <nx_rt_rebuild2_c1_k0>
  401c28:	mov    %rax,%r14
  401c2b:	mov    %rbx,%rdi
  401c2e:	xor    %esi,%esi
  401c30:	callq  402ce0 <nx_rt_fast_field>
  401c35:	mov    %rax,%rsi
  401c38:	jmp    401c10 <nx_list_reverse+0x10>
  401c3a:	movzwl %ax,%eax
  401c3d:	test   %eax,%eax
  401c3f:	jne    401c4c <nx_list_reverse+0x4c>
  401c41:	mov    %r14,%rax
  401c44:	add    $0x8,%rsp
  401c48:	pop    %rbx
  401c49:	pop    %r14
  401c4b:	retq   
  401c4c:	mov    %rbx,%rdi
  401c4f:	mov    $0x1,%esi
  401c54:	add    $0x8,%rsp
  401c58:	pop    %rbx
  401c59:	pop    %r14
  401c5b:	jmpq   402530 <nx_rt_fail>

Disassembly of section .fini:
