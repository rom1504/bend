000000000000b990 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_>:
    b990:	push   rbp
    b991:	sub    rsp,0x10
    b995:	movabs rbp,0xffffffff80
    b99f:	movabs rax,0xffff0000000000
    b9a9:	and    rax,rdx
    b9ac:	movabs rcx,0x80000000000
    b9b6:	cmp    rax,rcx
    b9b9:	jne    be36 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x4a6>
    b9bf:	lea    r10,[rbp+0x7f]
    b9c3:	mov    rdi,rdx
    b9c6:	and    rdi,r10
    b9c9:	test   rdx,rdx
    b9cc:	js     b9e8 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x58>
    b9ce:	mov    rax,QWORD PTR [r12+rdi*8]
    b9d2:	mov    rbx,QWORD PTR [r12+rdi*8+0x8]
    b9d7:	mov    rcx,rdi
    b9da:	cmp    rcx,0x3108180
    b9e1:	jae    ba5a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0xca>
    b9e3:	jmp    ba92 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x102>
    b9e8:	mov    ecx,DWORD PTR [r12+rdi*8+0x4]
    b9ed:	mov    eax,DWORD PTR [r12+rdi*8]
    b9f1:	mov    ebx,eax
    b9f3:	and    ebx,0xffffff
    b9f9:	cmp    ebx,0x1
    b9fc:	jne    bd0e <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x37e>
    ba02:	mov    edx,DWORD PTR [r12+rdi*8]
    ba06:	shl    rcx,0x20
    ba0a:	or     rcx,rax
    ba0d:	shr    rcx,0x18
    ba11:	mov    rax,QWORD PTR [r12+rcx*8]
    ba15:	mov    rbx,QWORD PTR [r12+rcx*8+0x8]
    ba1a:	mov    rdx,QWORD PTR [r13+0x0]
    ba1e:	mov    QWORD PTR [r12+rdi*8],rdx
    ba22:	mov    QWORD PTR [r13+0x0],rdi
    ba26:	mov    rdx,QWORD PTR [r13+0x100]
    ba2d:	inc    rdx
    ba30:	mov    QWORD PTR [r13+0x100],rdx
    ba37:	cmp    BYTE PTR [rip+0x10c352],0x1        # 117d90 <KEEP_WORDS>
    ba3e:	jne    bd3e <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x3ae>
    ba44:	cmp    rdx,0x8000
    ba4b:	jae    bd3e <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x3ae>
    ba51:	cmp    rcx,0x3108180
    ba58:	jb     ba92 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x102>
    ba5a:	mov    rdx,QWORD PTR [r13+0x8]
    ba5e:	mov    QWORD PTR [r12+rcx*8],rdx
    ba62:	mov    QWORD PTR [r13+0x8],rcx
    ba66:	mov    rcx,QWORD PTR [r13+0x108]
    ba6d:	add    rcx,0x2
    ba71:	mov    QWORD PTR [r13+0x108],rcx
    ba78:	cmp    BYTE PTR [rip+0x10c311],0x1        # 117d90 <KEEP_WORDS>
    ba7f:	jne    bcf3 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x363>
    ba85:	cmp    rcx,0x8000
    ba8c:	jae    bcf3 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x363>
    ba92:	mov    rcx,rax
    ba95:	shr    rcx,0x28
    ba99:	movzx  ecx,cx
    ba9c:	cmp    ecx,0xa5
    baa2:	je     badc <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x14c>
    baa4:	cmp    ecx,0xa4
    baaa:	jne    be68 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x4d8>
    bab0:	mov    rax,QWORD PTR [r13+0x8]
    bab4:	test   rax,rax
    bab7:	je     bcde <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x34e>
    babd:	mov    rcx,QWORD PTR [r12+rax*8]
    bac1:	mov    QWORD PTR [r13+0x8],rcx
    bac5:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    bacd:	movabs r9,0x100a40000000000
    bad7:	jmp    bc97 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x307>
    badc:	and    r10,rax
    badf:	test   rax,rax
    bae2:	js     bb07 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x177>
    bae4:	mov    r9,QWORD PTR [r12+r10*8]
    bae8:	mov    ebp,DWORD PTR [r12+r10*8+0x8]
    baed:	mov    r8,QWORD PTR [r12+r10*8+0x10]
    baf2:	mov    rcx,r10
    baf5:	cmp    rcx,0x3108180
    bafc:	jae    bb87 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x1f7>
    bb02:	jmp    bbbe <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x22e>
    bb07:	mov    QWORD PTR [rsp+0x8],rsi
    bb0c:	mov    ecx,DWORD PTR [r12+r10*8+0x4]
    bb11:	mov    edx,DWORD PTR [r12+r10*8]
    bb15:	mov    esi,edx
    bb17:	and    esi,0xffffff
    bb1d:	cmp    esi,0x1
    bb20:	jne    bdd8 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x448>
    bb26:	mov    eax,DWORD PTR [r12+r10*8]
    bb2a:	shl    rcx,0x20
    bb2e:	or     rcx,rdx
    bb31:	shr    rcx,0x18
    bb35:	mov    r9,QWORD PTR [r12+rcx*8]
    bb39:	mov    ebp,DWORD PTR [r12+rcx*8+0x8]
    bb3e:	mov    r8,QWORD PTR [r12+rcx*8+0x10]
    bb43:	mov    rax,QWORD PTR [r13+0x0]
    bb47:	mov    QWORD PTR [r12+r10*8],rax
    bb4b:	mov    QWORD PTR [r13+0x0],r10
    bb4f:	mov    rax,QWORD PTR [r13+0x100]
    bb56:	inc    rax
    bb59:	mov    QWORD PTR [r13+0x100],rax
    bb60:	cmp    BYTE PTR [rip+0x10c229],0x1        # 117d90 <KEEP_WORDS>
    bb67:	jne    be12 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x482>
    bb6d:	cmp    rax,0x8000
    bb73:	jae    be12 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x482>
    bb79:	mov    rsi,QWORD PTR [rsp+0x8]
    bb7e:	cmp    rcx,0x3108180
    bb85:	jb     bbbe <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x22e>
    bb87:	mov    rax,QWORD PTR [r13+0x10]
    bb8b:	mov    QWORD PTR [r12+rcx*8],rax
    bb8f:	mov    QWORD PTR [r13+0x10],rcx
    bb93:	mov    rax,QWORD PTR [r13+0x110]
    bb9a:	add    rax,0x4
    bb9e:	mov    QWORD PTR [r13+0x110],rax
    bba5:	cmp    BYTE PTR [rip+0x10c1e4],0x1        # 117d90 <KEEP_WORDS>
    bbac:	jne    bdbd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x42d>
    bbb2:	cmp    rax,0x8000
    bbb8:	jae    bdbd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x42d>
    bbbe:	mov    rcx,QWORD PTR [r13+0x10]
    bbc2:	cmp    esi,ebp
    bbc4:	jae    bc10 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x280>
    bbc6:	test   rcx,rcx
    bbc9:	je     bd63 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x3d3>
    bbcf:	mov    rax,QWORD PTR [r12+rcx*8]
    bbd3:	mov    QWORD PTR [r13+0x10],rax
    bbd7:	add    QWORD PTR [r13+0x110],0xfffffffffffffffc
    bbdf:	mov    QWORD PTR [r12+rcx*8],rbp
    bbe3:	mov    QWORD PTR [r12+rcx*8+0x8],r8
    bbe8:	mov    QWORD PTR [r12+rcx*8+0x10],0x1
    bbf1:	mov    rax,QWORD PTR [r13+0x8]
    bbf5:	test   rax,rax
    bbf8:	je     bd7b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x3eb>
    bbfe:	mov    rdx,QWORD PTR [r12+rax*8]
    bc02:	mov    QWORD PTR [r13+0x8],rdx
    bc06:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    bc0e:	jmp    bc5b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x2cb>
    bc10:	test   rcx,rcx
    bc13:	je     bd90 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x400>
    bc19:	mov    rax,QWORD PTR [r12+rcx*8]
    bc1d:	mov    QWORD PTR [r13+0x10],rax
    bc21:	add    QWORD PTR [r13+0x110],0xfffffffffffffffc
    bc29:	mov    QWORD PTR [r12+rcx*8],rbp
    bc2d:	mov    QWORD PTR [r12+rcx*8+0x8],r9
    bc32:	mov    QWORD PTR [r12+rcx*8+0x10],0x0
    bc3b:	mov    rax,QWORD PTR [r13+0x8]
    bc3f:	test   rax,rax
    bc42:	je     bda8 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x418>
    bc48:	mov    rdx,QWORD PTR [r12+rax*8]
    bc4c:	mov    QWORD PTR [r13+0x8],rdx
    bc50:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    bc58:	mov    r9,r8
    bc5b:	movabs rdx,0x200a60000000000
    bc65:	or     rdx,rcx
    bc68:	mov    QWORD PTR [r12+rax*8],rdx
    bc6c:	mov    QWORD PTR [r12+rax*8+0x8],rbx
    bc71:	movabs rbx,0x200120000000000
    bc7b:	or     rbx,rax
    bc7e:	mov    rax,QWORD PTR [r13+0x8]
    bc82:	test   rax,rax
    bc85:	je     bccc <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x33c>
    bc87:	mov    rcx,QWORD PTR [r12+rax*8]
    bc8b:	mov    QWORD PTR [r13+0x8],rcx
    bc8f:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    bc97:	mov    QWORD PTR [r12+rax*8],r9
    bc9b:	mov    QWORD PTR [r12+rax*8+0x8],rbx
    bca0:	movabs rsi,0x200080000000000
    bcaa:	or     rsi,rax
    bcad:	mov    eax,DWORD PTR [r14-0x8]
    bcb1:	add    r14,0xfffffffffffffff8
    bcb5:	lea    rcx,[rip+0xa7a4]        # 16460 <wl_tab>
    bcbc:	mov    rax,QWORD PTR [rcx+rax*8]
    bcc0:	mov    edi,0x1
    bcc5:	add    rsp,0x10
    bcc9:	pop    rbp
    bcca:	jmp    rax
    bccc:	mov    rdi,r12
    bccf:	mov    rsi,r13
    bcd2:	mov    edx,0x1
    bcd7:	call   13ff8 <heap_alloc_miss>
    bcdc:	jmp    bc97 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x307>
    bcde:	mov    rdi,r12
    bce1:	mov    rsi,r13
    bce4:	mov    edx,0x1
    bce9:	call   13ff8 <heap_alloc_miss>
    bcee:	jmp    bacd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x13d>
    bcf3:	mov    rdi,r12
    bcf6:	mov    rcx,rsi
    bcf9:	mov    rsi,r13
    bcfc:	mov    edx,0x1
    bd01:	call   13ed1 <heap_hand>
    bd06:	mov    rsi,rcx
    bd09:	jmp    ba92 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x102>
    bd0e:	shl    rcx,0x20
    bd12:	or     rcx,rax
    bd15:	shr    rcx,0x18
    bd19:	mov    rax,QWORD PTR [r12+rcx*8]
    bd1d:	mov    rbx,QWORD PTR [r12+rcx*8+0x8]
    bd22:	mov    rdi,r12
    bd25:	mov    r9,rsi
    bd28:	mov    rsi,r13
    bd2b:	mov    r8d,0x2
    bd31:	call   13f62 <span_fade>
    bd36:	mov    rsi,r9
    bd39:	jmp    ba92 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x102>
    bd3e:	mov    rdi,r12
    bd41:	mov    r8,rsi
    bd44:	mov    rsi,r13
    bd47:	xor    edx,edx
    bd49:	call   13ed1 <heap_hand>
    bd4e:	mov    rsi,r8
    bd51:	cmp    rcx,0x3108180
    bd58:	jae    ba5a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0xca>
    bd5e:	jmp    ba92 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x102>
    bd63:	mov    rdi,r12
    bd66:	mov    rsi,r13
    bd69:	mov    edx,0x2
    bd6e:	call   13ff8 <heap_alloc_miss>
    bd73:	mov    rcx,rax
    bd76:	jmp    bbdf <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x24f>
    bd7b:	mov    rdi,r12
    bd7e:	mov    rsi,r13
    bd81:	mov    edx,0x1
    bd86:	call   13ff8 <heap_alloc_miss>
    bd8b:	jmp    bc5b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x2cb>
    bd90:	mov    rdi,r12
    bd93:	mov    rsi,r13
    bd96:	mov    edx,0x2
    bd9b:	call   13ff8 <heap_alloc_miss>
    bda0:	mov    rcx,rax
    bda3:	jmp    bc29 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x299>
    bda8:	mov    rdi,r12
    bdab:	mov    rsi,r13
    bdae:	mov    edx,0x1
    bdb3:	call   13ff8 <heap_alloc_miss>
    bdb8:	jmp    bc58 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x2c8>
    bdbd:	mov    rdi,r12
    bdc0:	mov    rax,rsi
    bdc3:	mov    rsi,r13
    bdc6:	mov    edx,0x2
    bdcb:	call   13ed1 <heap_hand>
    bdd0:	mov    rsi,rax
    bdd3:	jmp    bbbe <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x22e>
    bdd8:	shl    rcx,0x20
    bddc:	or     rcx,rdx
    bddf:	shr    rcx,0x18
    bde3:	mov    r9,QWORD PTR [r12+rcx*8]
    bde7:	mov    ebp,DWORD PTR [r12+rcx*8+0x8]
    bdec:	mov    r10,QWORD PTR [r12+rcx*8+0x10]
    bdf1:	mov    rdi,r12
    bdf4:	mov    rsi,r13
    bdf7:	mov    rdx,rax
    bdfa:	mov    r8d,0x3
    be00:	call   13f62 <span_fade>
    be05:	mov    r8,r10
    be08:	mov    rsi,QWORD PTR [rsp+0x8]
    be0d:	jmp    bbbe <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x22e>
    be12:	mov    rdi,r12
    be15:	mov    rsi,r13
    be18:	xor    edx,edx
    be1a:	call   13ed1 <heap_hand>
    be1f:	mov    rsi,QWORD PTR [rsp+0x8]
    be24:	cmp    rcx,0x3108180
    be2b:	jae    bb87 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x1f7>
    be31:	jmp    bbbe <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x22e>
    be36:	movabs rax,0x7e00000000000000
    be40:	test   rdx,rax
    be43:	sete   al
    be46:	cmp    rdx,0xffffffffffffffff
    be4a:	sete   cl
    be4d:	or     cl,al
    be4f:	and    rbp,rdx
    be52:	cmp    rbp,0x3108180
    be59:	setb   al
    be5c:	or     al,cl
    be5e:	jne    bed1 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x541>
    be60:	mov    rdi,r12
    be63:	mov    rsi,r13
    be66:	jmp    becc <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x53c>
    be68:	movabs r14,0x7e00000000000000
    be72:	test   rax,r14
    be75:	sete   cl
    be78:	cmp    rax,0xffffffffffffffff
    be7c:	sete   dl
    be7f:	or     dl,cl
    be81:	mov    rcx,rax
    be84:	and    rcx,rbp
    be87:	cmp    rcx,0x3108180
    be8e:	setb   cl
    be91:	or     cl,dl
    be93:	jne    bea3 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x513>
    be95:	mov    rdi,r12
    be98:	mov    rsi,r13
    be9b:	mov    rdx,rax
    be9e:	call   6de0 <term_drop>
    bea3:	test   rbx,r14
    bea6:	sete   al
    bea9:	cmp    rbx,0xffffffffffffffff
    bead:	sete   cl
    beb0:	or     cl,al
    beb2:	and    rbp,rbx
    beb5:	cmp    rbp,0x3108180
    bebc:	setb   al
    bebf:	or     al,cl
    bec1:	jne    bed1 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_115_116_101_112_+0x541>
    bec3:	mov    rdi,r12
    bec6:	mov    rsi,r13
    bec9:	mov    rdx,rbx
    becc:	call   6de0 <term_drop>
    bed1:	lea    rdi,[rip+0xffffffffffff67b8]        # 2690 <FID_RESW_T+0x320>
    bed8:	call   13e70 <err_fail>
    bedd:	nop    DWORD PTR [rax]

