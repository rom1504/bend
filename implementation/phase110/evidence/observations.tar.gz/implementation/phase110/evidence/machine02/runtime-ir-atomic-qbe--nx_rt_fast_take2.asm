
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004033b0 <nx_rt_fast_take2>:
  4033b0:	movabs $0xffffffffff,%rax
  4033ba:	push   %r12
  4033bc:	and    %rsi,%rax
  4033bf:	push   %rbp
  4033c0:	push   %rbx
  4033c1:	mov    %rdi,%rbx
  4033c4:	mov    (%rdi),%rdi
  4033c7:	lea    0x0(,%rax,8),%rcx
  4033cf:	mov    0x8(%rbx),%rbp
  4033d3:	lea    (%rdi,%rcx,1),%rdx
  4033d7:	test   %rsi,%rsi
  4033da:	js     403448 <nx_rt_fast_take2+0x98>
  4033dc:	mov    (%rdx),%rdx
  4033df:	mov    %rdx,0x10(%rbx)
  4033e3:	mov    0x8(%rdi,%rcx,1),%rdx
  4033e8:	mov    %rdx,0x18(%rbx)
  4033ec:	cmp    $0x310817f,%rax
  4033f2:	ja     403408 <nx_rt_fast_take2+0x58>
  4033f4:	movl   $0x3,0x20(%rbx)
  4033fb:	xor    %eax,%eax
  4033fd:	pop    %rbx
  4033fe:	pop    %rbp
  4033ff:	pop    %r12
  403401:	retq   
  403402:	nopw   0x0(%rax,%rax,1)
  403408:	mov    0x8(%rbp),%rdx
  40340c:	mov    %rdx,(%rdi,%rax,8)
  403410:	mov    0x3edc2(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403416:	mov    %rax,0x8(%rbp)
  40341a:	mov    0x108(%rbp),%rax
  403421:	add    $0x2,%rax
  403425:	mov    %rax,0x108(%rbp)
  40342c:	cmp    %rdx,%rax
  40342f:	jae    4015fe <nx_rt_fast_take2.cold>
  403435:	movl   $0x3,0x20(%rbx)
  40343c:	xor    %eax,%eax
  40343e:	pop    %rbx
  40343f:	pop    %rbp
  403440:	pop    %r12
  403442:	retq   
  403443:	nopl   0x0(%rax,%rax,1)
  403448:	mov    0x4(%rdx),%ecx
  40344b:	mov    (%rdx),%r8d
  40344e:	shl    $0x20,%rcx
  403452:	or     %r8,%rcx
  403455:	mov    %rcx,%r12
  403458:	and    $0xffffff,%ecx
  40345e:	shr    $0x18,%r12
  403462:	lea    0x0(,%r12,8),%r8
  40346a:	lea    (%rdi,%r8,1),%r9
  40346e:	lea    0x8(%rdi,%r8,1),%r8
  403473:	cmp    $0x1,%rcx
  403477:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  40347d:	mov    (%rdx),%ecx
  40347f:	mov    (%r9),%rcx
  403482:	mov    %rcx,0x10(%rbx)
  403486:	mov    (%r8),%rcx
  403489:	mov    %rcx,0x18(%rbx)
  40348d:	mov    0x0(%rbp),%rcx
  403491:	mov    %rcx,(%rdx)
  403494:	mov    0x3ed3e(%rip),%edx        # 4421d8 <KEEP_WORDS>
  40349a:	mov    %rax,0x0(%rbp)
  40349e:	mov    0x100(%rbp),%rax
  4034a5:	add    $0x1,%rax
  4034a9:	mov    %rax,0x100(%rbp)
  4034b0:	cmp    %rdx,%rax
  4034b3:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  4034b9:	mov    %r12,%rax
  4034bc:	jmpq   4033ec <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
