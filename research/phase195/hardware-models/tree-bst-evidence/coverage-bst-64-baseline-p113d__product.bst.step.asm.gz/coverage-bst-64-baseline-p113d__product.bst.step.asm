0000000000408bff <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_>:
  408bff:	push   rbp
  408c00:	mov    rbp,rsp
  408c03:	sub    rsp,0x9a0
  408c0a:	mov    QWORD PTR [rbp-0x10],r12
  408c0e:	mov    QWORD PTR [rbp-0x8],rbx
  408c12:	mov    QWORD PTR [rbp-0x18],r13
  408c16:	mov    QWORD PTR [rbp-0x20],r14
  408c1a:	mov    QWORD PTR [rbp-0x28],r15
  408c1e:	mov    rax,rdi
  408c21:	mov    r12,rax
  408c24:	mov    rax,rsi
  408c27:	mov    QWORD PTR [rbp-0x30],rax
  408c2b:	mov    rax,rdx
  408c2e:	mov    r15,rax
  408c31:	mov    rax,rcx
  408c34:	mov    rsi,rax
  408c37:	mov    rax,r8
  408c3a:	mov    rbx,rax
  408c3d:	mov    rdi,rsi
  408c40:	shr    rdi,0x28
  408c44:	and    rdi,0xffff
  408c4b:	movabs r11,0xa4
  408c55:	cmp    rdi,r11
  408c58:	jne    408c95 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x96>
  408c5e:	movabs r10,0x100a40000000000
  408c68:	mov    r11,QWORD PTR [rbp-0x30]
  408c6c:	mov    QWORD PTR [r11],r10
  408c6f:	mov    r10,rbx
  408c72:	mov    r11,QWORD PTR [rbp-0x30]
  408c76:	mov    QWORD PTR [r11+0x8],r10
  408c7a:	xor    eax,eax
  408c7c:	mov    r12,QWORD PTR [rbp-0x10]
  408c80:	mov    rbx,QWORD PTR [rbp-0x8]
  408c84:	mov    r13,QWORD PTR [rbp-0x18]
  408c88:	mov    r14,QWORD PTR [rbp-0x20]
  408c8c:	mov    r15,QWORD PTR [rbp-0x28]
  408c90:	mov    rsp,rbp
  408c93:	pop    rbp
  408c94:	ret    
  408c95:	mov    rdi,rsi
  408c98:	shr    rdi,0x28
  408c9c:	and    rdi,0xffff
  408ca3:	movabs r11,0xa5
  408cad:	cmp    rdi,r11
  408cb0:	jne    408e81 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x282>
  408cb6:	mov    r10,r12
  408cb9:	mov    QWORD PTR [rsp+0x18],r10
  408cbe:	mov    r10,rsi
  408cc1:	mov    QWORD PTR [rsp+0x20],r10
  408cc6:	lea    r10,[rbp-0x850]
  408ccd:	mov    QWORD PTR [rsp+0x28],r10
  408cd2:	mov    rdi,QWORD PTR [rsp+0x18]
  408cd7:	mov    rsi,QWORD PTR [rsp+0x20]
  408cdc:	mov    rdx,QWORD PTR [rsp+0x28]
  408ce1:	xor    eax,eax
  408ce3:	call   41de20 <p125_rt_take3>
  408ce8:	mov    QWORD PTR [rbp-0x8d0],rax
  408cef:	lea    r10,[rbp-0x850]
  408cf6:	mov    r14,QWORD PTR [r10]
  408cf9:	lea    r10,[rbp-0x850]
  408d00:	mov    rdi,QWORD PTR [r10+0x8]
  408d04:	lea    r10,[rbp-0x850]
  408d0b:	mov    r13,QWORD PTR [r10+0x10]
  408d0f:	mov    r15d,r15d
  408d12:	mov    esi,edi
  408d14:	mov    r11,rsi
  408d17:	mov    rsi,r15
  408d1a:	cmp    rsi,r11
  408d1d:	setb   sil
  408d21:	movzx  esi,sil
  408d25:	mov    esi,esi
  408d27:	mov    r10,rsi
  408d2a:	test   r10d,r10d
  408d2d:	je     408dc6 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x1c7>
  408d33:	lea    r10,[rbp-0x918]
  408d3a:	mov    r11,rdi
  408d3d:	mov    QWORD PTR [r10],r11
  408d40:	lea    r10,[rbp-0x918]
  408d47:	mov    r11,r13
  408d4a:	mov    QWORD PTR [r10+0x8],r11
  408d4e:	lea    r10,[rbp-0x918]
  408d55:	movabs r11,0x1
  408d5f:	mov    QWORD PTR [r10+0x10],r11
  408d63:	mov    rdi,r12
  408d66:	movabs rsi,0xa6
  408d70:	mov    esi,esi
  408d72:	lea    rdx,[rbp-0x918]
  408d79:	xor    eax,eax
  408d7b:	call   41dd50 <p125_rt_ctor3>
  408d80:	mov    rdi,rax
  408d83:	lea    r10,[rbp-0x918]
  408d8a:	mov    r11,rdi
  408d8d:	mov    QWORD PTR [r10],r11
  408d90:	lea    r10,[rbp-0x918]
  408d97:	mov    r11,rbx
  408d9a:	mov    QWORD PTR [r10+0x8],r11
  408d9e:	mov    rdi,r12
  408da1:	movabs rsi,0x12
  408dab:	mov    esi,esi
  408dad:	lea    rdx,[rbp-0x918]
  408db4:	xor    eax,eax
  408db6:	call   41dad0 <p125_rt_ctor2>
  408dbb:	mov    rdi,rax
  408dbe:	mov    r13,r14
  408dc1:	jmp    408e51 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x252>
  408dc6:	lea    r10,[rbp-0x918]
  408dcd:	mov    r11,rdi
  408dd0:	mov    QWORD PTR [r10],r11
  408dd3:	lea    r10,[rbp-0x918]
  408dda:	mov    r11,r14
  408ddd:	mov    QWORD PTR [r10+0x8],r11
  408de1:	lea    r10,[rbp-0x918]
  408de8:	movabs r11,0x0
  408df2:	mov    QWORD PTR [r10+0x10],r11
  408df6:	mov    rdi,r12
  408df9:	movabs rsi,0xa6
  408e03:	mov    esi,esi
  408e05:	lea    rdx,[rbp-0x918]
  408e0c:	xor    eax,eax
  408e0e:	call   41dd50 <p125_rt_ctor3>
  408e13:	mov    rdi,rax
  408e16:	lea    r10,[rbp-0x918]
  408e1d:	mov    r11,rdi
  408e20:	mov    QWORD PTR [r10],r11
  408e23:	lea    r10,[rbp-0x918]
  408e2a:	mov    r11,rbx
  408e2d:	mov    QWORD PTR [r10+0x8],r11
  408e31:	mov    rdi,r12
  408e34:	movabs rsi,0x12
  408e3e:	mov    esi,esi
  408e40:	lea    rdx,[rbp-0x918]
  408e47:	xor    eax,eax
  408e49:	call   41dad0 <p125_rt_ctor2>
  408e4e:	mov    rdi,rax
  408e51:	mov    r10,r13
  408e54:	mov    r11,QWORD PTR [rbp-0x30]
  408e58:	mov    QWORD PTR [r11],r10
  408e5b:	mov    r10,rdi
  408e5e:	mov    r11,QWORD PTR [rbp-0x30]
  408e62:	mov    QWORD PTR [r11+0x8],r10
  408e66:	xor    eax,eax
  408e68:	mov    r12,QWORD PTR [rbp-0x10]
  408e6c:	mov    rbx,QWORD PTR [rbp-0x8]
  408e70:	mov    r13,QWORD PTR [rbp-0x18]
  408e74:	mov    r14,QWORD PTR [rbp-0x20]
  408e78:	mov    r15,QWORD PTR [rbp-0x28]
  408e7c:	mov    rsp,rbp
  408e7f:	pop    rbp
  408e80:	ret    
  408e81:	mov    rdi,r12
  408e84:	movabs rsi,0x4
  408e8e:	mov    esi,esi
  408e90:	xor    eax,eax
  408e92:	call   4185b0 <p111_rt_fail>
  408e97:	mov    QWORD PTR [rbp-0x8d0],rax
  408e9e:	movabs r10,0x0
  408ea8:	mov    r11,QWORD PTR [rbp-0x30]
  408eac:	mov    QWORD PTR [r11],r10
  408eaf:	movabs r10,0x0
  408eb9:	mov    r11,QWORD PTR [rbp-0x30]
  408ebd:	mov    QWORD PTR [r11+0x8],r10
  408ec1:	xor    eax,eax
  408ec3:	mov    r12,QWORD PTR [rbp-0x10]
  408ec7:	mov    rbx,QWORD PTR [rbp-0x8]
  408ecb:	mov    r13,QWORD PTR [rbp-0x18]
  408ecf:	mov    r14,QWORD PTR [rbp-0x20]
  408ed3:	mov    r15,QWORD PTR [rbp-0x28]
  408ed7:	mov    rsp,rbp
  408eda:	pop    rbp
  408edb:	ret    

