
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403b40 <nx_rt_rebuild2_c3_k0>:
  403b40:	push   %r15
  403b42:	push   %r14
  403b44:	push   %r13
  403b46:	push   %r12
  403b48:	mov    %rdx,%r12
  403b4b:	push   %rbp
  403b4c:	mov    %rdi,%rbp
  403b4f:	push   %rbx
  403b50:	movabs $0xffffffffff,%rbx
  403b5a:	and    %rsi,%rbx
  403b5d:	lea    0x0(,%rbx,8),%rdx
  403b65:	sub    $0x18,%rsp
  403b69:	mov    (%rdi),%r13
  403b6c:	mov    0x8(%rdi),%r15
  403b70:	lea    0x0(%r13,%rdx,1),%rax
  403b75:	test   %rsi,%rsi
  403b78:	js     403c40 <nx_rt_rebuild2_c3_k0+0x100>
  403b7e:	mov    (%rax),%r14
  403b81:	mov    0x8(%r13,%rdx,1),%r9
  403b86:	cmp    $0x310817f,%rbx
  403b8d:	jbe    403c18 <nx_rt_rebuild2_c3_k0+0xd8>
  403b93:	lea    0x0(%r13,%rbx,8),%r8
  403b98:	mov    %r14,%rax
  403b9b:	mov    %r9,0x10(%rbp)
  403b9f:	shr    $0x38,%rax
  403ba3:	movq   $0xffffffffffffffff,0x18(%rbp)
  403bab:	and    $0x7f,%eax
  403bae:	movl   $0x1,0x20(%rbp)
  403bb5:	cmp    $0x2,%rax
  403bb9:	je     403bf8 <nx_rt_rebuild2_c3_k0+0xb8>
  403bbb:	mov    %r12,%rax
  403bbe:	mov    %r14,(%r8)
  403bc1:	lea    0x8(%r13,%rbx,8),%rbp
  403bc6:	shr    $0x38,%rax
  403bca:	and    $0x7f,%eax
  403bcd:	cmp    $0x2,%rax
  403bd1:	je     403c08 <nx_rt_rebuild2_c3_k0+0xc8>
  403bd3:	movabs $0x200030000000000,%rax
  403bdd:	mov    %r12,0x0(%rbp)
  403be1:	add    $0x18,%rsp
  403be5:	or     %rbx,%rax
  403be8:	pop    %rbx
  403be9:	pop    %rbp
  403bea:	pop    %r12
  403bec:	pop    %r13
  403bee:	pop    %r14
  403bf0:	pop    %r15
  403bf2:	retq   
  403bf3:	nopl   0x0(%rax,%rax,1)
  403bf8:	test   %r14,%r14
  403bfb:	js     403bbb <nx_rt_rebuild2_c3_k0+0x7b>
  403bfd:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  403c02:	nopw   0x0(%rax,%rax,1)
  403c08:	test   %r12,%r12
  403c0b:	js     403bd3 <nx_rt_rebuild2_c3_k0+0x93>
  403c0d:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  403c12:	nopw   0x0(%rax,%rax,1)
  403c18:	mov    0x8(%r15),%rbx
  403c1c:	test   %rbx,%rbx
  403c1f:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  403c25:	lea    0x0(%r13,%rbx,8),%r8
  403c2a:	mov    (%r8),%rax
  403c2d:	subq   $0x2,0x108(%r15)
  403c35:	mov    %rax,0x8(%r15)
  403c39:	jmpq   403b98 <nx_rt_rebuild2_c3_k0+0x58>
  403c3e:	xchg   %ax,%ax
  403c40:	mov    0x4(%rax),%edx
  403c43:	mov    (%rax),%ecx
  403c45:	shl    $0x20,%rdx
  403c49:	or     %rcx,%rdx
  403c4c:	mov    %rdx,%rcx
  403c4f:	and    $0xffffff,%edx
  403c55:	shr    $0x18,%rcx
  403c59:	lea    0x8(,%rcx,8),%rdi
  403c61:	lea    0x0(%r13,%rdi,1),%r8
  403c66:	lea    -0x8(%r13,%rdi,1),%rdi
  403c6b:	cmp    $0x1,%rdx
  403c6f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  403c75:	mov    (%rax),%edx
  403c77:	mov    (%r15),%rdx
  403c7a:	mov    (%rdi),%r14
  403c7d:	mov    (%r8),%r9
  403c80:	mov    %rdx,(%rax)
  403c83:	mov    0x100(%r15),%rax
  403c8a:	mov    0x3d548(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403c90:	mov    %rbx,(%r15)
  403c93:	add    $0x1,%rax
  403c97:	mov    %rax,0x100(%r15)
  403c9e:	cmp    %rdx,%rax
  403ca1:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  403ca7:	mov    %rcx,%rbx
  403caa:	jmpq   403b86 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
