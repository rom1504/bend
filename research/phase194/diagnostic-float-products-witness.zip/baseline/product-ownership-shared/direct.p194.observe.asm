  408dd5:	push   %rbp
  408dd6:	mov    %rsp,%rbp
  408dd9:	sub    $0x920,%rsp
  408de0:	mov    %r12,-0x10(%rbp)
  408de4:	mov    %rbx,-0x8(%rbp)
  408de8:	mov    %r13,-0x18(%rbp)
  408dec:	mov    %rdi,%rax
  408def:	mov    %rax,%r12
  408df2:	mov    %rsi,%rax
  408df5:	mov    %rax,%rbx
  408df8:	mov    %r12,%rdi
  408dfb:	mov    %rbx,%rsi
  408dfe:	movabs $0x0,%rdx
  408e08:	movabs $0x1,%rcx
  408e12:	mov    %ecx,%ecx
  408e14:	xor    %eax,%eax
  408e16:	callq  41b9d0 <p118_rt_borrow_scalar_safe>
  408e1b:	mov    %rax,%rdi
  408e1e:	cmp    $0x0,%rdi
  408e25:	je     408e63 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x8e>
  408e2b:	mov    %r12,%rdi
  408e2e:	mov    %rbx,%rsi
  408e31:	xor    %eax,%eax
  408e33:	callq  408a1c <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_112_49_57_52_46_111_98_115_101_114_118_101_>
  408e38:	mov    %rax,%r13
  408e3b:	mov    %r12,%rdi
  408e3e:	mov    %rbx,%rsi
  408e41:	xor    %eax,%eax
  408e43:	callq  415580 <p111_rt_sink>
  408e48:	mov    %rax,-0x8a0(%rbp)
  408e4f:	mov    %r13,%rax
  408e52:	mov    -0x10(%rbp),%r12
  408e56:	mov    -0x8(%rbp),%rbx
  408e5a:	mov    -0x18(%rbp),%r13
  408e5e:	mov    %rbp,%rsp
  408e61:	pop    %rbp
  408e62:	retq   
  408e63:	mov    %r12,%rdi
  408e66:	mov    %rbx,%rsi
  408e69:	xor    %eax,%eax
  408e6b:	callq  4089a7 <p113d_FID_36_112_49_50_56_98_111_114_114_111_119_46_111_119_110_101_100_46_112_49_57_52_46_111_98_115_101_114_118_101_>
  408e70:	mov    %rax,%rdi
  408e73:	mov    %rdi,%rax
  408e76:	mov    -0x10(%rbp),%r12
  408e7a:	mov    -0x8(%rbp),%rbx
  408e7e:	mov    -0x18(%rbp),%r13
  408e82:	mov    %rbp,%rsp
  408e85:	pop    %rbp
  408e86:	retq   
