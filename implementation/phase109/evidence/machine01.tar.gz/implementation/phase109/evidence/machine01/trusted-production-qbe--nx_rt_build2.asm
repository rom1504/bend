
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402f00 <nx_rt_build2>:
  402f00:	endbr64 
  402f04:	push   %rbp
  402f05:	mov    %rsp,%rbp
  402f08:	sub    $0x28,%rsp
  402f0c:	push   %rbx
  402f0d:	push   %r12
  402f0f:	push   %r13
  402f11:	mov    %rcx,%r13
  402f14:	mov    %rdx,%r12
  402f17:	mov    %esi,%ebx
  402f19:	callq  402900 <nx_env>
  402f1e:	mov    %r13,%r8
  402f21:	mov    %r12,%rcx
  402f24:	mov    %rax,%rsi
  402f27:	mov    %rdx,%rax
  402f2a:	mov    %ebx,%edx
  402f2c:	mov    %rsi,-0x20(%rbp)
  402f30:	mov    %rax,-0x18(%rbp)
  402f34:	mov    -0x20(%rbp),%rax
  402f38:	mov    %rax,-0x10(%rbp)
  402f3c:	mov    -0x18(%rbp),%rax
  402f40:	mov    %rax,-0x8(%rbp)
  402f44:	mov    %r8,%r13
  402f47:	mov    %rcx,%r12
  402f4a:	mov    %edx,%ebx
  402f4c:	mov    -0x10(%rbp),%rdi
  402f50:	mov    -0x8(%rbp),%rsi
  402f54:	callq  402d90 <nx_fields>
  402f59:	mov    $0x2,%edi
  402f5e:	callq  4015a0 <cls_fit>
  402f63:	mov    %eax,%edx
  402f65:	mov    -0x10(%rbp),%rdi
  402f69:	mov    -0x8(%rbp),%rsi
  402f6d:	callq  4019b0 <heap_alloc>
  402f72:	mov    %r13,%r8
  402f75:	mov    %r12,%rcx
  402f78:	mov    %ebx,%edx
  402f7a:	mov    %rax,%r9
  402f7d:	mov    -0x10(%rbp),%rdi
  402f81:	mov    -0x8(%rbp),%rsi
  402f85:	callq  402e80 <nx_construct2>
  402f8a:	pop    %r13
  402f8c:	pop    %r12
  402f8e:	pop    %rbx
  402f8f:	leaveq 
  402f90:	retq   

Disassembly of section .fini:
