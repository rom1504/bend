    9c90:	test   %rsi,%rsi
    9c93:	je     9d36 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0xa6>
    9c99:	movd   %edx,%xmm0
    9c9d:	mov    %rsi,%rax
    9ca0:	and    $0x3,%rax
    9ca4:	je     9cd6 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x46>
    9ca6:	xor    %ecx,%ecx
    9ca8:	movss  -0x7f2c(%rip),%xmm1        # 1d84 <_IO_stdin_used-0x8>
    9cb0:	movdqa %xmm0,%xmm2
    9cb4:	addss  %xmm1,%xmm0
    9cb8:	addss  %xmm0,%xmm0
    9cbc:	subss  %xmm2,%xmm0
    9cc0:	inc    %rcx
    9cc3:	cmp    %rcx,%rax
    9cc6:	jne    9cb0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x20>
    9cc8:	mov    %rsi,%rax
    9ccb:	sub    %rcx,%rax
    9cce:	cmp    $0x4,%rsi
    9cd2:	jae    9cdf <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x4f>
    9cd4:	jmp    9d32 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0xa2>
    9cd6:	mov    %rsi,%rax
    9cd9:	cmp    $0x4,%rsi
    9cdd:	jb     9d32 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0xa2>
    9cdf:	movss  -0x7f63(%rip),%xmm1        # 1d84 <_IO_stdin_used-0x8>
    9ce7:	nopw   0x0(%rax,%rax,1)
    9cf0:	movaps %xmm0,%xmm2
    9cf3:	addss  %xmm1,%xmm2
    9cf7:	addss  %xmm2,%xmm2
    9cfb:	subss  %xmm0,%xmm2
    9cff:	movaps %xmm2,%xmm0
    9d02:	addss  %xmm1,%xmm0
    9d06:	addss  %xmm0,%xmm0
    9d0a:	subss  %xmm2,%xmm0
    9d0e:	movaps %xmm0,%xmm2
    9d11:	addss  %xmm1,%xmm2
    9d15:	addss  %xmm2,%xmm2
    9d19:	subss  %xmm0,%xmm2
    9d1d:	movaps %xmm2,%xmm0
    9d20:	addss  %xmm1,%xmm0
    9d24:	addss  %xmm0,%xmm0
    9d28:	subss  %xmm2,%xmm0
    9d2c:	add    $0xfffffffffffffffc,%rax
    9d30:	jne    9cf0 <WL_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_102_108_111_111_112_+0x60>
    9d32:	movd   %xmm0,%edx
    9d36:	mov    %edx,%esi
    9d38:	mov    -0x8(%r14),%eax
    9d3c:	add    $0xfffffffffffffff8,%r14
    9d40:	lea    0x9459(%rip),%rcx        # 131a0 <wl_tab>
    9d47:	mov    (%rcx,%rax,8),%rax
    9d4b:	mov    $0x1,%edi
    9d50:	jmpq   *%rax
    9d52:	data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
