function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0n ? {$: "Tuple", fst: 0n, snd: a}
    : {$: "Tuple", fst: a / b, snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655n) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && Math.fround(Number(s)) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = Number(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: Math.fround(v)} : {$: "None"};
}

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31n) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** Number(d)).fill(v);
}

// An unbalanced tree fails, as in C.
function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_swap(a, i, v) {
  const at = i % a.length;
  const old = a[at];
  a[at] = v;
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_jump(f, x) {
  return {$: "$JMP", f: f, x: x};
}

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : run_loop(f(...a));
}
const $0eff = {
...(() => {
// IO
// ==

function io_print(text) {
  io_out(1, io_bytes(text + "\n"));
  return { $: "Unit" };
}

return {
  io_print: typeof io_print === "function" ? io_print : undefined,
  io_print_need: typeof io_print_need === "function" ? io_print_need : undefined,
};
})(),
};

// Program
// =======

function $main$() {
  return (x_0) => $IO$print$(run_loop($U32$show$(run_loop($main$out$()))), x_0);
}

function $U32$show$(a_0) {
  const b_0 = a_0;
  return run_jump($U32$show$if$, [b_0, (b_0 === 0)]);
}

function $main$out$() {
  const x_0 = run_loop($digest$(run_loop($lsort$({$: "Con", ["head"]: 5, ["tail"]: {$: "Con", ["head"]: 3, ["tail"]: {$: "Con", ["head"]: 9, ["tail"]: {$: "Con", ["head"]: 1, ["tail"]: {$: "Con", ["head"]: 4, ["tail"]: {$: "Nil"}}}}}}))));
  const b0_0 = run_loop($bu$((x_0 === 13459)));
  const x_1 = run_loop($digest$(run_loop($lsort$({$: "Nil"}))));
  const b1_0 = run_loop($bu$((x_1 === 0)));
  const x_2 = run_loop($digest$(run_loop($lsort$({$: "Con", ["head"]: 1, ["tail"]: {$: "Con", ["head"]: 2, ["tail"]: {$: "Con", ["head"]: 3, ["tail"]: {$: "Nil"}}}}))));
  const b2_0 = run_loop($bu$((x_2 === 123)));
  const x_3 = ((b0_0 + b1_0) >>> 0);
  const x_4 = ((x_3 + b2_0) >>> 0);
  const x_5 = run_loop($big$x$(run_loop($lsort$({$: "Con", ["head"]: 4294967295, ["tail"]: {$: "Con", ["head"]: 0, ["tail"]: {$: "Con", ["head"]: 2147483648, ["tail"]: {$: "Nil"}}}}))));
  return ((x_4 + x_5) >>> 0);
}

function $U32$show$if$(a_0, z_0) {
  if (z_0) {
    return "0";
  } else {
    return run_jump($U32$show$go$, [10n, a_0, ""]);
  }
}

function $bu$(b_0) {
  if (!b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $digest$(xs_0) {
  return run_jump($digest$go$, [xs_0, 0]);
}

function $lsort$(xs_0) {
  return run_jump($sgo$, [32n, 0n, xs_0]);
}

function $big$x$(big_0) {
  return run_jump($big$a$, [run_loop($lget$(99, 0n, big_0))]);
}

function $U32$show$go$(f_0, n_0, acc_0) {
  if (f_0 === 0n) {
    return acc_0;
  } else {
    const g_0 = (f_0 - 1n);
    return run_jump($U32$show$fin$, [g_0, acc_0, n_0, (n_0 === 0)]);
  }
}

function $digest$go$(xs_0, acc_0) {
  if (xs_0.$ === "Nil") {
    return acc_0;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    const x_0 = (Math.imul(acc_0, 10) >>> 0);
    return run_jump($digest$go$, [t_0, ((x_0 + h_0) >>> 0)]);
  }
}

function $sgo$(k_0, b_0, xs_0) {
  if (k_0 === 0n) {
    return xs_0;
  } else {
    const j_0 = (k_0 - 1n);
    return run_jump($sgo$, [j_0, nat_chk(b_0 + 1n), run_loop($spass$(b_0, xs_0, {$: "Nil"}, {$: "Nil"}))]);
  }
}

function $big$a$(r_0) {
  const b1_0 = r_0["fst"];
  const x_0 = r_0["snd"];
  return run_jump($big$b$, [x_0, run_loop($lget$(99, 1n, b1_0))]);
}

function $lget$(d_0, i_0, xs_0) {
  if (i_0 === 0n) {
    if (xs_0.$ === "Nil") {
      return {$: "Tuple", ["fst"]: {$: "Nil"}, ["snd"]: d_0};
    } else {
      const h0_0 = xs_0["head"];
      const t_0 = xs_0["tail"];
      return {$: "Tuple", ["fst"]: {$: "Con", ["head"]: h0_0, ["tail"]: t_0}, ["snd"]: h0_0};
    }
  } else {
    const p_0 = (i_0 - 1n);
    if (xs_0.$ === "Nil") {
      return {$: "Tuple", ["fst"]: {$: "Nil"}, ["snd"]: d_0};
    } else {
      const h_0 = xs_0["head"];
      const t_1 = xs_0["tail"];
      return run_jump($lget$put$, [h_0, run_loop($lget$(d_0, p_0, t_1))]);
    }
  }
}

function $U32$show$fin$(g_0, acc_0, n_0, z_0) {
  if (z_0) {
    return acc_0;
  } else {
    const x_0 = (10 === 0 ? n_0 : n_0 % 10);
    return run_jump($U32$show$go$, [g_0, (10 === 0 ? 0 : (n_0 / 10) >>> 0), (char_new(((48 + x_0) >>> 0)) + acc_0)]);
  }
}

function $spass$(b_0, xs_0, zs_0, os_0) {
  if (xs_0.$ === "Con") {
    const h0_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    const x_0 = (b_0 >= 32n ? 0 : (h0_0 >>> Number(b_0)) >>> 0);
    const x_1 = ((x_0 & 1) >>> 0);
    return run_jump($spass$go$, [b_0, t_0, h0_0, (x_1 === 0), zs_0, os_0]);
  } else {
    return run_jump($lconcat$, [run_loop($lrev$(zs_0)), run_loop($lrev$(os_0))]);
  }
}

function $big$b$(x_0, r_0) {
  const b2_0 = r_0["fst"];
  const y_0 = r_0["snd"];
  return run_jump($big$c$, [x_0, y_0, run_loop($lget$(99, 2n, b2_0))]);
}

function $lget$put$(h_0, r_0) {
  const t2_0 = r_0["fst"];
  const x_0 = r_0["snd"];
  return {$: "Tuple", ["fst"]: {$: "Con", ["head"]: h_0, ["tail"]: t2_0}, ["snd"]: x_0};
}

function $spass$go$(b_0, xs_0, h_0, f_0, zs_0, os_0) {
  if (xs_0.$ === "Con") {
    const h0_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    if (f_0) {
      const x_0 = (b_0 >= 32n ? 0 : (h0_0 >>> Number(b_0)) >>> 0);
      const x_1 = ((x_0 & 1) >>> 0);
      return run_jump($spass$go$, [b_0, t_0, h0_0, (x_1 === 0), {$: "Con", ["head"]: h_0, ["tail"]: zs_0}, os_0]);
    } else {
      const x_2 = (b_0 >= 32n ? 0 : (h0_0 >>> Number(b_0)) >>> 0);
      const x_3 = ((x_2 & 1) >>> 0);
      return run_jump($spass$go$, [b_0, t_0, h0_0, (x_3 === 0), zs_0, {$: "Con", ["head"]: h_0, ["tail"]: os_0}]);
    }
  } else {
    if (f_0) {
      return run_jump($lconcat$, [run_loop($lrev$({$: "Con", ["head"]: h_0, ["tail"]: zs_0})), run_loop($lrev$(os_0))]);
    } else {
      return run_jump($lconcat$, [run_loop($lrev$(zs_0)), run_loop($lrev$({$: "Con", ["head"]: h_0, ["tail"]: os_0}))]);
    }
  }
}

function $lconcat$(xs_0, ys_0) {
  if (xs_0.$ === "Nil") {
    return ys_0;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    return {$: "Con", ["head"]: h_0, ["tail"]: run_loop($lconcat$(t_0, ys_0))};
  }
}

function $lrev$(xs_0) {
  return run_jump($lrev$go$, [xs_0, {$: "Nil"}]);
}

function $big$c$(x_0, y_0, r_0) {
  const b3_0 = r_0["fst"];
  const z_0 = r_0["snd"];
  const m3_0 = run_loop($bu$((x_0 === 0)));
  const m4_0 = run_loop($bu$((y_0 === 2147483648)));
  const m5_0 = run_loop($bu$((z_0 === 4294967295)));
  const x_1 = ((m3_0 + m4_0) >>> 0);
  return ((x_1 + m5_0) >>> 0);
}

function $lrev$go$(xs_0, acc_0) {
  if (xs_0.$ === "Nil") {
    return acc_0;
  } else {
    const h_0 = xs_0["head"];
    const t_0 = xs_0["tail"];
    return run_jump($lrev$go$, [t_0, {$: "Con", ["head"]: h_0, ["tail"]: acc_0}]);
  }
}

function $IO$print$(text_0, k_0) {
  return { $: "$FFI", run: $0eff.io_print, need: $0eff.io_print_need, args: [text_0], kont: k_0 };
}

// Cli
// ===

// A JS program runs one thread and no GPU: --threads and --gpu do nothing.
let cli_args = [];

function cli(argv) {
  for (let i = 0; i < argv.length; i += 1) {
    if (argv[i] === "--") {
      cli_args.push(...argv.slice(i + 1));
      break;
    } else if (argv[i] === "--help") {
      io_out(1, io_bytes("usage: " + process.argv[1] + "\n"));
      process.exit(0);
    } else if (argv[i] === "--threads" || argv[i] === "--gpu") {
      i += 1;
    } else {
      cli_args.push(argv[i]);
    }
  }
}

// Show
// ====

// char_show: an escape, a \u{hex}, else the code point
function show_chr(c, q) {
  const k = { 10: "n", 9: "t", 13: "r", 0: "0", 92: "\\" }[c]
    ?? (c === q.codePointAt(0) ? q : null);
  return k !== null ? "\\" + k : c < 32 || c === 127
    ? "\\u{" + c.toString(16) + "}" : String.fromCodePoint(c);
}

// A pure main's value, spelled as term_show spells it: d is a node of
// the descriptor D over the names N (see show_main), v the value, chain
// the bracket of the [a, b] or (a, b) it continues, or 0.
function show_val(D, N, d, v, chain) {
  if (D[d] === 7) {
    const fs = Object.values(typeof v === "boolean"
      ? { $: v ? "True" : "False" } : v);
    let a = d + 3;
    for (; N[D[a]] !== fs[0]; a += 3 + 2 * D[a + 2]) {}
    let o = "{";
    let z = "}";
    if (fs[0] === "Con" || fs[0] === "Nil") {
      o = "[";
      z = "]";
    } else if (fs[0] === "Tuple") {
      o = "(";
      z = ")";
    }
    let s = o === "{" ? fs[0] + "{" : chain === o ? "" : o;
    for (const [j, f] of fs.slice(1).entries()) {
      if (o === "[" ? j === 0 && chain === o : j > 0) {
        s += ", ";
      }
      s += show_val(D, N, D[a + 4 + 2 * j], f, j === 1 && o !== "{" ? o : 0);
    }
    return o === "{" || chain !== o ? s + z : s;
  }
  return D[d] === 0 ? String(v)
    : D[d] === 1 ? f32_show(v).replace(/^-?\d+(?=e|$)/, "$&.0")
    : D[d] === 2 ? v + "n"
    : D[d] === 3 ? "'" + show_chr(v.codePointAt(0), "'") + "'"
    : D[d] === 4 ? "\"" + [...v].map((c) =>
      show_chr(c.codePointAt(0), "\"")).join("") + "\""
    : D[d] === 5 ? "{==}"
    : "[" + v.map((x) => show_val(D, N, D[d + 1], x, 0)).join(", ") + "]";
}

// Io
// ==

function io_exit(main, show) {
  try {
    if (show !== null) {
      io_out(1, io_bytes(show_val(...show, 0, run_loop(main()), 0) + "\n"));
      process.exit(0);
    }
    process.exit(io_run(main));
  } catch (e) {
    io_errs(String(e));
    process.exit(1);
  }
}

function io_out(fd, data) {
  const fs = require("fs");
  let at = 0;
  while (at < data.length) {
    try {
      at += fs.writeSync(fd, data, at, data.length - at);
    } catch (e) {
      if (e.code === "EAGAIN" || e.code === "EINTR") {
        continue;
      }
      try {
        fs.writeSync(2, "bend: a short write on a standard stream\n");
      } catch (o) {
      }
      process.exit(1);
    }
  }
}

function io_errs(message) {
  io_out(2, io_bytes(message + "\n"));
}

function io_sys() {
  if (globalThis.BEND_SYS === undefined) {
    const ffi = require("bun:ffi");
    const mac = process.platform === "darwin";
    const err = mac ? "__error" : "__errno_location";
    const T = { i: "i32", u: "u32", U: "u64", I: "i64", p: "ptr",
      c: "cstring" };
    // fcntl is variadic. Apple arm64 passes variadic arguments on the
    // stack, where the fixed convention puts arguments past the eighth, so
    // there the flags ride as a ninth argument; elsewhere in a register.
    const vari = mac && process.arch === "arm64";
    const lib = ffi.dlopen(mac ? "libSystem.dylib" : "libc.so.6",
      Object.fromEntries(("socket:iii>i bind:ipu>i listen:ii>i connect:ipu>i"
        + " accept:ipp>i send:ipUi>I recv:ipUi>I read:ipU>I pread:ipUI>I"
        + " sendto:ipUipu>I"
        + " recvfrom:ipUipp>I close:i>i poll:pui>i setsockopt:iiipu>i"
        + (vari ? " fcntl:iiiiiiiii>i" : " fcntl:iii>i") + " getsockopt:iiipp>i"
        + " strerror:i>c " + err + ":>p").split(" ").map((s) => {
        const [name, args, ret] = s.split(/[:>]/);
        return [name, { args: [...args].map((a) => T[a]), returns: T[ret] }];
      })));
    const fcntl = (fd, cmd, arg) => vari
      ? lib.symbols.fcntl(fd, cmd, 0, 0, 0, 0, 0, 0, arg)
      : lib.symbols.fcntl(fd, cmd, arg);
    globalThis.BEND_SYS = { ...lib.symbols, fcntl, ptr: ffi.ptr, mac,
      errno: () => ffi.read.i32(lib.symbols[err](), 0) };
  }
  return globalThis.BEND_SYS;
}

function io_fail(code) {
  const text = String(io_sys().strerror(code));
  return { $: "Fail", error: io_tup(code >>> 0, text) };
}

function io_done(value) {
  return { $: "Done", value };
}

function io_tup(...xs) {
  return xs.reduceRight((snd, fst) => ({ $: "Tuple", fst: fst, snd: snd }));
}

function io_bytes(text) {
  return new TextEncoder().encode(text);
}

function io_text(b, n) {
  const dec = new TextDecoder("utf-8", { ignoreBOM: true });
  return dec.decode(b.subarray(0, n));
}

function io_addr(host, port) {
  const part = host.split(".");
  const deci = (p) => /^(0|[1-9]\d{0,2})$/.test(p) && Number(p) < 256;
  if (port > 65535 || part.length !== 4 || !part.every(deci)) {
    return null;
  }
  const b = new Uint8Array(16);
  const head = io_sys().mac ? [16, 2] : [2, 0];
  b.set([...head, port >> 8, port & 255, ...part.map(Number)]);
  return b;
}

function io_push(fun, arg, fresh) {
  const io = globalThis.BEND_IO;
  io.runs.push({ fun: fun, arg: arg });
  io.live += fresh ? 1 : 0;
}

function io_wait(io) {
  const soon = io.waits.reduce((m, w) => Math.min(m, w.at ?? m), Infinity);
  let ms = -1;
  if (soon !== Infinity) {
    ms = Math.ceil(soon - performance.now());
    ms = Math.min(Math.max(0, ms), 2147483647);
  }
  const fds = io.waits.filter((w) => w.fd !== undefined);
  const buf = Int32Array.from(fds.flatMap((w) => [w.fd, w.out ? 4 : 1]));
  io_sys().poll(fds.length > 0 ? io_sys().ptr(buf) : null, fds.length, ms);
  const now = performance.now();
  const fire = io.waits.filter((w) =>
    (buf[2 * fds.indexOf(w) + 1] >>> 16) !== 0 || w.at <= now);
  io.waits = io.waits.filter((w) => !fire.includes(w));
  for (const w of fire) {
    io_push(io_wake, w, false);
  }
}

// A park's wake: more's value goes to k, or undefined, a re-park.
function io_wake(w) {
  const x = w.more();
  return x === undefined ? undefined : w.k(x);
}

// Parks the running effect until fd is readable (out false) or writable,
// or until at (a performance.now() tick; undefined for no deadline),
// whichever comes first.
function io_park_on(fd, out, k, more, at) {
  globalThis.BEND_IO.waits.push({ fd: fd, out: out, k: k, more: more, at: at });
}

function io_run(m) {
  const io = { runs: [], live: 0, waits: [] };
  globalThis.BEND_IO = io;
  try {
    io_push(run_loop(m()), (x) => ({ $: "Emit", value: x }), true);
    for (;;) {
      if (io.runs.length === 0) {
        if (io.live === 0) {
          return 0;
        }
        if (io.waits.length === 0) {
          io_errs("bend: deadlock: every computation waits on a channel");
          return 1;
        }
        io_wait(io);
        continue;
      }
      const s = io.runs.shift();
      let op = s.fun(s.arg);
      for (;;) {
        if (op === undefined) {
          break;
        }
        if (op.$ === "Emit") {
          io.live -= 1;
          break;
        }
        if (op.$ === "Halt") {
          io_errs(op.message);
          return op.code;
        }
        const need = op.need?.() ?? {};
        const fd = need.read ? op.args[0] : null;
        if (need.time || fd !== null) {
          const more = () => op.run(...op.args, op.kont);
          io.waits.push(fd === null
            ? { at: performance.now() + Number(op.args[0]), k: op.kont, more }
            : { fd: fd, k: op.kont, more });
          break;
        }
        const x = op.run(...op.args, op.kont);
        if (x === undefined) {
          break;
        }
        op = op.kont(x);
      }
    }
  } catch (req) {
    if (req instanceof RangeError) {
      throw "bend: memory fault (machine stack overflow?)";
    }
    if (req?.$ !== "$FFI") {
      throw req;
    }
    io_errs("bend: runtime fail-stop");
    return 1;
  }
}

// Chan
// ====

// A parked receiver holds CHAN_RECV: the C lane parks TERM_HOLE, and a
// program can make neither. A sent value may be null (an erased proof).
const CHAN_RECV = Symbol();

function chan_wake(row, x) {
  const w = row.wait.shift();
  io_push(w.cont, x, false);
  return w.item;
}

function chan_take(row) {
  const v = row.ring.shift();
  if (row.wait.length > 0) {
    row.ring.push(chan_wake(row, true));
  }
  return v;
}

// A handle is the row (a stale copy keeps it, shut).
function chan_shut(row) {
  row.shut = true;
  while (row.wait.length > 0) {
    chan_wake(row, row.wait[0].item === CHAN_RECV ? { $: "None" } : false);
  }
}

cli(process.argv.slice(2));
io_exit($main$, null);