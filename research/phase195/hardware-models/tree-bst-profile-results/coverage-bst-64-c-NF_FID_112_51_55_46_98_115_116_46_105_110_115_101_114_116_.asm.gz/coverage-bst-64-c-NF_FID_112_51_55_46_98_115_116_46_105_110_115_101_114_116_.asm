0000000000011390 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_>:
   11390:	push   rbp
   11391:	push   r15
   11393:	push   r14
   11395:	push   r13
   11397:	push   r12
   11399:	push   rbx
   1139a:	sub    rsp,0x18
   1139e:	mov    QWORD PTR [rsp+0x10],rdx
   113a3:	mov    rbx,rsi
   113a6:	mov    r14,rdi
   113a9:	movabs r11,0x100a40000000000
   113b3:	movabs r15,0x100110000000000
   113bd:	movabs rax,0xffffffff80
   113c7:	test   rcx,rcx
   113ca:	je     11737 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x3a7>
   113d0:	lea    rsi,[rax+0x7f]
   113d4:	movabs rdi,0x200a60000000000
   113de:	mov    r13,rsi
   113e1:	jmp    113fc <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x6c>
   113e3:	data16 data16 data16 nop WORD PTR cs:[rax+rax*1+0x0]
   113f0:	mov    r9,r11
   113f3:	dec    rcx
   113f6:	je     11737 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x3a7>
   113fc:	mov    rax,r9
   113ff:	shr    rax,0x28
   11403:	movzx  eax,ax
   11406:	cmp    eax,0xa4
   1140b:	je     113f0 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x60>
   1140d:	cmp    eax,0xa5
   11412:	jne    121b2 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xe22>
   11418:	mov    rdx,r9
   1141b:	and    rdx,rsi
   1141e:	test   r9,r9
   11421:	js     11445 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb5>
   11423:	mov    r9,QWORD PTR [r14+rdx*8]
   11427:	mov    ebp,DWORD PTR [r14+rdx*8+0x8]
   1142c:	mov    r10,QWORD PTR [r14+rdx*8+0x10]
   11431:	mov    rax,rdx
   11434:	cmp    rax,0x3108180
   1143a:	jae    114c6 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x136>
   11440:	jmp    114fd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x16d>
   11445:	mov    eax,DWORD PTR [r14+rdx*8+0x4]
   1144a:	mov    esi,DWORD PTR [r14+rdx*8]
   1144e:	mov    edi,esi
   11450:	and    edi,0xffffff
   11456:	cmp    edi,0x1
   11459:	jne    116a7 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x317>
   1145f:	mov    edi,DWORD PTR [r14+rdx*8]
   11463:	shl    rax,0x20
   11467:	or     rax,rsi
   1146a:	shr    rax,0x18
   1146e:	mov    r9,QWORD PTR [r14+rax*8]
   11472:	mov    ebp,DWORD PTR [r14+rax*8+0x8]
   11477:	mov    r10,QWORD PTR [r14+rax*8+0x10]
   1147c:	mov    rsi,QWORD PTR [rbx]
   1147f:	mov    QWORD PTR [r14+rdx*8],rsi
   11483:	mov    QWORD PTR [rbx],rdx
   11486:	mov    rdx,QWORD PTR [rbx+0x100]
   1148d:	inc    rdx
   11490:	mov    QWORD PTR [rbx+0x100],rdx
   11497:	cmp    BYTE PTR [rip+0x1068f2],0x1        # 117d90 <KEEP_WORDS>
   1149e:	jne    11702 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x372>
   114a4:	cmp    rdx,0x8000
   114ab:	jae    11702 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x372>
   114b1:	mov    rsi,r13
   114b4:	movabs rdi,0x200a60000000000
   114be:	cmp    rax,0x3108180
   114c4:	jb     114fd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x16d>
   114c6:	mov    rdx,QWORD PTR [rbx+0x10]
   114ca:	mov    QWORD PTR [r14+rax*8],rdx
   114ce:	mov    QWORD PTR [rbx+0x10],rax
   114d2:	mov    rax,QWORD PTR [rbx+0x110]
   114d9:	add    rax,0x4
   114dd:	mov    QWORD PTR [rbx+0x110],rax
   114e4:	cmp    BYTE PTR [rip+0x1068a5],0x1        # 117d90 <KEEP_WORDS>
   114eb:	jne    1167b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x2eb>
   114f1:	cmp    rax,0x8000
   114f7:	jae    1167b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x2eb>
   114fd:	mov    r12,QWORD PTR [rbx+0x10]
   11501:	cmp    r8d,ebp
   11504:	jae    11550 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x1c0>
   11506:	test   r12,r12
   11509:	je     115c5 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x235>
   1150f:	mov    rax,QWORD PTR [r14+r12*8]
   11513:	mov    QWORD PTR [rbx+0x10],rax
   11517:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   1151f:	mov    QWORD PTR [r14+r12*8],rbp
   11523:	mov    QWORD PTR [r14+r12*8+0x8],r10
   11528:	mov    QWORD PTR [r14+r12*8+0x10],0x1
   11531:	mov    rax,QWORD PTR [rbx+0x8]
   11535:	test   rax,rax
   11538:	je     115f4 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x264>
   1153e:	mov    rdx,QWORD PTR [r14+rax*8]
   11542:	mov    QWORD PTR [rbx+0x8],rdx
   11546:	add    QWORD PTR [rbx+0x108],0xfffffffffffffffe
   1154e:	jmp    1159b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x20b>
   11550:	test   r12,r12
   11553:	je     11620 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x290>
   11559:	mov    rax,QWORD PTR [r14+r12*8]
   1155d:	mov    QWORD PTR [rbx+0x10],rax
   11561:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   11569:	mov    QWORD PTR [r14+r12*8],rbp
   1156d:	mov    QWORD PTR [r14+r12*8+0x8],r9
   11572:	mov    QWORD PTR [r14+r12*8+0x10],0x0
   1157b:	mov    rax,QWORD PTR [rbx+0x8]
   1157f:	test   rax,rax
   11582:	je     1164f <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x2bf>
   11588:	mov    rdx,QWORD PTR [r14+rax*8]
   1158c:	mov    QWORD PTR [rbx+0x8],rdx
   11590:	add    QWORD PTR [rbx+0x108],0xfffffffffffffffe
   11598:	mov    r9,r10
   1159b:	or     r12,rdi
   1159e:	mov    QWORD PTR [r14+rax*8],r12
   115a2:	mov    QWORD PTR [r14+rax*8+0x8],r15
   115a7:	movabs rdx,0x200120000000000
   115b1:	or     rax,rdx
   115b4:	mov    r15,rax
   115b7:	dec    rcx
   115ba:	jne    113fc <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x6c>
   115c0:	jmp    11737 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x3a7>
   115c5:	mov    rdi,r14
   115c8:	mov    rsi,rbx
   115cb:	mov    edx,0x2
   115d0:	call   13ff8 <heap_alloc_miss>
   115d5:	movabs rdi,0x200a60000000000
   115df:	mov    rsi,r13
   115e2:	movabs r11,0x100a40000000000
   115ec:	mov    r12,rax
   115ef:	jmp    1151f <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x18f>
   115f4:	mov    rdi,r14
   115f7:	mov    rsi,rbx
   115fa:	mov    edx,0x1
   115ff:	call   13ff8 <heap_alloc_miss>
   11604:	movabs rdi,0x200a60000000000
   1160e:	mov    rsi,r13
   11611:	movabs r11,0x100a40000000000
   1161b:	jmp    1159b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x20b>
   11620:	mov    rdi,r14
   11623:	mov    rsi,rbx
   11626:	mov    edx,0x2
   1162b:	call   13ff8 <heap_alloc_miss>
   11630:	movabs rdi,0x200a60000000000
   1163a:	mov    rsi,r13
   1163d:	movabs r11,0x100a40000000000
   11647:	mov    r12,rax
   1164a:	jmp    11569 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x1d9>
   1164f:	mov    rdi,r14
   11652:	mov    rsi,rbx
   11655:	mov    edx,0x1
   1165a:	call   13ff8 <heap_alloc_miss>
   1165f:	movabs rdi,0x200a60000000000
   11669:	mov    rsi,r13
   1166c:	movabs r11,0x100a40000000000
   11676:	jmp    11598 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x208>
   1167b:	mov    rdi,r14
   1167e:	mov    rsi,rbx
   11681:	mov    edx,0x2
   11686:	call   13ed1 <heap_hand>
   1168b:	movabs rdi,0x200a60000000000
   11695:	mov    rsi,r13
   11698:	movabs r11,0x100a40000000000
   116a2:	jmp    114fd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x16d>
   116a7:	shl    rax,0x20
   116ab:	or     rax,rsi
   116ae:	shr    rax,0x18
   116b2:	mov    r12,QWORD PTR [r14+rax*8]
   116b6:	mov    ebp,DWORD PTR [r14+rax*8+0x8]
   116bb:	mov    r10,QWORD PTR [r14+rax*8+0x10]
   116c0:	mov    rdi,r14
   116c3:	mov    rsi,rbx
   116c6:	mov    rdx,r9
   116c9:	mov    r9,rcx
   116cc:	mov    rcx,rax
   116cf:	mov    eax,r8d
   116d2:	mov    r8d,0x3
   116d8:	call   13f62 <span_fade>
   116dd:	movabs r11,0x100a40000000000
   116e7:	mov    rcx,r9
   116ea:	mov    r8d,eax
   116ed:	mov    r9,r12
   116f0:	mov    rsi,r13
   116f3:	movabs rdi,0x200a60000000000
   116fd:	jmp    114fd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x16d>
   11702:	mov    rdi,r14
   11705:	mov    rsi,rbx
   11708:	xor    edx,edx
   1170a:	call   13ed1 <heap_hand>
   1170f:	movabs r11,0x100a40000000000
   11719:	mov    rsi,r13
   1171c:	movabs rdi,0x200a60000000000
   11726:	cmp    rax,0x3108180
   1172c:	jb     114fd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x16d>
   11732:	jmp    114c6 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x136>
   11737:	mov    rax,r9
   1173a:	shr    rax,0x28
   1173e:	movzx  eax,ax
   11741:	cmp    eax,0xa5
   11746:	je     11b6b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x7db>
   1174c:	cmp    eax,0xa4
   11751:	jne    121b2 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xe22>
   11757:	mov    ecx,r8d
   1175a:	mov    rax,QWORD PTR [rbx+0x10]
   1175e:	test   rax,rax
   11761:	je     12062 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xcd2>
   11767:	mov    rdx,QWORD PTR [r14+rax*8]
   1176b:	mov    QWORD PTR [rbx+0x10],rdx
   1176f:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   11777:	movabs r8,0x200a50000000000
   11781:	movabs r11,0xffff0000000000
   1178b:	movabs rdx,0x100a40000000000
   11795:	mov    QWORD PTR [r14+rax*8],rdx
   11799:	mov    QWORD PTR [r14+rax*8+0x8],rcx
   1179e:	mov    QWORD PTR [r14+rax*8+0x10],rdx
   117a3:	movabs rcx,0xffffffff80
   117ad:	lea    rdi,[rcx+0x7f]
   117b1:	mov    QWORD PTR [rsp+0x8],rdi
   117b6:	jmp    117ed <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x45d>
   117b8:	nop    DWORD PTR [rax+rax*1+0x0]
   117c0:	test   rax,rax
   117c3:	je     119f6 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x666>
   117c9:	mov    rcx,QWORD PTR [r14+rax*8]
   117cd:	mov    QWORD PTR [rbx+0x10],rcx
   117d1:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   117d9:	mov    rcx,rbp
   117dc:	mov    rbp,r12
   117df:	mov    QWORD PTR [r14+rax*8],rcx
   117e3:	mov    QWORD PTR [r14+rax*8+0x8],r10
   117e8:	mov    QWORD PTR [r14+rax*8+0x10],rbp
   117ed:	mov    r12,rax
   117f0:	or     r12,r8
   117f3:	mov    rcx,r15
   117f6:	shr    rcx,0x28
   117fa:	cmp    cx,0x12
   117fe:	jne    12025 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xc95>
   11804:	mov    rdx,r15
   11807:	and    rdx,rdi
   1180a:	test   r15,r15
   1180d:	js     11830 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x4a0>
   1180f:	mov    r9,QWORD PTR [r14+rdx*8]
   11813:	mov    r15,QWORD PTR [r14+rdx*8+0x8]
   11818:	mov    rcx,rdx
   1181b:	cmp    rcx,0x3108180
   11822:	jae    118a5 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x515>
   11828:	jmp    118dd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x54d>
   1182d:	nop    DWORD PTR [rax]
   11830:	mov    ecx,DWORD PTR [r14+rdx*8+0x4]
   11835:	mov    esi,DWORD PTR [r14+rdx*8]
   11839:	mov    edi,esi
   1183b:	and    edi,0xffffff
   11841:	cmp    edi,0x1
   11844:	jne    11a83 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x6f3>
   1184a:	mov    edi,DWORD PTR [r14+rdx*8]
   1184e:	shl    rcx,0x20
   11852:	or     rcx,rsi
   11855:	shr    rcx,0x18
   11859:	mov    r9,QWORD PTR [r14+rcx*8]
   1185d:	mov    r15,QWORD PTR [r14+rcx*8+0x8]
   11862:	mov    rsi,QWORD PTR [rbx]
   11865:	mov    QWORD PTR [r14+rdx*8],rsi
   11869:	mov    QWORD PTR [rbx],rdx
   1186c:	mov    rdx,QWORD PTR [rbx+0x100]
   11873:	inc    rdx
   11876:	mov    QWORD PTR [rbx+0x100],rdx
   1187d:	cmp    BYTE PTR [rip+0x10650c],0x1        # 117d90 <KEEP_WORDS>
   11884:	jne    11b0f <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x77f>
   1188a:	cmp    rdx,0x8000
   11891:	jae    11b0f <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x77f>
   11897:	mov    rdi,QWORD PTR [rsp+0x8]
   1189c:	cmp    rcx,0x3108180
   118a3:	jb     118dd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x54d>
   118a5:	mov    rdx,QWORD PTR [rbx+0x8]
   118a9:	mov    QWORD PTR [r14+rcx*8],rdx
   118ad:	mov    QWORD PTR [rbx+0x8],rcx
   118b1:	mov    rcx,QWORD PTR [rbx+0x108]
   118b8:	add    rcx,0x2
   118bc:	mov    QWORD PTR [rbx+0x108],rcx
   118c3:	cmp    BYTE PTR [rip+0x1064c6],0x1        # 117d90 <KEEP_WORDS>
   118ca:	jne    11a3b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x6ab>
   118d0:	cmp    rcx,0x8000
   118d7:	jae    11a3b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x6ab>
   118dd:	mov    rcx,r9
   118e0:	and    rcx,r11
   118e3:	movabs rdx,0xa60000000000
   118ed:	cmp    rcx,rdx
   118f0:	jne    120f5 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xd65>
   118f6:	mov    rax,r9
   118f9:	and    rax,rdi
   118fc:	test   r9,r9
   118ff:	js     11920 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x590>
   11901:	mov    r10d,DWORD PTR [r14+rax*8]
   11905:	mov    rbp,QWORD PTR [r14+rax*8+0x8]
   1190a:	mov    r13d,DWORD PTR [r14+rax*8+0x10]
   1190f:	mov    rcx,rax
   11912:	cmp    rcx,0x3108180
   11919:	jae    11994 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x604>
   1191b:	jmp    119cb <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x63b>
   11920:	mov    ecx,DWORD PTR [r14+rax*8+0x4]
   11925:	mov    edx,DWORD PTR [r14+rax*8]
   11929:	mov    esi,edx
   1192b:	and    esi,0xffffff
   11931:	cmp    esi,0x1
   11934:	jne    11ac8 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x738>
   1193a:	mov    esi,DWORD PTR [r14+rax*8]
   1193e:	shl    rcx,0x20
   11942:	or     rcx,rdx
   11945:	shr    rcx,0x18
   11949:	mov    r10d,DWORD PTR [r14+rcx*8]
   1194d:	mov    rbp,QWORD PTR [r14+rcx*8+0x8]
   11952:	mov    r13d,DWORD PTR [r14+rcx*8+0x10]
   11957:	mov    rdx,QWORD PTR [rbx]
   1195a:	mov    QWORD PTR [r14+rax*8],rdx
   1195e:	mov    QWORD PTR [rbx],rax
   11961:	mov    rax,QWORD PTR [rbx+0x100]
   11968:	inc    rax
   1196b:	mov    QWORD PTR [rbx+0x100],rax
   11972:	cmp    BYTE PTR [rip+0x106417],0x1        # 117d90 <KEEP_WORDS>
   11979:	jne    11b3d <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x7ad>
   1197f:	cmp    rax,0x8000
   11985:	jae    11b3d <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x7ad>
   1198b:	cmp    rcx,0x3108180
   11992:	jb     119cb <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x63b>
   11994:	mov    rax,QWORD PTR [rbx+0x10]
   11998:	mov    QWORD PTR [r14+rcx*8],rax
   1199c:	mov    QWORD PTR [rbx+0x10],rcx
   119a0:	mov    rax,QWORD PTR [rbx+0x110]
   119a7:	add    rax,0x4
   119ab:	mov    QWORD PTR [rbx+0x110],rax
   119b2:	cmp    BYTE PTR [rip+0x1063d7],0x1        # 117d90 <KEEP_WORDS>
   119b9:	jne    11a5f <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x6cf>
   119bf:	cmp    rax,0x8000
   119c5:	jae    11a5f <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x6cf>
   119cb:	mov    rax,QWORD PTR [rbx+0x10]
   119cf:	cmp    r13d,0x1
   119d3:	jne    117c0 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x430>
   119d9:	test   rax,rax
   119dc:	je     11a1a <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x68a>
   119de:	mov    rcx,QWORD PTR [r14+rax*8]
   119e2:	mov    QWORD PTR [rbx+0x10],rcx
   119e6:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   119ee:	mov    rcx,r12
   119f1:	jmp    117df <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x44f>
   119f6:	mov    rdi,r14
   119f9:	mov    rsi,rbx
   119fc:	mov    edx,0x2
   11a01:	call   13ff8 <heap_alloc_miss>
   11a06:	mov    rdi,QWORD PTR [rsp+0x8]
   11a0b:	movabs r11,0xffff0000000000
   11a15:	jmp    117d9 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x449>
   11a1a:	mov    rdi,r14
   11a1d:	mov    rsi,rbx
   11a20:	mov    edx,0x2
   11a25:	call   13ff8 <heap_alloc_miss>
   11a2a:	mov    rdi,QWORD PTR [rsp+0x8]
   11a2f:	movabs r11,0xffff0000000000
   11a39:	jmp    119ee <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x65e>
   11a3b:	mov    rdi,r14
   11a3e:	mov    rsi,rbx
   11a41:	mov    edx,0x1
   11a46:	call   13ed1 <heap_hand>
   11a4b:	mov    rdi,QWORD PTR [rsp+0x8]
   11a50:	movabs r11,0xffff0000000000
   11a5a:	jmp    118dd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x54d>
   11a5f:	mov    rdi,r14
   11a62:	mov    rsi,rbx
   11a65:	mov    edx,0x2
   11a6a:	call   13ed1 <heap_hand>
   11a6f:	mov    rdi,QWORD PTR [rsp+0x8]
   11a74:	movabs r11,0xffff0000000000
   11a7e:	jmp    119cb <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x63b>
   11a83:	shl    rcx,0x20
   11a87:	or     rcx,rsi
   11a8a:	shr    rcx,0x18
   11a8e:	mov    r9,QWORD PTR [r14+rcx*8]
   11a92:	mov    r10,QWORD PTR [r14+rcx*8+0x8]
   11a97:	mov    rdi,r14
   11a9a:	mov    rsi,rbx
   11a9d:	mov    rdx,r15
   11aa0:	mov    r15,r8
   11aa3:	mov    r8d,0x2
   11aa9:	call   13f62 <span_fade>
   11aae:	movabs r11,0xffff0000000000
   11ab8:	mov    r8,r15
   11abb:	mov    r15,r10
   11abe:	mov    rdi,QWORD PTR [rsp+0x8]
   11ac3:	jmp    118dd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x54d>
   11ac8:	shl    rcx,0x20
   11acc:	or     rcx,rdx
   11acf:	shr    rcx,0x18
   11ad3:	mov    r10d,DWORD PTR [r14+rcx*8]
   11ad7:	mov    rbp,QWORD PTR [r14+rcx*8+0x8]
   11adc:	mov    r13d,DWORD PTR [r14+rcx*8+0x10]
   11ae1:	mov    rdi,r14
   11ae4:	mov    rsi,rbx
   11ae7:	mov    rdx,r9
   11aea:	mov    rax,r8
   11aed:	mov    r8d,0x3
   11af3:	call   13f62 <span_fade>
   11af8:	mov    rdi,QWORD PTR [rsp+0x8]
   11afd:	movabs r11,0xffff0000000000
   11b07:	mov    r8,rax
   11b0a:	jmp    119cb <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x63b>
   11b0f:	mov    rdi,r14
   11b12:	mov    rsi,rbx
   11b15:	xor    edx,edx
   11b17:	call   13ed1 <heap_hand>
   11b1c:	movabs r11,0xffff0000000000
   11b26:	mov    rdi,QWORD PTR [rsp+0x8]
   11b2b:	cmp    rcx,0x3108180
   11b32:	jae    118a5 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x515>
   11b38:	jmp    118dd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x54d>
   11b3d:	mov    rdi,r14
   11b40:	mov    rsi,rbx
   11b43:	xor    edx,edx
   11b45:	call   13ed1 <heap_hand>
   11b4a:	mov    rdi,QWORD PTR [rsp+0x8]
   11b4f:	movabs r11,0xffff0000000000
   11b59:	cmp    rcx,0x3108180
   11b60:	jae    11994 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x604>
   11b66:	jmp    119cb <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x63b>
   11b6b:	movabs rax,0xffffffff80
   11b75:	lea    r8,[rax+0x7f]
   11b79:	mov    rax,r9
   11b7c:	and    rax,r8
   11b7f:	test   r9,r9
   11b82:	js     11ba3 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x813>
   11b84:	mov    r10,QWORD PTR [r14+rax*8]
   11b88:	mov    r12d,DWORD PTR [r14+rax*8+0x8]
   11b8d:	mov    r13,QWORD PTR [r14+rax*8+0x10]
   11b92:	mov    rcx,rax
   11b95:	cmp    rcx,0x3108180
   11b9c:	jae    11c17 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x887>
   11b9e:	jmp    11c4e <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x8be>
   11ba3:	mov    ecx,DWORD PTR [r14+rax*8+0x4]
   11ba8:	mov    edx,DWORD PTR [r14+rax*8]
   11bac:	mov    esi,edx
   11bae:	and    esi,0xffffff
   11bb4:	cmp    esi,0x1
   11bb7:	jne    1208c <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xcfc>
   11bbd:	mov    esi,DWORD PTR [r14+rax*8]
   11bc1:	shl    rcx,0x20
   11bc5:	or     rcx,rdx
   11bc8:	shr    rcx,0x18
   11bcc:	mov    r10,QWORD PTR [r14+rcx*8]
   11bd0:	mov    r12d,DWORD PTR [r14+rcx*8+0x8]
   11bd5:	mov    r13,QWORD PTR [r14+rcx*8+0x10]
   11bda:	mov    rdx,QWORD PTR [rbx]
   11bdd:	mov    QWORD PTR [r14+rax*8],rdx
   11be1:	mov    QWORD PTR [rbx],rax
   11be4:	mov    rax,QWORD PTR [rbx+0x100]
   11beb:	inc    rax
   11bee:	mov    QWORD PTR [rbx+0x100],rax
   11bf5:	cmp    BYTE PTR [rip+0x106194],0x1        # 117d90 <KEEP_WORDS>
   11bfc:	jne    120c4 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xd34>
   11c02:	cmp    rax,0x8000
   11c08:	jae    120c4 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xd34>
   11c0e:	cmp    rcx,0x3108180
   11c15:	jb     11c4e <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x8be>
   11c17:	mov    rax,QWORD PTR [rbx+0x10]
   11c1b:	mov    QWORD PTR [r14+rcx*8],rax
   11c1f:	mov    QWORD PTR [rbx+0x10],rcx
   11c23:	mov    rax,QWORD PTR [rbx+0x110]
   11c2a:	add    rax,0x4
   11c2e:	mov    QWORD PTR [rbx+0x110],rax
   11c35:	cmp    BYTE PTR [rip+0x106154],0x1        # 117d90 <KEEP_WORDS>
   11c3c:	jne    12077 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xce7>
   11c42:	cmp    rax,0x8000
   11c48:	jae    12077 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xce7>
   11c4e:	mov    rax,QWORD PTR [rbx+0x10]
   11c52:	test   rax,rax
   11c55:	je     1204d <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xcbd>
   11c5b:	mov    rcx,QWORD PTR [r14+rax*8]
   11c5f:	mov    QWORD PTR [rbx+0x10],rcx
   11c63:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   11c6b:	movabs r11,0x200a50000000000
   11c75:	mov    QWORD PTR [r14+rax*8],r10
   11c79:	mov    QWORD PTR [r14+rax*8+0x8],r12
   11c7e:	mov    QWORD PTR [r14+rax*8+0x10],r13
   11c83:	jmp    11cba <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x92a>
   11c85:	data16 nop WORD PTR cs:[rax+rax*1+0x0]
   11c90:	test   rax,rax
   11c93:	je     11ed8 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb48>
   11c99:	mov    rcx,QWORD PTR [r14+rax*8]
   11c9d:	mov    QWORD PTR [rbx+0x10],rcx
   11ca1:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   11ca9:	mov    rcx,r12
   11cac:	mov    QWORD PTR [r14+rax*8],rcx
   11cb0:	mov    QWORD PTR [r14+rax*8+0x8],r13
   11cb5:	mov    QWORD PTR [r14+rax*8+0x10],r10
   11cba:	mov    r12,rax
   11cbd:	or     r12,r11
   11cc0:	mov    rcx,r15
   11cc3:	shr    rcx,0x28
   11cc7:	cmp    cx,0x12
   11ccb:	jne    12025 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xc95>
   11cd1:	mov    rdx,r15
   11cd4:	and    rdx,r8
   11cd7:	test   r15,r15
   11cda:	js     11d00 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x970>
   11cdc:	mov    r9,QWORD PTR [r14+rdx*8]
   11ce0:	mov    r15,QWORD PTR [r14+rdx*8+0x8]
   11ce5:	mov    rcx,rdx
   11ce8:	cmp    rcx,0x3108180
   11cef:	jae    11d70 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x9e0>
   11cf1:	jmp    11da8 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xa18>
   11cf6:	nop    WORD PTR cs:[rax+rax*1+0x0]
   11d00:	mov    ecx,DWORD PTR [r14+rdx*8+0x4]
   11d05:	mov    esi,DWORD PTR [r14+rdx*8]
   11d09:	mov    edi,esi
   11d0b:	and    edi,0xffffff
   11d11:	cmp    edi,0x1
   11d14:	jne    11f51 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xbc1>
   11d1a:	mov    edi,DWORD PTR [r14+rdx*8]
   11d1e:	shl    rcx,0x20
   11d22:	or     rcx,rsi
   11d25:	shr    rcx,0x18
   11d29:	mov    r9,QWORD PTR [r14+rcx*8]
   11d2d:	mov    r15,QWORD PTR [r14+rcx*8+0x8]
   11d32:	mov    rsi,QWORD PTR [rbx]
   11d35:	mov    QWORD PTR [r14+rdx*8],rsi
   11d39:	mov    QWORD PTR [rbx],rdx
   11d3c:	mov    rdx,QWORD PTR [rbx+0x100]
   11d43:	inc    rdx
   11d46:	mov    QWORD PTR [rbx+0x100],rdx
   11d4d:	cmp    BYTE PTR [rip+0x10603c],0x1        # 117d90 <KEEP_WORDS>
   11d54:	jne    11fd3 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xc43>
   11d5a:	cmp    rdx,0x8000
   11d61:	jae    11fd3 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xc43>
   11d67:	cmp    rcx,0x3108180
   11d6e:	jb     11da8 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xa18>
   11d70:	mov    rdx,QWORD PTR [rbx+0x8]
   11d74:	mov    QWORD PTR [r14+rcx*8],rdx
   11d78:	mov    QWORD PTR [rbx+0x8],rcx
   11d7c:	mov    rcx,QWORD PTR [rbx+0x108]
   11d83:	add    rcx,0x2
   11d87:	mov    QWORD PTR [rbx+0x108],rcx
   11d8e:	cmp    BYTE PTR [rip+0x105ffb],0x1        # 117d90 <KEEP_WORDS>
   11d95:	jne    11f13 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb83>
   11d9b:	cmp    rcx,0x8000
   11da2:	jae    11f13 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb83>
   11da8:	mov    rcx,r9
   11dab:	movabs rdx,0xffff0000000000
   11db5:	and    rcx,rdx
   11db8:	movabs rdx,0xa60000000000
   11dc2:	cmp    rcx,rdx
   11dc5:	jne    120f5 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xd65>
   11dcb:	mov    rax,r9
   11dce:	and    rax,r8
   11dd1:	test   r9,r9
   11dd4:	js     11e00 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xa70>
   11dd6:	mov    r13d,DWORD PTR [r14+rax*8]
   11dda:	mov    r10,QWORD PTR [r14+rax*8+0x8]
   11ddf:	mov    ebp,DWORD PTR [r14+rax*8+0x10]
   11de4:	mov    rcx,rax
   11de7:	cmp    rcx,0x3108180
   11dee:	jae    11e74 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xae4>
   11df4:	jmp    11eab <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb1b>
   11df9:	nop    DWORD PTR [rax+0x0]
   11e00:	mov    ecx,DWORD PTR [r14+rax*8+0x4]
   11e05:	mov    edx,DWORD PTR [r14+rax*8]
   11e09:	mov    esi,edx
   11e0b:	and    esi,0xffffff
   11e11:	cmp    esi,0x1
   11e14:	jne    11f91 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xc01>
   11e1a:	mov    esi,DWORD PTR [r14+rax*8]
   11e1e:	shl    rcx,0x20
   11e22:	or     rcx,rdx
   11e25:	shr    rcx,0x18
   11e29:	mov    r13d,DWORD PTR [r14+rcx*8]
   11e2d:	mov    r10,QWORD PTR [r14+rcx*8+0x8]
   11e32:	mov    ebp,DWORD PTR [r14+rcx*8+0x10]
   11e37:	mov    rdx,QWORD PTR [rbx]
   11e3a:	mov    QWORD PTR [r14+rax*8],rdx
   11e3e:	mov    QWORD PTR [rbx],rax
   11e41:	mov    rax,QWORD PTR [rbx+0x100]
   11e48:	inc    rax
   11e4b:	mov    QWORD PTR [rbx+0x100],rax
   11e52:	cmp    BYTE PTR [rip+0x105f37],0x1        # 117d90 <KEEP_WORDS>
   11e59:	jne    11ffc <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xc6c>
   11e5f:	cmp    rax,0x8000
   11e65:	jae    11ffc <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xc6c>
   11e6b:	cmp    rcx,0x3108180
   11e72:	jb     11eab <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb1b>
   11e74:	mov    rax,QWORD PTR [rbx+0x10]
   11e78:	mov    QWORD PTR [r14+rcx*8],rax
   11e7c:	mov    QWORD PTR [rbx+0x10],rcx
   11e80:	mov    rax,QWORD PTR [rbx+0x110]
   11e87:	add    rax,0x4
   11e8b:	mov    QWORD PTR [rbx+0x110],rax
   11e92:	cmp    BYTE PTR [rip+0x105ef7],0x1        # 117d90 <KEEP_WORDS>
   11e99:	jne    11f32 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xba2>
   11e9f:	cmp    rax,0x8000
   11ea5:	jae    11f32 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xba2>
   11eab:	mov    rax,QWORD PTR [rbx+0x10]
   11eaf:	cmp    ebp,0x1
   11eb2:	je     11c90 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x900>
   11eb8:	test   rax,rax
   11ebb:	je     11ef7 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb67>
   11ebd:	mov    rcx,QWORD PTR [r14+rax*8]
   11ec1:	mov    QWORD PTR [rbx+0x10],rcx
   11ec5:	add    QWORD PTR [rbx+0x110],0xfffffffffffffffc
   11ecd:	mov    rcx,r10
   11ed0:	mov    r10,r12
   11ed3:	jmp    11cac <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x91c>
   11ed8:	mov    rdi,r14
   11edb:	mov    rsi,rbx
   11ede:	mov    edx,0x2
   11ee3:	call   13ff8 <heap_alloc_miss>
   11ee8:	movabs r11,0x200a50000000000
   11ef2:	jmp    11ca9 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x919>
   11ef7:	mov    rdi,r14
   11efa:	mov    rsi,rbx
   11efd:	mov    edx,0x2
   11f02:	call   13ff8 <heap_alloc_miss>
   11f07:	movabs r11,0x200a50000000000
   11f11:	jmp    11ecd <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb3d>
   11f13:	mov    rdi,r14
   11f16:	mov    rsi,rbx
   11f19:	mov    edx,0x1
   11f1e:	call   13ed1 <heap_hand>
   11f23:	movabs r11,0x200a50000000000
   11f2d:	jmp    11da8 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xa18>
   11f32:	mov    rdi,r14
   11f35:	mov    rsi,rbx
   11f38:	mov    edx,0x2
   11f3d:	call   13ed1 <heap_hand>
   11f42:	movabs r11,0x200a50000000000
   11f4c:	jmp    11eab <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb1b>
   11f51:	shl    rcx,0x20
   11f55:	or     rcx,rsi
   11f58:	shr    rcx,0x18
   11f5c:	mov    r9,QWORD PTR [r14+rcx*8]
   11f60:	mov    r10,QWORD PTR [r14+rcx*8+0x8]
   11f65:	mov    rdi,r14
   11f68:	mov    rsi,rbx
   11f6b:	mov    rdx,r15
   11f6e:	mov    r15,r8
   11f71:	mov    r8d,0x2
   11f77:	call   13f62 <span_fade>
   11f7c:	movabs r11,0x200a50000000000
   11f86:	mov    r8,r15
   11f89:	mov    r15,r10
   11f8c:	jmp    11da8 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xa18>
   11f91:	shl    rcx,0x20
   11f95:	or     rcx,rdx
   11f98:	shr    rcx,0x18
   11f9c:	mov    r13d,DWORD PTR [r14+rcx*8]
   11fa0:	mov    r10,QWORD PTR [r14+rcx*8+0x8]
   11fa5:	mov    ebp,DWORD PTR [r14+rcx*8+0x10]
   11faa:	mov    rdi,r14
   11fad:	mov    rsi,rbx
   11fb0:	mov    rdx,r9
   11fb3:	mov    rax,r8
   11fb6:	mov    r8d,0x3
   11fbc:	call   13f62 <span_fade>
   11fc1:	movabs r11,0x200a50000000000
   11fcb:	mov    r8,rax
   11fce:	jmp    11eab <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb1b>
   11fd3:	mov    rdi,r14
   11fd6:	mov    rsi,rbx
   11fd9:	xor    edx,edx
   11fdb:	call   13ed1 <heap_hand>
   11fe0:	movabs r11,0x200a50000000000
   11fea:	cmp    rcx,0x3108180
   11ff1:	jae    11d70 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x9e0>
   11ff7:	jmp    11da8 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xa18>
   11ffc:	mov    rdi,r14
   11fff:	mov    rsi,rbx
   12002:	xor    edx,edx
   12004:	call   13ed1 <heap_hand>
   12009:	movabs r11,0x200a50000000000
   12013:	cmp    rcx,0x3108180
   1201a:	jae    11e74 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xae4>
   12020:	jmp    11eab <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xb1b>
   12025:	movzx  ecx,cx
   12028:	cmp    ecx,0x11
   1202b:	jne    120e3 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xd53>
   12031:	mov    rax,QWORD PTR [rsp+0x10]
   12036:	mov    QWORD PTR [rax],r12
   12039:	mov    eax,0x1
   1203e:	add    rsp,0x18
   12042:	pop    rbx
   12043:	pop    r12
   12045:	pop    r13
   12047:	pop    r14
   12049:	pop    r15
   1204b:	pop    rbp
   1204c:	ret    
   1204d:	mov    rdi,r14
   12050:	mov    rsi,rbx
   12053:	mov    edx,0x2
   12058:	call   13ff8 <heap_alloc_miss>
   1205d:	jmp    11c6b <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x8db>
   12062:	mov    rdi,r14
   12065:	mov    rsi,rbx
   12068:	mov    edx,0x2
   1206d:	call   13ff8 <heap_alloc_miss>
   12072:	jmp    11777 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x3e7>
   12077:	mov    rdi,r14
   1207a:	mov    rsi,rbx
   1207d:	mov    edx,0x2
   12082:	call   13ed1 <heap_hand>
   12087:	jmp    11c4e <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x8be>
   1208c:	shl    rcx,0x20
   12090:	or     rcx,rdx
   12093:	shr    rcx,0x18
   12097:	mov    r10,QWORD PTR [r14+rcx*8]
   1209b:	mov    r12d,DWORD PTR [r14+rcx*8+0x8]
   120a0:	mov    r13,QWORD PTR [r14+rcx*8+0x10]
   120a5:	mov    rdi,r14
   120a8:	mov    rsi,rbx
   120ab:	mov    rdx,r9
   120ae:	mov    rax,r8
   120b1:	mov    r8d,0x3
   120b7:	call   13f62 <span_fade>
   120bc:	mov    r8,rax
   120bf:	jmp    11c4e <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x8be>
   120c4:	mov    rdi,r14
   120c7:	mov    rsi,rbx
   120ca:	xor    edx,edx
   120cc:	call   13ed1 <heap_hand>
   120d1:	cmp    rcx,0x3108180
   120d8:	jae    11c17 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x887>
   120de:	jmp    11c4e <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0x8be>
   120e3:	mov    r13,rax
   120e6:	movabs rax,0x7e00000000000000
   120f0:	test   r15,rax
   120f3:	jmp    1213f <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xdaf>
   120f5:	mov    r13,rax
   120f8:	movabs rbp,0x7e00000000000000
   12102:	test   r9,rbp
   12105:	sete   al
   12108:	cmp    r9,0xffffffffffffffff
   1210c:	sete   cl
   1210f:	or     cl,al
   12111:	mov    rax,r9
   12114:	movabs rdx,0xffffffff80
   1211e:	and    rax,rdx
   12121:	cmp    rax,0x3108180
   12127:	setb   al
   1212a:	or     al,cl
   1212c:	jne    1213c <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xdac>
   1212e:	mov    rdi,r14
   12131:	mov    rsi,rbx
   12134:	mov    rdx,r9
   12137:	call   6de0 <term_drop>
   1213c:	test   r15,rbp
   1213f:	sete   al
   12142:	cmp    r15,0xffffffffffffffff
   12146:	sete   cl
   12149:	or     cl,al
   1214b:	mov    rax,r15
   1214e:	movabs rdx,0xffffffff80
   12158:	and    rax,rdx
   1215b:	cmp    rax,0x3108180
   12161:	setb   al
   12164:	or     al,cl
   12166:	jne    12176 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xde6>
   12168:	mov    rdi,r14
   1216b:	mov    rsi,rbx
   1216e:	mov    rdx,r15
   12171:	call   6de0 <term_drop>
   12176:	cmp    r12,0xffffffffffffffff
   1217a:	sete   al
   1217d:	movabs rcx,0xffffffff80
   12187:	and    r13,rcx
   1218a:	cmp    r13,0x3108180
   12191:	setb   cl
   12194:	or     cl,al
   12196:	jne    121a6 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xe16>
   12198:	mov    rdi,r14
   1219b:	mov    rsi,rbx
   1219e:	mov    rdx,r12
   121a1:	call   6de0 <term_drop>
   121a6:	lea    rdi,[rip+0xffffffffffff04e3]        # 2690 <FID_RESW_T+0x320>
   121ad:	call   13e70 <err_fail>
   121b2:	movabs r12,0x7e00000000000000
   121bc:	test   r9,r12
   121bf:	sete   al
   121c2:	cmp    r9,0xffffffffffffffff
   121c6:	sete   cl
   121c9:	or     cl,al
   121cb:	mov    rax,r9
   121ce:	movabs rdx,0xffffffff80
   121d8:	and    rax,rdx
   121db:	cmp    rax,0x3108180
   121e1:	setb   al
   121e4:	or     al,cl
   121e6:	jne    121f6 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xe66>
   121e8:	mov    rdi,r14
   121eb:	mov    rsi,rbx
   121ee:	mov    rdx,r9
   121f1:	call   6de0 <term_drop>
   121f6:	test   r15,r12
   121f9:	sete   al
   121fc:	cmp    r15,0xffffffffffffffff
   12200:	sete   cl
   12203:	or     cl,al
   12205:	movabs rax,0xffffffff80
   1220f:	and    rax,r15
   12212:	cmp    rax,0x3108180
   12218:	setb   al
   1221b:	or     al,cl
   1221d:	jne    121a6 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xe16>
   1221f:	mov    rdi,r14
   12222:	mov    rsi,rbx
   12225:	mov    rdx,r15
   12228:	jmp    121a1 <NF_FID_112_51_55_46_98_115_116_46_105_110_115_101_114_116_+0xe11>
   1222d:	nop    DWORD PTR [rax]

