  4108df:	lea    0x1201a(%rip),%rdx        # 422900 <p111_program>
  4108e6:	jmpq   417090 <p111_rt_main>
  4108eb:	nopl   0x0(%rax,%rax,1)
