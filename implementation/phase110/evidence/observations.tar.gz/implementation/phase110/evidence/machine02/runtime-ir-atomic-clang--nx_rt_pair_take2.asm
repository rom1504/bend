
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404560 <nx_rt_pair_take2>:
  404560:	movabs $0xffffffffff,%rax
  40456a:	push   %r15
  40456c:	and    %rsi,%rax
  40456f:	push   %r14
  404571:	push   %r13
  404573:	lea    0x0(,%rax,8),%rdx
  40457b:	push   %r12
  40457d:	push   %rbp
  40457e:	mov    (%rdi),%rbp
  404581:	mov    0x8(%rdi),%r14
  404585:	lea    0x0(%rbp,%rdx,1),%rcx
  40458a:	test   %rsi,%rsi
  40458d:	js     4045f0 <nx_rt_pair_take2+0x90>
  40458f:	mov    (%rcx),%r13
  404592:	mov    0x8(%rbp,%rdx,1),%r12
  404597:	cmp    $0x310817f,%rax
  40459d:	ja     4045b0 <nx_rt_pair_take2+0x50>
  40459f:	pop    %rbp
  4045a0:	mov    %r13,%rax
  4045a3:	mov    %r12,%rdx
  4045a6:	pop    %r12
  4045a8:	pop    %r13
  4045aa:	pop    %r14
  4045ac:	pop    %r15
  4045ae:	retq   
  4045af:	nop
  4045b0:	mov    0x8(%r14),%rdx
  4045b4:	mov    %rdx,0x0(%rbp,%rax,8)
  4045b9:	mov    0x3dc19(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4045bf:	mov    %rax,0x8(%r14)
  4045c3:	mov    0x108(%r14),%rax
  4045ca:	add    $0x2,%rax
  4045ce:	mov    %rax,0x108(%r14)
  4045d5:	cmp    %rdx,%rax
  4045d8:	jae    401be0 <nx_rt_pair_take2.cold>
  4045de:	pop    %rbp
  4045df:	mov    %r13,%rax
  4045e2:	mov    %r12,%rdx
  4045e5:	pop    %r12
  4045e7:	pop    %r13
  4045e9:	pop    %r14
  4045eb:	pop    %r15
  4045ed:	retq   
  4045ee:	xchg   %ax,%ax
  4045f0:	mov    0x4(%rcx),%edx
  4045f3:	mov    (%rcx),%edi
  4045f5:	shl    $0x20,%rdx
  4045f9:	or     %rdi,%rdx
  4045fc:	mov    %rdx,%r15
  4045ff:	and    $0xffffff,%edx
  404605:	shr    $0x18,%r15
  404609:	lea    0x8(,%r15,8),%rdi
  404611:	lea    0x0(%rbp,%rdi,1),%r8
  404616:	cmp    $0x1,%rdx
  40461a:	jne    401c07 <nx_rt_pair_take2.cold+0x27>
  404620:	mov    (%rcx),%edx
  404622:	mov    (%r14),%rdx
  404625:	mov    -0x8(%rbp,%rdi,1),%r13
  40462a:	mov    (%r8),%r12
  40462d:	mov    %rdx,(%rcx)
  404630:	mov    0x3dba2(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404636:	mov    %rax,(%r14)
  404639:	mov    0x100(%r14),%rax
  404640:	add    $0x1,%rax
  404644:	mov    %rax,0x100(%r14)
  40464b:	cmp    %rdx,%rax
  40464e:	jae    401bf5 <nx_rt_pair_take2.cold+0x15>
  404654:	mov    %r15,%rax
  404657:	jmpq   404597 <nx_rt_pair_take2+0x37>

Disassembly of section .fini:
