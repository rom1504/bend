
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403110 <nx_rt_field>:
  403110:	endbr64 
  403114:	push   %rbp
  403115:	mov    %rsp,%rbp
  403118:	sub    $0x10,%rsp
  40311c:	push   %rbx
  40311d:	push   %r12
  40311f:	mov    %esi,%r12d
  403122:	mov    %rdi,%rbx
  403125:	callq  402900 <nx_env>
  40312a:	mov    %r12d,%esi
  40312d:	mov    %rax,%rcx
  403130:	mov    %rdx,%rax
  403133:	mov    %rcx,-0x10(%rbp)
  403137:	mov    %rax,-0x8(%rbp)
  40313b:	cmp    $0x2,%esi
  40313e:	jae    403150 <nx_rt_field+0x40>
  403140:	mov    0x20(%rbx),%eax
  403143:	mov    %esi,%ecx
  403145:	mov    $0x1,%edx
  40314a:	shl    %cl,%edx
  40314c:	test   %eax,%edx
  40314e:	jne    403157 <nx_rt_field+0x47>
  403150:	mov    $0x0,%edi
  403155:	jmp    40315c <nx_rt_field+0x4c>
  403157:	mov    $0x1,%edi
  40315c:	mov    %esi,%r12d
  40315f:	lea    0x5501(%rip),%rsi        # 408667 <ERR_TEXT+0x2df>
  403166:	callq  4028e0 <nx_require>
  40316b:	mov    %r12d,%esi
  40316e:	mov    %rbx,%rdi
  403171:	callq  4030e0 <nx_field>
  403176:	pop    %r12
  403178:	pop    %rbx
  403179:	leaveq 
  40317a:	retq   

Disassembly of section .fini:
