
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004030f0 <nx_rt_fast_take2>:
  4030f0:	movabs $0xffffffffff,%rax
  4030fa:	push   %r12
  4030fc:	and    %rsi,%rax
  4030ff:	push   %rbp
  403100:	push   %rbx
  403101:	mov    %rdi,%rbx
  403104:	mov    (%rdi),%rdi
  403107:	lea    0x0(,%rax,8),%rcx
  40310f:	mov    0x8(%rbx),%rbp
  403113:	lea    (%rdi,%rcx,1),%rdx
  403117:	test   %rsi,%rsi
  40311a:	js     403188 <nx_rt_fast_take2+0x98>
  40311c:	mov    (%rdx),%rdx
  40311f:	mov    %rdx,0x10(%rbx)
  403123:	mov    0x8(%rdi,%rcx,1),%rdx
  403128:	mov    %rdx,0x18(%rbx)
  40312c:	cmp    $0x310817f,%rax
  403132:	ja     403148 <nx_rt_fast_take2+0x58>
  403134:	movl   $0x3,0x20(%rbx)
  40313b:	xor    %eax,%eax
  40313d:	pop    %rbx
  40313e:	pop    %rbp
  40313f:	pop    %r12
  403141:	retq   
  403142:	nopw   0x0(%rax,%rax,1)
  403148:	mov    0x8(%rbp),%rdx
  40314c:	mov    %rdx,(%rdi,%rax,8)
  403150:	mov    0x3f082(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403156:	mov    %rax,0x8(%rbp)
  40315a:	mov    0x108(%rbp),%rax
  403161:	add    $0x2,%rax
  403165:	mov    %rax,0x108(%rbp)
  40316c:	cmp    %rdx,%rax
  40316f:	jae    4015fe <nx_rt_fast_take2.cold>
  403175:	movl   $0x3,0x20(%rbx)
  40317c:	xor    %eax,%eax
  40317e:	pop    %rbx
  40317f:	pop    %rbp
  403180:	pop    %r12
  403182:	retq   
  403183:	nopl   0x0(%rax,%rax,1)
  403188:	mov    0x4(%rdx),%ecx
  40318b:	mov    (%rdx),%r8d
  40318e:	shl    $0x20,%rcx
  403192:	or     %r8,%rcx
  403195:	mov    %rcx,%r12
  403198:	and    $0xffffff,%ecx
  40319e:	shr    $0x18,%r12
  4031a2:	lea    0x0(,%r12,8),%r8
  4031aa:	lea    (%rdi,%r8,1),%r9
  4031ae:	lea    0x8(%rdi,%r8,1),%r8
  4031b3:	cmp    $0x1,%rcx
  4031b7:	jne    40161f <nx_rt_fast_take2.cold+0x21>
  4031bd:	mov    (%rdx),%ecx
  4031bf:	mov    (%r9),%rcx
  4031c2:	mov    %rcx,0x10(%rbx)
  4031c6:	mov    (%r8),%rcx
  4031c9:	mov    %rcx,0x18(%rbx)
  4031cd:	mov    0x0(%rbp),%rcx
  4031d1:	mov    %rcx,(%rdx)
  4031d4:	mov    0x3effe(%rip),%edx        # 4421d8 <KEEP_WORDS>
  4031da:	mov    %rax,0x0(%rbp)
  4031de:	mov    0x100(%rbp),%rax
  4031e5:	add    $0x1,%rax
  4031e9:	mov    %rax,0x100(%rbp)
  4031f0:	cmp    %rdx,%rax
  4031f3:	jae    401610 <nx_rt_fast_take2.cold+0x12>
  4031f9:	mov    %r12,%rax
  4031fc:	jmpq   40312c <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
