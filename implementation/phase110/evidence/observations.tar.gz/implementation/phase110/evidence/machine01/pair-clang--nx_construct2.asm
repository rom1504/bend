
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401f70 <nx_construct2>:
  401f70:	push   %r12
  401f72:	mov    %rcx,%rax
  401f75:	push   %rbp
  401f76:	shr    $0x38,%rax
  401f7a:	lea    0x0(,%r9,8),%rbp
  401f82:	push   %rbx
  401f83:	and    $0x7f,%eax
  401f86:	mov    %edx,%ebx
  401f88:	lea    (%rdi,%rbp,1),%r12
  401f8c:	mov    %rcx,%rdx
  401f8f:	sub    $0x20,%rsp
  401f93:	cmp    $0x2,%rax
  401f97:	je     401fd0 <nx_construct2+0x60>
  401f99:	mov    %r8,%rax
  401f9c:	mov    %rdx,(%r12)
  401fa0:	lea    0x8(%rbp,%rdi,1),%rbp
  401fa5:	shr    $0x38,%rax
  401fa9:	and    $0x7f,%eax
  401fac:	cmp    $0x2,%rax
  401fb0:	je     401fe0 <nx_construct2+0x70>
  401fb2:	mov    %rbx,%rax
  401fb5:	mov    %r8,0x0(%rbp)
  401fb9:	add    $0x20,%rsp
  401fbd:	shl    $0x28,%rax
  401fc1:	pop    %rbx
  401fc2:	pop    %rbp
  401fc3:	or     %r9,%rax
  401fc6:	pop    %r12
  401fc8:	bts    $0x39,%rax
  401fcd:	retq   
  401fce:	xchg   %ax,%ax
  401fd0:	test   %rcx,%rcx
  401fd3:	js     401f99 <nx_construct2+0x29>
  401fd5:	jmpq   401410 <nx_construct2.cold>
  401fda:	nopw   0x0(%rax,%rax,1)
  401fe0:	test   %r8,%r8
  401fe3:	js     401fb2 <nx_construct2+0x42>
  401fe5:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
