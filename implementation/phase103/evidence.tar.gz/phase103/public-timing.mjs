import fs from 'node:fs';
import {spawnSync} from 'node:child_process';
import {createHash} from 'node:crypto';
import assert from 'node:assert/strict';
const root=process.cwd(),dir=root+'/selfhost/build/phase103/public-timing01';fs.mkdirSync(dir);
const source=root+'/selfhost/tools/performance/phase77/fixtures/small.bend';
const rows=[];for(let i=0;i<3;i++)for(const role of i%2?['new','old']:['old','new']){
 const dest=dir+'/'+role+i+'.c',args=role==='old'?['python3','-B','selfhost/native.py',source,'-o',dest]:[root+'/selfhost/build/phase103/cli06/bend',source,'-o',dest];
 const start=performance.now(),r=spawnSync(args[0],args.slice(1),{timeout:30000});assert(!r.error&&r.status===0);
 fs.writeFileSync(dir+'/'+role+i+'.stderr',r.stderr);rows.push({role,round:i,command:args,wallSeconds:(performance.now()-start)/1000,sha256:createHash('sha256').update(fs.readFileSync(dest)).digest('hex')});
}
assert(new Set(rows.map(r=>r.sha256)).size===1);fs.writeFileSync(dir+'/report.json',JSON.stringify({complete:true,scope:'Three balanced small-source complete public CLI pairs, not compiler-kernel benchmark.',source,rows},null,2)+'\n');console.log(JSON.stringify(rows.map(({role,wallSeconds})=>({role,wallSeconds}))));
