
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/pair-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403b20 <nx_rt_rebuild2_c3_k0>:
  403b20:	push   %r15
  403b22:	push   %r14
  403b24:	push   %r13
  403b26:	push   %r12
  403b28:	mov    %rdx,%r12
  403b2b:	push   %rbp
  403b2c:	mov    %rdi,%rbp
  403b2f:	push   %rbx
  403b30:	movabs $0xffffffffff,%rbx
  403b3a:	and    %rsi,%rbx
  403b3d:	lea    0x0(,%rbx,8),%rdx
  403b45:	sub    $0x18,%rsp
  403b49:	mov    (%rdi),%r13
  403b4c:	mov    0x8(%rdi),%r15
  403b50:	lea    0x0(%r13,%rdx,1),%rax
  403b55:	test   %rsi,%rsi
  403b58:	js     403c20 <nx_rt_rebuild2_c3_k0+0x100>
  403b5e:	mov    (%rax),%r14
  403b61:	mov    0x8(%r13,%rdx,1),%r9
  403b66:	cmp    $0x310817f,%rbx
  403b6d:	jbe    403bf8 <nx_rt_rebuild2_c3_k0+0xd8>
  403b73:	lea    0x0(%r13,%rbx,8),%r8
  403b78:	mov    %r14,%rax
  403b7b:	mov    %r9,0x10(%rbp)
  403b7f:	shr    $0x38,%rax
  403b83:	movq   $0xffffffffffffffff,0x18(%rbp)
  403b8b:	and    $0x7f,%eax
  403b8e:	movl   $0x1,0x20(%rbp)
  403b95:	cmp    $0x2,%rax
  403b99:	je     403bd8 <nx_rt_rebuild2_c3_k0+0xb8>
  403b9b:	mov    %r12,%rax
  403b9e:	mov    %r14,(%r8)
  403ba1:	lea    0x8(%r13,%rbx,8),%rbp
  403ba6:	shr    $0x38,%rax
  403baa:	and    $0x7f,%eax
  403bad:	cmp    $0x2,%rax
  403bb1:	je     403be8 <nx_rt_rebuild2_c3_k0+0xc8>
  403bb3:	movabs $0x200030000000000,%rax
  403bbd:	mov    %r12,0x0(%rbp)
  403bc1:	add    $0x18,%rsp
  403bc5:	or     %rbx,%rax
  403bc8:	pop    %rbx
  403bc9:	pop    %rbp
  403bca:	pop    %r12
  403bcc:	pop    %r13
  403bce:	pop    %r14
  403bd0:	pop    %r15
  403bd2:	retq   
  403bd3:	nopl   0x0(%rax,%rax,1)
  403bd8:	test   %r14,%r14
  403bdb:	js     403b9b <nx_rt_rebuild2_c3_k0+0x7b>
  403bdd:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  403be2:	nopw   0x0(%rax,%rax,1)
  403be8:	test   %r12,%r12
  403beb:	js     403bb3 <nx_rt_rebuild2_c3_k0+0x93>
  403bed:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  403bf2:	nopw   0x0(%rax,%rax,1)
  403bf8:	mov    0x8(%r15),%rbx
  403bfc:	test   %rbx,%rbx
  403bff:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  403c05:	lea    0x0(%r13,%rbx,8),%r8
  403c0a:	mov    (%r8),%rax
  403c0d:	subq   $0x2,0x108(%r15)
  403c15:	mov    %rax,0x8(%r15)
  403c19:	jmpq   403b78 <nx_rt_rebuild2_c3_k0+0x58>
  403c1e:	xchg   %ax,%ax
  403c20:	mov    0x4(%rax),%edx
  403c23:	mov    (%rax),%ecx
  403c25:	shl    $0x20,%rdx
  403c29:	or     %rcx,%rdx
  403c2c:	mov    %rdx,%rcx
  403c2f:	and    $0xffffff,%edx
  403c35:	shr    $0x18,%rcx
  403c39:	lea    0x8(,%rcx,8),%rdi
  403c41:	lea    0x0(%r13,%rdi,1),%r8
  403c46:	lea    -0x8(%r13,%rdi,1),%rdi
  403c4b:	cmp    $0x1,%rdx
  403c4f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  403c55:	mov    (%rax),%edx
  403c57:	mov    (%r15),%rdx
  403c5a:	mov    (%rdi),%r14
  403c5d:	mov    (%r8),%r9
  403c60:	mov    %rdx,(%rax)
  403c63:	mov    0x100(%r15),%rax
  403c6a:	mov    0x3d568(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403c70:	mov    %rbx,(%r15)
  403c73:	add    $0x1,%rax
  403c77:	mov    %rax,0x100(%r15)
  403c7e:	cmp    %rdx,%rax
  403c81:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  403c87:	mov    %rcx,%rbx
  403c8a:	jmpq   403b66 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
