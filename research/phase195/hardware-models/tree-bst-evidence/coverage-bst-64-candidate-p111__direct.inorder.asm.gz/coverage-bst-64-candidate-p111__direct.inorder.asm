000000000040ec6e <p111_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>:
  40ec6e:	push   rbp
  40ec6f:	mov    rbp,rsp
  40ec72:	sub    rsp,0x930
  40ec79:	mov    QWORD PTR [rbp-0x10],r12
  40ec7d:	mov    rax,rdi
  40ec80:	mov    r12,rax
  40ec83:	mov    rdi,QWORD PTR [r12+0x28]
  40ec88:	mov    rsi,QWORD PTR [r12+0x30]
  40ec8d:	mov    r10,r12
  40ec90:	mov    QWORD PTR [rsp+0x30],r10
  40ec95:	mov    r10,rdi
  40ec98:	mov    QWORD PTR [rsp+0x38],r10
  40ec9d:	mov    r10,rsi
  40eca0:	mov    QWORD PTR [rsp+0x40],r10
  40eca5:	movabs r10,0x0
  40ecaf:	mov    QWORD PTR [rsp+0x48],r10
  40ecb4:	movabs r10,0x0
  40ecbe:	mov    QWORD PTR [rsp+0x50],r10
  40ecc3:	movabs r10,0x0
  40eccd:	mov    QWORD PTR [rsp+0x58],r10
  40ecd2:	mov    rdi,QWORD PTR [rsp+0x30]
  40ecd7:	mov    rsi,QWORD PTR [rsp+0x38]
  40ecdc:	mov    rdx,QWORD PTR [rsp+0x40]
  40ece1:	mov    rcx,QWORD PTR [rsp+0x48]
  40ece6:	mov    r8,QWORD PTR [rsp+0x50]
  40eceb:	mov    r9,QWORD PTR [rsp+0x58]
  40ecf0:	xor    eax,eax
  40ecf2:	call   40e966 <p114r_FID_36_100_105_114_101_99_116_46_105_110_111_114_100_101_114_>
  40ecf7:	mov    rdi,rax
  40ecfa:	lea    r10,[rbp-0x880]
  40ed01:	mov    r11,rdi
  40ed04:	mov    QWORD PTR [r10],r11
  40ed07:	mov    rdi,r12
  40ed0a:	lea    rsi,[rbp-0x880]
  40ed11:	movabs rdx,0x1
  40ed1b:	mov    edx,edx
  40ed1d:	xor    eax,eax
  40ed1f:	call   418440 <p111_rt_return>
  40ed24:	mov    rdi,rax
  40ed27:	mov    rax,rdi
  40ed2a:	mov    r12,QWORD PTR [rbp-0x10]
  40ed2e:	mov    rsp,rbp
  40ed31:	pop    rbp
  40ed32:	ret    

