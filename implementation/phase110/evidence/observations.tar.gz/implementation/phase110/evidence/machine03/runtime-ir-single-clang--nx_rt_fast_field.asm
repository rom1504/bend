
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004031f0 <nx_rt_fast_field>:
  4031f0:	mov    %esi,%ecx
  4031f2:	mov    $0xfffffffe,%eax
  4031f7:	rol    %cl,%eax
  4031f9:	add    $0x2,%rcx
  4031fd:	and    %eax,0x20(%rdi)
  403200:	mov    (%rdi,%rcx,8),%rax
  403204:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  40320c:	retq   

Disassembly of section .fini:
