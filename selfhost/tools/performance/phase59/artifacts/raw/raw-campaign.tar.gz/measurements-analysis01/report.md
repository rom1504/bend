# First-request measurements

Clean ratios only compare same-campaign medians. CPU comparisons use sample counts for every capture; admitted timestamp weights remain separate. All TS source URLs are grouped together. Self groups partition the full denominator, inclusive frames overlap. Shared SCC frame names identify dispatchers, not one source member. Allocation totals estimate one first-window cumulative allocation including collected objects, not live heap or speed. Repeats remain separate.

| Campaign | Case | Role | Combined first ms | First compile ms | Later median ms |
|---|---|---|---:|---:|---:|
| clean01 | test-evening-program | direct | 2269.909 | 2161.127 | 1126.229 |
| clean01 | test-evening-program | typescript | 945.825 | 674.476 | 441.616 |
| clean01 | lexer | direct | 1687.305 | 1581.436 | 730.160 |
| clean01 | lexer | typescript | 648.086 | 379.329 | 248.491 |

## first-cpu01 / test-evening-program / direct

Unit: samples; total 1650; samples 1650. Raw `ad717274ece49d25ab8a30af98dc4c662086e9258b26f7fc03aa33bd8dab12c0`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 4.727 | 4.727 | `$jd$jd_95_primitive_95_table` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:52555` |
| 4.000 | 4.000 | `compileSourceTextModule` | `node:internal/modules/esm/utils:316` |
| 3.879 | 6.182 | `$jd$subst$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:877` |
| 3.697 | 3.697 | `$jd$String_46_starts_95_with_46_if$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:572` |
| 3.394 | 3.394 | `(garbage collector)` | `:None` |
| 2.667 | 5.576 | `validateSpanCache` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/tools/typed-driver.mjs:245` |
| 2.364 | 8.000 | `readBaseCache` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/tools/typed-driver.mjs:345` |
| 2.303 | 2.303 | `validateSpanBook` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/tools/typed-driver.mjs:225` |
| 2.182 | 4.364 | `$jd$norm_95_eval_95_node$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1749` |
| 1.758 | 4.667 | `$jd$j_95_layout_95_term$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:24459` |
| 1.576 | 1.697 | `$jd$index_95_find$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1338` |
| 1.455 | 3.939 | `$jd$String_46_contains_46_if$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:594` |

## first-cpu01 / test-evening-program / typescript

Unit: samples; total 842; samples 842. Raw `2ccf5ba540c7ba8c652aa36db9b08f54a8279b1e864f6b2ab0ec85d7e92f5240`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 15.796 | 31.591 | `term_any` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:823` |
| 12.233 | 21.259 | `term_check` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3479` |
| 6.532 | 7.482 | `term_higher` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:693` |
| 3.444 | 3.444 | `(garbage collector)` | `:None` |
| 2.494 | 3.207 | `__require` | `node:internal/deps/amaro/dist/index:8` |
| 2.375 | 3.088 | `compare_go` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3057` |
| 2.138 | 3.563 | `type_adts` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:984` |
| 2.138 | 2.850 | `term_wnf` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2784` |
| 1.663 | 5.226 | `term_lower` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:782` |
| 1.544 | 31.235 | `(anonymous)` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:827` |
| 1.544 | 1.544 | `pmap_set` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:530` |
| 1.425 | 4.869 | `(anonymous)` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:739` |

## first-cpu01 / lexer / direct

Unit: samples; total 1157; samples 1157. Raw `a9dd771e68a13919b65096122cd2d448dc9c1c4afe5f4d1c853ba848f9569675`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 5.272 | 5.272 | `compileSourceTextModule` | `node:internal/modules/esm/utils:316` |
| 4.149 | 8.124 | `validateSpanCache` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/tools/typed-driver.mjs:245` |
| 3.544 | 3.544 | `validateSpanBook` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/tools/typed-driver.mjs:225` |
| 3.284 | 11.582 | `readBaseCache` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/tools/typed-driver.mjs:345` |
| 3.111 | 3.111 | `(garbage collector)` | `:None` |
| 2.420 | 3.284 | `$jd$ffw_95_walk$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:19227` |
| 2.074 | 2.074 | `$jd$jd_95_primitive_95_table` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:52555` |
| 1.988 | 3.025 | `$jd$g_95_eval$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:3200` |
| 1.988 | 2.939 | `$jd$subst$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:877` |
| 1.815 | 2.679 | `$jd$norm_95_eval_95_node$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1749` |
| 1.815 | 1.815 | `update` | `:None` |
| 1.469 | 6.223 | `$jd$norm_95_cmp_95_loop$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:2408` |

## first-cpu01 / lexer / typescript

Unit: samples; total 597; samples 597. Raw `2a388d39451babd96978f038aa5fe954f6c948b4a4235ff66c374129ecb6bb6b`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 18.090 | 32.161 | `term_check` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3479` |
| 4.690 | 5.528 | `term_higher` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:693` |
| 3.518 | 5.025 | `compare_go` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3057` |
| 3.518 | 4.355 | `__require` | `node:internal/deps/amaro/dist/index:8` |
| 3.350 | 3.350 | `(garbage collector)` | `:None` |
| 3.015 | 5.025 | `parse_term_ops` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2012` |
| 3.015 | 3.685 | `term_wnf` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2784` |
| 2.345 | 9.380 | `term_infer` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3265` |
| 2.178 | 5.360 | `term_lower` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:782` |
| 1.843 | 5.360 | `parse_term_base` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:1748` |
| 1.675 | 4.020 | `wasm-function[206]` | `wasm://wasm/00aa4bda:1` |
| 1.675 | 2.848 | `match_flatten` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2631` |

## first-cpu-evening-ts02 / test-evening-program / typescript

Unit: samples; total 863; samples 863. Raw `3a1ad907d212ce82fee699781dbbab8c7170735bc5758740d7b7614051d72097`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 15.411 | 31.518 | `term_any` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:823` |
| 12.399 | 21.321 | `term_check` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3479` |
| 5.910 | 6.837 | `term_higher` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:693` |
| 3.592 | 3.592 | `(garbage collector)` | `:None` |
| 2.781 | 4.056 | `term_wnf` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2784` |
| 2.317 | 3.013 | `__require` | `node:internal/deps/amaro/dist/index:8` |
| 2.086 | 3.476 | `compare_go` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3057` |
| 1.970 | 2.433 | `match_flatten` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2631` |
| 1.854 | 3.129 | `parse_term_ops` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2012` |
| 1.738 | 9.154 | `(anonymous)` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:1435` |
| 1.738 | 4.519 | `(anonymous)` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:739` |
| 1.506 | 5.678 | `term_lower` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:782` |

## first-allocation01 / test-evening-program / direct

Unit: estimated-allocated-bytes; total 898284512; samples 6707. Raw `7c7cdbf5cb9d8cfe490cf1086e92aa742cbebdd3665666cadbce4c438ee712ac`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 28.028 | 28.087 | `$jd$String_46_contains_46_if$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:594` |
| 26.135 | 30.902 | `$jd$jd_95_reach_95_refs_95_unique$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:58685` |
| 8.383 | 10.426 | `$jd$subst$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:877` |
| 4.680 | 4.709 | `$jd$String_46_starts_95_with_46_if$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:572` |
| 2.934 | 2.934 | `$jd$jd_95_primitive_95_table` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:52555` |
| 2.703 | 2.732 | `$jd$index_95_node` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1442` |
| 1.971 | 2.219 | `$jd$index_95_remove` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1414` |
| 1.795 | 8.075 | `$jd$subst_95_terms` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:954` |
| 1.182 | 3.109 | `$jd$sk_95_node` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:8775` |
| 1.154 | 2.307 | `$jd$wnf` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1744` |
| 1.022 | 1.022 | `$jd$kt` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:740` |
| 0.949 | 1.255 | `$jd$sk_95_quote` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:8629` |

## first-allocation01 / test-evening-program / typescript

Unit: estimated-allocated-bytes; total 123967856; samples 909. Raw `e05b248310cac2c9b1e8da7d3b28625c151b2776ebb3da1ea9770054589708c3`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 14.382 | 22.948 | `term_higher` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:693` |
| 7.826 | 16.500 | `term_wnf` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2784` |
| 4.230 | 18.191 | `type_adts` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:984` |
| 3.917 | 3.917 | `push` | `:None` |
| 3.807 | 14.647 | `(anonymous)` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:739` |
| 3.107 | 3.458 | `__require` | `node:internal/deps/amaro/dist/index:8` |
| 2.644 | 12.902 | `map` | `:None` |
| 2.539 | 2.539 | `ADT` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:407` |
| 2.329 | 2.435 | `Infer` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:478` |
| 2.327 | 2.327 | `Var` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:363` |
| 2.327 | 41.416 | `term_any` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/comp.ts:823` |
| 1.798 | 1.798 | `All` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:395` |

## first-allocation01 / lexer / direct

Unit: estimated-allocated-bytes; total 246094096; samples 1817. Raw `125ce38c91eaf00125deca1dcce77515ac2a5587dea8f95c60cef23296320cda`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 9.594 | 12.258 | `$jd$subst$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:877` |
| 8.642 | 8.802 | `$jd$index_95_node` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1442` |
| 6.287 | 6.606 | `$jd$index_95_remove` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:1414` |
| 3.944 | 4.690 | `$jd$String_46_contains_46_if$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:594` |
| 3.305 | 3.305 | `$jd$kt` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:740` |
| 3.265 | 3.691 | `$jd$String_46_starts_95_with_46_if$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:572` |
| 3.037 | 3.037 | `values` | `:None` |
| 2.984 | 2.984 | `$jd$jd_95_primitive_95_table` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:52555` |
| 2.826 | 2.985 | `$jd$missing` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:822` |
| 2.397 | 3.678 | `$jd$ffw_95_walk$scc` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:19227` |
| 2.131 | 8.581 | `$jd$subst_95_terms` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/dist/api.mjs:954` |
| 1.918 | 8.176 | `readBaseCache` | `file:///home/ai/bend2/build/publish/bend/selfhost/build/phase59/preparation01/prepare-direct/stage/project/tools/typed-driver.mjs:345` |

## first-allocation01 / lexer / typescript

Unit: estimated-allocated-bytes; total 64958408; samples 464. Raw `6eb5d463d23f686f930c73d1cb6c2e52b2616e8145d1d9c4bfe2ed368b8b1f99`.

| Self % | Inclusive % | Actual frame | URL / line |
|---:|---:|---|---|
| 10.494 | 20.586 | `term_higher` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:693` |
| 5.727 | 5.929 | `__require` | `node:internal/deps/amaro/dist/index:8` |
| 4.642 | 10.092 | `term_wnf` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2784` |
| 4.239 | 4.239 | `Var` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:363` |
| 3.835 | 3.835 | `Bin` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:456` |
| 3.027 | 10.697 | `match_flatten` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:2631` |
| 2.826 | 2.826 | `Infer` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:478` |
| 2.825 | 2.825 | `App` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:403` |
| 2.825 | 2.825 | `slice` | `:None` |
| 2.422 | 2.422 | `ADT` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:407` |
| 2.422 | 40.769 | `term_check` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:3479` |
| 2.422 | 2.825 | `word_to_term` | `file:///home/ai/bend2/build/publish/bend/selfhost/.bootstrap/upstream-phase23/bend2/bend.ts:1064` |
