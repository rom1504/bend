
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000404100 <nx_rt_rebuild2_c3_k0>:
  404100:	push   %r15
  404102:	push   %r14
  404104:	push   %r13
  404106:	push   %r12
  404108:	mov    %rdx,%r12
  40410b:	push   %rbp
  40410c:	mov    %rdi,%rbp
  40410f:	push   %rbx
  404110:	movabs $0xffffffffff,%rbx
  40411a:	and    %rsi,%rbx
  40411d:	lea    0x0(,%rbx,8),%rdx
  404125:	sub    $0x18,%rsp
  404129:	mov    (%rdi),%r13
  40412c:	mov    0x8(%rdi),%r15
  404130:	lea    0x0(%r13,%rdx,1),%rax
  404135:	test   %rsi,%rsi
  404138:	js     404200 <nx_rt_rebuild2_c3_k0+0x100>
  40413e:	mov    (%rax),%r14
  404141:	mov    0x8(%r13,%rdx,1),%r9
  404146:	cmp    $0x310817f,%rbx
  40414d:	jbe    4041d8 <nx_rt_rebuild2_c3_k0+0xd8>
  404153:	lea    0x0(%r13,%rbx,8),%r8
  404158:	mov    %r14,%rax
  40415b:	mov    %r9,0x10(%rbp)
  40415f:	shr    $0x38,%rax
  404163:	movq   $0xffffffffffffffff,0x18(%rbp)
  40416b:	and    $0x7f,%eax
  40416e:	movl   $0x1,0x20(%rbp)
  404175:	cmp    $0x2,%rax
  404179:	je     4041b8 <nx_rt_rebuild2_c3_k0+0xb8>
  40417b:	mov    %r12,%rax
  40417e:	mov    %r14,(%r8)
  404181:	lea    0x8(%r13,%rbx,8),%rbp
  404186:	shr    $0x38,%rax
  40418a:	and    $0x7f,%eax
  40418d:	cmp    $0x2,%rax
  404191:	je     4041c8 <nx_rt_rebuild2_c3_k0+0xc8>
  404193:	movabs $0x200030000000000,%rax
  40419d:	mov    %r12,0x0(%rbp)
  4041a1:	add    $0x18,%rsp
  4041a5:	or     %rbx,%rax
  4041a8:	pop    %rbx
  4041a9:	pop    %rbp
  4041aa:	pop    %r12
  4041ac:	pop    %r13
  4041ae:	pop    %r14
  4041b0:	pop    %r15
  4041b2:	retq   
  4041b3:	nopl   0x0(%rax,%rax,1)
  4041b8:	test   %r14,%r14
  4041bb:	js     40417b <nx_rt_rebuild2_c3_k0+0x7b>
  4041bd:	jmpq   40196c <nx_rt_rebuild2_c3_k0.cold>
  4041c2:	nopw   0x0(%rax,%rax,1)
  4041c8:	test   %r12,%r12
  4041cb:	js     404193 <nx_rt_rebuild2_c3_k0+0x93>
  4041cd:	jmpq   40198f <nx_rt_rebuild2_c3_k0.cold+0x23>
  4041d2:	nopw   0x0(%rax,%rax,1)
  4041d8:	mov    0x8(%r15),%rbx
  4041dc:	test   %rbx,%rbx
  4041df:	je     4019aa <nx_rt_rebuild2_c3_k0.cold+0x3e>
  4041e5:	lea    0x0(%r13,%rbx,8),%r8
  4041ea:	mov    (%r8),%rax
  4041ed:	subq   $0x2,0x108(%r15)
  4041f5:	mov    %rax,0x8(%r15)
  4041f9:	jmpq   404158 <nx_rt_rebuild2_c3_k0+0x58>
  4041fe:	xchg   %ax,%ax
  404200:	mov    0x4(%rax),%edx
  404203:	mov    (%rax),%ecx
  404205:	shl    $0x20,%rdx
  404209:	or     %rcx,%rdx
  40420c:	mov    %rdx,%rcx
  40420f:	and    $0xffffff,%edx
  404215:	shr    $0x18,%rcx
  404219:	lea    0x8(,%rcx,8),%rdi
  404221:	lea    0x0(%r13,%rdi,1),%r8
  404226:	lea    -0x8(%r13,%rdi,1),%rdi
  40422b:	cmp    $0x1,%rdx
  40422f:	jne    4019f3 <nx_rt_rebuild2_c3_k0.cold+0x87>
  404235:	mov    (%rax),%edx
  404237:	mov    (%r15),%rdx
  40423a:	mov    (%rdi),%r14
  40423d:	mov    (%r8),%r9
  404240:	mov    %rdx,(%rax)
  404243:	mov    0x100(%r15),%rax
  40424a:	mov    0x3df88(%rip),%edx        # 4421d8 <KEEP_WORDS>
  404250:	mov    %rbx,(%r15)
  404253:	add    $0x1,%rax
  404257:	mov    %rax,0x100(%r15)
  40425e:	cmp    %rdx,%rax
  404261:	jae    4019cf <nx_rt_rebuild2_c3_k0.cold+0x63>
  404267:	mov    %rcx,%rbx
  40426a:	jmpq   404146 <nx_rt_rebuild2_c3_k0+0x46>

Disassembly of section .fini:
