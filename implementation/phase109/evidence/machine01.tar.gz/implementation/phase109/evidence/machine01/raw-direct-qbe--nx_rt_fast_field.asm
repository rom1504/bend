
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402a00 <nx_rt_fast_field>:
  402a00:	mov    %esi,%ecx
  402a02:	mov    $0xfffffffe,%eax
  402a07:	rol    %cl,%eax
  402a09:	add    $0x2,%rcx
  402a0d:	and    %eax,0x20(%rdi)
  402a10:	mov    (%rdi,%rcx,8),%rax
  402a14:	movq   $0xffffffffffffffff,(%rdi,%rcx,8)
  402a1c:	retq   

Disassembly of section .fini:
