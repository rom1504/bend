
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-single-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402150 <nx_string_reverse>:
  402150:	endbr64 
  402154:	push   %rbp
  402155:	mov    %rsp,%rbp
  402158:	sub    $0x38,%rsp
  40215c:	push   %rbx
  40215d:	push   %r12
  40215f:	push   %r13
  402161:	push   %r14
  402163:	push   %r15
  402165:	mov    %rdx,%rbx
  402168:	mov    %rsi,%r14
  40216b:	mov    %rdi,%r12
  40216e:	callq  4047a0 <nx_rt_ir_heap>
  402173:	mov    %r12,%rdi
  402176:	mov    %rax,%r12
  402179:	mov    %rdi,%r13
  40217c:	callq  404810 <nx_rt_ir_alc>
  402181:	mov    %r14,%rsi
  402184:	mov    %r13,%rdi
  402187:	xchg   %rax,%rbx
  402189:	mov    %rax,%rdx
  40218c:	nopl   0x0(%rax)
  402190:	mov    %rsi,%rax
  402193:	shr    $0x28,%rax
  402197:	and    $0xffff,%rax
  40219d:	cmp    $0x2,%rax
  4021a1:	je     402499 <nx_string_reverse+0x349>
  4021a7:	cmp    $0x3,%rax
  4021ab:	jne    40248d <nx_string_reverse+0x33d>
  4021b1:	movabs $0xffffffffff,%rax
  4021bb:	and    %rsi,%rax
  4021be:	mov    %rsi,%r9
  4021c1:	shr    $0x3f,%r9
  4021c5:	cmp    $0x1,%r9
  4021c9:	sete   %cl
  4021cc:	movzbl %cl,%ecx
  4021cf:	mov    %rax,%r10
  4021d2:	shl    $0x3,%r10
  4021d6:	cmp    $0x0,%ecx
  4021d9:	jne    4021f5 <nx_string_reverse+0xa5>
  4021db:	cmp    $0x3108180,%rax
  4021e1:	setb   %cl
  4021e4:	movzbl %cl,%ecx
  4021e7:	cmp    $0x0,%ecx
  4021ea:	sete   %cl
  4021ed:	movzbl %cl,%ecx
  4021f0:	mov    %rax,%r8
  4021f3:	jmp    402238 <nx_string_reverse+0xe8>
  4021f5:	mov    %rax,%r8
  4021f8:	mov    (%r12,%r10,1),%rax
  4021fc:	mov    %rax,%rcx
  4021ff:	and    $0xffffff,%rcx
  402206:	cmp    $0x1,%rcx
  40220a:	sete   %cl
  40220d:	movzbl %cl,%ecx
  402210:	cmp    $0x0,%ecx
  402213:	jne    40221f <nx_string_reverse+0xcf>
  402215:	mov    $0x0,%ecx
  40221a:	mov    %r8,%rax
  40221d:	jmp    402238 <nx_string_reverse+0xe8>
  40221f:	shr    $0x18,%rax
  402223:	cmp    $0x3108180,%rax
  402229:	setb   %cl
  40222c:	movzbl %cl,%ecx
  40222f:	cmp    $0x0,%ecx
  402232:	sete   %cl
  402235:	movzbl %cl,%ecx
  402238:	mov    %rax,-0x30(%rbp)
  40223c:	cmp    $0x0,%ecx
  40223f:	jne    40226a <nx_string_reverse+0x11a>
  402241:	mov    %rdi,%r13
  402244:	callq  404100 <nx_rt_rebuild2_c3_k0>
  402249:	mov    %r13,%rdi
  40224c:	mov    %rax,%r14
  40224f:	mov    $0x0,%esi
  402254:	mov    %rdi,%r13
  402257:	callq  403490 <nx_rt_fast_field>
  40225c:	mov    %r14,%rdx
  40225f:	mov    %r13,%rdi
  402262:	mov    %rax,%rsi
  402265:	jmpq   402190 <nx_string_reverse+0x40>
  40226a:	mov    %rax,%r14
  40226d:	shl    $0x3,%r14
  402271:	mov    %r14,-0x10(%rbp)
  402275:	mov    %r12,%rcx
  402278:	add    %r14,%rcx
  40227b:	mov    %rcx,-0x20(%rbp)
  40227f:	mov    (%r12,%r14,1),%r13
  402283:	mov    0x8(%r12,%r14,1),%rsi
  402288:	mov    %rsi,-0x18(%rbp)
  40228c:	cmp    $0x1,%r9
  402290:	jne    4022e6 <nx_string_reverse+0x196>
  402292:	mov    (%rbx),%r9
  402295:	mov    %r9,(%r12,%r10,1)
  402299:	mov    %r8,(%rbx)
  40229c:	mov    0x100(%rbx),%r8
  4022a3:	add    $0x1,%r8
  4022a7:	mov    %r8,0x100(%rbx)
  4022ae:	cmp    $0x8000,%r8
  4022b5:	mov    %rdx,%r15
  4022b8:	setb   %dl
  4022bb:	movzbl %dl,%edx
  4022be:	cmp    $0x0,%edx
  4022c1:	jne    4022e3 <nx_string_reverse+0x193>
  4022c3:	mov    %rdi,%r14
  4022c6:	callq  401c36 <nx_rt_ir_hand0>
  4022cb:	mov    %r15,%rdx
  4022ce:	mov    %r14,%rdi
  4022d1:	mov    -0x30(%rbp),%rax
  4022d5:	mov    -0x18(%rbp),%rsi
  4022d9:	mov    -0x20(%rbp),%rcx
  4022dd:	mov    -0x10(%rbp),%r14
  4022e1:	jmp    4022e6 <nx_string_reverse+0x196>
  4022e3:	mov    %r15,%rdx
  4022e6:	mov    %r13,%r8
  4022e9:	shr    $0x38,%r8
  4022ed:	and    $0x7f,%r8
  4022f1:	cmp    $0x2,%r8
  4022f5:	sete   %r8b
  4022f9:	movzbl %r8b,%r8d
  4022fd:	mov    %r13,%r9
  402300:	shr    $0x3f,%r9
  402304:	cmp    $0x0,%r9
  402308:	sete   %r9b
  40230c:	movzbl %r9b,%r9d
  402310:	test   %r8d,%r9d
  402313:	je     4023ac <nx_string_reverse+0x25c>
  402319:	mov    (%rbx),%r9
  40231c:	cmp    $0x0,%r9
  402320:	je     40234a <nx_string_reverse+0x1fa>
  402322:	mov    %r9,%r8
  402325:	shl    $0x3,%r8
  402329:	mov    (%r12,%r8,1),%r8
  40232d:	mov    %r8,(%rbx)
  402330:	mov    %rdx,%r15
  402333:	mov    0x100(%rbx),%rdx
  40233a:	sub    $0x1,%rdx
  40233e:	mov    %rdx,0x100(%rbx)
  402345:	mov    %r15,%rdx
  402348:	jmp    40236e <nx_string_reverse+0x21e>
  40234a:	mov    %rdx,%r15
  40234d:	mov    %rdi,%r14
  402350:	callq  401c25 <nx_rt_ir_alloc0>
  402355:	mov    %r15,%rdx
  402358:	mov    %r14,%rdi
  40235b:	mov    %rax,%r9
  40235e:	mov    -0x30(%rbp),%rax
  402362:	mov    -0x18(%rbp),%rsi
  402366:	mov    -0x20(%rbp),%rcx
  40236a:	mov    -0x10(%rbp),%r14
  40236e:	mov    %r9,%r10
  402371:	shl    $0x3,%r10
  402375:	movabs $0xffffffffff,%r8
  40237f:	and    %r13,%r8
  402382:	shl    $0x18,%r8
  402386:	or     $0x1,%r8
  40238a:	mov    %r8,(%r12,%r10,1)
  40238e:	mov    %r13,%r8
  402391:	shr    $0x28,%r8
  402395:	shl    $0x28,%r8
  402399:	movabs $0x8000000000000000,%r10
  4023a3:	or     %r10,%r8
  4023a6:	mov    %r8,%r13
  4023a9:	or     %r9,%r13
  4023ac:	mov    %r13,-0x28(%rbp)
  4023b0:	mov    %rdx,%r8
  4023b3:	shr    $0x38,%r8
  4023b7:	and    $0x7f,%r8
  4023bb:	cmp    $0x2,%r8
  4023bf:	sete   %r8b
  4023c3:	movzbl %r8b,%r8d
  4023c7:	mov    %rdx,%r9
  4023ca:	shr    $0x3f,%r9
  4023ce:	cmp    $0x0,%r9
  4023d2:	sete   %r9b
  4023d6:	movzbl %r9b,%r9d
  4023da:	test   %r8d,%r9d
  4023dd:	je     402470 <nx_string_reverse+0x320>
  4023e3:	mov    (%rbx),%r8
  4023e6:	cmp    $0x0,%r8
  4023ea:	je     402414 <nx_string_reverse+0x2c4>
  4023ec:	mov    %r8,%r9
  4023ef:	shl    $0x3,%r9
  4023f3:	mov    (%r12,%r9,1),%r9
  4023f7:	mov    %r9,(%rbx)
  4023fa:	mov    %rdx,%r15
  4023fd:	mov    0x100(%rbx),%rdx
  402404:	sub    $0x1,%rdx
  402408:	mov    %rdx,0x100(%rbx)
  40240f:	mov    %r15,%rdx
  402412:	jmp    402438 <nx_string_reverse+0x2e8>
  402414:	mov    %rdx,%r15
  402417:	mov    %rdi,%r13
  40241a:	callq  401c25 <nx_rt_ir_alloc0>
  40241f:	mov    %r15,%rdx
  402422:	mov    %r13,%rdi
  402425:	mov    %rax,%r8
  402428:	mov    -0x28(%rbp),%r13
  40242c:	mov    -0x30(%rbp),%rax
  402430:	mov    -0x18(%rbp),%rsi
  402434:	mov    -0x20(%rbp),%rcx
  402438:	mov    %r8,%r10
  40243b:	shl    $0x3,%r10
  40243f:	movabs $0xffffffffff,%r9
  402449:	and    %rdx,%r9
  40244c:	shl    $0x18,%r9
  402450:	or     $0x1,%r9
  402454:	mov    %r9,(%r12,%r10,1)
  402458:	shr    $0x28,%rdx
  40245c:	shl    $0x28,%rdx
  402460:	movabs $0x8000000000000000,%r9
  40246a:	or     %r9,%rdx
  40246d:	or     %r8,%rdx
  402470:	mov    %r13,(%r12,%r14,1)
  402474:	mov    %rdx,0x8(%rcx)
  402478:	movabs $0x200030000000000,%rcx
  402482:	mov    %rax,%rdx
  402485:	or     %rcx,%rdx
  402488:	jmpq   402190 <nx_string_reverse+0x40>
  40248d:	mov    $0x1,%esi
  402492:	callq  402c90 <nx_rt_fail>
  402497:	jmp    40249c <nx_string_reverse+0x34c>
  402499:	mov    %rdx,%rax
  40249c:	pop    %r15
  40249e:	pop    %r14
  4024a0:	pop    %r13
  4024a2:	pop    %r12
  4024a4:	pop    %rbx
  4024a5:	leaveq 
  4024a6:	retq   

Disassembly of section .fini:
