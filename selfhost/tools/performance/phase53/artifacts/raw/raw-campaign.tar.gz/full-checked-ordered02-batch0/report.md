# Generated-program execution

Status: **measured**; 15/15 selected cases complete.

Times include export invocation, exact result validation and checksum work; import and first calls are separate.
The budget is a maximum wall time, not a request to pad a short run. Short warmups are screens, not steady-state evidence.

| Case | Paired rounds | Baseline ms | Candidate ms | TypeScript ms | Candidate / TS (or baseline / TS) |
|---|---:|---:|---:|---:|---:|
| local-pair | 5/5 | 1.61619 | 1.38588 | 1.23693 | 1.120× |
| local-fold | 5/5 | 0.0407017 | 0.0415811 | 0.0393284 | 1.057× |
| scalar-region-0 | 5/5 | 6.80497e-05 | 6.73905e-05 | 6.83513e-05 | 0.986× |
| scalar-region-8192 | 5/5 | 0.111156 | 0.0992523 | 0.0995799 | 0.997× |
| complete-generic-row32 | 5/5 | 0.00676782 | 0.00692158 | 0.00676731 | 1.023× |
| mandelbrot | 5/5 | 0.0782521 | 0.0684848 | 0.0453901 | 1.509× |
| editdist | 5/5 | 6.49095 | 5.60615 | 4.95545 | 1.131× |
| tree-bitonic | 5/5 | 0.265741 | 0.266666 | 0.274967 | 0.970× |
| lexer | 5/5 | 1.74663 | 1.71287 | 1.67614 | 1.022× |
| symreg | 5/5 | 1.32435 | 1.10183 | 1.10398 | 0.998× |
| test-morning-program | 5/5 | 0.00289599 | 0.00281621 | 0.00324282 | 0.868× |
| test-evening-program | 5/5 | 0.00260969 | 0.00269816 | 0.00261728 | 1.031× |
| test-rle-roundtrip | 5/5 | 0.000583444 | 0.000568206 | 0.000565496 | 1.005× |
| test-map-set-ops | 5/5 | 0.0190783 | 0.0193182 | 0.0203709 | 0.948× |
| raytrace | 3/3 | 57.4738 | 48.9369 | 34.3293 | 1.426× |

Missing, failed and partial samples remain in report.json; incomplete cases have no comparison ratio.
Output agreement on these fixed inputs is not a full conformance gate. No historical timing is used as a denominator.
