
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401fd0 <nx_construct2>:
  401fd0:	push   %r12
  401fd2:	mov    %rcx,%rax
  401fd5:	push   %rbp
  401fd6:	shr    $0x38,%rax
  401fda:	lea    0x0(,%r9,8),%rbp
  401fe2:	push   %rbx
  401fe3:	and    $0x7f,%eax
  401fe6:	mov    %edx,%ebx
  401fe8:	lea    (%rdi,%rbp,1),%r12
  401fec:	mov    %rcx,%rdx
  401fef:	sub    $0x20,%rsp
  401ff3:	cmp    $0x2,%rax
  401ff7:	je     402030 <nx_construct2+0x60>
  401ff9:	mov    %r8,%rax
  401ffc:	mov    %rdx,(%r12)
  402000:	lea    0x8(%rbp,%rdi,1),%rbp
  402005:	shr    $0x38,%rax
  402009:	and    $0x7f,%eax
  40200c:	cmp    $0x2,%rax
  402010:	je     402040 <nx_construct2+0x70>
  402012:	mov    %rbx,%rax
  402015:	mov    %r8,0x0(%rbp)
  402019:	add    $0x20,%rsp
  40201d:	shl    $0x28,%rax
  402021:	pop    %rbx
  402022:	pop    %rbp
  402023:	or     %r9,%rax
  402026:	pop    %r12
  402028:	bts    $0x39,%rax
  40202d:	retq   
  40202e:	xchg   %ax,%ax
  402030:	test   %rcx,%rcx
  402033:	js     401ff9 <nx_construct2+0x29>
  402035:	jmpq   401410 <nx_construct2.cold>
  40203a:	nopw   0x0(%rax,%rax,1)
  402040:	test   %r8,%r8
  402043:	js     402012 <nx_construct2+0x42>
  402045:	jmpq   401448 <nx_construct2.cold+0x38>

Disassembly of section .fini:
