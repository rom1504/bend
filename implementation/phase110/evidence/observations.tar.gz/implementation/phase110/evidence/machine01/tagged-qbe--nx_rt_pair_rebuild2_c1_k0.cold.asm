
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

000000000040173f <nx_rt_pair_rebuild2_c1_k0.cold>:
  40173f:	mov    $0x1,%edx
  401744:	mov    %rbp,%rdi
  401747:	mov    %r8,0x8(%rsp)
  40174c:	mov    %rsi,(%rsp)
  401750:	callq  401178 <heap_alloc_miss>
  401755:	mov    (%rsp),%rsi
  401759:	mov    0x8(%rsp),%r8
  40175e:	mov    %rax,%r9
  401761:	jmpq   4034d8 <nx_rt_pair_rebuild2_c1_k0+0x48>
  401766:	xor    %edx,%edx
  401768:	mov    %rbp,%rdi
  40176b:	mov    %r8,(%rsp)
  40176f:	callq  401100 <heap_hand>
  401774:	mov    (%rsp),%r8
  401778:	jmpq   403584 <nx_rt_pair_rebuild2_c1_k0+0xf4>
  40177d:	mov    (%rcx),%r13
  401780:	mov    (%rdi),%r12
  401783:	mov    %r14,%rcx
  401786:	mov    %r10,%rdx
  401789:	mov    %rbp,%rdi
  40178c:	mov    %r8,0x8(%rsp)
  401791:	mov    %rsi,(%rsp)
  401795:	callq  4014c6 <span_fade.constprop.0>
  40179a:	mov    (%rsp),%rsi
  40179e:	mov    0x8(%rsp),%r8
  4017a3:	jmpq   403500 <nx_rt_pair_rebuild2_c1_k0+0x70>

Disassembly of section .fini:
