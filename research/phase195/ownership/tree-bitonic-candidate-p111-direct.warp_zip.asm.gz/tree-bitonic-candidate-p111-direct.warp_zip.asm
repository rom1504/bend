
/home/ai/bend2/build/publish/bend/selfhost/build/phase194/native45-02/tree-bitonic/machine/program:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000412fde <p111_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>:
  412fde:	push   %rbp
  412fdf:	mov    %rsp,%rbp
  412fe2:	sub    $0x900,%rsp
  412fe9:	mov    %r12,-0x10(%rbp)
  412fed:	mov    %rdi,%rax
  412ff0:	mov    %rax,%r12
  412ff3:	mov    0x28(%r12),%rdi
  412ff8:	mov    0x30(%r12),%rsi
  412ffd:	mov    %r12,%r10
  413000:	mov    %r10,0x18(%rsp)
  413005:	mov    %rdi,%r10
  413008:	mov    %r10,0x20(%rsp)
  41300d:	mov    %rsi,%r10
  413010:	mov    %r10,0x28(%rsp)
  413015:	mov    0x18(%rsp),%rdi
  41301a:	mov    0x20(%rsp),%rsi
  41301f:	mov    0x28(%rsp),%rdx
  413024:	xor    %eax,%eax
  413026:	callq  408309 <p113d_FID_36_100_105_114_101_99_116_46_119_97_114_112_95_122_105_112_>
  41302b:	mov    %rax,%rdi
  41302e:	lea    -0x880(%rbp),%r10
  413035:	mov    %rdi,%r11
  413038:	mov    %r11,(%r10)
  41303b:	mov    %r12,%rdi
  41303e:	lea    -0x880(%rbp),%rsi
  413045:	movabs $0x1,%rdx
  41304f:	mov    %edx,%edx
  413051:	xor    %eax,%eax
  413053:	callq  41c5c0 <p111_rt_return>
  413058:	mov    %rax,%rdi
  41305b:	mov    %rdi,%rax
  41305e:	mov    -0x10(%rbp),%r12
  413062:	mov    %rbp,%rsp
  413065:	pop    %rbp
  413066:	retq   

Disassembly of section .fini:
