
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	push   %rbx
  401c01:	mov    %rdx,%rax
  401c04:	mov    %rdi,%rbx
  401c07:	nopw   0x0(%rax,%rax,1)
  401c10:	mov    %rsi,%rcx
  401c13:	shr    $0x28,%rcx
  401c17:	cmp    $0x1,%cx
  401c1b:	jne    401c2d <nx_list_reverse+0x2d>
  401c1d:	mov    %rbx,%rdi
  401c20:	mov    %rax,%rdx
  401c23:	callq  403430 <nx_rt_pair_rebuild2_c1_k0>
  401c28:	mov    %rdx,%rsi
  401c2b:	jmp    401c10 <nx_list_reverse+0x10>
  401c2d:	movzwl %cx,%ecx
  401c30:	test   %ecx,%ecx
  401c32:	jne    401c36 <nx_list_reverse+0x36>
  401c34:	pop    %rbx
  401c35:	retq   
  401c36:	mov    %rbx,%rdi
  401c39:	mov    $0x1,%esi
  401c3e:	pop    %rbx
  401c3f:	jmpq   402500 <nx_rt_fail>

Disassembly of section .fini:
