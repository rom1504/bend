000000000040adf0 <p111_FID_105_110_111_114_100_101_114_>:
  40adf0:	endbr64 
  40adf4:	push   rbp
  40adf5:	mov    rbp,rsp
  40adf8:	sub    rsp,0x808
  40adff:	push   rbx
  40ae00:	mov    ecx,0x0
  40ae05:	lea    rdx,[rbp-0x800]
  40ae0c:	mov    esi,0x45
  40ae11:	mov    rbx,rdi
  40ae14:	call   4126f0 <p111_rt_closure>
  40ae19:	mov    rdi,rbx
  40ae1c:	mov    QWORD PTR [rbp-0x800],rax
  40ae23:	mov    rcx,QWORD PTR [rip+0x14c6e]        # 41fa98 <p111_program+0x58>
  40ae2a:	test   rcx,0x4
  40ae31:	jne    40ae46 <p111_FID_105_110_111_114_100_101_114_+0x56>
  40ae33:	mov    edx,0x1
  40ae38:	lea    rsi,[rbp-0x800]
  40ae3f:	call   412900 <p111_rt_return>
  40ae44:	jmp    40ae6c <p111_FID_105_110_111_114_100_101_114_+0x7c>
  40ae46:	mov    QWORD PTR [rdi+0x28],rax
  40ae4a:	mov    DWORD PTR [rdi+0x1c],0x1
  40ae51:	mov    rax,QWORD PTR [rdi+0x10]
  40ae55:	mov    rcx,rax
  40ae58:	add    rcx,0xfffffffffffffff8
  40ae5c:	mov    QWORD PTR [rdi+0x10],rcx
  40ae60:	mov    rax,QWORD PTR [rax-0x8]
  40ae64:	mov    DWORD PTR [rdi+0x20],eax
  40ae67:	mov    eax,0x0
  40ae6c:	pop    rbx
  40ae6d:	leave  
  40ae6e:	ret    
  40ae6f:	nop

