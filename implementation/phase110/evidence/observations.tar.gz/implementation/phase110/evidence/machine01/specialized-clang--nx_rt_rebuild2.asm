
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402d00 <nx_rt_rebuild2>:
  402d00:	movabs $0xffffffffff,%r9
  402d0a:	push   %r14
  402d0c:	push   %r13
  402d0e:	and    %rsi,%r9
  402d11:	mov    %edx,%r13d
  402d14:	push   %r12
  402d16:	lea    0x0(,%r9,8),%rdx
  402d1e:	push   %rbp
  402d1f:	mov    %ecx,%ebp
  402d21:	push   %rbx
  402d22:	mov    %rdi,%rbx
  402d25:	sub    $0x20,%rsp
  402d29:	mov    (%rdi),%rdi
  402d2c:	mov    0x8(%rbx),%r12
  402d30:	lea    (%rdi,%rdx,1),%rax
  402d34:	test   %rsi,%rsi
  402d37:	js     402db8 <nx_rt_rebuild2+0xb8>
  402d39:	mov    (%rax),%rax
  402d3c:	mov    %rax,0x10(%rsp)
  402d41:	mov    0x8(%rdi,%rdx,1),%rax
  402d46:	mov    %rax,0x18(%rsp)
  402d4b:	cmp    $0x310817f,%r9
  402d52:	jbe    402d90 <nx_rt_rebuild2+0x90>
  402d54:	mov    $0x1,%eax
  402d59:	mov    0x10(%rsp,%rbp,8),%rcx
  402d5e:	mov    %r13d,%edx
  402d61:	mov    %r12,%rsi
  402d64:	sub    %ebp,%eax
  402d66:	movq   $0xffffffffffffffff,0x18(%rbx)
  402d6e:	mov    0x10(%rsp,%rax,8),%rax
  402d73:	movl   $0x1,0x20(%rbx)
  402d7a:	mov    %rax,0x10(%rbx)
  402d7e:	add    $0x20,%rsp
  402d82:	pop    %rbx
  402d83:	pop    %rbp
  402d84:	pop    %r12
  402d86:	pop    %r13
  402d88:	pop    %r14
  402d8a:	jmpq   401fa0 <nx_construct2>
  402d8f:	nop
  402d90:	mov    0x8(%r12),%r9
  402d95:	test   %r9,%r9
  402d98:	je     401651 <nx_rt_rebuild2.cold>
  402d9e:	mov    (%rdi,%r9,8),%rax
  402da2:	subq   $0x2,0x108(%r12)
  402dab:	mov    %rax,0x8(%r12)
  402db0:	jmp    402d54 <nx_rt_rebuild2+0x54>
  402db2:	nopw   0x0(%rax,%rax,1)
  402db8:	mov    0x4(%rax),%edx
  402dbb:	mov    (%rax),%ecx
  402dbd:	shl    $0x20,%rdx
  402dc1:	or     %rcx,%rdx
  402dc4:	mov    %rdx,%r14
  402dc7:	and    $0xffffff,%edx
  402dcd:	shr    $0x18,%r14
  402dd1:	lea    0x0(,%r14,8),%r10
  402dd9:	lea    (%rdi,%r10,1),%r11
  402ddd:	lea    0x8(%rdi,%r10,1),%r10
  402de2:	cmp    $0x1,%rdx
  402de6:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402dec:	mov    (%rax),%edx
  402dee:	mov    (%r11),%rdx
  402df1:	mov    %rdx,0x10(%rsp)
  402df6:	mov    (%r10),%rdx
  402df9:	mov    %rdx,0x18(%rsp)
  402dfe:	mov    (%r12),%rdx
  402e02:	mov    %rdx,(%rax)
  402e05:	mov    0x100(%r12),%rax
  402e0d:	mov    0x3e3c5(%rip),%edx        # 4411d8 <KEEP_WORDS>
  402e13:	mov    %r9,(%r12)
  402e17:	add    $0x1,%rax
  402e1b:	mov    %rax,0x100(%r12)
  402e23:	cmp    %rdx,%rax
  402e26:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402e2c:	mov    %r14,%r9
  402e2f:	jmpq   402d4b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
