
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402640 <nx_rt_field>:
  402640:	sub    $0x8,%rsp
  402644:	cmpb   $0x0,0x4b35(%rip)        # 407180 <nx_active>
  40264b:	je     402659 <nx_rt_field+0x19>
  40264d:	lea    0x4b4c(%rip),%rdx        # 4071a0 <nx_context>
  402654:	cmp    %rdx,%rdi
  402657:	je     402668 <nx_rt_field+0x28>
  402659:	lea    0x19d3(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402660:	callq  401950 <err_fail>
  402665:	nopl   (%rax)
  402668:	mov    %esi,%ecx
  40266a:	cmp    $0x1,%ecx
  40266d:	jbe    402680 <nx_rt_field+0x40>
  40266f:	lea    0x1cd2(%rip),%rdi        # 404348 <_IO_stdin_used+0x348>
  402676:	callq  401950 <err_fail>
  40267b:	nopl   0x0(%rax,%rax,1)
  402680:	mov    $0x1,%eax
  402685:	mov    0x4b35(%rip),%esi        # 4071c0 <nx_context+0x20>
  40268b:	shl    %cl,%eax
  40268d:	test   %eax,%esi
  40268f:	je     40266f <nx_rt_field+0x2f>
  402691:	not    %eax
  402693:	add    $0x2,%rcx
  402697:	and    %esi,%eax
  402699:	mov    %eax,0x4b21(%rip)        # 4071c0 <nx_context+0x20>
  40269f:	mov    (%rdx,%rcx,8),%rax
  4026a3:	movq   $0xffffffffffffffff,(%rdx,%rcx,8)
  4026ab:	add    $0x8,%rsp
  4026af:	retq   

Disassembly of section .fini:
