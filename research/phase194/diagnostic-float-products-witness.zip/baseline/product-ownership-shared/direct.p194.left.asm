  4088bf:	push   %rbp
  4088c0:	mov    %rsp,%rbp
  4088c3:	sub    $0x920,%rsp
  4088ca:	mov    %r12,-0x10(%rbp)
  4088ce:	mov    %rbx,-0x8(%rbp)
  4088d2:	mov    %r13,-0x18(%rbp)
  4088d6:	mov    %rdi,%rax
  4088d9:	mov    %rax,%r12
  4088dc:	mov    %rsi,%rax
  4088df:	mov    %rax,%rbx
  4088e2:	mov    %r12,%rdi
  4088e5:	mov    %rbx,%rsi
  4088e8:	movabs $0x0,%rdx
  4088f2:	movabs $0x1,%rcx
  4088fc:	mov    %ecx,%ecx
  4088fe:	xor    %eax,%eax
  408900:	callq  41b9d0 <p118_rt_borrow_scalar_safe>
  408905:	mov    %rax,%rdi
  408908:	cmp    $0x0,%rdi
  40890f:	je     40894d <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_108_101_102_116_+0x8e>
  408915:	mov    %r12,%rdi
  408918:	mov    %rbx,%rsi
  40891b:	xor    %eax,%eax
  40891d:	callq  4086e9 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_112_49_57_52_46_108_101_102_116_>
  408922:	mov    %rax,%r13
  408925:	mov    %r12,%rdi
  408928:	mov    %rbx,%rsi
  40892b:	xor    %eax,%eax
  40892d:	callq  415580 <p111_rt_sink>
  408932:	mov    %rax,-0x8a0(%rbp)
  408939:	mov    %r13,%rax
  40893c:	mov    -0x10(%rbp),%r12
  408940:	mov    -0x8(%rbp),%rbx
  408944:	mov    -0x18(%rbp),%r13
  408948:	mov    %rbp,%rsp
  40894b:	pop    %rbp
  40894c:	retq   
  40894d:	mov    %r12,%rdi
  408950:	mov    %rbx,%rsi
  408953:	xor    %eax,%eax
  408955:	callq  408614 <p113d_FID_36_112_49_50_56_98_111_114_114_111_119_46_111_119_110_101_100_46_112_49_57_52_46_108_101_102_116_>
  40895a:	mov    %rax,%rdi
  40895d:	mov    %rdi,%rax
  408960:	mov    -0x10(%rbp),%r12
  408964:	mov    -0x8(%rbp),%rbx
  408968:	mov    -0x18(%rbp),%r13
  40896c:	mov    %rbp,%rsp
  40896f:	pop    %rbp
  408970:	retq   
