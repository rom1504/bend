
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402f30 <nx_rt_rebuild2>:
  402f30:	push   %r15
  402f32:	push   %r14
  402f34:	push   %r13
  402f36:	mov    %ecx,%r13d
  402f39:	push   %r12
  402f3b:	mov    %rdi,%r12
  402f3e:	push   %rbp
  402f3f:	movabs $0xffffffffff,%rbp
  402f49:	push   %rbx
  402f4a:	and    %rsi,%rbp
  402f4d:	mov    %edx,%ebx
  402f4f:	lea    0x0(,%rbp,8),%rdx
  402f57:	sub    $0x28,%rsp
  402f5b:	mov    (%rdi),%r14
  402f5e:	mov    0x8(%rdi),%r15
  402f62:	lea    (%r14,%rdx,1),%rax
  402f66:	test   %rsi,%rsi
  402f69:	js     403050 <nx_rt_rebuild2+0x120>
  402f6f:	mov    (%rax),%rax
  402f72:	mov    %rax,0x10(%rsp)
  402f77:	mov    0x8(%r14,%rdx,1),%rax
  402f7c:	mov    %rax,0x18(%rsp)
  402f81:	cmp    $0x310817f,%rbp
  402f88:	jbe    403028 <nx_rt_rebuild2+0xf8>
  402f8e:	lea    (%r14,%rbp,8),%r9
  402f92:	mov    $0x1,%eax
  402f97:	mov    0x10(%rsp,%r13,8),%rdx
  402f9c:	movq   $0xffffffffffffffff,0x18(%r12)
  402fa5:	movl   $0x1,0x20(%r12)
  402fae:	sub    %r13d,%eax
  402fb1:	mov    0x10(%rsp,%rax,8),%rax
  402fb6:	mov    %rax,0x10(%r12)
  402fbb:	mov    %rdx,%rax
  402fbe:	shr    $0x38,%rax
  402fc2:	and    $0x7f,%eax
  402fc5:	cmp    $0x2,%rax
  402fc9:	je     403008 <nx_rt_rebuild2+0xd8>
  402fcb:	mov    %r8,%rax
  402fce:	mov    %rdx,(%r9)
  402fd1:	lea    0x8(%r14,%rbp,8),%r12
  402fd6:	shr    $0x38,%rax
  402fda:	and    $0x7f,%eax
  402fdd:	cmp    $0x2,%rax
  402fe1:	je     403018 <nx_rt_rebuild2+0xe8>
  402fe3:	mov    %rbx,%rax
  402fe6:	mov    %r8,(%r12)
  402fea:	add    $0x28,%rsp
  402fee:	shl    $0x28,%rax
  402ff2:	pop    %rbx
  402ff3:	or     %rbp,%rax
  402ff6:	pop    %rbp
  402ff7:	pop    %r12
  402ff9:	bts    $0x39,%rax
  402ffe:	pop    %r13
  403000:	pop    %r14
  403002:	pop    %r15
  403004:	retq   
  403005:	nopl   (%rax)
  403008:	test   %rdx,%rdx
  40300b:	js     402fcb <nx_rt_rebuild2+0x9b>
  40300d:	jmpq   401640 <nx_rt_rebuild2.cold>
  403012:	nopw   0x0(%rax,%rax,1)
  403018:	test   %r8,%r8
  40301b:	js     402fe3 <nx_rt_rebuild2+0xb3>
  40301d:	jmpq   40166a <nx_rt_rebuild2.cold+0x2a>
  403022:	nopw   0x0(%rax,%rax,1)
  403028:	mov    0x8(%r15),%rbp
  40302c:	test   %rbp,%rbp
  40302f:	je     401685 <nx_rt_rebuild2.cold+0x45>
  403035:	lea    (%r14,%rbp,8),%r9
  403039:	mov    (%r9),%rax
  40303c:	subq   $0x2,0x108(%r15)
  403044:	mov    %rax,0x8(%r15)
  403048:	jmpq   402f92 <nx_rt_rebuild2+0x62>
  40304d:	nopl   (%rax)
  403050:	mov    0x4(%rax),%edx
  403053:	mov    (%rax),%ecx
  403055:	shl    $0x20,%rdx
  403059:	or     %rcx,%rdx
  40305c:	mov    %rdx,%rcx
  40305f:	and    $0xffffff,%edx
  403065:	shr    $0x18,%rcx
  403069:	lea    0x0(,%rcx,8),%rdi
  403071:	lea    (%r14,%rdi,1),%r9
  403075:	lea    0x8(%r14,%rdi,1),%rdi
  40307a:	cmp    $0x1,%rdx
  40307e:	jne    4016cd <nx_rt_rebuild2.cold+0x8d>
  403084:	mov    (%rax),%edx
  403086:	mov    (%r9),%rdx
  403089:	mov    %rdx,0x10(%rsp)
  40308e:	mov    (%rdi),%rdx
  403091:	mov    %rdx,0x18(%rsp)
  403096:	mov    (%r15),%rdx
  403099:	mov    %rdx,(%rax)
  40309c:	mov    0x100(%r15),%rax
  4030a3:	mov    0x3e12f(%rip),%edx        # 4411d8 <KEEP_WORDS>
  4030a9:	mov    %rbp,(%r15)
  4030ac:	add    $0x1,%rax
  4030b0:	mov    %rax,0x100(%r15)
  4030b7:	cmp    %rdx,%rax
  4030ba:	jae    4016a9 <nx_rt_rebuild2.cold+0x69>
  4030c0:	mov    %rcx,%rbp
  4030c3:	jmpq   402f81 <nx_rt_rebuild2+0x51>

Disassembly of section .fini:
