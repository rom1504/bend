
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/specialized-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401651 <nx_rt_rebuild2.cold>:
  401651:	mov    $0x1,%edx
  401656:	mov    %r12,%rsi
  401659:	mov    %r8,0x8(%rsp)
  40165e:	mov    %rdi,(%rsp)
  401662:	callq  401178 <heap_alloc_miss>
  401667:	mov    (%rsp),%rdi
  40166b:	mov    0x8(%rsp),%r8
  401670:	mov    %rax,%r9
  401673:	jmpq   402d54 <nx_rt_rebuild2+0x54>
  401678:	xor    %edx,%edx
  40167a:	mov    %r12,%rsi
  40167d:	mov    %r8,(%rsp)
  401681:	callq  401100 <heap_hand>
  401686:	mov    (%rsp),%r8
  40168a:	jmpq   402e2c <nx_rt_rebuild2+0x12c>
  40168f:	mov    (%r11),%rax
  401692:	mov    %rsi,%rdx
  401695:	mov    %r14,%rcx
  401698:	mov    %r12,%rsi
  40169b:	mov    %r8,0x8(%rsp)
  4016a0:	mov    %rax,0x10(%rsp)
  4016a5:	mov    (%r10),%rax
  4016a8:	mov    %rdi,(%rsp)
  4016ac:	mov    %rax,0x18(%rsp)
  4016b1:	callq  4014c6 <span_fade.constprop.0>
  4016b6:	mov    (%rsp),%rdi
  4016ba:	mov    0x8(%rsp),%r8
  4016bf:	jmpq   402d90 <nx_rt_rebuild2+0x90>

Disassembly of section .fini:
