
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/production-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403020 <nx_rt_take2>:
  403020:	endbr64 
  403024:	push   %rbp
  403025:	mov    %rsp,%rbp
  403028:	sub    $0x20,%rsp
  40302c:	push   %rbx
  40302d:	push   %r12
  40302f:	mov    %rsi,%r12
  403032:	mov    %rdi,%rbx
  403035:	callq  402900 <nx_env>
  40303a:	mov    %r12,%rsi
  40303d:	mov    %rbx,%rdi
  403040:	mov    %rax,%rcx
  403043:	mov    %rdx,%rax
  403046:	mov    %rcx,-0x20(%rbp)
  40304a:	mov    %rax,-0x18(%rbp)
  40304e:	mov    -0x20(%rbp),%rax
  403052:	mov    %rax,-0x10(%rbp)
  403056:	mov    -0x18(%rbp),%rax
  40305a:	mov    %rax,-0x8(%rbp)
  40305e:	mov    0x20(%rdi),%eax
  403061:	cmp    $0x0,%eax
  403064:	mov    %rdi,%rbx
  403067:	sete   %dil
  40306b:	movzbl %dil,%edi
  40306f:	mov    %rsi,%r12
  403072:	lea    0x559e(%rip),%rsi        # 408617 <ERR_TEXT+0x28f>
  403079:	callq  4028e0 <nx_require>
  40307e:	mov    %r12,%rsi
  403081:	mov    %rbx,%rdi
  403084:	mov    %rsi,%rdx
  403087:	mov    %rdi,%rbx
  40308a:	mov    -0x10(%rbp),%rdi
  40308e:	mov    %rsi,%r12
  403091:	mov    -0x8(%rbp),%rsi
  403095:	callq  402950 <nx_id>
  40309a:	mov    %r12,%rsi
  40309d:	cmp    $0x1,%eax
  4030a0:	je     4030ae <nx_rt_take2+0x8e>
  4030a2:	cmp    $0x3,%eax
  4030a5:	je     4030ae <nx_rt_take2+0x8e>
  4030a7:	mov    $0x0,%edi
  4030ac:	jmp    4030b3 <nx_rt_take2+0x93>
  4030ae:	mov    $0x1,%edi
  4030b3:	mov    %rsi,%r12
  4030b6:	lea    0x5581(%rip),%rsi        # 40863e <ERR_TEXT+0x2b6>
  4030bd:	callq  4028e0 <nx_require>
  4030c2:	mov    %r12,%rsi
  4030c5:	mov    %rbx,%rdi
  4030c8:	callq  402fa0 <nx_take2>
  4030cd:	mov    $0x0,%eax
  4030d2:	pop    %r12
  4030d4:	pop    %rbx
  4030d5:	leaveq 
  4030d6:	retq   

Disassembly of section .fini:
