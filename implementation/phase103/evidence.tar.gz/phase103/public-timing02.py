import hashlib,json,subprocess,time
from pathlib import Path
root=Path.cwd(); out=root/'selfhost/build/phase103/public-timing02'; out.mkdir()
source=root/'selfhost/tools/performance/phase77/fixtures/small.bend'; rows=[]
for i in range(3):
 for role in (['old','new'] if i%2==0 else ['new','old']):
  dest=out/f'{role}{i}.c'
  if role=='old': cmd=['python3','-B','selfhost/native.py',str(source),'-o',str(dest)]
  else: cmd=['python3','-B','selfhost/tools/performance/phase86/guard.py','--out',str(out/f'guard{i}'),'--seconds','30','--',str(root/'selfhost/build/phase103/cli06/bend'),str(source),'-o',str(dest)]
  start=time.monotonic(); r=subprocess.run(cmd,capture_output=True); elapsed=time.monotonic()-start
  (out/f'{role}{i}.stdout').write_bytes(r.stdout); (out/f'{role}{i}.stderr').write_bytes(r.stderr)
  assert r.returncode==0,(r.stderr,r.stdout)
  wall=elapsed if role=='old' else json.loads((out/f'guard{i}/process.json').read_text())['wallSeconds']
  rows.append(dict(role=role,round=i,wallSeconds=wall,supervisedWallSeconds=elapsed,command=cmd,sha256=hashlib.sha256(dest.read_bytes()).hexdigest()))
assert len({x['sha256'] for x in rows})==1
(out/'report.json').write_text(json.dumps(dict(complete=True,scope='Small-source public interfaces: old includes its mandatory Python wrapper and guard; new measures direct native process under external guard. Different capture envelopes, no compiler-kernel claim.',rows=rows),indent=2)+'\n')
print([(r['role'],round(r['wallSeconds'],3)) for r in rows])
