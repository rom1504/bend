
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402a20 <nx_rt_rebuild2>:
  402a20:	movabs $0xffffffffff,%r9
  402a2a:	push   %r14
  402a2c:	push   %r13
  402a2e:	and    %rsi,%r9
  402a31:	mov    %edx,%r13d
  402a34:	push   %r12
  402a36:	lea    0x0(,%r9,8),%rdx
  402a3e:	push   %rbp
  402a3f:	mov    %ecx,%ebp
  402a41:	push   %rbx
  402a42:	mov    %rdi,%rbx
  402a45:	sub    $0x20,%rsp
  402a49:	mov    (%rdi),%rdi
  402a4c:	mov    0x8(%rbx),%r12
  402a50:	lea    (%rdi,%rdx,1),%rax
  402a54:	test   %rsi,%rsi
  402a57:	js     402ad8 <nx_rt_rebuild2+0xb8>
  402a59:	mov    (%rax),%rax
  402a5c:	mov    %rax,0x10(%rsp)
  402a61:	mov    0x8(%rdi,%rdx,1),%rax
  402a66:	mov    %rax,0x18(%rsp)
  402a6b:	cmp    $0x310817f,%r9
  402a72:	jbe    402ab0 <nx_rt_rebuild2+0x90>
  402a74:	mov    $0x1,%eax
  402a79:	mov    0x10(%rsp,%rbp,8),%rcx
  402a7e:	mov    %r13d,%edx
  402a81:	mov    %r12,%rsi
  402a84:	sub    %ebp,%eax
  402a86:	movq   $0xffffffffffffffff,0x18(%rbx)
  402a8e:	mov    0x10(%rsp,%rax,8),%rax
  402a93:	movl   $0x1,0x20(%rbx)
  402a9a:	mov    %rax,0x10(%rbx)
  402a9e:	add    $0x20,%rsp
  402aa2:	pop    %rbx
  402aa3:	pop    %rbp
  402aa4:	pop    %r12
  402aa6:	pop    %r13
  402aa8:	pop    %r14
  402aaa:	jmpq   401cc0 <nx_construct2>
  402aaf:	nop
  402ab0:	mov    0x8(%r12),%r9
  402ab5:	test   %r9,%r9
  402ab8:	je     401651 <nx_rt_rebuild2.cold>
  402abe:	mov    (%rdi,%r9,8),%rax
  402ac2:	subq   $0x2,0x108(%r12)
  402acb:	mov    %rax,0x8(%r12)
  402ad0:	jmp    402a74 <nx_rt_rebuild2+0x54>
  402ad2:	nopw   0x0(%rax,%rax,1)
  402ad8:	mov    0x4(%rax),%edx
  402adb:	mov    (%rax),%ecx
  402add:	shl    $0x20,%rdx
  402ae1:	or     %rcx,%rdx
  402ae4:	mov    %rdx,%r14
  402ae7:	and    $0xffffff,%edx
  402aed:	shr    $0x18,%r14
  402af1:	lea    0x0(,%r14,8),%r10
  402af9:	lea    (%rdi,%r10,1),%r11
  402afd:	lea    0x8(%rdi,%r10,1),%r10
  402b02:	cmp    $0x1,%rdx
  402b06:	jne    40168f <nx_rt_rebuild2.cold+0x3e>
  402b0c:	mov    (%rax),%edx
  402b0e:	mov    (%r11),%rdx
  402b11:	mov    %rdx,0x10(%rsp)
  402b16:	mov    (%r10),%rdx
  402b19:	mov    %rdx,0x18(%rsp)
  402b1e:	mov    (%r12),%rdx
  402b22:	mov    %rdx,(%rax)
  402b25:	mov    0x100(%r12),%rax
  402b2d:	mov    0x46a5(%rip),%edx        # 4071d8 <KEEP_WORDS>
  402b33:	mov    %r9,(%r12)
  402b37:	add    $0x1,%rax
  402b3b:	mov    %rax,0x100(%r12)
  402b43:	cmp    %rdx,%rax
  402b46:	jae    401678 <nx_rt_rebuild2.cold+0x27>
  402b4c:	mov    %r14,%r9
  402b4f:	jmpq   402a6b <nx_rt_rebuild2+0x4b>

Disassembly of section .fini:
