
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402090 <nx_string_reverse>:
  402090:	endbr64 
  402094:	push   %rbp
  402095:	mov    %rsp,%rbp
  402098:	sub    $0x38,%rsp
  40209c:	push   %rbx
  40209d:	push   %r12
  40209f:	push   %r13
  4020a1:	push   %r14
  4020a3:	push   %r15
  4020a5:	mov    %rdx,%rbx
  4020a8:	mov    %rsi,%r14
  4020ab:	mov    %rdi,%r12
  4020ae:	callq  404600 <nx_rt_ir_heap>
  4020b3:	mov    %r12,%rdi
  4020b6:	mov    %rax,%r12
  4020b9:	mov    %rdi,%r13
  4020bc:	callq  404670 <nx_rt_ir_alc>
  4020c1:	mov    %r14,%rsi
  4020c4:	mov    %r13,%rdi
  4020c7:	xchg   %rax,%rbx
  4020c9:	mov    %rax,%r15
  4020cc:	nopl   0x0(%rax)
  4020d0:	mov    %rsi,-0x10(%rbp)
  4020d4:	mov    %rsi,%rax
  4020d7:	shr    $0x28,%rax
  4020db:	and    $0xffff,%rax
  4020e1:	cmp    $0x2,%rax
  4020e5:	je     4022f7 <nx_string_reverse+0x267>
  4020eb:	cmp    $0x3,%rax
  4020ef:	jne    4022eb <nx_string_reverse+0x25b>
  4020f5:	movabs $0xffffffffff,%rax
  4020ff:	mov    %rsi,%r13
  402102:	and    %rax,%r13
  402105:	mov    %rsi,%r8
  402108:	shr    $0x3f,%r8
  40210c:	mov    %r8,-0x8(%rbp)
  402110:	cmp    $0x1,%r8
  402114:	je     40212b <nx_string_reverse+0x9b>
  402116:	cmp    $0x310817f,%r13
  40211d:	seta   %al
  402120:	movzbl %al,%eax
  402123:	mov    %r15,%rdx
  402126:	mov    %r13,%r15
  402129:	jmp    402181 <nx_string_reverse+0xf1>
  40212b:	mov    %r13,%rsi
  40212e:	mov    %rdi,%r14
  402131:	callq  4046e0 <nx_rt_ir_view>
  402136:	mov    %r15,%rdx
  402139:	mov    %r14,%rdi
  40213c:	mov    -0x10(%rbp),%rsi
  402140:	mov    -0x8(%rbp),%r8
  402144:	mov    %rax,%rcx
  402147:	and    $0xffffff,%rcx
  40214e:	cmp    $0x1,%rcx
  402152:	sete   %r9b
  402156:	movzbl %r9b,%r9d
  40215a:	mov    %rax,%rcx
  40215d:	shr    $0x18,%rcx
  402161:	cmp    $0x310817f,%rcx
  402168:	seta   %al
  40216b:	movzbl %al,%eax
  40216e:	cmp    $0x0,%r9d
  402172:	mov    %r13,%r15
  402175:	cmovne %rcx,%r13
  402179:	mov    $0x0,%ecx
  40217e:	cmove  %ecx,%eax
  402181:	mov    %r13,-0x30(%rbp)
  402185:	cmp    $0x0,%eax
  402188:	jne    4021b3 <nx_string_reverse+0x123>
  40218a:	mov    %rdi,%r13
  40218d:	callq  403f60 <nx_rt_rebuild2_c3_k0>
  402192:	mov    %r13,%rdi
  402195:	mov    %rax,%r14
  402198:	mov    $0x0,%esi
  40219d:	mov    %rdi,%r13
  4021a0:	callq  4032f0 <nx_rt_fast_field>
  4021a5:	mov    %r14,%rdx
  4021a8:	mov    %r13,%rdi
  4021ab:	mov    %rax,%rsi
  4021ae:	jmpq   4022e3 <nx_string_reverse+0x253>
  4021b3:	mov    %r13,%r14
  4021b6:	shl    $0x3,%r14
  4021ba:	mov    %r12,%rax
  4021bd:	add    %r14,%rax
  4021c0:	mov    %rax,-0x28(%rbp)
  4021c4:	mov    (%r12,%r14,1),%rcx
  4021c8:	mov    %rcx,-0x20(%rbp)
  4021cc:	mov    0x8(%r12,%r14,1),%rsi
  4021d1:	mov    %rsi,-0x18(%rbp)
  4021d5:	cmp    $0x1,%r8
  4021d9:	jne    40222d <nx_string_reverse+0x19d>
  4021db:	mov    (%rbx),%r8
  4021de:	mov    %r15,%r9
  4021e1:	shl    $0x3,%r9
  4021e5:	mov    %r8,(%r12,%r9,1)
  4021e9:	mov    %r15,(%rbx)
  4021ec:	mov    %rdx,%r15
  4021ef:	mov    0x100(%rbx),%rdx
  4021f6:	add    $0x1,%rdx
  4021fa:	mov    %rdx,0x100(%rbx)
  402201:	cmp    $0x8000,%rdx
  402208:	jb     40222a <nx_string_reverse+0x19a>
  40220a:	mov    %rdi,%r13
  40220d:	callq  401c36 <nx_rt_ir_hand0>
  402212:	mov    %r15,%rdx
  402215:	mov    %r13,%rdi
  402218:	mov    -0x30(%rbp),%r13
  40221c:	mov    -0x18(%rbp),%rsi
  402220:	mov    -0x20(%rbp),%rcx
  402224:	mov    -0x28(%rbp),%rax
  402228:	jmp    40222d <nx_string_reverse+0x19d>
  40222a:	mov    %r15,%rdx
  40222d:	mov    %rdx,%r8
  402230:	shr    $0x38,%r8
  402234:	cmp    $0x2,%r8
  402238:	jne    4022cb <nx_string_reverse+0x23b>
  40223e:	mov    (%rbx),%r8
  402241:	cmp    $0x0,%r8
  402245:	je     40226f <nx_string_reverse+0x1df>
  402247:	mov    %r8,%r9
  40224a:	shl    $0x3,%r9
  40224e:	mov    (%r12,%r9,1),%r9
  402252:	mov    %r9,(%rbx)
  402255:	mov    %rdx,%r15
  402258:	mov    0x100(%rbx),%rdx
  40225f:	sub    $0x1,%rdx
  402263:	mov    %rdx,0x100(%rbx)
  40226a:	mov    %r15,%rdx
  40226d:	jmp    402293 <nx_string_reverse+0x203>
  40226f:	mov    %rdx,%r15
  402272:	mov    %rdi,%r13
  402275:	callq  401c25 <nx_rt_ir_alloc0>
  40227a:	mov    %r15,%rdx
  40227d:	mov    %r13,%rdi
  402280:	mov    %rax,%r8
  402283:	mov    -0x30(%rbp),%r13
  402287:	mov    -0x18(%rbp),%rsi
  40228b:	mov    -0x20(%rbp),%rcx
  40228f:	mov    -0x28(%rbp),%rax
  402293:	mov    %r8,%r10
  402296:	shl    $0x3,%r10
  40229a:	movabs $0xffffffffff,%r9
  4022a4:	and    %rdx,%r9
  4022a7:	shl    $0x18,%r9
  4022ab:	or     $0x1,%r9
  4022af:	mov    %r9,(%r12,%r10,1)
  4022b3:	shr    $0x28,%rdx
  4022b7:	shl    $0x28,%rdx
  4022bb:	movabs $0x8000000000000000,%r9
  4022c5:	or     %r9,%rdx
  4022c8:	or     %r8,%rdx
  4022cb:	mov    %rcx,(%r12,%r14,1)
  4022cf:	mov    %rdx,0x8(%rax)
  4022d3:	movabs $0x200030000000000,%rax
  4022dd:	mov    %r13,%rdx
  4022e0:	or     %rax,%rdx
  4022e3:	mov    %rdx,%r15
  4022e6:	jmpq   4020d0 <nx_string_reverse+0x40>
  4022eb:	mov    $0x1,%esi
  4022f0:	callq  402af0 <nx_rt_fail>
  4022f5:	jmp    4022fa <nx_string_reverse+0x26a>
  4022f7:	mov    %r15,%rax
  4022fa:	pop    %r15
  4022fc:	pop    %r14
  4022fe:	pop    %r13
  402300:	pop    %r12
  402302:	pop    %rbx
  402303:	leaveq 
  402304:	retq   

Disassembly of section .fini:
