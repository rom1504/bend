000000000000b360 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_>:
    b360:	push   rbp
    b361:	sub    rsp,0x10
    b365:	mov    rax,rcx
    b368:	mov    QWORD PTR [rsp+0x8],rdx
    b36d:	mov    r8d,r15d
    b370:	test   rsi,rsi
    b373:	je     b894 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x534>
    b379:	mov    r10,rsi
    b37c:	movabs rcx,0xffffffff80
    b386:	movabs r11,0xffff0000000000
    b390:	lea    r15,[rcx+0x7f]
    b394:	mov    QWORD PTR [rsp],r15
    b398:	jmp    b42c <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0xcc>
    b39d:	mov    rdi,r12
    b3a0:	mov    rsi,r13
    b3a3:	mov    edx,0x1
    b3a8:	call   13ff8 <heap_alloc_miss>
    b3ad:	movabs r11,0xffff0000000000
    b3b7:	nop    WORD PTR [rax+rax*1+0x0]
    b3c0:	mov    r9,rbp
    b3c3:	mov    r15,QWORD PTR [rsp]
    b3c7:	movabs rdx,0x200a60000000000
    b3d1:	or     rcx,rdx
    b3d4:	mov    QWORD PTR [r12+rax*8],rcx
    b3d8:	mov    QWORD PTR [r12+rax*8+0x8],rbx
    b3dd:	mov    rbx,rax
    b3e0:	movabs rax,0x200120000000000
    b3ea:	or     rbx,rax
    b3ed:	mov    rax,QWORD PTR [r13+0x8]
    b3f1:	test   rax,rax
    b3f4:	je     b6dd <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x37d>
    b3fa:	mov    rcx,QWORD PTR [r12+rax*8]
    b3fe:	mov    QWORD PTR [r13+0x8],rcx
    b402:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    b40a:	dec    r10
    b40d:	mov    QWORD PTR [r12+rax*8],r9
    b411:	mov    QWORD PTR [r12+rax*8+0x8],rbx
    b416:	movabs rcx,0x200080000000000
    b420:	or     rax,rcx
    b423:	test   r10,r10
    b426:	je     b894 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x534>
    b42c:	mov    rcx,rax
    b42f:	and    rcx,r11
    b432:	movabs rdx,0x80000000000
    b43c:	cmp    rcx,rdx
    b43f:	jne    b8b9 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x559>
    b445:	mov    rdx,rax
    b448:	and    rdx,r15
    b44b:	test   rax,rax
    b44e:	js     b470 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x110>
    b450:	mov    rbp,QWORD PTR [r12+rdx*8]
    b454:	mov    rbx,QWORD PTR [r12+rdx*8+0x8]
    b459:	mov    rcx,rdx
    b45c:	cmp    rcx,0x3108180
    b463:	jae    b4e1 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x181>
    b465:	jmp    b518 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x1b8>
    b46a:	nop    WORD PTR [rax+rax*1+0x0]
    b470:	mov    ecx,DWORD PTR [r12+rdx*8+0x4]
    b475:	mov    esi,DWORD PTR [r12+rdx*8]
    b479:	mov    edi,esi
    b47b:	and    edi,0xffffff
    b481:	cmp    edi,0x1
    b484:	jne    b73a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x3da>
    b48a:	mov    eax,DWORD PTR [r12+rdx*8]
    b48e:	shl    rcx,0x20
    b492:	or     rcx,rsi
    b495:	shr    rcx,0x18
    b499:	mov    rbp,QWORD PTR [r12+rcx*8]
    b49d:	mov    rbx,QWORD PTR [r12+rcx*8+0x8]
    b4a2:	mov    rax,QWORD PTR [r13+0x0]
    b4a6:	mov    QWORD PTR [r12+rdx*8],rax
    b4aa:	mov    QWORD PTR [r13+0x0],rdx
    b4ae:	mov    rax,QWORD PTR [r13+0x100]
    b4b5:	inc    rax
    b4b8:	mov    QWORD PTR [r13+0x100],rax
    b4bf:	cmp    BYTE PTR [rip+0x10c8ca],0x1        # 117d90 <KEEP_WORDS>
    b4c6:	jne    b77b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x41b>
    b4cc:	cmp    rax,0x8000
    b4d2:	jae    b77b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x41b>
    b4d8:	cmp    rcx,0x3108180
    b4df:	jb     b518 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x1b8>
    b4e1:	mov    rax,QWORD PTR [r13+0x8]
    b4e5:	mov    QWORD PTR [r12+rcx*8],rax
    b4e9:	mov    QWORD PTR [r13+0x8],rcx
    b4ed:	mov    rax,QWORD PTR [r13+0x108]
    b4f4:	add    rax,0x2
    b4f8:	mov    QWORD PTR [r13+0x108],rax
    b4ff:	cmp    BYTE PTR [rip+0x10c88a],0x1        # 117d90 <KEEP_WORDS>
    b506:	jne    b71b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x3bb>
    b50c:	cmp    rax,0x8000
    b512:	jae    b71b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x3bb>
    b518:	mov    rax,rbp
    b51b:	shr    rax,0x28
    b51f:	movzx  eax,ax
    b522:	cmp    eax,0xa5
    b527:	je     b560 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x200>
    b529:	cmp    eax,0xa4
    b52e:	jne    b8fc <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x59c>
    b534:	mov    rax,QWORD PTR [r13+0x8]
    b538:	test   rax,rax
    b53b:	je     b6fc <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x39c>
    b541:	mov    rcx,QWORD PTR [r12+rax*8]
    b545:	mov    QWORD PTR [r13+0x8],rcx
    b549:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    b551:	movabs r9,0x100a40000000000
    b55b:	jmp    b40a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0xaa>
    b560:	mov    rax,rbp
    b563:	and    rax,r15
    b566:	test   rbp,rbp
    b569:	js     b58a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x22a>
    b56b:	mov    r9,QWORD PTR [r12+rax*8]
    b56f:	mov    r15d,DWORD PTR [r12+rax*8+0x8]
    b574:	mov    rbp,QWORD PTR [r12+rax*8+0x10]
    b579:	mov    rcx,rax
    b57c:	cmp    rcx,0x3108180
    b583:	jae    b600 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2a0>
    b585:	jmp    b637 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2d7>
    b58a:	mov    ecx,DWORD PTR [r12+rax*8+0x4]
    b58f:	mov    edx,DWORD PTR [r12+rax*8]
    b593:	mov    esi,edx
    b595:	and    esi,0xffffff
    b59b:	cmp    esi,0x1
    b59e:	jne    b826 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x4c6>
    b5a4:	mov    esi,DWORD PTR [r12+rax*8]
    b5a8:	shl    rcx,0x20
    b5ac:	or     rcx,rdx
    b5af:	shr    rcx,0x18
    b5b3:	mov    r9,QWORD PTR [r12+rcx*8]
    b5b7:	mov    r15d,DWORD PTR [r12+rcx*8+0x8]
    b5bc:	mov    rbp,QWORD PTR [r12+rcx*8+0x10]
    b5c1:	mov    rdx,QWORD PTR [r13+0x0]
    b5c5:	mov    QWORD PTR [r12+rax*8],rdx
    b5c9:	mov    QWORD PTR [r13+0x0],rax
    b5cd:	mov    rax,QWORD PTR [r13+0x100]
    b5d4:	inc    rax
    b5d7:	mov    QWORD PTR [r13+0x100],rax
    b5de:	cmp    BYTE PTR [rip+0x10c7ab],0x1        # 117d90 <KEEP_WORDS>
    b5e5:	jne    b86b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x50b>
    b5eb:	cmp    rax,0x8000
    b5f1:	jae    b86b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x50b>
    b5f7:	cmp    rcx,0x3108180
    b5fe:	jb     b637 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2d7>
    b600:	mov    rax,QWORD PTR [r13+0x10]
    b604:	mov    QWORD PTR [r12+rcx*8],rax
    b608:	mov    QWORD PTR [r13+0x10],rcx
    b60c:	mov    rax,QWORD PTR [r13+0x110]
    b613:	add    rax,0x4
    b617:	mov    QWORD PTR [r13+0x110],rax
    b61e:	cmp    BYTE PTR [rip+0x10c76b],0x1        # 117d90 <KEEP_WORDS>
    b625:	jne    b807 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x4a7>
    b62b:	cmp    rax,0x8000
    b631:	jae    b807 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x4a7>
    b637:	mov    rcx,QWORD PTR [r13+0x10]
    b63b:	cmp    DWORD PTR [rsp+0x8],r15d
    b640:	jae    b690 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x330>
    b642:	test   rcx,rcx
    b645:	je     b7a4 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x444>
    b64b:	mov    rax,QWORD PTR [r12+rcx*8]
    b64f:	mov    QWORD PTR [r13+0x10],rax
    b653:	add    QWORD PTR [r13+0x110],0xfffffffffffffffc
    b65b:	mov    QWORD PTR [r12+rcx*8],r15
    b65f:	mov    QWORD PTR [r12+rcx*8+0x8],rbp
    b664:	mov    QWORD PTR [r12+rcx*8+0x10],0x1
    b66d:	mov    rax,QWORD PTR [r13+0x8]
    b671:	test   rax,rax
    b674:	je     b7c6 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x466>
    b67a:	mov    rdx,QWORD PTR [r12+rax*8]
    b67e:	mov    QWORD PTR [r13+0x8],rdx
    b682:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    b68a:	jmp    b3c3 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x63>
    b68f:	nop
    b690:	test   rcx,rcx
    b693:	je     b7e5 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x485>
    b699:	mov    rax,QWORD PTR [r12+rcx*8]
    b69d:	mov    QWORD PTR [r13+0x10],rax
    b6a1:	add    QWORD PTR [r13+0x110],0xfffffffffffffffc
    b6a9:	mov    QWORD PTR [r12+rcx*8],r15
    b6ad:	mov    QWORD PTR [r12+rcx*8+0x8],r9
    b6b2:	mov    QWORD PTR [r12+rcx*8+0x10],0x0
    b6bb:	mov    rax,QWORD PTR [r13+0x8]
    b6bf:	test   rax,rax
    b6c2:	je     b39d <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x3d>
    b6c8:	mov    rdx,QWORD PTR [r12+rax*8]
    b6cc:	mov    QWORD PTR [r13+0x8],rdx
    b6d0:	add    QWORD PTR [r13+0x108],0xfffffffffffffffe
    b6d8:	jmp    b3c0 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x60>
    b6dd:	mov    rdi,r12
    b6e0:	mov    rsi,r13
    b6e3:	mov    edx,0x1
    b6e8:	call   13ff8 <heap_alloc_miss>
    b6ed:	movabs r11,0xffff0000000000
    b6f7:	jmp    b40a <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0xaa>
    b6fc:	mov    rdi,r12
    b6ff:	mov    rsi,r13
    b702:	mov    edx,0x1
    b707:	call   13ff8 <heap_alloc_miss>
    b70c:	movabs r11,0xffff0000000000
    b716:	jmp    b551 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x1f1>
    b71b:	mov    rdi,r12
    b71e:	mov    rsi,r13
    b721:	mov    edx,0x1
    b726:	call   13ed1 <heap_hand>
    b72b:	movabs r11,0xffff0000000000
    b735:	jmp    b518 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x1b8>
    b73a:	shl    rcx,0x20
    b73e:	or     rcx,rsi
    b741:	shr    rcx,0x18
    b745:	mov    rbp,QWORD PTR [r12+rcx*8]
    b749:	mov    rbx,QWORD PTR [r12+rcx*8+0x8]
    b74e:	mov    rdi,r12
    b751:	mov    rsi,r13
    b754:	mov    rdx,rax
    b757:	mov    r15d,r8d
    b75a:	mov    r8d,0x2
    b760:	call   13f62 <span_fade>
    b765:	movabs r11,0xffff0000000000
    b76f:	mov    r8d,r15d
    b772:	mov    r15,QWORD PTR [rsp]
    b776:	jmp    b518 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x1b8>
    b77b:	mov    rdi,r12
    b77e:	mov    rsi,r13
    b781:	xor    edx,edx
    b783:	call   13ed1 <heap_hand>
    b788:	movabs r11,0xffff0000000000
    b792:	cmp    rcx,0x3108180
    b799:	jae    b4e1 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x181>
    b79f:	jmp    b518 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x1b8>
    b7a4:	mov    rdi,r12
    b7a7:	mov    rsi,r13
    b7aa:	mov    edx,0x2
    b7af:	call   13ff8 <heap_alloc_miss>
    b7b4:	movabs r11,0xffff0000000000
    b7be:	mov    rcx,rax
    b7c1:	jmp    b65b <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2fb>
    b7c6:	mov    rdi,r12
    b7c9:	mov    rsi,r13
    b7cc:	mov    edx,0x1
    b7d1:	call   13ff8 <heap_alloc_miss>
    b7d6:	movabs r11,0xffff0000000000
    b7e0:	jmp    b3c3 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x63>
    b7e5:	mov    rdi,r12
    b7e8:	mov    rsi,r13
    b7eb:	mov    edx,0x2
    b7f0:	call   13ff8 <heap_alloc_miss>
    b7f5:	movabs r11,0xffff0000000000
    b7ff:	mov    rcx,rax
    b802:	jmp    b6a9 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x349>
    b807:	mov    rdi,r12
    b80a:	mov    rsi,r13
    b80d:	mov    edx,0x2
    b812:	call   13ed1 <heap_hand>
    b817:	movabs r11,0xffff0000000000
    b821:	jmp    b637 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2d7>
    b826:	shl    rcx,0x20
    b82a:	or     rcx,rdx
    b82d:	shr    rcx,0x18
    b831:	mov    r9,QWORD PTR [r12+rcx*8]
    b835:	mov    r15d,DWORD PTR [r12+rcx*8+0x8]
    b83a:	mov    rax,QWORD PTR [r12+rcx*8+0x10]
    b83f:	mov    rdi,r12
    b842:	mov    rsi,r13
    b845:	mov    rdx,rbp
    b848:	mov    rbp,rax
    b84b:	mov    eax,r8d
    b84e:	mov    r8d,0x3
    b854:	call   13f62 <span_fade>
    b859:	movabs r11,0xffff0000000000
    b863:	mov    r8d,eax
    b866:	jmp    b637 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2d7>
    b86b:	mov    rdi,r12
    b86e:	mov    rsi,r13
    b871:	xor    edx,edx
    b873:	call   13ed1 <heap_hand>
    b878:	movabs r11,0xffff0000000000
    b882:	cmp    rcx,0x3108180
    b889:	jae    b600 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2a0>
    b88f:	jmp    b637 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x2d7>
    b894:	mov    ecx,DWORD PTR [r14-0x8]
    b898:	add    r14,0xfffffffffffffff8
    b89c:	lea    rdx,[rip+0xabbd]        # 16460 <wl_tab>
    b8a3:	mov    rcx,QWORD PTR [rdx+rcx*8]
    b8a7:	mov    r15d,r8d
    b8aa:	mov    edi,0x1
    b8af:	mov    rsi,rax
    b8b2:	add    rsp,0x10
    b8b6:	pop    rbp
    b8b7:	jmp    rcx
    b8b9:	movabs rcx,0x7e00000000000000
    b8c3:	test   rax,rcx
    b8c6:	sete   cl
    b8c9:	cmp    rax,0xffffffffffffffff
    b8cd:	sete   dl
    b8d0:	or     dl,cl
    b8d2:	movabs rcx,0xffffffff80
    b8dc:	and    rcx,rax
    b8df:	cmp    rcx,0x3108180
    b8e6:	setb   cl
    b8e9:	or     cl,dl
    b8eb:	jne    b977 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x617>
    b8f1:	mov    rdi,r12
    b8f4:	mov    rsi,r13
    b8f7:	mov    rdx,rax
    b8fa:	jmp    b972 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x612>
    b8fc:	movabs r14,0x7e00000000000000
    b906:	test   rbp,r14
    b909:	sete   al
    b90c:	cmp    rbp,0xffffffffffffffff
    b910:	sete   cl
    b913:	or     cl,al
    b915:	mov    rax,rbp
    b918:	movabs rdx,0xffffffff80
    b922:	and    rax,rdx
    b925:	cmp    rax,0x3108180
    b92b:	setb   al
    b92e:	or     al,cl
    b930:	jne    b940 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x5e0>
    b932:	mov    rdi,r12
    b935:	mov    rsi,r13
    b938:	mov    rdx,rbp
    b93b:	call   6de0 <term_drop>
    b940:	test   rbx,r14
    b943:	sete   al
    b946:	cmp    rbx,0xffffffffffffffff
    b94a:	sete   cl
    b94d:	or     cl,al
    b94f:	movabs rax,0xffffffff80
    b959:	and    rax,rbx
    b95c:	cmp    rax,0x3108180
    b962:	setb   al
    b965:	or     al,cl
    b967:	jne    b977 <WL_FID_36_100_105_114_101_99_116_46_98_115_116_46_100_111_119_110_+0x617>
    b969:	mov    rdi,r12
    b96c:	mov    rsi,r13
    b96f:	mov    rdx,rbx
    b972:	call   6de0 <term_drop>
    b977:	lea    rdi,[rip+0xffffffffffff6d12]        # 2690 <FID_RESW_T+0x320>
    b97e:	call   13e70 <err_fail>
    b983:	data16 data16 data16 nop WORD PTR cs:[rax+rax*1+0x0]

