
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/fused-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000402880 <nx_rt_fast_take2>:
  402880:	movabs $0xffffffffff,%rax
  40288a:	push   %r12
  40288c:	and    %rsi,%rax
  40288f:	push   %rbp
  402890:	push   %rbx
  402891:	mov    %rdi,%rbx
  402894:	mov    (%rdi),%rdi
  402897:	lea    0x0(,%rax,8),%rcx
  40289f:	mov    0x8(%rbx),%rbp
  4028a3:	lea    (%rdi,%rcx,1),%rdx
  4028a7:	test   %rsi,%rsi
  4028aa:	js     402918 <nx_rt_fast_take2+0x98>
  4028ac:	mov    (%rdx),%rdx
  4028af:	mov    %rdx,0x10(%rbx)
  4028b3:	mov    0x8(%rdi,%rcx,1),%rdx
  4028b8:	mov    %rdx,0x18(%rbx)
  4028bc:	cmp    $0x310817f,%rax
  4028c2:	ja     4028d8 <nx_rt_fast_take2+0x58>
  4028c4:	movl   $0x3,0x20(%rbx)
  4028cb:	xor    %eax,%eax
  4028cd:	pop    %rbx
  4028ce:	pop    %rbp
  4028cf:	pop    %r12
  4028d1:	retq   
  4028d2:	nopw   0x0(%rax,%rax,1)
  4028d8:	mov    0x8(%rbp),%rdx
  4028dc:	mov    %rdx,(%rdi,%rax,8)
  4028e0:	mov    0x48f2(%rip),%edx        # 4071d8 <KEEP_WORDS>
  4028e6:	mov    %rax,0x8(%rbp)
  4028ea:	mov    0x108(%rbp),%rax
  4028f1:	add    $0x2,%rax
  4028f5:	mov    %rax,0x108(%rbp)
  4028fc:	cmp    %rdx,%rax
  4028ff:	jae    40160f <nx_rt_fast_take2.cold>
  402905:	movl   $0x3,0x20(%rbx)
  40290c:	xor    %eax,%eax
  40290e:	pop    %rbx
  40290f:	pop    %rbp
  402910:	pop    %r12
  402912:	retq   
  402913:	nopl   0x0(%rax,%rax,1)
  402918:	mov    0x4(%rdx),%ecx
  40291b:	mov    (%rdx),%r8d
  40291e:	shl    $0x20,%rcx
  402922:	or     %r8,%rcx
  402925:	mov    %rcx,%r12
  402928:	and    $0xffffff,%ecx
  40292e:	shr    $0x18,%r12
  402932:	lea    0x0(,%r12,8),%r8
  40293a:	lea    (%rdi,%r8,1),%r9
  40293e:	lea    0x8(%rdi,%r8,1),%r8
  402943:	cmp    $0x1,%rcx
  402947:	jne    401630 <nx_rt_fast_take2.cold+0x21>
  40294d:	mov    (%rdx),%ecx
  40294f:	mov    (%r9),%rcx
  402952:	mov    %rcx,0x10(%rbx)
  402956:	mov    (%r8),%rcx
  402959:	mov    %rcx,0x18(%rbx)
  40295d:	mov    0x0(%rbp),%rcx
  402961:	mov    %rcx,(%rdx)
  402964:	mov    0x486e(%rip),%edx        # 4071d8 <KEEP_WORDS>
  40296a:	mov    %rax,0x0(%rbp)
  40296e:	mov    0x100(%rbp),%rax
  402975:	add    $0x1,%rax
  402979:	mov    %rax,0x100(%rbp)
  402980:	cmp    %rdx,%rax
  402983:	jae    401621 <nx_rt_fast_take2.cold+0x12>
  402989:	mov    %r12,%rax
  40298c:	jmpq   4028bc <nx_rt_fast_take2+0x3c>

Disassembly of section .fini:
