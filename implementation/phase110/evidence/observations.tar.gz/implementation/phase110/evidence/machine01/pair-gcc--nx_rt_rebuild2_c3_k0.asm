
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403780 <nx_rt_rebuild2_c3_k0>:
  403780:	push   %r13
  403782:	mov    %rsi,%r10
  403785:	mov    %rdx,%r8
  403788:	movabs $0xffffffffff,%r9
  403792:	push   %r12
  403794:	and    %r10,%r9
  403797:	push   %rbp
  403798:	lea    0x0(,%r9,8),%rax
  4037a0:	push   %rbx
  4037a1:	mov    %rdi,%rbx
  4037a4:	sub    $0x28,%rsp
  4037a8:	mov    (%rdi),%rdi
  4037ab:	mov    0x8(%rbx),%rsi
  4037af:	lea    (%rdi,%rax,1),%rdx
  4037b3:	test   %r10,%r10
  4037b6:	js     403820 <nx_rt_rebuild2_c3_k0+0xa0>
  4037b8:	mov    (%rdx),%r12
  4037bb:	mov    0x8(%rdi,%rax,1),%rbp
  4037c0:	cmp    $0x310817f,%r9
  4037c7:	jbe    4037f8 <nx_rt_rebuild2_c3_k0+0x78>
  4037c9:	mov    %rbp,0x10(%rbx)
  4037cd:	mov    %r12,%rcx
  4037d0:	mov    $0x3,%edx
  4037d5:	movq   $0xffffffffffffffff,0x18(%rbx)
  4037dd:	movl   $0x1,0x20(%rbx)
  4037e4:	add    $0x28,%rsp
  4037e8:	pop    %rbx
  4037e9:	pop    %rbp
  4037ea:	pop    %r12
  4037ec:	pop    %r13
  4037ee:	jmpq   401fb0 <nx_construct2>
  4037f3:	nopl   0x0(%rax,%rax,1)
  4037f8:	mov    0x8(%rsi),%r9
  4037fc:	test   %r9,%r9
  4037ff:	je     40188c <nx_rt_rebuild2_c3_k0.cold>
  403805:	mov    (%rdi,%r9,8),%rax
  403809:	subq   $0x2,0x108(%rsi)
  403811:	mov    %rax,0x8(%rsi)
  403815:	jmp    4037c9 <nx_rt_rebuild2_c3_k0+0x49>
  403817:	nopw   0x0(%rax,%rax,1)
  403820:	mov    0x4(%rdx),%eax
  403823:	mov    (%rdx),%ecx
  403825:	shl    $0x20,%rax
  403829:	or     %rcx,%rax
  40382c:	mov    %rax,%r13
  40382f:	and    $0xffffff,%eax
  403834:	shr    $0x18,%r13
  403838:	lea    0x0(,%r13,8),%r11
  403840:	lea    (%rdi,%r11,1),%rbp
  403844:	lea    0x8(%rdi,%r11,1),%r11
  403849:	cmp    $0x1,%rax
  40384d:	jne    4018d2 <nx_rt_rebuild2_c3_k0.cold+0x46>
  403853:	mov    (%rdx),%eax
  403855:	mov    (%rsi),%rax
  403858:	mov    0x0(%rbp),%r12
  40385c:	mov    (%r11),%rbp
  40385f:	mov    %rax,(%rdx)
  403862:	mov    0x100(%rsi),%rax
  403869:	mov    0x3d969(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40386f:	mov    %r9,(%rsi)
  403872:	add    $0x1,%rax
  403876:	mov    %rax,0x100(%rsi)
  40387d:	cmp    %rdx,%rax
  403880:	jae    4018bc <nx_rt_rebuild2_c3_k0.cold+0x30>
  403886:	mov    %r13,%r9
  403889:	jmpq   4037c0 <nx_rt_rebuild2_c3_k0+0x40>

Disassembly of section .fini:
