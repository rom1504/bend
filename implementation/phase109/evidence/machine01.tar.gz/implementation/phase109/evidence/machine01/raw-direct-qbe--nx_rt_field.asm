
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/raw-reverse-kernel/direct-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

00000000004026e0 <nx_rt_field>:
  4026e0:	sub    $0x8,%rsp
  4026e4:	cmpb   $0x0,0x4a95(%rip)        # 407180 <nx_active>
  4026eb:	je     4026f9 <nx_rt_field+0x19>
  4026ed:	lea    0x4aac(%rip),%rdx        # 4071a0 <nx_context>
  4026f4:	cmp    %rdx,%rdi
  4026f7:	je     402708 <nx_rt_field+0x28>
  4026f9:	lea    0x1933(%rip),%rdi        # 404033 <_IO_stdin_used+0x33>
  402700:	callq  4019f0 <err_fail>
  402705:	nopl   (%rax)
  402708:	mov    %esi,%ecx
  40270a:	cmp    $0x1,%ecx
  40270d:	jbe    402720 <nx_rt_field+0x40>
  40270f:	lea    0x1c32(%rip),%rdi        # 404348 <_IO_stdin_used+0x348>
  402716:	callq  4019f0 <err_fail>
  40271b:	nopl   0x0(%rax,%rax,1)
  402720:	mov    $0x1,%eax
  402725:	mov    0x4a95(%rip),%esi        # 4071c0 <nx_context+0x20>
  40272b:	shl    %cl,%eax
  40272d:	test   %eax,%esi
  40272f:	je     40270f <nx_rt_field+0x2f>
  402731:	not    %eax
  402733:	add    $0x2,%rcx
  402737:	and    %esi,%eax
  402739:	mov    %eax,0x4a81(%rip)        # 4071c0 <nx_context+0x20>
  40273f:	mov    (%rdx,%rcx,8),%rax
  402743:	movq   $0xffffffffffffffff,(%rdx,%rcx,8)
  40274b:	add    $0x8,%rsp
  40274f:	retq   

Disassembly of section .fini:
