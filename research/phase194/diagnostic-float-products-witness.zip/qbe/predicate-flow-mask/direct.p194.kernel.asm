  406a60:	endbr64 
  406a64:	push   %rbp
  406a65:	mov    %rsp,%rbp
  406a68:	mov    %rcx,%rax
  406a6b:	mov    %rax,%rcx
  406a6e:	xchg   %ax,%ax
  406a70:	cmp    $0x0,%rsi
  406a74:	je     406ad0 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x70>
  406a76:	mov    %rcx,%rax
  406a79:	and    $0x7,%rax
  406a7d:	cmp    $0x3,%rax
  406a81:	setb   %al
  406a84:	movzbl %al,%eax
  406a87:	xor    $0x1,%eax
  406a8a:	mov    $0x1,%edi
  406a8f:	mov    $0x0,%eax
  406a94:	cmove  %rdi,%rax
  406a98:	neg    %eax
  406a9a:	add    $0x0,%eax
  406a9d:	mov    %eax,%edi
  406a9f:	mov    %rdx,%rax
  406aa2:	mov    %ecx,%edx
  406aa4:	imul   $0x3,%edx,%ecx
  406aa7:	mov    %ecx,%ecx
  406aa9:	add    $0x1,%ecx
  406aac:	mov    %ecx,%ecx
  406aae:	mov    %eax,%eax
  406ab0:	xor    %rax,%rdx
  406ab3:	and    %rdi,%rcx
  406ab6:	mov    $0xffffffff,%r8d
  406abc:	xor    %r8,%rdi
  406abf:	and    %rdi,%rdx
  406ac2:	or     %rdx,%rcx
  406ac5:	sub    $0x1,%rsi
  406ac9:	add    $0x1,%eax
  406acc:	mov    %eax,%edx
  406ace:	jmp    406a70 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_107_101_114_110_101_108_+0x10>
  406ad0:	mov    %rcx,%rax
  406ad3:	leaveq 
  406ad4:	retq   
  406ad5:	data16 nopw %cs:0x0(%rax,%rax,1)
