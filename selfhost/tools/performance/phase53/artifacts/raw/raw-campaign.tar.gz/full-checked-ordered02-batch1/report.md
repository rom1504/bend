# Generated-program execution

Status: **measured**; 15/15 selected cases complete.

Times include export invocation, exact result validation and checksum work; import and first calls are separate.
The budget is a maximum wall time, not a request to pad a short run. Short warmups are screens, not steady-state evidence.

| Case | Paired rounds | Baseline ms | Candidate ms | TypeScript ms | Candidate / TS (or baseline / TS) |
|---|---:|---:|---:|---:|---:|
| variation-editdist-0-17 | 5/5 | 1.61721 | 1.39074 | 1.24149 | 1.120× |
| variation-editdist-3-123 | 5/5 | 13.0441 | 11.109 | 9.90398 | 1.122× |
| variation-lexer-6-17 | 5/5 | 0.430701 | 0.41515 | 0.403485 | 1.029× |
| variation-lexer-10-123 | 5/5 | 6.98527 | 6.75939 | 6.73231 | 1.004× |
| variation-tree-bitonic-6-17 | 5/5 | 0.0369169 | 0.0369486 | 0.0368991 | 1.001× |
| variation-tree-bitonic-9-123 | 5/5 | 0.691182 | 0.690405 | 0.698072 | 0.989× |
| variation-symreg-4-17 | 5/5 | 0.641444 | 0.558546 | 0.553418 | 1.009× |
| variation-symreg-7-123 | 5/5 | 2.24363 | 1.87496 | 1.89452 | 0.990× |
| variation-local-fold-128-0 | 5/5 | 0.0014553 | 0.00146623 | 0.00143757 | 1.020× |
| variation-local-fold-8192-123 | 5/5 | 0.134889 | 0.127947 | 0.116739 | 1.096× |
| variation-mandelbrot-grid-4-7 | 5/5 | 0.0332039 | 0.0292281 | 0.0152876 | 1.912× |
| variation-mandelbrot-grid-5-31 | 5/5 | 0.413834 | 0.367147 | 0.233141 | 1.575× |
| variation-ray-active-64-2440 | 5/5 | 0.468472 | 0.413236 | 0.302926 | 1.364× |
| variation-ray-active-256-2240 | 5/5 | 2.0153 | 1.6965 | 1.24437 | 1.363× |
| coverage-closures-64 | 5/5 | 0.00595963 | 0.00555877 | 0.00558683 | 0.995× |

Missing, failed and partial samples remain in report.json; incomplete cases have no comparison ratio.
Output agreement on these fixed inputs is not a full conformance gate. No historical timing is used as a denominator.
