
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/specialized-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401df0 <nx_list_reverse>:
  401df0:	endbr64 
  401df4:	push   %rbp
  401df5:	mov    %rsp,%rbp
  401df8:	push   %rbx
  401df9:	push   %r12
  401dfb:	mov    %rdx,%rax
  401dfe:	mov    %rax,%rdx
  401e01:	data16 nopw %cs:0x0(%rax,%rax,1)
  401e0c:	nopl   0x0(%rax)
  401e10:	mov    %rsi,%rax
  401e13:	shr    $0x28,%rax
  401e17:	and    $0xffff,%rax
  401e1d:	cmp    $0x0,%rax
  401e21:	je     401e5b <nx_list_reverse+0x6b>
  401e23:	cmp    $0x1,%rax
  401e27:	jne    401e4f <nx_list_reverse+0x5f>
  401e29:	mov    %rdi,%rbx
  401e2c:	callq  4035a0 <nx_rt_rebuild2_c1_k0>
  401e31:	mov    %rbx,%rdi
  401e34:	mov    %rax,%r12
  401e37:	mov    $0x0,%esi
  401e3c:	mov    %rdi,%rbx
  401e3f:	callq  402ed0 <nx_rt_fast_field>
  401e44:	mov    %r12,%rdx
  401e47:	mov    %rbx,%rdi
  401e4a:	mov    %rax,%rsi
  401e4d:	jmp    401e10 <nx_list_reverse+0x20>
  401e4f:	mov    $0x1,%esi
  401e54:	callq  4026d0 <nx_rt_fail>
  401e59:	jmp    401e5e <nx_list_reverse+0x6e>
  401e5b:	mov    %rdx,%rax
  401e5e:	pop    %r12
  401e60:	pop    %rbx
  401e61:	leaveq 
  401e62:	retq   

Disassembly of section .fini:
