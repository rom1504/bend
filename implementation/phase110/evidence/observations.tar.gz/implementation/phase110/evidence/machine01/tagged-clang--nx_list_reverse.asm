
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	push   %r14
  401c02:	push   %rbx
  401c03:	push   %rax
  401c04:	mov    %rdx,%r14
  401c07:	mov    %rdi,%rbx
  401c0a:	nopw   0x0(%rax,%rax,1)
  401c10:	mov    %rsi,%rax
  401c13:	shr    $0x28,%rax
  401c17:	cmp    $0x1,%ax
  401c1b:	jne    401c41 <nx_list_reverse+0x41>
  401c1d:	mov    %rbx,%rdi
  401c20:	mov    $0x1,%edx
  401c25:	xor    %ecx,%ecx
  401c27:	mov    %r14,%r8
  401c2a:	callq  402d10 <nx_rt_rebuild2>
  401c2f:	mov    %rax,%r14
  401c32:	mov    %rbx,%rdi
  401c35:	xor    %esi,%esi
  401c37:	callq  402cf0 <nx_rt_fast_field>
  401c3c:	mov    %rax,%rsi
  401c3f:	jmp    401c10 <nx_list_reverse+0x10>
  401c41:	movzwl %ax,%eax
  401c44:	test   %eax,%eax
  401c46:	jne    401c53 <nx_list_reverse+0x53>
  401c48:	mov    %r14,%rax
  401c4b:	add    $0x8,%rsp
  401c4f:	pop    %rbx
  401c50:	pop    %r14
  401c52:	retq   
  401c53:	mov    %rbx,%rdi
  401c56:	mov    $0x1,%esi
  401c5b:	add    $0x8,%rsp
  401c5f:	pop    %rbx
  401c60:	pop    %r14
  401c62:	jmpq   402540 <nx_rt_fail>

Disassembly of section .fini:
