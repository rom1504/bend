#!/usr/bin/env python3
"""Bind saved checked04 bytes plus retained TypeScript bytes; execute nothing."""
import argparse, copy, json, shutil, sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[3]
TOOLS = ROOT / 'selfhost/tools/performance/programs'
sys.path.insert(0, str(TOOLS))
from run import load_bundle, relative_path, verify
from support import identity, save

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--candidate', type=Path, default=ROOT/'selfhost/build/phase44/full-preparation04/manifest.json')
p.add_argument('--reference', type=Path, default=ROOT/'selfhost/tools/performance/phase44/baseline/manifest.json')
p.add_argument('--catalog', type=Path, default=ROOT/'selfhost/tools/performance/phase37/catalog.json')
p.add_argument('--out', type=Path, required=True)
a = p.parse_args()
out = a.out.resolve(); out.mkdir(parents=True, exist_ok=False)
catalog = json.loads(a.catalog.read_text()); catalog_hash = identity(a.catalog)['sha256']
inputs = [identity(f) for f in [__file__, TOOLS/'run.py', TOOLS/'support.py', a.catalog]]
candidate = load_bundle(a.candidate, catalog, catalog_hash, catalog['cases'], ['candidate'], inputs, out/'acquisition/checked04')
reference = load_bundle(a.reference, catalog, catalog_hash, catalog['cases'], ['baseline', 'typescript'], inputs, out/'acquisition/reference')
roles = {'baseline': copy.deepcopy(candidate['roles']['candidate']), 'typescript': reference['roles']['typescript']}
assert roles['baseline']['compiler']['kind'] == 'checked-development-attempt'
assert roles['baseline']['compiler']['api']['sha256'] == '0d3325425139c59ac81c4f1bca19fa09e9f977062aa3b202c0ef1c8c7b56b0ea'
roles['baseline']['label'] = 'Phase44 checked04 saved outputs (prototype control; no new compilation)'
cases = []
for case in catalog['cases']:
    row = dict(id=case['id'], sourceSha256=case['source']['sha256'], point=case['point'], modules={})
    for role, bundle, previous in [('baseline', candidate, 'candidate'), ('typescript', reference, 'typescript')]:
        item = bundle['points'][case['id']][previous]
        source = Path(item['resolved']); verify(source, item)
        name = 'modules/' + role + '-' + item['sha256'] + '.mjs'
        target = relative_path(out, name); target.parent.mkdir(parents=True, exist_ok=True)
        if not target.exists(): shutil.copyfile(source, target)
        entry = verify(target, item); entry['path'] = name; row['modules'][role] = entry
    cases.append(row)
for item in inputs: verify(item['path'], item)
shutil.copyfile(__file__, out/'consumed-bind-prototype-baseline.py')
save(out/'derivation.json', dict(kind='phase44-prototype-control-binding', complete=True,
    scope='Exact saved checked04 candidate modules relabeled baseline, with unchanged retained TypeScript modules. Data-only binding; no new compilation, acquisition or execution.', inputs=inputs, cases=len(cases)))
receipt = identity(out/'derivation.json'); receipt['path'] = 'derivation.json'
save(out/'manifest.json', dict(kind='bend-program-bundle', schemaVersion=1, complete=True,
    upstreamCommit=catalog['upstreamCommit'], catalogSha256=catalog_hash, roles=roles, cases=cases, provenance=receipt))
print(json.dumps(dict(complete=True, cases=len(cases), manifest=str(out/'manifest.json'))))
