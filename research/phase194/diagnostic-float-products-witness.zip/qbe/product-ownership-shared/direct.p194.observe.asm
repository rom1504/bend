  406ed0:	endbr64 
  406ed4:	push   %rbp
  406ed5:	mov    %rsp,%rbp
  406ed8:	push   %rbx
  406ed9:	push   %r12
  406edb:	mov    $0x1,%ecx
  406ee0:	mov    $0x0,%edx
  406ee5:	mov    %rsi,%r12
  406ee8:	mov    %rdi,%rbx
  406eeb:	callq  415270 <p118_rt_borrow_scalar_safe>
  406ef0:	mov    %r12,%rsi
  406ef3:	mov    %rbx,%rdi
  406ef6:	cmp    $0x0,%rax
  406efa:	jne    406f03 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x33>
  406efc:	callq  406cf0 <p113d_FID_36_112_49_50_56_98_111_114_114_111_119_46_111_119_110_101_100_46_112_49_57_52_46_111_98_115_101_114_118_101_>
  406f01:	jmp    406f1f <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_111_98_115_101_114_118_101_+0x4f>
  406f03:	mov    %rsi,%r12
  406f06:	mov    %rdi,%rbx
  406f09:	callq  406d40 <p113d_FID_36_112_49_49_56_98_111_114_114_111_119_46_114_101_97_100_46_112_49_57_52_46_111_98_115_101_114_118_101_>
  406f0e:	mov    %r12,%rsi
  406f11:	mov    %rbx,%rdi
  406f14:	mov    %rax,%rbx
  406f17:	callq  40ee20 <p111_rt_sink>
  406f1c:	mov    %rbx,%rax
  406f1f:	pop    %r12
  406f21:	pop    %rbx
  406f22:	leaveq 
  406f23:	retq   
  406f24:	data16 nopw %cs:0x0(%rax,%rax,1)
  406f2f:	nop
