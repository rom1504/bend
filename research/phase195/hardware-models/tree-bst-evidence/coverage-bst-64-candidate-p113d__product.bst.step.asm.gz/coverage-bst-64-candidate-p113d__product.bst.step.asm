0000000000408bff <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_>:
  408bff:	push   rbp
  408c00:	mov    rbp,rsp
  408c03:	sub    rsp,0x990
  408c0a:	mov    QWORD PTR [rbp-0x10],r12
  408c0e:	mov    QWORD PTR [rbp-0x8],rbx
  408c12:	mov    QWORD PTR [rbp-0x18],r13
  408c16:	mov    QWORD PTR [rbp-0x20],r14
  408c1a:	mov    QWORD PTR [rbp-0x28],r15
  408c1e:	mov    rax,rdi
  408c21:	mov    r12,rax
  408c24:	mov    rax,rsi
  408c27:	mov    QWORD PTR [rbp-0x30],rax
  408c2b:	mov    rax,rdx
  408c2e:	mov    r15,rax
  408c31:	mov    rax,rcx
  408c34:	mov    rsi,rax
  408c37:	mov    rax,r8
  408c3a:	mov    rbx,rax
  408c3d:	mov    rdi,rsi
  408c40:	shr    rdi,0x28
  408c44:	and    rdi,0xffff
  408c4b:	movabs r11,0xa4
  408c55:	cmp    rdi,r11
  408c58:	jne    408c95 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x96>
  408c5e:	movabs r10,0x100a40000000000
  408c68:	mov    r11,QWORD PTR [rbp-0x30]
  408c6c:	mov    QWORD PTR [r11],r10
  408c6f:	mov    r10,rbx
  408c72:	mov    r11,QWORD PTR [rbp-0x30]
  408c76:	mov    QWORD PTR [r11+0x8],r10
  408c7a:	xor    eax,eax
  408c7c:	mov    r12,QWORD PTR [rbp-0x10]
  408c80:	mov    rbx,QWORD PTR [rbp-0x8]
  408c84:	mov    r13,QWORD PTR [rbp-0x18]
  408c88:	mov    r14,QWORD PTR [rbp-0x20]
  408c8c:	mov    r15,QWORD PTR [rbp-0x28]
  408c90:	mov    rsp,rbp
  408c93:	pop    rbp
  408c94:	ret    
  408c95:	mov    rdi,rsi
  408c98:	shr    rdi,0x28
  408c9c:	and    rdi,0xffff
  408ca3:	movabs r11,0xa5
  408cad:	cmp    rdi,r11
  408cb0:	jne    408e7f <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x280>
  408cb6:	mov    r10,r12
  408cb9:	mov    QWORD PTR [rsp+0x18],r10
  408cbe:	mov    r10,rsi
  408cc1:	mov    QWORD PTR [rsp+0x20],r10
  408cc6:	lea    r10,[rbp-0x850]
  408ccd:	mov    QWORD PTR [rsp+0x28],r10
  408cd2:	mov    rdi,QWORD PTR [rsp+0x18]
  408cd7:	mov    rsi,QWORD PTR [rsp+0x20]
  408cdc:	mov    rdx,QWORD PTR [rsp+0x28]
  408ce1:	xor    eax,eax
  408ce3:	call   41de20 <p125_rt_take3>
  408ce8:	mov    QWORD PTR [rbp-0x8d0],rax
  408cef:	lea    r10,[rbp-0x850]
  408cf6:	mov    r14,QWORD PTR [r10]
  408cf9:	lea    r10,[rbp-0x850]
  408d00:	mov    rdi,QWORD PTR [r10+0x8]
  408d04:	lea    r10,[rbp-0x850]
  408d0b:	mov    r13,QWORD PTR [r10+0x10]
  408d0f:	mov    r15d,r15d
  408d12:	mov    esi,edi
  408d14:	mov    r11,rsi
  408d17:	mov    rsi,r15
  408d1a:	cmp    rsi,r11
  408d1d:	setb   sil
  408d21:	movzx  esi,sil
  408d25:	mov    r10,rsi
  408d28:	test   r10d,r10d
  408d2b:	je     408dc4 <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x1c5>
  408d31:	lea    r10,[rbp-0x918]
  408d38:	mov    r11,rdi
  408d3b:	mov    QWORD PTR [r10],r11
  408d3e:	lea    r10,[rbp-0x918]
  408d45:	mov    r11,r13
  408d48:	mov    QWORD PTR [r10+0x8],r11
  408d4c:	lea    r10,[rbp-0x918]
  408d53:	movabs r11,0x1
  408d5d:	mov    QWORD PTR [r10+0x10],r11
  408d61:	mov    rdi,r12
  408d64:	movabs rsi,0xa6
  408d6e:	mov    esi,esi
  408d70:	lea    rdx,[rbp-0x918]
  408d77:	xor    eax,eax
  408d79:	call   41dd50 <p125_rt_ctor3>
  408d7e:	mov    rdi,rax
  408d81:	lea    r10,[rbp-0x918]
  408d88:	mov    r11,rdi
  408d8b:	mov    QWORD PTR [r10],r11
  408d8e:	lea    r10,[rbp-0x918]
  408d95:	mov    r11,rbx
  408d98:	mov    QWORD PTR [r10+0x8],r11
  408d9c:	mov    rdi,r12
  408d9f:	movabs rsi,0x12
  408da9:	mov    esi,esi
  408dab:	lea    rdx,[rbp-0x918]
  408db2:	xor    eax,eax
  408db4:	call   41dad0 <p125_rt_ctor2>
  408db9:	mov    rdi,rax
  408dbc:	mov    r13,r14
  408dbf:	jmp    408e4f <p113d_FID_36_112_114_111_100_117_99_116_46_98_115_116_46_115_116_101_112_+0x250>
  408dc4:	lea    r10,[rbp-0x918]
  408dcb:	mov    r11,rdi
  408dce:	mov    QWORD PTR [r10],r11
  408dd1:	lea    r10,[rbp-0x918]
  408dd8:	mov    r11,r14
  408ddb:	mov    QWORD PTR [r10+0x8],r11
  408ddf:	lea    r10,[rbp-0x918]
  408de6:	movabs r11,0x0
  408df0:	mov    QWORD PTR [r10+0x10],r11
  408df4:	mov    rdi,r12
  408df7:	movabs rsi,0xa6
  408e01:	mov    esi,esi
  408e03:	lea    rdx,[rbp-0x918]
  408e0a:	xor    eax,eax
  408e0c:	call   41dd50 <p125_rt_ctor3>
  408e11:	mov    rdi,rax
  408e14:	lea    r10,[rbp-0x918]
  408e1b:	mov    r11,rdi
  408e1e:	mov    QWORD PTR [r10],r11
  408e21:	lea    r10,[rbp-0x918]
  408e28:	mov    r11,rbx
  408e2b:	mov    QWORD PTR [r10+0x8],r11
  408e2f:	mov    rdi,r12
  408e32:	movabs rsi,0x12
  408e3c:	mov    esi,esi
  408e3e:	lea    rdx,[rbp-0x918]
  408e45:	xor    eax,eax
  408e47:	call   41dad0 <p125_rt_ctor2>
  408e4c:	mov    rdi,rax
  408e4f:	mov    r10,r13
  408e52:	mov    r11,QWORD PTR [rbp-0x30]
  408e56:	mov    QWORD PTR [r11],r10
  408e59:	mov    r10,rdi
  408e5c:	mov    r11,QWORD PTR [rbp-0x30]
  408e60:	mov    QWORD PTR [r11+0x8],r10
  408e64:	xor    eax,eax
  408e66:	mov    r12,QWORD PTR [rbp-0x10]
  408e6a:	mov    rbx,QWORD PTR [rbp-0x8]
  408e6e:	mov    r13,QWORD PTR [rbp-0x18]
  408e72:	mov    r14,QWORD PTR [rbp-0x20]
  408e76:	mov    r15,QWORD PTR [rbp-0x28]
  408e7a:	mov    rsp,rbp
  408e7d:	pop    rbp
  408e7e:	ret    
  408e7f:	mov    rdi,r12
  408e82:	movabs rsi,0x4
  408e8c:	mov    esi,esi
  408e8e:	xor    eax,eax
  408e90:	call   4185b0 <p111_rt_fail>
  408e95:	mov    QWORD PTR [rbp-0x8d0],rax
  408e9c:	movabs r10,0x0
  408ea6:	mov    r11,QWORD PTR [rbp-0x30]
  408eaa:	mov    QWORD PTR [r11],r10
  408ead:	movabs r10,0x0
  408eb7:	mov    r11,QWORD PTR [rbp-0x30]
  408ebb:	mov    QWORD PTR [r11+0x8],r10
  408ebf:	xor    eax,eax
  408ec1:	mov    r12,QWORD PTR [rbp-0x10]
  408ec5:	mov    rbx,QWORD PTR [rbp-0x8]
  408ec9:	mov    r13,QWORD PTR [rbp-0x18]
  408ecd:	mov    r14,QWORD PTR [rbp-0x20]
  408ed1:	mov    r15,QWORD PTR [rbp-0x28]
  408ed5:	mov    rsp,rbp
  408ed8:	pop    rbp
  408ed9:	ret    

