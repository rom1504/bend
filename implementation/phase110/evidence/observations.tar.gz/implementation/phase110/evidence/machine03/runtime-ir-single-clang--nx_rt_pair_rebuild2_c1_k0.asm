
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/stored-build01/runtime-ir-single-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403a30 <nx_rt_pair_rebuild2_c1_k0>:
  403a30:	push   %r15
  403a32:	push   %r14
  403a34:	push   %r13
  403a36:	push   %r12
  403a38:	mov    %rdx,%r12
  403a3b:	push   %rbp
  403a3c:	push   %rbx
  403a3d:	movabs $0xffffffffff,%rbx
  403a47:	and    %rsi,%rbx
  403a4a:	lea    0x0(,%rbx,8),%rdx
  403a52:	sub    $0x18,%rsp
  403a56:	mov    (%rdi),%rbp
  403a59:	mov    0x8(%rdi),%r15
  403a5d:	lea    0x0(%rbp,%rdx,1),%rax
  403a62:	test   %rsi,%rsi
  403a65:	js     403b20 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  403a6b:	mov    (%rax),%r14
  403a6e:	mov    0x8(%rbp,%rdx,1),%r13
  403a73:	cmp    $0x310817f,%rbx
  403a7a:	jbe    403af0 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  403a7c:	lea    0x0(%rbp,%rbx,8),%r8
  403a81:	mov    %r14,%rax
  403a84:	shr    $0x38,%rax
  403a88:	and    $0x7f,%eax
  403a8b:	cmp    $0x2,%rax
  403a8f:	je     403ad0 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403a91:	mov    %r12,%rax
  403a94:	mov    %r14,(%r8)
  403a97:	lea    0x8(%rbp,%rbx,8),%r14
  403a9c:	shr    $0x38,%rax
  403aa0:	and    $0x7f,%eax
  403aa3:	cmp    $0x2,%rax
  403aa7:	je     403ae0 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  403aa9:	movabs $0x200010000000000,%rax
  403ab3:	mov    %r12,(%r14)
  403ab6:	mov    %r13,%rdx
  403ab9:	add    $0x18,%rsp
  403abd:	or     %rbx,%rax
  403ac0:	pop    %rbx
  403ac1:	pop    %rbp
  403ac2:	pop    %r12
  403ac4:	pop    %r13
  403ac6:	pop    %r14
  403ac8:	pop    %r15
  403aca:	retq   
  403acb:	nopl   0x0(%rax,%rax,1)
  403ad0:	test   %r14,%r14
  403ad3:	js     403a91 <nx_rt_pair_rebuild2_c1_k0+0x61>
  403ad5:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  403ada:	nopw   0x0(%rax,%rax,1)
  403ae0:	test   %r12,%r12
  403ae3:	js     403aa9 <nx_rt_pair_rebuild2_c1_k0+0x79>
  403ae5:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  403aea:	nopw   0x0(%rax,%rax,1)
  403af0:	mov    0x8(%r15),%rbx
  403af4:	test   %rbx,%rbx
  403af7:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  403afd:	lea    0x0(%rbp,%rbx,8),%r8
  403b02:	mov    (%r8),%rax
  403b05:	subq   $0x2,0x108(%r15)
  403b0d:	mov    %rax,0x8(%r15)
  403b11:	jmpq   403a81 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403b16:	nopw   %cs:0x0(%rax,%rax,1)
  403b20:	mov    0x4(%rax),%edx
  403b23:	mov    (%rax),%ecx
  403b25:	shl    $0x20,%rdx
  403b29:	or     %rcx,%rdx
  403b2c:	mov    %rdx,%rcx
  403b2f:	and    $0xffffff,%edx
  403b35:	shr    $0x18,%rcx
  403b39:	lea    0x8(,%rcx,8),%rdi
  403b41:	lea    0x0(%rbp,%rdi,1),%r8
  403b46:	lea    -0x8(%rbp,%rdi,1),%rdi
  403b4b:	cmp    $0x1,%rdx
  403b4f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403b55:	mov    (%rax),%edx
  403b57:	mov    (%r15),%rdx
  403b5a:	mov    (%rdi),%r14
  403b5d:	mov    (%r8),%r13
  403b60:	mov    %rdx,(%rax)
  403b63:	mov    0x100(%r15),%rax
  403b6a:	mov    0x3e668(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403b70:	mov    %rbx,(%r15)
  403b73:	add    $0x1,%rax
  403b77:	mov    %rax,0x100(%r15)
  403b7e:	cmp    %rdx,%rax
  403b81:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403b87:	mov    %rcx,%rbx
  403b8a:	jmpq   403a73 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
