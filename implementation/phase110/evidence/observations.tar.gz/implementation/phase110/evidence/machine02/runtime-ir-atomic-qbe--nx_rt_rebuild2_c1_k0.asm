
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/runtime-ir-atomic-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403ba0 <nx_rt_rebuild2_c1_k0>:
  403ba0:	push   %r15
  403ba2:	push   %r14
  403ba4:	push   %r13
  403ba6:	push   %r12
  403ba8:	mov    %rdx,%r12
  403bab:	push   %rbp
  403bac:	mov    %rdi,%rbp
  403baf:	push   %rbx
  403bb0:	movabs $0xffffffffff,%rbx
  403bba:	and    %rsi,%rbx
  403bbd:	lea    0x0(,%rbx,8),%rdx
  403bc5:	sub    $0x18,%rsp
  403bc9:	mov    (%rdi),%r13
  403bcc:	mov    0x8(%rdi),%r15
  403bd0:	lea    0x0(%r13,%rdx,1),%rax
  403bd5:	test   %rsi,%rsi
  403bd8:	js     403ca0 <nx_rt_rebuild2_c1_k0+0x100>
  403bde:	mov    (%rax),%r14
  403be1:	mov    0x8(%r13,%rdx,1),%r9
  403be6:	cmp    $0x310817f,%rbx
  403bed:	jbe    403c78 <nx_rt_rebuild2_c1_k0+0xd8>
  403bf3:	lea    0x0(%r13,%rbx,8),%r8
  403bf8:	mov    %r14,%rax
  403bfb:	mov    %r9,0x10(%rbp)
  403bff:	shr    $0x38,%rax
  403c03:	movq   $0xffffffffffffffff,0x18(%rbp)
  403c0b:	and    $0x7f,%eax
  403c0e:	movl   $0x1,0x20(%rbp)
  403c15:	cmp    $0x2,%rax
  403c19:	je     403c58 <nx_rt_rebuild2_c1_k0+0xb8>
  403c1b:	mov    %r12,%rax
  403c1e:	mov    %r14,(%r8)
  403c21:	lea    0x8(%r13,%rbx,8),%rbp
  403c26:	shr    $0x38,%rax
  403c2a:	and    $0x7f,%eax
  403c2d:	cmp    $0x2,%rax
  403c31:	je     403c68 <nx_rt_rebuild2_c1_k0+0xc8>
  403c33:	movabs $0x200010000000000,%rax
  403c3d:	mov    %r12,0x0(%rbp)
  403c41:	add    $0x18,%rsp
  403c45:	or     %rbx,%rax
  403c48:	pop    %rbx
  403c49:	pop    %rbp
  403c4a:	pop    %r12
  403c4c:	pop    %r13
  403c4e:	pop    %r14
  403c50:	pop    %r15
  403c52:	retq   
  403c53:	nopl   0x0(%rax,%rax,1)
  403c58:	test   %r14,%r14
  403c5b:	js     403c1b <nx_rt_rebuild2_c1_k0+0x7b>
  403c5d:	jmpq   4016f8 <nx_rt_rebuild2_c1_k0.cold>
  403c62:	nopw   0x0(%rax,%rax,1)
  403c68:	test   %r12,%r12
  403c6b:	js     403c33 <nx_rt_rebuild2_c1_k0+0x93>
  403c6d:	jmpq   40171b <nx_rt_rebuild2_c1_k0.cold+0x23>
  403c72:	nopw   0x0(%rax,%rax,1)
  403c78:	mov    0x8(%r15),%rbx
  403c7c:	test   %rbx,%rbx
  403c7f:	je     401736 <nx_rt_rebuild2_c1_k0.cold+0x3e>
  403c85:	lea    0x0(%r13,%rbx,8),%r8
  403c8a:	mov    (%r8),%rax
  403c8d:	subq   $0x2,0x108(%r15)
  403c95:	mov    %rax,0x8(%r15)
  403c99:	jmpq   403bf8 <nx_rt_rebuild2_c1_k0+0x58>
  403c9e:	xchg   %ax,%ax
  403ca0:	mov    0x4(%rax),%edx
  403ca3:	mov    (%rax),%ecx
  403ca5:	shl    $0x20,%rdx
  403ca9:	or     %rcx,%rdx
  403cac:	mov    %rdx,%rcx
  403caf:	and    $0xffffff,%edx
  403cb5:	shr    $0x18,%rcx
  403cb9:	lea    0x8(,%rcx,8),%rdi
  403cc1:	lea    0x0(%r13,%rdi,1),%r8
  403cc6:	lea    -0x8(%r13,%rdi,1),%rdi
  403ccb:	cmp    $0x1,%rdx
  403ccf:	jne    40177f <nx_rt_rebuild2_c1_k0.cold+0x87>
  403cd5:	mov    (%rax),%edx
  403cd7:	mov    (%r15),%rdx
  403cda:	mov    (%rdi),%r14
  403cdd:	mov    (%r8),%r9
  403ce0:	mov    %rdx,(%rax)
  403ce3:	mov    0x100(%r15),%rax
  403cea:	mov    0x3e4e8(%rip),%edx        # 4421d8 <KEEP_WORDS>
  403cf0:	mov    %rbx,(%r15)
  403cf3:	add    $0x1,%rax
  403cf7:	mov    %rax,0x100(%r15)
  403cfe:	cmp    %rdx,%rax
  403d01:	jae    40175b <nx_rt_rebuild2_c1_k0.cold+0x63>
  403d07:	mov    %rcx,%rbx
  403d0a:	jmpq   403be6 <nx_rt_rebuild2_c1_k0+0x46>

Disassembly of section .fini:
