function word_to_u32(w) {
  let x = 0;
  for (let i = 0; w.$ === "WCon"; i++) {
    x |= Number(w.head) << i;
    w = w.tail;
  }
  return x >>> 0;
}

function u32_to_word(x) {
  let w = {$: "WNil"};
  for (let i = 31; i >= 0; i--) {
    w = {$: "WCon", head: ((x >>> i) & 1) === 1, tail: w};
  }
  return w;
}

function cmp_new(a, b) {
  return {$: a < b ? "LT"
    : a === b ? "EQ" : "GT"};
}

function nat_divmod(a, b) {
  return b === 0 ? {$: "Tuple", fst: 0, snd: a}
    : {$: "Tuple", fst: Math.trunc(a / b), snd: a % b};
}

function nat_chk(n) {
  if (n > 281474976710655) {
    throw "bend: a Nat past the largest immediate 2^48-1";
  }
  return n;
}

function nat_host(n) {
  const int = typeof n === "bigint" || Number.isInteger(n);
  if (int && n >= 0 && n <= 2 ** 53) {
    return Number(n);
  }
  return { [Symbol.toPrimitive]() { throw "bend: a Nat past the largest immediate 2^48-1"; } };
}

function f32_show(x) {
  if (x !== x) {
    return "nan";
  }
  if (!Number.isFinite(x) || Object.is(x, -0)) {
    return x < 0 ? "-inf"
      : x === 0 ? "-0" : "inf";
  }
  let s = "x";
  for (let p = 1; p <= 9 && f32_round(s) !== x; p += 1) {
    s = String(Number(x.toExponential(p - 1)));
  }
  return s;
}

function f32_bits(x) {
  return new Uint32Array(new Float32Array([x]).buffer)[0];
}

function f32_from_bits(u) {
  return new Float32Array(new Uint32Array([u]).buffer)[0];
}

function f32_read(s) {
  const re = /^\s*[+-]?((\d+\.?\d*|\.\d+)(e[+-]?\d+)?|inf(inity)?|nan)$/i;
  const v = f32_round(s.replace(/inf\w*/i, "Infinity"));
  return re.test(s) ? {$: "Some", value: v} : {$: "None"};
}

const f32_round = function f32_round(s        )         {
  const d = Number(s);
  const a = Math.abs(d);
  const f = Math.fround(a);
  const g = 2 * a - Math.min(f, 2 ** 128);
  if (g === f || Math.fround(g) !== g || g === Infinity) {
    return Math.sign(d) * f;
  }
  let k = 0;
  while (a * 2 ** k % 1 !== 0) {
    k += 1;
  }
  const [, i, r, e] = /(\d*)\.?(\d*)(?:e([+-]?\d+))?$/i.exec(s) ;
  const n = Number(e ?? 0) - r.length;
  const x = BigInt(i + r) * 2n ** BigInt(k) * 10n ** BigInt(Math.max(n, 0));
  const y = BigInt(a * 2 ** k) * 10n ** BigInt(Math.max(-n, 0));
  return Math.sign(d) * (x === y || x > y !== g > f ? f : g);
};

function char_new(code) {
  if (code > 0x10FFFF || (code >= 0xD800 && code <= 0xDFFF)) {
    throw "bend: " + code + " is not a Unicode scalar value";
  }
  return String.fromCodePoint(code);
}

// Array
// =====

function array_new(d, v) {
  if (d > 31) {
    throw "bend: an array past the deepest block class 31";
  }
  return Array(2 ** d).fill(v);
}

function array_node(a, b) {
  if (a.length !== b.length) {
    throw "bend: runtime fail-stop";
  }
  return a.concat(b);
}

function array_rmw(a, i, f) {
  const at = i % a.length;
  const old = a[at];
  a[at] = f(old);
  return {$: "Tuple", fst: a, snd: old};
}

// Run
// ===

function run_tail(f, x) {
  return {$: "$JMP", f: f.j?.f === f ? f.j : f, x: [x]};
}

function run_clo(j) {
  const f = (x) => run_loop(j(x));
  f.j = j;
  j.f = f;
  return f;
}

function run_loop(r) {
  while (r !== null && typeof r === "object" && r.$ === "$JMP") {
    r = r.f(...r.x);
  }
  return r;
}

function run_lib(f, n) {
  return (...a) => a.length < n ? run_lib((...b) => f(...a, ...b), n - a.length)
    : f(...a);
}

// Effect
// ======

const $0eff = Object.create(null);

function io_eff(k, run, need) {
  if (k in $0eff) {
    throw new Error("bend: two effects register " + k);
  }
  $0eff[k] = { run, need };
}
// Program
// =======

function $b2u$(_b_0) {
  if (!_b_0) {
    return 0;
  } else {
    return 1;
  }
}

function $prng$(_x_0) {
  const _x_1 = (13 >= 32 ? 0 : (_x_0 << 13) >>> 0);
  const _b_0 = ((_x_0 ^ _x_1) >>> 0);
  const _x_2 = (17 >= 32 ? 0 : (_b_0 >>> 17) >>> 0);
  const _d_0 = ((_b_0 ^ _x_2) >>> 0);
  const _x_3 = (5 >= 32 ? 0 : (_d_0 << 5) >>> 0);
  return ((_d_0 ^ _x_3) >>> 0);
}

function $umin$go$(_x_0, _y_0, _lt_0) {
  if (_lt_0) {
    return _x_0;
  } else {
    return _y_0;
  }
}

function $umin$(_x_0, _y_0) {
  return $umin$go$(_x_0, _y_0, (_x_0 < _y_0));
}

function $gen$($0, $1, $2, $3) {
  for (;;) {
    {
      const _j_0 = $0;
      const _k_0 = $1;
      const _s_0 = $2;
      const _x_0 = $3;
      if (_j_0 === 0) {
        return _x_0;
      } else {
        const _q_0 = (_j_0 - 1);
        const _s2_0 = ($prng$(_s_0));
        const _x_1 = ((_s2_0 & 3) >>> 0);
        $0 = _q_0;
        $1 = ((_k_0 + 1) >>> 0);
        $2 = _s2_0;
        $3 = (_x_0[_k_0 % _x_0.length] = _x_1, _x_0);
        continue;
      }
    }
  }
}

function $init$($0, $1, $2) {
  for (;;) {
    {
      const _j_0 = $0;
      const _k_0 = $1;
      const _x_0 = $2;
      if (_j_0 === 0) {
        return _x_0;
      } else {
        const _q_0 = (_j_0 - 1);
        $0 = _q_0;
        $1 = ((_k_0 + 1) >>> 0);
        $2 = (_x_0[_k_0 % _x_0.length] = _k_0, _x_0);
        continue;
      }
    }
  }
}

function $cell$f4$(_j_0, _cost_0, _diag_0, _up_0, _a_0, _b_0, _prev_0, _r_0) {
  const _cur_0 = _r_0["fst"];
  const _left_0 = _r_0["snd"];
  const _v_0 = ($umin$(($umin$(((_up_0 + 1) >>> 0), ((_left_0 + 1) >>> 0))), ((_diag_0 + _cost_0) >>> 0)));
  const _x_0 = ((_j_0 + 1) >>> 0);
  return {$: "Dp", "a": _a_0, "b": _b_0, "prev": _prev_0, "cur": (_cur_0[_x_0 % _cur_0.length] = _v_0, _cur_0)};
}

function $cell$f3$(_j_0, _cost_0, _diag_0, _a_0, _b_0, _cur_0, _r_0) {
  const _prev_0 = _r_0["fst"];
  const _up_0 = _r_0["snd"];
  return $cell$f4$(_j_0, _cost_0, _diag_0, _up_0, _a_0, _b_0, _prev_0, {$: "Tuple", fst: _cur_0, snd: _cur_0[_j_0 % _cur_0.length]});
}

function $cell$f2$(_j_0, _cost_0, _a_0, _b_0, _cur_0, _r_0) {
  const _prev_0 = _r_0["fst"];
  const _diag_0 = _r_0["snd"];
  const _x_0 = ((_j_0 + 1) >>> 0);
  return $cell$f3$(_j_0, _cost_0, _diag_0, _a_0, _b_0, _cur_0, {$: "Tuple", fst: _prev_0, snd: _prev_0[_x_0 % _prev_0.length]});
}

function $cell$f1$(_j_0, _ai_0, _a_0, _prev_0, _cur_0, _r_0) {
  const _b_0 = _r_0["fst"];
  const _bj_0 = _r_0["snd"];
  return $cell$f2$(_j_0, ($b2u$((_ai_0 !== _bj_0))), _a_0, _b_0, _cur_0, {$: "Tuple", fst: _prev_0, snd: _prev_0[_j_0 % _prev_0.length]});
}

function $cell$(_j_0, _ai_0, _st_0) {
  const _a_0 = _st_0["a"];
  const _b_0 = _st_0["b"];
  const _prev_0 = _st_0["prev"];
  const _cur_0 = _st_0["cur"];
  return $cell$f1$(_j_0, _ai_0, _a_0, _prev_0, _cur_0, {$: "Tuple", fst: _b_0, snd: _b_0[_j_0 % _b_0.length]});
}

function $row$($0, $1, $2, $3) {
  for (;;) {
    {
      const _n_0 = $0;
      const _j_0 = $1;
      const _ai_0 = $2;
      const _st_0 = $3;
      if (_n_0 === 0) {
        const _a_0 = _st_0["a"];
        const _b_0 = _st_0["b"];
        const _prev_0 = _st_0["prev"];
        const _cur_0 = _st_0["cur"];
        return {$: "Dp", "a": _a_0, "b": _b_0, "prev": _cur_0, "cur": _prev_0};
      } else {
        const _q_0 = (_n_0 - 1);
        $0 = _q_0;
        $1 = ((_j_0 + 1) >>> 0);
        $2 = _ai_0;
        $3 = ($cell$(_j_0, _ai_0, _st_0));
        continue;
      }
    }
  }
}

function $dp$f1$(_i_0, _b_0, _prev_0, _cur_0, _r_0) {
  const _a_0 = _r_0["fst"];
  const _ai_0 = _r_0["snd"];
  const _x_0 = ((_i_0 + 1) >>> 0);
  return $row$(256, 0, _ai_0, {$: "Dp", "a": _a_0, "b": _b_0, "prev": _prev_0, "cur": (_cur_0[0 % _cur_0.length] = _x_0, _cur_0)});
}

function $dp$row$(_i_0, _st_0) {
  const _a_0 = _st_0["a"];
  const _b_0 = _st_0["b"];
  const _prev_0 = _st_0["prev"];
  const _cur_0 = _st_0["cur"];
  return $dp$f1$(_i_0, _b_0, _prev_0, _cur_0, {$: "Tuple", fst: _a_0, snd: _a_0[_i_0 % _a_0.length]});
}

function $dp$($0, $1, $2) {
  for (;;) {
    {
      const _n_0 = $0;
      const _i_0 = $1;
      const _st_0 = $2;
      if (_n_0 === 0) {
        return _st_0;
      } else {
        const _q_0 = (_n_0 - 1);
        $0 = _q_0;
        $1 = ((_i_0 + 1) >>> 0);
        $2 = ($dp$row$(_i_0, _st_0));
        continue;
      }
    }
  }
}

function $dist$fin$(_r_0) {
  const _d_0 = _r_0["snd"];
  return _d_0;
}

function $dist$(_st_0) {
  const _prev_0 = _st_0["prev"];
  return $dist$fin$({$: "Tuple", fst: _prev_0, snd: _prev_0[256 % _prev_0.length]});
}

function $pair$(_p_0) {
  const _x_0 = ((_p_0 + 1) >>> 0);
  const _s_0 = (Math.imul(_x_0, 2654435761) >>> 0);
  const _a_0 = ($gen$(256, 0, _s_0, array_new(8, 0)));
  const _b_0 = ($gen$(256, 0, (Math.imul(_s_0, 340573321) >>> 0), array_new(8, 0)));
  const _prev_0 = ($init$(257, 0, array_new(9, 0)));
  const _d_0 = ($dist$(($dp$(256, 0, {$: "Dp", "a": _a_0, "b": _b_0, "prev": _prev_0, "cur": array_new(9, 0)}))));
  const _x_1 = (Math.imul(_d_0, 2654435761) >>> 0);
  const _x_2 = ((_p_0 + 1) >>> 0);
  return ((_x_1 ^ _x_2) >>> 0);
}

function $batch$(_d_0, _p_0) {
  if (_d_0 === 0) {
    return $pair$(_p_0);
  } else {
    const _q_0 = (_d_0 - 1);
    const _x_0 = ($batch$(_q_0, _p_0));
    const _x_1 = (_q_0 >= 32 ? 0 : (1 << _q_0) >>> 0);
    const _y_0 = ($batch$(_q_0, ((_p_0 + _x_1) >>> 0)));
    return ((_x_0 + _y_0) >>> 0);
  }
}

function $size$small$() {
  return 2;
}

function $size$big$() {
  return 15;
}

function $bench$(_size_0, _seed_0) {
  return $batch$(_size_0, _seed_0);
}

function $row$probe$(_n_0, _seed_0) {
  const _count_0 = _n_0;
  const _a_0 = ($gen$(_count_0, 0, _seed_0, array_new(7, 0)));
  const _b_0 = ($gen$(_count_0, 0, (Math.imul(_seed_0, 340573321) >>> 0), array_new(7, 0)));
  const _x_0 = ((_n_0 + 1) >>> 0);
  const _prev_0 = ($init$(_x_0, 0, array_new(7, 0)));
  return $row$(_count_0, 0, ((_seed_0 & 3) >>> 0), {$: "Dp", "a": _a_0, "b": _b_0, "prev": _prev_0, "cur": array_new(7, 0)});
}
export default {
  "b2u": run_lib((a0) => { const r = (run_loop($b2u$((a0)))); (a0); return r; }, 1),
  "prng": run_lib((a0) => { const r = (run_loop($prng$((a0)))); (a0); return r; }, 1),
  "umin.go": run_lib((a0, a1, a2) => { const r = (run_loop($umin$go$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "umin": run_lib((a0, a1) => { const r = (run_loop($umin$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "gen": run_lib((a0, a1, a2, a3) => { const r = (run_loop($gen$(nat_host(a0), (a1), (a2), (a3)))); BigInt(a0); (a1); (a2); (a3); return r; }, 4),
  "init": run_lib((a0, a1, a2) => { const r = (run_loop($init$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "cell.f4": run_lib((a0, a1, a2, a3, a4, a5, a6, a7) => { const r = (run_loop($cell$f4$((a0), (a1), (a2), (a3), (a4), (a5), (a6), (a7)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); (a7); return r; }, 8),
  "cell.f3": run_lib((a0, a1, a2, a3, a4, a5, a6) => { const r = (run_loop($cell$f3$((a0), (a1), (a2), (a3), (a4), (a5), (a6)))); (a0); (a1); (a2); (a3); (a4); (a5); (a6); return r; }, 7),
  "cell.f2": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($cell$f2$((a0), (a1), (a2), (a3), (a4), (a5)))); (a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "cell.f1": run_lib((a0, a1, a2, a3, a4, a5) => { const r = (run_loop($cell$f1$((a0), (a1), (a2), (a3), (a4), (a5)))); (a0); (a1); (a2); (a3); (a4); (a5); return r; }, 6),
  "cell": run_lib((a0, a1, a2) => { const r = (run_loop($cell$((a0), (a1), (a2)))); (a0); (a1); (a2); return r; }, 3),
  "row": run_lib((a0, a1, a2, a3) => { const r = (run_loop($row$(nat_host(a0), (a1), (a2), (a3)))); BigInt(a0); (a1); (a2); (a3); return r; }, 4),
  "dp.f1": run_lib((a0, a1, a2, a3, a4) => { const r = (run_loop($dp$f1$((a0), (a1), (a2), (a3), (a4)))); (a0); (a1); (a2); (a3); (a4); return r; }, 5),
  "dp.row": run_lib((a0, a1) => { const r = (run_loop($dp$row$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "dp": run_lib((a0, a1, a2) => { const r = (run_loop($dp$(nat_host(a0), (a1), (a2)))); BigInt(a0); (a1); (a2); return r; }, 3),
  "dist.fin": run_lib((a0) => { const r = (run_loop($dist$fin$((a0)))); (a0); return r; }, 1),
  "dist": run_lib((a0) => { const r = (run_loop($dist$((a0)))); (a0); return r; }, 1),
  "pair": run_lib((a0) => { const r = (run_loop($pair$((a0)))); (a0); return r; }, 1),
  "batch": run_lib((a0, a1) => { const r = (run_loop($batch$(nat_host(a0), (a1)))); BigInt(a0); (a1); return r; }, 2),
  "size.small": run_lib(() => { const r = BigInt(run_loop($size$small$()));  return r; }, 0),
  "size.big": run_lib(() => { const r = BigInt(run_loop($size$big$()));  return r; }, 0),
  "bench": run_lib((a0, a1) => { const r = (run_loop($bench$((a0), (a1)))); (a0); (a1); return r; }, 2),
  "row.probe": run_lib((a0, a1) => { const r = (run_loop($row$probe$((a0), (a1)))); (a0); (a1); return r; }, 2),
};
