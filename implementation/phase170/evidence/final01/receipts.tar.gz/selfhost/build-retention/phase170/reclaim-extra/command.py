#!/usr/bin/env python3
"""Root-operated apply/restore of the exact authenticated extra selective plans."""
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
ROOT=Path(__file__).resolve().parents[4]
PLAN=Path(__file__).with_name('plan.json')
EXPECTED_SHA='c367ac0a09ef464156bd1f9335fbe17fc2677156f5836196c0c45da4ec2ab625'

def authenticate(identity):
    path=Path(identity['file']);data=path.read_bytes()
    if len(data)!=identity['bytes'] or hashlib.sha256(data).hexdigest()!=identity['sha256']:
        raise ValueError('Changed pinned file: '+str(path))
    return path

def main():
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('action',choices=['check','apply','restore'])
    args=p.parse_args()
    data=PLAN.read_bytes()
    if hashlib.sha256(data).hexdigest()!=EXPECTED_SHA:raise ValueError('Aggregate reviewed plan changed')
    manifest=json.loads(data)
    if not manifest['complete'] or manifest['totals']['selectedFiles']!=114:raise ValueError('Incomplete plan')
    for row in manifest['roots']:
        for key in ['archiveReceipt','lifecycle','closure','policy','plan']:authenticate(row[key])
        plan=json.loads(authenticate(row['plan']).read_text())
        listing=authenticate(plan['files'])
        entries=[json.loads(line) for line in listing.read_text().splitlines()]
        actual={v['file']['file']:(v['file']['bytes'],v['file']['sha256']) for v in entries}
        expected={v['file']:(v['bytes'],v['sha256']) for v in row['selectedFiles']}
        if len(entries)!=len(expected) or actual!=expected or plan['allocatedBytes']!=row['allocatedBytes']:
            raise ValueError('Wrong verified selection: '+row['name'])
    if args.action!='check':
        for row in manifest['roots']:subprocess.run(row[args.action+'Command'],cwd=ROOT,check=True)
    print(json.dumps(dict(complete=True,action=args.action,roots=40,selectedFiles=114,allocatedBytes=manifest['totals']['allocatedBytes'])))

if __name__=='__main__':main()
