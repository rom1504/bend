
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401c00 <nx_list_reverse>:
  401c00:	push   %r12
  401c02:	mov    %rsi,%rax
  401c05:	mov    %rdx,%r12
  401c08:	push   %rbp
  401c09:	shr    $0x28,%rax
  401c0d:	sub    $0x8,%rsp
  401c11:	and    $0xffff,%eax
  401c16:	je     401c5b <nx_list_reverse+0x5b>
  401c18:	mov    %rdi,%rbp
  401c1b:	cmp    $0x1,%rax
  401c1f:	je     401c2e <nx_list_reverse+0x2e>
  401c21:	jmp    401c70 <nx_list_reverse+0x70>
  401c23:	nopl   0x0(%rax,%rax,1)
  401c28:	cmp    $0x1,%rax
  401c2c:	jne    401c70 <nx_list_reverse+0x70>
  401c2e:	mov    %r12,%r8
  401c31:	xor    %ecx,%ecx
  401c33:	mov    $0x1,%edx
  401c38:	mov    %rbp,%rdi
  401c3b:	callq  402d50 <nx_rt_rebuild2>
  401c40:	xor    %esi,%esi
  401c42:	mov    %rbp,%rdi
  401c45:	mov    %rax,%r12
  401c48:	callq  402d30 <nx_rt_fast_field>
  401c4d:	mov    %rax,%rsi
  401c50:	shr    $0x28,%rax
  401c54:	and    $0xffff,%eax
  401c59:	jne    401c28 <nx_list_reverse+0x28>
  401c5b:	add    $0x8,%rsp
  401c5f:	mov    %r12,%rax
  401c62:	pop    %rbp
  401c63:	pop    %r12
  401c65:	retq   
  401c66:	nopw   %cs:0x0(%rax,%rax,1)
  401c70:	add    $0x8,%rsp
  401c74:	mov    %rbp,%rdi
  401c77:	mov    $0x1,%esi
  401c7c:	pop    %rbp
  401c7d:	pop    %r12
  401c7f:	jmpq   402580 <nx_rt_fail>

Disassembly of section .fini:
