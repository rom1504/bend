
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/pair-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403740 <nx_rt_rebuild2_c3_k0>:
  403740:	push   %r13
  403742:	mov    %rsi,%r10
  403745:	mov    %rdx,%r8
  403748:	movabs $0xffffffffff,%r9
  403752:	push   %r12
  403754:	and    %r10,%r9
  403757:	push   %rbp
  403758:	lea    0x0(,%r9,8),%rax
  403760:	push   %rbx
  403761:	mov    %rdi,%rbx
  403764:	sub    $0x28,%rsp
  403768:	mov    (%rdi),%rdi
  40376b:	mov    0x8(%rbx),%rsi
  40376f:	lea    (%rdi,%rax,1),%rdx
  403773:	test   %r10,%r10
  403776:	js     4037e0 <nx_rt_rebuild2_c3_k0+0xa0>
  403778:	mov    (%rdx),%r12
  40377b:	mov    0x8(%rdi,%rax,1),%rbp
  403780:	cmp    $0x310817f,%r9
  403787:	jbe    4037b8 <nx_rt_rebuild2_c3_k0+0x78>
  403789:	mov    %rbp,0x10(%rbx)
  40378d:	mov    %r12,%rcx
  403790:	mov    $0x3,%edx
  403795:	movq   $0xffffffffffffffff,0x18(%rbx)
  40379d:	movl   $0x1,0x20(%rbx)
  4037a4:	add    $0x28,%rsp
  4037a8:	pop    %rbx
  4037a9:	pop    %rbp
  4037aa:	pop    %r12
  4037ac:	pop    %r13
  4037ae:	jmpq   401f70 <nx_construct2>
  4037b3:	nopl   0x0(%rax,%rax,1)
  4037b8:	mov    0x8(%rsi),%r9
  4037bc:	test   %r9,%r9
  4037bf:	je     40188c <nx_rt_rebuild2_c3_k0.cold>
  4037c5:	mov    (%rdi,%r9,8),%rax
  4037c9:	subq   $0x2,0x108(%rsi)
  4037d1:	mov    %rax,0x8(%rsi)
  4037d5:	jmp    403789 <nx_rt_rebuild2_c3_k0+0x49>
  4037d7:	nopw   0x0(%rax,%rax,1)
  4037e0:	mov    0x4(%rdx),%eax
  4037e3:	mov    (%rdx),%ecx
  4037e5:	shl    $0x20,%rax
  4037e9:	or     %rcx,%rax
  4037ec:	mov    %rax,%r13
  4037ef:	and    $0xffffff,%eax
  4037f4:	shr    $0x18,%r13
  4037f8:	lea    0x0(,%r13,8),%r11
  403800:	lea    (%rdi,%r11,1),%rbp
  403804:	lea    0x8(%rdi,%r11,1),%r11
  403809:	cmp    $0x1,%rax
  40380d:	jne    4018d2 <nx_rt_rebuild2_c3_k0.cold+0x46>
  403813:	mov    (%rdx),%eax
  403815:	mov    (%rsi),%rax
  403818:	mov    0x0(%rbp),%r12
  40381c:	mov    (%r11),%rbp
  40381f:	mov    %rax,(%rdx)
  403822:	mov    0x100(%rsi),%rax
  403829:	mov    0x3d9a9(%rip),%edx        # 4411d8 <KEEP_WORDS>
  40382f:	mov    %r9,(%rsi)
  403832:	add    $0x1,%rax
  403836:	mov    %rax,0x100(%rsi)
  40383d:	cmp    %rdx,%rax
  403840:	jae    4018bc <nx_rt_rebuild2_c3_k0.cold+0x30>
  403846:	mov    %r13,%r9
  403849:	jmpq   403780 <nx_rt_rebuild2_c3_k0+0x40>

Disassembly of section .fini:
