
/home/ai/bend2/build/publish/bend/selfhost/build/phase109/suite01/trusted-reverse-kernel/direct-clang:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401910 <nx_string_reverse>:
  401910:	push   %r15
  401912:	push   %r14
  401914:	push   %r12
  401916:	push   %rbx
  401917:	push   %rax
  401918:	mov    %rdx,%r14
  40191b:	mov    %rsi,%r15
  40191e:	mov    %rdi,%rbx
  401921:	data16 data16 data16 data16 data16 nopw %cs:0x0(%rax,%rax,1)
  401930:	mov    %rbx,%rdi
  401933:	mov    %r15,%rsi
  401936:	callq  402710 <nx_rt_fast_id>
  40193b:	cmp    $0x3,%eax
  40193e:	jne    401980 <nx_string_reverse+0x70>
  401940:	mov    %rbx,%rdi
  401943:	mov    %r15,%rsi
  401946:	callq  4028a0 <nx_rt_fast_take2>
  40194b:	mov    %rbx,%rdi
  40194e:	xor    %esi,%esi
  401950:	callq  4029c0 <nx_rt_fast_field>
  401955:	mov    %rax,%r12
  401958:	mov    %rbx,%rdi
  40195b:	mov    $0x1,%esi
  401960:	callq  4029c0 <nx_rt_fast_field>
  401965:	mov    %rax,%r15
  401968:	mov    %rbx,%rdi
  40196b:	mov    $0x3,%esi
  401970:	mov    %r12,%rdx
  401973:	mov    %r14,%rcx
  401976:	callq  4027f0 <nx_rt_fast_build2>
  40197b:	mov    %rax,%r14
  40197e:	jmp    401930 <nx_string_reverse+0x20>
  401980:	cmp    $0x2,%eax
  401983:	jne    401994 <nx_string_reverse+0x84>
  401985:	mov    %r14,%rax
  401988:	add    $0x8,%rsp
  40198c:	pop    %rbx
  40198d:	pop    %r12
  40198f:	pop    %r14
  401991:	pop    %r15
  401993:	retq   
  401994:	mov    %rbx,%rdi
  401997:	mov    $0x1,%esi
  40199c:	add    $0x8,%rsp
  4019a0:	pop    %rbx
  4019a1:	pop    %r12
  4019a3:	pop    %r14
  4019a5:	pop    %r15
  4019a7:	jmpq   402210 <nx_rt_fail>

Disassembly of section .fini:
