
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/build01/tagged-gcc:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000401907 <nx_rt_pair_rebuild2_c3_k0.cold>:
  401907:	mov    $0x1,%edx
  40190c:	mov    %rbp,%rdi
  40190f:	mov    %r8,0x8(%rsp)
  401914:	mov    %rsi,(%rsp)
  401918:	callq  401178 <heap_alloc_miss>
  40191d:	mov    (%rsp),%rsi
  401921:	mov    0x8(%rsp),%r8
  401926:	mov    %rax,%r9
  401929:	jmpq   403918 <nx_rt_pair_rebuild2_c3_k0+0x48>
  40192e:	xor    %edx,%edx
  401930:	mov    %rbp,%rdi
  401933:	mov    %r8,(%rsp)
  401937:	callq  401100 <heap_hand>
  40193c:	mov    (%rsp),%r8
  401940:	jmpq   4039c4 <nx_rt_pair_rebuild2_c3_k0+0xf4>
  401945:	mov    (%rcx),%r13
  401948:	mov    (%rdi),%r12
  40194b:	mov    %r14,%rcx
  40194e:	mov    %r10,%rdx
  401951:	mov    %rbp,%rdi
  401954:	mov    %r8,0x8(%rsp)
  401959:	mov    %rsi,(%rsp)
  40195d:	callq  4014c6 <span_fade.constprop.0>
  401962:	mov    (%rsp),%rsi
  401966:	mov    0x8(%rsp),%r8
  40196b:	jmpq   403940 <nx_rt_pair_rebuild2_c3_k0+0x70>

Disassembly of section .fini:
