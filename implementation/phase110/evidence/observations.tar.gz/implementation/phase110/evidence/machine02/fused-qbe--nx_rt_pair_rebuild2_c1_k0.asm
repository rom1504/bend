
/home/ai/bend2/build/publish/bend/selfhost/build/phase110/private-build01/fused-qbe:     file format elf64-x86-64


Disassembly of section .init:

Disassembly of section .plt:

Disassembly of section .text:

0000000000403730 <nx_rt_pair_rebuild2_c1_k0>:
  403730:	push   %r15
  403732:	push   %r14
  403734:	push   %r13
  403736:	push   %r12
  403738:	mov    %rdx,%r12
  40373b:	push   %rbp
  40373c:	push   %rbx
  40373d:	movabs $0xffffffffff,%rbx
  403747:	and    %rsi,%rbx
  40374a:	lea    0x0(,%rbx,8),%rdx
  403752:	sub    $0x18,%rsp
  403756:	mov    (%rdi),%rbp
  403759:	mov    0x8(%rdi),%r15
  40375d:	lea    0x0(%rbp,%rdx,1),%rax
  403762:	test   %rsi,%rsi
  403765:	js     403820 <nx_rt_pair_rebuild2_c1_k0+0xf0>
  40376b:	mov    (%rax),%r14
  40376e:	mov    0x8(%rbp,%rdx,1),%r13
  403773:	cmp    $0x310817f,%rbx
  40377a:	jbe    4037f0 <nx_rt_pair_rebuild2_c1_k0+0xc0>
  40377c:	lea    0x0(%rbp,%rbx,8),%r8
  403781:	mov    %r14,%rax
  403784:	shr    $0x38,%rax
  403788:	and    $0x7f,%eax
  40378b:	cmp    $0x2,%rax
  40378f:	je     4037d0 <nx_rt_pair_rebuild2_c1_k0+0xa0>
  403791:	mov    %r12,%rax
  403794:	mov    %r14,(%r8)
  403797:	lea    0x8(%rbp,%rbx,8),%r14
  40379c:	shr    $0x38,%rax
  4037a0:	and    $0x7f,%eax
  4037a3:	cmp    $0x2,%rax
  4037a7:	je     4037e0 <nx_rt_pair_rebuild2_c1_k0+0xb0>
  4037a9:	movabs $0x200010000000000,%rax
  4037b3:	mov    %r12,(%r14)
  4037b6:	mov    %r13,%rdx
  4037b9:	add    $0x18,%rsp
  4037bd:	or     %rbx,%rax
  4037c0:	pop    %rbx
  4037c1:	pop    %rbp
  4037c2:	pop    %r12
  4037c4:	pop    %r13
  4037c6:	pop    %r14
  4037c8:	pop    %r15
  4037ca:	retq   
  4037cb:	nopl   0x0(%rax,%rax,1)
  4037d0:	test   %r14,%r14
  4037d3:	js     403791 <nx_rt_pair_rebuild2_c1_k0+0x61>
  4037d5:	jmpq   4017a0 <nx_rt_pair_rebuild2_c1_k0.cold>
  4037da:	nopw   0x0(%rax,%rax,1)
  4037e0:	test   %r12,%r12
  4037e3:	js     4037a9 <nx_rt_pair_rebuild2_c1_k0+0x79>
  4037e5:	jmpq   4017c5 <nx_rt_pair_rebuild2_c1_k0.cold+0x25>
  4037ea:	nopw   0x0(%rax,%rax,1)
  4037f0:	mov    0x8(%r15),%rbx
  4037f4:	test   %rbx,%rbx
  4037f7:	je     4017e0 <nx_rt_pair_rebuild2_c1_k0.cold+0x40>
  4037fd:	lea    0x0(%rbp,%rbx,8),%r8
  403802:	mov    (%r8),%rax
  403805:	subq   $0x2,0x108(%r15)
  40380d:	mov    %rax,0x8(%r15)
  403811:	jmpq   403781 <nx_rt_pair_rebuild2_c1_k0+0x51>
  403816:	nopw   %cs:0x0(%rax,%rax,1)
  403820:	mov    0x4(%rax),%edx
  403823:	mov    (%rax),%ecx
  403825:	shl    $0x20,%rdx
  403829:	or     %rcx,%rdx
  40382c:	mov    %rdx,%rcx
  40382f:	and    $0xffffff,%edx
  403835:	shr    $0x18,%rcx
  403839:	lea    0x8(,%rcx,8),%rdi
  403841:	lea    0x0(%rbp,%rdi,1),%r8
  403846:	lea    -0x8(%rbp,%rdi,1),%rdi
  40384b:	cmp    $0x1,%rdx
  40384f:	jne    401819 <nx_rt_pair_rebuild2_c1_k0.cold+0x79>
  403855:	mov    (%rax),%edx
  403857:	mov    (%r15),%rdx
  40385a:	mov    (%rdi),%r14
  40385d:	mov    (%r8),%r13
  403860:	mov    %rdx,(%rax)
  403863:	mov    0x100(%r15),%rax
  40386a:	mov    0x3d968(%rip),%edx        # 4411d8 <KEEP_WORDS>
  403870:	mov    %rbx,(%r15)
  403873:	add    $0x1,%rax
  403877:	mov    %rax,0x100(%r15)
  40387e:	cmp    %rdx,%rax
  403881:	jae    4017fd <nx_rt_pair_rebuild2_c1_k0.cold+0x5d>
  403887:	mov    %rcx,%rbx
  40388a:	jmpq   403773 <nx_rt_pair_rebuild2_c1_k0+0x43>

Disassembly of section .fini:
