  406f30:	endbr64 
  406f34:	push   %rbp
  406f35:	mov    %rsp,%rbp
  406f38:	sub    $0x800,%rsp
  406f3f:	push   %rbx
  406f40:	push   %r12
  406f42:	mov    %rsi,-0x800(%rbp)
  406f49:	mov    %rdx,-0x7f8(%rbp)
  406f50:	lea    -0x800(%rbp),%rdx
  406f57:	mov    $0xa4,%esi
  406f5c:	mov    %rdi,%rbx
  406f5f:	callq  414ad0 <p125_rt_ctor2>
  406f64:	mov    %rbx,%rdi
  406f67:	mov    %rax,%rsi
  406f6a:	mov    %rdi,%rbx
  406f6d:	callq  40ed90 <p111_rt_keep>
  406f72:	mov    %rbx,%rdi
  406f75:	mov    %rax,%rsi
  406f78:	mov    %rsi,%r12
  406f7b:	mov    %rdi,%rbx
  406f7e:	callq  406c80 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_108_101_102_116_>
  406f83:	mov    %r12,%rsi
  406f86:	mov    %rbx,%rdi
  406f89:	mov    %rax,%rbx
  406f8c:	callq  406ad0 <p113d_FID_36_100_105_114_101_99_116_46_112_49_57_52_46_114_105_103_104_116_>
  406f91:	mov    %rax,%rcx
  406f94:	mov    %ebx,%eax
  406f96:	mov    %ecx,%ecx
  406f98:	add    %ecx,%eax
  406f9a:	mov    %eax,%eax
  406f9c:	pop    %r12
  406f9e:	pop    %rbx
  406f9f:	leaveq 
  406fa0:	retq   
  406fa1:	data16 nopw %cs:0x0(%rax,%rax,1)
  406fac:	nopl   0x0(%rax)
